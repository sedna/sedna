/* Generated from data-structures.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:35
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: data-structures.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file udata-structures.c -extend ./private-namespace.scm
   unit: data_structures
*/

#include "chicken.h"

#define C_mem_compare(to, from, n)   C_fix(C_memcmp(C_c_string(to), C_c_string(from), C_unfix(n)))

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[112];
static double C_possibly_force_alignment;


C_noret_decl(C_data_structures_toplevel)
C_externexport void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4682)
static C_word C_fcall f_4682(C_word t0);
C_noret_decl(f_4668)
static void C_fcall f_4668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4591)
static void C_fcall f_4591(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4495)
static void C_ccall f_4495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4505)
static void C_fcall f_4505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_fcall f_4349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_fcall f_4363(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4343)
static void C_ccall f_4343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4188)
static void C_fcall f_4188(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_fcall f_4229(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3988)
static void C_fcall f_3988(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3920)
static void C_fcall f_3920(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_fcall f_3872(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3736)
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3751)
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3771)
static void C_ccall f_3771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3614)
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3626)
static void C_fcall f_3626(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3659)
static void C_fcall f_3659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_fcall f_3698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3644)
static void C_fcall f_3644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_fcall f_3469(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_fcall f_3415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3426)
static C_word C_fcall f_3426(C_word t0,C_word t1);
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3322)
static void C_fcall f_3322(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3332)
static void C_ccall f_3332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static C_word C_fcall f_3337(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3210)
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3237)
static void C_fcall f_3237(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_fcall f_3190(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3205)
static void C_ccall f_3205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_fcall f_3197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3092)
static void C_ccall f_3092r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3109)
static void C_fcall f_3109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_fcall f_3104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3099)
static void C_fcall f_3099(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3094)
static void C_fcall f_3094(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3065)
static void C_fcall f_3065(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2995)
static void C_fcall f_2995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_fcall f_2990(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2985)
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2980)
static void C_fcall f_2980(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2951)
static void C_fcall f_2951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2834)
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2772)
static void C_fcall f_2772(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2793)
static void C_fcall f_2793(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2806)
static void C_ccall f_2806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2762)
static void C_ccall f_2762r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2643)
static void C_fcall f_2643(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_fcall f_2668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2602)
static void C_fcall f_2602(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2545)
static void C_fcall f_2545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_fcall f_2540(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2471)
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2506)
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2522)
static void C_ccall f_2522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_fcall f_2475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2478)
static void C_ccall f_2478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2428)
static void C_fcall f_2428(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_fcall f_2390(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2373)
static void C_ccall f_2373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2271)
static void C_fcall f_2271(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2215)
static void C_fcall f_2215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_fcall f_2133(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2154)
static void C_fcall f_2154(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2083)
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2054)
static void C_fcall f_2054(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2018)
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1996)
static C_word C_fcall f_1996(C_word t0,C_word t1);
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1900)
static void C_fcall f_1900(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1825)
static void C_ccall f_1825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1833)
static void C_fcall f_1833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1798)
static void C_fcall f_1798(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1823)
static void C_ccall f_1823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1678)
static void C_fcall f_1678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1645)
static void C_fcall f_1645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_4668)
static void C_fcall trf_4668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4668(t0,t1);}

C_noret_decl(trf_4591)
static void C_fcall trf_4591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4591(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4591(t0,t1,t2);}

C_noret_decl(trf_4505)
static void C_fcall trf_4505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4505(t0,t1);}

C_noret_decl(trf_4349)
static void C_fcall trf_4349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4349(t0,t1);}

C_noret_decl(trf_4363)
static void C_fcall trf_4363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4363(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4363(t0,t1,t2,t3);}

C_noret_decl(trf_4284)
static void C_fcall trf_4284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4284(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4284(t0,t1,t2,t3);}

C_noret_decl(trf_4188)
static void C_fcall trf_4188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4188(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4188(t0,t1,t2);}

C_noret_decl(trf_4229)
static void C_fcall trf_4229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4229(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4229(t0,t1);}

C_noret_decl(trf_4056)
static void C_fcall trf_4056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4056(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4056(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3988)
static void C_fcall trf_3988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3988(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3988(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3920)
static void C_fcall trf_3920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3920(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3920(t0,t1,t2,t3);}

C_noret_decl(trf_3872)
static void C_fcall trf_3872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3872(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3872(t0,t1,t2);}

C_noret_decl(trf_3751)
static void C_fcall trf_3751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3751(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3751(t0,t1,t2,t3);}

C_noret_decl(trf_3626)
static void C_fcall trf_3626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3626(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3626(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3659)
static void C_fcall trf_3659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3659(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3659(t0,t1,t2);}

C_noret_decl(trf_3698)
static void C_fcall trf_3698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3698(t0,t1);}

C_noret_decl(trf_3644)
static void C_fcall trf_3644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3644(t0,t1);}

C_noret_decl(trf_3469)
static void C_fcall trf_3469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3469(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3469(t0,t1,t2,t3);}

C_noret_decl(trf_3415)
static void C_fcall trf_3415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3415(t0,t1);}

C_noret_decl(trf_3322)
static void C_fcall trf_3322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3322(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3322(t0,t1,t2,t3);}

C_noret_decl(trf_3210)
static void C_fcall trf_3210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3210(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3210(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3237)
static void C_fcall trf_3237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3237(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3237(t0,t1,t2);}

C_noret_decl(trf_3190)
static void C_fcall trf_3190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3190(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3190(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3197)
static void C_fcall trf_3197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3197(t0,t1);}

C_noret_decl(trf_3109)
static void C_fcall trf_3109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3109(t0,t1);}

C_noret_decl(trf_3104)
static void C_fcall trf_3104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3104(t0,t1,t2);}

C_noret_decl(trf_3099)
static void C_fcall trf_3099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3099(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3099(t0,t1,t2,t3);}

C_noret_decl(trf_3094)
static void C_fcall trf_3094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3094(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3094(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3065)
static void C_fcall trf_3065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3065(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3065(t0,t1);}

C_noret_decl(trf_2995)
static void C_fcall trf_2995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2995(t0,t1);}

C_noret_decl(trf_2990)
static void C_fcall trf_2990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2990(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2990(t0,t1,t2);}

C_noret_decl(trf_2985)
static void C_fcall trf_2985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2985(t0,t1,t2,t3);}

C_noret_decl(trf_2980)
static void C_fcall trf_2980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2980(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2980(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2951)
static void C_fcall trf_2951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2951(t0,t1);}

C_noret_decl(trf_2772)
static void C_fcall trf_2772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2772(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2772(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2793)
static void C_fcall trf_2793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2793(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2793(t0,t1,t2,t3);}

C_noret_decl(trf_2643)
static void C_fcall trf_2643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2643(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2643(t0,t1,t2,t3);}

C_noret_decl(trf_2668)
static void C_fcall trf_2668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2668(t0,t1,t2,t3);}

C_noret_decl(trf_2602)
static void C_fcall trf_2602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2602(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2602(t0,t1,t2);}

C_noret_decl(trf_2545)
static void C_fcall trf_2545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2545(t0,t1);}

C_noret_decl(trf_2540)
static void C_fcall trf_2540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2540(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2540(t0,t1,t2);}

C_noret_decl(trf_2471)
static void C_fcall trf_2471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2471(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2471(t0,t1,t2,t3);}

C_noret_decl(trf_2506)
static void C_fcall trf_2506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2506(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2506(t0,t1,t2);}

C_noret_decl(trf_2475)
static void C_fcall trf_2475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2475(t0,t1);}

C_noret_decl(trf_2428)
static void C_fcall trf_2428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2428(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2428(t0,t1,t2);}

C_noret_decl(trf_2390)
static void C_fcall trf_2390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2390(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2390(t0,t1);}

C_noret_decl(trf_2271)
static void C_fcall trf_2271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2271(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2271(t0,t1,t2,t3);}

C_noret_decl(trf_2215)
static void C_fcall trf_2215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2215(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2215(t0,t1,t2);}

C_noret_decl(trf_2133)
static void C_fcall trf_2133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2133(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2133(t0,t1,t2,t3);}

C_noret_decl(trf_2154)
static void C_fcall trf_2154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2154(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2154(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2083)
static void C_fcall trf_2083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2083(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2083(t0,t1,t2,t3);}

C_noret_decl(trf_2054)
static void C_fcall trf_2054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2054(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2054(t0,t1,t2);}

C_noret_decl(trf_2018)
static void C_fcall trf_2018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2018(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2018(t0,t1,t2);}

C_noret_decl(trf_1900)
static void C_fcall trf_1900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1900(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1900(t0,t1,t2);}

C_noret_decl(trf_1833)
static void C_fcall trf_1833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1833(t0,t1,t2);}

C_noret_decl(trf_1798)
static void C_fcall trf_1798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1798(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1798(t0,t1,t2);}

C_noret_decl(trf_1678)
static void C_fcall trf_1678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1678(t0,t1,t2);}

C_noret_decl(trf_1645)
static void C_fcall trf_1645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1645(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_data_structures_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("data_structures_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1020)){
C_save(t1);
C_rereclaim2(1020*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,112);
lf[0]=C_h_intern(&lf[0],8,"identity");
lf[1]=C_h_intern(&lf[1],7,"project");
lf[2]=C_h_intern(&lf[2],7,"conjoin");
lf[3]=C_h_intern(&lf[3],7,"disjoin");
lf[4]=C_h_intern(&lf[4],10,"constantly");
lf[5]=C_h_intern(&lf[5],4,"flip");
lf[6]=C_h_intern(&lf[6],10,"complement");
lf[7]=C_h_intern(&lf[7],7,"compose");
lf[8]=C_h_intern(&lf[8],6,"values");
lf[9]=C_h_intern(&lf[9],1,"o");
lf[10]=C_h_intern(&lf[10],8,"list-of\077");
lf[11]=C_h_intern(&lf[11],7,"list-of");
lf[12]=C_h_intern(&lf[12],4,"noop");
lf[13]=C_h_intern(&lf[13],19,"\003sysundefined-value");
lf[14]=C_h_intern(&lf[14],4,"each");
lf[15]=C_h_intern(&lf[15],4,"any\077");
lf[16]=C_h_intern(&lf[16],5,"none\077");
lf[17]=C_h_intern(&lf[17],7,"always\077");
lf[18]=C_h_intern(&lf[18],6,"never\077");
lf[19]=C_h_intern(&lf[19],12,"left-section");
lf[20]=C_h_intern(&lf[20],10,"\003sysappend");
lf[21]=C_h_intern(&lf[21],17,"\003syscheck-closure");
lf[22]=C_h_intern(&lf[22],7,"reverse");
lf[23]=C_h_intern(&lf[23],13,"right-section");
lf[24]=C_h_intern(&lf[24],5,"atom\077");
lf[25]=C_h_intern(&lf[25],5,"tail\077");
lf[26]=C_h_intern(&lf[26],11,"intersperse");
lf[27]=C_h_intern(&lf[27],7,"butlast");
lf[28]=C_h_intern(&lf[28],7,"flatten");
lf[29]=C_h_intern(&lf[29],4,"chop");
lf[30]=C_h_intern(&lf[30],9,"\003syserror");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid numeric argument");
lf[32]=C_h_intern(&lf[32],4,"join");
lf[33]=C_h_intern(&lf[33],27,"\003syserror-not-a-proper-list");
lf[34]=C_h_intern(&lf[34],8,"compress");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000%bad argument type - not a proper list");
lf[36]=C_h_intern(&lf[36],15,"\003syssignal-hook");
lf[37]=C_h_intern(&lf[37],11,"\000type-error");
lf[38]=C_h_intern(&lf[38],7,"shuffle");
lf[39]=C_h_intern(&lf[39],7,"\003sysmap");
lf[40]=C_h_intern(&lf[40],3,"cdr");
lf[41]=C_h_intern(&lf[41],5,"sort!");
lf[42]=C_h_intern(&lf[42],13,"alist-update!");
lf[43]=C_h_intern(&lf[43],4,"eqv\077");
lf[44]=C_h_intern(&lf[44],3,"eq\077");
lf[45]=C_h_intern(&lf[45],4,"assq");
lf[46]=C_h_intern(&lf[46],4,"assv");
lf[47]=C_h_intern(&lf[47],6,"equal\077");
lf[48]=C_h_intern(&lf[48],5,"assoc");
lf[49]=C_h_intern(&lf[49],9,"alist-ref");
lf[50]=C_h_intern(&lf[50],6,"rassoc");
lf[51]=C_h_intern(&lf[51],37,"\017data-structuresreverse-string-append");
lf[52]=C_h_intern(&lf[52],11,"make-string");
lf[53]=C_h_intern(&lf[53],18,"open-output-string");
lf[54]=C_h_intern(&lf[54],7,"display");
lf[55]=C_h_intern(&lf[55],6,"string");
lf[56]=C_h_intern(&lf[56],17,"get-output-string");
lf[57]=C_h_intern(&lf[57],8,"->string");
lf[58]=C_h_intern(&lf[58],14,"symbol->string");
lf[59]=C_h_intern(&lf[59],18,"\003sysnumber->string");
lf[60]=C_h_intern(&lf[60],13,"string-append");
lf[61]=C_h_intern(&lf[61],4,"conc");
lf[62]=C_h_intern(&lf[62],19,"\003syssubstring-index");
lf[63]=C_h_intern(&lf[63],15,"substring-index");
lf[64]=C_h_intern(&lf[64],22,"\003syssubstring-index-ci");
lf[65]=C_h_intern(&lf[65],18,"substring-index-ci");
lf[66]=C_h_intern(&lf[66],15,"string-compare3");
lf[67]=C_h_intern(&lf[67],18,"string-compare3-ci");
lf[68]=C_h_intern(&lf[68],15,"\003syssubstring=\077");
lf[69]=C_h_intern(&lf[69],11,"substring=\077");
lf[70]=C_h_intern(&lf[70],18,"\003syssubstring-ci=\077");
lf[71]=C_h_intern(&lf[71],14,"substring-ci=\077");
lf[72]=C_h_intern(&lf[72],12,"string-split");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\003\011\012 ");
lf[74]=C_h_intern(&lf[74],13,"\003syssubstring");
lf[75]=C_h_intern(&lf[75],18,"string-intersperse");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[78]=C_h_intern(&lf[78],19,"\003sysallocate-vector");
lf[79]=C_h_intern(&lf[79],12,"list->string");
lf[80]=C_h_intern(&lf[80],16,"string-translate");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid translation destination");
lf[82]=C_h_intern(&lf[82],17,"string-translate*");
lf[83]=C_h_intern(&lf[83],21,"\003sysfragments->string");
lf[84]=C_h_intern(&lf[84],11,"string-chop");
lf[85]=C_h_intern(&lf[85],12,"string-chomp");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[87]=C_h_intern(&lf[87],7,"sorted\077");
lf[88]=C_h_intern(&lf[88],5,"merge");
lf[89]=C_h_intern(&lf[89],6,"merge!");
lf[90]=C_h_intern(&lf[90],12,"vector->list");
lf[91]=C_h_intern(&lf[91],4,"sort");
lf[92]=C_h_intern(&lf[92],12,"list->vector");
lf[93]=C_h_intern(&lf[93],6,"append");
lf[94]=C_h_intern(&lf[94],13,"binary-search");
lf[95]=C_h_intern(&lf[95],10,"make-queue");
lf[96]=C_h_intern(&lf[96],5,"queue");
lf[97]=C_h_intern(&lf[97],6,"queue\077");
lf[98]=C_h_intern(&lf[98],12,"queue-empty\077");
lf[99]=C_h_intern(&lf[99],11,"queue-first");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[101]=C_h_intern(&lf[101],10,"queue-last");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[103]=C_h_intern(&lf[103],10,"queue-add!");
lf[104]=C_h_intern(&lf[104],13,"queue-remove!");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\016queue is empty");
lf[106]=C_h_intern(&lf[106],11,"queue->list");
lf[107]=C_h_intern(&lf[107],11,"list->queue");
lf[108]=C_h_intern(&lf[108],16,"queue-push-back!");
lf[109]=C_h_intern(&lf[109],21,"queue-push-back-list!");
lf[110]=C_h_intern(&lf[110],17,"register-feature!");
lf[111]=C_h_intern(&lf[111],15,"data-structures");
C_register_lf2(lf,112,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* data-structures.scm: 73   register-feature! */
t3=*((C_word*)lf[110]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[111]);}

/* k1622 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[146],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! identity ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1626,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[1]+1 /* (set! project ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1629,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[2]+1 /* (set! conjoin ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1637,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[3]+1 /* (set! disjoin ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1670,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[4]+1 /* (set! constantly ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1707,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[5]+1 /* (set! flip ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1730,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[6]+1 /* (set! complement ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1738,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[7]+1 /* (set! compose ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1750,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[9]+1 /* (set! o ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1786,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[10]+1 /* (set! list-of? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1825,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[11]+1 /* (set! list-of ...) */,*((C_word*)lf[10]+1));
t13=C_mutate((C_word*)lf[12]+1 /* (set! noop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1866,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[14]+1 /* (set! each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1872,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[15]+1 /* (set! any? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1928,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[16]+1 /* (set! none? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1931,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[17]+1 /* (set! always? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1934,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[18]+1 /* (set! never? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1937,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[19]+1 /* (set! left-section ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1940,tmp=(C_word)a,a+=2,tmp));
t20=*((C_word*)lf[22]+1);
t21=C_mutate((C_word*)lf[23]+1 /* (set! right-section ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[24]+1 /* (set! atom? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1981,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[25]+1 /* (set! tail? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1984,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[26]+1 /* (set! intersperse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2012,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[27]+1 /* (set! butlast ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2045,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[28]+1 /* (set! flatten ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2077,tmp=(C_word)a,a+=2,tmp));
t27=*((C_word*)lf[22]+1);
t28=C_mutate((C_word*)lf[29]+1 /* (set! chop ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2118,a[2]=t27,tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[32]+1 /* (set! join ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2203,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[34]+1 /* (set! compress ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2262,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[38]+1 /* (set! shuffle ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2342,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[42]+1 /* (set! alist-update! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2383,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[49]+1 /* (set! alist-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2469,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[50]+1 /* (set! rassoc ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2590,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[51]+1 /* (set! reverse-string-append ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2640,tmp=(C_word)a,a+=2,tmp));
t36=*((C_word*)lf[53]+1);
t37=*((C_word*)lf[54]+1);
t38=*((C_word*)lf[55]+1);
t39=*((C_word*)lf[56]+1);
t40=C_mutate((C_word*)lf[57]+1 /* (set! ->string ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2717,a[2]=t36,a[3]=t37,a[4]=t39,a[5]=t38,tmp=(C_word)a,a+=6,tmp));
t41=*((C_word*)lf[60]+1);
t42=C_mutate((C_word*)lf[61]+1 /* (set! conc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2762,a[2]=t41,tmp=(C_word)a,a+=3,tmp));
t43=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2772,tmp=(C_word)a,a+=2,tmp);
t44=C_mutate((C_word*)lf[62]+1 /* (set! substring-index ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=t43,tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[64]+1 /* (set! substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2828,a[2]=t43,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[63]+1 /* (set! substring-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2837,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[65]+1 /* (set! substring-index-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2858,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[66]+1 /* (set! string-compare3 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2879,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[67]+1 /* (set! string-compare3-ci ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2910,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[68]+1 /* (set! substring=? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[69]+1 /* (set! substring=? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2978,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[70]+1 /* (set! substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3055,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[71]+1 /* (set! substring-ci=? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3092,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[72]+1 /* (set! string-split ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3169,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[75]+1 /* (set! string-intersperse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3304,tmp=(C_word)a,a+=2,tmp));
t56=*((C_word*)lf[52]+1);
t57=*((C_word*)lf[79]+1);
t58=C_mutate((C_word*)lf[80]+1 /* (set! string-translate ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3412,a[2]=t57,a[3]=t56,tmp=(C_word)a,a+=4,tmp));
t59=C_mutate((C_word*)lf[82]+1 /* (set! string-translate* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3614,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[84]+1 /* (set! string-chop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3736,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[85]+1 /* (set! string-chomp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3800,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[87]+1 /* (set! sorted? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3845,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[88]+1 /* (set! merge ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3954,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[89]+1 /* (set! merge! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4053,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[41]+1 /* (set! sort! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4185,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[91]+1 /* (set! sort ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4318,tmp=(C_word)a,a+=2,tmp));
t67=*((C_word*)lf[92]+1);
t68=C_mutate((C_word*)lf[94]+1 /* (set! binary-search ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4345,a[2]=t67,tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[95]+1 /* (set! make-queue ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4428,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[97]+1 /* (set! queue? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4434,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[98]+1 /* (set! queue-empty? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4440,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[99]+1 /* (set! queue-first ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4453,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[101]+1 /* (set! queue-last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4474,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[103]+1 /* (set! queue-add! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4495,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[104]+1 /* (set! queue-remove! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4527,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[106]+1 /* (set! queue->list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4563,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[107]+1 /* (set! list->queue ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4572,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[108]+1 /* (set! queue-push-back! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4626,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[109]+1 /* (set! queue-push-back-list! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4655,tmp=(C_word)a,a+=2,tmp));
t80=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t80+1)))(2,t80,C_SCHEME_UNDEFINED);}

/* queue-push-back-list! in k1622 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4655,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[96],lf[109]);
t5=(C_word)C_i_check_list_2(t3,lf[109]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4665,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* data-structures.scm: 908  append */
t8=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t3,t7);}

/* k4663 in queue-push-back-list! in k1622 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_4668(t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4682,tmp=(C_word)a,a+=2,tmp);
t5=t2;
f_4668(t5,f_4682(t1));}}

/* doloop1534 in k4663 in queue-push-back-list! in k1622 */
static C_word C_fcall f_4682(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* k4666 in k4663 in queue-push-back-list! in k1622 */
static void C_fcall f_4668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),t1));}

/* queue-push-back! in k1622 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4626,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[96],lf[108]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_i_setslot(t2,C_fix(1),t6);
t8=(C_word)C_slot(t2,C_fix(2));
t9=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?(C_word)C_i_setslot(t2,C_fix(2),t6):C_SCHEME_UNDEFINED));}

/* list->queue in k1622 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4572,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[107]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4583,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_4583(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4591,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4591(t9,t4,t2);}}

/* doloop1493 in list->queue in k1622 */
static void C_fcall f_4591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4591,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4601,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* data-structures.scm: 884  ##sys#error-not-a-proper-list */
t8=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[2],lf[107]);}
else{
t8=t5;
f_4601(2,t8,C_SCHEME_UNDEFINED);}}}

/* k4599 in doloop1493 in list->queue in k1622 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4591(t3,((C_word*)t0)[2],t2);}

/* k4581 in list->queue in k1622 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4583,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[96],((C_word*)t0)[2],t1));}

/* queue->list in k1622 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4563,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[96],lf[106]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* queue-remove! in k1622 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4527,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[96],lf[104]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4537,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 862  ##sys#error */
t7=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[104],lf[105],t2);}
else{
t7=t5;
f_4537(2,t7,C_SCHEME_UNDEFINED);}}

/* k4535 in queue-remove! in k1622 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
t5=(C_truep(t4)?(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),C_SCHEME_END_OF_LIST):C_SCHEME_UNDEFINED);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(((C_word*)t0)[4],C_fix(0)));}

/* queue-add! in k1622 */
static void C_ccall f_4495(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4495,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[96],lf[103]);
t5=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=t1,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t7);
if(C_truep(t8)){
t9=t6;
f_4505(t9,(C_word)C_i_setslot(t2,C_fix(1),t5));}
else{
t9=(C_word)C_slot(t2,C_fix(2));
t10=t6;
f_4505(t10,(C_word)C_i_setslot(t9,C_fix(1),t5));}}

/* k4503 in queue-add! in k1622 */
static void C_fcall f_4505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* queue-last in k1622 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4474,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[96],lf[101]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4484,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 843  ##sys#error */
t7=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[101],lf[102],t2);}
else{
t7=t5;
f_4484(2,t7,C_SCHEME_UNDEFINED);}}

/* k4482 in queue-last in k1622 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-first in k1622 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4453,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[96],lf[99]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4463,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t6)){
/* data-structures.scm: 832  ##sys#error */
t7=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[99],lf[100],t2);}
else{
t7=t5;
f_4463(2,t7,C_SCHEME_UNDEFINED);}}

/* k4461 in queue-first in k1622 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* queue-empty? in k1622 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4440,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[96],lf[98]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4));}

/* queue? in k1622 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4434,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[96]));}

/* make-queue in k1622 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[96],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* binary-search in k1622 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4345,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4423,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 789  list->vector */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_4349(t6,(C_word)C_i_check_vector_2(((C_word*)t4)[1],lf[94]));}}

/* k4421 in binary-search in k1622 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4349(t3,t2);}

/* k4347 in binary-search in k1622 */
static void C_fcall f_4349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4349,NULL,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[4])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4363(t6,((C_word*)t0)[2],C_fix(0),t2);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* loop in k4347 in binary-search in k1622 */
static void C_fcall f_4363(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4363,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t3,t2);
t5=(C_word)C_fixnum_divide(t4,C_fix(2));
t6=(C_word)C_u_fixnum_plus(t2,t5);
t7=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4373,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 797  proc */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}

/* k4371 in loop in k4347 in binary-search in k1622 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 799  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4363(t4,((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[5]);}}
else{
t3=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* data-structures.scm: 800  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4363(t4,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}}}

/* sort in k1622 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4318,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4336,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 779  vector->list */
t6=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4343,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 780  append */
t5=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_SCHEME_END_OF_LIST);}}

/* k4341 in sort in k1622 */
static void C_ccall f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 780  sort! */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4334 in sort in k1622 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 779  sort! */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4330 in sort in k1622 */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 779  list->vector */
t2=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* sort! in k1622 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4185,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4188,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t8=(C_word)C_fix((C_word)C_header_size(((C_word*)t4)[1]));
t9=((C_word*)t4)[1];
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4275,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=t9,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 762  vector->list */
t11=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,((C_word*)t4)[1]);}
else{
t8=(C_word)C_i_length(((C_word*)t4)[1]);
/* data-structures.scm: 768  step */
t9=((C_word*)t6)[1];
f_4188(t9,t1,t8);}}

/* k4273 in sort! in k1622 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 763  step */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4188(t4,t3,((C_word*)t0)[2]);}

/* k4280 in k4273 in sort! in k1622 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4284(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* doloop1352 in k4280 in k4273 in sort! in k1622 */
static void C_fcall f_4284(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4284,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_setslot(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* step in sort! in k1622 */
static void C_fcall f_4188(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4188,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_quotient(4,0,t3,t2,C_fix(2));}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(2)))){
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_u_i_cadr(((C_word*)((C_word*)t0)[2])[1]);
t5=((C_word*)((C_word*)t0)[2])[1];
t6=(C_word)C_u_i_cddr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4229,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4239,a[2]=t3,a[3]=t8,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 747  less? */
t10=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t4,t3);}
else{
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=(C_word)C_i_set_i_slot(t3,C_fix(1),C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}}}

/* k4237 in step in sort! in k1622 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(0),((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)t0)[3];
f_4229(t4,(C_word)C_i_setslot(t3,C_fix(0),((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[3];
f_4229(t2,C_SCHEME_UNDEFINED);}}

/* k4227 in step in sort! in k1622 */
static void C_fcall f_4229(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_i_set_i_slot(t2,C_fix(1),C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}

/* k4196 in step in sort! in k1622 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 738  step */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4188(t3,t2,t1);}

/* k4199 in k4196 in step in sort! in k1622 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 740  step */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4188(t4,t3,t2);}

/* k4205 in k4199 in k4196 in step in sort! in k1622 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 741  merge! */
t2=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* merge! in k1622 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4053,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4056,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4135,a[2]=t6,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_u_i_car(t3);
t10=(C_word)C_u_i_car(t2);
/* data-structures.scm: 715  less? */
t11=t4;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,t9,t10);}}}

/* k4133 in merge! in k1622 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4138,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_4138(2,t4,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[3]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 718  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4056(t5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t4);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=t2;
f_4158(2,t4,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[4]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 723  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4056(t5,t2,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}}}

/* k4156 in k4133 in merge! in k1622 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4136 in k4133 in merge! in k1622 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in merge! in k1622 */
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4056,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_u_i_car(t3);
/* data-structures.scm: 700  less? */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k4061 in loop in merge! in k1622 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[3]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* data-structures.scm: 705  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4056(t5,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[3],t4);}}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_nullp(t3))){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[5]));}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 711  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4056(t5,((C_word*)t0)[4],((C_word*)t0)[3],t4,((C_word*)t0)[5]);}}}

/* merge in k1622 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3954,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3988,a[2]=t4,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_3988(t12,t1,t5,t6,t7,t8);}}}

/* loop in merge in k1622 */
static void C_fcall f_3988(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3988,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,a[5]=t3,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 683  less? */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,t2);}

/* k3993 in loop in merge in k1622 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
if(C_truep(t1)){
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[7]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[7]);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 686  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3988(t5,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3,t4);}}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[7]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* data-structures.scm: 690  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3988(t5,t2,t3,t4,((C_word*)t0)[3],((C_word*)t0)[7]);}}}

/* k4041 in k3993 in loop in merge in k1622 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4013 in k3993 in loop in merge in k1622 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* sorted? in k1622 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3845,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_fix((C_word)C_header_size(t2));
if(C_truep((C_word)C_i_less_or_equalp(t4,C_fix(1)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3872,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3872(t8,t1,C_fix(1));}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3920,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3920(t9,t1,t4,t5);}}}

/* loop in sorted? in k1622 */
static void C_fcall f_3920(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3920,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t3);
/* data-structures.scm: 666  less? */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* k3946 in loop in sorted? in k1622 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 667  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3920(t4,((C_word*)t0)[4],t2,t3);}}

/* doloop1236 in sorted? in k1622 */
static void C_fcall f_3872(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3872,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nequalp(t2,((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_3882(2,t5,t3);}
else{
t5=(C_word)C_slot(((C_word*)t0)[3],t2);
t6=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[3],t6);
/* data-structures.scm: 660  less? */
t8=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,t5,t7);}}

/* k3880 in doloop1236 in sorted? in k1622 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_nequalp(((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_3872(t3,((C_word*)t0)[5],t2);}}

/* string-chomp in k1622 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3800r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3800r(t0,t1,t2,t3);}}

static void C_ccall f_3800r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[86]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[85]);
t7=(C_word)C_i_check_string_2(t5,lf[85]);
t8=(C_word)C_block_size(t2);
t9=(C_word)C_block_size(t5);
t10=(C_word)C_u_fixnum_difference(t8,t9);
t11=(C_word)C_fixnum_greater_or_equal_p(t8,t9);
t12=(C_truep(t11)?(C_word)C_substring_compare(t2,t5,t10,C_fix(0),t9):C_SCHEME_FALSE);
if(C_truep(t12)){
/* data-structures.scm: 627  ##sys#substring */
t13=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t1,t2,C_fix(0),t10);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t2);}}

/* string-chop in k1622 */
static void C_ccall f_3736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3736,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[84]);
t5=(C_word)C_i_check_exact_2(t3,lf[84]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3751,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_3751(t10,t1,t6,C_fix(0));}

/* loop in string-chop in k1622 */
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3751,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3771,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_u_fixnum_plus(t3,t2);
/* data-structures.scm: 613  ##sys#substring */
t6=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
/* data-structures.scm: 614  ##sys#substring */
t6=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[3],t3,t5);}}}

/* k3780 in loop in string-chop in k1622 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3786,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],((C_word*)t0)[4]);
/* data-structures.scm: 614  loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3751(t5,t2,t3,t4);}

/* k3784 in k3780 in loop in string-chop in k1622 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3769 in loop in string-chop in k1622 */
static void C_ccall f_3771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3771,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* string-translate* in k1622 */
static void C_ccall f_3614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3614,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[82]);
t5=(C_word)C_i_check_list_2(t3,lf[82]);
t6=(C_word)C_block_size(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3626,a[2]=t3,a[3]=t8,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
/* data-structures.scm: 602  collect */
t10=((C_word*)t8)[1];
f_3626(t10,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-translate* in k1622 */
static void C_fcall f_3626(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3626,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3640,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3644,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3654,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 584  ##sys#substring */
t10=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[4],t3,t2);}
else{
t9=t8;
f_3644(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3659,a[2]=t8,a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t4,a[8]=t2,tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_3659(t10,t1,((C_word*)t0)[2]);}}

/* loop in collect in string-translate* in k1622 */
static void C_fcall f_3659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3659,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 588  collect */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3626(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_substring_compare(((C_word*)t0)[3],t4,((C_word*)t0)[8],C_fix(0),t5))){
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t5);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3698,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[8],((C_word*)t0)[5]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3724,a[2]=t8,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 596  ##sys#substring */
t10=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[8]);}
else{
t9=t8;
f_3698(t9,C_SCHEME_UNDEFINED);}}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* data-structures.scm: 601  loop */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k3722 in loop in collect in string-translate* in k1622 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3698(t4,t3);}

/* k3696 in loop in collect in string-translate* in k1622 */
static void C_fcall f_3698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3698,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* data-structures.scm: 597  collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3626(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k3652 in collect in string-translate* in k1622 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3644(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k3642 in collect in string-translate* in k1622 */
static void C_fcall f_3644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 582  reverse */
t2=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3638 in collect in string-translate* in k1622 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 580  ##sys#fragments->string */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-translate in k1622 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3412r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3412r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3412r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3415,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_charp(t3))){
t7=t6;
f_3449(2,t7,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3589,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(t3))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 538  list->string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(C_word)C_i_check_string_2(t3,lf[80]);
/* data-structures.scm: 541  instring */
f_3415(t6,t3);}}}

/* k3604 in string-translate in k1622 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 538  instring */
f_3415(((C_word*)t0)[2],t1);}

/* f_3589 in string-translate in k1622 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3589,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* k3447 in string-translate in k1622 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_charp(t3))){
t4=t2;
f_3452(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t3))){
/* data-structures.scm: 546  list->string */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t4=(C_word)C_i_check_string_2(t3,lf[80]);
t5=t2;
f_3452(2,t5,t3);}}}
else{
t3=t2;
f_3452(2,t3,C_SCHEME_FALSE);}}

/* k3450 in k3447 in string-translate in k1622 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=(C_word)C_i_stringp(t1);
t3=(C_truep(t2)?(C_word)C_block_size(t1):C_SCHEME_FALSE);
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[80]);
t5=(C_word)C_block_size(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* data-structures.scm: 553  make-string */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k3462 in k3450 in k3447 in string-translate in k1622 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3469(t5,((C_word*)t0)[2],C_fix(0),C_fix(0));}

/* loop in k3462 in k3450 in k3447 in string-translate in k1622 */
static void C_fcall f_3469(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3469,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* data-structures.scm: 557  ##sys#substring */
t4=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[7],C_fix(0),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[6],t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3488,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* data-structures.scm: 560  from */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k3486 in loop in k3462 in k3450 in k3447 in string-translate in k1622 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
t2=t1;
if(C_truep(t2)){
t3=((C_word*)t0)[9];
if(C_truep(t3)){
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 567  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3469(t7,((C_word*)t0)[4],t5,t6);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
/* data-structures.scm: 569  ##sys#error */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[80],lf[81],((C_word*)t0)[6],((C_word*)t0)[9]);}
else{
t4=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],(C_word)C_subchar(((C_word*)t0)[9],t1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 572  loop */
t7=((C_word*)((C_word*)t0)[5])[1];
f_3469(t7,((C_word*)t0)[4],t5,t6);}}}
else{
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* data-structures.scm: 564  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3469(t5,((C_word*)t0)[4],t4,((C_word*)t0)[7]);}}
else{
t3=(C_word)C_setsubchar(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[2]);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* data-structures.scm: 563  loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3469(t6,((C_word*)t0)[4],t4,t5);}}

/* instring in string-translate in k1622 */
static void C_fcall f_3415(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3415,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3420,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_3420 in instring in string-translate in k1622 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3426(t3,C_fix(0)));}

/* loop */
static C_word C_fcall f_3426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t1);}
else{
t3=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* string-intersperse in k1622 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3304r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3304r(t0,t1,t2,t3);}}

static void C_ccall f_3304r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[76]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_list_2(t2,lf[75]);
t7=(C_word)C_i_check_string_2(t5,lf[75]);
t8=(C_word)C_block_size(t5);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3322,a[2]=t10,a[3]=t8,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3322(t12,t1,t2,C_fix(0));}

/* loop1 in string-intersperse in k1622 */
static void C_fcall f_3322(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3322,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
if(C_truep((C_word)C_eqp(((C_word*)t0)[5],C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[77]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3332,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[3]);
/* data-structures.scm: 501  ##sys#allocate-vector */
t6=*((C_word*)lf[78]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,t5,C_SCHEME_TRUE,C_make_character(32),C_SCHEME_FALSE);}}
else{
t4=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_i_check_string_2(t5,lf[75]);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_block_size(t5);
t9=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t3);
t10=(C_word)C_u_fixnum_plus(t8,t9);
/* data-structures.scm: 516  loop1 */
t14=t1;
t15=t7;
t16=t10;
t1=t14;
t2=t15;
t3=t16;
goto loop;}
else{
/* data-structures.scm: 518  ##sys#error-not-a-proper-list */
t5=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[5]);}}}

/* k3330 in loop1 in string-intersperse in k1622 */
static void C_ccall f_3332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3337,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_3337(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop2 in k3330 in loop1 in string-intersperse in k1622 */
static C_word C_fcall f_3337(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
loop:
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_block_size(t3);
t6=(C_word)C_substring_copy(t3,((C_word*)t0)[4],C_fix(0),t5,t2);
t7=(C_word)C_u_fixnum_plus(t2,t5);
if(C_truep((C_word)C_eqp(t4,C_SCHEME_END_OF_LIST))){
return(((C_word*)t0)[4]);}
else{
t8=(C_word)C_substring_copy(((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],t7);
t9=(C_word)C_u_fixnum_plus(t7,((C_word*)t0)[2]);
t11=t4;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* string-split in k1622 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3169r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3169r(t0,t1,t2,t3);}}

static void C_ccall f_3169r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(18);
t4=(C_word)C_i_check_string_2(t2,lf[72]);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?lf[73]:(C_word)C_slot(t3,C_fix(0)));
t7=(C_word)C_block_size(t3);
t8=(C_word)C_eqp(t7,C_fix(2));
t9=(C_truep(t8)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_string_2(t6,lf[72]);
t12=(C_word)C_block_size(t6);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3190,a[2]=t2,a[3]=t14,tmp=(C_word)a,a+=4,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3210,a[2]=t6,a[3]=t17,a[4]=t12,a[5]=t2,a[6]=t15,a[7]=t9,a[8]=t14,a[9]=t10,tmp=(C_word)a,a+=10,tmp));
t19=((C_word*)t17)[1];
f_3210(t19,t1,C_fix(0),C_SCHEME_FALSE,C_fix(0));}

/* loop in string-split in k1622 */
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3210,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3220,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_greaterp(t2,t4);
t7=(C_truep(t6)?t6:((C_word*)t0)[7]);
if(C_truep(t7)){
/* data-structures.scm: 477  add */
t8=((C_word*)t0)[6];
f_3190(t8,t5,t4,t2,t3);}
else{
t8=t5;
f_3220(2,t8,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_subchar(((C_word*)t0)[5],t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3237,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[3],a[10]=t2,a[11]=((C_word*)t0)[4],tmp=(C_word)a,a+=12,tmp));
t9=((C_word*)t7)[1];
f_3237(t9,t1,C_fix(0));}}

/* scan in loop in string-split in k1622 */
static void C_fcall f_3237(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3237,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
/* data-structures.scm: 482  loop */
t4=((C_word*)((C_word*)t0)[9])[1];
f_3210(t4,t1,t3,((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t5=(C_word)C_fixnum_greaterp(((C_word*)t0)[10],((C_word*)t0)[7]);
t6=(C_truep(t5)?t5:((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3276,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 486  add */
t8=((C_word*)t0)[3];
f_3190(t8,t7,((C_word*)t0)[7],((C_word*)t0)[10],((C_word*)t0)[8]);}
else{
/* data-structures.scm: 487  loop */
t7=((C_word*)((C_word*)t0)[9])[1];
f_3210(t7,t1,t4,((C_word*)t0)[8],t4);}}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* data-structures.scm: 488  scan */
t11=t1;
t12=t4;
t1=t11;
t2=t12;
goto loop;}}}

/* k3274 in scan in loop in string-split in k1622 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 486  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3210(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,((C_word*)t0)[2]);}

/* k3218 in loop in string-split in k1622 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:C_SCHEME_END_OF_LIST));}

/* add in string-split in k1622 */
static void C_fcall f_3190(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3190,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3205,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 470  ##sys#substring */
t6=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t2,t3);}

/* k3203 in add in string-split in k1622 */
static void C_ccall f_3205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3205,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3197,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_3197(t4,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=t3;
f_3197(t5,t4);}}

/* k3195 in k3203 in add in string-split in k1622 */
static void C_fcall f_3197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* substring-ci=? in k1622 */
static void C_ccall f_3092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3092r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3092r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3092r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3094,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3099,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3104,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3109,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1853876 */
t9=t8;
f_3109(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2854872 */
t11=t7;
f_3104(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len855867 */
t13=t6;
f_3099(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body851861 */
t15=t5;
f_3094(t15,t1,t9,t11,t13);}}}}

/* def-start1853 in substring-ci=? in k1622 */
static void C_fcall f_3109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3109,NULL,2,t0,t1);}
/* def-start2854872 */
t2=((C_word*)t0)[2];
f_3104(t2,t1,C_fix(0));}

/* def-start2854 in substring-ci=? in k1622 */
static void C_fcall f_3104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3104,NULL,3,t0,t1,t2);}
/* def-len855867 */
t3=((C_word*)t0)[2];
f_3099(t3,t1,t2,C_fix(0));}

/* def-len855 in substring-ci=? in k1622 */
static void C_fcall f_3099(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3099,NULL,4,t0,t1,t2,t3);}
/* body851861 */
t4=((C_word*)t0)[2];
f_3094(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body851 in substring-ci=? in k1622 */
static void C_fcall f_3094(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3094,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 455  ##sys#substring-ci=? */
t5=*((C_word*)lf[70]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring-ci=? in k1622 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_3055,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[71]);
t8=(C_word)C_i_check_string_2(t3,lf[71]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3065,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_3065(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_u_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_u_fixnum_difference(t12,t5);
t14=t9;
f_3065(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k3063 in ##sys#substring-ci=? in k1622 */
static void C_fcall f_3065(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[71]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[71]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* substring=? in k1622 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_2978r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2978r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2978r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2980,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2990,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2995,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-start1775798 */
t9=t8;
f_2995(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start2776794 */
t11=t7;
f_2990(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-len777789 */
t13=t6;
f_2985(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body773783 */
t15=t5;
f_2980(t15,t1,t9,t11,t13);}}}}

/* def-start1775 in substring=? in k1622 */
static void C_fcall f_2995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2995,NULL,2,t0,t1);}
/* def-start2776794 */
t2=((C_word*)t0)[2];
f_2990(t2,t1,C_fix(0));}

/* def-start2776 in substring=? in k1622 */
static void C_fcall f_2990(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2990,NULL,3,t0,t1,t2);}
/* def-len777789 */
t3=((C_word*)t0)[2];
f_2985(t3,t1,t2,C_fix(0));}

/* def-len777 in substring=? in k1622 */
static void C_fcall f_2985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2985,NULL,4,t0,t1,t2,t3);}
/* body773783 */
t4=((C_word*)t0)[2];
f_2980(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body773 in substring=? in k1622 */
static void C_fcall f_2980(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2980,NULL,5,t0,t1,t2,t3,t4);}
/* data-structures.scm: 441  ##sys#substring=? */
t5=*((C_word*)lf[68]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}

/* ##sys#substring=? in k1622 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_2941,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,lf[69]);
t8=(C_word)C_i_check_string_2(t3,lf[69]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2951,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t10=t9;
f_2951(t10,t6);}
else{
t10=(C_word)C_block_size(t2);
t11=(C_word)C_u_fixnum_difference(t10,t4);
t12=(C_word)C_block_size(t3);
t13=(C_word)C_u_fixnum_difference(t12,t5);
t14=t9;
f_2951(t14,(C_word)C_i_fixnum_min(t11,t13));}}

/* k2949 in ##sys#substring=? in k1622 */
static void C_fcall f_2951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[69]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[69]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[5],t1));}

/* string-compare3-ci in k1622 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2910,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[67]);
t5=(C_word)C_i_check_string_2(t3,lf[67]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_u_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_string_compare_case_insensitive(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* string-compare3 in k1622 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2879,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[66]);
t5=(C_word)C_i_check_string_2(t3,lf[66]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_block_size(t3);
t8=(C_word)C_u_fixnum_difference(t6,t7);
t9=(C_word)C_fixnum_lessp(t8,C_fix(0));
t10=(C_truep(t9)?t6:t7);
t11=(C_word)C_mem_compare(t2,t3,t10);
t12=(C_word)C_eqp(t11,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_truep(t12)?t8:t11));}

/* substring-index-ci in k1622 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2858r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2858r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2858r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
/* data-structures.scm: 400  ##sys#substring-index-ci */
t7=*((C_word*)lf[64]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t3,t6);}

/* substring-index in k1622 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2837r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2837r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2837r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
/* data-structures.scm: 397  ##sys#substring-index */
t7=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t3,t6);}

/* ##sys#substring-index-ci in k1622 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2828,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2834,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 391  traverse */
f_2772(t1,t2,t3,t4,t5,lf[65]);}

/* a2833 in ##sys#substring-index-ci in k1622 */
static void C_ccall f_2834(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2834,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare_case_insensitive(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* ##sys#substring-index in k1622 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2819,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 385  traverse */
f_2772(t1,t2,t3,t4,t5,lf[63]);}

/* a2824 in ##sys#substring-index in k1622 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2825,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_substring_compare(((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2,t3));}

/* traverse in k1622 */
static void C_fcall f_2772(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2772,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t2,t6);
t8=(C_word)C_i_check_string_2(t3,t6);
t9=(C_word)C_block_size(t3);
t10=(C_word)C_block_size(t2);
t11=(C_word)C_i_check_exact_2(t4,t6);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2793,a[2]=t10,a[3]=t5,a[4]=t13,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_2793(t15,t1,t4,t10);}

/* loop in traverse in k1622 */
static void C_fcall f_2793(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2793,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t3,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 379  test */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,((C_word*)t0)[2]);}}

/* k2804 in loop in traverse in k1622 */
static void C_ccall f_2806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 381  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2793(t4,((C_word*)t0)[5],t2,t3);}}

/* conc in k1622 */
static void C_ccall f_2762(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2762r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2762r(t0,t1,t2);}}

static void C_ccall f_2762r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2770,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[57]+1),t2);}

/* k2768 in conc in k1622 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ->string in k1622 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2717,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* data-structures.scm: 354  symbol->string */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
/* data-structures.scm: 355  string */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* data-structures.scm: 356  ##sys#number->string */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2754,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 358  open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}}}

/* k2752 in ->string in k1622 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2757,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 359  display */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2755 in k2752 in ->string in k1622 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 360  get-output-string */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##data-structures#reverse-string-append in k1622 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2640,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
/* data-structures.scm: 343  rev-string-append */
t6=((C_word*)t4)[1];
f_2643(t6,t1,t2,C_fix(0));}

/* rev-string-append in ##data-structures#reverse-string-append in k1622 */
static void C_fcall f_2643(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2643,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_fix((C_word)C_header_size(t4));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2659,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_a_i_plus(&a,2,t3,t5);
/* data-structures.scm: 334  rev-string-append */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}
else{
/* data-structures.scm: 341  make-string */
t4=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k2657 in rev-string-append in ##data-structures#reverse-string-append in k1622 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(t1));
t3=(C_word)C_a_i_minus(&a,2,t2,((C_word*)t0)[5]);
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2668,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2668(t8,((C_word*)t0)[2],C_fix(0),t4);}

/* loop in k2657 in rev-string-append in ##data-structures#reverse-string-append in k1622 */
static void C_fcall f_2668(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2668,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_lessp(t2,((C_word*)t0)[5]))){
t4=(C_word)C_subchar(((C_word*)t0)[4],t2);
t5=(C_word)C_setsubchar(((C_word*)t0)[3],t3,t4);
t6=(C_word)C_a_i_plus(&a,2,t2,C_fix(1));
t7=(C_word)C_a_i_plus(&a,2,t3,C_fix(1));
/* data-structures.scm: 339  loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* rassoc in k1622 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2590r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2590r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2590r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t5=(C_word)C_i_check_list_2(t3,lf[50]);
t6=(C_word)C_notvemptyp(t4);
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):*((C_word*)lf[43]+1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2602,a[2]=t2,a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2602(t11,t1,t3);}

/* loop in rassoc in k1622 */
static void C_fcall f_2602(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2602,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_i_check_pair_2(t3,lf[50]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 320  tst */
t7=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)t0)[2],t6);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2619 in loop in rassoc in k1622 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 322  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2602(t3,((C_word*)t0)[5],t2);}}

/* alist-ref in k1622 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2469r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2469r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2469r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2471,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2545,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-cmp479523 */
t8=t7;
f_2545(t8,t1);}
else{
t8=(C_word)C_u_i_car(t4);
t9=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-default480519 */
t10=t6;
f_2540(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
/* body477486 */
t12=t5;
f_2471(t12,t1,t8,t10);}}}

/* def-cmp479 in alist-ref in k1622 */
static void C_fcall f_2545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2545,NULL,2,t0,t1);}
/* def-default480519 */
t2=((C_word*)t0)[2];
f_2540(t2,t1,*((C_word*)lf[43]+1));}

/* def-default480 in alist-ref in k1622 */
static void C_fcall f_2540(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2540,NULL,3,t0,t1,t2);}
/* body477486 */
t3=((C_word*)t0)[2];
f_2471(t3,t1,t2,C_SCHEME_FALSE);}

/* body477 in alist-ref in k1622 */
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2471,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(*((C_word*)lf[44]+1),t2);
if(C_truep(t5)){
t6=t4;
f_2475(t6,*((C_word*)lf[45]+1));}
else{
t6=(C_word)C_eqp(*((C_word*)lf[43]+1),t2);
if(C_truep(t6)){
t7=t4;
f_2475(t7,*((C_word*)lf[46]+1));}
else{
t7=(C_word)C_eqp(*((C_word*)lf[47]+1),t2);
t8=t4;
f_2475(t8,(C_truep(t7)?*((C_word*)lf[48]+1):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2500,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}}

/* f_2500 in body477 in alist-ref in k1622 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2500,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2506,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2506(t7,t1,t3);}

/* loop */
static void C_fcall f_2506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2506,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2522,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 305  cmp */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2522(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2520 in loop */
static void C_ccall f_2522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 307  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2506(t3,((C_word*)t0)[5],t2);}}

/* k2473 in body477 in alist-ref in k1622 */
static void C_fcall f_2475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2475,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2478,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 308  aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2476 in k2473 in body477 in alist-ref in k1622 */
static void C_ccall f_2478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):((C_word*)t0)[2]));}

/* alist-update! in k1622 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5rv,(void*)f_2383r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_2383r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2383r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):*((C_word*)lf[43]+1));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2390,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_eqp(*((C_word*)lf[44]+1),t7);
if(C_truep(t9)){
t10=t8;
f_2390(t10,*((C_word*)lf[45]+1));}
else{
t10=(C_word)C_eqp(*((C_word*)lf[43]+1),t7);
if(C_truep(t10)){
t11=t8;
f_2390(t11,*((C_word*)lf[46]+1));}
else{
t11=(C_word)C_eqp(*((C_word*)lf[47]+1),t7);
t12=t8;
f_2390(t12,(C_truep(t11)?*((C_word*)lf[48]+1):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=t7,tmp=(C_word)a,a+=3,tmp)));}}}

/* f_2422 in alist-update! in k1622 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2422,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2428,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2428(t7,t1,t3);}

/* loop */
static void C_fcall f_2428(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2428,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
/* data-structures.scm: 286  cmp */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t5=t4;
f_2444(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2442 in loop */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 288  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2428(t3,((C_word*)t0)[5],t2);}}

/* k2388 in alist-update! in k1622 */
static void C_fcall f_2390(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2390,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 289  aq */
t3=t1;
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2391 in k2388 in alist-update! in k1622 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* shuffle in k1622 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2342,4,t0,t1,t2,t3);}
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2353,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2373,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* map */
t8=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}

/* a2372 in shuffle in k1622 */
static void C_ccall f_2373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2373,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2381,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 270  random */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2379 in a2372 in shuffle in k1622 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k2355 in shuffle in k1622 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2359,tmp=(C_word)a,a+=2,tmp);
/* data-structures.scm: 270  sort! */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2358 in k2355 in shuffle in k1622 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2359,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_lessp(t4,t5));}

/* k2351 in shuffle in k1622 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[40]+1),t1);}

/* compress in k1622 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2262,4,t0,t1,t2,t3);}
t4=lf[35];
t5=(C_word)C_i_check_list_2(t3,lf[34]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2271,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2271(t9,t1,t2,t3);}

/* loop in compress in k1622 */
static void C_fcall f_2271(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2271,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
if(C_truep((C_word)C_slot(t2,C_fix(0)))){
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2313,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 262  loop */
t11=t5;
t12=t6;
t13=t7;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(1));
/* data-structures.scm: 263  loop */
t11=t1;
t12=t4;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
/* data-structures.scm: 261  ##sys#signal-hook */
t4=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[37],lf[34],((C_word*)t0)[2],t3);}}
else{
/* data-structures.scm: 259  ##sys#signal-hook */
t4=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[37],lf[34],((C_word*)t0)[2],t2);}}}

/* k2311 in loop in compress in k1622 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* join in k1622 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2203r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2203r(t0,t1,t2,t3);}}

static void C_ccall f_2203r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=(C_word)C_i_check_list_2(t5,lf[32]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2215,a[2]=t8,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_2215(t10,t1,t2);}

/* loop in join in k1622 */
static void C_fcall f_2215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2215,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 250  loop */
t7=t5;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}
else{
/* data-structures.scm: 244  ##sys#error-not-a-proper-list */
t3=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}}}

/* k2248 in loop in join in k1622 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 250  ##sys#append */
t2=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop in k1622 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2118,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[29]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2125,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,C_fix(0)))){
/* data-structures.scm: 225  ##sys#error */
t6=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[29],lf[31],t3);}
else{
t6=t5;
f_2125(2,t6,C_SCHEME_UNDEFINED);}}

/* k2123 in chop in k1622 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2133(t6,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* loop in k2123 in chop in k1622 */
static void C_fcall f_2133(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2133,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,1,t2));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2154,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2154(t7,t1,C_SCHEME_END_OF_LIST,t2,((C_word*)t0)[4]);}}}

/* doloop333 in loop in k2123 in chop in k1622 */
static void C_fcall f_2154(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2154,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2168,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* data-structures.scm: 236  reverse */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_slot(t3,C_fix(1));
t9=(C_word)C_u_fixnum_difference(t4,C_fix(1));
t12=t1;
t13=t7;
t14=t8;
t15=t9;
t1=t12;
t2=t13;
t3=t14;
t4=t15;
goto loop;}}

/* k2166 in doloop333 in loop in k2123 in chop in k1622 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2172,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* data-structures.scm: 236  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2133(t4,t2,((C_word*)t0)[2],t3);}

/* k2170 in k2166 in doloop333 in loop in k2123 in chop in k1622 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2172,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* flatten in k1622 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2077r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2077r(t0,t1,t2);}}

static void C_ccall f_2077r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2083,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2083(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in flatten in k1622 */
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2083,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_listp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2109,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 217  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2116,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 218  loop */
t9=t6;
t10=t5;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k2114 in loop in flatten in k1622 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2107 in loop in flatten in k1622 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 217  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2083(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* butlast in k1622 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2045,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[27]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2054(t7,t1,t2);}

/* loop in butlast in k1622 */
static void C_fcall f_2054(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2054,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2075,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 207  loop */
t8=t6;
t9=t3;
t1=t8;
t2=t9;
goto loop;}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}}

/* k2073 in loop in butlast in k1622 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* intersperse in k1622 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2012,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_2018(t7,t1,t2);}

/* loop in intersperse in k1622 */
static void C_fcall f_2018(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2018,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_eqp(t3,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2043,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 200  loop */
t7=t5;
t8=t3;
t1=t7;
t2=t8;
goto loop;}}}

/* k2041 in loop in intersperse in k1622 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* tail? in k1622 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1984,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_list_2(t3,lf[25]);
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,f_1996(t6,t3));}}

/* loop in tail? in k1622 */
static C_word C_fcall f_1996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_eqp(t1,C_SCHEME_END_OF_LIST))){
return(C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_eqp(((C_word*)t0)[2],t1))){
return(C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(t1,C_fix(1));
t4=t2;
t1=t4;
goto loop;}}}

/* atom? in k1622 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1981,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* right-section in k1622 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1955r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1955r(t0,t1,t2,t3);}}

static void C_ccall f_1955r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1959,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* data-structures.scm: 174  ##sys#check-closure */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[23]);}

/* k1957 in right-section in k1622 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 175  ##sys#reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1960 in k1957 in right-section in k1622 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1963,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_1963 in k1960 in k1957 in right-section in k1622 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_1963r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1963r(t0,t1,t2);}}

static void C_ccall f_1963r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1975,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 177  ##sys#reverse */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1977 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 177  ##sys#append */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1973 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 177  ##sys#reverse */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1969 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* left-section in k1622 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1940r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1940r(t0,t1,t2,t3);}}

static void C_ccall f_1940r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1944,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 167  ##sys#check-closure */
t5=*((C_word*)lf[21]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[19]);}

/* k1942 in left-section in k1622 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));}

/* f_1945 in k1942 in left-section in k1622 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1945r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1945r(t0,t1,t2);}}

static void C_ccall f_1945r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1953,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 169  ##sys#append */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k1951 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* never? in k1622 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* always? in k1622 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* none? in k1622 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1931,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* any? in k1622 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1928,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* each in k1622 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1872r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1872r(t0,t1,t2);}}

static void C_ccall f_1872r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1880,tmp=(C_word)a,a+=2,tmp));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_slot(t2,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_1894 in each in k1622 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_1894r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1894r(t0,t1,t2);}}

static void C_ccall f_1894r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1900(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1900(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1900,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t4))){
C_apply(4,0,t1,t3,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1919,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,t3,((C_word*)t0)[3]);}}

/* k1917 in loop */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 156  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1900(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_1880 in each in k1622 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[13]+1));}

/* noop in k1622 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[13]+1));}

/* list-of? in k1622 */
static void C_ccall f_1825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1825,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1827 in list-of? in k1622 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1827,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1833(t6,t1,t2);}

/* loop */
static void C_fcall f_1833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1833,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_not_pair_p(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1852,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* data-structures.scm: 137  pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}}

/* k1850 in loop */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 137  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1833(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* o in k1622 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1786r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1786r(t0,t1,t2);}}

static void C_ccall f_1786r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[0]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1798(t6,t1,t2);}}

/* loop in o in k1622 */
static void C_fcall f_1798(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1798,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1812,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp)));}

/* f_1812 in loop in o in k1622 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1812,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1820,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1823,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* data-structures.scm: 130  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1798(t5,t4,((C_word*)t0)[2]);}

/* k1821 */
static void C_ccall f_1823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1818 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* data-structures.scm: 130  h */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* compose in k1622 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1750r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1750r(t0,t1,t2);}}

static void C_ccall f_1750r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1753,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
if(C_truep((C_word)C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,*((C_word*)lf[8]+1));}
else{
C_apply(4,0,t1,((C_word*)t4)[1],t2);}}

/* rec in compose in k1622 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1753r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1753r(t0,t1,t2,t3);}}

static void C_ccall f_1753r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(C_word)C_i_nullp(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t2:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1761,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp)));}

/* f_1761 in rec in compose in k1622 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1761r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1761r(t0,t1,t2);}}

static void C_ccall f_1761r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* data-structures.scm: 115  call-with-values */
C_u_call_with_values(4,0,t1,t3,((C_word*)t0)[2]);}

/* a1766 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k1773 in a1766 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* complement in k1622 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1738,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1740 in complement in k1622 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1740r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1740r(t0,t1,t2);}}

static void C_ccall f_1740r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1748,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(4,0,t3,((C_word*)t0)[2],t2);}

/* k1746 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* flip in k1622 */
static void C_ccall f_1730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1730,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1732 in flip in k1622 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1732,4,t0,t1,t2,t3);}
/* data-structures.scm: 104  proc */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* constantly in k1622 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1707r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1707r(t0,t1,t2);}}

static void C_ccall f_1707r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_u_i_car(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1720,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}}

/* f_1720 in constantly in k1622 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* f_1718 in constantly in k1622 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* disjoin in k1622 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1670r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1670r(t0,t1,t2);}}

static void C_ccall f_1670r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(3);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1672,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1672 in disjoin in k1622 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1672,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1678,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1678(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1678,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,((C_word*)t0)[2]);}}

/* k1686 in loop */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* data-structures.scm: 96   loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1678(t3,((C_word*)t0)[4],t2);}}

/* conjoin in k1622 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1637r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1637r(t0,t1,t2);}}

static void C_ccall f_1637r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a=C_alloc(3);
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1639,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1639 in conjoin in k1622 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1639,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1645,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1645(t6,t1,((C_word*)t0)[2]);}

/* loop */
static void C_fcall f_1645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1645,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1658,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k1656 in loop */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* data-structures.scm: 89   loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1645(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* project in k1622 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1629,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1631 in project in k1622 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1631r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1631r(t0,t1,t2);}}

static void C_ccall f_1631r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,((C_word*)t0)[2]));}

/* identity in k1622 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1626,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[233] = {
{"toplevel:data_structures_scm",(void*)C_data_structures_toplevel},
{"f_1624:data_structures_scm",(void*)f_1624},
{"f_4655:data_structures_scm",(void*)f_4655},
{"f_4665:data_structures_scm",(void*)f_4665},
{"f_4682:data_structures_scm",(void*)f_4682},
{"f_4668:data_structures_scm",(void*)f_4668},
{"f_4626:data_structures_scm",(void*)f_4626},
{"f_4572:data_structures_scm",(void*)f_4572},
{"f_4591:data_structures_scm",(void*)f_4591},
{"f_4601:data_structures_scm",(void*)f_4601},
{"f_4583:data_structures_scm",(void*)f_4583},
{"f_4563:data_structures_scm",(void*)f_4563},
{"f_4527:data_structures_scm",(void*)f_4527},
{"f_4537:data_structures_scm",(void*)f_4537},
{"f_4495:data_structures_scm",(void*)f_4495},
{"f_4505:data_structures_scm",(void*)f_4505},
{"f_4474:data_structures_scm",(void*)f_4474},
{"f_4484:data_structures_scm",(void*)f_4484},
{"f_4453:data_structures_scm",(void*)f_4453},
{"f_4463:data_structures_scm",(void*)f_4463},
{"f_4440:data_structures_scm",(void*)f_4440},
{"f_4434:data_structures_scm",(void*)f_4434},
{"f_4428:data_structures_scm",(void*)f_4428},
{"f_4345:data_structures_scm",(void*)f_4345},
{"f_4423:data_structures_scm",(void*)f_4423},
{"f_4349:data_structures_scm",(void*)f_4349},
{"f_4363:data_structures_scm",(void*)f_4363},
{"f_4373:data_structures_scm",(void*)f_4373},
{"f_4318:data_structures_scm",(void*)f_4318},
{"f_4343:data_structures_scm",(void*)f_4343},
{"f_4336:data_structures_scm",(void*)f_4336},
{"f_4332:data_structures_scm",(void*)f_4332},
{"f_4185:data_structures_scm",(void*)f_4185},
{"f_4275:data_structures_scm",(void*)f_4275},
{"f_4282:data_structures_scm",(void*)f_4282},
{"f_4284:data_structures_scm",(void*)f_4284},
{"f_4188:data_structures_scm",(void*)f_4188},
{"f_4239:data_structures_scm",(void*)f_4239},
{"f_4229:data_structures_scm",(void*)f_4229},
{"f_4198:data_structures_scm",(void*)f_4198},
{"f_4201:data_structures_scm",(void*)f_4201},
{"f_4207:data_structures_scm",(void*)f_4207},
{"f_4053:data_structures_scm",(void*)f_4053},
{"f_4135:data_structures_scm",(void*)f_4135},
{"f_4158:data_structures_scm",(void*)f_4158},
{"f_4138:data_structures_scm",(void*)f_4138},
{"f_4056:data_structures_scm",(void*)f_4056},
{"f_4063:data_structures_scm",(void*)f_4063},
{"f_3954:data_structures_scm",(void*)f_3954},
{"f_3988:data_structures_scm",(void*)f_3988},
{"f_3995:data_structures_scm",(void*)f_3995},
{"f_4043:data_structures_scm",(void*)f_4043},
{"f_4015:data_structures_scm",(void*)f_4015},
{"f_3845:data_structures_scm",(void*)f_3845},
{"f_3920:data_structures_scm",(void*)f_3920},
{"f_3948:data_structures_scm",(void*)f_3948},
{"f_3872:data_structures_scm",(void*)f_3872},
{"f_3882:data_structures_scm",(void*)f_3882},
{"f_3800:data_structures_scm",(void*)f_3800},
{"f_3736:data_structures_scm",(void*)f_3736},
{"f_3751:data_structures_scm",(void*)f_3751},
{"f_3782:data_structures_scm",(void*)f_3782},
{"f_3786:data_structures_scm",(void*)f_3786},
{"f_3771:data_structures_scm",(void*)f_3771},
{"f_3614:data_structures_scm",(void*)f_3614},
{"f_3626:data_structures_scm",(void*)f_3626},
{"f_3659:data_structures_scm",(void*)f_3659},
{"f_3724:data_structures_scm",(void*)f_3724},
{"f_3698:data_structures_scm",(void*)f_3698},
{"f_3654:data_structures_scm",(void*)f_3654},
{"f_3644:data_structures_scm",(void*)f_3644},
{"f_3640:data_structures_scm",(void*)f_3640},
{"f_3412:data_structures_scm",(void*)f_3412},
{"f_3606:data_structures_scm",(void*)f_3606},
{"f_3589:data_structures_scm",(void*)f_3589},
{"f_3449:data_structures_scm",(void*)f_3449},
{"f_3452:data_structures_scm",(void*)f_3452},
{"f_3464:data_structures_scm",(void*)f_3464},
{"f_3469:data_structures_scm",(void*)f_3469},
{"f_3488:data_structures_scm",(void*)f_3488},
{"f_3415:data_structures_scm",(void*)f_3415},
{"f_3420:data_structures_scm",(void*)f_3420},
{"f_3426:data_structures_scm",(void*)f_3426},
{"f_3304:data_structures_scm",(void*)f_3304},
{"f_3322:data_structures_scm",(void*)f_3322},
{"f_3332:data_structures_scm",(void*)f_3332},
{"f_3337:data_structures_scm",(void*)f_3337},
{"f_3169:data_structures_scm",(void*)f_3169},
{"f_3210:data_structures_scm",(void*)f_3210},
{"f_3237:data_structures_scm",(void*)f_3237},
{"f_3276:data_structures_scm",(void*)f_3276},
{"f_3220:data_structures_scm",(void*)f_3220},
{"f_3190:data_structures_scm",(void*)f_3190},
{"f_3205:data_structures_scm",(void*)f_3205},
{"f_3197:data_structures_scm",(void*)f_3197},
{"f_3092:data_structures_scm",(void*)f_3092},
{"f_3109:data_structures_scm",(void*)f_3109},
{"f_3104:data_structures_scm",(void*)f_3104},
{"f_3099:data_structures_scm",(void*)f_3099},
{"f_3094:data_structures_scm",(void*)f_3094},
{"f_3055:data_structures_scm",(void*)f_3055},
{"f_3065:data_structures_scm",(void*)f_3065},
{"f_2978:data_structures_scm",(void*)f_2978},
{"f_2995:data_structures_scm",(void*)f_2995},
{"f_2990:data_structures_scm",(void*)f_2990},
{"f_2985:data_structures_scm",(void*)f_2985},
{"f_2980:data_structures_scm",(void*)f_2980},
{"f_2941:data_structures_scm",(void*)f_2941},
{"f_2951:data_structures_scm",(void*)f_2951},
{"f_2910:data_structures_scm",(void*)f_2910},
{"f_2879:data_structures_scm",(void*)f_2879},
{"f_2858:data_structures_scm",(void*)f_2858},
{"f_2837:data_structures_scm",(void*)f_2837},
{"f_2828:data_structures_scm",(void*)f_2828},
{"f_2834:data_structures_scm",(void*)f_2834},
{"f_2819:data_structures_scm",(void*)f_2819},
{"f_2825:data_structures_scm",(void*)f_2825},
{"f_2772:data_structures_scm",(void*)f_2772},
{"f_2793:data_structures_scm",(void*)f_2793},
{"f_2806:data_structures_scm",(void*)f_2806},
{"f_2762:data_structures_scm",(void*)f_2762},
{"f_2770:data_structures_scm",(void*)f_2770},
{"f_2717:data_structures_scm",(void*)f_2717},
{"f_2754:data_structures_scm",(void*)f_2754},
{"f_2757:data_structures_scm",(void*)f_2757},
{"f_2640:data_structures_scm",(void*)f_2640},
{"f_2643:data_structures_scm",(void*)f_2643},
{"f_2659:data_structures_scm",(void*)f_2659},
{"f_2668:data_structures_scm",(void*)f_2668},
{"f_2590:data_structures_scm",(void*)f_2590},
{"f_2602:data_structures_scm",(void*)f_2602},
{"f_2621:data_structures_scm",(void*)f_2621},
{"f_2469:data_structures_scm",(void*)f_2469},
{"f_2545:data_structures_scm",(void*)f_2545},
{"f_2540:data_structures_scm",(void*)f_2540},
{"f_2471:data_structures_scm",(void*)f_2471},
{"f_2500:data_structures_scm",(void*)f_2500},
{"f_2506:data_structures_scm",(void*)f_2506},
{"f_2522:data_structures_scm",(void*)f_2522},
{"f_2475:data_structures_scm",(void*)f_2475},
{"f_2478:data_structures_scm",(void*)f_2478},
{"f_2383:data_structures_scm",(void*)f_2383},
{"f_2422:data_structures_scm",(void*)f_2422},
{"f_2428:data_structures_scm",(void*)f_2428},
{"f_2444:data_structures_scm",(void*)f_2444},
{"f_2390:data_structures_scm",(void*)f_2390},
{"f_2393:data_structures_scm",(void*)f_2393},
{"f_2342:data_structures_scm",(void*)f_2342},
{"f_2373:data_structures_scm",(void*)f_2373},
{"f_2381:data_structures_scm",(void*)f_2381},
{"f_2357:data_structures_scm",(void*)f_2357},
{"f_2359:data_structures_scm",(void*)f_2359},
{"f_2353:data_structures_scm",(void*)f_2353},
{"f_2262:data_structures_scm",(void*)f_2262},
{"f_2271:data_structures_scm",(void*)f_2271},
{"f_2313:data_structures_scm",(void*)f_2313},
{"f_2203:data_structures_scm",(void*)f_2203},
{"f_2215:data_structures_scm",(void*)f_2215},
{"f_2250:data_structures_scm",(void*)f_2250},
{"f_2118:data_structures_scm",(void*)f_2118},
{"f_2125:data_structures_scm",(void*)f_2125},
{"f_2133:data_structures_scm",(void*)f_2133},
{"f_2154:data_structures_scm",(void*)f_2154},
{"f_2168:data_structures_scm",(void*)f_2168},
{"f_2172:data_structures_scm",(void*)f_2172},
{"f_2077:data_structures_scm",(void*)f_2077},
{"f_2083:data_structures_scm",(void*)f_2083},
{"f_2116:data_structures_scm",(void*)f_2116},
{"f_2109:data_structures_scm",(void*)f_2109},
{"f_2045:data_structures_scm",(void*)f_2045},
{"f_2054:data_structures_scm",(void*)f_2054},
{"f_2075:data_structures_scm",(void*)f_2075},
{"f_2012:data_structures_scm",(void*)f_2012},
{"f_2018:data_structures_scm",(void*)f_2018},
{"f_2043:data_structures_scm",(void*)f_2043},
{"f_1984:data_structures_scm",(void*)f_1984},
{"f_1996:data_structures_scm",(void*)f_1996},
{"f_1981:data_structures_scm",(void*)f_1981},
{"f_1955:data_structures_scm",(void*)f_1955},
{"f_1959:data_structures_scm",(void*)f_1959},
{"f_1962:data_structures_scm",(void*)f_1962},
{"f_1963:data_structures_scm",(void*)f_1963},
{"f_1979:data_structures_scm",(void*)f_1979},
{"f_1975:data_structures_scm",(void*)f_1975},
{"f_1971:data_structures_scm",(void*)f_1971},
{"f_1940:data_structures_scm",(void*)f_1940},
{"f_1944:data_structures_scm",(void*)f_1944},
{"f_1945:data_structures_scm",(void*)f_1945},
{"f_1953:data_structures_scm",(void*)f_1953},
{"f_1937:data_structures_scm",(void*)f_1937},
{"f_1934:data_structures_scm",(void*)f_1934},
{"f_1931:data_structures_scm",(void*)f_1931},
{"f_1928:data_structures_scm",(void*)f_1928},
{"f_1872:data_structures_scm",(void*)f_1872},
{"f_1894:data_structures_scm",(void*)f_1894},
{"f_1900:data_structures_scm",(void*)f_1900},
{"f_1919:data_structures_scm",(void*)f_1919},
{"f_1880:data_structures_scm",(void*)f_1880},
{"f_1866:data_structures_scm",(void*)f_1866},
{"f_1825:data_structures_scm",(void*)f_1825},
{"f_1827:data_structures_scm",(void*)f_1827},
{"f_1833:data_structures_scm",(void*)f_1833},
{"f_1852:data_structures_scm",(void*)f_1852},
{"f_1786:data_structures_scm",(void*)f_1786},
{"f_1798:data_structures_scm",(void*)f_1798},
{"f_1812:data_structures_scm",(void*)f_1812},
{"f_1823:data_structures_scm",(void*)f_1823},
{"f_1820:data_structures_scm",(void*)f_1820},
{"f_1750:data_structures_scm",(void*)f_1750},
{"f_1753:data_structures_scm",(void*)f_1753},
{"f_1761:data_structures_scm",(void*)f_1761},
{"f_1767:data_structures_scm",(void*)f_1767},
{"f_1775:data_structures_scm",(void*)f_1775},
{"f_1738:data_structures_scm",(void*)f_1738},
{"f_1740:data_structures_scm",(void*)f_1740},
{"f_1748:data_structures_scm",(void*)f_1748},
{"f_1730:data_structures_scm",(void*)f_1730},
{"f_1732:data_structures_scm",(void*)f_1732},
{"f_1707:data_structures_scm",(void*)f_1707},
{"f_1720:data_structures_scm",(void*)f_1720},
{"f_1718:data_structures_scm",(void*)f_1718},
{"f_1670:data_structures_scm",(void*)f_1670},
{"f_1672:data_structures_scm",(void*)f_1672},
{"f_1678:data_structures_scm",(void*)f_1678},
{"f_1688:data_structures_scm",(void*)f_1688},
{"f_1637:data_structures_scm",(void*)f_1637},
{"f_1639:data_structures_scm",(void*)f_1639},
{"f_1645:data_structures_scm",(void*)f_1645},
{"f_1658:data_structures_scm",(void*)f_1658},
{"f_1629:data_structures_scm",(void*)f_1629},
{"f_1631:data_structures_scm",(void*)f_1631},
{"f_1626:data_structures_scm",(void*)f_1626},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
