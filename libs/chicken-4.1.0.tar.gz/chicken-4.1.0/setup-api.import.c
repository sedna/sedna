/* Generated from ./setup-api.import.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:40
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: ./setup-api.import.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature chicken-compile-shared -dynamic -ignore-repository -output-file setup-api.import.c
   used units: library eval data_structures ports extras srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[31];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,20),40,102,111,114,109,45,101,114,114,111,114,32,115,49,51,32,112,49,52,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,13),40,97,51,53,50,32,108,105,110,101,53,55,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,13),40,97,52,50,57,32,108,105,110,101,51,51,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,18),40,97,50,56,56,32,102,111,114,109,52,32,114,53,32,99,54,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,39),40,97,50,53,52,32,105,110,112,117,116,55,54,56,57,32,114,101,110,97,109,101,56,53,57,48,32,99,111,109,112,97,114,101,55,51,57,49,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,13),40,97,50,51,55,32,101,120,112,49,52,49,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,45),40,97,50,48,50,32,105,110,112,117,116,49,49,49,49,50,52,32,114,101,110,97,109,101,49,50,48,49,50,53,32,99,111,109,112,97,114,101,49,48,56,49,50,54,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_156)
static void C_ccall f_156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_159)
static void C_ccall f_159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_162)
static void C_ccall f_162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_165)
static void C_ccall f_165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_168)
static void C_ccall f_168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_171)
static void C_ccall f_171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_174)
static void C_ccall f_174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_203)
static void C_ccall f_203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_213)
static void C_ccall f_213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_220)
static void C_ccall f_220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_232)
static void C_ccall f_232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_238)
static void C_ccall f_238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_246)
static void C_ccall f_246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_236)
static void C_ccall f_236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_255)
static void C_ccall f_255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_265)
static void C_ccall f_265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_272)
static void C_ccall f_272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_284)
static void C_ccall f_284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_289)
static void C_ccall f_289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_293)
static void C_ccall f_293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_299)
static void C_ccall f_299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_302)
static void C_ccall f_302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_437)
static void C_fcall f_437(C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_310)
static void C_ccall f_310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_317)
static void C_ccall f_317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_384)
static void C_fcall f_384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_351)
static void C_ccall f_351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_329)
static void C_ccall f_329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_303)
static void C_fcall f_303(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_177)
static void C_ccall f_177(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_437)
static void C_fcall trf_437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_437(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_437(t0,t1);}

C_noret_decl(trf_384)
static void C_fcall trf_384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_384(t0,t1);}

C_noret_decl(trf_303)
static void C_fcall trf_303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_303(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_303(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1475)){
C_save(t1);
C_rereclaim2(1475*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,31);
lf[0]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007execute\376\001\000\000\021setup-api#execute");
lf[1]=C_h_intern(&lf[1],5,"error");
lf[2]=C_h_intern(&lf[2],4,"list");
lf[3]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[4]=C_h_intern(&lf[4],10,"\003sysappend");
lf[5]=C_h_intern(&lf[5],7,"\003sysmap");
lf[6]=C_h_intern(&lf[6],9,"make/proc");
lf[7]=C_h_intern(&lf[7],15,"make:line-error");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\047second part of clause is not a sequence");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000%clause does not have at least 2 parts");
lf[10]=C_h_intern(&lf[10],5,"every");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\023empty specification");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000&illegal specification (not a sequence)");
lf[13]=C_h_intern(&lf[13],6,"lambda");
lf[14]=C_h_intern(&lf[14],16,"\003syscheck-syntax");
lf[15]=C_h_intern(&lf[15],4,"make");
lf[16]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[17]=C_h_intern(&lf[17],3,"csc");
lf[18]=C_h_intern(&lf[18],3,"run");
lf[19]=C_h_intern(&lf[19],21,"\003syssyntax-error-hook");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\024no rule matches form");
lf[21]=C_h_intern(&lf[21],9,"\003syslist\077");
lf[22]=C_h_intern(&lf[22],7,"compile");
lf[23]=C_h_intern(&lf[23],10,"quasiquote");
lf[24]=C_h_intern(&lf[24],9,"\003sysmap-n");
lf[25]=C_h_intern(&lf[25],7,"execute");
lf[26]=C_h_intern(&lf[26],28,"\003sysregister-compiled-module");
lf[27]=C_h_intern(&lf[27],9,"setup-api");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011move-file\376\001\000\000\023setup-api#move-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011make/proc\376\001\000\000\023set"
"up-api#make/proc\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016host-extension\376\001\000\000\030setup-api#host-extension\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\021install-extension\376\001\000\000\033setup-api#install-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017install"
"-program\376\001\000\000\031setup-api#install-program\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016install-script\376\001\000\000\030setup-ap"
"i#install-script\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-verbose-mode\376\001\000\000\034setup-api#setup-verbose-mo"
"de\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-install-mode\376\001\000\000\034setup-api#setup-install-mode\376\003\000\000\002\376\003\000\000\002\376\001"
"\000\000\022setup-verbose-flag\376\001\000\000\034setup-api#setup-verbose-flag\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-insta"
"ll-flag\376\001\000\000\034setup-api#setup-install-flag\376\003\000\000\002\376\003\000\000\002\376\001\000\000\023installation-prefix\376\001\000\000\035s"
"etup-api#installation-prefix\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016chicken-prefix\376\001\000\000\030setup-api#chicken-"
"prefix\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014find-library\376\001\000\000\026setup-api#find-library\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013find-"
"header\376\001\000\000\025setup-api#find-header\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014program-path\376\001\000\000\026setup-api#progra"
"m-path\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014remove-file*\376\001\000\000\026setup-api#remove-file*\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005patch"
"\376\001\000\000\017setup-api#patch\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012yes-or-no\077\376\001\000\000\024setup-api#yes-or-no\077\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\013abort-setup\376\001\000\000\025setup-api#abort-setup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024setup-root-directory\376\001\000"
"\000\036setup-api#setup-root-directory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\030create-directory/parents\376\001\000\000\042setu"
"p-api#create-directory/parents\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014test-compile\376\001\000\000\026setup-api#test-com"
"pile\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013try-compile\376\001\000\000\025setup-api#try-compile\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011copy-file"
"\376\001\000\000\023setup-api#copy-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013run-verbose\376\001\000\000\025setup-api#run-verbose\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\030required-chicken-version\376\001\000\000\042setup-api#required-chicken-version\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\032required-extension-version\376\001\000\000$setup-api#required-extension-version\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\015cross-chicken\376\001\000\000\027setup-api#cross-chicken\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014sudo-install\376"
"\001\000\000\026setup-api#sudo-install\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022keep-intermediates\376\001\000\000\034setup-api#keep-i"
"ntermediates\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012version>=\077\376\001\000\000\024setup-api#version>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032ext"
"ension-name-and-version\376\001\000\000$setup-api#extension-name-and-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016e"
"xtension-name\376\001\000\000\030setup-api#extension-name\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021extension-version\376\001\000\000\033s"
"etup-api#extension-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032create-temporary-directory\376\001\000\000$setup-ap"
"i#create-temporary-directory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020remove-directory\376\001\000\000\032setup-api#remove"
"-directory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020remove-extension\376\001\000\000\032setup-api#remove-extension\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\011read-info\376\001\000\000\023setup-api#read-info\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011shellpath\376\001\000\000\023setup-api#s"
"hellpath\376\377\016");
lf[29]=C_h_intern(&lf[29],4,"eval");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006import\376\003\000\000\002\376\001\000\000\006scheme\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\007foreign\376\003\000\000\002\376\001\000\000\005rege"
"x\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005ports\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\017data-str"
"uctures\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\005files\376\377\016");
C_register_lf2(lf,31,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_156,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k154 */
static void C_ccall f_156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_159,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k157 in k154 */
static void C_ccall f_159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k160 in k157 in k154 */
static void C_ccall f_162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_165,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k163 in k160 in k157 in k154 */
static void C_ccall f_165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_168,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_171,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_174,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ./setup-api.import.scm: 1    eval */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t2,lf[30]);}

/* k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_177,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[0]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_289,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[15],t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_255,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,lf[22],t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_203,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_a_i_cons(&a,2,lf[18],t8);
t10=(C_word)C_a_i_list(&a,3,t5,t7,t9);
/* ./setup-api.import.scm: 14   ##sys#register-compiled-module */
((C_proc7)C_retrieve_symbol_proc(lf[26]))(7,*((C_word*)lf[26]+1),t2,lf[27],t3,lf[28],t10,C_SCHEME_END_OF_LIST);}

/* a202 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_203(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_203,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_213,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#list? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t6,t5);}

/* k211 in a202 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_213,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* rename120125 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[25]);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),((C_word*)t0)[5],lf[20],((C_word*)t0)[2]);}}

/* k218 in k211 in a202 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* rename120125 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[2]);}

/* k230 in k218 in k211 in a202 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_236,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_238,a[2]=((C_word*)t0)[3],a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
/* ##sys#map-n */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t2,t3,((C_word*)t0)[2]);}

/* a237 in k230 in k218 in k211 in a202 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_238,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_246,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* rename120125 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[23]);}

/* k244 in a237 in k230 in k218 in k211 in a202 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_246,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k234 in k230 in k218 in k211 in a202 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_236,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a254 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_255(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_255,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_265,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* ##sys#list? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t6,t5);}

/* k263 in a254 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_265,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* rename8590 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[18]);}
else{
/* ##sys#syntax-error-hook */
((C_proc4)C_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),((C_word*)t0)[4],lf[20],((C_word*)t0)[2]);}}

/* k270 in k263 in a254 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_284,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* rename8590 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[17]);}

/* k282 in k270 in k263 in a254 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_284,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_289,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_293,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ./setup-api.import.scm: 58   ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[14]))(5,*((C_word*)lf[14]+1),t5,lf[15],t2,lf[16]);}

/* k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_293,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ./setup-api.import.scm: 60   r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[2]);}

/* k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_302,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ./setup-api.import.scm: 61   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[13]);}

/* k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_303,a[2]=((C_word*)t0)[6],a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_listp(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_416,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_416(2,t6,t4);}
else{
/* ./setup-api.import.scm: 64   form-error */
t6=t2;
f_303(t6,t5,lf[12],C_SCHEME_END_OF_LIST);}}

/* k414 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_425,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_425(2,t4,t2);}
else{
/* ./setup-api.import.scm: 66   form-error */
t4=((C_word*)t0)[3];
f_303(t4,t3,lf[11],C_SCHEME_END_OF_LIST);}}
else{
t2=((C_word*)t0)[2];
f_310(2,t2,C_SCHEME_FALSE);}}

/* k423 in k414 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_430,a[2]=((C_word*)t0)[4],a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp);
/* ./setup-api.import.scm: 67   every */
((C_proc4)C_retrieve_symbol_proc(lf[10]))(4,*((C_word*)lf[10]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_310(2,t2,C_SCHEME_FALSE);}}

/* a429 in k423 in k414 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_430,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_437,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_437(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_437(t4,C_SCHEME_FALSE);}}

/* k435 in a429 in k423 in k414 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_fcall f_437(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_437,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_440(2,t3,t1);}
else{
/* ./setup-api.import.scm: 69   form-error */
t3=((C_word*)t0)[2];
f_303(t3,t2,lf[9],(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}}

/* k438 in k435 in a429 in k423 in k414 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* ./setup-api.import.scm: 74   make:line-error */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[8],t5,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ./setup-api.import.scm: 79   r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[6]);}

/* k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_351,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a352 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_353,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_406,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_cadr(t2);
/* ##sys#append */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k404 in a352 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_384,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_384(t6,C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_402,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,C_SCHEME_END_OF_LIST);}}

/* k400 in k404 in a352 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_402,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_384(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}

/* k382 in k404 in a352 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_fcall f_384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k375 in k404 in a352 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k349 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k345 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_347,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?lf[3]:(C_word)C_i_cddr(((C_word*)t0)[2]));
/* ##sys#append */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_SCHEME_END_OF_LIST);}

/* k327 in k345 in k315 in k308 in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_329,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* form-error in k300 in k297 in k291 in a288 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_fcall f_303(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_303,NULL,4,t0,t1,t2,t3);}
C_apply(6,0,t1,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],t3);}

/* k175 in k172 in k169 in k166 in k163 in k160 in k157 in k154 */
static void C_ccall f_177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[41] = {
{"toplevel:__setup_api_import_scm",(void*)C_toplevel},
{"f_156:__setup_api_import_scm",(void*)f_156},
{"f_159:__setup_api_import_scm",(void*)f_159},
{"f_162:__setup_api_import_scm",(void*)f_162},
{"f_165:__setup_api_import_scm",(void*)f_165},
{"f_168:__setup_api_import_scm",(void*)f_168},
{"f_171:__setup_api_import_scm",(void*)f_171},
{"f_174:__setup_api_import_scm",(void*)f_174},
{"f_203:__setup_api_import_scm",(void*)f_203},
{"f_213:__setup_api_import_scm",(void*)f_213},
{"f_220:__setup_api_import_scm",(void*)f_220},
{"f_232:__setup_api_import_scm",(void*)f_232},
{"f_238:__setup_api_import_scm",(void*)f_238},
{"f_246:__setup_api_import_scm",(void*)f_246},
{"f_236:__setup_api_import_scm",(void*)f_236},
{"f_255:__setup_api_import_scm",(void*)f_255},
{"f_265:__setup_api_import_scm",(void*)f_265},
{"f_272:__setup_api_import_scm",(void*)f_272},
{"f_284:__setup_api_import_scm",(void*)f_284},
{"f_289:__setup_api_import_scm",(void*)f_289},
{"f_293:__setup_api_import_scm",(void*)f_293},
{"f_299:__setup_api_import_scm",(void*)f_299},
{"f_302:__setup_api_import_scm",(void*)f_302},
{"f_416:__setup_api_import_scm",(void*)f_416},
{"f_425:__setup_api_import_scm",(void*)f_425},
{"f_430:__setup_api_import_scm",(void*)f_430},
{"f_437:__setup_api_import_scm",(void*)f_437},
{"f_440:__setup_api_import_scm",(void*)f_440},
{"f_310:__setup_api_import_scm",(void*)f_310},
{"f_317:__setup_api_import_scm",(void*)f_317},
{"f_353:__setup_api_import_scm",(void*)f_353},
{"f_406:__setup_api_import_scm",(void*)f_406},
{"f_402:__setup_api_import_scm",(void*)f_402},
{"f_384:__setup_api_import_scm",(void*)f_384},
{"f_377:__setup_api_import_scm",(void*)f_377},
{"f_351:__setup_api_import_scm",(void*)f_351},
{"f_347:__setup_api_import_scm",(void*)f_347},
{"f_329:__setup_api_import_scm",(void*)f_329},
{"f_303:__setup_api_import_scm",(void*)f_303},
{"f_177:__setup_api_import_scm",(void*)f_177},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
