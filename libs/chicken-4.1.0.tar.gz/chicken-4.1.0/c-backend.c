/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:39
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: c-backend.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[840];
static double C_possibly_force_alignment;


/* from getsize */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2378(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2378(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2373(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2373(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8862)
static void C_ccall f_8862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9136)
static void C_ccall f_9136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9124)
static void C_ccall f_9124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9094)
static void C_ccall f_9094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9055)
static void C_ccall f_9055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9042)
static void C_ccall f_9042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8924)
static void C_ccall f_8924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8871)
static C_word C_fcall f_8871(C_word *a,C_word t0);
C_noret_decl(f_8464)
static void C_ccall f_8464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8551)
static void C_fcall f_8551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8632)
static void C_ccall f_8632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_fcall f_8654(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8466)
static void C_fcall f_8466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7979)
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8009)
static void C_fcall f_8009(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8036)
static void C_fcall f_8036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_fcall f_8231(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8240)
static void C_fcall f_8240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8249)
static void C_ccall f_8249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8271)
static void C_fcall f_8271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8348)
static void C_ccall f_8348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7981)
static void C_fcall f_7981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7211)
static void C_fcall f_7211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7313)
static void C_fcall f_7313(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7346)
static void C_fcall f_7346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7442)
static void C_fcall f_7442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_fcall f_7454(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7469)
static void C_ccall f_7469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7509)
static void C_fcall f_7509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7526)
static void C_fcall f_7526(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7543)
static void C_fcall f_7543(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7582)
static void C_fcall f_7582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7599)
static void C_fcall f_7599(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_fcall f_7616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_fcall f_7633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7650)
static void C_fcall f_7650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_fcall f_7667(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7684)
static void C_fcall f_7684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7713)
static void C_ccall f_7713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7707)
static void C_ccall f_7707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7674)
static void C_ccall f_7674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7657)
static void C_ccall f_7657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7640)
static void C_ccall f_7640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7623)
static void C_ccall f_7623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7606)
static void C_ccall f_7606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7554)
static void C_ccall f_7554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7564)
static void C_ccall f_7564(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7562)
static void C_ccall f_7562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7558)
static void C_ccall f_7558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7550)
static void C_ccall f_7550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7141)
static void C_fcall f_7141(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7136)
static void C_fcall f_7136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7073)
static void C_ccall f_7073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7088)
static void C_ccall f_7088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7132)
static void C_ccall f_7132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7103)
static void C_ccall f_7103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7007)
static void C_ccall f_7007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7019)
static void C_ccall f_7019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_ccall f_7052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7060)
static void C_ccall f_7060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7050)
static void C_ccall f_7050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7025)
static void C_ccall f_7025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7028)
static void C_ccall f_7028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6675)
static void C_fcall f_6675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_fcall f_6684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6696)
static void C_fcall f_6696(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6708)
static void C_fcall f_6708(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6748)
static void C_fcall f_6748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6411)
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6415)
static void C_ccall f_6415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6418)
static void C_ccall f_6418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_ccall f_6439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6442)
static void C_ccall f_6442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6445)
static void C_ccall f_6445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6466)
static void C_ccall f_6466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6472)
static void C_ccall f_6472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_ccall f_6603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6573)
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6589)
static void C_ccall f_6589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6551)
static void C_ccall f_6551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6496)
static void C_ccall f_6496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6387)
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6393)
static void C_ccall f_6393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6397)
static void C_ccall f_6397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6400)
static void C_ccall f_6400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6385)
static void C_ccall f_6385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6339)
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6345)
static void C_ccall f_6345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6353)
static void C_ccall f_6353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6337)
static void C_ccall f_6337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6234)
static void C_ccall f_6234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6243)
static void C_fcall f_6243(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6272)
static void C_fcall f_6272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_fcall f_6275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_fcall f_6259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6161)
static void C_ccall f_6161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6175)
static void C_fcall f_6175(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6191)
static void C_ccall f_6191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6194)
static void C_ccall f_6194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6164)
static void C_ccall f_6164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6167)
static void C_ccall f_6167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6128)
static void C_ccall f_6128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_ccall f_6131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6137)
static void C_ccall f_6137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6149)
static void C_ccall f_6149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_ccall f_6152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_fcall f_5377(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5396)
static void C_ccall f_5396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5399)
static void C_ccall f_5399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6121)
static void C_ccall f_6121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_fcall f_5405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5420)
static void C_ccall f_5420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6051)
static void C_ccall f_6051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6054)
static void C_ccall f_6054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6076)
static void C_ccall f_6076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_fcall f_6023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6026)
static void C_ccall f_6026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5459)
static void C_ccall f_5459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5462)
static void C_ccall f_5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_fcall f_5471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5985)
static void C_fcall f_5985(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5995)
static void C_ccall f_5995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5477)
static void C_ccall f_5477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5928)
static void C_fcall f_5928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5940)
static void C_ccall f_5940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_fcall f_5949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5850)
static void C_ccall f_5850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_fcall f_5892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_fcall f_5859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5868)
static void C_fcall f_5868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5813)
static void C_fcall f_5813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5801)
static void C_ccall f_5801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5706)
static void C_ccall f_5706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_fcall f_5503(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5592)
static void C_ccall f_5592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_ccall f_5588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_fcall f_5563(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5068)
static void C_ccall f_5068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_fcall f_5115(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5093)
static void C_ccall f_5093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_ccall f_5025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_fcall f_4944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_fcall f_4950(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_fcall f_5146(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_fcall f_5153(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_fcall f_5242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_fcall f_4981(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5288)
static void C_fcall f_5288(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_fcall f_5303(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5319)
static void C_fcall f_5319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5365)
static void C_fcall f_5365(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_fcall f_4658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_fcall f_4844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_fcall f_4847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_fcall f_4893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4803)
static void C_ccall f_4803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static void C_ccall f_4794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_fcall f_4697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4733)
static void C_ccall f_4733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4661)
static void C_fcall f_4661(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_fcall f_4674(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_fcall f_4407(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4411)
static void C_ccall f_4411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_fcall f_4445(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4634)
static void C_ccall f_4634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_fcall f_4466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4627)
static void C_ccall f_4627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4562)
static void C_ccall f_4562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4587)
static void C_ccall f_4587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_fcall f_4531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4522)
static void C_ccall f_4522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_fcall f_4258(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4279)
static void C_fcall f_4279(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4348)
static void C_fcall f_4348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_fcall f_4321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4331)
static void C_ccall f_4331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_fcall f_4111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_fcall f_4114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_fcall f_2538(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4079)
static void C_fcall f_4079(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_fcall f_2541(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_fcall f_3980(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_ccall f_4012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3944)
static void C_ccall f_3944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_ccall f_3747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3610)
static void C_ccall f_3610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_fcall f_3218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_fcall f_3224(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2526)
static void C_ccall f_2526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3357)
static void C_fcall f_3357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_fcall f_3462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3270)
static void C_ccall f_3270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3273)
static void C_ccall f_3273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3182)
static void C_ccall f_3182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3143)
static void C_ccall f_3143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3095)
static void C_ccall f_3095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3112)
static void C_ccall f_3112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2967)
static void C_ccall f_2967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_ccall f_2928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2856)
static void C_ccall f_2856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2859)
static void C_ccall f_2859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_ccall f_2823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_fcall f_2528(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2458)
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8551)
static void C_fcall trf_8551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8551(t0,t1);}

C_noret_decl(trf_8654)
static void C_fcall trf_8654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8654(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8654(t0,t1);}

C_noret_decl(trf_8466)
static void C_fcall trf_8466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8466(t0,t1);}

C_noret_decl(trf_8009)
static void C_fcall trf_8009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8009(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8009(t0,t1);}

C_noret_decl(trf_8036)
static void C_fcall trf_8036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8036(t0,t1);}

C_noret_decl(trf_8231)
static void C_fcall trf_8231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8231(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8231(t0,t1);}

C_noret_decl(trf_8240)
static void C_fcall trf_8240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8240(t0,t1);}

C_noret_decl(trf_8271)
static void C_fcall trf_8271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8271(t0,t1);}

C_noret_decl(trf_7981)
static void C_fcall trf_7981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7981(t0,t1);}

C_noret_decl(trf_7211)
static void C_fcall trf_7211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7211(t0,t1);}

C_noret_decl(trf_7313)
static void C_fcall trf_7313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7313(t0,t1);}

C_noret_decl(trf_7346)
static void C_fcall trf_7346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7346(t0,t1);}

C_noret_decl(trf_7442)
static void C_fcall trf_7442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7442(t0,t1);}

C_noret_decl(trf_7454)
static void C_fcall trf_7454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7454(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7454(t0,t1);}

C_noret_decl(trf_7509)
static void C_fcall trf_7509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7509(t0,t1);}

C_noret_decl(trf_7526)
static void C_fcall trf_7526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7526(t0,t1);}

C_noret_decl(trf_7543)
static void C_fcall trf_7543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7543(t0,t1);}

C_noret_decl(trf_7582)
static void C_fcall trf_7582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7582(t0,t1);}

C_noret_decl(trf_7599)
static void C_fcall trf_7599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7599(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7599(t0,t1);}

C_noret_decl(trf_7616)
static void C_fcall trf_7616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7616(t0,t1);}

C_noret_decl(trf_7633)
static void C_fcall trf_7633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7633(t0,t1);}

C_noret_decl(trf_7650)
static void C_fcall trf_7650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7650(t0,t1);}

C_noret_decl(trf_7667)
static void C_fcall trf_7667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7667(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7667(t0,t1);}

C_noret_decl(trf_7684)
static void C_fcall trf_7684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7684(t0,t1);}

C_noret_decl(trf_7141)
static void C_fcall trf_7141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7141(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7141(t0,t1,t2);}

C_noret_decl(trf_7136)
static void C_fcall trf_7136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7136(t0,t1);}

C_noret_decl(trf_6675)
static void C_fcall trf_6675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6675(t0,t1);}

C_noret_decl(trf_6684)
static void C_fcall trf_6684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6684(t0,t1);}

C_noret_decl(trf_6696)
static void C_fcall trf_6696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6696(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6696(t0,t1);}

C_noret_decl(trf_6708)
static void C_fcall trf_6708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6708(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6708(t0,t1);}

C_noret_decl(trf_6748)
static void C_fcall trf_6748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6748(t0,t1);}

C_noret_decl(trf_6243)
static void C_fcall trf_6243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6243(t0,t1,t2);}

C_noret_decl(trf_6272)
static void C_fcall trf_6272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6272(t0,t1);}

C_noret_decl(trf_6275)
static void C_fcall trf_6275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6275(t0,t1);}

C_noret_decl(trf_6259)
static void C_fcall trf_6259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6259(t0,t1);}

C_noret_decl(trf_6175)
static void C_fcall trf_6175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6175(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6175(t0,t1,t2);}

C_noret_decl(trf_5377)
static void C_fcall trf_5377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5377(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5377(t0,t1);}

C_noret_decl(trf_5405)
static void C_fcall trf_5405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5405(t0,t1);}

C_noret_decl(trf_6023)
static void C_fcall trf_6023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6023(t0,t1);}

C_noret_decl(trf_5471)
static void C_fcall trf_5471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5471(t0,t1);}

C_noret_decl(trf_5985)
static void C_fcall trf_5985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5985(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5985(t0,t1,t2,t3);}

C_noret_decl(trf_5928)
static void C_fcall trf_5928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5928(t0,t1);}

C_noret_decl(trf_5949)
static void C_fcall trf_5949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5949(t0,t1);}

C_noret_decl(trf_5892)
static void C_fcall trf_5892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5892(t0,t1);}

C_noret_decl(trf_5859)
static void C_fcall trf_5859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5859(t0,t1);}

C_noret_decl(trf_5868)
static void C_fcall trf_5868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5868(t0,t1);}

C_noret_decl(trf_5813)
static void C_fcall trf_5813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5813(t0,t1);}

C_noret_decl(trf_5503)
static void C_fcall trf_5503(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5503(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5503(t0,t1);}

C_noret_decl(trf_5563)
static void C_fcall trf_5563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5563(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5563(t0,t1,t2,t3);}

C_noret_decl(trf_5115)
static void C_fcall trf_5115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5115(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5115(t0,t1,t2,t3);}

C_noret_decl(trf_4944)
static void C_fcall trf_4944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4944(t0,t1);}

C_noret_decl(trf_4950)
static void C_fcall trf_4950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4950(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4950(t0,t1,t2,t3);}

C_noret_decl(trf_5146)
static void C_fcall trf_5146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5146(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5146(t0,t1,t2,t3);}

C_noret_decl(trf_5153)
static void C_fcall trf_5153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5153(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5153(t0,t1);}

C_noret_decl(trf_5242)
static void C_fcall trf_5242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5242(t0,t1);}

C_noret_decl(trf_4981)
static void C_fcall trf_4981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4981(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4981(t0,t1);}

C_noret_decl(trf_5288)
static void C_fcall trf_5288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5288(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5288(t0,t1,t2);}

C_noret_decl(trf_5303)
static void C_fcall trf_5303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5303(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5303(t0,t1,t2,t3);}

C_noret_decl(trf_5319)
static void C_fcall trf_5319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5319(t0,t1);}

C_noret_decl(trf_5365)
static void C_fcall trf_5365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5365(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5365(t0,t1,t2,t3);}

C_noret_decl(trf_4658)
static void C_fcall trf_4658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4658(t0,t1);}

C_noret_decl(trf_4844)
static void C_fcall trf_4844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4844(t0,t1);}

C_noret_decl(trf_4847)
static void C_fcall trf_4847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4847(t0,t1);}

C_noret_decl(trf_4893)
static void C_fcall trf_4893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4893(t0,t1);}

C_noret_decl(trf_4697)
static void C_fcall trf_4697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4697(t0,t1,t2);}

C_noret_decl(trf_4661)
static void C_fcall trf_4661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4661(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4661(t0,t1);}

C_noret_decl(trf_4674)
static void C_fcall trf_4674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4674(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4674(t0,t1,t2,t3);}

C_noret_decl(trf_4407)
static void C_fcall trf_4407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4407(t0,t1);}

C_noret_decl(trf_4445)
static void C_fcall trf_4445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4445(t0,t1);}

C_noret_decl(trf_4466)
static void C_fcall trf_4466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4466(t0,t1);}

C_noret_decl(trf_4531)
static void C_fcall trf_4531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4531(t0,t1);}

C_noret_decl(trf_4258)
static void C_fcall trf_4258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4258(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4258(t0,t1);}

C_noret_decl(trf_4279)
static void C_fcall trf_4279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4279(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4279(t0,t1,t2,t3);}

C_noret_decl(trf_4348)
static void C_fcall trf_4348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4348(t0,t1,t2);}

C_noret_decl(trf_4321)
static void C_fcall trf_4321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4321(t0,t1,t2);}

C_noret_decl(trf_4111)
static void C_fcall trf_4111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4111(t0,t1);}

C_noret_decl(trf_4114)
static void C_fcall trf_4114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4114(t0,t1);}

C_noret_decl(trf_2538)
static void C_fcall trf_2538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2538(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2538(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4079)
static void C_fcall trf_4079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4079(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4079(t0,t1,t2,t3);}

C_noret_decl(trf_2541)
static void C_fcall trf_2541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2541(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2541(t0,t1,t2,t3);}

C_noret_decl(trf_3980)
static void C_fcall trf_3980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3980(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3980(t0,t1,t2,t3);}

C_noret_decl(trf_3218)
static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3218(t0,t1);}

C_noret_decl(trf_3224)
static void C_fcall trf_3224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3224(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3224(t0,t1);}

C_noret_decl(trf_3357)
static void C_fcall trf_3357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3357(t0,t1);}

C_noret_decl(trf_3462)
static void C_fcall trf_3462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3462(t0,t1);}

C_noret_decl(trf_2723)
static void C_fcall trf_2723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2723(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2723(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2528)
static void C_fcall trf_2528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2528(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2528(t0,t1);}

C_noret_decl(trf_2496)
static void C_fcall trf_2496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2496(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2414)){
C_save(t1);
C_rereclaim2(2414*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,840);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],12,"\003sysfor-each");
lf[5]=C_h_intern(&lf[5],17,"\010compilergen-list");
lf[6]=C_h_intern(&lf[6],11,"intersperse");
lf[7]=C_h_intern(&lf[7],18,"\010compilerunique-id");
lf[8]=C_h_intern(&lf[8],22,"\010compilergenerate-code");
lf[9]=C_h_intern(&lf[9],13,"\010compilerbomb");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[11]=C_h_intern(&lf[11],17,"lambda-literal-id");
lf[12]=C_h_intern(&lf[12],4,"find");
lf[13]=C_h_intern(&lf[13],17,"string-translate*");
lf[14]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[15]=C_h_intern(&lf[15],8,"->string");
lf[16]=C_h_intern(&lf[16],14,"\004coreimmediate");
lf[17]=C_h_intern(&lf[17],4,"bool");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[20]=C_h_intern(&lf[20],4,"char");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[22]=C_h_intern(&lf[22],3,"nil");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[24]=C_h_intern(&lf[24],3,"fix");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[26]=C_h_intern(&lf[26],3,"eof");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[29]=C_h_intern(&lf[29],12,"\004coreliteral");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[33]=C_h_intern(&lf[33],2,"if");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[37]=C_h_intern(&lf[37],9,"\004coreproc");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[39]=C_h_intern(&lf[39],9,"\004corebind");
lf[40]=C_h_intern(&lf[40],8,"\004coreref");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[43]=C_h_intern(&lf[43],10,"\004coreunbox");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[46]=C_h_intern(&lf[46],13,"\004coreupdate_i");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[48]=C_h_intern(&lf[48],11,"\004coreupdate");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[52]=C_h_intern(&lf[52],16,"\004coreupdatebox_i");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[55]=C_h_intern(&lf[55],14,"\004coreupdatebox");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[58]=C_h_intern(&lf[58],12,"\004coreclosure");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[63]=C_h_intern(&lf[63],8,"for-each");
lf[64]=C_h_intern(&lf[64],4,"iota");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[66]=C_h_intern(&lf[66],8,"\004corebox");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[69]=C_h_intern(&lf[69],10,"\004corelocal");
lf[70]=C_h_intern(&lf[70],13,"\004coresetlocal");
lf[71]=C_h_intern(&lf[71],11,"\004coreglobal");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[76]=C_h_intern(&lf[76],21,"\010compilerc-ify-string");
lf[77]=C_h_intern(&lf[77],14,"symbol->string");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[82]=C_h_intern(&lf[82],14,"\004coresetglobal");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[89]=C_h_intern(&lf[89],16,"\004coresetglobal_i");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[96]=C_h_intern(&lf[96],14,"\004coreundefined");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[98]=C_h_intern(&lf[98],9,"\004corecall");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[104]=C_h_intern(&lf[104],26,"lambda-literal-temporaries");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[106]=C_h_intern(&lf[106],22,"lambda-literal-looping");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[113]=C_h_intern(&lf[113],13,"string-append");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\020C_retrieve_proc(");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\032C_retrieve_symbol_proc(lf[");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[129]=C_h_intern(&lf[129],6,"unsafe");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[134]=C_h_intern(&lf[134],19,"no-procedure-checks");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[137]=C_h_intern(&lf[137],24,"\010compileremit-trace-info");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[140]=C_h_intern(&lf[140],16,"string-translate");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[145]=C_h_intern(&lf[145],27,"lambda-literal-closure-size");
lf[146]=C_h_intern(&lf[146],28,"\010compilersource-info->string");
lf[147]=C_h_intern(&lf[147],12,"\004corerecurse");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[151]=C_h_intern(&lf[151],16,"\004coredirect_call");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[153]=C_h_intern(&lf[153],13,"\004corecallunit");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[158]=C_h_intern(&lf[158],11,"\004corereturn");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[161]=C_h_intern(&lf[161],11,"\004coreinline");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[163]=C_h_intern(&lf[163],20,"\004coreinline_allocate");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[166]=C_h_intern(&lf[166],15,"\004coreinline_ref");
lf[167]=C_h_intern(&lf[167],34,"\010compilerforeign-result-conversion");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[169]=C_h_intern(&lf[169],18,"\004coreinline_update");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[172]=C_h_intern(&lf[172],36,"\010compilerforeign-argument-conversion");
lf[173]=C_h_intern(&lf[173],33,"\010compilerforeign-type-declaration");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[175]=C_h_intern(&lf[175],19,"\004coreinline_loc_ref");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[181]=C_h_intern(&lf[181],22,"\004coreinline_loc_update");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_h_intern(&lf[187],11,"\004coreswitch");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[192]=C_h_intern(&lf[192],9,"\004corecond");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[196]=C_h_intern(&lf[196],13,"pair-for-each");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[198]=C_h_intern(&lf[198],30,"\010compilerexternal-protos-first");
lf[199]=C_h_intern(&lf[199],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[200]=C_h_intern(&lf[200],22,"foreign-callback-stubs");
lf[201]=C_h_intern(&lf[201],29,"\010compilerforeign-declarations");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[204]=C_h_intern(&lf[204],28,"\010compilertarget-include-file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[206]=C_h_intern(&lf[206],18,"\010compilerunit-name");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[208]=C_h_intern(&lf[208],19,"\010compilerused-units");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[210]=C_h_intern(&lf[210],27,"\010compilercompiler-arguments");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[216]=C_h_intern(&lf[216],18,"string-intersperse");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[220]=C_h_intern(&lf[220],7,"\003sysmap");
lf[221]=C_h_intern(&lf[221],12,"string-split");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[223]=C_h_intern(&lf[223],15,"chicken-version");
lf[224]=C_h_intern(&lf[224],18,"\003sysdecode-seconds");
lf[225]=C_h_intern(&lf[225],15,"current-seconds");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[230]=C_h_intern(&lf[230],23,"\003syslambda-info->string");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[240]=C_h_intern(&lf[240],9,"make-list");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[244]=C_h_intern(&lf[244],4,"none");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[255]=C_h_intern(&lf[255],8,"toplevel");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[258]=C_h_intern(&lf[258],27,"\010compileremit-unsafe-marker");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[271]=C_h_intern(&lf[271],21,"small-parameter-limit");
lf[272]=C_h_intern(&lf[272],11,"lset-adjoin");
lf[273]=C_h_intern(&lf[273],1,"=");
lf[274]=C_h_intern(&lf[274],32,"lambda-literal-callee-signatures");
lf[275]=C_h_intern(&lf[275],24,"lambda-literal-allocated");
lf[276]=C_h_intern(&lf[276],21,"lambda-literal-direct");
lf[277]=C_h_intern(&lf[277],33,"lambda-literal-rest-argument-mode");
lf[278]=C_h_intern(&lf[278],28,"lambda-literal-rest-argument");
lf[279]=C_h_intern(&lf[279],27,"\010compilermake-variable-list");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[281]=C_h_intern(&lf[281],27,"lambda-literal-customizable");
lf[282]=C_h_intern(&lf[282],29,"lambda-literal-argument-count");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[289]=C_h_intern(&lf[289],27,"\010compilermake-argument-list");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[329]=C_h_intern(&lf[329],6,"vector");
lf[330]=C_h_intern(&lf[330],23,"lambda-literal-external");
lf[331]=C_h_intern(&lf[331],14,"\003syscopy-bytes");
lf[332]=C_h_intern(&lf[332],11,"make-string");
lf[333]=C_h_intern(&lf[333],6,"modulo");
lf[334]=C_h_intern(&lf[334],3,"fx/");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[338]=C_h_intern(&lf[338],19,"\003sysundefined-value");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[349]=C_h_intern(&lf[349],23,"\010compilerencode-literal");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[351]=C_h_intern(&lf[351],32,"\010compilerblock-variable-literal\077");
lf[352]=C_h_intern(&lf[352],20,"\010compilerbig-fixnum\077");
lf[353]=C_h_intern(&lf[353],7,"sprintf");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[355]=C_h_intern(&lf[355],25,"\010compilerwords-per-flonum");
lf[356]=C_h_intern(&lf[356],6,"reduce");
lf[357]=C_h_intern(&lf[357],1,"+");
lf[358]=C_h_intern(&lf[358],12,"vector->list");
lf[359]=C_h_intern(&lf[359],14,"\010compilerwords");
lf[360]=C_h_intern(&lf[360],15,"\003sysbytevector\077");
lf[361]=C_h_intern(&lf[361],19,"\010compilerimmediate\077");
lf[362]=C_h_intern(&lf[362],19,"lambda-literal-body");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[375]=C_h_intern(&lf[375],4,"list");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[414]=C_h_intern(&lf[414],26,"\010compilertarget-stack-size");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[417]=C_h_intern(&lf[417],30,"\010compilertarget-heap-shrinkage");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[419]=C_h_intern(&lf[419],27,"\010compilertarget-heap-growth");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[421]=C_h_intern(&lf[421],33,"\010compilertarget-initial-heap-size");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[424]=C_h_intern(&lf[424],25,"\010compilertarget-heap-size");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[428]=C_h_intern(&lf[428],40,"\010compilerdisable-stack-overflow-checking");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[434]=C_h_intern(&lf[434],4,"fold");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[437]=C_h_intern(&lf[437],28,"\010compilerinsert-timer-checks");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[442]=C_h_intern(&lf[442],14,"no-argc-checks");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[479]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[482]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[489]=C_h_intern(&lf[489],16,"\010compilercleanup");
lf[490]=C_h_intern(&lf[490],18,"\010compilerdebugging");
lf[491]=C_h_intern(&lf[491],1,"o");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[497]=C_h_intern(&lf[497],18,"\010compilerreal-name");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[499]=C_h_intern(&lf[499],25,"emit-procedure-table-info");
lf[500]=C_h_intern(&lf[500],31,"generate-foreign-callback-stubs");
lf[501]=C_h_intern(&lf[501],31,"\010compilergenerate-foreign-stubs");
lf[502]=C_h_intern(&lf[502],29,"\010compilerforeign-lambda-stubs");
lf[503]=C_h_intern(&lf[503],36,"\010compilergenerate-external-variables");
lf[504]=C_h_intern(&lf[504],27,"\010compilerexternal-variables");
lf[505]=C_h_intern(&lf[505],1,"p");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[507]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[523]=C_h_intern(&lf[523],29,"\010compilerstring->c-identifier");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[527]=C_h_intern(&lf[527],11,"string-copy");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[529]=C_h_intern(&lf[529],13,"list-tabulate");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[532]=C_h_intern(&lf[532],41,"\010compilergenerate-foreign-callback-header");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[545]=C_h_intern(&lf[545],4,"void");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[548]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[570]=C_h_intern(&lf[570],21,"foreign-stub-callback");
lf[571]=C_h_intern(&lf[571],16,"foreign-stub-cps");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[573]=C_h_intern(&lf[573],27,"foreign-stub-argument-names");
lf[574]=C_h_intern(&lf[574],17,"foreign-stub-body");
lf[575]=C_h_intern(&lf[575],17,"foreign-stub-name");
lf[576]=C_h_intern(&lf[576],24,"foreign-stub-return-type");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[579]=C_h_intern(&lf[579],27,"foreign-stub-argument-types");
lf[580]=C_h_intern(&lf[580],19,"\010compilerreal-name2");
lf[581]=C_h_intern(&lf[581],15,"foreign-stub-id");
lf[582]=C_h_intern(&lf[582],5,"float");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[584]=C_h_intern(&lf[584],8,"c-string");
lf[585]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[586]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[588]=C_h_intern(&lf[588],16,"nonnull-c-string");
lf[589]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[590]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[591]=C_h_intern(&lf[591],3,"ref");
lf[592]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[593]=C_h_intern(&lf[593],5,"const");
lf[594]=C_h_intern(&lf[594],7,"pointer");
lf[595]=C_h_intern(&lf[595],9,"c-pointer");
lf[596]=C_h_intern(&lf[596],15,"nonnull-pointer");
lf[597]=C_h_intern(&lf[597],17,"nonnull-c-pointer");
lf[598]=C_h_intern(&lf[598],8,"function");
lf[599]=C_h_intern(&lf[599],8,"instance");
lf[600]=C_h_intern(&lf[600],16,"nonnull-instance");
lf[601]=C_h_intern(&lf[601],12,"instance-ref");
lf[602]=C_h_intern(&lf[602],18,"\003syshash-table-ref");
lf[603]=C_h_intern(&lf[603],27,"\010compilerforeign-type-table");
lf[604]=C_h_intern(&lf[604],17,"nonnull-c-string*");
lf[605]=C_h_intern(&lf[605],25,"nonnull-unsigned-c-string");
lf[606]=C_h_intern(&lf[606],26,"nonnull-unsigned-c-string*");
lf[607]=C_h_intern(&lf[607],6,"symbol");
lf[608]=C_h_intern(&lf[608],9,"c-string*");
lf[609]=C_h_intern(&lf[609],17,"unsigned-c-string");
lf[610]=C_h_intern(&lf[610],18,"unsigned-c-string*");
lf[611]=C_h_intern(&lf[611],6,"double");
lf[612]=C_h_intern(&lf[612],16,"unsigned-integer");
lf[613]=C_h_intern(&lf[613],18,"unsigned-integer32");
lf[614]=C_h_intern(&lf[614],4,"long");
lf[615]=C_h_intern(&lf[615],7,"integer");
lf[616]=C_h_intern(&lf[616],9,"integer32");
lf[617]=C_h_intern(&lf[617],13,"unsigned-long");
lf[618]=C_h_intern(&lf[618],6,"number");
lf[619]=C_h_intern(&lf[619],9,"integer64");
lf[620]=C_h_intern(&lf[620],13,"c-string-list");
lf[621]=C_h_intern(&lf[621],14,"c-string-list*");
lf[622]=C_h_intern(&lf[622],3,"int");
lf[623]=C_h_intern(&lf[623],5,"int32");
lf[624]=C_h_intern(&lf[624],5,"short");
lf[625]=C_h_intern(&lf[625],14,"unsigned-short");
lf[626]=C_h_intern(&lf[626],13,"scheme-object");
lf[627]=C_h_intern(&lf[627],13,"unsigned-char");
lf[628]=C_h_intern(&lf[628],12,"unsigned-int");
lf[629]=C_h_intern(&lf[629],14,"unsigned-int32");
lf[630]=C_h_intern(&lf[630],4,"byte");
lf[631]=C_h_intern(&lf[631],13,"unsigned-byte");
lf[632]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[647]=C_h_intern(&lf[647],36,"foreign-callback-stub-argument-types");
lf[648]=C_h_intern(&lf[648],33,"foreign-callback-stub-return-type");
lf[649]=C_h_intern(&lf[649],24,"foreign-callback-stub-id");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[652]=C_h_intern(&lf[652],32,"foreign-callback-stub-qualifiers");
lf[653]=C_h_intern(&lf[653],26,"foreign-callback-stub-name");
lf[654]=C_h_intern(&lf[654],4,"quit");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[664]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[666]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[669]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[670]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[674]=C_h_intern(&lf[674],11,"byte-vector");
lf[675]=C_h_intern(&lf[675],19,"nonnull-byte-vector");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[677]=C_h_intern(&lf[677],4,"blob");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[679]=C_h_intern(&lf[679],9,"u16vector");
lf[680]=C_h_intern(&lf[680],17,"nonnull-u16vector");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[682]=C_h_intern(&lf[682],8,"s8vector");
lf[683]=C_h_intern(&lf[683],16,"nonnull-s8vector");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[685]=C_h_intern(&lf[685],9,"u32vector");
lf[686]=C_h_intern(&lf[686],17,"nonnull-u32vector");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[688]=C_h_intern(&lf[688],9,"s16vector");
lf[689]=C_h_intern(&lf[689],17,"nonnull-s16vector");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[691]=C_h_intern(&lf[691],9,"s32vector");
lf[692]=C_h_intern(&lf[692],17,"nonnull-s32vector");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[694]=C_h_intern(&lf[694],9,"f32vector");
lf[695]=C_h_intern(&lf[695],17,"nonnull-f32vector");
lf[696]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[697]=C_h_intern(&lf[697],9,"f64vector");
lf[698]=C_h_intern(&lf[698],17,"nonnull-f64vector");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[705]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[711]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[712]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[723]=C_h_intern(&lf[723],3,"...");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[728]=C_h_intern(&lf[728],9,"\003syserror");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[730]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[731]=C_h_intern(&lf[731],4,"enum");
lf[732]=C_h_intern(&lf[732],5,"union");
lf[733]=C_h_intern(&lf[733],6,"struct");
lf[734]=C_h_intern(&lf[734],8,"template");
lf[735]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[736]=C_h_intern(&lf[736],12,"nonnull-blob");
lf[737]=C_h_intern(&lf[737],8,"u8vector");
lf[738]=C_h_intern(&lf[738],16,"nonnull-u8vector");
lf[739]=C_h_intern(&lf[739],14,"scheme-pointer");
lf[740]=C_h_intern(&lf[740],22,"nonnull-scheme-pointer");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[835]=C_h_intern(&lf[835],17,"\003sysstring-append");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[837]=C_h_intern(&lf[837],5,"cons*");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[839]=C_h_intern(&lf[839],6,"random");
C_register_lf2(lf,840,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2432 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2435 in k2432 */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2438 in k2435 in k2432 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2449,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2452,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2473,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9162,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9166,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 98   random */
((C_proc3)C_retrieve_symbol_proc(lf[839]))(3,*((C_word*)lf[839]+1),t7,C_fix(16777216));}

/* k9164 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9170,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 98   current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t2);}

/* k9168 in k9164 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 98   sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[353]))(5,*((C_word*)lf[353]+1),((C_word*)t0)[3],lf[838],((C_word*)t0)[2],t1);}

/* k9160 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 97   string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),((C_word*)t0)[2],t1);}

/* k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=C_mutate((C_word*)lf[7]+1 /* (set! unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[8]+1 /* (set! generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2493,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[499]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6157,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[489]+1 /* (set! cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6234,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[279]+1 /* (set! make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6323,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[289]+1 /* (set! make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6339,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[503]+1 /* (set! generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6355,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[199]+1 /* (set! generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6387,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[501]+1 /* (set! generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6405,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[500]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6638,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[532]+1 /* (set! generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7069,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[173]+1 /* (set! foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7134,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[172]+1 /* (set! foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7979,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[167]+1 /* (set! foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8464,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[349]+1 /* (set! encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8862,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_8862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[22],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8862,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8871,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8924,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t4;
f_8924(2,t6,lf[822]);}
else{
t6=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t4;
f_8924(2,t7,lf[823]);}
else{
if(C_truep((C_word)C_charp(t2))){
t7=(C_word)C_fix((C_word)C_character_code(t2));
t8=f_8871(C_a_i(&a,4),t7);
/* c-backend.scm: 1407 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,lf[824],t8);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t7=t4;
f_8924(2,t7,lf[825]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t7=t4;
f_8924(2,t7,lf[826]);}
else{
t7=C_retrieve(lf[338]);
t8=(C_word)C_eqp(t7,t2);
if(C_truep(t8)){
t9=t4;
f_8924(2,t9,lf[827]);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9042,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1412 big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t9,t2);}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9055,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1421 number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_i_string_length(t9);
t11=f_8871(C_a_i(&a,4),t10);
/* c-backend.scm: 1424 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t4,lf[833],t11,t9);}
else{
if(C_truep((C_word)C_immp(t2))){
/* c-backend.scm: 1429 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t4,lf[834],t2);}
else{
if(C_truep((C_word)C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9094,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=(C_word)stub2373(C_SCHEME_UNDEFINED,t10);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,1,t12);
t14=t2;
t15=(C_word)stub2378(C_SCHEME_UNDEFINED,t14);
t16=f_8871(C_a_i(&a,4),t15);
/* c-backend.scm: 1432 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t9,t13,t16);}
else{
t9=t2;
t10=(C_word)stub2378(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9124,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=(C_word)stub2373(C_SCHEME_UNDEFINED,t12);
t14=(C_word)C_make_character((C_word)C_unfix(t13));
t15=(C_word)C_a_i_string(&a,1,t14);
t16=f_8871(C_a_i(&a,4),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9136,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9138,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1442 list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t17,t10,t18);}}}}}}}}}}}}

/* a9137 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9138,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1442 encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t1,t3);}

/* k9134 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1439 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[837]))(5,*((C_word*)lf[837]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9122 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1438 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[836]);}

/* k9092 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1431 ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[835]))(4,*((C_word*)lf[835]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9053 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1421 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[831],t1,lf[832]);}

/* k9040 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9042,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9038,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1419 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[2],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[2]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1413 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[830],t13);}}

/* k9036 in k9040 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1419 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[828],t1,lf[829]);}

/* k8922 in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_8924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8924,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1403 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static C_word C_fcall f_8871(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_8464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8464,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[796]);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[623]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[797]);}
else{
t10=(C_word)C_eqp(t5,lf[628]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[629]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[798]);}
else{
t12=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[799]);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[800]);}
else{
t14=(C_word)C_eqp(t5,lf[630]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[801]);}
else{
t15=(C_word)C_eqp(t5,lf[631]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[802]);}
else{
t16=(C_word)C_eqp(t5,lf[582]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[611]));
if(C_truep(t17)){
/* c-backend.scm: 1341 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[803],t3);}
else{
t18=(C_word)C_eqp(t5,lf[618]);
if(C_truep(t18)){
/* c-backend.scm: 1342 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t1,lf[804],t3);}
else{
t19=(C_word)C_eqp(t5,lf[588]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8551,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8551(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t21)){
t22=t20;
f_8551(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[597]);
if(C_truep(t22)){
t23=t20;
f_8551(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t23)){
t24=t20;
f_8551(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t24)){
t25=t20;
f_8551(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t25)){
t26=t20;
f_8551(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[610]);
if(C_truep(t26)){
t27=t20;
f_8551(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t27)){
t28=t20;
f_8551(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t28)){
t29=t20;
f_8551(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t29)){
t30=t20;
f_8551(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[620]);
t31=t20;
f_8551(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[621])));}}}}}}}}}}}}}}}}}}}}

/* k8549 in ##compiler#foreign-result-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8551,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1346 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[805],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t2)){
/* c-backend.scm: 1347 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[806],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t4)){
/* c-backend.scm: 1348 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[807],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t5)){
/* c-backend.scm: 1349 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[808],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
/* c-backend.scm: 1350 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[809],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t8)){
/* c-backend.scm: 1351 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[810],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t9)){
/* c-backend.scm: 1352 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[6],lf[811],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[812]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[545]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[626]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[813]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1356 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t13,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t14=t13;
f_8632(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k8630 in k8549 in ##compiler#foreign-result-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_8632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8632,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1358 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8654(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8654(t3,C_SCHEME_FALSE);}}}

/* k8652 in k8630 in k8549 in ##compiler#foreign-result-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8654(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[596]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,lf[597]));
if(C_truep(t4)){
/* c-backend.scm: 1362 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[814],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t5)){
/* c-backend.scm: 1364 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[815],((C_word*)t0)[3]);}
else{
t6=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t6)){
/* c-backend.scm: 1366 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[816],((C_word*)t0)[3]);}
else{
t7=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t7)){
/* c-backend.scm: 1368 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[817],((C_word*)t0)[3]);}
else{
t8=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t8)){
/* c-backend.scm: 1370 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[818],((C_word*)t0)[3]);}
else{
t9=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1371 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=(C_word)C_eqp(t2,lf[594]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t2,lf[595]));
if(C_truep(t11)){
/* c-backend.scm: 1373 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[819],((C_word*)t0)[3]);}
else{
t12=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t12)){
/* c-backend.scm: 1374 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[820],((C_word*)t0)[3]);}
else{
t13=(C_word)C_eqp(t2,lf[731]);
if(C_truep(t13)){
/* c-backend.scm: 1375 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),((C_word*)t0)[4],lf[821],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1376 err */
t14=((C_word*)t0)[2];
f_8466(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm: 1377 err */
t2=((C_word*)t0)[2];
f_8466(t2,((C_word*)t0)[4]);}}

/* err in ##compiler#foreign-result-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8466,NULL,2,t0,t1);}
/* c-backend.scm: 1332 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[795],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7979(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7979,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[626]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[742]);}
else{
t6=(C_word)C_eqp(t4,lf[20]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[627]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[743]);}
else{
t8=(C_word)C_eqp(t4,lf[630]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8009,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_8009(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[622]);
if(C_truep(t10)){
t11=t9;
f_8009(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[628]);
if(C_truep(t11)){
t12=t9;
f_8009(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[629]);
t13=t9;
f_8009(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[631])));}}}}}}

/* k8007 in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8009(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8009,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[744]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[624]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[745]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[625]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[746]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[617]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[747]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[611]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_8036(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[618]);
t8=t6;
f_8036(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[582])));}}}}}}

/* k8034 in k8007 in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8036,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[748]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[615]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[616]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[749]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[619]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[750]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[751]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[612]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[613]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[752]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[594]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[753]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[754]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[739]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[755]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[740]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[756]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[757]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[758]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[677]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[759]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[736]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[760]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[674]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[761]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[762]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[737]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[763]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[738]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[764]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[679]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[765]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[680]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[766]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[685]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[767]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[686]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[768]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[682]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[769]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[683]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[770]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[688]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[771]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[689]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[772]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[691]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[773]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[774]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[694]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[775]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[695]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[776]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[697]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[777]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[698]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[778]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8231,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8231(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[608]);
if(C_truep(t36)){
t37=t35;
f_8231(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[609]);
t38=t35;
f_8231(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[610])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8229 in k8034 in k8007 in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8231(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8231,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[779]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8240,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8240(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_8240(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_8240(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_8240(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k8238 in k8229 in k8034 in k8007 in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8240,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[780]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[17]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[781]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1305 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_8249(2,t4,C_SCHEME_FALSE);}}}}

/* k8247 in k8238 in k8229 in k8034 in k8007 in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_8249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8249,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1307 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[3]))){
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8271(t4,(C_word)C_fixnum_greater_or_equal_p(t3,C_fix(2)));}
else{
t3=t2;
f_8271(t3,C_SCHEME_FALSE);}}}

/* k8269 in k8247 in k8238 in k8229 in k8034 in k8007 in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_8271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8271,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[782]);}
else{
t4=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[783]);}
else{
t5=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[784]);}
else{
t6=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[785]);}
else{
t7=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[786]);}
else{
t8=(C_word)C_eqp(t2,lf[600]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[787]);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[788]);}
else{
t10=(C_word)C_eqp(t2,lf[593]);
if(C_truep(t10)){
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1318 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),((C_word*)t0)[3],t11);}
else{
t11=(C_word)C_eqp(t2,lf[731]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[789]);}
else{
t12=(C_word)C_eqp(t2,lf[591]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8348,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 1321 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t13,t14,lf[792]);}
else{
t13=(C_word)C_eqp(t2,lf[601]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1324 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[793],t14,lf[794]);}
else{
/* c-backend.scm: 1325 err */
t14=((C_word*)t0)[2];
f_7981(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm: 1326 err */
t2=((C_word*)t0)[2];
f_7981(t2,((C_word*)t0)[3]);}}

/* k8346 in k8269 in k8247 in k8238 in k8229 in k8034 in k8007 in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_8348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1321 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[790],t1,lf[791]);}

/* err in ##compiler#foreign-argument-conversion in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7981(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7981,NULL,2,t0,t1);}
/* c-backend.scm: 1259 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[741],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7134,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7136,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7141,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[626]);
if(C_truep(t7)){
/* c-backend.scm: 1166 str */
t8=t5;
f_7141(t8,t1,lf[657]);}
else{
t8=(C_word)C_eqp(t6,lf[20]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[630]));
if(C_truep(t9)){
/* c-backend.scm: 1167 str */
t10=t5;
f_7141(t10,t1,lf[658]);}
else{
t10=(C_word)C_eqp(t6,lf[627]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[631]));
if(C_truep(t11)){
/* c-backend.scm: 1168 str */
t12=t5;
f_7141(t12,t1,lf[659]);}
else{
t12=(C_word)C_eqp(t6,lf[628]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[612]));
if(C_truep(t13)){
/* c-backend.scm: 1169 str */
t14=t5;
f_7141(t14,t1,lf[660]);}
else{
t14=(C_word)C_eqp(t6,lf[629]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[613]));
if(C_truep(t15)){
/* c-backend.scm: 1170 str */
t16=t5;
f_7141(t16,t1,lf[661]);}
else{
t16=(C_word)C_eqp(t6,lf[622]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7211,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7211(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[615]);
t19=t17;
f_7211(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[17])));}}}}}}}

/* k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7211,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1171 str */
t2=((C_word*)t0)[7];
f_7141(t2,((C_word*)t0)[6],lf[662]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[623]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[616]));
if(C_truep(t3)){
/* c-backend.scm: 1172 str */
t4=((C_word*)t0)[7];
f_7141(t4,((C_word*)t0)[6],lf[663]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t4)){
/* c-backend.scm: 1173 str */
t5=((C_word*)t0)[7];
f_7141(t5,((C_word*)t0)[6],lf[664]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[624]);
if(C_truep(t5)){
/* c-backend.scm: 1174 str */
t6=((C_word*)t0)[7];
f_7141(t6,((C_word*)t0)[6],lf[665]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t6)){
/* c-backend.scm: 1175 str */
t7=((C_word*)t0)[7];
f_7141(t7,((C_word*)t0)[6],lf[666]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[625]);
if(C_truep(t7)){
/* c-backend.scm: 1176 str */
t8=((C_word*)t0)[7];
f_7141(t8,((C_word*)t0)[6],lf[667]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t8)){
/* c-backend.scm: 1177 str */
t9=((C_word*)t0)[7];
f_7141(t9,((C_word*)t0)[6],lf[668]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t9)){
/* c-backend.scm: 1178 str */
t10=((C_word*)t0)[7];
f_7141(t10,((C_word*)t0)[6],lf[669]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[618]));
if(C_truep(t11)){
/* c-backend.scm: 1179 str */
t12=((C_word*)t0)[7];
f_7141(t12,((C_word*)t0)[6],lf[670]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t13)){
/* c-backend.scm: 1181 str */
t14=((C_word*)t0)[7];
f_7141(t14,((C_word*)t0)[6],lf[671]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7313(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t16)){
t17=t15;
f_7313(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[739]);
t18=t15;
f_7313(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[740])));}}}}}}}}}}}}}

/* k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7313,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1182 str */
t2=((C_word*)t0)[7];
f_7141(t2,((C_word*)t0)[6],lf[672]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[621]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[673]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[674]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[675]));
if(C_truep(t5)){
/* c-backend.scm: 1185 str */
t6=((C_word*)t0)[7];
f_7141(t6,((C_word*)t0)[6],lf[676]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[677]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7346(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[736]);
if(C_truep(t8)){
t9=t7;
f_7346(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[737]);
t10=t7;
f_7346(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[738])));}}}}}}

/* k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7346,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1186 str */
t2=((C_word*)t0)[7];
f_7141(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[679]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[680]));
if(C_truep(t3)){
/* c-backend.scm: 1187 str */
t4=((C_word*)t0)[7];
f_7141(t4,((C_word*)t0)[6],lf[681]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[682]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[683]));
if(C_truep(t5)){
/* c-backend.scm: 1188 str */
t6=((C_word*)t0)[7];
f_7141(t6,((C_word*)t0)[6],lf[684]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[685]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[686]));
if(C_truep(t7)){
/* c-backend.scm: 1189 str */
t8=((C_word*)t0)[7];
f_7141(t8,((C_word*)t0)[6],lf[687]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[688]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[689]));
if(C_truep(t9)){
/* c-backend.scm: 1190 str */
t10=((C_word*)t0)[7];
f_7141(t10,((C_word*)t0)[6],lf[690]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[691]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[692]));
if(C_truep(t11)){
/* c-backend.scm: 1191 str */
t12=((C_word*)t0)[7];
f_7141(t12,((C_word*)t0)[6],lf[693]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[694]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[695]));
if(C_truep(t13)){
/* c-backend.scm: 1192 str */
t14=((C_word*)t0)[7];
f_7141(t14,((C_word*)t0)[6],lf[696]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[697]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[698]));
if(C_truep(t15)){
/* c-backend.scm: 1193 str */
t16=((C_word*)t0)[7];
f_7141(t16,((C_word*)t0)[6],lf[699]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7442(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t18)){
t19=t17;
f_7442(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[604]);
if(C_truep(t19)){
t20=t17;
f_7442(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
t21=t17;
f_7442(t21,(C_truep(t20)?t20:(C_word)C_eqp(((C_word*)t0)[5],lf[607])));}}}}}}}}}}}}

/* k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7442,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1195 str */
t2=((C_word*)t0)[7];
f_7141(t2,((C_word*)t0)[6],lf[700]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[605]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7454(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[606]);
if(C_truep(t4)){
t5=t3;
f_7454(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
t6=t3;
f_7454(t6,(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[5],lf[610])));}}}}

/* k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7454,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1197 str */
t2=((C_word*)t0)[7];
f_7141(t2,((C_word*)t0)[6],lf[701]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t2)){
/* c-backend.scm: 1198 str */
t3=((C_word*)t0)[7];
f_7141(t3,((C_word*)t0)[6],lf[702]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1200 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t3,C_retrieve(lf[603]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7469(2,t4,C_SCHEME_FALSE);}}}}

/* k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7469,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1202 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1203 str */
t2=((C_word*)t0)[3];
f_7141(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[4]))){
t2=(C_word)C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7509,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=t3;
f_7509(t6,(C_word)C_i_memq(t5,lf[735]));}
else{
t5=t3;
f_7509(t5,C_SCHEME_FALSE);}}
else{
/* c-backend.scm: 1253 err */
t2=((C_word*)t0)[2];
f_7136(t2,((C_word*)t0)[6]);}}}}

/* k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7509,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7520,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1210 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[703],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(C_fix(2),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=t2;
f_7526(t5,(C_word)C_eqp(lf[591],t4));}
else{
t4=t2;
f_7526(t4,C_SCHEME_FALSE);}}}

/* k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7526,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7537,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1213 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t3,lf[704],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7543(t4,(C_word)C_eqp(lf[734],t3));}
else{
t3=t2;
f_7543(t3,C_SCHEME_FALSE);}}}

/* k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7550,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7554,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1218 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,t4,lf[709]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7582(t5,(C_word)C_eqp(lf[593],t4));}
else{
t4=t2;
f_7582(t4,C_SCHEME_FALSE);}}}

/* k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7582,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7589,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1225 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=t2;
f_7599(t5,(C_word)C_eqp(lf[733],t4));}
else{
t4=t2;
f_7599(t4,C_SCHEME_FALSE);}}}

/* k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7599(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7599,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7606,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1227 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7616(t5,(C_word)C_eqp(lf[732],t4));}
else{
t4=t2;
f_7616(t4,C_SCHEME_FALSE);}}}

/* k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7616,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7623,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1229 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(2));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7633(t5,(C_word)C_eqp(lf[731],t4));}
else{
t4=t2;
f_7633(t4,C_SCHEME_FALSE);}}}

/* k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7633,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7640,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1231 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7650(t5,(C_word)C_i_memq(t4,lf[730]));}
else{
t4=t2;
f_7650(t4,C_SCHEME_FALSE);}}}

/* k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7650,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7657,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1233 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(3));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=t2;
f_7667(t5,(C_word)C_eqp(lf[601],t4));}
else{
t4=t2;
f_7667(t4,C_SCHEME_FALSE);}}}

/* k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7667(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7667,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7674,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1235 ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)t0)[2],C_fix(3)))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7684(t4,(C_word)C_eqp(lf[598],t3));}
else{
t3=t2;
f_7684(t3,C_SCHEME_FALSE);}}}

/* k7682 in k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7684,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7696,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7696(2,t6,lf[727]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7696(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[728]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[729],t4);}}}
else{
/* c-backend.scm: 1252 err */
t2=((C_word*)t0)[2];
f_7136(t2,((C_word*)t0)[4]);}}

/* k7694 in k7682 in k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1241 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[726]);}

/* k7701 in k7694 in k7682 in k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7707,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7711,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7713,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7712 in k7701 in k7694 in k7682 in k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7713,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[723],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[724]);}
else{
/* c-backend.scm: 1248 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[725]);}}

/* k7709 in k7701 in k7694 in k7682 in k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1244 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[722]);}

/* k7705 in k7701 in k7694 in k7682 in k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1240 string-append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[113]+1)))(9,*((C_word*)lf[113]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[719],((C_word*)t0)[2],lf[720],t1,lf[721]);}

/* k7672 in k7665 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1235 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[718],((C_word*)t0)[2]);}

/* k7655 in k7648 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1233 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],t1,lf[717],((C_word*)t0)[2]);}

/* k7638 in k7631 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1231 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[715],t1,lf[716],((C_word*)t0)[2]);}

/* k7621 in k7614 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1229 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[713],t1,lf[714],((C_word*)t0)[2]);}

/* k7604 in k7597 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1227 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[711],t1,lf[712],((C_word*)t0)[2]);}

/* k7587 in k7580 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1225 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[710],t1);}

/* k7552 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7558,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7562,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7564,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7563 in k7552 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7564(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7564,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t1,t2,lf[708]);}

/* k7560 in k7552 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1220 string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[707]);}

/* k7556 in k7552 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1217 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[705],t1,lf[706]);}

/* k7548 in k7541 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1216 str */
t2=((C_word*)t0)[3];
f_7141(t2,((C_word*)t0)[2],t1);}

/* k7535 in k7524 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1213 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7518 in k7507 in k7467 in k7452 in k7440 in k7344 in k7311 in k7209 in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1210 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* str in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7141(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7141,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1164 string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,t2,lf[656],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_7136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7136,NULL,2,t0,t1);}
/* c-backend.scm: 1163 quit */
((C_proc4)C_retrieve_symbol_proc(lf[654]))(4,*((C_word*)lf[654]+1),t1,lf[655],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7069,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7073,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1145 foreign-callback-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[653]))(3,*((C_word*)lf[653]+1),t4,t3);}

/* k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7076,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1146 foreign-callback-stub-qualifiers */
((C_proc3)C_retrieve_symbol_proc(lf[652]))(3,*((C_word*)lf[652]+1),t2,((C_word*)t0)[2]);}

/* k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1147 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7082,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1148 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[2]);}

/* k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7082,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1150 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[651]);}

/* k7086 in k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7091,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1151 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t3,((C_word*)t0)[2],lf[650]);}

/* k7130 in k7086 in k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1151 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k7089 in k7086 in k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7094,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7099,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1152 pair-for-each */
((C_proc5)C_retrieve_symbol_proc(lf[196]))(5,*((C_word*)lf[196]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7098 in k7089 in k7086 in k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7099,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7103,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7120,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1154 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t5,t6,t7);}

/* k7118 in a7098 in k7089 in k7086 in k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1154 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k7101 in a7098 in k7089 in k7086 in k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1155 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k7092 in k7089 in k7086 in k7080 in k7077 in k7074 in k7071 in ##compiler#generate-foreign-callback-header in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1157 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6638,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6644,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6644,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6648,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1092 foreign-callback-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[649]))(3,*((C_word*)lf[649]+1),t3,t2);}

/* k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6651,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1093 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6654,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1094 foreign-callback-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[648]))(3,*((C_word*)lf[648]+1),t2,((C_word*)t0)[2]);}

/* k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1095 foreign-callback-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[647]))(3,*((C_word*)lf[647]+1),t2,((C_word*)t0)[3]);}

/* k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6657,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1097 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t3,t2,lf[646]);}

/* k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6663,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6665,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1124 fold */
((C_proc6)C_retrieve_symbol_proc(lf[434]))(6,*((C_word*)lf[434]+1),t5,((C_word*)t3)[1],lf[645],((C_word*)t0)[4],t1);}

/* k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1125 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7067,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1127 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7010(2,t3,C_SCHEME_UNDEFINED);}}

/* k7065 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1127 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[643],t1,lf[644]);}

/* k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1128 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[642],((C_word*)t0)[2]);}

/* k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1129 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(123),C_SCHEME_TRUE,lf[640],((C_word*)t0)[2],lf[641]);}

/* k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1130 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[639]);}

/* k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7052,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1131 for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7051 in k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7052,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7060,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1133 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t4,t3,lf[638]);}

/* k7058 in a7051 in k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1133 gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[635],t1,((C_word*)t0)[2],lf[636],C_SCHEME_TRUE,lf[637]);}

/* k7020 in k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_7025(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7050,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1138 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t4,((C_word*)t0)[4]);}}

/* k7048 in k7020 in k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1138 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[634],t1);}

/* k7023 in k7020 in k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1139 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[633],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k7026 in k7023 in k7020 in k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7031,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[545],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_7031(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1140 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k7029 in k7026 in k7023 in k7020 in k7017 in k7014 in k7011 in k7008 in k7005 in k7002 in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1141 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[632]);}

/* compute-size in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6665,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[20]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6675,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6675(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[622]);
if(C_truep(t8)){
t9=t7;
f_6675(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[623]);
if(C_truep(t9)){
t10=t7;
f_6675(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[624]);
if(C_truep(t10)){
t11=t7;
f_6675(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[17]);
if(C_truep(t11)){
t12=t7;
f_6675(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[545]);
if(C_truep(t12)){
t13=t7;
f_6675(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
t14=t7;
f_6675(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[626]);
if(C_truep(t14)){
t15=t7;
f_6675(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[627]);
if(C_truep(t15)){
t16=t7;
f_6675(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[628]);
if(C_truep(t16)){
t17=t7;
f_6675(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[629]);
if(C_truep(t17)){
t18=t7;
f_6675(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[630]);
t19=t7;
f_6675(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[631])));}}}}}}}}}}}}

/* k6673 in compute-size in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6675,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6684(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[611]);
if(C_truep(t4)){
t5=t3;
f_6684(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t5)){
t6=t3;
f_6684(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[612]);
if(C_truep(t6)){
t7=t3;
f_6684(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[613]);
if(C_truep(t7)){
t8=t3;
f_6684(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t8)){
t9=t3;
f_6684(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[615]);
if(C_truep(t9)){
t10=t3;
f_6684(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[616]);
if(C_truep(t10)){
t11=t3;
f_6684(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[617]);
if(C_truep(t11)){
t12=t3;
f_6684(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t12)){
t13=t3;
f_6684(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[618]);
if(C_truep(t13)){
t14=t3;
f_6684(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[619]);
if(C_truep(t14)){
t15=t3;
f_6684(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[620]);
t16=t3;
f_6684(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[621])));}}}}}}}}}}}}}}

/* k6682 in k6673 in compute-size in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6684,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1106 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[583]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6696(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[608]);
if(C_truep(t4)){
t5=t3;
f_6696(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
if(C_truep(t5)){
t6=t3;
f_6696(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[609]);
t7=t3;
f_6696(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[610])));}}}}}

/* k6694 in k6682 in k6673 in compute-size in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6696(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6696,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1108 string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[113]+1)))(8,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[585],((C_word*)t0)[5],lf[586],((C_word*)t0)[5],lf[587]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[588]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6708(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[604]);
if(C_truep(t4)){
t5=t3;
f_6708(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[605]);
if(C_truep(t5)){
t6=t3;
f_6708(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[606]);
t7=t3;
f_6708(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[607])));}}}}}

/* k6706 in k6694 in k6682 in k6673 in compute-size in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6708(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6708,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1110 string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[113]+1)))(6,*((C_word*)lf[113]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[589],((C_word*)t0)[4],lf[590]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1112 ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[602]))(4,*((C_word*)lf[602]+1),t2,C_retrieve(lf[603]),((C_word*)t0)[2]);}
else{
t3=t2;
f_6714(2,t3,C_SCHEME_FALSE);}}}

/* k6712 in k6706 in k6694 in k6682 in k6673 in compute-size in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1114 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6665(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[591]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6748,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_6748(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[594]);
if(C_truep(t5)){
t6=t4;
f_6748(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[595]);
if(C_truep(t6)){
t7=t4;
f_6748(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[596]);
if(C_truep(t7)){
t8=t4;
f_6748(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[597]);
if(C_truep(t8)){
t9=t4;
f_6748(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[598]);
if(C_truep(t9)){
t10=t4;
f_6748(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[599]);
if(C_truep(t10)){
t11=t4;
f_6748(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[600]);
t12=t4;
f_6748(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[601])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k6746 in k6712 in k6706 in k6694 in k6682 in k6673 in compute-size in k6661 in k6655 in k6652 in k6649 in k6646 in a6643 in generate-foreign-callback-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1119 string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[592]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1120 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6665(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6405,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6411,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6411(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6411,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6415,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1025 foreign-stub-id */
((C_proc3)C_retrieve_symbol_proc(lf[581]))(3,*((C_word*)lf[581]+1),t3,t2);}

/* k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6418,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1026 real-name2 */
((C_proc4)C_retrieve_symbol_proc(lf[580]))(4,*((C_word*)lf[580]+1),t2,t1,((C_word*)t0)[2]);}

/* k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6421,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1027 foreign-stub-argument-types */
((C_proc3)C_retrieve_symbol_proc(lf[579]))(3,*((C_word*)lf[579]+1),t2,((C_word*)t0)[2]);}

/* k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6421,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6636,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1029 make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,t2,lf[578]);}

/* k6634 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6636,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[577],t1);
/* c-backend.scm: 1029 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t2,C_make_character(44));}

/* k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1030 foreign-stub-return-type */
((C_proc3)C_retrieve_symbol_proc(lf[576]))(3,*((C_word*)lf[576]+1),t2,((C_word*)t0)[2]);}

/* k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1031 foreign-stub-name */
((C_proc3)C_retrieve_symbol_proc(lf[575]))(3,*((C_word*)lf[575]+1),t2,((C_word*)t0)[2]);}

/* k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1032 foreign-stub-body */
((C_proc3)C_retrieve_symbol_proc(lf[574]))(3,*((C_word*)lf[574]+1),t2,((C_word*)t0)[2]);}

/* k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1033 foreign-stub-argument-names */
((C_proc3)C_retrieve_symbol_proc(lf[573]))(3,*((C_word*)lf[573]+1),t2,((C_word*)t0)[2]);}

/* k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6442(2,t3,t1);}
else{
/* c-backend.scm: 1033 make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1034 foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t2,((C_word*)t0)[9],lf[572]);}

/* k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1035 foreign-stub-cps */
((C_proc3)C_retrieve_symbol_proc(lf[571]))(3,*((C_word*)lf[571]+1),t2,((C_word*)t0)[2]);}

/* k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1036 foreign-stub-callback */
((C_proc3)C_retrieve_symbol_proc(lf[570]))(3,*((C_word*)lf[570]+1),t2,((C_word*)t0)[2]);}

/* k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1037 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6625,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1039 cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6457(2,t3,C_SCHEME_UNDEFINED);}}

/* k6623 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1039 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[568],t1,lf[569]);}

/* k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1041 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[566],((C_word*)t0)[6],lf[567]);}
else{
t3=t2;
f_6460(2,t3,C_SCHEME_UNDEFINED);}}

/* k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1044 gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[561],((C_word*)t0)[2],lf[562],C_SCHEME_TRUE,lf[563],((C_word*)t0)[2],lf[564]);}
else{
/* c-backend.scm: 1046 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[565],((C_word*)t0)[2],C_make_character(40));}}

/* k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[3]);}

/* k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1049 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[556],C_SCHEME_TRUE,lf[557],((C_word*)t0)[2],lf[558]);}
else{
/* c-backend.scm: 1050 gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[559],C_SCHEME_TRUE,lf[560],((C_word*)t0)[2],C_make_character(40));}}

/* k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1052 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[555]);}

/* k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1053 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[554]);}

/* k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6481,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6573,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1062 iota */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6]);}

/* k6601 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1054 for-each */
((C_proc6)C_retrieve_proc(*((C_word*)lf[63]+1)))(6,*((C_word*)lf[63]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a6572 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6573,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6581,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6593,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1059 symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t6,t4);}
else{
/* c-backend.scm: 1059 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[553],t3);}}

/* k6591 in a6572 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1057 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6579 in a6572 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1060 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[552]);}

/* k6583 in k6579 in a6572 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1061 foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k6587 in k6583 in k6579 in a6572 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1056 gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[549],((C_word*)t0)[3],C_make_character(41),t1,lf[550],((C_word*)t0)[2],lf[551]);}

/* k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1063 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[548]);}
else{
t3=t2;
f_6484(2,t3,C_SCHEME_UNDEFINED);}}

/* k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6493,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1065 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[539]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[545]);
if(C_truep(t4)){
/* c-backend.scm: 1076 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1075 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[547],((C_word*)t0)[2]);}}}

/* k6512 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1077 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(40));}

/* k6515 in k6512 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6551,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6555,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1078 make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[546]);}

/* k6553 in k6515 in k6512 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1078 intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k6549 in k6515 in k6512 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k6518 in k6515 in k6512 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[545]);
if(C_truep(t3)){
t4=t2;
f_6523(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1079 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k6521 in k6518 in k6515 in k6512 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1080 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[544]);}

/* k6524 in k6521 in k6518 in k6515 in k6512 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1082 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[540],C_SCHEME_TRUE,lf[541]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1084 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[542]);}
else{
/* c-backend.scm: 1085 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[543]);}}}

/* k6491 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1067 gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[538],C_SCHEME_TRUE);}

/* k6494 in k6491 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1069 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[534],C_SCHEME_TRUE,lf[535]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1071 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[536]);}
else{
/* c-backend.scm: 1072 gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[537]);}}}

/* k6485 in k6482 in k6479 in k6476 in k6473 in k6470 in k6467 in k6464 in k6461 in k6458 in k6455 in k6452 in k6449 in k6446 in k6443 in k6440 in k6437 in k6434 in k6431 in k6428 in k6425 in k6419 in k6416 in k6413 in a6410 in ##compiler#generate-foreign-stubs in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1086 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6387,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6393,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6392 in ##compiler#generate-foreign-callback-stub-prototypes in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6393,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6397,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1017 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6395 in a6392 in ##compiler#generate-foreign-callback-stub-prototypes in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6400,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1018 generate-foreign-callback-header */
((C_proc4)C_retrieve_symbol_proc(lf[532]))(4,*((C_word*)lf[532]+1),t2,lf[533],((C_word*)t0)[2]);}

/* k6398 in k6395 in a6392 in ##compiler#generate-foreign-callback-stub-prototypes in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1019 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6355,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6359,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1002 gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}

/* k6357 in ##compiler#generate-external-variables in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6364,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6363 in k6357 in ##compiler#generate-external-variables in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6364,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(0));
t4=(C_word)C_i_vector_ref(t2,C_fix(1));
t5=(C_word)C_i_vector_ref(t2,C_fix(2));
t6=(C_truep(t5)?lf[530]:lf[531]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6385,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1008 foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t7,t4,t3);}

/* k6383 in a6363 in k6357 in ##compiler#generate-external-variables in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1008 gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6339(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6339,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6345,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 994  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6344 in ##compiler#make-argument-list in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6345,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6353,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 996  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6351 in a6344 in ##compiler#make-argument-list in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 996  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6323,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6329,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 989  list-tabulate */
((C_proc4)C_retrieve_symbol_proc(lf[529]))(4,*((C_word*)lf[529]+1),t1,t2,t4);}

/* a6328 in ##compiler#make-variable-list in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6329,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6337,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 991  number->string */
C_number_to_string(3,0,t3,t2);}

/* k6335 in a6328 in ##compiler#make-variable-list in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 991  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[528],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6234,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6243,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6243(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6243,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6259,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6272,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_6272(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_6272(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_6272(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_6272(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_6272(t10,C_SCHEME_FALSE);}}}}}

/* k6270 in loop in ##compiler#cleanup in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6272,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6275,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_6275(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 980  string-copy */
((C_proc3)C_retrieve_symbol_proc(lf[527]))(3,*((C_word*)lf[527]+1),t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_6259(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k6280 in k6270 in loop in ##compiler#cleanup in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6275(t3,t2);}

/* k6273 in k6270 in loop in ##compiler#cleanup in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_6259(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k6257 in loop in ##compiler#cleanup in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 983  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6243(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6157,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6161,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 945  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[524],C_SCHEME_TRUE,lf[525],t6,lf[526]);}

/* k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6164,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6175,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6175(t6,t2,((C_word*)t0)[2]);}

/* doloop1264 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6175(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6175,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 949  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[516]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 950  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t4);}}

/* k6186 in doloop1264 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6191,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6220,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 951  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[523]))(3,*((C_word*)lf[523]+1),t3,((C_word*)t0)[2]);}

/* k6218 in k6186 in doloop1264 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 951  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[521],((C_word*)t0)[2],C_make_character(58),t1,lf[522]);}

/* k6189 in k6186 in doloop1264 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 954  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[517],C_retrieve(lf[206]),lf[518]);}
else{
/* c-backend.scm: 955  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[519]);}}
else{
/* c-backend.scm: 956  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[520]);}}

/* k6192 in k6189 in k6186 in doloop1264 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6175(t3,((C_word*)t0)[2],t2);}

/* k6162 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6167,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 957  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[515]);}

/* k6165 in k6162 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6170,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 958  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[514]);}

/* k6168 in k6165 in k6162 in k6159 in emit-procedure-table-info in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 959  gen */
((C_proc15)C_retrieve_symbol_proc(lf[1]))(15,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[507],C_SCHEME_TRUE,lf[508],C_SCHEME_TRUE,lf[509],C_SCHEME_TRUE,lf[510],C_SCHEME_TRUE,lf[511],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}

/* ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2493,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2528,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2538,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4111,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4258,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4407,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5365,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5288,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4981,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5146,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4944,a[2]=t2,a[3]=t19,tmp=(C_word)a,a+=4,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4987,a[2]=t18,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5377,a[2]=t4,a[3]=t8,a[4]=t22,a[5]=t20,a[6]=t2,a[7]=t11,tmp=(C_word)a,a+=8,tmp);
t25=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6124,a[2]=t12,a[3]=t13,a[4]=t14,a[5]=t8,a[6]=t15,a[7]=t24,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 928  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[490]))(4,*((C_word*)lf[490]+1),t25,lf[505],lf[506]);}

/* k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6124,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 930  header */
t4=((C_word*)t0)[2];
f_4111(t4,t3);}

/* k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 931  declarations */
t3=((C_word*)t0)[2];
f_4258(t3,t2);}

/* k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 932  generate-external-variables */
((C_proc3)C_retrieve_symbol_proc(lf[503]))(3,*((C_word*)lf[503]+1),t2,C_retrieve(lf[504]));}

/* k6132 in k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 933  generate-foreign-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[501]))(4,*((C_word*)lf[501]+1),t2,C_retrieve(lf[502]),((C_word*)t0)[3]);}

/* k6135 in k6132 in k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 934  prototypes */
t3=((C_word*)t0)[2];
f_4407(t3,t2);}

/* k6138 in k6135 in k6132 in k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 935  generate-foreign-callback-stubs */
((C_proc4)C_retrieve_symbol_proc(lf[500]))(4,*((C_word*)lf[500]+1),t2,C_retrieve(lf[200]),((C_word*)t0)[2]);}

/* k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 936  trampolines */
t3=((C_word*)t0)[2];
f_4658(t3,t2);}

/* k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 937  procedures */
t3=((C_word*)t0)[2];
f_5377(t3,t2);}

/* k6147 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6152,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 938  emit-procedure-table-info */
((C_proc4)C_retrieve_symbol_proc(lf[499]))(4,*((C_word*)lf[499]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6150 in k6147 in k6144 in k6141 in k6138 in k6135 in k6132 in k6129 in k6126 in k6122 in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 509  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[498],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5377(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5377,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5383,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 752  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5390,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 753  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[6]);}

/* k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 754  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[497]))(4,*((C_word*)lf[497]+1),t2,t1,((C_word*)t0)[2]);}

/* k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5396,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 755  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[6]);}

/* k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 756  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[7]);}

/* k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5399,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 757  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t4,((C_word*)t0)[8]);}

/* k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6121,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 758  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5405(t3,C_SCHEME_FALSE);}}

/* k6119 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5405(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5405,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 760  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t4,((C_word*)t0)[13],lf[496]);}

/* k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5414,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 761  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)t0)[13],lf[495]);}

/* k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5417,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 762  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 763  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t2,t3,C_make_character(44));}

/* k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 764  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t2,((C_word*)t0)[12]);}

/* k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 765  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,((C_word*)t0)[13]);}

/* k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5429,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 766  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[14]);}

/* k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 767  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[15]);}

/* k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 768  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[16]);}

/* k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 770  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t2,C_retrieve(lf[206]),lf[493]);}
else{
t3=t2;
f_5438(2,t3,lf[494]);}}

/* k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 772  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[490]))(5,*((C_word*)lf[490]+1),t2,lf[491],lf[492],((C_word*)t0)[14]);}
else{
t3=t2;
f_5441(2,t3,C_SCHEME_UNDEFINED);}}

/* k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 773  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6090,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 774  cleanup */
((C_proc3)C_retrieve_symbol_proc(lf[489]))(3,*((C_word*)lf[489]+1),t3,((C_word*)t0)[2]);}

/* k6088 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 774  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[487],t1,lf[488],C_SCHEME_TRUE);}

/* k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6073,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 783  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[481]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6051,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 776  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[486]);}}

/* k6049 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6054,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[484]:lf[485]);
/* c-backend.scm: 777  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k6052 in k6049 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6057,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 779  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[482]);}
else{
/* c-backend.scm: 780  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[483]);}}

/* k6055 in k6052 in k6049 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 781  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6071 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_6076(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 785  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[480]);}}

/* k6074 in k6071 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 786  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[474],C_SCHEME_TRUE,lf[475],C_SCHEME_TRUE,lf[476],C_SCHEME_TRUE,lf[477],((C_word*)t0)[2],lf[478],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[479],((C_word*)t0)[2]);}

/* k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 791  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_5456(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 792  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[473]);}}

/* k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6023,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_6023(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6023(t4,C_SCHEME_FALSE);}}

/* k6021 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_6023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6023,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 794  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[472]);}
else{
t2=((C_word*)t0)[2];
f_5459(2,t2,C_SCHEME_UNDEFINED);}}

/* k6024 in k6021 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_6026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 795  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_5459(2,t2,C_SCHEME_UNDEFINED);}}

/* k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[15]);}

/* k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 797  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[471]);}
else{
t3=t2;
f_5465(2,t3,C_SCHEME_UNDEFINED);}}

/* k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 798  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[470]);}

/* k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[244]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_5471(t5,t4);}
else{
t4=t2;
f_5471(t4,C_SCHEME_UNDEFINED);}}

/* k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5471,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5474,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 800  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[469]);}

/* k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 802  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[467],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5985,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_5985(t8,t2,((C_word*)t0)[20],t4);}}

/* doloop1017 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5985(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5985,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5995,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 806  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[468],t2,C_make_character(59));}}

/* k5993 in doloop1017 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_5985(t4,((C_word*)t0)[2],t2,t3);}

/* k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5697,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5772,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 808  fold */
((C_proc5)C_retrieve_symbol_proc(lf[434]))(5,*((C_word*)lf[434]+1),t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 842  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[448]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5850,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5928,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_5928(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_5928(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k5926 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5928,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 856  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[458],C_SCHEME_TRUE,lf[459],C_SCHEME_TRUE,lf[460],((C_word*)t0)[3],lf[461]);}
else{
/* c-backend.scm: 859  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_SCHEME_TRUE,lf[462],((C_word*)t0)[3],lf[463]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5940,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5940(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 861  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[466]);}}}

/* k5938 in k5926 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 862  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[465]);}
else{
t3=t2;
f_5943(2,t3,C_SCHEME_UNDEFINED);}}

/* k5941 in k5938 in k5926 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[129]);
t4=t2;
f_5949(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[428]))));}
else{
t3=t2;
f_5949(t3,C_SCHEME_FALSE);}}

/* k5947 in k5941 in k5938 in k5926 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 864  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[464]);}
else{
t2=((C_word*)t0)[2];
f_5850(2,t2,C_SCHEME_UNDEFINED);}}

/* k5848 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5853,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5892,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5892(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
t6=t3;
f_5892(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5892(t4,C_SCHEME_FALSE);}}

/* k5890 in k5848 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 868  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[452],((C_word*)t0)[3],lf[453],((C_word*)t0)[3],lf[454]);}
else{
t4=((C_word*)t0)[2];
f_5853(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 869  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[455],((C_word*)t0)[3],lf[456],((C_word*)t0)[3],lf[457]);}}
else{
t2=((C_word*)t0)[2];
f_5853(2,t2,C_SCHEME_UNDEFINED);}}

/* k5851 in k5848 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5859(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_5859(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_5859(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k5857 in k5851 in k5848 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5859,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 871  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[451]);}
else{
t3=t2;
f_5862(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_5480(2,t2,C_SCHEME_UNDEFINED);}}

/* k5860 in k5857 in k5851 in k5848 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_5868(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_5868(t3,C_SCHEME_FALSE);}}

/* k5866 in k5860 in k5857 in k5851 in k5848 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 873  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[449]);}
else{
/* c-backend.scm: 874  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[450]);}}

/* k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 843  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[447]);}

/* k5787 in k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 844  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[446]);}

/* k5790 in k5787 in k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 846  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 847  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[445]);}}

/* k5793 in k5790 in k5787 in k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 848  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[443],((C_word*)t0)[3],lf[444]);}

/* k5796 in k5793 in k5790 in k5787 in k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5801,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5813,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[129]);
if(C_truep(t4)){
t5=t3;
f_5813(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[442]);
if(C_truep(t5)){
t6=t3;
f_5813(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_5813(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5811 in k5796 in k5793 in k5790 in k5787 in k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 850  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[439],((C_word*)t0)[2],lf[440],((C_word*)t0)[2],lf[441]);}
else{
t2=((C_word*)t0)[3];
f_5801(2,t2,C_SCHEME_UNDEFINED);}}

/* k5799 in k5796 in k5793 in k5790 in k5787 in k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[437]))){
/* c-backend.scm: 851  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[438]);}
else{
t3=t2;
f_5804(2,t3,C_SCHEME_UNDEFINED);}}

/* k5802 in k5799 in k5796 in k5793 in k5790 in k5787 in k5784 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 852  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[435],((C_word*)t0)[2],lf[436]);}

/* a5771 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5772,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5780,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 808  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4987(3,t5,t4,t2);}

/* k5778 in a5771 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5697,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5703,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 810  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[430],C_SCHEME_TRUE,lf[431],C_SCHEME_TRUE,lf[432],((C_word*)t0)[2],lf[433]);}

/* k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[428]))){
/* c-backend.scm: 814  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[429]);}
else{
t3=t2;
f_5706(2,t3,C_SCHEME_UNDEFINED);}}

/* k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[206]))){
t3=t2;
f_5709(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5740,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[421]))){
/* c-backend.scm: 817  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[422],C_retrieve(lf[421]),lf[423]);}
else{
if(C_truep(C_retrieve(lf[424]))){
/* c-backend.scm: 819  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[425],C_retrieve(lf[424]),lf[426],C_SCHEME_TRUE,lf[427]);}
else{
t4=t3;
f_5740(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k5738 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[419]))){
/* c-backend.scm: 822  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[420],C_retrieve(lf[419]),C_make_character(59));}
else{
t3=t2;
f_5743(2,t3,C_SCHEME_UNDEFINED);}}

/* k5741 in k5738 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5746,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[417]))){
/* c-backend.scm: 824  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[418],C_retrieve(lf[417]),C_make_character(59));}
else{
t3=t2;
f_5746(2,t3,C_SCHEME_UNDEFINED);}}

/* k5744 in k5741 in k5738 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[414]))){
/* c-backend.scm: 826  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[415],C_retrieve(lf[414]),lf[416]);}
else{
t2=((C_word*)t0)[2];
f_5709(2,t2,C_SCHEME_UNDEFINED);}}

/* k5707 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 827  gen */
((C_proc16)C_retrieve_symbol_proc(lf[1]))(16,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[407],((C_word*)t0)[3],lf[408],C_SCHEME_TRUE,lf[409],((C_word*)t0)[3],lf[410],C_SCHEME_TRUE,lf[411],C_SCHEME_TRUE,lf[412],C_SCHEME_TRUE,lf[413]);}

/* k5710 in k5707 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 832  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[401],((C_word*)t0)[2],lf[402],C_SCHEME_TRUE,lf[403],C_SCHEME_TRUE,lf[404],((C_word*)t0)[2],lf[405],C_SCHEME_TRUE,lf[406]);}

/* k5713 in k5710 in k5707 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 836  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[399],((C_word*)t0)[2],lf[400]);}

/* k5716 in k5713 in k5710 in k5707 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5718,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_5480(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 838  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[397],((C_word*)t0)[4],lf[398]);}}

/* k5725 in k5716 in k5713 in k5710 in k5707 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 839  literal-frame */
t3=((C_word*)t0)[2];
f_4944(t3,t2);}

/* k5728 in k5725 in k5716 in k5713 in k5710 in k5707 in k5704 in k5701 in k5695 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 840  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[395],((C_word*)t0)[2],lf[396]);}

/* k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5483,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[255],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_5503(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5503(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_5503(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_5503(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_5503(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5503(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5503,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[386]:lf[387]);
/* c-backend.scm: 885  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[388],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5638,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[392]:lf[393]);
/* c-backend.scm: 911  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,t4,lf[394]);}}
else{
t2=((C_word*)t0)[10];
f_5483(2,t2,C_SCHEME_UNDEFINED);}}

/* k5636 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5641,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 913  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[3],lf[390]);}
else{
/* c-backend.scm: 914  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],lf[391],((C_word*)t0)[3]);}}

/* k5639 in k5636 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5644,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 916  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5644(2,t3,C_SCHEME_UNDEFINED);}}

/* k5651 in k5639 in k5636 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5642 in k5639 in k5636 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 918  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[389]);}

/* k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[329]);
if(C_truep(t3)){
/* c-backend.scm: 886  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t4=t2;
f_5512(2,t4,C_SCHEME_UNDEFINED);}}

/* k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 887  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[384],((C_word*)t0)[5],lf[385]);}

/* k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 889  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5518(2,t3,C_SCHEME_UNDEFINED);}}

/* k5617 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 891  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,lf[380],C_SCHEME_TRUE,lf[381],C_SCHEME_TRUE,lf[382],((C_word*)t0)[6],lf[383]);}

/* k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[375]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 895  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[376],((C_word*)t0)[6],lf[377]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[329]);
if(C_truep(t5)){
/* c-backend.scm: 896  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[6],lf[379]);}
else{
t6=t2;
f_5524(2,t6,C_SCHEME_UNDEFINED);}}}

/* k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 897  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[374]);}

/* k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5588,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5592,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 898  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[5],lf[373]);}

/* k5590 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 898  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k5586 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 899  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[371],((C_word*)t0)[5],lf[372]);}

/* k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 901  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[369],((C_word*)t0)[2],lf[370]);}

/* k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 903  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[367],((C_word*)t0)[3],lf[368]);}

/* k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 904  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[366]);}

/* k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5563,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5563(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop1181 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5563(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5563,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5573,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 908  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[365],t2,C_make_character(59));}}

/* k5571 in doloop1181 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5563(t4,((C_word*)t0)[2],t2,t3);}

/* k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5510 in k5507 in k5501 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 909  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[363],((C_word*)t0)[3],lf[364]);}
else{
t3=((C_word*)t0)[2];
f_5483(2,t3,C_SCHEME_UNDEFINED);}}

/* k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 920  lambda-literal-body */
((C_proc3)C_retrieve_symbol_proc(lf[362]))(3,*((C_word*)lf[362]+1),t3,((C_word*)t0)[2]);}

/* k5491 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 919  expression */
t3=((C_word*)t0)[4];
f_2538(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k5484 in k5481 in k5478 in k5475 in k5472 in k5469 in k5466 in k5463 in k5460 in k5457 in k5454 in k5451 in k5448 in k5445 in k5442 in k5439 in k5436 in k5433 in k5430 in k5427 in k5424 in k5421 in k5418 in k5415 in k5412 in k5409 in k5403 in k5400 in k5397 in k5394 in k5391 in k5388 in k5385 in a5382 in procedures in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 925  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4987,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 687  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[361]))(3,*((C_word*)lf[361]+1),t3,t2);}

/* k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[355]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 691  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4987(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5054,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5058,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5062,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 692  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[358]+1)))(3,*((C_word*)lf[358]+1),t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 693  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}}}}}}

/* k5066 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5068,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 694  bad-literal */
f_4981(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 696  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[360]+1)))(3,*((C_word*)lf[360]+1),t2,((C_word*)t0)[4]);}}}}

/* k5084 in k5066 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5093,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 696  words */
((C_proc3)C_retrieve_symbol_proc(lf[359]))(3,*((C_word*)lf[359]+1),t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5115(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 703  bad-literal */
f_4981(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k5084 in k5066 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5115(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5115,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5137,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 702  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4987(3,t8,t6,t7);}}

/* k5135 in loop in k5084 in k5066 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 702  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5115(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5091 in k5084 in k5066 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k5060 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k5056 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 692  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[356]))(5,*((C_word*)lf[356]+1),((C_word*)t0)[2],*((C_word*)lf[357]+1),C_fix(0),t1);}

/* k5052 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k5023 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5029,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 691  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4987(3,t4,t2,t3);}

/* k5027 in k5023 in k4992 in literal-size in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4944,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4950(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop826 in literal-frame in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4950(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4950,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4960,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4979,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 681  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[353]))(4,*((C_word*)lf[353]+1),t6,lf[354],t2);}}

/* k4977 in doloop826 in literal-frame in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 681  gen-lit */
t2=((C_word*)t0)[4];
f_5146(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4958 in doloop826 in literal-frame in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4950(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5146(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5146,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 707  big-fixnum? */
((C_proc3)C_retrieve_symbol_proc(lf[352]))(3,*((C_word*)lf[352]+1),t5,t2);}
else{
t5=t4;
f_5153(t5,C_SCHEME_FALSE);}}

/* k5284 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5153(t2,(C_word)C_i_not(t1));}

/* k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5153(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5153,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 708  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[336],((C_word*)t0)[4],lf[337]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 709  block-variable-literal? */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,((C_word*)t0)[4]);}}

/* k5157 in k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[338]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 711  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[339]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[340]:lf[341]);
/* c-backend.scm: 713  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 715  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[342],t4,lf[343]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5209,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 718  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 723  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[347]);}
else{
t4=(C_word)C_immp(((C_word*)t0)[5]);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_lambdainfop(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_fixnump(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_5242(t8,t6);}
else{
t8=(C_word)C_immp(((C_word*)t0)[5]);
t9=t7;
f_5242(t9,(C_word)C_i_not(t8));}}}}}}}}}

/* k5240 in k5157 in k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5242,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 727  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[3],lf[350]);}
else{
/* c-backend.scm: 730  bad-literal */
f_4981(((C_word*)t0)[6],((C_word*)t0)[4]);}}

/* k5243 in k5240 in k5157 in k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5255,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 728  encode-literal */
((C_proc3)C_retrieve_symbol_proc(lf[349]))(3,*((C_word*)lf[349]+1),t3,((C_word*)t0)[2]);}

/* k5253 in k5243 in k5240 in k5157 in k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 728  gen-string-constant */
t2=((C_word*)t0)[3];
f_5288(t2,((C_word*)t0)[2],t1);}

/* k5246 in k5243 in k5240 in k5157 in k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 729  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[348]);}

/* k5207 in k5157 in k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5209,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5215,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 720  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[346]);}

/* k5213 in k5207 in k5157 in k5151 in gen-lit in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 721  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),((C_word*)t0)[5],lf[344],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[345]);}

/* bad-literal in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4981(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4981,NULL,2,t1,t2);}
/* c-backend.scm: 684  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),t1,lf[335],t2);}

/* gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5288(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5288,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5295,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 734  fx/ */
((C_proc4)C_retrieve_proc(*((C_word*)lf[334]+1)))(4,*((C_word*)lf[334]+1),t4,t3,C_fix(80));}

/* k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5298,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 735  modulo */
((C_proc4)C_retrieve_proc(*((C_word*)lf[333]+1)))(4,*((C_word*)lf[333]+1),t2,((C_word*)t0)[5],C_fix(80));}

/* k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5298,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5303,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5303(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop912 in k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5303(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5303,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5319(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_5319(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5340,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5355,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5359,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 741  string-like-substring */
f_5365(t7,((C_word*)t0)[4],t3,t8);}}

/* k5357 in doloop912 in k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 741  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5353 in doloop912 in k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 741  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5338 in doloop912 in k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5303(t4,((C_word*)t0)[2],t2,t3);}

/* k5317 in doloop912 in k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5319,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5330,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 740  string-like-substring */
f_5365(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5328 in k5317 in doloop912 in k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k5324 in k5317 in doloop912 in k5296 in k5293 in gen-string-constant in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 740  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_5365(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5365,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5372,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 745  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[332]+1)))(3,*((C_word*)lf[332]+1),t6,t5);}

/* k5370 in string-like-substring in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5375,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 746  ##sys#copy-bytes */
((C_proc7)C_retrieve_symbol_proc(lf[331]))(7,*((C_word*)lf[331]+1),t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5373 in k5370 in string-like-substring in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4658,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4661,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4777,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4825,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4825,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4829,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 640  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 641  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t4,((C_word*)t0)[2]);}

/* k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 642  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 643  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 644  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4942,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 645  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4844(t3,C_SCHEME_FALSE);}}

/* k4940 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4844(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4844,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_4847(t5,t4);}
else{
t3=t2;
f_4847(t3,C_SCHEME_UNDEFINED);}}

/* k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4847,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 647  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4859,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 649  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[325],((C_word*)t0)[9],lf[326],C_SCHEME_TRUE,lf[327],((C_word*)t0)[9],lf[328]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4887(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 657  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t3,((C_word*)t0)[2]);}}}}

/* k4929 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4887(2,t3,t2);}
else{
/* c-backend.scm: 657  lambda-literal-external */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4885 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4887,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[244]);
t4=t2;
f_4893(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_4893(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4891 in k4885 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4893,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[329]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 660  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 661  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t3,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 662  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t2,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k4909 in k4891 in k4885 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4905 in k4891 in k4885 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4901 in k4891 in k4885 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4857 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 651  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[323],((C_word*)t0)[3],lf[324]);}

/* k4860 in k4857 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 652  restore */
f_4661(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4863 in k4860 in k4857 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 653  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4866 in k4863 in k4860 in k4857 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 654  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t2,((C_word*)((C_word*)t0)[2])[1],lf[322]);}

/* k4869 in k4866 in k4863 in k4860 in k4857 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4881,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 655  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t3,t1,C_make_character(44));}

/* k4879 in k4869 in k4866 in k4863 in k4860 in k4857 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4872 in k4869 in k4866 in k4863 in k4860 in k4857 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in a4824 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 656  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[321]);}

/* k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4796,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 666  gen */
((C_proc13)C_retrieve_symbol_proc(lf[1]))(13,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[316],t2,lf[317],C_SCHEME_TRUE,lf[318],t2,lf[319],t2,lf[320]);}

/* k4798 in a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4803,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 668  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[313],((C_word*)t0)[3],lf[314],((C_word*)t0)[3],lf[315]);}

/* k4801 in k4798 in a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 669  restore */
f_4661(t2,((C_word*)t0)[3]);}

/* k4804 in k4801 in k4798 in a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 670  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[312],((C_word*)t0)[2],C_make_character(44));}

/* k4807 in k4804 in k4801 in k4798 in a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4819,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4823,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 671  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,((C_word*)t0)[2],lf[311]);}

/* k4821 in k4807 in k4804 in k4801 in k4798 in a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 671  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4817 in k4807 in k4804 in k4801 in k4798 in a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4810 in k4807 in k4804 in k4801 in k4798 in a4795 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 672  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[310]);}

/* k4778 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4794,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 674  emitter */
t4=((C_word*)t0)[3];
f_4697(t4,t3,C_SCHEME_FALSE);}

/* k4792 in k4778 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4781 in k4778 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 675  emitter */
t3=((C_word*)t0)[2];
f_4697(t3,t2,C_SCHEME_TRUE);}

/* k4788 in k4781 in k4778 in k4775 in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4697,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4699 in emitter in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4699,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[305]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[306]);
/* c-backend.scm: 618  gen */
((C_proc14)C_retrieve_symbol_proc(lf[1]))(14,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[307],t2,C_make_character(114),t4,lf[308],C_SCHEME_TRUE,lf[309],t2,C_make_character(114),t5);}

/* k4701 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 620  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[303],((C_word*)t0)[4],lf[304]);}

/* k4704 in k4701 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 621  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[302],((C_word*)t0)[4],C_make_character(114));}

/* k4707 in k4704 in k4701 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 622  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(118));}
else{
t3=t2;
f_4712(2,t3,C_SCHEME_UNDEFINED);}}

/* k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 623  gen */
((C_proc11)C_retrieve_symbol_proc(lf[1]))(11,*((C_word*)lf[1]+1),t2,lf[298],((C_word*)t0)[4],lf[299],C_SCHEME_TRUE,lf[300],C_SCHEME_TRUE,lf[301],((C_word*)t0)[4],C_make_character(59));}

/* k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 626  restore */
f_4661(t2,((C_word*)t0)[4]);}

/* k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 627  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[297]);}

/* k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 629  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[295]);}
else{
/* c-backend.scm: 630  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[296]);}}

/* k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 631  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[294]);}

/* k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4730,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 632  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[293]);}
else{
t3=t2;
f_4730(2,t3,C_SCHEME_UNDEFINED);}}

/* k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 633  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[292]);}

/* k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 634  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[291]);}

/* k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4739,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4746,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4750,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 635  make-argument-list */
((C_proc4)C_retrieve_symbol_proc(lf[289]))(4,*((C_word*)lf[289]+1),t4,t5,lf[290]);}

/* k4748 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 635  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4744 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4737 in k4734 in k4731 in k4728 in k4725 in k4722 in k4719 in k4716 in k4713 in k4710 in k4707 in k4704 in k4701 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 636  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[288]);}

/* restore in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4661(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4661,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4665,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4674,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4674(t8,t3,t4,C_fix(0));}

/* doloop727 in restore in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4674(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4674,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4684,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 613  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,lf[285],t2,lf[286],t3,lf[287]);}}

/* k4682 in doloop727 in restore in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4674(t4,((C_word*)t0)[2],t2,t3);}

/* k4663 in restore in trampolines in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 614  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],C_SCHEME_TRUE,lf[283],((C_word*)t0)[2],lf[284]);}

/* prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4407,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4411,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 542  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE);}

/* k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4435,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4435,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4439,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 545  lambda-literal-argument-count */
((C_proc3)C_retrieve_symbol_proc(lf[282]))(3,*((C_word*)lf[282]+1),t3,t2);}

/* k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 546  lambda-literal-customizable */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t2,((C_word*)t0)[2]);}

/* k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4656,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 547  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4445(t3,C_SCHEME_FALSE);}}

/* k4654 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4445(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4445,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4642,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 548  make-variable-list */
((C_proc4)C_retrieve_symbol_proc(lf[279]))(4,*((C_word*)lf[279]+1),t3,t4,lf[280]);}

/* k4640 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 548  intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1,C_make_character(44));}

/* k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 549  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,((C_word*)t0)[2]);}

/* k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 550  lambda-literal-rest-argument */
((C_proc3)C_retrieve_symbol_proc(lf[278]))(3,*((C_word*)lf[278]+1),t2,((C_word*)t0)[2]);}

/* k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 551  lambda-literal-rest-argument-mode */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,((C_word*)t0)[2]);}

/* k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 552  lambda-literal-direct */
((C_proc3)C_retrieve_symbol_proc(lf[276]))(3,*((C_word*)lf[276]+1),t2,((C_word*)t0)[2]);}

/* k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 553  lambda-literal-allocated */
((C_proc3)C_retrieve_symbol_proc(lf[275]))(3,*((C_word*)lf[275]+1),t2,((C_word*)t0)[2]);}

/* k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4634,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 555  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_4466(t5,C_SCHEME_UNDEFINED);}}

/* k4632 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4466(t3,t2);}

/* k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4466,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 556  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4627,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 561  lambda-literal-callee-signatures */
((C_proc3)C_retrieve_symbol_proc(lf[274]))(3,*((C_word*)lf[274]+1),t4,((C_word*)t0)[2]);}

/* k4625 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4607 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4608,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[271]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4619,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 560  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[272]))(5,*((C_word*)lf[272]+1),t5,*((C_word*)lf[273]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k4617 in a4607 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[255],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4584,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 571  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t4,C_retrieve(lf[206]),lf[262]);}
else{
t5=t4;
f_4584(2,t5,lf[263]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 563  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,lf[269],((C_word*)t0)[5],lf[270],C_SCHEME_TRUE);}}

/* k4557 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 564  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[268]);}

/* k4560 in k4557 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[266]:lf[267]);
/* c-backend.scm: 565  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,t3);}

/* k4563 in k4560 in k4557 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 567  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[264]);}
else{
/* c-backend.scm: 568  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[265]);}}

/* k4566 in k4563 in k4560 in k4557 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 569  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4582 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4587,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 572  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,lf[260],t1,lf[261],C_SCHEME_TRUE);}

/* k4585 in k4582 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[258]))){
/* c-backend.scm: 574  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[259],C_SCHEME_TRUE);}
else{
t3=t2;
f_4590(2,t3,C_SCHEME_UNDEFINED);}}

/* k4588 in k4585 in k4582 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 575  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[257]);}

/* k4591 in k4588 in k4585 in k4582 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 576  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[256],((C_word*)t0)[2]);}

/* k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 577  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(40));}

/* k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4481(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 578  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[254]);}}

/* k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_4531(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4531(t4,C_SCHEME_FALSE);}}

/* k4529 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4531,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 580  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[253]);}
else{
t2=((C_word*)t0)[2];
f_4484(2,t2,C_SCHEME_UNDEFINED);}}

/* k4532 in k4529 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 581  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_4484(2,t2,C_SCHEME_UNDEFINED);}}

/* k4482 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[4]);}

/* k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4487,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 584  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[251]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 592  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(41));}}

/* k4517 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4522,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4522(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 594  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[252]);}}

/* k4520 in k4517 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 595  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k4491 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[244]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 587  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[247],((C_word*)t0)[2],lf[248],C_SCHEME_TRUE,lf[249],((C_word*)t0)[2],lf[250]);}}

/* k4500 in k4491 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[1]),((C_word*)t0)[2]);}

/* k4503 in k4500 in k4491 in k4485 in k4482 in k4479 in k4476 in k4473 in k4470 in k4467 in k4464 in k4461 in k4458 in k4455 in k4452 in k4449 in k4446 in k4443 in k4440 in k4437 in a4434 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 590  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[245],t2,lf[246]);}

/* k4412 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4419,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a4418 in k4412 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4419,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4423,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 599  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[242],t2,lf[243]);}

/* k4421 in a4418 in k4412 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 600  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[240]))(4,*((C_word*)lf[240]+1),t3,((C_word*)t0)[2],lf[241]);}

/* k4431 in k4421 in a4418 in k4412 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[1]),t1);}

/* k4424 in k4421 in a4418 in k4412 in k4409 in prototypes in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 601  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[239]);}

/* declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4258(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4258,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4265,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 513  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[238]);}

/* k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4401,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[208]));}

/* a4400 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4401,3,t0,t1,t2);}
/* c-backend.scm: 516  gen */
((C_proc10)C_retrieve_symbol_proc(lf[1]))(10,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,lf[234],t2,lf[235],C_SCHEME_TRUE,lf[236],t2,lf[237]);}

/* k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_4271(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 520  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[232],((C_word*)t0)[2],lf[233]);}}

/* k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 521  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[231]);}

/* k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4279,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4279(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4279(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4279,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4289,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 525  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t4,t5);}}

/* k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4295,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 527  gen */
((C_proc12)C_retrieve_symbol_proc(lf[1]))(12,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,lf[228],((C_word*)t0)[5],lf[229],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4348,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4348(t6,t2,C_fix(0));}

/* doloop597 in k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4348,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4358,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 534  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,C_make_character(44),t6);}}

/* k4356 in doloop597 in k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4348(t3,((C_word*)t0)[2],t2);}

/* k4296 in k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(7));
t4=(C_word)C_fixnum_and(C_fix(16777208),t3);
t5=(C_word)C_fixnum_difference(t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4321,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4321(t9,t2,t5);}

/* doloop609 in k4296 in k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4321,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4331,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 537  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t4,lf[227]);}}

/* k4329 in doloop609 in k4296 in k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4321(t3,((C_word*)t0)[2],t2);}

/* k4299 in k4296 in k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 538  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[226]);}

/* k4302 in k4299 in k4296 in k4293 in k4287 in doloop581 in k4272 in k4269 in k4266 in k4263 in declarations in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4279(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4111,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4114,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4131,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 479  current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[225]))(2,*((C_word*)lf[225]+1),t4);}

/* k4248 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 479  ##sys#decode-seconds */
((C_proc4)C_retrieve_symbol_proc(lf[224]))(4,*((C_word*)lf[224]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4131,2,t0,t1);}
t2=(C_word)C_i_vector_ref(t1,C_fix(1));
t3=(C_word)C_i_vector_ref(t1,C_fix(2));
t4=(C_word)C_i_vector_ref(t1,C_fix(3));
t5=(C_word)C_i_vector_ref(t1,C_fix(4));
t6=(C_word)C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4208,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 487  pad0 */
f_4114(t9,t10);}

/* k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 487  pad0 */
f_4114(t2,((C_word*)t0)[2]);}

/* k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 487  pad0 */
f_4114(t2,((C_word*)t0)[2]);}

/* k4214 in k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4220,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 487  pad0 */
f_4114(t2,((C_word*)t0)[2]);}

/* k4218 in k4214 in k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4224,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4230,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4238,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 490  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t6,C_SCHEME_TRUE);}

/* k4240 in k4218 in k4214 in k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 490  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),((C_word*)t0)[2],t1,lf[222]);}

/* k4236 in k4218 in k4214 in k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[220]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4229 in k4218 in k4214 in k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4230,3,t0,t1,t2);}
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),t1,lf[218],t2,lf[219]);}

/* k4226 in k4218 in k4214 in k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 488  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[217]);}

/* k4222 in k4218 in k4214 in k4210 in k4206 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 485  gen */
((C_proc21)C_retrieve_symbol_proc(lf[1]))(21,*((C_word*)lf[1]+1),((C_word*)t0)[8],lf[211],((C_word*)t0)[7],lf[212],C_SCHEME_TRUE,lf[213],C_SCHEME_TRUE,lf[214],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[215]);}

/* k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 493  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),t2,C_retrieve(lf[210]));}

/* k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 494  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE);}

/* k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[206]))){
/* c-backend.scm: 495  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[207],C_retrieve(lf[206]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 497  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,lf[209]);}}

/* k4195 in k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 498  gen-list */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),((C_word*)t0)[2],C_retrieve(lf[208]));}

/* k4156 in k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 499  gen */
((C_proc9)C_retrieve_symbol_proc(lf[1]))(9,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[202],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[203],C_retrieve(lf[204]),lf[205]);}

/* k4159 in k4156 in k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[198]))){
/* c-backend.scm: 501  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t2,C_retrieve(lf[200]));}
else{
t3=t2;
f_4164(2,t3,C_SCHEME_UNDEFINED);}}

/* k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4167,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[201])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4179,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 503  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_4167(2,t3,C_SCHEME_UNDEFINED);}}

/* k4177 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4184,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[201]));}

/* a4183 in k4177 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4184,3,t0,t1,t2);}
/* c-backend.scm: 504  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,t2);}

/* k4165 in k4162 in k4159 in k4156 in k4153 in k4150 in k4147 in k4129 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[198]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 506  generate-foreign-callback-stub-prototypes */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),((C_word*)t0)[2],C_retrieve(lf[200]));}}

/* pad0 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4114(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4114,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4128,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 477  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4126 in pad0 in header in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 477  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[197],t1);}

/* expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_2538(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2538,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4079,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 472  expr */
t11=((C_word*)t6)[1];
f_2541(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_4079(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4079,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4085,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 466  pair-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[196]))(4,*((C_word*)lf[196]+1),t1,t4,t2);}

/* a4084 in expr-args in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4085,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_4089(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 468  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}}

/* k4087 in a4084 in expr-args in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 469  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2541(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_2541(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2541,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[16]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[17]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[18]:lf[19]);
/* c-backend.scm: 125  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 126  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[21],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t14)){
/* c-backend.scm: 127  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[23]);}
else{
t15=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 128  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[25],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[26]);
if(C_truep(t16)){
/* c-backend.scm: 129  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[27]);}
else{
/* c-backend.scm: 130  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t1,lf[28]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[29]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 135  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[30],t13,lf[31]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 136  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[32],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[33]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2665,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 139  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t13,C_SCHEME_TRUE,lf[36]);}
else{
t13=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 148  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,lf[38],t14);}
else{
t14=(C_word)C_eqp(t9,lf[39]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[6],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_2723(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[40]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2774,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 160  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t16,lf[42]);}
else{
t16=(C_word)C_eqp(t9,lf[43]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2801,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 165  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t17,lf[45]);}
else{
t17=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2820,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 170  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t18,lf[47]);}
else{
t18=(C_word)C_eqp(t9,lf[48]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2853,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 177  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t19,lf[51]);}
else{
t19=(C_word)C_eqp(t9,lf[52]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 184  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t20,lf[54]);}
else{
t20=(C_word)C_eqp(t9,lf[55]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2919,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 191  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t21,lf[57]);}
else{
t21=(C_word)C_eqp(t9,lf[58]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2951,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 199  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t23,lf[65],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[66]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2986,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 209  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t23,lf[68]);}
else{
t23=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 213  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[70]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3018,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 216  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[71]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 225  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[72],t26,lf[73]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3060,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3064,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 226  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 227  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[78],t26,lf[79]);}
else{
/* c-backend.scm: 228  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[80],t26,lf[81]);}}}
else{
t26=(C_word)C_eqp(t9,lf[82]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(C_word)C_i_caddr(t7);
t30=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3095,a[2]=t29,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t28)){
/* c-backend.scm: 235  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t30,lf[85],t27,lf[86]);}
else{
/* c-backend.scm: 236  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t30,lf[87],t27,lf[88]);}}
else{
t27=(C_word)C_eqp(t9,lf[89]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
t29=(C_word)C_i_cadr(t7);
t30=(C_word)C_i_caddr(t7);
if(C_truep(t29)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3143,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3157,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=t32,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 247  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t33,t30);}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3164,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3178,a[2]=t28,a[3]=t31,tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3182,a[2]=t32,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 252  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t33,t30);}}
else{
t28=(C_word)C_eqp(t9,lf[96]);
if(C_truep(t28)){
/* c-backend.scm: 256  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t1,lf[97]);}
else{
t29=(C_word)C_eqp(t9,lf[98]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3215,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t36,a[6]=t32,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],a[9]=t31,a[10]=t33,a[11]=t3,a[12]=t30,a[13]=((C_word*)t0)[4],a[14]=t1,a[15]=t5,a[16]=t7,tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 265  source-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3639,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[6],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 349  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[151]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3724,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3728,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 377  find-lambda */
t41=((C_word*)t0)[2];
f_2496(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3747,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 394  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t35,C_SCHEME_TRUE,lf[155],t36,lf[156],t34,lf[157]);}
else{
t33=(C_word)C_eqp(t9,lf[158]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3766,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 399  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t34,C_SCHEME_TRUE,lf[160]);}
else{
t34=(C_word)C_eqp(t9,lf[161]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3785,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 404  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t35,lf[162],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[163]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3804,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 409  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t36,lf[164],t37,lf[165],t38);}
else{
t36=(C_word)C_eqp(t9,lf[166]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3840,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 417  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t37,t38,lf[168]);}
else{
t37=(C_word)C_eqp(t9,lf[169]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3860,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3878,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 421  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t41,t38,lf[174]);}
else{
t38=(C_word)C_eqp(t9,lf[175]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3894,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 427  foreign-result-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[167]))(4,*((C_word*)lf[167]+1),t41,t39,lf[180]);}
else{
t39=(C_word)C_eqp(t9,lf[181]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3924,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3952,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 433  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t42,t40,lf[186]);}
else{
t40=(C_word)C_eqp(t9,lf[187]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3961,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 440  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t41,C_SCHEME_TRUE,lf[191]);}
else{
t41=(C_word)C_eqp(t9,lf[192]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4044,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 455  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t42,lf[194]);}
else{
/* c-backend.scm: 463  bomb */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t1,lf[195]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4042 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 456  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k4045 in k4042 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 457  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[193]);}

/* k4048 in k4045 in k4042 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 458  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k4051 in k4048 in k4045 in k4042 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 459  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4054 in k4051 in k4048 in k4045 in k4042 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 460  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k4057 in k4054 in k4051 in k4048 in k4045 in k4042 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 461  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 441  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2541(t4,t2,t3,((C_word*)t0)[3]);}

/* k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 442  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[190]);}

/* k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3980,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3980(t7,((C_word*)t0)[2],t2,t3);}

/* doloop486 in k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_3980(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3980,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 446  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[188]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 449  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,lf[189]);}}

/* k4001 in doloop486 in k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 450  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k4004 in k4001 in doloop486 in k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 451  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(58));}

/* k4007 in k4004 in k4001 in doloop486 in k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 452  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k4010 in k4007 in k4004 in k4001 in doloop486 in k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_4012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3980(t4,((C_word*)t0)[2],t2,t3);}

/* k3988 in doloop486 in k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 447  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3991 in k3988 in doloop486 in k3965 in k3962 in k3959 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 448  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* k3950 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 433  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[184],t1,lf[185]);}

/* k3922 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 434  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2541(t4,t2,t3,((C_word*)t0)[3]);}

/* k3925 in k3922 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3944,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 435  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t3,((C_word*)t0)[2]);}

/* k3942 in k3925 in k3922 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 435  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[183],t1);}

/* k3928 in k3925 in k3922 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 436  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3931 in k3928 in k3925 in k3922 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 437  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[182]);}

/* k3906 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3912,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 427  foreign-type-declaration */
((C_proc4)C_retrieve_symbol_proc(lf[173]))(4,*((C_word*)lf[173]+1),t2,((C_word*)t0)[2],lf[179]);}

/* k3910 in k3906 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 427  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[177],t1,lf[178]);}

/* k3892 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3895 in k3892 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 429  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[176]);}

/* k3876 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3882,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 421  foreign-argument-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[172]))(3,*((C_word*)lf[172]+1),t2,((C_word*)t0)[2]);}

/* k3880 in k3876 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 421  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[171],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3858 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3863,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 422  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3861 in k3858 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 423  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[170]);}

/* k3838 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 417  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3802 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3807,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 412  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t3,C_make_character(44));}
else{
t3=t2;
f_3807(2,t3,C_SCHEME_UNDEFINED);}}

/* k3814 in k3802 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 413  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4079(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3805 in k3802 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 414  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3783 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 405  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3786 in k3783 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 406  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3764 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 400  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3767 in k3764 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 401  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[159]);}

/* k3745 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3750,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 395  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3748 in k3745 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 396  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[154]);}

/* k3726 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 377  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3722 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3724,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 379  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],C_make_character(40));}

/* k3670 in k3722 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3705,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 381  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t3,lf[152],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3675(2,t3,C_SCHEME_UNDEFINED);}}

/* k3703 in k3670 in k3722 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 382  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_3675(2,t4,C_SCHEME_UNDEFINED);}}

/* k3673 in k3670 in k3722 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3678(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3693,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 384  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3691 in k3673 in k3670 in k3722 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 385  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3678(2,t2,C_SCHEME_UNDEFINED);}}

/* k3676 in k3673 in k3670 in k3722 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 386  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4079(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3681(2,t3,C_SCHEME_UNDEFINED);}}

/* k3679 in k3676 in k3673 in k3670 in k3722 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 387  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3639,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3582,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 351  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3623,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 364  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3621 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3626(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 365  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[150]);}}

/* k3624 in k3621 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3629,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 366  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3627 in k3624 in k3621 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 367  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 352  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3606,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 353  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3605 in k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3606,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3610,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 355  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3608 in a3605 in k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 356  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2541(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3611 in k3608 in a3605 in k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 357  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3586 in k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3596,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 361  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3602 in k3586 in k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 359  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3595 in k3586 in k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3596,4,t0,t1,t2,t3);}
/* c-backend.scm: 360  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[149],t2,C_make_character(59));}

/* k3589 in k3586 in k3583 in k3580 in k3637 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 362  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[148]);}

/* k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[16]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_3218(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[16]):C_SCHEME_FALSE));}
else{
t3=t2;
f_3218(t3,C_SCHEME_FALSE);}}

/* k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_3218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[16]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 268  find-lambda */
t6=((C_word*)t0)[2];
f_2496(t6,t5,t1);}
else{
t4=t3;
f_3224(t4,C_SCHEME_FALSE);}}

/* k3530 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 268  lambda-literal-closure-size */
((C_proc3)C_retrieve_symbol_proc(lf[145]))(3,*((C_word*)lf[145]+1),((C_word*)t0)[2],t1);}

/* k3526 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3224(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_3224(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3224,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[17]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_retrieve(lf[137]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2526,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 112  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3521,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 273  uncommentify */
f_2528(t4,((C_word*)t0)[3]);}}
else{
t4=t3;
f_3230(2,t4,C_SCHEME_UNDEFINED);}}

/* k3519 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 273  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[143],t1,lf[144]);}

/* k2524 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 112  string-translate */
((C_proc5)C_retrieve_symbol_proc(lf[140]))(5,*((C_word*)lf[140]+1),((C_word*)t0)[2],t1,lf[141],lf[142]);}

/* k3512 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 272  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[138],t1,lf[139]);}

/* k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[37],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 276  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[100]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 280  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3357,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t6=(C_word)C_eqp(lf[71],t5);
if(C_truep(t6)){
t7=C_retrieve(lf[129]);
if(C_truep(t7)){
t8=t4;
f_3357(t8,C_SCHEME_FALSE);}
else{
t8=C_retrieve(lf[134]);
if(C_truep(t8)){
t9=t4;
f_3357(t9,C_SCHEME_FALSE);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=t4;
f_3357(t10,(C_word)C_i_not(t9));}}}
else{
t7=t4;
f_3357(t7,C_SCHEME_FALSE);}}}}

/* k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_3357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3357,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_caddr(t2);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3372,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 314  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t8,C_SCHEME_TRUE,lf[124],((C_word*)t0)[5],lf[125]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 333  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}

/* k3439 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 334  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2541(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3442 in k3439 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 335  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,C_make_character(59),C_SCHEME_TRUE,lf[135],((C_word*)t0)[4],lf[136]);}

/* k3445 in k3442 in k3439 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[129]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3462(t5,t3);}
else{
t5=C_retrieve(lf[134]);
t6=t4;
f_3462(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k3460 in k3445 in k3442 in k3439 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_3462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 338  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[130],((C_word*)t0)[2],lf[131]);}
else{
/* c-backend.scm: 339  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[132],((C_word*)t0)[2],lf[133]);}}

/* k3448 in k3445 in k3442 in k3439 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 340  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[127],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],C_make_character(44));}

/* k3451 in k3448 in k3445 in k3442 in k3439 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 341  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3454 in k3451 in k3448 in k3445 in k3442 in k3439 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 342  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[126]);}

/* k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3388,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3413,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 316  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3420,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3427,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 323  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3438,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 327  number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[2]);}}}

/* k3436 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 327  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[122],t1,lf[123]);}

/* k3429 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* c-backend.scm: 328  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[120],((C_word*)t0)[2],lf[121]);}

/* k3425 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 323  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[118],t1,lf[119]);}

/* k3418 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
/* c-backend.scm: 324  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[116],((C_word*)((C_word*)t0)[3])[1],lf[117]);}

/* k3411 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 316  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[114],t1,lf[115]);}

/* k3386 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3388,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 318  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[109],((C_word*)((C_word*)t0)[5])[1],lf[110]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadddr(((C_word*)t0)[2]);
/* c-backend.scm: 320  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,t5);}}

/* k3403 in k3386 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 320  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3399 in k3386 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 319  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[111],((C_word*)((C_word*)t0)[2])[1],lf[112],t1,C_make_character(41));}

/* k3373 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 329  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),t2,lf[108],((C_word*)t0)[3],C_make_character(44),((C_word*)((C_word*)t0)[2])[1],C_make_character(44));}

/* k3376 in k3373 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 330  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3379 in k3376 in k3373 in k3370 in k3355 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 331  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[107]);}

/* k3349 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 281  lambda-literal-looping */
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_3261(2,t3,C_SCHEME_FALSE);}}

/* k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3264,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 282  lambda-literal-temporaries */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_3311(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 297  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3333 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 298  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2541(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3336 in k3333 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 299  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3309 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 300  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3312 in k3309 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3317(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 301  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],C_make_character(44));}}

/* k3315 in k3312 in k3309 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3320,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3320(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 302  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k3318 in k3315 in k3312 in k3309 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 303  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3321 in k3318 in k3315 in k3312 in k3309 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 304  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[105]);}

/* k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 283  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3270,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3294,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 284  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),t2,t3,((C_word*)t0)[2],t1);}

/* a3293 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3294,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 286  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3296 in a3293 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 287  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2541(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3299 in k3296 in a3293 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 288  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3268 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3273,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3284,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 292  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3290 in k3268 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 290  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3283 in k3268 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3284,4,t0,t1,t2,t3);}
/* c-backend.scm: 291  gen */
((C_proc8)C_retrieve_symbol_proc(lf[1]))(8,*((C_word*)lf[1]+1),t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[103],t2,C_make_character(59));}

/* k3271 in k3268 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3276(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 293  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t2,C_SCHEME_TRUE,lf[102],((C_word*)t0)[2],C_make_character(59));}}

/* k3274 in k3271 in k3268 in k3265 in k3262 in k3259 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 294  gen */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_SCHEME_TRUE,lf[101]);}

/* k3240 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 277  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4079(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3243 in k3240 in k3228 in k3222 in k3216 in k3213 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 278  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[99]);}

/* k3180 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 252  uncommentify */
f_2528(((C_word*)t0)[2],t1);}

/* k3176 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 251  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95]);}

/* k3162 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 253  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3165 in k3162 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 254  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3159 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  uncommentify */
f_2528(((C_word*)t0)[2],t1);}

/* k3155 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 246  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92]);}

/* k3141 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3146,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 248  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3144 in k3141 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 249  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(59));}

/* k3093 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3098,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3116,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 237  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t4,((C_word*)t0)[2]);}

/* k3114 in k3093 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 237  uncommentify */
f_2528(((C_word*)t0)[2],t1);}

/* k3110 in k3093 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 237  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[83],t1,lf[84]);}

/* k3096 in k3093 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 238  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k3099 in k3096 in k3093 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 239  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k3062 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 226  c-ify-string */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k3058 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 226  gen */
((C_proc7)C_retrieve_symbol_proc(lf[1]))(7,*((C_word*)lf[1]+1),((C_word*)t0)[3],lf[74],((C_word*)t0)[2],lf[75],t1,C_make_character(41));}

/* k3016 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 217  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2541(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2984 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 210  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2987 in k2984 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 211  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[67]);}

/* k2949 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 205  iota */
((C_proc5)C_retrieve_symbol_proc(lf[64]))(5,*((C_word*)lf[64]+1),t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2975 in k2949 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 200  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[63]+1)))(5,*((C_word*)lf[63]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2962 in k2949 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2963,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2967,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 202  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t4,lf[61],t3,lf[62]);}

/* k2965 in a2962 in k2949 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 203  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2541(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2968 in k2965 in a2962 in k2949 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 204  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(44));}

/* k2952 in k2949 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 206  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[59],t2,lf[60]);}

/* k2917 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 192  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2920 in k2917 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 193  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[56]);}

/* k2923 in k2920 in k2917 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2928,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 194  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2926 in k2923 in k2920 in k2917 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 195  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2888 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 185  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2891 in k2888 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 186  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[53]);}

/* k2894 in k2891 in k2888 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 187  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2897 in k2894 in k2891 in k2888 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 188  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2851 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 178  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2541(t4,t2,t3,((C_word*)t0)[3]);}

/* k2854 in k2851 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 179  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,lf[49],t4,lf[50]);}

/* k2857 in k2854 in k2851 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2862,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 180  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2860 in k2857 in k2854 in k2851 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 181  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2818 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 171  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2541(t4,t2,t3,((C_word*)t0)[3]);}

/* k2821 in k2818 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 172  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(44),t3,C_make_character(44));}

/* k2824 in k2821 in k2818 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 173  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2827 in k2824 in k2821 in k2818 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 174  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(41));}

/* k2799 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 166  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2802 in k2799 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 167  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[44]);}

/* k2772 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 161  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2775 in k2772 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 162  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[41],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2723,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 153  gen */
((C_proc6)C_retrieve_symbol_proc(lf[1]))(6,*((C_word*)lf[1]+1),t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 157  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2541(t7,t1,t6,t3);}}

/* k2731 in loop in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 154  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2541(t4,t2,t3,((C_word*)t0)[6]);}

/* k2734 in k2731 in loop in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 155  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,C_make_character(59));}

/* k2737 in k2734 in k2731 in loop in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 156  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2723(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2663 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 140  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2666 in k2663 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 141  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),t2,lf[35]);}

/* k2669 in k2666 in k2663 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 142  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2672 in k2669 in k2666 in k2663 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 143  gen */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t2,C_make_character(125),C_SCHEME_TRUE,lf[34]);}

/* k2675 in k2672 in k2669 in k2666 in k2663 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 144  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2541(t4,t2,t3,((C_word*)t0)[2]);}

/* k2678 in k2675 in k2672 in k2669 in k2666 in k2663 in expr in expression in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 145  gen */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],C_make_character(125));}

/* uncommentify in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_2528(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2528,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2536,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 113  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,t2);}

/* k2534 in uncommentify in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 113  string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,lf[14]);}

/* find-lambda in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_fcall f_2496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2496,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2500,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2508,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 109  find */
((C_proc4)C_retrieve_symbol_proc(lf[12]))(4,*((C_word*)lf[12]+1),t3,t4,((C_word*)t0)[2]);}

/* a2507 in find-lambda in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2508,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 109  lambda-literal-id */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k2514 in a2507 in find-lambda in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k2498 in find-lambda in ##compiler#generate-code in k2489 in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 110  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2473,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2479,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 91   intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t4,t2,C_make_character(32));}

/* k2485 in ##compiler#gen-list in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2478 in ##compiler#gen-list in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2479,3,t0,t1,t2);}
/* c-backend.scm: 90   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}

/* ##compiler#gen in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_2452r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2452r(t0,t1,t2);}}

static void C_ccall f_2452r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2458,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a2457 in ##compiler#gen in k2447 in k2444 in k2441 in k2438 in k2435 in k2432 */
static void C_ccall f_2458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2458,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 84   newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t1,C_retrieve(lf[0]));}
else{
/* c-backend.scm: 85   display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t1,t2,C_retrieve(lf[0]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[665] = {
{"toplevel:c_backend_scm",(void*)C_backend_toplevel},
{"f_2434:c_backend_scm",(void*)f_2434},
{"f_2437:c_backend_scm",(void*)f_2437},
{"f_2440:c_backend_scm",(void*)f_2440},
{"f_2443:c_backend_scm",(void*)f_2443},
{"f_2446:c_backend_scm",(void*)f_2446},
{"f_2449:c_backend_scm",(void*)f_2449},
{"f_9166:c_backend_scm",(void*)f_9166},
{"f_9170:c_backend_scm",(void*)f_9170},
{"f_9162:c_backend_scm",(void*)f_9162},
{"f_2491:c_backend_scm",(void*)f_2491},
{"f_8862:c_backend_scm",(void*)f_8862},
{"f_9138:c_backend_scm",(void*)f_9138},
{"f_9136:c_backend_scm",(void*)f_9136},
{"f_9124:c_backend_scm",(void*)f_9124},
{"f_9094:c_backend_scm",(void*)f_9094},
{"f_9055:c_backend_scm",(void*)f_9055},
{"f_9042:c_backend_scm",(void*)f_9042},
{"f_9038:c_backend_scm",(void*)f_9038},
{"f_8924:c_backend_scm",(void*)f_8924},
{"f_8871:c_backend_scm",(void*)f_8871},
{"f_8464:c_backend_scm",(void*)f_8464},
{"f_8551:c_backend_scm",(void*)f_8551},
{"f_8632:c_backend_scm",(void*)f_8632},
{"f_8654:c_backend_scm",(void*)f_8654},
{"f_8466:c_backend_scm",(void*)f_8466},
{"f_7979:c_backend_scm",(void*)f_7979},
{"f_8009:c_backend_scm",(void*)f_8009},
{"f_8036:c_backend_scm",(void*)f_8036},
{"f_8231:c_backend_scm",(void*)f_8231},
{"f_8240:c_backend_scm",(void*)f_8240},
{"f_8249:c_backend_scm",(void*)f_8249},
{"f_8271:c_backend_scm",(void*)f_8271},
{"f_8348:c_backend_scm",(void*)f_8348},
{"f_7981:c_backend_scm",(void*)f_7981},
{"f_7134:c_backend_scm",(void*)f_7134},
{"f_7211:c_backend_scm",(void*)f_7211},
{"f_7313:c_backend_scm",(void*)f_7313},
{"f_7346:c_backend_scm",(void*)f_7346},
{"f_7442:c_backend_scm",(void*)f_7442},
{"f_7454:c_backend_scm",(void*)f_7454},
{"f_7469:c_backend_scm",(void*)f_7469},
{"f_7509:c_backend_scm",(void*)f_7509},
{"f_7526:c_backend_scm",(void*)f_7526},
{"f_7543:c_backend_scm",(void*)f_7543},
{"f_7582:c_backend_scm",(void*)f_7582},
{"f_7599:c_backend_scm",(void*)f_7599},
{"f_7616:c_backend_scm",(void*)f_7616},
{"f_7633:c_backend_scm",(void*)f_7633},
{"f_7650:c_backend_scm",(void*)f_7650},
{"f_7667:c_backend_scm",(void*)f_7667},
{"f_7684:c_backend_scm",(void*)f_7684},
{"f_7696:c_backend_scm",(void*)f_7696},
{"f_7703:c_backend_scm",(void*)f_7703},
{"f_7713:c_backend_scm",(void*)f_7713},
{"f_7711:c_backend_scm",(void*)f_7711},
{"f_7707:c_backend_scm",(void*)f_7707},
{"f_7674:c_backend_scm",(void*)f_7674},
{"f_7657:c_backend_scm",(void*)f_7657},
{"f_7640:c_backend_scm",(void*)f_7640},
{"f_7623:c_backend_scm",(void*)f_7623},
{"f_7606:c_backend_scm",(void*)f_7606},
{"f_7589:c_backend_scm",(void*)f_7589},
{"f_7554:c_backend_scm",(void*)f_7554},
{"f_7564:c_backend_scm",(void*)f_7564},
{"f_7562:c_backend_scm",(void*)f_7562},
{"f_7558:c_backend_scm",(void*)f_7558},
{"f_7550:c_backend_scm",(void*)f_7550},
{"f_7537:c_backend_scm",(void*)f_7537},
{"f_7520:c_backend_scm",(void*)f_7520},
{"f_7141:c_backend_scm",(void*)f_7141},
{"f_7136:c_backend_scm",(void*)f_7136},
{"f_7069:c_backend_scm",(void*)f_7069},
{"f_7073:c_backend_scm",(void*)f_7073},
{"f_7076:c_backend_scm",(void*)f_7076},
{"f_7079:c_backend_scm",(void*)f_7079},
{"f_7082:c_backend_scm",(void*)f_7082},
{"f_7088:c_backend_scm",(void*)f_7088},
{"f_7132:c_backend_scm",(void*)f_7132},
{"f_7091:c_backend_scm",(void*)f_7091},
{"f_7099:c_backend_scm",(void*)f_7099},
{"f_7120:c_backend_scm",(void*)f_7120},
{"f_7103:c_backend_scm",(void*)f_7103},
{"f_7094:c_backend_scm",(void*)f_7094},
{"f_6638:c_backend_scm",(void*)f_6638},
{"f_6644:c_backend_scm",(void*)f_6644},
{"f_6648:c_backend_scm",(void*)f_6648},
{"f_6651:c_backend_scm",(void*)f_6651},
{"f_6654:c_backend_scm",(void*)f_6654},
{"f_6657:c_backend_scm",(void*)f_6657},
{"f_6663:c_backend_scm",(void*)f_6663},
{"f_7004:c_backend_scm",(void*)f_7004},
{"f_7007:c_backend_scm",(void*)f_7007},
{"f_7067:c_backend_scm",(void*)f_7067},
{"f_7010:c_backend_scm",(void*)f_7010},
{"f_7013:c_backend_scm",(void*)f_7013},
{"f_7016:c_backend_scm",(void*)f_7016},
{"f_7019:c_backend_scm",(void*)f_7019},
{"f_7052:c_backend_scm",(void*)f_7052},
{"f_7060:c_backend_scm",(void*)f_7060},
{"f_7022:c_backend_scm",(void*)f_7022},
{"f_7050:c_backend_scm",(void*)f_7050},
{"f_7025:c_backend_scm",(void*)f_7025},
{"f_7028:c_backend_scm",(void*)f_7028},
{"f_7031:c_backend_scm",(void*)f_7031},
{"f_6665:c_backend_scm",(void*)f_6665},
{"f_6675:c_backend_scm",(void*)f_6675},
{"f_6684:c_backend_scm",(void*)f_6684},
{"f_6696:c_backend_scm",(void*)f_6696},
{"f_6708:c_backend_scm",(void*)f_6708},
{"f_6714:c_backend_scm",(void*)f_6714},
{"f_6748:c_backend_scm",(void*)f_6748},
{"f_6405:c_backend_scm",(void*)f_6405},
{"f_6411:c_backend_scm",(void*)f_6411},
{"f_6415:c_backend_scm",(void*)f_6415},
{"f_6418:c_backend_scm",(void*)f_6418},
{"f_6421:c_backend_scm",(void*)f_6421},
{"f_6636:c_backend_scm",(void*)f_6636},
{"f_6427:c_backend_scm",(void*)f_6427},
{"f_6430:c_backend_scm",(void*)f_6430},
{"f_6433:c_backend_scm",(void*)f_6433},
{"f_6436:c_backend_scm",(void*)f_6436},
{"f_6439:c_backend_scm",(void*)f_6439},
{"f_6442:c_backend_scm",(void*)f_6442},
{"f_6445:c_backend_scm",(void*)f_6445},
{"f_6448:c_backend_scm",(void*)f_6448},
{"f_6451:c_backend_scm",(void*)f_6451},
{"f_6454:c_backend_scm",(void*)f_6454},
{"f_6625:c_backend_scm",(void*)f_6625},
{"f_6457:c_backend_scm",(void*)f_6457},
{"f_6460:c_backend_scm",(void*)f_6460},
{"f_6463:c_backend_scm",(void*)f_6463},
{"f_6466:c_backend_scm",(void*)f_6466},
{"f_6469:c_backend_scm",(void*)f_6469},
{"f_6472:c_backend_scm",(void*)f_6472},
{"f_6475:c_backend_scm",(void*)f_6475},
{"f_6478:c_backend_scm",(void*)f_6478},
{"f_6603:c_backend_scm",(void*)f_6603},
{"f_6573:c_backend_scm",(void*)f_6573},
{"f_6593:c_backend_scm",(void*)f_6593},
{"f_6581:c_backend_scm",(void*)f_6581},
{"f_6585:c_backend_scm",(void*)f_6585},
{"f_6589:c_backend_scm",(void*)f_6589},
{"f_6481:c_backend_scm",(void*)f_6481},
{"f_6484:c_backend_scm",(void*)f_6484},
{"f_6514:c_backend_scm",(void*)f_6514},
{"f_6517:c_backend_scm",(void*)f_6517},
{"f_6555:c_backend_scm",(void*)f_6555},
{"f_6551:c_backend_scm",(void*)f_6551},
{"f_6520:c_backend_scm",(void*)f_6520},
{"f_6523:c_backend_scm",(void*)f_6523},
{"f_6526:c_backend_scm",(void*)f_6526},
{"f_6493:c_backend_scm",(void*)f_6493},
{"f_6496:c_backend_scm",(void*)f_6496},
{"f_6487:c_backend_scm",(void*)f_6487},
{"f_6387:c_backend_scm",(void*)f_6387},
{"f_6393:c_backend_scm",(void*)f_6393},
{"f_6397:c_backend_scm",(void*)f_6397},
{"f_6400:c_backend_scm",(void*)f_6400},
{"f_6355:c_backend_scm",(void*)f_6355},
{"f_6359:c_backend_scm",(void*)f_6359},
{"f_6364:c_backend_scm",(void*)f_6364},
{"f_6385:c_backend_scm",(void*)f_6385},
{"f_6339:c_backend_scm",(void*)f_6339},
{"f_6345:c_backend_scm",(void*)f_6345},
{"f_6353:c_backend_scm",(void*)f_6353},
{"f_6323:c_backend_scm",(void*)f_6323},
{"f_6329:c_backend_scm",(void*)f_6329},
{"f_6337:c_backend_scm",(void*)f_6337},
{"f_6234:c_backend_scm",(void*)f_6234},
{"f_6243:c_backend_scm",(void*)f_6243},
{"f_6272:c_backend_scm",(void*)f_6272},
{"f_6282:c_backend_scm",(void*)f_6282},
{"f_6275:c_backend_scm",(void*)f_6275},
{"f_6259:c_backend_scm",(void*)f_6259},
{"f_6157:c_backend_scm",(void*)f_6157},
{"f_6161:c_backend_scm",(void*)f_6161},
{"f_6175:c_backend_scm",(void*)f_6175},
{"f_6188:c_backend_scm",(void*)f_6188},
{"f_6220:c_backend_scm",(void*)f_6220},
{"f_6191:c_backend_scm",(void*)f_6191},
{"f_6194:c_backend_scm",(void*)f_6194},
{"f_6164:c_backend_scm",(void*)f_6164},
{"f_6167:c_backend_scm",(void*)f_6167},
{"f_6170:c_backend_scm",(void*)f_6170},
{"f_2493:c_backend_scm",(void*)f_2493},
{"f_6124:c_backend_scm",(void*)f_6124},
{"f_6128:c_backend_scm",(void*)f_6128},
{"f_6131:c_backend_scm",(void*)f_6131},
{"f_6134:c_backend_scm",(void*)f_6134},
{"f_6137:c_backend_scm",(void*)f_6137},
{"f_6140:c_backend_scm",(void*)f_6140},
{"f_6143:c_backend_scm",(void*)f_6143},
{"f_6146:c_backend_scm",(void*)f_6146},
{"f_6149:c_backend_scm",(void*)f_6149},
{"f_6152:c_backend_scm",(void*)f_6152},
{"f_5377:c_backend_scm",(void*)f_5377},
{"f_5383:c_backend_scm",(void*)f_5383},
{"f_5387:c_backend_scm",(void*)f_5387},
{"f_5390:c_backend_scm",(void*)f_5390},
{"f_5393:c_backend_scm",(void*)f_5393},
{"f_5396:c_backend_scm",(void*)f_5396},
{"f_5399:c_backend_scm",(void*)f_5399},
{"f_5402:c_backend_scm",(void*)f_5402},
{"f_6121:c_backend_scm",(void*)f_6121},
{"f_5405:c_backend_scm",(void*)f_5405},
{"f_5411:c_backend_scm",(void*)f_5411},
{"f_5414:c_backend_scm",(void*)f_5414},
{"f_5417:c_backend_scm",(void*)f_5417},
{"f_5420:c_backend_scm",(void*)f_5420},
{"f_5423:c_backend_scm",(void*)f_5423},
{"f_5426:c_backend_scm",(void*)f_5426},
{"f_5429:c_backend_scm",(void*)f_5429},
{"f_5432:c_backend_scm",(void*)f_5432},
{"f_5435:c_backend_scm",(void*)f_5435},
{"f_5438:c_backend_scm",(void*)f_5438},
{"f_5441:c_backend_scm",(void*)f_5441},
{"f_5444:c_backend_scm",(void*)f_5444},
{"f_6090:c_backend_scm",(void*)f_6090},
{"f_5447:c_backend_scm",(void*)f_5447},
{"f_6051:c_backend_scm",(void*)f_6051},
{"f_6054:c_backend_scm",(void*)f_6054},
{"f_6057:c_backend_scm",(void*)f_6057},
{"f_6073:c_backend_scm",(void*)f_6073},
{"f_6076:c_backend_scm",(void*)f_6076},
{"f_5450:c_backend_scm",(void*)f_5450},
{"f_5453:c_backend_scm",(void*)f_5453},
{"f_5456:c_backend_scm",(void*)f_5456},
{"f_6023:c_backend_scm",(void*)f_6023},
{"f_6026:c_backend_scm",(void*)f_6026},
{"f_5459:c_backend_scm",(void*)f_5459},
{"f_5462:c_backend_scm",(void*)f_5462},
{"f_5465:c_backend_scm",(void*)f_5465},
{"f_5468:c_backend_scm",(void*)f_5468},
{"f_5471:c_backend_scm",(void*)f_5471},
{"f_5474:c_backend_scm",(void*)f_5474},
{"f_5985:c_backend_scm",(void*)f_5985},
{"f_5995:c_backend_scm",(void*)f_5995},
{"f_5477:c_backend_scm",(void*)f_5477},
{"f_5928:c_backend_scm",(void*)f_5928},
{"f_5940:c_backend_scm",(void*)f_5940},
{"f_5943:c_backend_scm",(void*)f_5943},
{"f_5949:c_backend_scm",(void*)f_5949},
{"f_5850:c_backend_scm",(void*)f_5850},
{"f_5892:c_backend_scm",(void*)f_5892},
{"f_5853:c_backend_scm",(void*)f_5853},
{"f_5859:c_backend_scm",(void*)f_5859},
{"f_5862:c_backend_scm",(void*)f_5862},
{"f_5868:c_backend_scm",(void*)f_5868},
{"f_5786:c_backend_scm",(void*)f_5786},
{"f_5789:c_backend_scm",(void*)f_5789},
{"f_5792:c_backend_scm",(void*)f_5792},
{"f_5795:c_backend_scm",(void*)f_5795},
{"f_5798:c_backend_scm",(void*)f_5798},
{"f_5813:c_backend_scm",(void*)f_5813},
{"f_5801:c_backend_scm",(void*)f_5801},
{"f_5804:c_backend_scm",(void*)f_5804},
{"f_5772:c_backend_scm",(void*)f_5772},
{"f_5780:c_backend_scm",(void*)f_5780},
{"f_5697:c_backend_scm",(void*)f_5697},
{"f_5703:c_backend_scm",(void*)f_5703},
{"f_5706:c_backend_scm",(void*)f_5706},
{"f_5740:c_backend_scm",(void*)f_5740},
{"f_5743:c_backend_scm",(void*)f_5743},
{"f_5746:c_backend_scm",(void*)f_5746},
{"f_5709:c_backend_scm",(void*)f_5709},
{"f_5712:c_backend_scm",(void*)f_5712},
{"f_5715:c_backend_scm",(void*)f_5715},
{"f_5718:c_backend_scm",(void*)f_5718},
{"f_5727:c_backend_scm",(void*)f_5727},
{"f_5730:c_backend_scm",(void*)f_5730},
{"f_5480:c_backend_scm",(void*)f_5480},
{"f_5503:c_backend_scm",(void*)f_5503},
{"f_5638:c_backend_scm",(void*)f_5638},
{"f_5641:c_backend_scm",(void*)f_5641},
{"f_5653:c_backend_scm",(void*)f_5653},
{"f_5644:c_backend_scm",(void*)f_5644},
{"f_5509:c_backend_scm",(void*)f_5509},
{"f_5512:c_backend_scm",(void*)f_5512},
{"f_5515:c_backend_scm",(void*)f_5515},
{"f_5619:c_backend_scm",(void*)f_5619},
{"f_5518:c_backend_scm",(void*)f_5518},
{"f_5521:c_backend_scm",(void*)f_5521},
{"f_5524:c_backend_scm",(void*)f_5524},
{"f_5527:c_backend_scm",(void*)f_5527},
{"f_5592:c_backend_scm",(void*)f_5592},
{"f_5588:c_backend_scm",(void*)f_5588},
{"f_5530:c_backend_scm",(void*)f_5530},
{"f_5533:c_backend_scm",(void*)f_5533},
{"f_5536:c_backend_scm",(void*)f_5536},
{"f_5539:c_backend_scm",(void*)f_5539},
{"f_5542:c_backend_scm",(void*)f_5542},
{"f_5545:c_backend_scm",(void*)f_5545},
{"f_5563:c_backend_scm",(void*)f_5563},
{"f_5573:c_backend_scm",(void*)f_5573},
{"f_5548:c_backend_scm",(void*)f_5548},
{"f_5483:c_backend_scm",(void*)f_5483},
{"f_5493:c_backend_scm",(void*)f_5493},
{"f_5486:c_backend_scm",(void*)f_5486},
{"f_4987:c_backend_scm",(void*)f_4987},
{"f_4994:c_backend_scm",(void*)f_4994},
{"f_5068:c_backend_scm",(void*)f_5068},
{"f_5086:c_backend_scm",(void*)f_5086},
{"f_5115:c_backend_scm",(void*)f_5115},
{"f_5137:c_backend_scm",(void*)f_5137},
{"f_5093:c_backend_scm",(void*)f_5093},
{"f_5062:c_backend_scm",(void*)f_5062},
{"f_5058:c_backend_scm",(void*)f_5058},
{"f_5054:c_backend_scm",(void*)f_5054},
{"f_5025:c_backend_scm",(void*)f_5025},
{"f_5029:c_backend_scm",(void*)f_5029},
{"f_4944:c_backend_scm",(void*)f_4944},
{"f_4950:c_backend_scm",(void*)f_4950},
{"f_4979:c_backend_scm",(void*)f_4979},
{"f_4960:c_backend_scm",(void*)f_4960},
{"f_5146:c_backend_scm",(void*)f_5146},
{"f_5286:c_backend_scm",(void*)f_5286},
{"f_5153:c_backend_scm",(void*)f_5153},
{"f_5159:c_backend_scm",(void*)f_5159},
{"f_5242:c_backend_scm",(void*)f_5242},
{"f_5245:c_backend_scm",(void*)f_5245},
{"f_5255:c_backend_scm",(void*)f_5255},
{"f_5248:c_backend_scm",(void*)f_5248},
{"f_5209:c_backend_scm",(void*)f_5209},
{"f_5215:c_backend_scm",(void*)f_5215},
{"f_4981:c_backend_scm",(void*)f_4981},
{"f_5288:c_backend_scm",(void*)f_5288},
{"f_5295:c_backend_scm",(void*)f_5295},
{"f_5298:c_backend_scm",(void*)f_5298},
{"f_5303:c_backend_scm",(void*)f_5303},
{"f_5359:c_backend_scm",(void*)f_5359},
{"f_5355:c_backend_scm",(void*)f_5355},
{"f_5340:c_backend_scm",(void*)f_5340},
{"f_5319:c_backend_scm",(void*)f_5319},
{"f_5330:c_backend_scm",(void*)f_5330},
{"f_5326:c_backend_scm",(void*)f_5326},
{"f_5365:c_backend_scm",(void*)f_5365},
{"f_5372:c_backend_scm",(void*)f_5372},
{"f_5375:c_backend_scm",(void*)f_5375},
{"f_4658:c_backend_scm",(void*)f_4658},
{"f_4825:c_backend_scm",(void*)f_4825},
{"f_4829:c_backend_scm",(void*)f_4829},
{"f_4832:c_backend_scm",(void*)f_4832},
{"f_4835:c_backend_scm",(void*)f_4835},
{"f_4838:c_backend_scm",(void*)f_4838},
{"f_4841:c_backend_scm",(void*)f_4841},
{"f_4942:c_backend_scm",(void*)f_4942},
{"f_4844:c_backend_scm",(void*)f_4844},
{"f_4847:c_backend_scm",(void*)f_4847},
{"f_4853:c_backend_scm",(void*)f_4853},
{"f_4931:c_backend_scm",(void*)f_4931},
{"f_4887:c_backend_scm",(void*)f_4887},
{"f_4893:c_backend_scm",(void*)f_4893},
{"f_4911:c_backend_scm",(void*)f_4911},
{"f_4907:c_backend_scm",(void*)f_4907},
{"f_4903:c_backend_scm",(void*)f_4903},
{"f_4859:c_backend_scm",(void*)f_4859},
{"f_4862:c_backend_scm",(void*)f_4862},
{"f_4865:c_backend_scm",(void*)f_4865},
{"f_4868:c_backend_scm",(void*)f_4868},
{"f_4871:c_backend_scm",(void*)f_4871},
{"f_4881:c_backend_scm",(void*)f_4881},
{"f_4874:c_backend_scm",(void*)f_4874},
{"f_4777:c_backend_scm",(void*)f_4777},
{"f_4796:c_backend_scm",(void*)f_4796},
{"f_4800:c_backend_scm",(void*)f_4800},
{"f_4803:c_backend_scm",(void*)f_4803},
{"f_4806:c_backend_scm",(void*)f_4806},
{"f_4809:c_backend_scm",(void*)f_4809},
{"f_4823:c_backend_scm",(void*)f_4823},
{"f_4819:c_backend_scm",(void*)f_4819},
{"f_4812:c_backend_scm",(void*)f_4812},
{"f_4780:c_backend_scm",(void*)f_4780},
{"f_4794:c_backend_scm",(void*)f_4794},
{"f_4783:c_backend_scm",(void*)f_4783},
{"f_4790:c_backend_scm",(void*)f_4790},
{"f_4697:c_backend_scm",(void*)f_4697},
{"f_4699:c_backend_scm",(void*)f_4699},
{"f_4703:c_backend_scm",(void*)f_4703},
{"f_4706:c_backend_scm",(void*)f_4706},
{"f_4709:c_backend_scm",(void*)f_4709},
{"f_4712:c_backend_scm",(void*)f_4712},
{"f_4715:c_backend_scm",(void*)f_4715},
{"f_4718:c_backend_scm",(void*)f_4718},
{"f_4721:c_backend_scm",(void*)f_4721},
{"f_4724:c_backend_scm",(void*)f_4724},
{"f_4727:c_backend_scm",(void*)f_4727},
{"f_4730:c_backend_scm",(void*)f_4730},
{"f_4733:c_backend_scm",(void*)f_4733},
{"f_4736:c_backend_scm",(void*)f_4736},
{"f_4750:c_backend_scm",(void*)f_4750},
{"f_4746:c_backend_scm",(void*)f_4746},
{"f_4739:c_backend_scm",(void*)f_4739},
{"f_4661:c_backend_scm",(void*)f_4661},
{"f_4674:c_backend_scm",(void*)f_4674},
{"f_4684:c_backend_scm",(void*)f_4684},
{"f_4665:c_backend_scm",(void*)f_4665},
{"f_4407:c_backend_scm",(void*)f_4407},
{"f_4411:c_backend_scm",(void*)f_4411},
{"f_4435:c_backend_scm",(void*)f_4435},
{"f_4439:c_backend_scm",(void*)f_4439},
{"f_4442:c_backend_scm",(void*)f_4442},
{"f_4656:c_backend_scm",(void*)f_4656},
{"f_4445:c_backend_scm",(void*)f_4445},
{"f_4642:c_backend_scm",(void*)f_4642},
{"f_4448:c_backend_scm",(void*)f_4448},
{"f_4451:c_backend_scm",(void*)f_4451},
{"f_4454:c_backend_scm",(void*)f_4454},
{"f_4457:c_backend_scm",(void*)f_4457},
{"f_4460:c_backend_scm",(void*)f_4460},
{"f_4463:c_backend_scm",(void*)f_4463},
{"f_4634:c_backend_scm",(void*)f_4634},
{"f_4466:c_backend_scm",(void*)f_4466},
{"f_4469:c_backend_scm",(void*)f_4469},
{"f_4627:c_backend_scm",(void*)f_4627},
{"f_4608:c_backend_scm",(void*)f_4608},
{"f_4619:c_backend_scm",(void*)f_4619},
{"f_4472:c_backend_scm",(void*)f_4472},
{"f_4559:c_backend_scm",(void*)f_4559},
{"f_4562:c_backend_scm",(void*)f_4562},
{"f_4565:c_backend_scm",(void*)f_4565},
{"f_4568:c_backend_scm",(void*)f_4568},
{"f_4584:c_backend_scm",(void*)f_4584},
{"f_4587:c_backend_scm",(void*)f_4587},
{"f_4590:c_backend_scm",(void*)f_4590},
{"f_4593:c_backend_scm",(void*)f_4593},
{"f_4475:c_backend_scm",(void*)f_4475},
{"f_4478:c_backend_scm",(void*)f_4478},
{"f_4481:c_backend_scm",(void*)f_4481},
{"f_4531:c_backend_scm",(void*)f_4531},
{"f_4534:c_backend_scm",(void*)f_4534},
{"f_4484:c_backend_scm",(void*)f_4484},
{"f_4487:c_backend_scm",(void*)f_4487},
{"f_4519:c_backend_scm",(void*)f_4519},
{"f_4522:c_backend_scm",(void*)f_4522},
{"f_4493:c_backend_scm",(void*)f_4493},
{"f_4502:c_backend_scm",(void*)f_4502},
{"f_4505:c_backend_scm",(void*)f_4505},
{"f_4414:c_backend_scm",(void*)f_4414},
{"f_4419:c_backend_scm",(void*)f_4419},
{"f_4423:c_backend_scm",(void*)f_4423},
{"f_4433:c_backend_scm",(void*)f_4433},
{"f_4426:c_backend_scm",(void*)f_4426},
{"f_4258:c_backend_scm",(void*)f_4258},
{"f_4265:c_backend_scm",(void*)f_4265},
{"f_4401:c_backend_scm",(void*)f_4401},
{"f_4268:c_backend_scm",(void*)f_4268},
{"f_4271:c_backend_scm",(void*)f_4271},
{"f_4274:c_backend_scm",(void*)f_4274},
{"f_4279:c_backend_scm",(void*)f_4279},
{"f_4289:c_backend_scm",(void*)f_4289},
{"f_4295:c_backend_scm",(void*)f_4295},
{"f_4348:c_backend_scm",(void*)f_4348},
{"f_4358:c_backend_scm",(void*)f_4358},
{"f_4298:c_backend_scm",(void*)f_4298},
{"f_4321:c_backend_scm",(void*)f_4321},
{"f_4331:c_backend_scm",(void*)f_4331},
{"f_4301:c_backend_scm",(void*)f_4301},
{"f_4304:c_backend_scm",(void*)f_4304},
{"f_4111:c_backend_scm",(void*)f_4111},
{"f_4250:c_backend_scm",(void*)f_4250},
{"f_4131:c_backend_scm",(void*)f_4131},
{"f_4208:c_backend_scm",(void*)f_4208},
{"f_4212:c_backend_scm",(void*)f_4212},
{"f_4216:c_backend_scm",(void*)f_4216},
{"f_4220:c_backend_scm",(void*)f_4220},
{"f_4242:c_backend_scm",(void*)f_4242},
{"f_4238:c_backend_scm",(void*)f_4238},
{"f_4230:c_backend_scm",(void*)f_4230},
{"f_4228:c_backend_scm",(void*)f_4228},
{"f_4224:c_backend_scm",(void*)f_4224},
{"f_4149:c_backend_scm",(void*)f_4149},
{"f_4152:c_backend_scm",(void*)f_4152},
{"f_4155:c_backend_scm",(void*)f_4155},
{"f_4197:c_backend_scm",(void*)f_4197},
{"f_4158:c_backend_scm",(void*)f_4158},
{"f_4161:c_backend_scm",(void*)f_4161},
{"f_4164:c_backend_scm",(void*)f_4164},
{"f_4179:c_backend_scm",(void*)f_4179},
{"f_4184:c_backend_scm",(void*)f_4184},
{"f_4167:c_backend_scm",(void*)f_4167},
{"f_4114:c_backend_scm",(void*)f_4114},
{"f_4128:c_backend_scm",(void*)f_4128},
{"f_2538:c_backend_scm",(void*)f_2538},
{"f_4079:c_backend_scm",(void*)f_4079},
{"f_4085:c_backend_scm",(void*)f_4085},
{"f_4089:c_backend_scm",(void*)f_4089},
{"f_2541:c_backend_scm",(void*)f_2541},
{"f_4044:c_backend_scm",(void*)f_4044},
{"f_4047:c_backend_scm",(void*)f_4047},
{"f_4050:c_backend_scm",(void*)f_4050},
{"f_4053:c_backend_scm",(void*)f_4053},
{"f_4056:c_backend_scm",(void*)f_4056},
{"f_4059:c_backend_scm",(void*)f_4059},
{"f_3961:c_backend_scm",(void*)f_3961},
{"f_3964:c_backend_scm",(void*)f_3964},
{"f_3967:c_backend_scm",(void*)f_3967},
{"f_3980:c_backend_scm",(void*)f_3980},
{"f_4003:c_backend_scm",(void*)f_4003},
{"f_4006:c_backend_scm",(void*)f_4006},
{"f_4009:c_backend_scm",(void*)f_4009},
{"f_4012:c_backend_scm",(void*)f_4012},
{"f_3990:c_backend_scm",(void*)f_3990},
{"f_3993:c_backend_scm",(void*)f_3993},
{"f_3952:c_backend_scm",(void*)f_3952},
{"f_3924:c_backend_scm",(void*)f_3924},
{"f_3927:c_backend_scm",(void*)f_3927},
{"f_3944:c_backend_scm",(void*)f_3944},
{"f_3930:c_backend_scm",(void*)f_3930},
{"f_3933:c_backend_scm",(void*)f_3933},
{"f_3908:c_backend_scm",(void*)f_3908},
{"f_3912:c_backend_scm",(void*)f_3912},
{"f_3894:c_backend_scm",(void*)f_3894},
{"f_3897:c_backend_scm",(void*)f_3897},
{"f_3878:c_backend_scm",(void*)f_3878},
{"f_3882:c_backend_scm",(void*)f_3882},
{"f_3860:c_backend_scm",(void*)f_3860},
{"f_3863:c_backend_scm",(void*)f_3863},
{"f_3840:c_backend_scm",(void*)f_3840},
{"f_3804:c_backend_scm",(void*)f_3804},
{"f_3816:c_backend_scm",(void*)f_3816},
{"f_3807:c_backend_scm",(void*)f_3807},
{"f_3785:c_backend_scm",(void*)f_3785},
{"f_3788:c_backend_scm",(void*)f_3788},
{"f_3766:c_backend_scm",(void*)f_3766},
{"f_3769:c_backend_scm",(void*)f_3769},
{"f_3747:c_backend_scm",(void*)f_3747},
{"f_3750:c_backend_scm",(void*)f_3750},
{"f_3728:c_backend_scm",(void*)f_3728},
{"f_3724:c_backend_scm",(void*)f_3724},
{"f_3672:c_backend_scm",(void*)f_3672},
{"f_3705:c_backend_scm",(void*)f_3705},
{"f_3675:c_backend_scm",(void*)f_3675},
{"f_3693:c_backend_scm",(void*)f_3693},
{"f_3678:c_backend_scm",(void*)f_3678},
{"f_3681:c_backend_scm",(void*)f_3681},
{"f_3639:c_backend_scm",(void*)f_3639},
{"f_3623:c_backend_scm",(void*)f_3623},
{"f_3626:c_backend_scm",(void*)f_3626},
{"f_3629:c_backend_scm",(void*)f_3629},
{"f_3582:c_backend_scm",(void*)f_3582},
{"f_3585:c_backend_scm",(void*)f_3585},
{"f_3606:c_backend_scm",(void*)f_3606},
{"f_3610:c_backend_scm",(void*)f_3610},
{"f_3613:c_backend_scm",(void*)f_3613},
{"f_3588:c_backend_scm",(void*)f_3588},
{"f_3604:c_backend_scm",(void*)f_3604},
{"f_3596:c_backend_scm",(void*)f_3596},
{"f_3591:c_backend_scm",(void*)f_3591},
{"f_3215:c_backend_scm",(void*)f_3215},
{"f_3218:c_backend_scm",(void*)f_3218},
{"f_3532:c_backend_scm",(void*)f_3532},
{"f_3528:c_backend_scm",(void*)f_3528},
{"f_3224:c_backend_scm",(void*)f_3224},
{"f_3521:c_backend_scm",(void*)f_3521},
{"f_2526:c_backend_scm",(void*)f_2526},
{"f_3514:c_backend_scm",(void*)f_3514},
{"f_3230:c_backend_scm",(void*)f_3230},
{"f_3357:c_backend_scm",(void*)f_3357},
{"f_3441:c_backend_scm",(void*)f_3441},
{"f_3444:c_backend_scm",(void*)f_3444},
{"f_3447:c_backend_scm",(void*)f_3447},
{"f_3462:c_backend_scm",(void*)f_3462},
{"f_3450:c_backend_scm",(void*)f_3450},
{"f_3453:c_backend_scm",(void*)f_3453},
{"f_3456:c_backend_scm",(void*)f_3456},
{"f_3372:c_backend_scm",(void*)f_3372},
{"f_3438:c_backend_scm",(void*)f_3438},
{"f_3431:c_backend_scm",(void*)f_3431},
{"f_3427:c_backend_scm",(void*)f_3427},
{"f_3420:c_backend_scm",(void*)f_3420},
{"f_3413:c_backend_scm",(void*)f_3413},
{"f_3388:c_backend_scm",(void*)f_3388},
{"f_3405:c_backend_scm",(void*)f_3405},
{"f_3401:c_backend_scm",(void*)f_3401},
{"f_3375:c_backend_scm",(void*)f_3375},
{"f_3378:c_backend_scm",(void*)f_3378},
{"f_3381:c_backend_scm",(void*)f_3381},
{"f_3351:c_backend_scm",(void*)f_3351},
{"f_3261:c_backend_scm",(void*)f_3261},
{"f_3335:c_backend_scm",(void*)f_3335},
{"f_3338:c_backend_scm",(void*)f_3338},
{"f_3311:c_backend_scm",(void*)f_3311},
{"f_3314:c_backend_scm",(void*)f_3314},
{"f_3317:c_backend_scm",(void*)f_3317},
{"f_3320:c_backend_scm",(void*)f_3320},
{"f_3323:c_backend_scm",(void*)f_3323},
{"f_3264:c_backend_scm",(void*)f_3264},
{"f_3267:c_backend_scm",(void*)f_3267},
{"f_3294:c_backend_scm",(void*)f_3294},
{"f_3298:c_backend_scm",(void*)f_3298},
{"f_3301:c_backend_scm",(void*)f_3301},
{"f_3270:c_backend_scm",(void*)f_3270},
{"f_3292:c_backend_scm",(void*)f_3292},
{"f_3284:c_backend_scm",(void*)f_3284},
{"f_3273:c_backend_scm",(void*)f_3273},
{"f_3276:c_backend_scm",(void*)f_3276},
{"f_3242:c_backend_scm",(void*)f_3242},
{"f_3245:c_backend_scm",(void*)f_3245},
{"f_3182:c_backend_scm",(void*)f_3182},
{"f_3178:c_backend_scm",(void*)f_3178},
{"f_3164:c_backend_scm",(void*)f_3164},
{"f_3167:c_backend_scm",(void*)f_3167},
{"f_3161:c_backend_scm",(void*)f_3161},
{"f_3157:c_backend_scm",(void*)f_3157},
{"f_3143:c_backend_scm",(void*)f_3143},
{"f_3146:c_backend_scm",(void*)f_3146},
{"f_3095:c_backend_scm",(void*)f_3095},
{"f_3116:c_backend_scm",(void*)f_3116},
{"f_3112:c_backend_scm",(void*)f_3112},
{"f_3098:c_backend_scm",(void*)f_3098},
{"f_3101:c_backend_scm",(void*)f_3101},
{"f_3064:c_backend_scm",(void*)f_3064},
{"f_3060:c_backend_scm",(void*)f_3060},
{"f_3018:c_backend_scm",(void*)f_3018},
{"f_2986:c_backend_scm",(void*)f_2986},
{"f_2989:c_backend_scm",(void*)f_2989},
{"f_2951:c_backend_scm",(void*)f_2951},
{"f_2977:c_backend_scm",(void*)f_2977},
{"f_2963:c_backend_scm",(void*)f_2963},
{"f_2967:c_backend_scm",(void*)f_2967},
{"f_2970:c_backend_scm",(void*)f_2970},
{"f_2954:c_backend_scm",(void*)f_2954},
{"f_2919:c_backend_scm",(void*)f_2919},
{"f_2922:c_backend_scm",(void*)f_2922},
{"f_2925:c_backend_scm",(void*)f_2925},
{"f_2928:c_backend_scm",(void*)f_2928},
{"f_2890:c_backend_scm",(void*)f_2890},
{"f_2893:c_backend_scm",(void*)f_2893},
{"f_2896:c_backend_scm",(void*)f_2896},
{"f_2899:c_backend_scm",(void*)f_2899},
{"f_2853:c_backend_scm",(void*)f_2853},
{"f_2856:c_backend_scm",(void*)f_2856},
{"f_2859:c_backend_scm",(void*)f_2859},
{"f_2862:c_backend_scm",(void*)f_2862},
{"f_2820:c_backend_scm",(void*)f_2820},
{"f_2823:c_backend_scm",(void*)f_2823},
{"f_2826:c_backend_scm",(void*)f_2826},
{"f_2829:c_backend_scm",(void*)f_2829},
{"f_2801:c_backend_scm",(void*)f_2801},
{"f_2804:c_backend_scm",(void*)f_2804},
{"f_2774:c_backend_scm",(void*)f_2774},
{"f_2777:c_backend_scm",(void*)f_2777},
{"f_2723:c_backend_scm",(void*)f_2723},
{"f_2733:c_backend_scm",(void*)f_2733},
{"f_2736:c_backend_scm",(void*)f_2736},
{"f_2739:c_backend_scm",(void*)f_2739},
{"f_2665:c_backend_scm",(void*)f_2665},
{"f_2668:c_backend_scm",(void*)f_2668},
{"f_2671:c_backend_scm",(void*)f_2671},
{"f_2674:c_backend_scm",(void*)f_2674},
{"f_2677:c_backend_scm",(void*)f_2677},
{"f_2680:c_backend_scm",(void*)f_2680},
{"f_2528:c_backend_scm",(void*)f_2528},
{"f_2536:c_backend_scm",(void*)f_2536},
{"f_2496:c_backend_scm",(void*)f_2496},
{"f_2508:c_backend_scm",(void*)f_2508},
{"f_2516:c_backend_scm",(void*)f_2516},
{"f_2500:c_backend_scm",(void*)f_2500},
{"f_2473:c_backend_scm",(void*)f_2473},
{"f_2487:c_backend_scm",(void*)f_2487},
{"f_2479:c_backend_scm",(void*)f_2479},
{"f_2452:c_backend_scm",(void*)f_2452},
{"f_2458:c_backend_scm",(void*)f_2458},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
