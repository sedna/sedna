/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:35
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: utils.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file uutils.c
   unit: utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[31];
static double C_possibly_force_alignment;


C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_150)
static void C_ccall f_150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_153)
static void C_ccall f_153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_156)
static void C_ccall f_156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_293)
static void C_ccall f_293(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_293)
static void C_ccall f_293r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_322)
static void C_ccall f_322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_257)
static void C_ccall f_257(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_257)
static void C_ccall f_257r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_267)
static void C_ccall f_267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_275)
static void C_ccall f_275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_212)
static void C_ccall f_212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_237)
static void C_ccall f_237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_251)
static void C_ccall f_251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_230)
static void C_ccall f_230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_176)
static void C_ccall f_176(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_176)
static void C_ccall f_176r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_183)
static void C_ccall f_183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_188)
static void C_fcall f_188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_192)
static void C_ccall f_192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_201)
static void C_ccall f_201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_158)
static void C_ccall f_158(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_158)
static void C_ccall f_158r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_162)
static void C_ccall f_162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_165)
static void C_ccall f_165(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_188)
static void C_fcall trf_188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_188(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(313)){
C_save(t1);
C_rereclaim2(313*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,31);
lf[0]=C_h_intern(&lf[0],7,"sprintf");
lf[1]=C_h_intern(&lf[1],6,"system");
lf[2]=C_h_intern(&lf[2],7,"system*");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[5]=C_h_intern(&lf[5],9,"read-line");
lf[6]=C_h_intern(&lf[6],13,"for-each-line");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-input");
lf[8]=C_h_intern(&lf[8],14,"\003syscheck-port");
lf[9]=C_h_intern(&lf[9],18,"for-each-argv-line");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[11]=C_h_intern(&lf[11],20,"with-input-from-file");
lf[12]=C_h_intern(&lf[12],12,"\003sysfor-each");
lf[13]=C_h_intern(&lf[13],22,"command-line-arguments");
lf[14]=C_h_intern(&lf[14],8,"read-all");
lf[15]=C_h_intern(&lf[15],20,"\003sysread-string/port");
lf[16]=C_h_intern(&lf[16],5,"port\077");
lf[17]=C_h_intern(&lf[17],2,"qs");
lf[18]=C_h_intern(&lf[18],7,"mingw32");
lf[19]=C_h_intern(&lf[19],4,"msvc");
lf[20]=C_h_intern(&lf[20],13,"string-append");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\002\047\047");
lf[24]=C_h_intern(&lf[24],18,"string-concatenate");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000#\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000`\376\003\000\000\002\376\377\012\000\000\264\376\003\000\000\002\376\377\012\000\000~\376\003\000\000\002\376\377\012\000\000&\376\003\000"
"\000\002\376\377\012\000\000%\376\003\000\000\002\376\377\012\000\000$\376\003\000\000\002\376\377\012\000\000!\376\003\000\000\002\376\377\012\000\000*\376\003\000\000\002\376\377\012\000\000;\376\003\000\000\002\376\377\012\000\000<\376\003\000\000\002\376\377\012\000\000>\376\003\000\000\002\376"
"\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000(\376\003\000\000\002\376\377\012\000\000)\376\003\000\000\002\376\377\012\000\000[\376\003\000\000\002\376\377\012\000\000]\376\003\000\000\002\376\377\012\000\000{\376\003\000\000\002\376\377\012\000\000}\376\377\016");
lf[26]=C_h_intern(&lf[26],7,"\003sysmap");
lf[27]=C_h_intern(&lf[27],16,"\003sysstring->list");
lf[28]=C_h_intern(&lf[28],14,"build-platform");
lf[29]=C_h_intern(&lf[29],17,"register-feature!");
lf[30]=C_h_intern(&lf[30],5,"utils");
C_register_lf2(lf,31,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_150,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k148 */
static void C_ccall f_150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_153,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k151 in k148 */
static void C_ccall f_153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 52   register-feature! */
t3=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[30]);}

/* k154 in k151 in k148 */
static void C_ccall f_156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_156,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=*((C_word*)lf[1]+1);
t4=C_mutate((C_word*)lf[2]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_158,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[5]+1);
t6=C_mutate((C_word*)lf[6]+1 /* (set! for-each-line ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_176,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! for-each-argv-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_212,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[14]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_257,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[17]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_293,tmp=(C_word)a,a+=2,tmp));
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* qs in k154 in k151 in k148 */
static void C_ccall f_293(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_293r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_293r(t0,t1,t2,t3);}}

static void C_ccall f_293r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
/* utils.scm: 107  build-platform */
t5=*((C_word*)lf[28]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t4;
f_297(2,t5,(C_word)C_slot(t3,C_fix(0)));}}

/* k295 in qs in k154 in k151 in k148 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_297,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[18]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(t1,lf[19]));
if(C_truep(t3)){
/* utils.scm: 110  string-append */
t4=*((C_word*)lf[20]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[21],((C_word*)t0)[2],lf[22]);}
else{
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[23]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_322,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_324,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_347,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[2]);}}}

/* k345 in k295 in qs in k154 in k151 in k148 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a323 in k295 in qs in k154 in k151 in k148 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_324,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=(C_truep(t3)?t3:(C_word)C_u_i_memq(t2,lf[25]));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_a_i_string(&a,2,C_make_character(92),t2):(C_word)C_a_i_string(&a,1,t2)));}

/* k320 in k295 in qs in k154 in k151 in k148 */
static void C_ccall f_322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 114  string-concatenate */
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* read-all in k154 in k151 in k148 */
static void C_ccall f_257(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_257r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_257r(t0,t1,t2);}}

static void C_ccall f_257r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?*((C_word*)lf[7]+1):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_267,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 100  port? */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k265 in read-all in k154 in k151 in k148 */
static void C_ccall f_267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_267,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_275,tmp=(C_word)a,a+=2,tmp);
/* utils.scm: 102  with-input-from-file */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a274 in k265 in read-all in k154 in k151 in k148 */
static void C_ccall f_275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_275,2,t0,t1);}
/* read-string/port */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_SCHEME_FALSE,*((C_word*)lf[7]+1));}

/* for-each-argv-line in k154 in k151 in k148 */
static void C_ccall f_212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_212,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_237,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 88   command-line-arguments */
t4=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k235 in for-each-argv-line in k154 in k151 in k148 */
static void C_ccall f_237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_237,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* utils.scm: 91   for-each-line */
t2=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}}

/* a250 in k235 in for-each-argv-line in k154 in k151 in k148 */
static void C_ccall f_251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_251,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
if(C_truep((C_word)C_u_i_string_equal_p(t2,lf[10]))){
/* utils.scm: 86   for-each-line */
t4=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_230,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* utils.scm: 87   with-input-from-file */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a229 in a250 in k235 in for-each-argv-line in k154 in k151 in k148 */
static void C_ccall f_230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_230,2,t0,t1);}
/* for-each-line */
t2=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* for-each-line in k154 in k151 in k148 */
static void C_ccall f_176(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_176r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_176r(t0,t1,t2,t3);}}

static void C_ccall f_176r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):*((C_word*)lf[7]+1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_183,a[2]=t1,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* utils.scm: 73   ##sys#check-port */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[6]);}

/* k181 in for-each-line in k154 in k151 in k148 */
static void C_ccall f_183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_183,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_188(t5,((C_word*)t0)[2]);}

/* loop in k181 in for-each-line in k154 in k151 in k148 */
static void C_fcall f_188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_188,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm: 75   read-line */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k190 in loop in k181 in for-each-line in k154 in k151 in k148 */
static void C_ccall f_192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_192,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_201,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 77   proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k199 in k190 in loop in k181 in for-each-line in k154 in k151 in k148 */
static void C_ccall f_201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm: 78   loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_188(t2,((C_word*)t0)[2]);}

/* system* in k154 in k151 in k148 */
static void C_ccall f_158(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_158r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_158r(t0,t1,t2,t3);}}

static void C_ccall f_158r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_162,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t4,((C_word*)t0)[2],t2,t3);}

/* k160 in system* in k154 in k151 in k148 */
static void C_ccall f_162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_165,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* utils.scm: 62   system */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k163 in k160 in system* in k154 in k151 in k148 */
static void C_ccall f_165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* utils.scm: 64   ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[4],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[25] = {
{"toplevel:utils_scm",(void*)C_utils_toplevel},
{"f_150:utils_scm",(void*)f_150},
{"f_153:utils_scm",(void*)f_153},
{"f_156:utils_scm",(void*)f_156},
{"f_293:utils_scm",(void*)f_293},
{"f_297:utils_scm",(void*)f_297},
{"f_347:utils_scm",(void*)f_347},
{"f_324:utils_scm",(void*)f_324},
{"f_322:utils_scm",(void*)f_322},
{"f_257:utils_scm",(void*)f_257},
{"f_267:utils_scm",(void*)f_267},
{"f_275:utils_scm",(void*)f_275},
{"f_212:utils_scm",(void*)f_212},
{"f_237:utils_scm",(void*)f_237},
{"f_251:utils_scm",(void*)f_251},
{"f_230:utils_scm",(void*)f_230},
{"f_176:utils_scm",(void*)f_176},
{"f_183:utils_scm",(void*)f_183},
{"f_188:utils_scm",(void*)f_188},
{"f_192:utils_scm",(void*)f_192},
{"f_201:utils_scm",(void*)f_201},
{"f_158:utils_scm",(void*)f_158},
{"f_162:utils_scm",(void*)f_162},
{"f_165:utils_scm",(void*)f_165},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
