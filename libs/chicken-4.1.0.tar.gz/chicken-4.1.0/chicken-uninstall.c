/* Generated from chicken-uninstall.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:40
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: chicken-uninstall.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -ignore-repository -output-file chicken-uninstall.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils ports regex srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[55];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_359)
static void C_ccall f_359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_362)
static void C_ccall f_362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_371)
static void C_ccall f_371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_784)
static void C_ccall f_784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_fcall f_581(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_616)
static void C_fcall f_616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_677)
static void C_fcall f_677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_686)
static void C_ccall f_686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_ccall f_709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_664)
static void C_ccall f_664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_638)
static void C_ccall f_638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_595)
static void C_ccall f_595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_426)
static void C_ccall f_426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_405)
static void C_ccall f_405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_ccall f_418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_481)
static void C_ccall f_481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_517)
static void C_ccall f_517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_487)
static void C_ccall f_487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_505)
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_499)
static void C_ccall f_499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_495)
static void C_ccall f_495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_460)
static void C_ccall f_460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_440)
static void C_ccall f_440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_452)
static void C_ccall f_452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_551)
static void C_ccall f_551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_774)
static void C_ccall f_774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_777)
static void C_ccall f_777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_565)
static void C_fcall f_565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_581)
static void C_fcall trf_581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_581(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_581(t0,t1,t2,t3);}

C_noret_decl(trf_616)
static void C_fcall trf_616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_616(t0,t1);}

C_noret_decl(trf_677)
static void C_fcall trf_677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_677(t0,t1);}

C_noret_decl(trf_565)
static void C_fcall trf_565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_565(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(342)){
C_save(t1);
C_rereclaim2(342*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,55);
lf[2]=C_h_intern(&lf[2],4,"exit");
lf[3]=C_h_intern(&lf[3],5,"print");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\001#usage: chicken-uninstall [OPTION | PATTERN] ...\012\012  -h   -help              "
"      show this message and exit\012  -v   -version                 show version an"
"d exit\012       -force                   don\047t ask, delete whatever matches\012  -s  "
" -sudo                    use sudo(1) for deleting files");
lf[5]=C_h_intern(&lf[5],25,"\003sysimplicit-exit-handler");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\022nothing to remove.");
lf[7]=C_h_intern(&lf[7],26,"setup-api#remove-extension");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\011removing ");
lf[9]=C_h_intern(&lf[9],12,"\003sysfor-each");
lf[10]=C_h_intern(&lf[10],7,"aborted");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\010aborted.");
lf[12]=C_h_intern(&lf[12],6,"signal");
lf[13]=C_h_intern(&lf[13],20,"setup-api#yes-or-no\077");
lf[14]=C_h_intern(&lf[14],8,"\000default");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[16]=C_h_intern(&lf[16],18,"string-concatenate");
lf[17]=C_h_intern(&lf[17],6,"append");
lf[18]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000+About to delete the following extensions:\012\012\376\377\016");
lf[19]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030\012Do you want to proceed\077\376\377\016");
lf[20]=C_h_intern(&lf[20],13,"string-append");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[23]=C_h_intern(&lf[23],7,"\003sysmap");
lf[24]=C_h_intern(&lf[24],22,"with-exception-handler");
lf[25]=C_h_intern(&lf[25],30,"call-with-current-continuation");
lf[26]=C_h_intern(&lf[26],17,"delete-duplicates");
lf[27]=C_h_intern(&lf[27],8,"string=\077");
lf[28]=C_h_intern(&lf[28],11,"concatenate");
lf[29]=C_h_intern(&lf[29],4,"grep");
lf[30]=C_h_intern(&lf[30],13,"pathname-file");
lf[31]=C_h_intern(&lf[31],4,"glob");
lf[32]=C_h_intern(&lf[32],13,"make-pathname");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[35]=C_h_intern(&lf[35],15,"repository-path");
lf[36]=C_h_intern(&lf[36],7,"reverse");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[40]=C_h_intern(&lf[40],15,"chicken-version");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[44]=C_h_intern(&lf[44],22,"setup-api#sudo-install");
lf[45]=C_h_intern(&lf[45],17,"lset-intersection");
lf[46]=C_h_intern(&lf[46],3,"eq\077");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\377\016");
lf[48]=C_h_intern(&lf[48],16,"\003sysstring->list");
lf[49]=C_h_intern(&lf[49],9,"substring");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[52]=C_h_intern(&lf[52],22,"command-line-arguments");
lf[53]=C_h_intern(&lf[53],11,"\003sysrequire");
lf[54]=C_h_intern(&lf[54],9,"setup-api");
C_register_lf2(lf,55,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k354 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k357 in k354 */
static void C_ccall f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k360 in k357 in k354 */
static void C_ccall f_362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k363 in k360 in k357 in k354 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_368,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_371,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,lf[54]);}

/* k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=lf[0] /* main#*force* */ =C_SCHEME_FALSE;;
t3=C_mutate(&lf[1] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_565,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_774,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_784,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 117  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t5);}

/* k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_784,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_581,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_581(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_fcall f_581(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_581,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_595,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* chicken-uninstall.scm: 92   usage */
f_565(t4,C_fix(1));}
else{
/* chicken-uninstall.scm: 92   reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t3);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[37]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_616,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_616(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[50]);
t8=t6;
f_616(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[51])));}}}

/* k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_fcall f_616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_616,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-uninstall.scm: 97   usage */
f_565(((C_word*)t0)[6],C_fix(0));}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[38]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[39]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_631,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_638,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 99   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[40]))(2,*((C_word*)lf[40]+1),t5);}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[41]))){
t4=lf[0] /* main#*force* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-uninstall.scm: 103  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_581(t6,((C_word*)t0)[6],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[42]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[5],lf[43]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-uninstall.scm: 105  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),t6,C_SCHEME_TRUE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_677,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t9=t6;
f_677(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_677(t8,C_SCHEME_FALSE);}}}}}}

/* k675 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_fcall f_677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_677,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_724,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 110  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-uninstall.scm: 114  usage */
f_565(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-uninstall.scm: 115  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_581(t4,((C_word*)t0)[4],t2,t3);}}

/* k722 in k675 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[48]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k684 in k675 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_720,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-uninstall.scm: 111  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,*((C_word*)lf[46]+1),lf[47],t1);}

/* k718 in k684 in k675 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_720,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_699,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_703,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_709,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-uninstall.scm: 113  usage */
f_565(((C_word*)t0)[5],C_fix(1));}}

/* a708 in k718 in k684 in k675 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_709,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k701 in k718 in k684 in k675 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-uninstall.scm: 112  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[17]+1)))(4,*((C_word*)lf[17]+1),((C_word*)t0)[2],t1,t2);}

/* k697 in k718 in k684 in k675 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 112  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_581(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k662 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-uninstall.scm: 106  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_581(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k636 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 99   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),((C_word*)t0)[2],t1);}

/* k629 in k614 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 100  exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[2],C_fix(0));}

/* k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_595,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_527,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_405,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_426,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_434,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 42   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t7);}

/* k432 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[32]))(5,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1,lf[33],lf[34]);}

/* k428 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 42   glob */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),((C_word*)t0)[2],t1);}

/* k424 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[30]),t1);}

/* k403 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_416,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_418,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a417 in k403 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_418,3,t0,t1,t2);}
/* grep */
((C_proc4)C_retrieve_symbol_proc(lf[29]))(4,*((C_word*)lf[29]+1),t1,t2,((C_word*)t0)[2]);}

/* k414 in k403 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 44   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),((C_word*)t0)[2],t1);}

/* k410 in k403 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 43   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[26]))(4,*((C_word*)lf[26]+1),((C_word*)t0)[2],t1,*((C_word*)lf[27]+1));}

/* k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_527,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-uninstall.scm: 67   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),((C_word*)t0)[3],lf[6]);}
else{
t2=C_retrieve2(lf[0],"main#*force*");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_542,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_542(2,t4,t2);}
else{
t4=(C_word)C_i_equalp(t1,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_542(2,t5,t4);}
else{
t5=t1;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_452,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_454,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t6,t7);}}}}

/* a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_454,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_460,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_481,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,t3,t4);}

/* a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_487,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a510 in a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_511(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_511r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_511r(t0,t1,t2);}}

static void C_ccall f_511r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k211217 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a516 in a510 in a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_517,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a486 in a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_495,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_505,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a504 in a486 in a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_505,3,t0,t1,t2);}
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[20]+1)))(5,*((C_word*)lf[20]+1),t1,lf[21],t2,lf[22]);}

/* k501 in a486 in a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 58   append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[17]+1)))(5,*((C_word*)lf[17]+1),((C_word*)t0)[2],lf[18],t1,lf[19]);}

/* k497 in a486 in a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 57   string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1);}

/* k493 in a486 in a480 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 56   setup-api#yes-or-no? */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,lf[14],lf[15]);}

/* a459 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_460,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k211217 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a465 in a459 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_466,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[2],lf[10]);
if(C_truep(t2)){
t3=t1;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_440,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-uninstall.scm: 48   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t4,lf[11]);}
else{
/* chicken-uninstall.scm: 55   signal */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t1,((C_word*)t0)[2]);}}

/* k438 in a465 in a459 in a453 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 49   exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[2],C_fix(1));}

/* k450 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k540 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_542,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_547,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* a546 in k540 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_551,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-uninstall.scm: 71   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[3]+1)))(4,*((C_word*)lf[3]+1),t3,lf[8],t2);}

/* k549 in a546 in k540 in k525 in k593 in loop in k782 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 72   setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k772 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t3);}

/* k778 in k772 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k775 in k772 in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_fcall f_565(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_565,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_569,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-uninstall.scm: 76   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t3,lf[4]);}

/* k567 in main#usage in k396 in k393 in k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-uninstall.scm: 85   exit */
((C_proc3)C_retrieve_symbol_proc(lf[2]))(3,*((C_word*)lf[2]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[60] = {
{"toplevel:chicken_uninstall_scm",(void*)C_toplevel},
{"f_356:chicken_uninstall_scm",(void*)f_356},
{"f_359:chicken_uninstall_scm",(void*)f_359},
{"f_362:chicken_uninstall_scm",(void*)f_362},
{"f_365:chicken_uninstall_scm",(void*)f_365},
{"f_368:chicken_uninstall_scm",(void*)f_368},
{"f_371:chicken_uninstall_scm",(void*)f_371},
{"f_374:chicken_uninstall_scm",(void*)f_374},
{"f_377:chicken_uninstall_scm",(void*)f_377},
{"f_380:chicken_uninstall_scm",(void*)f_380},
{"f_383:chicken_uninstall_scm",(void*)f_383},
{"f_386:chicken_uninstall_scm",(void*)f_386},
{"f_389:chicken_uninstall_scm",(void*)f_389},
{"f_392:chicken_uninstall_scm",(void*)f_392},
{"f_395:chicken_uninstall_scm",(void*)f_395},
{"f_398:chicken_uninstall_scm",(void*)f_398},
{"f_784:chicken_uninstall_scm",(void*)f_784},
{"f_581:chicken_uninstall_scm",(void*)f_581},
{"f_616:chicken_uninstall_scm",(void*)f_616},
{"f_677:chicken_uninstall_scm",(void*)f_677},
{"f_724:chicken_uninstall_scm",(void*)f_724},
{"f_686:chicken_uninstall_scm",(void*)f_686},
{"f_720:chicken_uninstall_scm",(void*)f_720},
{"f_709:chicken_uninstall_scm",(void*)f_709},
{"f_703:chicken_uninstall_scm",(void*)f_703},
{"f_699:chicken_uninstall_scm",(void*)f_699},
{"f_664:chicken_uninstall_scm",(void*)f_664},
{"f_638:chicken_uninstall_scm",(void*)f_638},
{"f_631:chicken_uninstall_scm",(void*)f_631},
{"f_595:chicken_uninstall_scm",(void*)f_595},
{"f_434:chicken_uninstall_scm",(void*)f_434},
{"f_430:chicken_uninstall_scm",(void*)f_430},
{"f_426:chicken_uninstall_scm",(void*)f_426},
{"f_405:chicken_uninstall_scm",(void*)f_405},
{"f_418:chicken_uninstall_scm",(void*)f_418},
{"f_416:chicken_uninstall_scm",(void*)f_416},
{"f_412:chicken_uninstall_scm",(void*)f_412},
{"f_527:chicken_uninstall_scm",(void*)f_527},
{"f_454:chicken_uninstall_scm",(void*)f_454},
{"f_481:chicken_uninstall_scm",(void*)f_481},
{"f_511:chicken_uninstall_scm",(void*)f_511},
{"f_517:chicken_uninstall_scm",(void*)f_517},
{"f_487:chicken_uninstall_scm",(void*)f_487},
{"f_505:chicken_uninstall_scm",(void*)f_505},
{"f_503:chicken_uninstall_scm",(void*)f_503},
{"f_499:chicken_uninstall_scm",(void*)f_499},
{"f_495:chicken_uninstall_scm",(void*)f_495},
{"f_460:chicken_uninstall_scm",(void*)f_460},
{"f_466:chicken_uninstall_scm",(void*)f_466},
{"f_440:chicken_uninstall_scm",(void*)f_440},
{"f_452:chicken_uninstall_scm",(void*)f_452},
{"f_542:chicken_uninstall_scm",(void*)f_542},
{"f_547:chicken_uninstall_scm",(void*)f_547},
{"f_551:chicken_uninstall_scm",(void*)f_551},
{"f_774:chicken_uninstall_scm",(void*)f_774},
{"f_780:chicken_uninstall_scm",(void*)f_780},
{"f_777:chicken_uninstall_scm",(void*)f_777},
{"f_565:chicken_uninstall_scm",(void*)f_565},
{"f_569:chicken_uninstall_scm",(void*)f_569},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
