/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:33
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: srfi-69.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file srfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[116];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,49,49,53,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,32),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,49,50,57,32,46,32,116,109,112,49,50,56,49,51,48,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,50,50,55,32,46,32,116,109,112,50,50,54,50,50,56,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,50,54,52,32,46,32,116,109,112,50,54,51,50,54,53,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,50,57,55,32,46,32,121,50,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,33),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,51,49,52,32,46,32,116,109,112,51,49,51,51,49,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,101,113,63,45,104,97,115,104,32,111,98,106,51,55,56,32,46,32,116,109,112,51,55,55,51,55,57,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,101,113,118,63,45,104,97,115,104,32,111,98,106,52,56,54,32,46,32,116,109,112,52,56,53,52,56,55,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,104,115,104,53,51,56,32,105,53,51,57,32,108,101,110,53,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,46),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,53,50,57,32,115,101,101,100,53,51,48,32,100,101,112,116,104,53,51,49,32,115,116,97,114,116,53,51,50,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,39),40,114,101,99,117,114,115,105,118,101,45,97,116,111,109,105,99,45,104,97,115,104,32,111,98,106,53,52,52,32,100,101,112,116,104,53,52,53,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,32),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,53,55,55,32,100,101,112,116,104,53,55,56,41};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,21),40,42,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,53,50,52,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,32),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,54,56,52,32,46,32,116,109,112,54,56,51,54,56,53,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,55,52,51,32,115,116,97,114,116,55,53,50,32,101,110,100,55,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,55,52,54,32,37,115,116,97,114,116,55,52,49,55,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,55,52,53,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,55,49,55,32,46,32,116,109,112,55,49,54,55,49,56,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,56,50,50,32,115,116,97,114,116,56,51,49,32,101,110,100,56,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,56,50,53,32,37,115,116,97,114,116,56,50,48,56,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,56,50,52,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,35),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,55,57,54,32,46,32,116,109,112,55,57,53,55,57,55,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,56,57,49,32,114,101,113,56,57,50,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,86),40,42,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,57,49,56,32,104,97,115,104,57,49,57,32,108,101,110,57,50,48,32,109,105,110,45,108,111,97,100,57,50,49,32,109,97,120,45,108,111,97,100,57,50,50,32,105,110,105,116,105,97,108,57,50,53,32,116,109,112,57,49,55,57,50,54,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,20),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,49,48,52,48,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,8),40,102,95,51,53,52,56,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,48,51,51,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,57,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,21),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,49,48,57,56,41,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,49,49,48,50,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,49,49,48,55,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,49,49,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,49,49,49,55,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,49,49,50,50,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,29),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,49,49,50,55,41,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,49,49,51,50,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,49,49,51,55,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,49,49,52,52,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,49,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,54,48,32,105,49,49,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,114,101,115,105,122,101,33,32,104,116,49,49,57,50,32,118,101,99,49,49,57,51,32,108,101,110,49,49,57,52,41,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,22),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,49,50,51,49,41,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,50,49,57,32,105,49,50,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,25),40,42,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,49,50,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,49,50,52,50,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,51,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,51,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,50,54,53,32,102,117,110,99,49,50,55,53,32,116,104,117,110,107,49,50,55,54,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,8),40,102,95,52,50,54,55,41};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,116,104,117,110,107,49,50,54,56,32,37,102,117,110,99,49,50,54,51,49,51,52,53,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,102,117,110,99,49,50,54,55,41,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,49),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,49,50,53,52,32,107,101,121,49,50,53,53,32,46,32,116,109,112,49,50,53,51,49,50,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,52,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,52,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,61),40,42,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,51,55,48,32,107,101,121,49,51,55,49,32,102,117,110,99,49,51,55,50,32,100,101,102,49,51,55,51,41,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,60),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,49,52,51,57,32,107,101,121,49,52,52,48,32,102,117,110,99,49,52,52,49,32,100,101,102,49,52,52,50,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,52,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,52,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,49,52,52,57,32,107,101,121,49,52,53,48,32,118,97,108,49,52,53,49,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,53,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,47),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,49,53,53,57,32,107,101,121,49,53,54,48,32,100,101,102,49,53,54,49,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,54,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,49,53,57,50,32,107,101,121,49,53,57,51,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,54,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,54,55,51,32,98,117,99,107,101,116,49,54,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,49,54,52,48,32,107,101,121,49,54,52,49,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,55,49,48,32,98,117,99,107,101,116,49,55,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,54,57,56,32,105,49,55,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,36),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,49,54,56,56,32,102,117,110,99,49,54,56,57,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,49,55,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,55,53,50,32,108,115,116,49,55,53,57,41,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,55,52,51,32,105,49,55,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,36),40,42,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,55,51,53,32,104,116,50,49,55,51,54,41,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,55,55,50,32,104,116,50,49,55,55,51,41,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,49,55,55,57,32,104,116,50,49,55,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,56,48,49,32,108,115,116,49,56,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,55,57,54,32,108,115,116,49,55,57,55,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,49,55,56,54,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,13),40,97,53,51,55,48,32,120,49,56,49,57,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,40),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,49,56,49,52,32,46,32,114,101,115,116,49,56,49,53,41};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,56,52,49,32,108,115,116,49,56,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,56,51,54,32,108,115,116,49,56,51,55,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,49,56,50,54,41};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,56,54,56,32,108,115,116,49,56,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,56,54,51,32,108,115,116,49,56,54,52,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,49,56,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,18),40,97,53,53,52,56,32,98,117,99,107,101,116,49,56,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,56,56,56,32,105,49,56,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,38),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,56,56,48,32,112,114,111,99,49,56,56,49,41,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,26),40,102,111,108,100,50,32,98,117,99,107,101,116,49,57,50,50,32,97,99,99,49,57,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,57,49,55,32,97,99,99,49,57,49,56,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,43),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,57,48,53,32,102,117,110,99,49,57,48,54,32,105,110,105,116,49,57,48,55,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,42),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,57,51,51,32,102,117,110,99,49,57,51,52,32,105,110,105,116,49,57,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,57,52,49,32,112,114,111,99,49,57,52,50,41,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,49,57,52,56,32,112,114,111,99,49,57,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,25),40,97,53,54,56,48,32,107,49,57,53,56,32,118,49,57,53,57,32,97,49,57,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,49,57,53,53,32,102,117,110,99,49,57,53,54,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,53,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,53,52,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,8),40,102,95,53,56,49,49,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,36),40,97,53,54,57,48,32,104,116,49,53,49,52,32,107,101,121,49,53,49,53,32,46,32,116,109,112,49,53,49,51,49,53,49,54,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5811)
static void C_ccall f_5811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5713)
static void C_ccall f_5713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_fcall f_5770(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_fcall f_5728(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5676)
static void C_ccall f_5676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5633)
static void C_ccall f_5633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_fcall f_5567(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5579)
static void C_fcall f_5579(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5595)
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_fcall f_5518(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5530)
static void C_fcall f_5530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5549)
static void C_ccall f_5549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5468)
static void C_fcall f_5468(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5484)
static void C_fcall f_5484(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5403)
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5419)
static void C_fcall f_5419(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5359)
static void C_ccall f_5359r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5369)
static void C_ccall f_5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5301)
static void C_fcall f_5301(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5317)
static void C_fcall f_5317(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5258)
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5193)
static void C_fcall f_5193(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5205)
static void C_fcall f_5205(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5228)
static void C_fcall f_5228(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5184)
static void C_ccall f_5184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5081)
static void C_ccall f_5081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_fcall f_5102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5128)
static void C_fcall f_5128(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4986)
static C_word C_fcall f_4986(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_fcall f_4913(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static C_word C_fcall f_4873(C_word t0,C_word t1);
C_noret_decl(f_4736)
static void C_ccall f_4736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static C_word C_fcall f_4767(C_word t0,C_word t1);
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_fcall f_4695(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4567)
static void C_ccall f_4567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_fcall f_4648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_fcall f_4599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_fcall f_4320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4490)
static void C_fcall f_4490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_fcall f_4433(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4374)
static void C_fcall f_4374(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_ccall f_4384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4272)
static void C_fcall f_4272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_fcall f_4032(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_fcall f_4219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_fcall f_4095(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3909)
static void C_fcall f_3909(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_fcall f_3924(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3986)
static void C_fcall f_3986(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_fcall f_3816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3839)
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3826)
static void C_ccall f_3826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3750)
static void C_ccall f_3750(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_fcall f_3423(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_fcall f_3426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3652)
static void C_ccall f_3652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_fcall f_3429(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_fcall f_3475(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_fcall f_3442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static C_word C_fcall f_3347(C_word t0);
C_noret_decl(f_3314)
static void C_fcall f_3314(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_fcall f_3284(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3290)
static C_word C_fcall f_3290(C_word t0,C_word t1);
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3222)
static void C_fcall f_3222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_fcall f_3213(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3194)
static void C_fcall f_3194(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3198)
static void C_ccall f_3198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_ccall f_3173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3097)
static void C_fcall f_3097(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3088)
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3069)
static void C_fcall f_3069(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3076)
static void C_ccall f_3076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_ccall f_3048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2649)
static void C_fcall f_2649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_fcall f_2748(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_fcall f_2717(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2733)
static void C_fcall f_2733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_fcall f_2652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2669)
static void C_fcall f_2669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_fcall f_2051(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5770)
static void C_fcall trf_5770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5770(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5770(t0,t1,t2);}

C_noret_decl(trf_5728)
static void C_fcall trf_5728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5728(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5728(t0,t1,t2);}

C_noret_decl(trf_5567)
static void C_fcall trf_5567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5567(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5567(t0,t1,t2,t3);}

C_noret_decl(trf_5579)
static void C_fcall trf_5579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5579(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5579(t0,t1,t2,t3);}

C_noret_decl(trf_5595)
static void C_fcall trf_5595(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5595(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5595(t0,t1,t2,t3);}

C_noret_decl(trf_5518)
static void C_fcall trf_5518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5518(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5518(t0,t1,t2);}

C_noret_decl(trf_5530)
static void C_fcall trf_5530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5530(t0,t1,t2);}

C_noret_decl(trf_5468)
static void C_fcall trf_5468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5468(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5468(t0,t1,t2,t3);}

C_noret_decl(trf_5484)
static void C_fcall trf_5484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5484(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5484(t0,t1,t2,t3);}

C_noret_decl(trf_5403)
static void C_fcall trf_5403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5403(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5403(t0,t1,t2,t3);}

C_noret_decl(trf_5419)
static void C_fcall trf_5419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5419(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5419(t0,t1,t2,t3);}

C_noret_decl(trf_5301)
static void C_fcall trf_5301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5301(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5301(t0,t1,t2,t3);}

C_noret_decl(trf_5317)
static void C_fcall trf_5317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5317(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5317(t0,t1,t2,t3);}

C_noret_decl(trf_5193)
static void C_fcall trf_5193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5193(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5193(t0,t1,t2);}

C_noret_decl(trf_5205)
static void C_fcall trf_5205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5205(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5205(t0,t1,t2);}

C_noret_decl(trf_5228)
static void C_fcall trf_5228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5228(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5228(t0,t1,t2);}

C_noret_decl(trf_5102)
static void C_fcall trf_5102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5102(t0,t1,t2);}

C_noret_decl(trf_5128)
static void C_fcall trf_5128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5128(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5128(t0,t1,t2,t3);}

C_noret_decl(trf_5033)
static void C_fcall trf_5033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5033(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5033(t0,t1,t2,t3);}

C_noret_decl(trf_4913)
static void C_fcall trf_4913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4913(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4913(t0,t1,t2);}

C_noret_decl(trf_4806)
static void C_fcall trf_4806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4806(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4806(t0,t1,t2);}

C_noret_decl(trf_4695)
static void C_fcall trf_4695(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4695(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4695(t0,t1);}

C_noret_decl(trf_4648)
static void C_fcall trf_4648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4648(t0,t1,t2);}

C_noret_decl(trf_4599)
static void C_fcall trf_4599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4599(t0,t1,t2);}

C_noret_decl(trf_4320)
static void C_fcall trf_4320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4320(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4320(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4490)
static void C_fcall trf_4490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4490(t0,t1);}

C_noret_decl(trf_4433)
static void C_fcall trf_4433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4433(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4433(t0,t1,t2);}

C_noret_decl(trf_4374)
static void C_fcall trf_4374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4374(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4374(t0,t1,t2);}

C_noret_decl(trf_4272)
static void C_fcall trf_4272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4272(t0,t1);}

C_noret_decl(trf_4255)
static void C_fcall trf_4255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4255(t0,t1,t2);}

C_noret_decl(trf_4032)
static void C_fcall trf_4032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4032(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4032(t0,t1,t2,t3);}

C_noret_decl(trf_4219)
static void C_fcall trf_4219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4219(t0,t1);}

C_noret_decl(trf_4158)
static void C_fcall trf_4158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4158(t0,t1,t2);}

C_noret_decl(trf_4095)
static void C_fcall trf_4095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4095(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4095(t0,t1,t2);}

C_noret_decl(trf_3909)
static void C_fcall trf_3909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3909(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3909(t0,t1,t2);}

C_noret_decl(trf_3924)
static void C_fcall trf_3924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3924(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3924(t0,t1,t2);}

C_noret_decl(trf_3986)
static void C_fcall trf_3986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3986(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3986(t0,t1,t2);}

C_noret_decl(trf_3816)
static void C_fcall trf_3816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3816(t0,t1,t2);}

C_noret_decl(trf_3839)
static void C_fcall trf_3839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3839(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3839(t0,t1,t2);}

C_noret_decl(trf_3423)
static void C_fcall trf_3423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3423(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3423(t0,t1);}

C_noret_decl(trf_3426)
static void C_fcall trf_3426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3426(t0,t1);}

C_noret_decl(trf_3429)
static void C_fcall trf_3429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3429(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3429(t0,t1);}

C_noret_decl(trf_3464)
static void C_fcall trf_3464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3464(t0,t1,t2);}

C_noret_decl(trf_3475)
static void C_fcall trf_3475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3475(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3475(t0,t1,t2);}

C_noret_decl(trf_3442)
static void C_fcall trf_3442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3442(t0,t1);}

C_noret_decl(trf_3314)
static void C_fcall trf_3314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3314(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3314(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_3284)
static void C_fcall trf_3284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3284(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3284(t0,t1,t2);}

C_noret_decl(trf_3222)
static void C_fcall trf_3222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3222(t0,t1);}

C_noret_decl(trf_3213)
static void C_fcall trf_3213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3213(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3213(t0,t1,t2);}

C_noret_decl(trf_3194)
static void C_fcall trf_3194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3194(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3194(t0,t1,t2,t3);}

C_noret_decl(trf_3097)
static void C_fcall trf_3097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3097(t0,t1);}

C_noret_decl(trf_3088)
static void C_fcall trf_3088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3088(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3088(t0,t1,t2);}

C_noret_decl(trf_3069)
static void C_fcall trf_3069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3069(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3069(t0,t1,t2,t3);}

C_noret_decl(trf_2649)
static void C_fcall trf_2649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2649(t0,t1);}

C_noret_decl(trf_2748)
static void C_fcall trf_2748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2748(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2748(t0,t1,t2,t3);}

C_noret_decl(trf_2717)
static void C_fcall trf_2717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2717(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2717(t0,t1,t2,t3);}

C_noret_decl(trf_2733)
static void C_fcall trf_2733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2733(t0,t1);}

C_noret_decl(trf_2652)
static void C_fcall trf_2652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2652(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2652(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2669)
static void C_fcall trf_2669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2669(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2669(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2051)
static void C_fcall trf_2051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2051(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2051(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(943)){
C_save(t1);
C_rereclaim2(943*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,116);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysnumber-hash-hook");
lf[4]=C_h_intern(&lf[4],11,"number-hash");
lf[5]=C_h_intern(&lf[5],5,"fxmod");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],5,"\000type");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_h_intern(&lf[10],15,"object-uid-hash");
lf[11]=C_h_intern(&lf[11],11,"symbol-hash");
lf[12]=C_h_intern(&lf[12],17,"\003syscheck-keyword");
lf[13]=C_h_intern(&lf[13],11,"\000type-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[15]=C_h_intern(&lf[15],8,"keyword\077");
lf[16]=C_h_intern(&lf[16],12,"keyword-hash");
lf[17]=C_h_intern(&lf[17],8,"eq\077-hash");
lf[18]=C_h_intern(&lf[18],16,"hash-by-identity");
lf[19]=C_h_intern(&lf[19],9,"eqv\077-hash");
lf[20]=C_h_intern(&lf[20],11,"input-port\077");
lf[21]=C_h_intern(&lf[21],11,"equal\077-hash");
lf[22]=C_h_intern(&lf[22],4,"hash");
lf[23]=C_h_intern(&lf[23],11,"string-hash");
lf[24]=C_h_intern(&lf[24],13,"\003syssubstring");
lf[25]=C_h_intern(&lf[25],15,"\003syscheck-range");
lf[26]=C_h_intern(&lf[26],14,"string-ci-hash");
lf[27]=C_h_intern(&lf[27],14,"string-hash-ci");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[31]=C_h_intern(&lf[31],11,"make-vector");
lf[33]=C_h_intern(&lf[33],10,"hash-table");
lf[34]=C_h_intern(&lf[34],3,"eq\077");
lf[35]=C_h_intern(&lf[35],4,"eqv\077");
lf[36]=C_h_intern(&lf[36],6,"equal\077");
lf[37]=C_h_intern(&lf[37],8,"string=\077");
lf[38]=C_h_intern(&lf[38],11,"string-ci=\077");
lf[39]=C_h_intern(&lf[39],1,"=");
lf[40]=C_h_intern(&lf[40],15,"make-hash-table");
lf[41]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[42]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[43]=C_h_intern(&lf[43],7,"warning");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[45]=C_h_intern(&lf[45],5,"error");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[47]=C_h_intern(&lf[47],5,"\000test");
lf[48]=C_h_intern(&lf[48],17,"\003syscheck-closure");
lf[49]=C_h_intern(&lf[49],5,"\000hash");
lf[50]=C_h_intern(&lf[50],5,"\000size");
lf[51]=C_h_intern(&lf[51],19,"hash-table-max-size");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[53]=C_h_intern(&lf[53],8,"\000initial");
lf[54]=C_h_intern(&lf[54],9,"\000min-load");
lf[55]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[56]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[58]=C_h_intern(&lf[58],17,"\003syscheck-inexact");
lf[59]=C_h_intern(&lf[59],9,"\000max-load");
lf[60]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[61]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[63]=C_h_intern(&lf[63],10,"\000weak-keys");
lf[64]=C_h_intern(&lf[64],12,"\000weak-values");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[69]=C_h_intern(&lf[69],11,"hash-table\077");
lf[70]=C_h_intern(&lf[70],15,"hash-table-size");
lf[71]=C_h_intern(&lf[71],31,"hash-table-equivalence-function");
lf[72]=C_h_intern(&lf[72],24,"hash-table-hash-function");
lf[73]=C_h_intern(&lf[73],19,"hash-table-min-load");
lf[74]=C_h_intern(&lf[74],19,"hash-table-max-load");
lf[75]=C_h_intern(&lf[75],20,"hash-table-weak-keys");
lf[76]=C_h_intern(&lf[76],22,"hash-table-weak-values");
lf[77]=C_h_intern(&lf[77],23,"hash-table-has-initial\077");
lf[78]=C_h_intern(&lf[78],18,"hash-table-initial");
lf[79]=C_h_intern(&lf[79],18,"hash-table-resize!");
lf[81]=C_h_intern(&lf[81],15,"hash-table-copy");
lf[82]=C_h_intern(&lf[82],18,"hash-table-update!");
lf[83]=C_h_intern(&lf[83],5,"floor");
lf[84]=C_h_intern(&lf[84],13,"\000access-error");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[86]=C_h_intern(&lf[86],8,"identity");
lf[88]=C_h_intern(&lf[88],26,"hash-table-update!/default");
lf[89]=C_h_intern(&lf[89],15,"hash-table-set!");
lf[90]=C_h_intern(&lf[90],19,"\003sysundefined-value");
lf[91]=C_h_intern(&lf[91],14,"hash-table-ref");
lf[92]=C_h_intern(&lf[92],22,"hash-table-ref/default");
lf[93]=C_h_intern(&lf[93],18,"hash-table-exists\077");
lf[94]=C_h_intern(&lf[94],18,"hash-table-delete!");
lf[95]=C_h_intern(&lf[95],18,"hash-table-remove!");
lf[96]=C_h_intern(&lf[96],17,"hash-table-clear!");
lf[97]=C_h_intern(&lf[97],12,"vector-fill!");
lf[99]=C_h_intern(&lf[99],17,"hash-table-merge!");
lf[100]=C_h_intern(&lf[100],16,"hash-table-merge");
lf[101]=C_h_intern(&lf[101],17,"hash-table->alist");
lf[102]=C_h_intern(&lf[102],17,"alist->hash-table");
lf[103]=C_h_intern(&lf[103],12,"\003sysfor-each");
lf[104]=C_h_intern(&lf[104],15,"hash-table-keys");
lf[105]=C_h_intern(&lf[105],17,"hash-table-values");
lf[108]=C_h_intern(&lf[108],15,"hash-table-fold");
lf[109]=C_h_intern(&lf[109],19,"hash-table-for-each");
lf[110]=C_h_intern(&lf[110],15,"hash-table-walk");
lf[111]=C_h_intern(&lf[111],14,"hash-table-map");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[113]=C_h_intern(&lf[113],18,"getter-with-setter");
lf[114]=C_h_intern(&lf[114],17,"register-feature!");
lf[115]=C_h_intern(&lf[115],7,"srfi-69");
C_register_lf2(lf,116,create_ptable());
t2=C_mutate(&lf[0] /* (set! c141 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2030,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 65   register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t3,lf[115]);}

/* k2028 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[114],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2038,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[10]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[11]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2222,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[12]+1 /* (set! check-keyword ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2273,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[16]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[17]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[18]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[17]+1));
t10=C_mutate((C_word*)lf[19]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2601,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[3] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2649,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[21]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[22]+1 /* (set! hash ...) */,*((C_word*)lf[21]+1));
t14=C_mutate((C_word*)lf[23]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3032,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[26]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[27]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[26]+1));
t17=C_mutate(&lf[28] /* (set! constant883 ...) */,lf[29]);
t18=C_mutate(&lf[30] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[31]+1);
t20=C_mutate(&lf[32] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3314,a[2]=t19,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[34]+1);
t22=*((C_word*)lf[35]+1);
t23=*((C_word*)lf[36]+1);
t24=*((C_word*)lf[37]+1);
t25=*((C_word*)lf[38]+1);
t26=*((C_word*)lf[39]+1);
t27=C_mutate((C_word*)lf[40]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3345,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,a[8]=((C_word)li28),tmp=(C_word)a,a+=9,tmp));
t28=C_mutate((C_word*)lf[69]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3708,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[70]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3714,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3723,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3732,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3741,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3750,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3759,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[76]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3768,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3777,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[78]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3789,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[79]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3883,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t39=*((C_word*)lf[31]+1);
t40=C_mutate(&lf[80] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=t39,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[81]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[34]+1);
t43=C_mutate((C_word*)lf[82]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4030,a[2]=t42,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp));
t44=*((C_word*)lf[34]+1);
t45=C_mutate(&lf[87] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4320,a[2]=t44,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t47=*((C_word*)lf[34]+1);
t48=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=t47,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[34]+1);
t51=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5691,a[2]=t50,a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 808  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),t49,t51,*((C_word*)lf[89]+1));}

/* a5690 in k2028 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_5691r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5691r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5691r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5695,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_5695(2,t6,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5811,a[2]=t2,a[3]=t3,a[4]=((C_word)li102),tmp=(C_word)a,a+=5,tmp));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_5695(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* f_5811 in a5690 in k2028 */
static void C_ccall f_5811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5811,2,t0,t1);}
/* srfi-69.scm: 811  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[84],lf[91],lf[112],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5693 in a5690 in k2028 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5695,2,t0,t1);}
t2=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[33],lf[91]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 815  ##sys#check-closure */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[91]);}

/* k5699 in k5693 in a5690 in k2028 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5713,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_block_size(t2);
/* srfi-69.scm: 819  hash */
t7=t4;
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5711 in k5699 in k5693 in a5690 in k2028 */
static void C_ccall f_5713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5713,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5728,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5728(t7,((C_word*)t0)[2],t3);}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5770(t7,((C_word*)t0)[2],t3);}}

/* loop in k5711 in k5699 in k5693 in a5690 in k2028 */
static void C_fcall f_5770(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5770,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 832  def */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 834  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5787 in loop in k5711 in k5699 in k5693 in a5690 in k2028 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 836  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5770(t3,((C_word*)t0)[5],t2);}}

/* loop in k5711 in k5699 in k5693 in a5690 in k2028 */
static void C_fcall f_5728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5728,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-69.scm: 824  def */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 828  loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4732 in k2028 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[58],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[34]+1);
t4=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4736,a[2]=t3,a[3]=((C_word)li62),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[34]+1);
t6=C_mutate((C_word*)lf[93]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4842,a[2]=t5,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[34]+1);
t8=C_mutate((C_word*)lf[94]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4950,a[2]=t7,a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5081,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[96]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5177,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[98] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5193,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[99]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5258,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[100]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5270,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[101]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[40]+1);
t16=C_mutate((C_word*)lf[102]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5359,a[2]=t15,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5388,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[105]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5453,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[106] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5518,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[107] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5567,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[108]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5633,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[109]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5645,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[110]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5657,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[111]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5669,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t25=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4732 in k2028 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5669,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[111]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5676,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1088 ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[111]);}

/* k5674 in hash-table-map in k4732 in k2028 */
static void C_ccall f_5676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5681,a[2]=((C_word*)t0)[4],a[3]=((C_word)li98),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1089 *hash-table-fold */
f_5567(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5680 in k5674 in hash-table-map in k4732 in k2028 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5681,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5689,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 1089 func */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5687 in a5680 in k5674 in hash-table-map in k4732 in k2028 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5689,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4732 in k2028 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5657,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[110]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5664,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1083 ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[110]);}

/* k5662 in hash-table-walk in k4732 in k2028 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1084 *hash-table-for-each */
f_5518(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4732 in k2028 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5645,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[109]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5652,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 1078 ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[109]);}

/* k5650 in hash-table-for-each in k4732 in k2028 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1079 *hash-table-for-each */
f_5518(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4732 in k2028 */
static void C_ccall f_5633(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5633,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[33],lf[108]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5640,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 1073 ##sys#check-closure */
t7=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[108]);}

/* k5638 in hash-table-fold in k4732 in k2028 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1074 *hash-table-fold */
f_5567(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k4732 in k2028 */
static void C_fcall f_5567(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5567,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5579,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,a[6]=((C_word)li93),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_5579(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k4732 in k2028 */
static void C_fcall f_5579(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5579,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word)li92),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5595(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k4732 in k2028 */
static void C_fcall f_5595(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5595,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 1066 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5579(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5623,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 1069 func */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,t3);}}

/* k5621 in fold2 in loop in *hash-table-fold in k4732 in k2028 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 1068 fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5595(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k4732 in k2028 */
static void C_fcall f_5518(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5518,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5530,a[2]=t4,a[3]=t3,a[4]=t7,a[5]=t5,a[6]=((C_word)li90),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5530(t9,t1,C_fix(0));}

/* doloop1888 in *hash-table-for-each in k4732 in k2028 */
static void C_fcall f_5530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5530,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5540,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5549,a[2]=((C_word*)t0)[3],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* srfi-69.scm: 1053 ##sys#for-each */
t6=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a5548 in doloop1888 in *hash-table-for-each in k4732 in k2028 */
static void C_ccall f_5549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5549,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1054 proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k5538 in doloop1888 in *hash-table-for-each in k4732 in k2028 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5530(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4732 in k2028 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5453,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[105]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5468,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li87),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5468(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4732 in k2028 */
static void C_fcall f_5468(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5468,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5484,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li86),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5484(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4732 in k2028 */
static void C_fcall f_5484(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5484,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1036 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5468(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1037 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4732 in k2028 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5388,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[104]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5403,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5403(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4732 in k2028 */
static void C_fcall f_5403(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5403,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5419,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li83),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5419(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4732 in k2028 */
static void C_fcall f_5419(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5419,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 1021 loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5403(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm: 1022 loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4732 in k2028 */
static void C_ccall f_5359(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5359r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5359r(t0,t1,t2,t3);}}

static void C_ccall f_5359r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_list_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5366,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,((C_word*)t0)[2],t3);}

/* k5364 in alist->hash-table in k4732 in k2028 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5369,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5371,a[2]=t1,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5370 in k5364 in alist->hash-table in k4732 in k2028 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5371,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[102]);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 1005 *hash-table-update!/default */
t6=lf[87];
f_4320(t6,t1,((C_word*)t0)[2],t4,*((C_word*)lf[86]+1),t5);}

/* k5367 in k5364 in alist->hash-table in k4732 in k2028 */
static void C_ccall f_5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4732 in k2028 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5286,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[101]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5301,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li79),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5301(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4732 in k2028 */
static void C_fcall f_5301(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5301,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5317,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5317(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4732 in k2028 */
static void C_fcall f_5317(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5317,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 992  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5301(t5,t1,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_slot(t5,C_fix(0));
t7=(C_word)C_slot(t5,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm: 993  loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4732 in k2028 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5270,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[100]);
t5=(C_word)C_i_check_structure_2(t3,lf[33],lf[100]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5284,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 978  *hash-table-copy */
t7=lf[80];
f_3909(t7,t6,t2);}

/* k5282 in hash-table-merge in k4732 in k2028 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 978  *hash-table-merge! */
f_5193(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4732 in k2028 */
static void C_ccall f_5258(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5258,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[99]);
t5=(C_word)C_i_check_structure_2(t3,lf[33],lf[99]);
/* srfi-69.scm: 973  *hash-table-merge! */
f_5193(t1,t2,t3);}

/* *hash-table-merge! in k4732 in k2028 */
static void C_fcall f_5193(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5193,NULL,3,t1,t2,t3);}
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5205,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5205(t9,t1,C_fix(0));}

/* doloop1743 in *hash-table-merge! in k4732 in k2028 */
static void C_fcall f_5205(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5205,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5215,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5228(t8,t3,t4);}}

/* doloop1752 in doloop1743 in *hash-table-merge! in k4732 in k2028 */
static void C_fcall f_5228(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5228,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5241,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 968  *hash-table-update!/default */
t7=lf[87];
f_4320(t7,t4,((C_word*)t0)[2],t5,*((C_word*)lf[86]+1),t6);}}

/* k5239 in doloop1752 in doloop1743 in *hash-table-merge! in k4732 in k2028 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5228(t3,((C_word*)t0)[2],t2);}

/* k5213 in doloop1743 in *hash-table-merge! in k4732 in k2028 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5205(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4732 in k2028 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5177,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5184,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 955  vector-fill! */
t6=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k5182 in hash-table-clear! in k4732 in k2028 */
static void C_ccall f_5184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4732 in k2028 */
static void C_ccall f_5081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5081,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[95]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5088,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 932  ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[95]);}

/* k5086 in hash-table-remove! in k4732 in k2028 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5088,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_block_size(t2);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5102,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word)li70),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_5102(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1698 in k5086 in hash-table-remove! in k4732 in k2028 */
static void C_fcall f_5102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5102,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5115,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word)li69),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_5128(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1698 in k5086 in hash-table-remove! in k4732 in k2028 */
static void C_fcall f_5128(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5128,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5147,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
t8=(C_word)C_slot(t4,C_fix(1));
/* srfi-69.scm: 942  func */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}

/* k5145 in loop in doloop1698 in k5086 in hash-table-remove! in k4732 in k2028 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 949  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5128(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k5113 in doloop1698 in k5086 in hash-table-remove! in k4732 in k2028 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5102(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4732 in k2028 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4950,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[94]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_block_size(t5);
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4966,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 896  hash */
t9=t7;
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t3,t6);}

/* k4964 in hash-table-delete! in k4732 in k2028 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[5],t1);
t6=(C_word)C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4986,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li66),tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4986(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word)li67),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_5033(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4964 in hash-table-delete! in k4732 in k2028 */
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5033,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5052,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
/* srfi-69.scm: 919  test */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k5050 in loop in k4964 in hash-table-delete! in k4732 in k2028 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?(C_word)C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):(C_word)C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=(C_word)C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm: 926  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5033(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4964 in hash-table-delete! in k4732 in k2028 */
static C_word C_fcall f_4986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?(C_word)C_i_setslot(t1,C_fix(1),t4):(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4732 in k2028 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4842,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(t2,lf[33],lf[93]);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(3));
t7=(C_word)C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4858,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_block_size(t5);
/* srfi-69.scm: 872  hash */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k4856 in hash-table-exists? in k4732 in k2028 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4858,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[3],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4873(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4913(t7,((C_word*)t0)[2],t3);}}

/* loop in k4856 in hash-table-exists? in k4732 in k2028 */
static void C_fcall f_4913(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4913,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 884  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4924 in loop in k4856 in hash-table-exists? in k4732 in k2028 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 885  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4913(t3,((C_word*)t0)[4],t2);}}

/* loop in k4856 in hash-table-exists? in k4732 in k2028 */
static C_word C_fcall f_4873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4732 in k2028 */
static void C_ccall f_4736(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4736,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[33],lf[92]);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(3));
t8=(C_word)C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4752,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_block_size(t6);
/* srfi-69.scm: 846  hash */
t11=t8;
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t3,t10);}

/* k4750 in hash-table-ref/default in k4732 in k2028 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4767(t4,t3));}
else{
t3=(C_word)C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4806(t7,((C_word*)t0)[2],t3);}}

/* loop in k4750 in hash-table-ref/default in k4732 in k2028 */
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4806,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 861  test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4820 in loop in k4750 in hash-table-ref/default in k4732 in k2028 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 863  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4806(t3,((C_word*)t0)[5],t2);}}

/* loop in k4750 in hash-table-ref/default in k4732 in k2028 */
static C_word C_fcall f_4767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return((C_word)C_slot(t2,C_fix(1)));}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-set! in k2028 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4539,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(t2,lf[33],lf[89]);
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4722,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t7,a[7]=t4,a[8]=t3,a[9]=((C_word*)t0)[2],a[10]=t1,a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k4720 in hash-table-set! in k2028 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4714,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4712 in k4720 in hash-table-set! in k2028 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[6]);
t6=t4;
f_4695(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[6],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4695(t5,C_SCHEME_FALSE);}}

/* k4693 in k4712 in k4720 in hash-table-set! in k2028 */
static void C_fcall f_4695(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[79]+1)))(5,*((C_word*)lf[79]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4567(2,t2,C_SCHEME_UNDEFINED);}}

/* k4565 in k4712 in k4720 in hash-table-set! in k2028 */
static void C_ccall f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 780  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k4580 in k4565 in k4712 in k4720 in hash-table-set! in k2028 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4582,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4599,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word)li57),tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_4599(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word)li58),tmp=(C_word)a,a+=12,tmp));
t8=((C_word*)t6)[1];
f_4648(t8,t3,t2);}}

/* loop in k4580 in k4565 in k4712 in k4720 in hash-table-set! in k2028 */
static void C_fcall f_4648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4648,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=(C_word)C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 800  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k4676 in loop in k4580 in k4565 in k4712 in k4720 in hash-table-set! in k2028 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 802  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4648(t3,((C_word*)t0)[6],t2);}}

/* loop in k4580 in k4565 in k4712 in k4720 in hash-table-set! in k2028 */
static void C_fcall f_4599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4599,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 792  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4586 in k4580 in k4565 in k4712 in k4720 in hash-table-set! in k2028 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[90]+1));}

/* hash-table-update!/default in k2028 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4527,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_structure_2(t2,lf[33],lf[88]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4534,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm: 767  ##sys#check-closure */
t8=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t4,lf[88]);}

/* k4532 in hash-table-update!/default in k2028 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 768  *hash-table-update!/default */
t2=lf[87];
f_4320(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k2028 */
static void C_fcall f_4320(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4320,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_fixnum_plus(t6,C_fix(1));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(5));
t11=(C_word)C_slot(t8,C_fix(6));
t12=(C_word)C_block_size(t9);
t13=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4517,a[2]=t11,a[3]=t12,a[4]=t9,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t4,a[9]=t7,a[10]=t3,a[11]=((C_word*)t0)[2],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t14=(C_word)C_a_i_times(&a,2,t12,t10);
/* srfi-69.scm: 636  floor */
t15=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t13,t14);}

/* k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4509,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_4490(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4490(t5,C_SCHEME_FALSE);}}

/* k4488 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_fcall f_4490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[79]+1)))(5,*((C_word*)lf[79]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4345(2,t2,C_SCHEME_UNDEFINED);}}

/* k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4345,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 735  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4374,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li53),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4374(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li54),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4433(t7,((C_word*)t0)[2],t2);}}

/* loop in k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_fcall f_4433(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4433,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4443,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 754  func */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 759  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4464 in loop in k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4466,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 760  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 763  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4433(t3,((C_word*)t0)[5],t2);}}

/* k4467 in k4464 in loop in k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4441 in loop in k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_fcall f_4374(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4374,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4384,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm: 741  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 747  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 750  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4408 in loop in k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4382 in loop in k4358 in k4343 in k4507 in k4515 in *hash-table-update!/default in k2028 */
static void C_ccall f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-update! in k2028 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_4030r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4030r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4030r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4032,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li48),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4255,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4272,a[2]=t6,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-func12671357 */
t8=t7;
f_4272(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-thunk12681344 */
t10=t6;
f_4255(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body12651274 */
t12=t5;
f_4032(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-func1267 in hash-table-update! in k2028 */
static void C_fcall f_4272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4272,NULL,2,t0,t1);}
/* def-thunk12681344 */
t2=((C_word*)t0)[2];
f_4255(t2,t1,*((C_word*)lf[86]+1));}

/* def-thunk1268 in hash-table-update! in k2028 */
static void C_fcall f_4255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4255,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(9));
t4=(C_truep(t3)?t3:(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
/* body12651274 */
t5=((C_word*)t0)[2];
f_4032(t5,t1,t2,t4);}

/* f_4267 in def-thunk1268 in hash-table-update! in k2028 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
/* srfi-69.scm: 684  ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,lf[84],lf[82],lf[85],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body1265 in hash-table-update! in k2028 */
static void C_fcall f_4032(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4032,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_structure_2(((C_word*)t0)[4],lf[33],lf[82]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4039,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 688  ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[82]);}

/* k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 689  ##sys#check-closure */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[82]);}

/* k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(2));
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
t4=((C_word*)t0)[7];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_slot(t4,C_fix(5));
t7=(C_word)C_slot(t4,C_fix(6));
t8=(C_word)C_block_size(t5);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4246,a[2]=t7,a[3]=t8,a[4]=t5,a[5]=t4,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t3,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
t10=(C_word)C_a_i_times(&a,2,t8,t6);
/* srfi-69.scm: 636  floor */
t11=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}

/* k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4238,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-69.scm: 637  floor */
t5=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[3],C_fix(1073741823)))){
t5=(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[2],((C_word*)t0)[9]);
t6=t4;
f_4219(t6,(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[9],t2):C_SCHEME_FALSE));}
else{
t5=t4;
f_4219(t5,C_SCHEME_FALSE);}}

/* k4217 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_fcall f_4219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm: 640  hash-table-resize! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[79]+1)))(5,*((C_word*)lf[79]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4066(2,t2,C_SCHEME_UNDEFINED);}}

/* k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(4));
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t5=(C_word)C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm: 696  hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4081,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],t1);
t3=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4095,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li46),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4095(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4158,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li47),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4158(t7,((C_word*)t0)[2],t2);}}

/* loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_fcall f_4158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4158,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4168,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4186,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 715  thunk */
t5=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4195,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
/* srfi-69.scm: 720  test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4193 in loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm: 721  func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 724  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4158(t3,((C_word*)t0)[5],t2);}}

/* k4196 in k4193 in loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4184 in loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 715  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4166 in loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_fcall f_4095(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4095,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4105,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4123,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 702  thunk */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-69.scm: 708  func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 711  loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k4133 in loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4121 in loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 702  func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4103 in loop in k4079 in k4064 in k4236 in k4244 in k4040 in k4037 in body1265 in hash-table-update! in k2028 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* hash-table-copy in k2028 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4021,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[81]);
/* srfi-69.scm: 669  *hash-table-copy */
t4=lf[80];
f_3909(t4,t1,t2);}

/* *hash-table-copy in k2028 */
static void C_fcall f_3909(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3909,NULL,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3919,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 649  make-vector */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3917 in *hash-table-copy in k2028 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li43),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3924(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop1219 in k3917 in *hash-table-copy in k2028 */
static void C_fcall f_3924(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3924,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(3));
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(4));
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t7=(C_word)C_slot(((C_word*)t0)[5],C_fix(6));
t8=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t9=(C_word)C_slot(((C_word*)t0)[5],C_fix(8));
t10=(C_word)C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm: 652  *make-hash-table */
t11=lf[32];
f_3314(t11,t1,t3,t4,t5,t6,t7,t10,(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3980,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3986,a[2]=t6,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3986(t8,t3,t4);}}

/* copy-loop in doloop1219 in k3917 in *hash-table-copy in k2028 */
static void C_fcall f_3986(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3986,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4007,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* srfi-69.scm: 665  copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k4005 in copy-loop in doloop1219 in k3917 in *hash-table-copy in k2028 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3978 in doloop1219 in k3917 in *hash-table-copy in k2028 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3924(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k2028 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3883,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_times(t4,C_fix(2));
t6=(C_word)C_i_fixnum_min(C_fix(1073741823),t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3890,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 624  hash-table-canonical-length */
f_3284(t7,lf[28],t6);}

/* k3888 in hash-table-resize! in k2028 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 625  make-vector */
t3=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k3891 in k3888 in hash-table-resize! in k2028 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3896,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_block_size(t4);
t7=(C_word)C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3816,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,a[8]=((C_word)li40),tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_3816(t11,t2,C_fix(0));}

/* doloop1160 in k3891 in k3888 in hash-table-resize! in k2028 */
static void C_fcall f_3816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3816,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3826,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3839(t8,t3,t4);}}

/* loop in doloop1160 in k3891 in k3888 in hash-table-resize! in k2028 */
static void C_fcall f_3839(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3839,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3855,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm: 615  hash */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3853 in loop in doloop1160 in k3891 in k3888 in hash-table-resize! in k2028 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_slot(((C_word*)t0)[5],t1);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=(C_word)C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 618  loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3839(t8,((C_word*)t0)[2],t7);}

/* k3824 in doloop1160 in k3891 in k3888 in hash-table-resize! in k2028 */
static void C_ccall f_3826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3816(t3,((C_word*)t0)[2],t2);}

/* k3894 in k3891 in k3888 in hash-table-resize! in k2028 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k2028 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3789,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[78]);
t4=(C_word)C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm: 602  thunk */
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k2028 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3777,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[77]);
t4=(C_word)C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k2028 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3768,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k2028 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3759,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k2028 */
static void C_ccall f_3750(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3750,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k2028 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3741,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[73]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k2028 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3732,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k2028 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3723,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(3)));}

/* hash-table-size in k2028 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3714,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[33],lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(2)));}

/* hash-table? in k2028 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3708,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[33]));}

/* make-hash-table in k2028 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_3345r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3345r(t0,t1,t2);}}

static void C_ccall f_3345r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[36]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[41];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[42];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3423,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t8,a[9]=t6,a[10]=t1,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3423(t19,C_SCHEME_UNDEFINED);}
else{
t19=(C_word)C_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3698,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 481  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t20,t19);}}

/* k3696 in make-hash-table in k2028 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3698,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3423(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 482  ##sys#check-closure */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[40]);}}

/* k3699 in k3696 in make-hash-table in k2028 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3423(t5,t4);}

/* k3421 in make-hash-table in k2028 */
static void C_fcall f_3423(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3423,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3426(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 487  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k3676 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3678,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3426(t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 488  ##sys#check-closure */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[40]);}}

/* k3679 in k3676 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3426(t5,t4);}

/* k3424 in k3421 in make-hash-table in k2028 */
static void C_fcall f_3426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3426,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3429(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm: 493  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k3644 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3646,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3429(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[40]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3652,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_3652(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 496  error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[40],lf[68],((C_word*)t0)[4]);}}}

/* k3650 in k3644 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[51]+1),((C_word*)t0)[5]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
f_3429(t6,t5);}

/* k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_fcall f_3429(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3429,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t4,a[9]=((C_word*)t0)[3],a[10]=((C_word)li27),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_3464(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3464,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3485,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm: 506  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t5,t3);}}

/* k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=t3;
f_3491(2,t4,(C_word)C_i_car(t2));}
else{
/* srfi-69.scm: 510  invarg-err */
t4=((C_word*)t0)[2];
f_3475(t4,t3,lf[66]);}}
else{
/* srfi-69.scm: 542  invarg-err */
t2=((C_word*)t0)[2];
f_3475(t2,((C_word*)t0)[10],lf[67]);}}

/* k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3494,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[9],lf[47]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3507,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 513  ##sys#check-closure */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,lf[40]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[9],lf[49]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3517,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 516  ##sys#check-closure */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t1,lf[40]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[9],lf[50]);
if(C_truep(t5)){
t6=(C_word)C_i_check_exact_2(t1,lf[40]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3530,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_3530(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 521  error */
t8=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[40],lf[52],t1);}}
else{
t6=(C_word)C_eqp(((C_word*)t0)[9],lf[53]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3548,a[2]=t1,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp));
t8=t2;
f_3494(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[9],lf[54]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3558,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 526  ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),t8,t1,lf[40]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[9],lf[59]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3583,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 531  ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[58]+1)))(4,*((C_word*)lf[58]+1),t9,t1,lf[40]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[9],lf[63]);
if(C_truep(t9)){
t10=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t11=C_SCHEME_UNDEFINED;
t12=t2;
f_3494(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[9],lf[64]);
if(C_truep(t10)){
t11=(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE);
t12=C_SCHEME_UNDEFINED;
t13=t2;
f_3494(2,t13,t12);}
else{
/* srfi-69.scm: 540  invarg-err */
t11=((C_word*)t0)[2];
f_3475(t11,t2,lf[65]);}}}}}}}}}

/* k3581 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[60],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[61]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3586(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 533  error */
t5=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[40],lf[62],((C_word*)t0)[3]);}}

/* k3584 in k3581 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3494(2,t3,t2);}

/* k3556 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_flonum_lessp(lf[55],((C_word*)t0)[3]);
t4=(C_truep(t3)?(C_word)C_flonum_lessp(((C_word*)t0)[3],lf[56]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_3561(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 528  error */
t5=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[40],lf[57],((C_word*)t0)[3]);}}

/* k3559 in k3556 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3494(2,t3,t2);}

/* f_3548 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3548,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3528 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_fixnum_min(*((C_word*)lf[51]+1),((C_word*)t0)[4]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3494(2,t4,t3);}

/* k3515 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3494(2,t3,t2);}

/* k3505 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_3494(2,t3,t2);}

/* k3492 in k3489 in k3483 in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm: 541  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3464(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_fcall f_3475(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3475,NULL,3,t0,t1,t2);}
/* srfi-69.scm: 505  error */
t3=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[40],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3430 in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_flonum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* srfi-69.scm: 545  error */
t3=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[40],lf[46],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t2;
f_3435(2,t3,C_SCHEME_UNDEFINED);}}

/* k3433 in k3430 in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm: 547  hash-table-canonical-length */
f_3284(t2,lf[28],((C_word*)((C_word*)t0)[9])[1]);}

/* k3437 in k3433 in k3430 in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=t3;
f_3442(t4,C_SCHEME_UNDEFINED);}
else{
t4=f_3347(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=t3;
f_3442(t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 554  warning */
((C_proc4)C_retrieve_proc(*((C_word*)lf[43]+1)))(4,*((C_word*)lf[43]+1),t5,lf[40],lf[44]);}}}

/* k3453 in k3437 in k3433 in k3430 in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[21]+1));
t3=((C_word*)t0)[2];
f_3442(t3,t2);}

/* k3440 in k3437 in k3433 in k3430 in k3427 in k3424 in k3421 in make-hash-table in k2028 */
static void C_fcall f_3442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 557  *make-hash-table */
t2=lf[32];
f_3314(t2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k2028 */
static C_word C_fcall f_3347(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_stack_check;
t1=(C_word)C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:(C_word)C_eqp(*((C_word*)lf[34]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
return(*((C_word*)lf[17]+1));}
else{
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[19]+1));}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
return(*((C_word*)lf[21]+1));}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:(C_word)C_eqp(*((C_word*)lf[37]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[23]+1));}
else{
t9=(C_word)C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:(C_word)C_eqp(*((C_word*)lf[38]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
return(*((C_word*)lf[27]+1));}
else{
t11=(C_word)C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[7])[1]));
return((C_truep(t12)?*((C_word*)lf[4]+1):C_SCHEME_FALSE));}}}}}}

/* *make-hash-table in k2028 */
static void C_fcall f_3314(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3314,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3318,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
/* srfi-69.scm: 429  make-vector */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
t11=t9;
f_3318(2,t11,(C_word)C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[0],t8);}}}

/* k3316 in *make-hash-table in k2028 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,10,lf[33],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k2028 */
static void C_fcall f_3284(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3284,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3290,a[2]=t3,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3290(t4,t2));}

/* loop in hash-table-canonical-length in k2028 */
static C_word C_fcall f_3290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
t5=(C_truep(t4)?t4:(C_word)C_i_nullp(t3));
if(C_truep(t5)){
return(t2);}
else{
t7=t3;
t1=t7;
goto loop;}}

/* string-ci-hash in k2028 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3157r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3157r(t0,t1,t2,t3);}}

static void C_ccall f_3157r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_check_string_2(t2,lf[26]);
t9=(C_word)C_i_check_exact_2(t5,lf[26]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3173,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3194,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3213,a[2]=t11,a[3]=t2,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3222,a[2]=t12,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start824841 */
t14=t13;
f_3222(t14,t10);}
else{
t14=(C_word)C_i_car(t7);
t15=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end825837 */
t16=t12;
f_3213(t16,t10,t14);}
else{
t16=(C_word)C_i_car(t15);
t17=(C_word)C_i_cdr(t15);
if(C_truep((C_word)C_i_nullp(t17))){
/* body822830 */
t18=t11;
f_3194(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_3173(2,t11,t2);}}

/* def-start824 in string-ci-hash in k2028 */
static void C_fcall f_3222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3222,NULL,2,t0,t1);}
/* def-end825837 */
t2=((C_word*)t0)[2];
f_3213(t2,t1,C_fix(0));}

/* def-end825 in string-ci-hash in k2028 */
static void C_fcall f_3213(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3213,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body822830 */
t4=((C_word*)t0)[2];
f_3194(t4,t1,t2,t3);}

/* body822 in string-ci-hash in k2028 */
static void C_fcall f_3194(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3194,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3198,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 377  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t4,t2,C_fix(0),t5,lf[27]);}

/* k3196 in body822 in string-ci-hash in k2028 */
static void C_ccall f_3198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 378  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[27]);}

/* k3199 in k3196 in body822 in string-ci-hash in k2028 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 379  ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3171 in string-ci-hash in k2028 */
static void C_ccall f_3173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string_ci(t1);
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2);
t5=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t4);
/* srfi-69.scm: 137  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}

/* string-hash in k2028 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3032r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3032r(t0,t1,t2,t3);}}

static void C_ccall f_3032r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):(C_word)C_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t8=(C_word)C_i_check_string_2(t2,lf[23]);
t9=(C_word)C_i_check_exact_2(t5,lf[23]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3048,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3069,a[2]=t2,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3088,a[2]=t11,a[3]=t2,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=t12,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-start745762 */
t14=t13;
f_3097(t14,t10);}
else{
t14=(C_word)C_i_car(t7);
t15=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t15))){
/* def-end746758 */
t16=t12;
f_3088(t16,t10,t14);}
else{
t16=(C_word)C_i_car(t15);
t17=(C_word)C_i_cdr(t15);
if(C_truep((C_word)C_i_nullp(t17))){
/* body743751 */
t18=t11;
f_3069(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_3048(2,t11,t2);}}

/* def-start745 in string-hash in k2028 */
static void C_fcall f_3097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3097,NULL,2,t0,t1);}
/* def-end746758 */
t2=((C_word*)t0)[2];
f_3088(t2,t1,C_fix(0));}

/* def-end746 in string-hash in k2028 */
static void C_fcall f_3088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3088,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(((C_word*)t0)[3]);
/* body743751 */
t4=((C_word*)t0)[2];
f_3069(t4,t1,t2,t3);}

/* body743 in string-hash in k2028 */
static void C_fcall f_3069(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3069,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3073,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm: 365  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t4,t2,C_fix(0),t5,lf[23]);}

/* k3071 in body743 in string-hash in k2028 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm: 366  ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[23]);}

/* k3074 in k3071 in body743 in string-hash in k2028 */
static void C_ccall f_3076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm: 367  ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[24]+1)))(5,*((C_word*)lf[24]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3046 in string-hash in k2028 */
static void C_ccall f_3048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_hash_string(t1);
t3=(C_word)C_fixnum_lessp(t2,C_fix(0));
t4=(C_truep(t3)?(C_word)C_fixnum_negate(t2):t2);
t5=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t4);
/* srfi-69.scm: 137  fxmod */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],t5,((C_word*)t0)[2]);}

/* equal?-hash in k2028 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2983r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2983r(t0,t1,t2,t3);}}

static void C_ccall f_2983r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2987,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2987(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2987(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2985 in equal?-hash in k2028 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[22]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2993,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 353  *equal?-hash */
f_2649(t3,((C_word*)t0)[2]);}

/* k2991 in k2985 in equal?-hash in k2028 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 137  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* *equal?-hash in k2028 */
static void C_fcall f_2649(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2649,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2652,a[2]=t8,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2717,a[2]=t8,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2748,a[2]=t4,a[3]=t6,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm: 349  recursive-hash */
t12=((C_word*)t8)[1];
f_2748(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k2028 */
static void C_fcall f_2748(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2748,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep((C_word)C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep((C_word)C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_fix((C_word)C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_hash_string(t5));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
t4=t2;
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_fixnum_plus(t5,t25);
t27=t1;
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2885,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t4);}}
else{
t4=t2;
if(C_truep((C_word)C_blockp(t4))){
t5=t2;
if(C_truep((C_word)C_byteblockp(t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_hash_string(t6));}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=t2;
t7=(C_word)C_i_length(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2911,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 285  recursive-atomic-hash */
t10=((C_word*)((C_word*)t0)[3])[1];
f_2717(t10,t8,t9,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=t2;
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2940,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t6,C_fix(0));
/* srfi-69.scm: 288  recursive-atomic-hash */
t9=((C_word*)((C_word*)t0)[3])[1];
f_2717(t9,t7,t8,t3);}
else{
t6=t2;
if(C_truep((C_word)C_portp(t6))){
t7=t2;
t8=(C_word)C_peek_fixnum(t7,C_fix(0));
t9=(C_word)C_fixnum_shift_left(t8,C_fix(4));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2961,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 293  input-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t10,t7);}
else{
t7=t2;
if(C_truep((C_word)C_specialp(t7))){
t8=t2;
t9=(C_word)C_peek_fixnum(t8,C_fix(0));
/* srfi-69.scm: 298  vector-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2652(t10,t1,t8,t9,t3,C_fix(1));}
else{
t8=t2;
/* srfi-69.scm: 301  vector-hash */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2652(t9,t1,t8,C_fix(0),t3,C_fix(0));}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* k2959 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?C_fix(260):C_fix(261));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_plus(((C_word*)t0)[2],t2));}

/* k2938 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=(C_word)C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2932,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 289  recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2717(t5,t3,t4,((C_word*)t0)[2]);}

/* k2930 in k2938 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2909 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2883 in recursive-hash in *equal?-hash in k2028 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fix(t1));}

/* recursive-atomic-hash in *equal?-hash in k2028 */
static void C_fcall f_2717(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2717,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_symbolp(t4));
t7=(C_truep(t6)?t6:(C_word)C_i_numberp(t4));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t7)){
t9=t8;
f_2733(t9,t7);}
else{
t9=t2;
t10=t8;
f_2733(t10,(C_word)C_byteblockp(t9));}}

/* k2731 in recursive-atomic-hash in *equal?-hash in k2028 */
static void C_fcall f_2733(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm: 323  recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2748(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k2028 */
static void C_fcall f_2652(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2652,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_plus(t6,t3);
t8=(C_word)C_i_fixnum_min(C_fix(4),t6);
t9=(C_word)C_fixnum_difference(t8,t5);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2669,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t11,a[6]=((C_word)li8),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_2669(t13,t1,t7,t5,t9);}

/* loop in vector-hash in *equal?-hash in k2028 */
static void C_fcall f_2669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2669,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_word)C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2703,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_slot(((C_word*)t0)[4],t3);
t9=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm: 315  recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2748(t10,t7,t8,t9);}}

/* k2701 in loop in vector-hash in *equal?-hash in k2028 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[7],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm: 313  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2669(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k2028 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2601r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2601r(t0,t1,t2,t3);}}

static void C_ccall f_2601r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2605,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2605(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2605(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2603 in eqv?-hash in k2028 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2605,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[19]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2611,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
f_2611(2,t5,t4);}
else{
if(C_truep((C_word)C_charp(t4))){
t5=t3;
f_2611(2,t5,(C_word)C_fix((C_word)C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_2611(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_2611(2,t5,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2611(2,t5,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t4))){
t5=t3;
f_2611(2,t5,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_2611(2,t6,(C_word)C_hash_string(t5));}
else{
if(C_truep((C_word)C_i_numberp(t4))){
if(C_truep((C_word)C_i_flonump(t4))){
t5=(C_word)C_subbyte(t4,C_fix(7));
t6=(C_word)C_subbyte(t4,C_fix(6));
t7=(C_word)C_subbyte(t4,C_fix(5));
t8=(C_word)C_subbyte(t4,C_fix(4));
t9=(C_word)C_subbyte(t4,C_fix(3));
t10=(C_word)C_subbyte(t4,C_fix(2));
t11=(C_word)C_subbyte(t4,C_fix(1));
t12=(C_word)C_subbyte(t4,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_fixnum_plus(t5,t25);
t27=t3;
f_2611(2,t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t4);}}
else{
if(C_truep((C_word)C_blockp(t4))){
/* srfi-69.scm: 184  *equal?-hash */
f_2649(t3,t4);}
else{
t5=t3;
f_2611(2,t5,C_fix(262));}}}}}}}}}

/* k2588 in k2603 in eqv?-hash in k2028 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2611(2,t2,(C_word)C_fix(t1));}

/* k2609 in k2603 in eqv?-hash in k2028 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 137  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* eq?-hash in k2028 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2410r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2410r(t0,t1,t2,t3);}}

static void C_ccall f_2410r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2414,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2414(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2414(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2412 in eq?-hash in k2028 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[17]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2420,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep((C_word)C_fixnump(t4))){
t5=t3;
f_2420(2,t5,t4);}
else{
if(C_truep((C_word)C_charp(t4))){
t5=t3;
f_2420(2,t5,(C_word)C_fix((C_word)C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_2420(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_2420(2,t5,C_fix(257));
default:
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_2420(2,t5,C_fix(258));}
else{
if(C_truep((C_word)C_eofp(t4))){
t5=t3;
f_2420(2,t5,C_fix(259));}
else{
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
f_2420(2,t6,(C_word)C_hash_string(t5));}
else{
if(C_truep((C_word)C_blockp(t4))){
/* srfi-69.scm: 184  *equal?-hash */
f_2649(t3,t4);}
else{
t5=t3;
f_2420(2,t5,C_fix(262));}}}}}}}}

/* k2418 in k2412 in eq?-hash in k2028 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 137  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* keyword-hash in k2028 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2299r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2299r(t0,t1,t2,t3);}}

static void C_ccall f_2299r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2303(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2303(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2301 in keyword-hash in k2028 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 220  ##sys#check-keyword */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[3],lf[16]);}

/* k2304 in k2301 in keyword-hash in k2028 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[16]);
t3=((C_word*)t0)[3];
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_hash_string(t4);
t6=(C_word)C_fixnum_lessp(t5,C_fix(0));
t7=(C_truep(t6)?(C_word)C_fixnum_negate(t5):t5);
t8=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t7);
/* srfi-69.scm: 137  fxmod */
t9=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[2],t8,((C_word*)t0)[4]);}

/* ##sys#check-keyword in k2028 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2273r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2273r(t0,t1,t2,t3);}}

static void C_ccall f_2273r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm: 207  keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t2);}

/* k2278 in ##sys#check-keyword in k2028 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_vemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)));
/* srfi-69.scm: 208  ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],lf[13],t3,lf[14],((C_word*)t0)[2]);}}

/* symbol-hash in k2028 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2222r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2222r(t0,t1,t2,t3);}}

static void C_ccall f_2222r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2226,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2226(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2226(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2224 in symbol-hash in k2028 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[3],lf[11]);
t3=(C_word)C_i_check_exact_2(t1,lf[11]);
t4=((C_word*)t0)[3];
t5=(C_word)C_slot(t4,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=(C_word)C_fixnum_lessp(t6,C_fix(0));
t8=(C_truep(t7)?(C_word)C_fixnum_negate(t6):t6);
t9=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t8);
/* srfi-69.scm: 137  fxmod */
t10=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[2],t9,t1);}

/* object-uid-hash in k2028 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2174r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2174r(t0,t1,t2,t3);}}

static void C_ccall f_2174r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2178,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2178(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2178(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2176 in object-uid-hash in k2028 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[10]);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2184,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm: 184  *equal?-hash */
f_2649(t4,t3);}

/* k2182 in k2176 in object-uid-hash in k2028 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 137  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* number-hash in k2028 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2038r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2038r(t0,t1,t2,t3);}}

static void C_ccall f_2038r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2042(2,t5,C_fix(536870912));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2042(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2040 in number-hash in k2028 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[3]))){
t3=t2;
f_2045(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm: 173  ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[7],lf[4],lf[8],((C_word*)t0)[3]);}}

/* k2043 in k2040 in number-hash in k2028 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2045,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[4]);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t3))){
t5=t4;
f_2051(t5,t3);}
else{
if(C_truep((C_word)C_i_flonump(t3))){
t5=(C_word)C_subbyte(t3,C_fix(7));
t6=(C_word)C_subbyte(t3,C_fix(6));
t7=(C_word)C_subbyte(t3,C_fix(5));
t8=(C_word)C_subbyte(t3,C_fix(4));
t9=(C_word)C_subbyte(t3,C_fix(3));
t10=(C_word)C_subbyte(t3,C_fix(2));
t11=(C_word)C_subbyte(t3,C_fix(1));
t12=(C_word)C_subbyte(t3,C_fix(0));
t13=(C_word)C_fixnum_shift_left(t12,C_fix(1));
t14=(C_word)C_fixnum_plus(t11,t13);
t15=(C_word)C_fixnum_shift_left(t14,C_fix(1));
t16=(C_word)C_fixnum_plus(t10,t15);
t17=(C_word)C_fixnum_shift_left(t16,C_fix(1));
t18=(C_word)C_fixnum_plus(t9,t17);
t19=(C_word)C_fixnum_shift_left(t18,C_fix(1));
t20=(C_word)C_fixnum_plus(t8,t19);
t21=(C_word)C_fixnum_shift_left(t20,C_fix(1));
t22=(C_word)C_fixnum_plus(t7,t21);
t23=(C_word)C_fixnum_shift_left(t22,C_fix(1));
t24=(C_word)C_fixnum_plus(t6,t23);
t25=(C_word)C_fixnum_shift_left(t24,C_fix(1));
t26=(C_word)C_fixnum_plus(t5,t25);
t27=t4;
f_2051(t27,(C_word)C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm: 165  ##sys#number-hash-hook */
((C_proc3)C_retrieve_proc(*((C_word*)lf[2]+1)))(3,*((C_word*)lf[2]+1),t5,t3);}}}

/* k2145 in k2043 in k2040 in number-hash in k2028 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2051(t2,(C_word)C_fix(t1));}

/* k2049 in k2043 in k2040 in number-hash in k2028 */
static void C_fcall f_2051(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_lessp(t1,C_fix(0));
t3=(C_truep(t2)?(C_word)C_fixnum_negate(t1):t1);
t4=(C_word)C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_FIXNUM),t3);
/* srfi-69.scm: 137  fxmod */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* ##sys#number-hash-hook in k2028 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2032,3,t0,t1,t2);}
/* srfi-69.scm: 161  *equal?-hash */
f_2649(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[230] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_2030:srfi_69_scm",(void*)f_2030},
{"f_5691:srfi_69_scm",(void*)f_5691},
{"f_5811:srfi_69_scm",(void*)f_5811},
{"f_5695:srfi_69_scm",(void*)f_5695},
{"f_5701:srfi_69_scm",(void*)f_5701},
{"f_5713:srfi_69_scm",(void*)f_5713},
{"f_5770:srfi_69_scm",(void*)f_5770},
{"f_5789:srfi_69_scm",(void*)f_5789},
{"f_5728:srfi_69_scm",(void*)f_5728},
{"f_4734:srfi_69_scm",(void*)f_4734},
{"f_5669:srfi_69_scm",(void*)f_5669},
{"f_5676:srfi_69_scm",(void*)f_5676},
{"f_5681:srfi_69_scm",(void*)f_5681},
{"f_5689:srfi_69_scm",(void*)f_5689},
{"f_5657:srfi_69_scm",(void*)f_5657},
{"f_5664:srfi_69_scm",(void*)f_5664},
{"f_5645:srfi_69_scm",(void*)f_5645},
{"f_5652:srfi_69_scm",(void*)f_5652},
{"f_5633:srfi_69_scm",(void*)f_5633},
{"f_5640:srfi_69_scm",(void*)f_5640},
{"f_5567:srfi_69_scm",(void*)f_5567},
{"f_5579:srfi_69_scm",(void*)f_5579},
{"f_5595:srfi_69_scm",(void*)f_5595},
{"f_5623:srfi_69_scm",(void*)f_5623},
{"f_5518:srfi_69_scm",(void*)f_5518},
{"f_5530:srfi_69_scm",(void*)f_5530},
{"f_5549:srfi_69_scm",(void*)f_5549},
{"f_5540:srfi_69_scm",(void*)f_5540},
{"f_5453:srfi_69_scm",(void*)f_5453},
{"f_5468:srfi_69_scm",(void*)f_5468},
{"f_5484:srfi_69_scm",(void*)f_5484},
{"f_5388:srfi_69_scm",(void*)f_5388},
{"f_5403:srfi_69_scm",(void*)f_5403},
{"f_5419:srfi_69_scm",(void*)f_5419},
{"f_5359:srfi_69_scm",(void*)f_5359},
{"f_5366:srfi_69_scm",(void*)f_5366},
{"f_5371:srfi_69_scm",(void*)f_5371},
{"f_5369:srfi_69_scm",(void*)f_5369},
{"f_5286:srfi_69_scm",(void*)f_5286},
{"f_5301:srfi_69_scm",(void*)f_5301},
{"f_5317:srfi_69_scm",(void*)f_5317},
{"f_5270:srfi_69_scm",(void*)f_5270},
{"f_5284:srfi_69_scm",(void*)f_5284},
{"f_5258:srfi_69_scm",(void*)f_5258},
{"f_5193:srfi_69_scm",(void*)f_5193},
{"f_5205:srfi_69_scm",(void*)f_5205},
{"f_5228:srfi_69_scm",(void*)f_5228},
{"f_5241:srfi_69_scm",(void*)f_5241},
{"f_5215:srfi_69_scm",(void*)f_5215},
{"f_5177:srfi_69_scm",(void*)f_5177},
{"f_5184:srfi_69_scm",(void*)f_5184},
{"f_5081:srfi_69_scm",(void*)f_5081},
{"f_5088:srfi_69_scm",(void*)f_5088},
{"f_5102:srfi_69_scm",(void*)f_5102},
{"f_5128:srfi_69_scm",(void*)f_5128},
{"f_5147:srfi_69_scm",(void*)f_5147},
{"f_5115:srfi_69_scm",(void*)f_5115},
{"f_4950:srfi_69_scm",(void*)f_4950},
{"f_4966:srfi_69_scm",(void*)f_4966},
{"f_5033:srfi_69_scm",(void*)f_5033},
{"f_5052:srfi_69_scm",(void*)f_5052},
{"f_4986:srfi_69_scm",(void*)f_4986},
{"f_4842:srfi_69_scm",(void*)f_4842},
{"f_4858:srfi_69_scm",(void*)f_4858},
{"f_4913:srfi_69_scm",(void*)f_4913},
{"f_4926:srfi_69_scm",(void*)f_4926},
{"f_4873:srfi_69_scm",(void*)f_4873},
{"f_4736:srfi_69_scm",(void*)f_4736},
{"f_4752:srfi_69_scm",(void*)f_4752},
{"f_4806:srfi_69_scm",(void*)f_4806},
{"f_4822:srfi_69_scm",(void*)f_4822},
{"f_4767:srfi_69_scm",(void*)f_4767},
{"f_4539:srfi_69_scm",(void*)f_4539},
{"f_4722:srfi_69_scm",(void*)f_4722},
{"f_4714:srfi_69_scm",(void*)f_4714},
{"f_4695:srfi_69_scm",(void*)f_4695},
{"f_4567:srfi_69_scm",(void*)f_4567},
{"f_4582:srfi_69_scm",(void*)f_4582},
{"f_4648:srfi_69_scm",(void*)f_4648},
{"f_4678:srfi_69_scm",(void*)f_4678},
{"f_4599:srfi_69_scm",(void*)f_4599},
{"f_4588:srfi_69_scm",(void*)f_4588},
{"f_4527:srfi_69_scm",(void*)f_4527},
{"f_4534:srfi_69_scm",(void*)f_4534},
{"f_4320:srfi_69_scm",(void*)f_4320},
{"f_4517:srfi_69_scm",(void*)f_4517},
{"f_4509:srfi_69_scm",(void*)f_4509},
{"f_4490:srfi_69_scm",(void*)f_4490},
{"f_4345:srfi_69_scm",(void*)f_4345},
{"f_4360:srfi_69_scm",(void*)f_4360},
{"f_4433:srfi_69_scm",(void*)f_4433},
{"f_4466:srfi_69_scm",(void*)f_4466},
{"f_4469:srfi_69_scm",(void*)f_4469},
{"f_4443:srfi_69_scm",(void*)f_4443},
{"f_4374:srfi_69_scm",(void*)f_4374},
{"f_4410:srfi_69_scm",(void*)f_4410},
{"f_4384:srfi_69_scm",(void*)f_4384},
{"f_4030:srfi_69_scm",(void*)f_4030},
{"f_4272:srfi_69_scm",(void*)f_4272},
{"f_4255:srfi_69_scm",(void*)f_4255},
{"f_4267:srfi_69_scm",(void*)f_4267},
{"f_4032:srfi_69_scm",(void*)f_4032},
{"f_4039:srfi_69_scm",(void*)f_4039},
{"f_4042:srfi_69_scm",(void*)f_4042},
{"f_4246:srfi_69_scm",(void*)f_4246},
{"f_4238:srfi_69_scm",(void*)f_4238},
{"f_4219:srfi_69_scm",(void*)f_4219},
{"f_4066:srfi_69_scm",(void*)f_4066},
{"f_4081:srfi_69_scm",(void*)f_4081},
{"f_4158:srfi_69_scm",(void*)f_4158},
{"f_4195:srfi_69_scm",(void*)f_4195},
{"f_4198:srfi_69_scm",(void*)f_4198},
{"f_4186:srfi_69_scm",(void*)f_4186},
{"f_4168:srfi_69_scm",(void*)f_4168},
{"f_4095:srfi_69_scm",(void*)f_4095},
{"f_4135:srfi_69_scm",(void*)f_4135},
{"f_4123:srfi_69_scm",(void*)f_4123},
{"f_4105:srfi_69_scm",(void*)f_4105},
{"f_4021:srfi_69_scm",(void*)f_4021},
{"f_3909:srfi_69_scm",(void*)f_3909},
{"f_3919:srfi_69_scm",(void*)f_3919},
{"f_3924:srfi_69_scm",(void*)f_3924},
{"f_3986:srfi_69_scm",(void*)f_3986},
{"f_4007:srfi_69_scm",(void*)f_4007},
{"f_3980:srfi_69_scm",(void*)f_3980},
{"f_3883:srfi_69_scm",(void*)f_3883},
{"f_3890:srfi_69_scm",(void*)f_3890},
{"f_3893:srfi_69_scm",(void*)f_3893},
{"f_3816:srfi_69_scm",(void*)f_3816},
{"f_3839:srfi_69_scm",(void*)f_3839},
{"f_3855:srfi_69_scm",(void*)f_3855},
{"f_3826:srfi_69_scm",(void*)f_3826},
{"f_3896:srfi_69_scm",(void*)f_3896},
{"f_3789:srfi_69_scm",(void*)f_3789},
{"f_3777:srfi_69_scm",(void*)f_3777},
{"f_3768:srfi_69_scm",(void*)f_3768},
{"f_3759:srfi_69_scm",(void*)f_3759},
{"f_3750:srfi_69_scm",(void*)f_3750},
{"f_3741:srfi_69_scm",(void*)f_3741},
{"f_3732:srfi_69_scm",(void*)f_3732},
{"f_3723:srfi_69_scm",(void*)f_3723},
{"f_3714:srfi_69_scm",(void*)f_3714},
{"f_3708:srfi_69_scm",(void*)f_3708},
{"f_3345:srfi_69_scm",(void*)f_3345},
{"f_3698:srfi_69_scm",(void*)f_3698},
{"f_3701:srfi_69_scm",(void*)f_3701},
{"f_3423:srfi_69_scm",(void*)f_3423},
{"f_3678:srfi_69_scm",(void*)f_3678},
{"f_3681:srfi_69_scm",(void*)f_3681},
{"f_3426:srfi_69_scm",(void*)f_3426},
{"f_3646:srfi_69_scm",(void*)f_3646},
{"f_3652:srfi_69_scm",(void*)f_3652},
{"f_3429:srfi_69_scm",(void*)f_3429},
{"f_3464:srfi_69_scm",(void*)f_3464},
{"f_3485:srfi_69_scm",(void*)f_3485},
{"f_3491:srfi_69_scm",(void*)f_3491},
{"f_3583:srfi_69_scm",(void*)f_3583},
{"f_3586:srfi_69_scm",(void*)f_3586},
{"f_3558:srfi_69_scm",(void*)f_3558},
{"f_3561:srfi_69_scm",(void*)f_3561},
{"f_3548:srfi_69_scm",(void*)f_3548},
{"f_3530:srfi_69_scm",(void*)f_3530},
{"f_3517:srfi_69_scm",(void*)f_3517},
{"f_3507:srfi_69_scm",(void*)f_3507},
{"f_3494:srfi_69_scm",(void*)f_3494},
{"f_3475:srfi_69_scm",(void*)f_3475},
{"f_3432:srfi_69_scm",(void*)f_3432},
{"f_3435:srfi_69_scm",(void*)f_3435},
{"f_3439:srfi_69_scm",(void*)f_3439},
{"f_3455:srfi_69_scm",(void*)f_3455},
{"f_3442:srfi_69_scm",(void*)f_3442},
{"f_3347:srfi_69_scm",(void*)f_3347},
{"f_3314:srfi_69_scm",(void*)f_3314},
{"f_3318:srfi_69_scm",(void*)f_3318},
{"f_3284:srfi_69_scm",(void*)f_3284},
{"f_3290:srfi_69_scm",(void*)f_3290},
{"f_3157:srfi_69_scm",(void*)f_3157},
{"f_3222:srfi_69_scm",(void*)f_3222},
{"f_3213:srfi_69_scm",(void*)f_3213},
{"f_3194:srfi_69_scm",(void*)f_3194},
{"f_3198:srfi_69_scm",(void*)f_3198},
{"f_3201:srfi_69_scm",(void*)f_3201},
{"f_3173:srfi_69_scm",(void*)f_3173},
{"f_3032:srfi_69_scm",(void*)f_3032},
{"f_3097:srfi_69_scm",(void*)f_3097},
{"f_3088:srfi_69_scm",(void*)f_3088},
{"f_3069:srfi_69_scm",(void*)f_3069},
{"f_3073:srfi_69_scm",(void*)f_3073},
{"f_3076:srfi_69_scm",(void*)f_3076},
{"f_3048:srfi_69_scm",(void*)f_3048},
{"f_2983:srfi_69_scm",(void*)f_2983},
{"f_2987:srfi_69_scm",(void*)f_2987},
{"f_2993:srfi_69_scm",(void*)f_2993},
{"f_2649:srfi_69_scm",(void*)f_2649},
{"f_2748:srfi_69_scm",(void*)f_2748},
{"f_2961:srfi_69_scm",(void*)f_2961},
{"f_2940:srfi_69_scm",(void*)f_2940},
{"f_2932:srfi_69_scm",(void*)f_2932},
{"f_2911:srfi_69_scm",(void*)f_2911},
{"f_2885:srfi_69_scm",(void*)f_2885},
{"f_2717:srfi_69_scm",(void*)f_2717},
{"f_2733:srfi_69_scm",(void*)f_2733},
{"f_2652:srfi_69_scm",(void*)f_2652},
{"f_2669:srfi_69_scm",(void*)f_2669},
{"f_2703:srfi_69_scm",(void*)f_2703},
{"f_2601:srfi_69_scm",(void*)f_2601},
{"f_2605:srfi_69_scm",(void*)f_2605},
{"f_2590:srfi_69_scm",(void*)f_2590},
{"f_2611:srfi_69_scm",(void*)f_2611},
{"f_2410:srfi_69_scm",(void*)f_2410},
{"f_2414:srfi_69_scm",(void*)f_2414},
{"f_2420:srfi_69_scm",(void*)f_2420},
{"f_2299:srfi_69_scm",(void*)f_2299},
{"f_2303:srfi_69_scm",(void*)f_2303},
{"f_2306:srfi_69_scm",(void*)f_2306},
{"f_2273:srfi_69_scm",(void*)f_2273},
{"f_2280:srfi_69_scm",(void*)f_2280},
{"f_2222:srfi_69_scm",(void*)f_2222},
{"f_2226:srfi_69_scm",(void*)f_2226},
{"f_2174:srfi_69_scm",(void*)f_2174},
{"f_2178:srfi_69_scm",(void*)f_2178},
{"f_2184:srfi_69_scm",(void*)f_2184},
{"f_2038:srfi_69_scm",(void*)f_2038},
{"f_2042:srfi_69_scm",(void*)f_2042},
{"f_2045:srfi_69_scm",(void*)f_2045},
{"f_2147:srfi_69_scm",(void*)f_2147},
{"f_2051:srfi_69_scm",(void*)f_2051},
{"f_2032:srfi_69_scm",(void*)f_2032},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
