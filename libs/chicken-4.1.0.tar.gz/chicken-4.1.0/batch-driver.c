/* Generated from batch-driver.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:38
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: batch-driver.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file batch-driver.c
   unit: driver
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[392];
static double C_possibly_force_alignment;


C_noret_decl(C_driver_toplevel)
C_externexport void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_ccall f_1136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1152)
static void C_ccall f_1152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1162)
static void C_ccall f_1162r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_fcall f_3535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1217)
static void C_ccall f_1217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1223)
static void C_fcall f_1223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_fcall f_1614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_fcall f_1617(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3418)
static void C_ccall f_3418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1632)
static void C_ccall f_1632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_fcall f_1635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_fcall f_1638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_fcall f_1644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_ccall f_1647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_fcall f_1650(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_fcall f_1653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_fcall f_1656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_fcall f_1659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_fcall f_1662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_fcall f_1669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_fcall f_1672(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_fcall f_1675(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_fcall f_1678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_fcall f_1681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_fcall f_1684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_fcall f_1687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_fcall f_1690(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_fcall f_1693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1699)
static void C_fcall f_1699(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3294)
static void C_ccall f_3294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_fcall f_1705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1717)
static void C_ccall f_1717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_fcall f_1739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_fcall f_1742(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_fcall f_1745(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_fcall f_1748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2998)
static void C_ccall f_2998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1793)
static void C_ccall f_1793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_fcall f_1800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1808)
static void C_ccall f_1808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_fcall f_1834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_fcall f_1864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_fcall f_2744(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_fcall f_2799(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2820)
static void C_ccall f_2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2755)
static void C_ccall f_2755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2735)
static void C_ccall f_2735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2739)
static void C_ccall f_2739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2732)
static void C_ccall f_2732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_fcall f_1940(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_fcall f_1949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2666)
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_fcall f_2548(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_ccall f_2501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_fcall f_2008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_fcall f_2011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_fcall f_2255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2185)
static void C_ccall f_2185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2224)
static void C_ccall f_2224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_fcall f_1535(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1565)
static void C_fcall f_1565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_fcall f_1560(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1537)
static void C_fcall f_1537(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1529)
static void C_fcall f_1529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1512)
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1502)
static C_word C_fcall f_1502(C_word t0);
C_noret_decl(f_1472)
static void C_fcall f_1472(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1478)
static void C_fcall f_1478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_fcall f_1392(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_fcall f_1353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1364)
static void C_ccall f_1364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_fcall f_1331(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1316)
static void C_fcall f_1316(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_fcall f_1294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_fcall f_1279(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1165)
static void C_fcall f_1165(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3535)
static void C_fcall trf_3535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3535(t0,t1);}

C_noret_decl(trf_1223)
static void C_fcall trf_1223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1223(t0,t1);}

C_noret_decl(trf_1614)
static void C_fcall trf_1614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1614(t0,t1);}

C_noret_decl(trf_1617)
static void C_fcall trf_1617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1617(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1617(t0,t1);}

C_noret_decl(trf_1635)
static void C_fcall trf_1635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1635(t0,t1);}

C_noret_decl(trf_1638)
static void C_fcall trf_1638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1638(t0,t1);}

C_noret_decl(trf_1644)
static void C_fcall trf_1644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1644(t0,t1);}

C_noret_decl(trf_1650)
static void C_fcall trf_1650(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1650(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1650(t0,t1);}

C_noret_decl(trf_1653)
static void C_fcall trf_1653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1653(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1653(t0,t1);}

C_noret_decl(trf_1656)
static void C_fcall trf_1656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1656(t0,t1);}

C_noret_decl(trf_1659)
static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1659(t0,t1);}

C_noret_decl(trf_1662)
static void C_fcall trf_1662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1662(t0,t1);}

C_noret_decl(trf_1669)
static void C_fcall trf_1669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1669(t0,t1);}

C_noret_decl(trf_1672)
static void C_fcall trf_1672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1672(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1672(t0,t1);}

C_noret_decl(trf_1675)
static void C_fcall trf_1675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1675(t0,t1);}

C_noret_decl(trf_1678)
static void C_fcall trf_1678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1678(t0,t1);}

C_noret_decl(trf_1681)
static void C_fcall trf_1681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1681(t0,t1);}

C_noret_decl(trf_1684)
static void C_fcall trf_1684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1684(t0,t1);}

C_noret_decl(trf_1687)
static void C_fcall trf_1687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1687(t0,t1);}

C_noret_decl(trf_1690)
static void C_fcall trf_1690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1690(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1690(t0,t1);}

C_noret_decl(trf_1693)
static void C_fcall trf_1693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1693(t0,t1);}

C_noret_decl(trf_1699)
static void C_fcall trf_1699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1699(t0,t1);}

C_noret_decl(trf_1705)
static void C_fcall trf_1705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1705(t0,t1);}

C_noret_decl(trf_1739)
static void C_fcall trf_1739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1739(t0,t1);}

C_noret_decl(trf_1742)
static void C_fcall trf_1742(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1742(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1742(t0,t1);}

C_noret_decl(trf_1745)
static void C_fcall trf_1745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1745(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1745(t0,t1);}

C_noret_decl(trf_1748)
static void C_fcall trf_1748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1748(t0,t1);}

C_noret_decl(trf_1800)
static void C_fcall trf_1800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1800(t0,t1);}

C_noret_decl(trf_1834)
static void C_fcall trf_1834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1834(t0,t1);}

C_noret_decl(trf_1864)
static void C_fcall trf_1864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1864(t0,t1);}

C_noret_decl(trf_2744)
static void C_fcall trf_2744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2744(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2744(t0,t1,t2);}

C_noret_decl(trf_2799)
static void C_fcall trf_2799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2799(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2799(t0,t1,t2);}

C_noret_decl(trf_1940)
static void C_fcall trf_1940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1940(t0,t1);}

C_noret_decl(trf_1949)
static void C_fcall trf_1949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1949(t0,t1);}

C_noret_decl(trf_2548)
static void C_fcall trf_2548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2548(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2548(t0,t1);}

C_noret_decl(trf_2008)
static void C_fcall trf_2008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2008(t0,t1);}

C_noret_decl(trf_2011)
static void C_fcall trf_2011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2011(t0,t1);}

C_noret_decl(trf_2049)
static void C_fcall trf_2049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2049(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2049(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2255)
static void C_fcall trf_2255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2255(t0,t1);}

C_noret_decl(trf_1535)
static void C_fcall trf_1535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1535(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1535(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1565)
static void C_fcall trf_1565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1565(t0,t1);}

C_noret_decl(trf_1560)
static void C_fcall trf_1560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1560(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1560(t0,t1,t2);}

C_noret_decl(trf_1537)
static void C_fcall trf_1537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1537(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1537(t0,t1,t2,t3);}

C_noret_decl(trf_1529)
static void C_fcall trf_1529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1529(t0,t1,t2);}

C_noret_decl(trf_1512)
static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1512(t0,t1,t2);}

C_noret_decl(trf_1472)
static void C_fcall trf_1472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1472(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1472(t0,t1,t2);}

C_noret_decl(trf_1478)
static void C_fcall trf_1478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1478(t0,t1,t2);}

C_noret_decl(trf_1392)
static void C_fcall trf_1392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1392(t0,t1);}

C_noret_decl(trf_1353)
static void C_fcall trf_1353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1353(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1353(t0,t1);}

C_noret_decl(trf_1331)
static void C_fcall trf_1331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1331(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1331(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1316)
static void C_fcall trf_1316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1316(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1316(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1294)
static void C_fcall trf_1294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1294(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1294(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1279)
static void C_fcall trf_1279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1279(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1279(t0,t1,t2,t3);}

C_noret_decl(trf_1270)
static void C_fcall trf_1270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1270(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1270(t0,t1,t2,t3);}

C_noret_decl(trf_1165)
static void C_fcall trf_1165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1165(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_driver_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_driver_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("driver_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3023)){
C_save(t1);
C_rereclaim2(3023*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,392);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],17,"user-options-pass");
lf[3]=C_h_intern(&lf[3],14,"user-read-pass");
lf[4]=C_h_intern(&lf[4],22,"user-preprocessor-pass");
lf[5]=C_h_intern(&lf[5],9,"user-pass");
lf[6]=C_h_intern(&lf[6],23,"user-post-analysis-pass");
lf[7]=C_h_intern(&lf[7],19,"compile-source-file");
lf[8]=C_h_intern(&lf[8],4,"quit");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~A\047 option");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid argument to `~A\047 option");
lf[11]=C_h_intern(&lf[11],12,"explicit-use");
lf[12]=C_h_intern(&lf[12],26,"\010compilerexplicit-use-flag");
lf[13]=C_h_intern(&lf[13],12,"\004coredeclare");
lf[14]=C_h_intern(&lf[14],7,"verbose");
lf[15]=C_h_intern(&lf[15],11,"output-file");
lf[16]=C_h_intern(&lf[16],36,"\010compilerdefault-optimization-passes");
lf[17]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\003\000\000\002\376\001\000\000\031\003sysimplicit-exit-handler\376\377\016\376\377\016\376\377\016");
lf[18]=C_h_intern(&lf[18],7,"profile");
lf[19]=C_h_intern(&lf[19],12,"profile-name");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\007PROFILE");
lf[21]=C_h_intern(&lf[21],9,"heap-size");
lf[22]=C_h_intern(&lf[22],17,"heap-initial-size");
lf[23]=C_h_intern(&lf[23],11,"heap-growth");
lf[24]=C_h_intern(&lf[24],14,"heap-shrinkage");
lf[25]=C_h_intern(&lf[25],13,"keyword-style");
lf[26]=C_h_intern(&lf[26],4,"unit");
lf[27]=C_h_intern(&lf[27],12,"analyze-only");
lf[28]=C_h_intern(&lf[28],7,"dynamic");
lf[29]=C_h_intern(&lf[29],7,"nursery");
lf[30]=C_h_intern(&lf[30],10,"stack-size");
lf[31]=C_h_intern(&lf[31],6,"printf");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\006~\077~%~!");
lf[33]=C_h_intern(&lf[33],26,"\010compilerdebugging-chicken");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\006[~a]~%");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\010pass: ~a");
lf[36]=C_h_intern(&lf[36],19,"\010compilerdump-nodes");
lf[37]=C_h_intern(&lf[37],12,"pretty-print");
lf[38]=C_h_intern(&lf[38],30,"\010compilerbuild-expression-tree");
lf[39]=C_h_intern(&lf[39],34,"\010compilerdisplay-analysis-database");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\020(iteration ~s)~%");
lf[41]=C_h_intern(&lf[41],12,"\003sysfor-each");
lf[42]=C_h_intern(&lf[42],19,"\003syshash-table-set!");
lf[43]=C_h_intern(&lf[43],24,"\003sysline-number-database");
lf[44]=C_h_intern(&lf[44],10,"alist-cons");
lf[45]=C_h_intern(&lf[45],18,"\003syshash-table-ref");
lf[46]=C_h_intern(&lf[46],9,"list-info");
lf[47]=C_h_intern(&lf[47],26,"\003sysdefault-read-info-hook");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid numeric argument ~S");
lf[49]=C_h_intern(&lf[49],9,"substring");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000!milliseconds needed for ~a: \011~s~%");
lf[51]=C_h_intern(&lf[51],8,"\003sysread");
lf[52]=C_h_intern(&lf[52],12,"\010compilerget");
lf[53]=C_h_intern(&lf[53],13,"\010compilerput!");
lf[54]=C_h_intern(&lf[54],27,"\010compileranalyze-expression");
lf[55]=C_h_intern(&lf[55],9,"\003syserror");
lf[56]=C_h_intern(&lf[56],1,"D");
lf[57]=C_h_intern(&lf[57],25,"\010compilerimport-libraries");
lf[58]=C_h_intern(&lf[58],26,"\010compilerdisabled-warnings");
lf[59]=C_h_intern(&lf[59],16,"emit-inline-file");
lf[60]=C_h_intern(&lf[60],12,"inline-limit");
lf[61]=C_h_intern(&lf[61],21,"\010compilerverbose-mode");
lf[62]=C_h_intern(&lf[62],31,"\003sysread-error-with-line-number");
lf[63]=C_h_intern(&lf[63],21,"\003sysinclude-pathnames");
lf[64]=C_h_intern(&lf[64],19,"\000compiler-extension");
lf[65]=C_h_intern(&lf[65],12,"\003sysfeatures");
lf[66]=C_h_intern(&lf[66],10,"\000compiling");
lf[67]=C_h_intern(&lf[67],28,"\003sysexplicit-library-modules");
lf[68]=C_h_intern(&lf[68],25,"\010compilertarget-heap-size");
lf[69]=C_h_intern(&lf[69],33,"\010compilertarget-initial-heap-size");
lf[70]=C_h_intern(&lf[70],27,"\010compilertarget-heap-growth");
lf[71]=C_h_intern(&lf[71],30,"\010compilertarget-heap-shrinkage");
lf[72]=C_h_intern(&lf[72],26,"\010compilertarget-stack-size");
lf[73]=C_h_intern(&lf[73],8,"no-trace");
lf[74]=C_h_intern(&lf[74],24,"\010compileremit-trace-info");
lf[75]=C_h_intern(&lf[75],29,"disable-stack-overflow-checks");
lf[76]=C_h_intern(&lf[76],40,"\010compilerdisable-stack-overflow-checking");
lf[77]=C_h_intern(&lf[77],7,"version");
lf[78]=C_h_intern(&lf[78],7,"newline");
lf[79]=C_h_intern(&lf[79],22,"\010compilerprint-version");
lf[80]=C_h_intern(&lf[80],4,"help");
lf[81]=C_h_intern(&lf[81],20,"\010compilerprint-usage");
lf[82]=C_h_intern(&lf[82],7,"release");
lf[83]=C_h_intern(&lf[83],7,"display");
lf[84]=C_h_intern(&lf[84],15,"chicken-version");
lf[85]=C_h_intern(&lf[85],24,"\010compilersource-filename");
lf[86]=C_h_intern(&lf[86],28,"\010compilerprofile-lambda-list");
lf[87]=C_h_intern(&lf[87],31,"\010compilerline-number-database-2");
lf[88]=C_h_intern(&lf[88],4,"node");
lf[89]=C_h_intern(&lf[89],6,"lambda");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\016\376\377\016");
lf[91]=C_h_intern(&lf[91],23,"\010compilerconstant-table");
lf[92]=C_h_intern(&lf[92],21,"\010compilerinline-table");
lf[93]=C_h_intern(&lf[93],23,"\010compilerfirst-analysis");
lf[94]=C_h_intern(&lf[94],41,"\010compilerperform-high-level-optimizations");
lf[95]=C_h_intern(&lf[95],37,"\010compilerinline-substitutions-enabled");
lf[96]=C_h_intern(&lf[96],22,"optimize-leaf-routines");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\031leaf routine optimization");
lf[98]=C_h_intern(&lf[98],34,"\010compilertransform-direct-lambdas!");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[100]=C_h_intern(&lf[100],4,"leaf");
lf[101]=C_h_intern(&lf[101],18,"\010compilerdebugging");
lf[102]=C_h_intern(&lf[102],1,"p");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025rewritings enabled...");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\023optimized-iteration");
lf[105]=C_h_intern(&lf[105],1,"5");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\014optimization");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\021optimization pass");
lf[108]=C_h_intern(&lf[108],36,"\010compilerprepare-for-code-generation");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\025compilation finished.");
lf[110]=C_h_intern(&lf[110],30,"\010compilercompiler-cleanup-hook");
lf[111]=C_h_intern(&lf[111],1,"t");
lf[112]=C_h_intern(&lf[112],17,"\003sysdisplay-times");
lf[113]=C_h_intern(&lf[113],14,"\003sysstop-timer");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\017code generation");
lf[115]=C_h_intern(&lf[115],17,"close-output-port");
lf[116]=C_h_intern(&lf[116],22,"\010compilergenerate-code");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\023generating `~A\047 ...");
lf[118]=C_h_intern(&lf[118],16,"open-output-file");
lf[119]=C_h_intern(&lf[119],19,"current-output-port");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\013preparation");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\021closure-converted");
lf[122]=C_h_intern(&lf[122],1,"9");
lf[123]=C_h_intern(&lf[123],4,"exit");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000#(don\047t worry - still compiling...)\012");
lf[125]=C_h_intern(&lf[125],20,"\003syswarnings-enabled");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\016final-analysis");
lf[127]=C_h_intern(&lf[127],1,"8");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\022closure conversion");
lf[129]=C_h_intern(&lf[129],35,"\010compilerperform-closure-conversion");
lf[130]=C_h_intern(&lf[130],27,"\010compilerinline-output-file");
lf[131]=C_h_intern(&lf[131],32,"\010compileremit-global-inline-file");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000&Generating global inline file `~a\047 ...");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\011optimized");
lf[134]=C_h_intern(&lf[134],1,"7");
lf[135]=C_h_intern(&lf[135],1,"s");
lf[136]=C_h_intern(&lf[136],33,"\010compilerprint-program-statistics");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[138]=C_h_intern(&lf[138],1,"4");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[140]=C_h_intern(&lf[140],1,"d");
lf[141]=C_h_intern(&lf[141],29,"\010compilerdump-defined-globals");
lf[142]=C_h_intern(&lf[142],1,"u");
lf[143]=C_h_intern(&lf[143],31,"\010compilerdump-undefined-globals");
lf[144]=C_h_intern(&lf[144],3,"opt");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\003cps");
lf[146]=C_h_intern(&lf[146],1,"3");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\016cps conversion");
lf[148]=C_h_intern(&lf[148],31,"\010compilerperform-cps-conversion");
lf[149]=C_h_intern(&lf[149],6,"unsafe");
lf[150]=C_h_intern(&lf[150],34,"\010compilerscan-toplevel-assignments");
lf[151]=C_h_intern(&lf[151],24,"\010compilerinline-globally");
lf[152]=C_h_intern(&lf[152],23,"\010compilerinline-locally");
lf[153]=C_h_intern(&lf[153],25,"\010compilerload-inline-file");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[155]=C_h_intern(&lf[155],19,"consult-inline-file");
lf[156]=C_h_intern(&lf[156],28,"\010compilerenable-inline-files");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\032Loading inline file ~a ...");
lf[158]=C_h_intern(&lf[158],12,"file-exists\077");
lf[159]=C_h_intern(&lf[159],28,"\003sysresolve-include-filename");
lf[160]=C_h_intern(&lf[160],13,"make-pathname");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[162]=C_h_intern(&lf[162],14,"symbol->string");
lf[163]=C_h_intern(&lf[163],11,"concatenate");
lf[164]=C_h_intern(&lf[164],7,"\003sysmap");
lf[165]=C_h_intern(&lf[165],3,"cdr");
lf[166]=C_h_intern(&lf[166],2,"pp");
lf[167]=C_h_intern(&lf[167],1,"M");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\017; requirements:");
lf[169]=C_h_intern(&lf[169],12,"vector->list");
lf[170]=C_h_intern(&lf[170],26,"\010compilerfile-requirements");
lf[171]=C_h_intern(&lf[171],26,"\010compilerdo-lambda-lifting");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\015lambda lifted");
lf[173]=C_h_intern(&lf[173],1,"L");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\016lambda lifting");
lf[175]=C_h_intern(&lf[175],32,"\010compilerperform-lambda-lifting!");
lf[176]=C_h_intern(&lf[176],22,"\010compilerdo-scrutinize");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\032pre-analysis (lambda-lift)");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[179]=C_h_intern(&lf[179],1,"0");
lf[180]=C_h_intern(&lf[180],4,"lift");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\010scrutiny");
lf[182]=C_h_intern(&lf[182],19,"\010compilerscrutinize");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\023performing scrutiny");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\014pre-analysis");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\010analysis");
lf[186]=C_h_intern(&lf[186],8,"scrutiny");
lf[187]=C_h_intern(&lf[187],27,"\010compilerload-type-database");
lf[188]=C_h_intern(&lf[188],5,"types");
lf[189]=C_h_intern(&lf[189],17,"ignore-repository");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\010types.db");
lf[191]=C_h_intern(&lf[191],37,"\010compilerinitialize-analysis-database");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\021initial node tree");
lf[193]=C_h_intern(&lf[193],1,"T");
lf[194]=C_h_intern(&lf[194],25,"\010compilerbuild-node-graph");
lf[195]=C_h_intern(&lf[195],32,"\010compilercanonicalize-begin-body");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\011user pass");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\014User pass...");
lf[198]=C_h_intern(&lf[198],12,"check-syntax");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\015canonicalized");
lf[200]=C_h_intern(&lf[200],1,"2");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\020canonicalization");
lf[202]=C_h_intern(&lf[202],25,"\010compilercompiler-warning");
lf[203]=C_h_intern(&lf[203],5,"style");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000Icompiling extensions in unsafe mode is bad practice and should be avoided");
lf[205]=C_h_intern(&lf[205],8,"feature\077");
lf[206]=C_h_intern(&lf[206],19,"compiling-extension");
lf[207]=C_h_intern(&lf[207],18,"\010compilerunit-name");
lf[208]=C_h_intern(&lf[208],5,"usage");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000*library unit `~a\047 compiled in dynamic mode");
lf[210]=C_h_intern(&lf[210],37,"\010compilerdisplay-line-number-database");
lf[211]=C_h_intern(&lf[211],1,"n");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\025line number database:");
lf[213]=C_h_intern(&lf[213],32,"\010compilerdisplay-real-name-table");
lf[214]=C_h_intern(&lf[214],1,"N");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\020real name table:");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\012  ~a\011\011~a~%");
lf[217]=C_h_intern(&lf[217],35,"\010compilercompiler-syntax-statistics");
lf[218]=C_h_intern(&lf[218],1,"x");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\030applied compiler syntax:");
lf[220]=C_h_intern(&lf[220],6,"append");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016\376\377\016");
lf[222]=C_h_intern(&lf[222],5,"quote");
lf[223]=C_h_intern(&lf[223],33,"\010compilerprofile-info-vector-name");
lf[224]=C_h_intern(&lf[224],28,"\003sysset-profile-info-vector!");
lf[225]=C_h_intern(&lf[225],21,"\010compileremit-profile");
lf[226]=C_h_intern(&lf[226],25,"\003sysregister-profile-info");
lf[227]=C_h_intern(&lf[227],4,"set!");
lf[228]=C_h_intern(&lf[228],13,"\004corecallunit");
lf[229]=C_h_intern(&lf[229],19,"\010compilerused-units");
lf[230]=C_h_intern(&lf[230],28,"\010compilerimmutable-constants");
lf[231]=C_h_intern(&lf[231],6,"gensym");
lf[232]=C_h_intern(&lf[232],32,"\010compilercanonicalize-expression");
lf[233]=C_h_intern(&lf[233],4,"uses");
lf[234]=C_h_intern(&lf[234],7,"declare");
lf[235]=C_h_intern(&lf[235],10,"\003sysappend");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\006source");
lf[237]=C_h_intern(&lf[237],1,"1");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\032User preprocessing pass...");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\021User read pass...");
lf[240]=C_h_intern(&lf[240],21,"\010compilerstring->expr");
lf[241]=C_h_intern(&lf[241],7,"reverse");
lf[242]=C_h_intern(&lf[242],27,"\003syscurrent-source-filename");
lf[243]=C_h_intern(&lf[243],33,"\010compilerclose-checked-input-file");
lf[244]=C_h_intern(&lf[244],16,"\003sysdynamic-wind");
lf[245]=C_h_intern(&lf[245],34,"\010compilercheck-and-open-input-file");
lf[246]=C_h_intern(&lf[246],8,"epilogue");
lf[247]=C_h_intern(&lf[247],8,"prologue");
lf[248]=C_h_intern(&lf[248],8,"postlude");
lf[249]=C_h_intern(&lf[249],7,"prelude");
lf[250]=C_h_intern(&lf[250],11,"make-vector");
lf[251]=C_h_intern(&lf[251],34,"\010compilerline-number-database-size");
lf[252]=C_h_intern(&lf[252],1,"r");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\021target stack size");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\020target heap size");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\021debugging options");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\007options");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\022compiling `~a\047 ...");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\0009\012Enter \042chicken -help\042 for information on how to use it.\012");
lf[259]=C_h_intern(&lf[259],5,"-help");
lf[260]=C_h_intern(&lf[260],1,"h");
lf[261]=C_h_intern(&lf[261],2,"-h");
lf[262]=C_h_intern(&lf[262],33,"\010compilerload-identifier-database");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[264]=C_h_intern(&lf[264],18,"accumulate-profile");
lf[265]=C_h_intern(&lf[265],28,"\010compilerprofiled-procedures");
lf[266]=C_h_intern(&lf[266],3,"all");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\014accumulated ");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\024Generating ~aprofile");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\004set!\376\003\000\000\002\376\001\000\000\027\003sysprofile-append-mode\376\003\000\000\002\376\377\006\001\376\377\016\376\377\016");
lf[271]=C_h_intern(&lf[271],39,"\010compilerdefault-profiling-declarations");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\011calltrace");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\022debugging info: ~A");
lf[275]=C_h_intern(&lf[275],21,"no-usual-integrations");
lf[276]=C_h_intern(&lf[276],17,"standard-bindings");
lf[277]=C_h_intern(&lf[277],34,"\010compilerdefault-standard-bindings");
lf[278]=C_h_intern(&lf[278],17,"extended-bindings");
lf[279]=C_h_intern(&lf[279],34,"\010compilerdefault-extended-bindings");
lf[280]=C_h_intern(&lf[280],1,"m");
lf[281]=C_h_intern(&lf[281],14,"set-gc-report!");
lf[282]=C_h_intern(&lf[282],42,"\010compilerdefault-default-target-stack-size");
lf[283]=C_h_intern(&lf[283],41,"\010compilerdefault-default-target-heap-size");
lf[284]=C_h_intern(&lf[284],14,"compile-syntax");
lf[285]=C_h_intern(&lf[285],25,"\003sysenable-runtime-macros");
lf[286]=C_h_intern(&lf[286],22,"\004corerequire-extension");
lf[287]=C_h_intern(&lf[287],14,"string->symbol");
lf[288]=C_h_intern(&lf[288],17,"require-extension");
lf[289]=C_h_intern(&lf[289],16,"static-extension");
lf[290]=C_h_intern(&lf[290],28,"\010compilerpostponed-initforms");
lf[291]=C_h_intern(&lf[291],6,"delete");
lf[292]=C_h_intern(&lf[292],3,"eq\077");
lf[293]=C_h_intern(&lf[293],4,"load");
lf[294]=C_h_intern(&lf[294],12,"load-verbose");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\036Loading compiler extensions...");
lf[296]=C_h_intern(&lf[296],6,"extend");
lf[297]=C_h_intern(&lf[297],17,"register-feature!");
lf[298]=C_h_intern(&lf[298],12,"string-split");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[300]=C_h_intern(&lf[300],10,"append-map");
lf[301]=C_h_intern(&lf[301],7,"feature");
lf[302]=C_h_intern(&lf[302],38,"no-procedure-checks-for-usual-bindings");
lf[303]=C_h_intern(&lf[303],8,"\003sysput!");
lf[304]=C_h_intern(&lf[304],21,"\010compileralways-bound");
lf[305]=C_h_intern(&lf[305],34,"\010compileralways-bound-to-procedure");
lf[306]=C_h_intern(&lf[306],19,"no-procedure-checks");
lf[307]=C_h_intern(&lf[307],28,"\010compilerno-procedure-checks");
lf[308]=C_h_intern(&lf[308],15,"no-bound-checks");
lf[309]=C_h_intern(&lf[309],24,"\010compilerno-bound-checks");
lf[310]=C_h_intern(&lf[310],14,"no-argc-checks");
lf[311]=C_h_intern(&lf[311],23,"\010compilerno-argc-checks");
lf[312]=C_h_intern(&lf[312],20,"keep-shadowed-macros");
lf[313]=C_h_intern(&lf[313],33,"\010compilerundefine-shadowed-macros");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000(source- and output-filename are the same");
lf[315]=C_h_intern(&lf[315],23,"\010compilerchop-separator");
lf[316]=C_h_intern(&lf[316],12,"include-path");
lf[317]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[318]=C_h_intern(&lf[318],13,"symbol-escape");
lf[319]=C_h_intern(&lf[319],20,"parentheses-synonyms");
lf[320]=C_h_intern(&lf[320],5,"\000none");
lf[321]=C_h_intern(&lf[321],14,"case-sensitive");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000.Disabled the Chicken extensions to R5RS syntax");
lf[323]=C_h_intern(&lf[323],16,"no-symbol-escape");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000$Disabled support for escaped symbols");
lf[325]=C_h_intern(&lf[325],23,"no-parenthesis-synonyms");
lf[326]=C_h_intern(&lf[326],20,"parenthesis-synonyms");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000)Disabled support for parenthesis synonyms");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[329]=C_h_intern(&lf[329],7,"\000prefix");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[332]=C_h_intern(&lf[332],7,"\000suffix");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000+invalid argument to `-keyword-style\047 option");
lf[334]=C_h_intern(&lf[334],17,"compress-literals");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000+`the -compress-literals\047 option is obsolete");
lf[336]=C_h_intern(&lf[336],16,"case-insensitive");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000,Identifiers and symbols are case insensitive");
lf[338]=C_h_intern(&lf[338],24,"\010compilerinline-max-size");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\0000invalid argument to `-inline-limit\047 option: `~A\047");
lf[340]=C_h_intern(&lf[340],26,"\010compilerlocal-definitions");
lf[341]=C_h_intern(&lf[341],6,"inline");
lf[342]=C_h_intern(&lf[342],30,"emit-external-prototypes-first");
lf[343]=C_h_intern(&lf[343],30,"\010compilerexternal-protos-first");
lf[344]=C_h_intern(&lf[344],5,"block");
lf[345]=C_h_intern(&lf[345],26,"\010compilerblock-compilation");
lf[346]=C_h_intern(&lf[346],17,"fixnum-arithmetic");
lf[347]=C_h_intern(&lf[347],11,"number-type");
lf[348]=C_h_intern(&lf[348],6,"fixnum");
lf[349]=C_h_intern(&lf[349],18,"disable-interrupts");
lf[350]=C_h_intern(&lf[350],28,"\010compilerinsert-timer-checks");
lf[351]=C_h_intern(&lf[351],16,"unsafe-libraries");
lf[352]=C_h_intern(&lf[352],27,"\010compileremit-unsafe-marker");
lf[353]=C_h_intern(&lf[353],11,"no-warnings");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\025Warnings are disabled");
lf[355]=C_h_intern(&lf[355],15,"disable-warning");
lf[356]=C_h_intern(&lf[356],13,"inline-global");
lf[357]=C_h_intern(&lf[357],5,"local");
lf[358]=C_h_intern(&lf[358],18,"no-compiler-syntax");
lf[359]=C_h_intern(&lf[359],32,"\010compilercompiler-syntax-enabled");
lf[360]=C_h_intern(&lf[360],14,"no-lambda-info");
lf[361]=C_h_intern(&lf[361],26,"\010compileremit-closure-info");
lf[362]=C_h_intern(&lf[362],3,"raw");
lf[363]=C_h_intern(&lf[363],12,"emit-exports");
lf[364]=C_h_intern(&lf[364],7,"warning");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000(deprecated compiler option: emit-exports");
lf[366]=C_h_intern(&lf[366],1,"b");
lf[367]=C_h_intern(&lf[367],15,"\003sysstart-timer");
lf[368]=C_h_intern(&lf[368],10,"scrutinize");
lf[369]=C_h_intern(&lf[369],11,"lambda-lift");
lf[370]=C_h_intern(&lf[370],13,"string-append");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\013.import.scm");
lf[372]=C_h_intern(&lf[372],19,"emit-import-library");
lf[373]=C_h_intern(&lf[373],16,"\003sysstring->list");
lf[374]=C_h_intern(&lf[374],5,"debug");
lf[375]=C_h_intern(&lf[375],18,"\003sysdload-disabled");
lf[376]=C_h_intern(&lf[376],15,"repository-path");
lf[377]=C_h_intern(&lf[377],30,"\010compilerstandalone-executable");
lf[378]=C_h_intern(&lf[378],29,"\010compilerstring->c-identifier");
lf[379]=C_h_intern(&lf[379],18,"\010compilerstringify");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[382]=C_h_intern(&lf[382],24,"get-environment-variable");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[384]=C_h_intern(&lf[384],9,"to-stdout");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[386]=C_h_intern(&lf[386],13,"pathname-file");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\003out");
lf[388]=C_h_intern(&lf[388],29,"\010compilerdefault-declarations");
lf[389]=C_h_intern(&lf[389],30,"\010compilerunits-used-by-default");
lf[390]=C_h_intern(&lf[390],28,"\010compilerinitialize-compiler");
lf[391]=C_h_intern(&lf[391],14,"make-parameter");
C_register_lf2(lf,392,create_ptable());
t2=C_mutate(&lf[0] /* (set! c357 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1124,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1122 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1125 in k1122 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1128 in k1125 in k1122 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 82   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[391]))(3,*((C_word*)lf[391]+1),t2,C_SCHEME_FALSE);}

/* k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1144,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! user-options-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 83   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[391]))(3,*((C_word*)lf[391]+1),t3,C_SCHEME_FALSE);}

/* k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1148,2,t0,t1);}
t2=C_mutate((C_word*)lf[3]+1 /* (set! user-read-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 84   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[391]))(3,*((C_word*)lf[391]+1),t3,C_SCHEME_FALSE);}

/* k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1152,2,t0,t1);}
t2=C_mutate((C_word*)lf[4]+1 /* (set! user-preprocessor-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 85   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[391]))(3,*((C_word*)lf[391]+1),t3,C_SCHEME_FALSE);}

/* k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1156,2,t0,t1);}
t2=C_mutate((C_word*)lf[5]+1 /* (set! user-pass ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 86   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[391]))(3,*((C_word*)lf[391]+1),t3,C_SCHEME_FALSE);}

/* k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! user-post-analysis-pass ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! compile-source-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1162,tmp=(C_word)a,a+=2,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1162(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_1162r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1162r(t0,t1,t2,t3);}}

static void C_ccall f_1162r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1165,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1198,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 99   initialize-compiler */
((C_proc2)C_retrieve_symbol_proc(lf[390]))(2,*((C_word*)lf[390]+1),t5);}

/* k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1198,2,t0,t1);}
t2=(C_word)C_i_memq(lf[11],((C_word*)t0)[5]);
t3=C_mutate((C_word*)lf[12]+1 /* (set! explicit-use-flag ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3535,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[12]))){
t7=t6;
f_3535(t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3546,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t8=*((C_word*)lf[235]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[389]),C_SCHEME_END_OF_LIST);}}

/* k3544 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3546,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[233],t1);
t3=((C_word*)t0)[2];
f_3535(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k3533 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_3535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 102  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[2],C_retrieve(lf[388]),t1);}

/* k3529 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[235]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[13],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(C_word)C_i_memq(lf[14],((C_word*)t0)[5]);
t7=(C_word)C_i_memq(lf[15],((C_word*)t0)[5]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t7)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 110  option-arg */
f_1165(t9,t7);}
else{
if(C_truep((C_word)C_i_memq(lf[384],((C_word*)t0)[5]))){
t9=t8;
f_1214(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 115  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[386]))(3,*((C_word*)lf[386]+1),t9,((C_word*)t0)[2]);}
else{
t10=t9;
f_3516(2,t10,lf[387]);}}}}

/* k3514 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 115  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[160]))(5,*((C_word*)lf[160]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[385]);}

/* k3492 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_symbolp(t1))){
/* batch-driver.scm: 112  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
f_1214(2,t2,t1);}}

/* k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1217,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3488,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 116  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[382]))(3,*((C_word*)lf[382]+1),t4,lf[383]);}

/* k3486 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[380]);
/* batch-driver.scm: 116  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[298]))(4,*((C_word*)lf[298]+1),((C_word*)t0)[2],t2,lf[381]);}

/* k3482 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[315]),t1);}

/* k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1217,2,t0,t1);}
t2=C_retrieve(lf[16]);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=lf[17];
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(C_word)C_i_memq(lf[18],((C_word*)t0)[8]);
t12=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1223,a[2]=t1,a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t4,a[10]=t6,a[11]=((C_word*)t0)[6],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t11)){
t13=t12;
f_1223(t13,t11);}
else{
t13=(C_word)C_i_memq(lf[264],((C_word*)t0)[8]);
t14=t12;
f_1223(t14,(C_truep(t13)?t13:(C_word)C_i_memq(lf[19],((C_word*)t0)[8])));}}

/* k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1223,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[19],((C_word*)t0)[13]);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):C_SCHEME_FALSE);
t4=(C_truep(t3)?t3:lf[20]);
t5=(C_word)C_i_memq(lf[21],((C_word*)t0)[13]);
t6=(C_word)C_i_memq(lf[22],((C_word*)t0)[13]);
t7=(C_word)C_i_memq(lf[23],((C_word*)t0)[13]);
t8=(C_word)C_i_memq(lf[24],((C_word*)t0)[13]);
t9=(C_word)C_i_memq(lf[25],((C_word*)t0)[13]);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_memq(lf[26],((C_word*)t0)[13]);
t13=(C_word)C_i_memq(lf[27],((C_word*)t0)[13]);
t14=(C_word)C_i_memq(lf[28],((C_word*)t0)[13]);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_FALSE;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=(C_word)C_i_memq(lf[29],((C_word*)t0)[13]);
t22=(C_truep(t21)?t21:(C_word)C_i_memq(lf[30],((C_word*)t0)[13]));
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=t24,a[3]=t16,tmp=(C_word)a,a+=4,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1343,tmp=(C_word)a,a+=2,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1392,tmp=(C_word)a,a+=2,tmp);
t30=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t32=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t33=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1529,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1535,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t35=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[10],a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=((C_word*)t0)[11],a[10]=t29,a[11]=t22,a[12]=t1,a[13]=t33,a[14]=((C_word*)t0)[3],a[15]=t4,a[16]=((C_word*)t0)[4],a[17]=t27,a[18]=t30,a[19]=t26,a[20]=t13,a[21]=t14,a[22]=((C_word*)t0)[5],a[23]=t23,a[24]=t25,a[25]=t34,a[26]=t32,a[27]=t31,a[28]=t18,a[29]=((C_word*)t0)[6],a[30]=((C_word*)t0)[7],a[31]=((C_word*)t0)[8],a[32]=t20,a[33]=t11,a[34]=((C_word*)t0)[12],a[35]=((C_word*)t0)[13],a[36]=t16,tmp=(C_word)a,a+=37,tmp);
if(C_truep(t12)){
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3457,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
t37=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3461,a[2]=t36,tmp=(C_word)a,a+=3,tmp);
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3465,a[2]=t37,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 213  option-arg */
f_1165(t38,t12);}
else{
t36=t35;
f_1614(t36,C_SCHEME_UNDEFINED);}}

/* k3463 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 213  stringify */
((C_proc3)C_retrieve_symbol_proc(lf[379]))(3,*((C_word*)lf[379]+1),((C_word*)t0)[2],t1);}

/* k3459 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 213  string->c-identifier */
((C_proc3)C_retrieve_symbol_proc(lf[378]))(3,*((C_word*)lf[378]+1),((C_word*)t0)[2],t1);}

/* k3455 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[207]+1 /* (set! unit-name ...) */,t1);
t3=((C_word*)t0)[2];
f_1614(t3,t2);}

/* k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=C_retrieve(lf[207]);
t4=(C_truep(t3)?t3:((C_word*)t0)[21]);
if(C_truep(t4)){
t5=C_set_block_item(lf[377] /* standalone-executable */,0,C_SCHEME_FALSE);
t6=t2;
f_1617(t6,t5);}
else{
t5=t2;
f_1617(t5,C_SCHEME_UNDEFINED);}}

/* k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1617(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1617,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
if(C_truep((C_word)C_i_memq(lf[189],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[375] /* dload-disabled */,0,C_SCHEME_TRUE);
/* batch-driver.scm: 218  repository-path */
((C_proc3)C_retrieve_symbol_proc(lf[376]))(3,*((C_word*)lf[376]+1),t2,C_SCHEME_FALSE);}
else{
t3=t2;
f_1620(2,t3,C_SCHEME_UNDEFINED);}}

/* k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[43],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|36,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],a[36]=((C_word*)t0)[36],tmp=(C_word)a,a+=37,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3420,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3442,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 224  collect-options */
t5=((C_word*)t0)[18];
f_1472(t5,t4,lf[374]);}

/* k3440 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 220  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[300]))(4,*((C_word*)lf[300]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3419 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3420,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3426,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3438,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t5=C_retrieve(lf[373]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3436 in a3419 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3425 in a3419 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3426,3,t0,t1,t2);}
t3=(C_word)C_a_i_string(&a,1,t2);
/* batch-driver.scm: 222  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[287]+1)))(3,*((C_word*)lf[287]+1),t1,t3);}

/* k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=C_mutate((C_word*)lf[33]+1 /* (set! debugging-chicken ...) */,t1);
t3=(C_word)C_i_memq(lf[56],C_retrieve(lf[33]));
t4=C_mutate(((C_word *)((C_word*)t0)[36])+1,t3);
t5=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1632,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3402,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3418,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 230  collect-options */
t8=((C_word*)t0)[18];
f_1472(t8,t7,lf[372]);}

/* k3416 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3401 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3410,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 228  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[287]+1)))(3,*((C_word*)lf[287]+1),t3,t2);}

/* k3408 in a3401 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3414,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 229  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[370]+1)))(4,*((C_word*)lf[370]+1),t2,((C_word*)t0)[2],lf[371]);}

/* k3412 in k3408 in a3401 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1632,2,t0,t1);}
t2=C_mutate((C_word*)lf[57]+1 /* (set! import-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[369],((C_word*)t0)[35]))){
t4=C_set_block_item(lf[171] /* do-lambda-lifting */,0,C_SCHEME_TRUE);
t5=t3;
f_1635(t5,t4);}
else{
t4=t3;
f_1635(t4,C_SCHEME_UNDEFINED);}}

/* k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1635,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[368],((C_word*)t0)[35]))){
t3=C_set_block_item(lf[176] /* do-scrutinize */,0,C_SCHEME_TRUE);
t4=t2;
f_1638(t4,t3);}
else{
t3=t2;
f_1638(t3,C_SCHEME_UNDEFINED);}}

/* k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1638,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|35,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],a[35]=((C_word*)t0)[35],tmp=(C_word)a,a+=36,tmp);
if(C_truep((C_word)C_i_memq(lf[111],C_retrieve(lf[33])))){
/* batch-driver.scm: 233  ##sys#start-timer */
t3=*((C_word*)lf[367]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=t2;
f_1641(2,t3,C_SCHEME_UNDEFINED);}}

/* k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],a[34]=((C_word*)t0)[35],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[366],C_retrieve(lf[33])))){
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t4=t2;
f_1644(t4,t3);}
else{
t3=t2;
f_1644(t3,C_SCHEME_UNDEFINED);}}

/* k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1644,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[363],((C_word*)t0)[34]))){
/* batch-driver.scm: 236  warning */
((C_proc3)C_retrieve_symbol_proc(lf[364]))(3,*((C_word*)lf[364]+1),t2,lf[365]);}
else{
t3=t2;
f_1647(2,t3,C_SCHEME_UNDEFINED);}}

/* k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[362],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[12] /* explicit-use-flag */,0,C_SCHEME_TRUE);
t4=C_set_block_item(((C_word*)t0)[15],0,C_SCHEME_END_OF_LIST);
t5=C_set_block_item(((C_word*)t0)[30],0,C_SCHEME_END_OF_LIST);
t6=t2;
f_1650(t6,t5);}
else{
t3=t2;
f_1650(t3,C_SCHEME_UNDEFINED);}}

/* k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1650(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1650,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[360],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[361] /* emit-closure-info */,0,C_SCHEME_FALSE);
t4=t2;
f_1653(t4,t3);}
else{
t3=t2;
f_1653(t3,C_SCHEME_UNDEFINED);}}

/* k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1653,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[358],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[359] /* compiler-syntax-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_1656(t4,t3);}
else{
t3=t2;
f_1656(t3,C_SCHEME_UNDEFINED);}}

/* k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1656,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[357],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[340] /* local-definitions */,0,C_SCHEME_TRUE);
t4=t2;
f_1659(t4,t3);}
else{
t3=t2;
f_1659(t3,C_SCHEME_UNDEFINED);}}

/* k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1659,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[356],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[156] /* enable-inline-files */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[152] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[151] /* inline-globally */,0,C_SCHEME_TRUE);
t6=t2;
f_1662(t6,t5);}
else{
t3=t2;
f_1662(t3,C_SCHEME_UNDEFINED);}}

/* k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1662,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3352,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 251  collect-options */
t4=((C_word*)t0)[17];
f_1472(t4,t3,lf[355]);}

/* k3350 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[287]+1),t1);}

/* k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! disabled-warnings ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[353],((C_word*)t0)[34]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3347,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 253  dribble */
t5=((C_word*)t0)[22];
f_1270(t5,t4,lf[354],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1669(t4,C_SCHEME_UNDEFINED);}}

/* k3345 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[125] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_1669(t3,t2);}

/* k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1669,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[96],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[96] /* optimize-leaf-routines */,0,C_SCHEME_TRUE);
t4=t2;
f_1672(t4,t3);}
else{
t3=t2;
f_1672(t3,C_SCHEME_UNDEFINED);}}

/* k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1672(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1672,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[149],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[149] /* unsafe */,0,C_SCHEME_TRUE);
t4=t2;
f_1675(t4,t3);}
else{
t3=t2;
f_1675(t3,C_SCHEME_UNDEFINED);}}

/* k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1675,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
t3=(C_truep(((C_word*)t0)[20])?(C_word)C_i_memq(lf[351],((C_word*)t0)[34]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_set_block_item(lf[352] /* emit-unsafe-marker */,0,C_SCHEME_TRUE);
t5=t2;
f_1678(t5,t4);}
else{
t4=t2;
f_1678(t4,C_SCHEME_UNDEFINED);}}

/* k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1678,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[349],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[350] /* insert-timer-checks */,0,C_SCHEME_FALSE);
t4=t2;
f_1681(t4,t3);}
else{
t3=t2;
f_1681(t3,C_SCHEME_UNDEFINED);}}

/* k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1681,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[346],((C_word*)t0)[34]))){
t3=C_mutate((C_word*)lf[347]+1 /* (set! number-type ...) */,lf[348]);
t4=t2;
f_1684(t4,t3);}
else{
t3=t2;
f_1684(t3,C_SCHEME_UNDEFINED);}}

/* k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1684,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[344],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[345] /* block-compilation */,0,C_SCHEME_TRUE);
t4=t2;
f_1687(t4,t3);}
else{
t3=t2;
f_1687(t3,C_SCHEME_UNDEFINED);}}

/* k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1687,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[342],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[343] /* external-protos-first */,0,C_SCHEME_TRUE);
t4=t2;
f_1690(t4,t3);}
else{
t3=t2;
f_1690(t3,C_SCHEME_UNDEFINED);}}

/* k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1690(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1690,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[341],((C_word*)t0)[34]))){
t3=C_set_block_item(lf[152] /* inline-locally */,0,C_SCHEME_TRUE);
t4=t2;
f_1693(t4,t3);}
else{
t3=t2;
f_1693(t3,C_SCHEME_UNDEFINED);}}

/* k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1693,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[59],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=C_set_block_item(lf[152] /* inline-locally */,0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[340] /* local-definitions */,0,C_SCHEME_TRUE);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3306,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 269  option-arg */
f_1165(t6,t2);}
else{
t4=t3;
f_1699(t4,C_SCHEME_FALSE);}}

/* k3304 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[130]+1 /* (set! inline-output-file ...) */,t1);
t3=((C_word*)t0)[2];
f_1699(t3,t2);}

/* k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1699,NULL,2,t0,t1);}
t2=(C_word)C_i_memq(lf[60],((C_word*)t0)[34]);
t3=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[34],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],a[34]=((C_word*)t0)[33],tmp=(C_word)a,a+=35,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 272  option-arg */
f_1165(t4,t2);}
else{
t4=t3;
f_1705(t4,C_SCHEME_FALSE);}}

/* k3289 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3294,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 273  string->number */
C_string_to_number(3,0,t2,t1);}

/* k3292 in k3289 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_3297(2,t3,t1);}
else{
/* batch-driver.scm: 274  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t2,lf[339],((C_word*)t0)[2]);}}

/* k3295 in k3292 in k3289 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[338]+1 /* (set! inline-max-size ...) */,t1);
t3=((C_word*)t0)[2];
f_1705(t3,t2);}

/* k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1705,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[336],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3281,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 276  dribble */
t4=((C_word*)t0)[22];
f_1270(t4,t3,lf[337],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1708(2,t3,C_SCHEME_UNDEFINED);}}

/* k3279 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 277  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t2,lf[336]);}

/* k3282 in k3279 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 278  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[321]))(3,*((C_word*)lf[321]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|34,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],a[34]=((C_word*)t0)[34],tmp=(C_word)a,a+=35,tmp);
if(C_truep((C_word)C_i_memq(lf[334],((C_word*)t0)[30]))){
/* batch-driver.scm: 280  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[202]))(4,*((C_word*)lf[202]+1),t2,lf[208],lf[335]);}
else{
t3=t2;
f_1711(2,t3,C_SCHEME_UNDEFINED);}}

/* k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],a[33]=((C_word*)t0)[34],tmp=(C_word)a,a+=34,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 282  option-arg */
f_1165(t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_1714(2,t3,C_SCHEME_UNDEFINED);}}

/* k3237 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(lf[328],t1))){
/* batch-driver.scm: 283  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[329]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[330],t1))){
/* batch-driver.scm: 284  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[320]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[331],t1))){
/* batch-driver.scm: 285  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],lf[332]);}
else{
/* batch-driver.scm: 286  quit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[333]);}}}}

/* k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[325],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3233,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 288  dribble */
t4=((C_word*)t0)[21];
f_1270(t4,t3,lf[327],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1717(2,t3,C_SCHEME_UNDEFINED);}}

/* k3231 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 289  parenthesis-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[326]))(3,*((C_word*)lf[326]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[323],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 291  dribble */
t4=((C_word*)t0)[21];
f_1270(t4,t3,lf[324],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1720(2,t3,C_SCHEME_UNDEFINED);}}

/* k3222 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 292  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[318]))(3,*((C_word*)lf[318]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],a[33]=((C_word*)t0)[33],tmp=(C_word)a,a+=34,tmp);
if(C_truep((C_word)C_i_memq(lf[317],((C_word*)t0)[29]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3206,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 294  dribble */
t4=((C_word*)t0)[21];
f_1270(t4,t3,lf[322],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1723(2,t3,C_SCHEME_UNDEFINED);}}

/* k3204 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 295  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[321]))(3,*((C_word*)lf[321]+1),t2,C_SCHEME_FALSE);}

/* k3207 in k3204 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 296  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,lf[320]);}

/* k3210 in k3207 in k3204 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 297  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[319]))(3,*((C_word*)lf[319]+1),t2,C_SCHEME_FALSE);}

/* k3213 in k3210 in k3207 in k3204 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 298  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[318]))(3,*((C_word*)lf[318]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1723,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! verbose-mode ...) */,((C_word*)t0)[33]);
t3=C_set_block_item(lf[62] /* read-error-with-line-number */,0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[33],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3200,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 302  collect-options */
t7=((C_word*)t0)[16];
f_1472(t7,t6,lf[316]);}

/* k3198 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[315]),t1);}

/* k3194 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 302  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[220]+1)))(5,*((C_word*)lf[220]+1),((C_word*)t0)[3],t1,C_retrieve(lf[63]),((C_word*)t0)[2]);}

/* k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t4=(C_truep(((C_word*)t0)[20])?(C_truep(((C_word*)t0)[27])?(C_word)C_i_string_equal_p(((C_word*)t0)[20],((C_word*)t0)[27]):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t4)){
/* batch-driver.scm: 306  quit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),t3,lf[314]);}
else{
t5=t3;
f_1732(2,t5,C_SCHEME_UNDEFINED);}}

/* k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 307  collect-options */
t4=((C_word*)t0)[16];
f_1472(t4,t3,lf[233]);}

/* k3178 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[287]+1),t1);}

/* k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[32])+1,t1);
t3=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[32],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[312],((C_word*)t0)[29]))){
t4=C_set_block_item(lf[313] /* undefine-shadowed-macros */,0,C_SCHEME_FALSE);
t5=t3;
f_1739(t5,t4);}
else{
t4=t3;
f_1739(t4,C_SCHEME_UNDEFINED);}}

/* k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1739,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[310],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[311] /* no-argc-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1742(t4,t3);}
else{
t3=t2;
f_1742(t3,C_SCHEME_UNDEFINED);}}

/* k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1742(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1742,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[308],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[309] /* no-bound-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1745(t4,t3);}
else{
t3=t2;
f_1745(t3,C_SCHEME_UNDEFINED);}}

/* k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1745(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1745,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[306],((C_word*)t0)[30]))){
t3=C_set_block_item(lf[307] /* no-procedure-checks */,0,C_SCHEME_TRUE);
t4=t2;
f_1748(t4,t3);}
else{
t3=t2;
f_1748(t3,C_SCHEME_UNDEFINED);}}

/* k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1748,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
if(C_truep((C_word)C_i_memq(lf[302],((C_word*)t0)[30]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3099,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t5=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve(lf[277]));}
else{
t3=t2;
f_1751(2,t3,C_SCHEME_UNDEFINED);}}

/* a3098 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3099,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3130,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_3105(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_3105(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}

/* k3103 in a3098 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[303]))(5,*((C_word*)lf[303]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[305],t1);}

/* k3128 in a3098 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3135(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3135(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3133 in k3128 in a3098 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[303]))(5,*((C_word*)lf[303]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[304],t1);}

/* k3029 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3036,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[279]));}

/* a3035 in k3029 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3036,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3067,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3042,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_3042(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_3042(2,t8,(C_word)C_i_car(t5));}
else{
/* ##sys#error */
t8=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}

/* k3040 in a3035 in k3029 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[303]))(5,*((C_word*)lf[303]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[305],t1);}

/* k3065 in a3035 in k3029 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3067,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3072,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3072(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3072(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3070 in k3065 in a3035 in k3029 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[303]))(5,*((C_word*)lf[303]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[304],t1);}

/* k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3017,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 331  collect-options */
t6=((C_word*)t0)[17];
f_1472(t6,t5,lf[301]);}

/* k3023 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 331  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[300]))(4,*((C_word*)lf[300]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3016 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3017,3,t0,t1,t2);}
/* string-split */
((C_proc4)C_retrieve_symbol_proc(lf[298]))(4,*((C_word*)lf[298]+1),t1,t2,lf[299]);}

/* k3013 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[297]),t1);}

/* k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1754,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[64],C_retrieve(lf[65]));
t3=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],a[32]=((C_word*)t0)[32],tmp=(C_word)a,a+=33,tmp);
/* batch-driver.scm: 335  collect-options */
t5=((C_word*)t0)[17];
f_1472(t5,t4,lf[296]);}

/* k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|33,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],a[32]=((C_word*)t0)[31],a[33]=((C_word*)t0)[32],tmp=(C_word)a,a+=34,tmp);
/* batch-driver.scm: 336  dribble */
t3=((C_word*)t0)[22];
f_1270(t3,t2,lf[295],C_SCHEME_END_OF_LIST);}

/* k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|32,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],a[32]=((C_word*)t0)[33],tmp=(C_word)a,a+=33,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 337  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[294]))(3,*((C_word*)lf[294]+1),t2,C_SCHEME_TRUE);}
else{
t3=t2;
f_1767(2,t3,C_SCHEME_UNDEFINED);}}

/* k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],a[30]=((C_word*)t0)[31],a[31]=((C_word*)t0)[32],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3000,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2999 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3000,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3008,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 339  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[159]))(5,*((C_word*)lf[159]+1),t3,t2,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3006 in a2999 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 339  load */
((C_proc3)C_retrieve_symbol_proc(lf[293]))(3,*((C_word*)lf[293]+1),((C_word*)t0)[2],t1);}

/* k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 341  delete */
((C_proc5)C_retrieve_symbol_proc(lf[291]))(5,*((C_word*)lf[291]+1),t2,lf[64],C_retrieve(lf[65]),*((C_word*)lf[292]+1));}

/* k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[66],C_retrieve(lf[65]));
t4=C_mutate((C_word*)lf[65]+1 /* (set! features ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],a[31]=((C_word*)t0)[31],tmp=(C_word)a,a+=32,tmp);
/* batch-driver.scm: 344  user-post-analysis-pass */
((C_proc2)C_retrieve_symbol_proc(lf[6]))(2,*((C_word*)lf[6]+1),t5);}

/* k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 347  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),t3,((C_word*)((C_word*)t0)[30])[1],C_retrieve(lf[290]));}

/* k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[30])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2998,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 349  collect-options */
t5=((C_word*)t0)[16];
f_1472(t5,t4,lf[289]);}

/* k2996 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[287]+1),t1);}

/* k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|31,a[1]=(C_word)f_1793,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],a[26]=((C_word*)t0)[25],a[27]=((C_word*)t0)[26],a[28]=((C_word*)t0)[27],a[29]=((C_word*)t0)[28],a[30]=((C_word*)t0)[29],a[31]=((C_word*)t0)[30],tmp=(C_word)a,a+=32,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2964,a[2]=((C_word*)t0)[30],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2966,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2986,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 355  collect-options */
t8=((C_word*)t0)[16];
f_1472(t8,t7,lf[288]);}

/* k2992 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[287]+1),t1);}

/* k2988 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 355  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2984 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2965 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2966,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[286],t5));}

/* k2962 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 352  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1793,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[31])+1,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[31],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
/* batch-driver.scm: 359  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),t3,C_retrieve(lf[67]),((C_word*)t0)[2]);}

/* k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|30,a[1]=(C_word)f_1800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],a[25]=((C_word*)t0)[25],a[26]=((C_word*)t0)[26],a[27]=((C_word*)t0)[27],a[28]=((C_word*)t0)[28],a[29]=((C_word*)t0)[29],a[30]=((C_word*)t0)[30],tmp=(C_word)a,a+=31,tmp);
if(C_truep((C_word)C_i_memq(lf[284],((C_word*)t0)[30]))){
t4=C_set_block_item(lf[285] /* enable-runtime-macros */,0,C_SCHEME_TRUE);
t5=t3;
f_1800(t5,t4);}
else{
t4=t3;
f_1800(t4,C_SCHEME_UNDEFINED);}}

/* k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1800,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|29,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],a[29]=((C_word*)t0)[30],tmp=(C_word)a,a+=30,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 365  option-arg */
f_1165(t3,((C_word*)t0)[2]);}
else{
t3=C_retrieve(lf[283]);
if(C_truep(t3)){
t4=(C_word)C_eqp(t3,C_fix(0));
t5=t2;
f_1804(2,t5,(C_truep(t4)?C_SCHEME_FALSE:t3));}
else{
t4=t2;
f_1804(2,t4,C_SCHEME_FALSE);}}}

/* k2941 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 365  arg-val */
f_1392(((C_word*)t0)[2],t1);}

/* k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1804,2,t0,t1);}
t2=C_mutate((C_word*)lf[68]+1 /* (set! target-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|28,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],a[28]=((C_word*)t0)[29],tmp=(C_word)a,a+=29,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2936,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 369  option-arg */
f_1165(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1808(2,t4,C_SCHEME_FALSE);}}

/* k2934 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 369  arg-val */
f_1392(((C_word*)t0)[2],t1);}

/* k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1808,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! target-initial-heap-size ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|27,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],a[27]=((C_word*)t0)[28],tmp=(C_word)a,a+=28,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2929,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 370  option-arg */
f_1165(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1812(2,t4,C_SCHEME_FALSE);}}

/* k2927 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 370  arg-val */
f_1392(((C_word*)t0)[2],t1);}

/* k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=C_mutate((C_word*)lf[70]+1 /* (set! target-heap-growth ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|26,a[1]=(C_word)f_1816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],a[24]=((C_word*)t0)[25],a[25]=((C_word*)t0)[26],a[26]=((C_word*)t0)[27],tmp=(C_word)a,a+=27,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2922,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 371  option-arg */
f_1165(t4,((C_word*)t0)[2]);}
else{
t4=t3;
f_1816(2,t4,C_SCHEME_FALSE);}}

/* k2920 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 371  arg-val */
f_1392(((C_word*)t0)[2],t1);}

/* k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=C_mutate((C_word*)lf[71]+1 /* (set! target-heap-shrinkage ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[20],a[18]=((C_word*)t0)[21],a[19]=((C_word*)t0)[22],a[20]=((C_word*)t0)[23],a[21]=((C_word*)t0)[24],a[22]=((C_word*)t0)[25],a[23]=((C_word*)t0)[26],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 374  option-arg */
f_1165(t4,((C_word*)t0)[4]);}
else{
t4=C_retrieve(lf[282]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t3;
f_1820(2,t6,(C_truep(t5)?C_SCHEME_FALSE:t4));}
else{
t5=t3;
f_1820(2,t5,C_SCHEME_FALSE);}}}

/* k2900 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 374  arg-val */
f_1392(((C_word*)t0)[2],t1);}

/* k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=C_mutate((C_word*)lf[72]+1 /* (set! target-stack-size ...) */,t1);
t3=(C_word)C_i_memq(lf[73],((C_word*)t0)[23]);
t4=(C_word)C_i_not(t3);
t5=C_mutate((C_word*)lf[74]+1 /* (set! emit-trace-info ...) */,t4);
t6=(C_word)C_i_memq(lf[75],((C_word*)t0)[23]);
t7=C_mutate((C_word*)lf[76]+1 /* (set! disable-stack-overflow-checking ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[280],C_retrieve(lf[33])))){
/* batch-driver.scm: 380  set-gc-report! */
((C_proc3)C_retrieve_symbol_proc(lf[281]))(3,*((C_word*)lf[281]+1),t8,C_SCHEME_TRUE);}
else{
t9=t8;
f_1831(2,t9,C_SCHEME_UNDEFINED);}}

/* k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep((C_word)C_i_memq(lf[275],((C_word*)t0)[23]))){
t3=t2;
f_1834(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_mutate((C_word*)lf[276]+1 /* (set! standard-bindings ...) */,C_retrieve(lf[277]));
t4=C_mutate((C_word*)lf[278]+1 /* (set! extended-bindings ...) */,C_retrieve(lf[279]));
t5=t2;
f_1834(t5,t4);}}

/* k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1834,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(C_truep(C_retrieve(lf[74]))?lf[272]:lf[273]);
/* batch-driver.scm: 384  dribble */
t4=((C_word*)t0)[15];
f_1270(t4,t2,lf[274],(C_word)C_a_i_list(&a,1,t3));}

/* k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_eqp(lf[264],t3);
t5=C_set_block_item(lf[225] /* emit-profile */,0,C_SCHEME_TRUE);
t6=C_mutate((C_word*)lf[265]+1 /* (set! profiled-procedures ...) */,lf[266]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2861,a[2]=t2,a[3]=((C_word*)t0)[15],a[4]=t4,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t8=(C_truep(t4)?lf[270]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 393  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[220]+1)))(5,*((C_word*)lf[220]+1),t7,((C_word*)((C_word*)t0)[6])[1],C_retrieve(lf[271]),t8);}
else{
t3=t2;
f_1840(2,t3,C_SCHEME_UNDEFINED);}}

/* k2859 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2861,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_truep(((C_word*)t0)[4])?lf[267]:lf[268]);
/* batch-driver.scm: 399  dribble */
t4=((C_word*)t0)[3];
f_1270(t4,((C_word*)t0)[2],lf[269],(C_word)C_a_i_list(&a,1,t3));}

/* k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 402  load-identifier-database */
((C_proc3)C_retrieve_symbol_proc(lf[262]))(3,*((C_word*)lf[262]+1),t2,lf[263]);}

/* k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
if(C_truep((C_word)C_i_memq(lf[77],((C_word*)t0)[22]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[21],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 405  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_i_memq(lf[80],((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(t2)){
t4=t3;
f_1864(t4,t2);}
else{
t4=(C_word)C_i_memq(lf[259],((C_word*)t0)[22]);
if(C_truep(t4)){
t5=t3;
f_1864(t5,t4);}
else{
t5=(C_word)C_i_memq(lf[260],((C_word*)t0)[22]);
t6=t3;
f_1864(t6,(C_truep(t5)?t5:(C_word)C_i_memq(lf[261],((C_word*)t0)[22])));}}}}

/* k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1864,NULL,2,t0,t1);}
if(C_truep(t1)){
/* batch-driver.scm: 408  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[81]))(2,*((C_word*)lf[81]+1),((C_word*)t0)[22]);}
else{
if(C_truep((C_word)C_i_memq(lf[82],((C_word*)t0)[21]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 410  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[84]))(2,*((C_word*)lf[84]+1),t3);}
else{
t2=((C_word*)t0)[20];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[21],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[22],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],a[18]=((C_word*)t0)[16],a[19]=((C_word*)t0)[17],a[20]=((C_word*)t0)[18],a[21]=((C_word*)t0)[19],a[22]=((C_word*)t0)[20],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 418  dribble */
t4=((C_word*)t0)[14];
f_1270(t4,t3,lf[257],(C_word)C_a_i_list(&a,1,((C_word*)t0)[20]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[22],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 413  print-version */
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t3,C_SCHEME_TRUE);}}}}

/* k1890 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 414  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],lf[258]);}

/* k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1898,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! source-filename ...) */,((C_word*)t0)[22]);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[22],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 420  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t3,lf[252],lf[256],((C_word*)t0)[9]);}

/* k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 421  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[252],lf[255],C_retrieve(lf[33]));}

/* k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 422  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[252],lf[254],C_retrieve(lf[68]));}

/* k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 423  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[252],lf[253],C_retrieve(lf[72]));}

/* k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1911,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(6));
t3=C_mutate(((C_word *)((C_word*)t0)[22])+1,t2);
t4=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[22],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 427  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[250]+1)))(4,*((C_word*)lf[250]+1),t4,C_retrieve(lf[251]),C_SCHEME_END_OF_LIST);}

/* k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1919,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! line-number-database ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_1922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* batch-driver.scm: 428  collect-options */
t4=((C_word*)t0)[10];
f_1472(t4,t3,lf[249]);}

/* k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
/* batch-driver.scm: 429  collect-options */
t3=((C_word*)t0)[10];
f_1472(t3,t2,lf[248]);}

/* k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[11],a[3]=t2,a[4]=((C_word*)t0)[17],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 431  collect-options */
t4=((C_word*)t0)[11];
f_1472(t4,t3,lf[247]);}

/* k2827 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2837,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 433  collect-options */
t4=((C_word*)t0)[2];
f_1472(t4,t3,lf[246]);}

/* k2835 in k2827 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 430  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[220]+1)))(5,*((C_word*)lf[220]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|25,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],a[25]=((C_word*)t0)[24],tmp=(C_word)a,a+=26,tmp);
/* batch-driver.scm: 435  user-read-pass */
((C_proc2)C_retrieve_symbol_proc(lf[3]))(2,*((C_word*)lf[3]+1),t2);}

/* k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[16],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[18],a[15]=((C_word*)t0)[19],a[16]=((C_word*)t0)[20],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[22],a[19]=((C_word*)t0)[23],a[20]=((C_word*)t0)[24],a[21]=((C_word*)t0)[25],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2735,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 437  dribble */
t4=((C_word*)t0)[21];
f_1270(t4,t3,lf[239],C_SCHEME_END_OF_LIST);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2744(t6,t2,((C_word*)t0)[4]);}}

/* doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_2744(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2744,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2755,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* map */
t5=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve(lf[240]),((C_word*)t0)[4]);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 447  check-and-open-input-file */
((C_proc3)C_retrieve_symbol_proc(lf[245]))(3,*((C_word*)lf[245]+1),t4,t3);}}

/* k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2773,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2785,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2822,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[244]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2821 in k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[242]));
t3=C_mutate((C_word*)lf[242]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2789 in k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2794,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 449  read-form */
t3=((C_word*)t0)[2];
f_1529(t3,t2,((C_word*)t0)[5]);}

/* k2792 in a2789 in k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2799(t5,((C_word*)t0)[2],t1);}

/* doloop715 in k2792 in a2789 in k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_2799(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2799,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
/* batch-driver.scm: 452  close-checked-input-file */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),t1,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2820,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 450  read-form */
t6=((C_word*)t0)[2];
f_1529(t6,t5,((C_word*)t0)[6]);}}

/* k2818 in doloop715 in k2792 in a2789 in k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2799(t2,((C_word*)t0)[2],t1);}

/* a2784 in k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[242]));
t3=C_mutate((C_word*)lf[242]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2774 in k2771 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2744(t3,((C_word*)t0)[2],t2);}

/* k2757 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 444  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[241]+1)))(3,*((C_word*)lf[241]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2761 in k2757 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2767,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* map */
t3=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[240]),((C_word*)t0)[2]);}

/* k2765 in k2761 in k2757 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 443  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[220]+1)))(5,*((C_word*)lf[220]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2753 in doloop686 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2733 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2739,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 438  proc */
t3=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2737 in k2733 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1934(2,t3,t2);}

/* k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 456  user-preprocessor-pass */
((C_proc2)C_retrieve_symbol_proc(lf[4]))(2,*((C_word*)lf[4]+1),t2);}

/* k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2728,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 458  dribble */
t4=((C_word*)t0)[17];
f_1270(t4,t3,lf[238],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1940(t3,C_SCHEME_UNDEFINED);}}

/* k2726 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2730 in k2726 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1940(t3,t2);}

/* k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1940,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],tmp=(C_word)a,a+=22,tmp);
/* batch-driver.scm: 461  print-expr */
t3=((C_word*)t0)[7];
f_1331(t3,t2,lf[236],lf[237],((C_word*)((C_word*)t0)[3])[1]);}

/* k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1943,2,t0,t1);}
t2=f_1502(((C_word*)t0)[21]);
t3=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],tmp=(C_word)a,a+=21,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t4=t3;
f_1949(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2705,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 464  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),t4,C_retrieve(lf[67]),((C_word*)((C_word*)t0)[2])[1]);}}

/* k2703 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2705,2,t0,t1);}
t2=C_mutate((C_word*)lf[67]+1 /* (set! explicit-library-modules ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t4=*((C_word*)lf[235]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* k2723 in k2703 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[233],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[234],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=((C_word*)t0)[2];
f_1949(t7,t6);}

/* k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1949,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[18],a[17]=((C_word*)t0)[19],a[18]=((C_word*)t0)[20],tmp=(C_word)a,a+=19,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2698,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 466  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),t3,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2696 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[232]),t1);}

/* k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* batch-driver.scm: 467  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[231]))(2,*((C_word*)lf[231]+1),t2);}

/* k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=(C_word)C_i_length(C_retrieve(lf[86]));
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[18],a[16]=((C_word*)t0)[19],tmp=(C_word)a,a+=17,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2666,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_retrieve(lf[230]));}

/* a2665 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2666(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2666,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[222],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_cons(&a,2,lf[227],t8));}

/* k2538 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2656,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[229]));}

/* a2655 in k2538 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2656,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[228],t3));}

/* k2542 in k2538 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[225]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[222],t3);
t5=(C_truep(C_retrieve(lf[207]))?C_SCHEME_FALSE:((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[222],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t4,t8);
t10=(C_word)C_a_i_cons(&a,2,lf[226],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[223]),t11);
t13=(C_word)C_a_i_cons(&a,2,lf[227],t12);
t14=t2;
f_2548(t14,(C_word)C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST));}
else{
t3=t2;
f_2548(t3,C_SCHEME_END_OF_LIST);}}

/* k2546 in k2542 in k2538 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_2548(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2548,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2567,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[86]));}

/* a2566 in k2546 in k2542 in k2538 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2567,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[222],t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[222],t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t5,t9);
t11=(C_word)C_a_i_cons(&a,2,C_retrieve(lf[223]),t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,(C_word)C_a_i_cons(&a,2,lf[224],t11));}

/* k2550 in k2546 in k2542 in k2538 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_retrieve(lf[207]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[8]));
t4=(C_truep(t3)?((C_word*)((C_word*)t0)[7])[1]:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 469  append */
((C_proc9)C_retrieve_proc(*((C_word*)lf[220]+1)))(9,*((C_word*)lf[220]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],t4,lf[221]);}

/* k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[217])))){
/* batch-driver.scm: 491  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t5,lf[218],lf[219]);}
else{
t6=t5;
f_2513(2,t6,C_SCHEME_FALSE);}}

/* k2511 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2518,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[217]));}
else{
t2=((C_word*)t0)[2];
f_1964(2,t2,C_SCHEME_UNDEFINED);}}

/* a2517 in k2511 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2518,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
/* batch-driver.scm: 493  printf */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t1,lf[216],t3,t4);}

/* k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2507,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 495  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[214],lf[215]);}

/* k2505 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 496  display-real-name-table */
((C_proc2)C_retrieve_symbol_proc(lf[213]))(2,*((C_word*)lf[213]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1967(2,t2,C_SCHEME_UNDEFINED);}}

/* k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2501,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 497  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[211],lf[212]);}

/* k2499 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 498  display-line-number-database */
((C_proc2)C_retrieve_symbol_proc(lf[210]))(2,*((C_word*)lf[210]+1),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
f_1970(2,t2,C_SCHEME_UNDEFINED);}}

/* k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(C_truep(C_retrieve(lf[207]))?((C_word*)t0)[10]:C_SCHEME_FALSE);
if(C_truep(t3)){
/* batch-driver.scm: 501  compiler-warning */
((C_proc5)C_retrieve_symbol_proc(lf[202]))(5,*((C_word*)lf[202]+1),t2,lf[208],lf[209],C_retrieve(lf[207]));}
else{
t4=t2;
f_1973(2,t4,C_SCHEME_UNDEFINED);}}

/* k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[149]))){
/* batch-driver.scm: 503  feature? */
((C_proc3)C_retrieve_symbol_proc(lf[205]))(3,*((C_word*)lf[205]+1),t3,lf[206]);}
else{
t4=t3;
f_2486(2,t4,C_SCHEME_FALSE);}}

/* k2484 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 504  compiler-warning */
((C_proc4)C_retrieve_symbol_proc(lf[202]))(4,*((C_word*)lf[202]+1),((C_word*)t0)[2],lf[203],lf[204]);}
else{
t2=((C_word*)t0)[2];
f_1976(2,t2,C_SCHEME_UNDEFINED);}}

/* k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! line-number-database ...) */,C_retrieve(lf[87]));
t3=C_set_block_item(lf[87] /* line-number-database-2 */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_1981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 511  end-time */
t5=((C_word*)t0)[16];
f_1512(t5,t4,lf[201]);}

/* k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 512  print-expr */
t3=((C_word*)t0)[2];
f_1331(t3,t2,lf[199],lf[200],((C_word*)((C_word*)t0)[3])[1]);}

/* k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_memq(lf[198],((C_word*)t0)[3]))){
/* batch-driver.scm: 514  exit */
((C_proc2)C_retrieve_symbol_proc(lf[123]))(2,*((C_word*)lf[123]+1),t2);}
else{
t3=t2;
f_1987(2,t3,C_SCHEME_UNDEFINED);}}

/* k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* batch-driver.scm: 516  user-pass */
((C_proc2)C_retrieve_symbol_proc(lf[5]))(2,*((C_word*)lf[5]+1),t2);}

/* k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2467,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 518  dribble */
t4=((C_word*)t0)[12];
f_1270(t4,t3,lf[197],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1993(2,t3,C_SCHEME_UNDEFINED);}}

/* k2465 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=f_1502(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k2472 in k2465 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* batch-driver.scm: 521  end-time */
t3=((C_word*)t0)[3];
f_1512(t3,((C_word*)t0)[2],lf[196]);}

/* k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 526  canonicalize-begin-body */
((C_proc3)C_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k2462 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 525  build-node-graph */
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),((C_word*)t0)[2],t1);}

/* k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_record(&a,4,lf[88],lf[89],lf[90],t2);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=((C_word*)t0)[15],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 529  print-node */
t7=((C_word*)t0)[12];
f_1294(t7,t6,lf[192],lf[193],t3);}

/* k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 530  initialize-analysis-database */
((C_proc2)C_retrieve_symbol_proc(lf[191]))(2,*((C_word*)lf[191]+1),t2);}

/* k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],tmp=(C_word)a,a+=17,tmp);
if(C_truep(C_retrieve(lf[176]))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[16],a[7]=t2,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[17],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_memq(lf[189],((C_word*)t0)[2]))){
t4=t3;
f_2410(2,t4,C_SCHEME_UNDEFINED);}
else{
/* batch-driver.scm: 535  load-type-database */
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),t3,lf[190]);}}
else{
t3=t2;
f_2008(t3,C_SCHEME_UNDEFINED);}}

/* k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2442,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2450,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 536  collect-options */
t5=((C_word*)t0)[2];
f_1472(t5,t4,lf[188]);}

/* k2448 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2441 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2442,3,t0,t1,t2);}
/* ##compiler#load-type-database */
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t1,t2,C_SCHEME_FALSE);}

/* k2411 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
t2=f_1502(((C_word*)t0)[8]);
t3=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 539  analyze */
t5=((C_word*)t0)[2];
f_1535(t5,t4,lf[186],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k2419 in k2411 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2421,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2424,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 540  print-db */
t4=((C_word*)t0)[2];
f_1316(t4,t3,lf[185],lf[179],((C_word*)((C_word*)t0)[7])[1],C_fix(0));}

/* k2422 in k2419 in k2411 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 541  end-time */
t3=((C_word*)t0)[4];
f_1512(t3,t2,lf[184]);}

/* k2425 in k2422 in k2419 in k2411 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2427,2,t0,t1);}
t2=f_1502(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 543  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[102],lf[183]);}

/* k2431 in k2425 in k2422 in k2419 in k2411 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 544  scrutinize */
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2434 in k2431 in k2425 in k2422 in k2419 in k2411 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 545  end-time */
t3=((C_word*)t0)[2];
f_1512(t3,t2,lf[181]);}

/* k2437 in k2434 in k2431 in k2425 in k2422 in k2419 in k2411 in k2408 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2008(t3,t2);}

/* k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_2008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2008,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[171]))){
t3=f_1502(((C_word*)t0)[16]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=((C_word*)t0)[16],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve(lf[176]))){
t5=t4;
f_2383(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 552  analyze */
t7=((C_word*)t0)[14];
f_1535(t7,t6,lf[180],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}}
else{
t3=t2;
f_2011(t3,C_SCHEME_UNDEFINED);}}

/* k2399 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 553  print-db */
t4=((C_word*)t0)[2];
f_1316(t4,t3,lf[178],lf[179],((C_word*)((C_word*)t0)[5])[1],C_fix(0));}

/* k2402 in k2399 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 554  end-time */
t2=((C_word*)t0)[3];
f_1512(t2,((C_word*)t0)[2],lf[177]);}

/* k2381 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=f_1502(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 556  perform-lambda-lifting! */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2387 in k2381 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 557  end-time */
t3=((C_word*)t0)[2];
f_1512(t3,t2,lf[174]);}

/* k2390 in k2387 in k2381 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 558  print-node */
t3=((C_word*)t0)[3];
f_1294(t3,t2,lf[172],lf[173],((C_word*)t0)[2]);}

/* k2393 in k2390 in k2387 in k2381 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2011(t3,t2);}

/* k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_2011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2011,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 561  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[169]+1)))(3,*((C_word*)lf[169]+1),t3,C_retrieve(lf[170]));}

/* k2375 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 561  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[163]))(3,*((C_word*)lf[163]+1),((C_word*)t0)[2],t1);}

/* k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2017,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2370,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 562  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[167],lf[168]);}

/* k2368 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 563  pp */
((C_proc3)C_retrieve_symbol_proc(lf[166]))(3,*((C_word*)lf[166]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2017(2,t2,C_SCHEME_UNDEFINED);}}

/* k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[156]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2363,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2367,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[165]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_2020(2,t3,C_SCHEME_UNDEFINED);}}

/* k2365 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 573  concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[163]))(3,*((C_word*)lf[163]+1),((C_word*)t0)[2],t1);}

/* k2361 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2331 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2332,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2355,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 568  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[162]+1)))(3,*((C_word*)lf[162]+1),t5,t2);}

/* k2357 in a2331 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 568  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[160]))(5,*((C_word*)lf[160]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1,lf[161]);}

/* k2353 in a2331 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 567  ##sys#resolve-include-filename */
((C_proc5)C_retrieve_symbol_proc(lf[159]))(5,*((C_word*)lf[159]+1),((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k2334 in a2331 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2336,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 570  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[158]))(3,*((C_word*)lf[158]+1),t2,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2343 in k2334 in a2331 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 571  dribble */
t3=((C_word*)t0)[2];
f_1270(t3,t2,lf[157],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2346 in k2343 in k2334 in a2331 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 572  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 574  collect-options */
t3=((C_word*)t0)[2];
f_1472(t3,t2,lf[155]);}

/* k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_2026(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(lf[151] /* inline-globally */,0,C_SCHEME_TRUE);
t4=C_set_block_item(lf[152] /* inline-locally */,0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t6=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t2,t5,t1);}}

/* a2319 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2320,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 580  dribble */
t4=((C_word*)t0)[2];
f_1270(t4,t3,lf[154],(C_word)C_a_i_list(&a,1,t2));}

/* k2322 in a2319 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 581  load-inline-file */
((C_proc3)C_retrieve_symbol_proc(lf[153]))(3,*((C_word*)lf[153]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=C_set_block_item(lf[43] /* line-number-database */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[91] /* constant-table */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[92] /* inline-table */,0,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_retrieve(lf[149]))){
t6=t5;
f_2032(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(3));
t7=(C_word)C_i_car(t6);
/* batch-driver.scm: 588  scan-toplevel-assignments */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),t5,t7);}}

/* k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=f_1502(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 591  perform-cps-conversion */
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),t3,((C_word*)t0)[2]);}

/* k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2041,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 592  end-time */
t3=((C_word*)t0)[12];
f_1512(t3,t2,lf[147]);}

/* k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 593  print-node */
t3=((C_word*)t0)[11];
f_1294(t3,t2,lf[145],lf[146],((C_word*)t0)[2]);}

/* k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2049,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t3,a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp));
t5=((C_word*)t3)[1];
f_2049(t5,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2049,NULL,5,t0,t1,t2,t3,t4);}
t5=f_1502(((C_word*)t0)[13]);
t6=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=t3,a[16]=((C_word*)t0)[13],a[17]=t4,tmp=(C_word)a,a+=18,tmp);
/* batch-driver.scm: 599  analyze */
t7=((C_word*)t0)[10];
f_1535(t7,t6,lf[144],t3,(C_word)C_a_i_list(&a,2,t2,t4));}

/* k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=t1,a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
if(C_truep(C_retrieve(lf[93]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2284,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[142],C_retrieve(lf[33])))){
/* batch-driver.scm: 602  dump-undefined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[143]))(3,*((C_word*)lf[143]+1),t3,t1);}
else{
t4=t3;
f_2284(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_2059(2,t3,C_SCHEME_UNDEFINED);}}

/* k2282 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_memq(lf[140],C_retrieve(lf[33])))){
/* batch-driver.scm: 604  dump-defined-globals */
((C_proc3)C_retrieve_symbol_proc(lf[141]))(3,*((C_word*)lf[141]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2059(2,t2,C_SCHEME_UNDEFINED);}}

/* k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=C_set_block_item(lf[93] /* first-analysis */,0,C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 606  end-time */
t4=((C_word*)t0)[12];
f_1512(t4,t3,lf[139]);}

/* k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
/* batch-driver.scm: 607  print-db */
t3=((C_word*)t0)[2];
f_1316(t3,t2,lf[137],lf[138],((C_word*)t0)[15],((C_word*)t0)[14]);}

/* k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_memq(lf[135],C_retrieve(lf[33])))){
/* batch-driver.scm: 609  print-program-statistics */
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t2,((C_word*)t0)[15]);}
else{
t3=t2;
f_2069(2,t3,C_SCHEME_UNDEFINED);}}

/* k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
if(C_truep(((C_word*)t0)[18])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 612  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[101]))(5,*((C_word*)lf[101]+1),t2,lf[102],lf[107],((C_word*)t0)[14]);}
else{
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[17],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 636  print-node */
t3=((C_word*)t0)[10];
f_1294(t3,t2,lf[133],lf[134],((C_word*)t0)[16]);}}

/* k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(C_retrieve(lf[130]))){
t3=C_retrieve(lf[130]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[14],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 640  dribble */
t5=((C_word*)t0)[13];
f_1270(t5,t4,lf[132],(C_word)C_a_i_list(&a,1,t3));}
else{
t3=t2;
f_2164(2,t3,C_SCHEME_UNDEFINED);}}

/* k2270 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 641  emit-global-inline-file */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=f_1502(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
/* batch-driver.scm: 644  perform-closure-conversion */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,((C_word*)t0)[2],((C_word*)t0)[14]);}

/* k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t1,a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* batch-driver.scm: 645  end-time */
t3=((C_word*)t0)[11];
f_1512(t3,t2,lf[128]);}

/* k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
/* batch-driver.scm: 646  print-db */
t3=((C_word*)t0)[3];
f_1316(t3,t2,lf[126],lf[127],((C_word*)t0)[13],((C_word*)t0)[2]);}

/* k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[125]))){
t4=(C_word)C_fudge(C_fix(6));
t5=(C_word)C_fixnum_difference(t4,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_2255(t6,(C_word)C_fixnum_greaterp(t5,C_fix(60000)));}
else{
t4=t3;
f_2255(t4,C_SCHEME_FALSE);}}

/* k2253 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_2255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* batch-driver.scm: 648  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],lf[124]);}
else{
t2=((C_word*)t0)[2];
f_2179(2,t2,C_SCHEME_UNDEFINED);}}

/* k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 649  exit */
((C_proc3)C_retrieve_symbol_proc(lf[123]))(3,*((C_word*)lf[123]+1),t2,C_fix(0));}
else{
t3=t2;
f_2182(2,t3,C_SCHEME_UNDEFINED);}}

/* k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 650  print-node */
t3=((C_word*)t0)[2];
f_1294(t3,t2,lf[121],lf[122],((C_word*)t0)[10]);}

/* k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2185,2,t0,t1);}
t2=f_1502(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2199,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t1,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 655  end-time */
t7=((C_word*)t0)[6];
f_1512(t7,t6,lf[120]);}

/* k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=f_1502(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[8])){
/* batch-driver.scm: 658  open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t3,((C_word*)t0)[8]);}
else{
/* batch-driver.scm: 658  current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[119]+1)))(2,*((C_word*)lf[119]+1),t3);}}

/* k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* batch-driver.scm: 659  dribble */
t3=((C_word*)t0)[11];
f_1270(t3,t2,lf[117],(C_word)C_a_i_list(&a,1,((C_word*)t0)[8]));}

/* k2210 in k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 660  generate-code */
((C_proc9)C_retrieve_symbol_proc(lf[116]))(9,*((C_word*)lf[116]+1),t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[8],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2213 in k2210 in k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
/* batch-driver.scm: 661  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2218(2,t3,C_SCHEME_UNDEFINED);}}

/* k2216 in k2213 in k2210 in k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 662  end-time */
t3=((C_word*)t0)[2];
f_1512(t3,t2,lf[114]);}

/* k2219 in k2216 in k2213 in k2210 in k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_memq(lf[111],C_retrieve(lf[33])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2240,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 663  ##sys#stop-timer */
t4=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2224(2,t3,C_SCHEME_UNDEFINED);}}

/* k2238 in k2219 in k2216 in k2213 in k2210 in k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 663  ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* k2222 in k2219 in k2216 in k2213 in k2210 in k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 664  compiler-cleanup-hook */
((C_proc2)C_retrieve_symbol_proc(lf[110]))(2,*((C_word*)lf[110]+1),t2);}

/* k2225 in k2222 in k2219 in k2216 in k2213 in k2210 in k2207 in k2201 in a2198 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 665  dribble */
t2=((C_word*)t0)[3];
f_1270(t2,((C_word*)t0)[2],lf[109],C_SCHEME_END_OF_LIST);}

/* a2192 in k2183 in k2180 in k2177 in k2174 in k2171 in k2168 in k2162 in k2159 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
/* batch-driver.scm: 654  prepare-for-code-generation */
((C_proc4)C_retrieve_symbol_proc(lf[108]))(4,*((C_word*)lf[108]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=f_1502(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2089,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* batch-driver.scm: 617  end-time */
t5=((C_word*)t0)[4];
f_1512(t5,t4,lf[106]);}

/* k2091 in a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* batch-driver.scm: 618  print-node */
t3=((C_word*)t0)[2];
f_1294(t3,t2,lf[104],lf[105],((C_word*)t0)[6]);}

/* k2094 in k2091 in a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
if(C_truep(((C_word*)t0)[9])){
t2=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 620  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2049(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t2=C_retrieve(lf[95]);
if(C_truep(t2)){
if(C_truep(C_retrieve(lf[96]))){
t3=f_1502(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 627  analyze */
t5=((C_word*)t0)[2];
f_1535(t5,t4,lf[100],((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* batch-driver.scm: 633  loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2049(t4,((C_word*)t0)[6],t3,((C_word*)t0)[5],C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* batch-driver.scm: 622  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[101]))(4,*((C_word*)lf[101]+1),t3,lf[102],lf[103]);}}}

/* k2113 in k2094 in k2091 in a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_set_block_item(lf[95] /* inline-substitutions-enabled */,0,C_SCHEME_TRUE);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
/* batch-driver.scm: 624  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2049(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2130 in k2094 in k2091 in a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2135,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* batch-driver.scm: 628  end-time */
t3=((C_word*)t0)[2];
f_1512(t3,t2,lf[99]);}

/* k2133 in k2130 in k2094 in k2091 in a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=f_1502(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 630  transform-direct-lambdas! */
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),t3,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k2139 in k2133 in k2130 in k2094 in k2091 in a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2144,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* batch-driver.scm: 631  end-time */
t3=((C_word*)t0)[2];
f_1512(t3,t2,lf[97]);}

/* k2142 in k2139 in k2133 in k2130 in k2094 in k2091 in a2088 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[6]);
/* batch-driver.scm: 632  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2049(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2082 in k2073 in k2067 in k2064 in k2061 in k2057 in k2054 in loop in k2042 in k2039 in k2036 in k2030 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k2006 in k2003 in k2000 in k2458 in k1991 in k1988 in k1985 in k1982 in k1979 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1953 in k1950 in k1947 in k1941 in k1938 in k1935 in k1932 in k1929 in k1926 in k1923 in k1920 in k1917 in k1909 in k1906 in k1903 in k1900 in k1896 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
/* batch-driver.scm: 616  perform-high-level-optimizations */
((C_proc4)C_retrieve_symbol_proc(lf[94]))(4,*((C_word*)lf[94]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1881 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 410  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),((C_word*)t0)[2],t1);}

/* k1874 in k1862 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 411  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[2]);}

/* k1850 in k1841 in k1838 in k1835 in k1832 in k1829 in k1818 in k1814 in k1810 in k1806 in k1802 in k1798 in k1795 in k1791 in k1787 in k1784 in k1780 in k1772 in k1768 in k1765 in k1762 in k1759 in k1752 in k1749 in k1746 in k1743 in k1740 in k1737 in k1734 in k1730 in k1727 in k1721 in k1718 in k1715 in k1712 in k1709 in k1706 in k1703 in k1697 in k1691 in k1688 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1660 in k1657 in k1654 in k1651 in k1648 in k1645 in k1642 in k1639 in k1636 in k1633 in k1630 in k1622 in k1618 in k1615 in k1612 in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 406  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[2]);}

/* analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1535(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1535,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1537,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1560,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1565,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-no299347 */
t8=t7;
f_1565(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-contf300343 */
t10=t6;
f_1560(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body297306 */
t12=t5;
f_1537(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-no299 in analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1565,NULL,2,t0,t1);}
/* def-contf300343 */
t2=((C_word*)t0)[2];
f_1560(t2,t1,C_fix(0));}

/* def-contf300 in analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1560(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1560,NULL,3,t0,t1,t2);}
/* body297306 */
t3=((C_word*)t0)[2];
f_1537(t3,t1,t2,C_SCHEME_TRUE);}

/* body297 in analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1537(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1537,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1541,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* batch-driver.scm: 204  analyze-expression */
((C_proc3)C_retrieve_symbol_proc(lf[54]))(3,*((C_word*)lf[54]+1),t4,((C_word*)t0)[2]);}

/* k1539 in body297 in analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1544,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1549,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 206  upap */
t5=((C_word*)((C_word*)t0)[6])[1];
((C_proc9)C_retrieve_proc(t5))(9,t5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
f_1544(2,t3,C_SCHEME_UNDEFINED);}}

/* a1554 in k1539 in body297 in analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1555,5,t0,t1,t2,t3,t4);}
/* ##compiler#put! */
((C_proc6)C_retrieve_symbol_proc(lf[53]))(6,*((C_word*)lf[53]+1),t1,((C_word*)t0)[2],t2,t3,t4);}

/* a1548 in k1539 in body297 in analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1549,4,t0,t1,t2,t3);}
/* ##compiler#get */
((C_proc5)C_retrieve_symbol_proc(lf[52]))(5,*((C_word*)lf[52]+1),t1,((C_word*)t0)[2],t2,t3);}

/* k1542 in k1539 in body297 in analyze in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* read-form in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1529,NULL,3,t0,t1,t2);}
/* batch-driver.scm: 200  ##sys#read */
((C_proc4)C_retrieve_symbol_proc(lf[51]))(4,*((C_word*)lf[51]+1),t1,t2,((C_word*)t0)[2]);}

/* end-time in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1512(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_fixnum_difference(t3,((C_word*)((C_word*)t0)[2])[1]);
/* batch-driver.scm: 197  printf */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t1,lf[50],t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* begin-time in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static C_word C_fcall f_1502(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t1=(C_word)C_fudge(C_fix(6));
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
return(t2);}
else{
return(C_SCHEME_UNDEFINED);}}

/* collect-options in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1472(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1472,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1478(t6,t1,((C_word*)t0)[2]);}

/* loop in collect-options in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1478,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(((C_word*)t0)[4],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 189  option-arg */
f_1165(t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k1490 in loop in collect-options in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1496,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* batch-driver.scm: 189  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1478(t4,t2,t3);}

/* k1494 in k1490 in loop in collect-options in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1496,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* arg-val in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1392(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1392,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1402,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(2)))){
/* batch-driver.scm: 180  string->number */
C_string_to_number(3,0,t5,t2);}
else{
t6=(C_word)C_i_string_ref(t2,t4);
t7=(C_word)C_eqp(t6,C_make_character(109));
t8=(C_truep(t7)?t7:(C_word)C_eqp(t6,C_make_character(77)));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1433,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 182  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[49]+1)))(5,*((C_word*)lf[49]+1),t10,t2,C_fix(0),t4);}
else{
t9=(C_word)C_eqp(t6,C_make_character(107));
t10=(C_truep(t9)?t9:(C_word)C_eqp(t6,C_make_character(75)));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1461,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 183  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[49]+1)))(5,*((C_word*)lf[49]+1),t12,t2,C_fix(0),t4);}
else{
/* batch-driver.scm: 184  string->number */
C_string_to_number(3,0,t5,t2);}}}}

/* k1459 in arg-val in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 183  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1455 in arg-val in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1402(2,t2,(C_word)C_fixnum_times(t1,C_fix(1024)));}

/* k1439 in arg-val in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 182  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1431 in arg-val in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1402(2,t2,(C_word)C_fixnum_times(t1,C_fix(1048576)));}

/* k1400 in arg-val in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* batch-driver.scm: 185  quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[48],((C_word*)t0)[2]);}}

/* infohook in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1343,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1347,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_retrieve(lf[47]);
t7=(C_truep(t6)?t6:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1389,tmp=(C_word)a,a+=2,tmp));
t8=t7;
((C_proc5)C_retrieve_proc(t8))(5,t8,t5,t2,t3,t4);}

/* f_1389 in infohook in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1389,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k1345 in infohook in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1350,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[46],((C_word*)t0)[2]);
if(C_truep(t4)){
t5=(C_word)C_i_car(t1);
t6=t3;
f_1353(t6,(C_word)C_i_symbolp(t5));}
else{
t5=t3;
f_1353(t5,C_SCHEME_FALSE);}}

/* k1351 in k1345 in infohook in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1353,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1364,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* batch-driver.scm: 172  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t4,C_retrieve(lf[43]),t5);}
else{
t2=((C_word*)t0)[3];
f_1350(2,t2,C_SCHEME_UNDEFINED);}}

/* k1366 in k1351 in k1345 in infohook in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* batch-driver.scm: 171  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[44]))(5,*((C_word*)lf[44]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k1362 in k1351 in k1345 in infohook in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 168  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[42]))(5,*((C_word*)lf[42]+1),((C_word*)t0)[3],C_retrieve(lf[43]),((C_word*)t0)[2],t1);}

/* k1348 in k1345 in infohook in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* print-expr in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1331(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1331,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1338,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 162  print-header */
t6=((C_word*)t0)[2];
f_1279(t6,t5,t2,t3);}

/* k1336 in print-expr in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* for-each */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_retrieve(lf[37]),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* print-db in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1316(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1316,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1323,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 157  print-header */
t7=((C_word*)t0)[2];
f_1279(t7,t6,t2,t3);}

/* k1321 in print-db in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* batch-driver.scm: 158  printf */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t2,lf[40],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1324 in k1321 in print-db in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 159  display-analysis-database */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* print-node in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1294(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1294,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1301,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 151  print-header */
t6=((C_word*)t0)[2];
f_1279(t6,t5,t2,t3);}

/* k1299 in print-node in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
/* batch-driver.scm: 153  dump-nodes */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 154  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1312 in k1299 in print-node in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* batch-driver.scm: 154  pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* print-header in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1279(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1279,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* batch-driver.scm: 144  dribble */
t5=((C_word*)t0)[2];
f_1270(t5,t4,lf[35],(C_word)C_a_i_list(&a,1,t2));}

/* k1281 in print-header in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1283,2,t0,t1);}
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[33])))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* batch-driver.scm: 147  printf */
((C_proc4)C_retrieve_symbol_proc(lf[31]))(4,*((C_word*)lf[31]+1),t2,lf[34],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1290 in k1281 in print-header in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* dribble in k1221 in k1215 in k1212 in k3525 in k1196 in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1270(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1270,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
/* batch-driver.scm: 141  printf */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t1,lf[32],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* option-arg in compile-source-file in k1158 in k1154 in k1150 in k1146 in k1142 in k1137 in k1134 in k1131 in k1128 in k1125 in k1122 */
static void C_fcall f_1165(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1165,NULL,2,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_car(t2);
/* batch-driver.scm: 94   quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[9],t4);}
else{
t4=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_symbolp(t4))){
/* batch-driver.scm: 97   quit */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),t1,lf[10],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[335] = {
{"toplevel:batch_driver_scm",(void*)C_driver_toplevel},
{"f_1124:batch_driver_scm",(void*)f_1124},
{"f_1127:batch_driver_scm",(void*)f_1127},
{"f_1130:batch_driver_scm",(void*)f_1130},
{"f_1133:batch_driver_scm",(void*)f_1133},
{"f_1136:batch_driver_scm",(void*)f_1136},
{"f_1139:batch_driver_scm",(void*)f_1139},
{"f_1144:batch_driver_scm",(void*)f_1144},
{"f_1148:batch_driver_scm",(void*)f_1148},
{"f_1152:batch_driver_scm",(void*)f_1152},
{"f_1156:batch_driver_scm",(void*)f_1156},
{"f_1160:batch_driver_scm",(void*)f_1160},
{"f_1162:batch_driver_scm",(void*)f_1162},
{"f_1198:batch_driver_scm",(void*)f_1198},
{"f_3546:batch_driver_scm",(void*)f_3546},
{"f_3535:batch_driver_scm",(void*)f_3535},
{"f_3531:batch_driver_scm",(void*)f_3531},
{"f_3527:batch_driver_scm",(void*)f_3527},
{"f_3516:batch_driver_scm",(void*)f_3516},
{"f_3494:batch_driver_scm",(void*)f_3494},
{"f_1214:batch_driver_scm",(void*)f_1214},
{"f_3488:batch_driver_scm",(void*)f_3488},
{"f_3484:batch_driver_scm",(void*)f_3484},
{"f_1217:batch_driver_scm",(void*)f_1217},
{"f_1223:batch_driver_scm",(void*)f_1223},
{"f_3465:batch_driver_scm",(void*)f_3465},
{"f_3461:batch_driver_scm",(void*)f_3461},
{"f_3457:batch_driver_scm",(void*)f_3457},
{"f_1614:batch_driver_scm",(void*)f_1614},
{"f_1617:batch_driver_scm",(void*)f_1617},
{"f_1620:batch_driver_scm",(void*)f_1620},
{"f_3442:batch_driver_scm",(void*)f_3442},
{"f_3420:batch_driver_scm",(void*)f_3420},
{"f_3438:batch_driver_scm",(void*)f_3438},
{"f_3426:batch_driver_scm",(void*)f_3426},
{"f_1624:batch_driver_scm",(void*)f_1624},
{"f_3418:batch_driver_scm",(void*)f_3418},
{"f_3402:batch_driver_scm",(void*)f_3402},
{"f_3410:batch_driver_scm",(void*)f_3410},
{"f_3414:batch_driver_scm",(void*)f_3414},
{"f_1632:batch_driver_scm",(void*)f_1632},
{"f_1635:batch_driver_scm",(void*)f_1635},
{"f_1638:batch_driver_scm",(void*)f_1638},
{"f_1641:batch_driver_scm",(void*)f_1641},
{"f_1644:batch_driver_scm",(void*)f_1644},
{"f_1647:batch_driver_scm",(void*)f_1647},
{"f_1650:batch_driver_scm",(void*)f_1650},
{"f_1653:batch_driver_scm",(void*)f_1653},
{"f_1656:batch_driver_scm",(void*)f_1656},
{"f_1659:batch_driver_scm",(void*)f_1659},
{"f_1662:batch_driver_scm",(void*)f_1662},
{"f_3352:batch_driver_scm",(void*)f_3352},
{"f_1666:batch_driver_scm",(void*)f_1666},
{"f_3347:batch_driver_scm",(void*)f_3347},
{"f_1669:batch_driver_scm",(void*)f_1669},
{"f_1672:batch_driver_scm",(void*)f_1672},
{"f_1675:batch_driver_scm",(void*)f_1675},
{"f_1678:batch_driver_scm",(void*)f_1678},
{"f_1681:batch_driver_scm",(void*)f_1681},
{"f_1684:batch_driver_scm",(void*)f_1684},
{"f_1687:batch_driver_scm",(void*)f_1687},
{"f_1690:batch_driver_scm",(void*)f_1690},
{"f_1693:batch_driver_scm",(void*)f_1693},
{"f_3306:batch_driver_scm",(void*)f_3306},
{"f_1699:batch_driver_scm",(void*)f_1699},
{"f_3291:batch_driver_scm",(void*)f_3291},
{"f_3294:batch_driver_scm",(void*)f_3294},
{"f_3297:batch_driver_scm",(void*)f_3297},
{"f_1705:batch_driver_scm",(void*)f_1705},
{"f_3281:batch_driver_scm",(void*)f_3281},
{"f_3284:batch_driver_scm",(void*)f_3284},
{"f_1708:batch_driver_scm",(void*)f_1708},
{"f_1711:batch_driver_scm",(void*)f_1711},
{"f_3239:batch_driver_scm",(void*)f_3239},
{"f_1714:batch_driver_scm",(void*)f_1714},
{"f_3233:batch_driver_scm",(void*)f_3233},
{"f_1717:batch_driver_scm",(void*)f_1717},
{"f_3224:batch_driver_scm",(void*)f_3224},
{"f_1720:batch_driver_scm",(void*)f_1720},
{"f_3206:batch_driver_scm",(void*)f_3206},
{"f_3209:batch_driver_scm",(void*)f_3209},
{"f_3212:batch_driver_scm",(void*)f_3212},
{"f_3215:batch_driver_scm",(void*)f_3215},
{"f_1723:batch_driver_scm",(void*)f_1723},
{"f_3200:batch_driver_scm",(void*)f_3200},
{"f_3196:batch_driver_scm",(void*)f_3196},
{"f_1729:batch_driver_scm",(void*)f_1729},
{"f_1732:batch_driver_scm",(void*)f_1732},
{"f_3180:batch_driver_scm",(void*)f_3180},
{"f_1736:batch_driver_scm",(void*)f_1736},
{"f_1739:batch_driver_scm",(void*)f_1739},
{"f_1742:batch_driver_scm",(void*)f_1742},
{"f_1745:batch_driver_scm",(void*)f_1745},
{"f_1748:batch_driver_scm",(void*)f_1748},
{"f_3099:batch_driver_scm",(void*)f_3099},
{"f_3105:batch_driver_scm",(void*)f_3105},
{"f_3130:batch_driver_scm",(void*)f_3130},
{"f_3135:batch_driver_scm",(void*)f_3135},
{"f_3031:batch_driver_scm",(void*)f_3031},
{"f_3036:batch_driver_scm",(void*)f_3036},
{"f_3042:batch_driver_scm",(void*)f_3042},
{"f_3067:batch_driver_scm",(void*)f_3067},
{"f_3072:batch_driver_scm",(void*)f_3072},
{"f_1751:batch_driver_scm",(void*)f_1751},
{"f_3025:batch_driver_scm",(void*)f_3025},
{"f_3017:batch_driver_scm",(void*)f_3017},
{"f_3015:batch_driver_scm",(void*)f_3015},
{"f_1754:batch_driver_scm",(void*)f_1754},
{"f_1761:batch_driver_scm",(void*)f_1761},
{"f_1764:batch_driver_scm",(void*)f_1764},
{"f_1767:batch_driver_scm",(void*)f_1767},
{"f_3000:batch_driver_scm",(void*)f_3000},
{"f_3008:batch_driver_scm",(void*)f_3008},
{"f_1770:batch_driver_scm",(void*)f_1770},
{"f_1774:batch_driver_scm",(void*)f_1774},
{"f_1782:batch_driver_scm",(void*)f_1782},
{"f_1786:batch_driver_scm",(void*)f_1786},
{"f_2998:batch_driver_scm",(void*)f_2998},
{"f_1789:batch_driver_scm",(void*)f_1789},
{"f_2994:batch_driver_scm",(void*)f_2994},
{"f_2990:batch_driver_scm",(void*)f_2990},
{"f_2986:batch_driver_scm",(void*)f_2986},
{"f_2966:batch_driver_scm",(void*)f_2966},
{"f_2964:batch_driver_scm",(void*)f_2964},
{"f_1793:batch_driver_scm",(void*)f_1793},
{"f_1797:batch_driver_scm",(void*)f_1797},
{"f_1800:batch_driver_scm",(void*)f_1800},
{"f_2943:batch_driver_scm",(void*)f_2943},
{"f_1804:batch_driver_scm",(void*)f_1804},
{"f_2936:batch_driver_scm",(void*)f_2936},
{"f_1808:batch_driver_scm",(void*)f_1808},
{"f_2929:batch_driver_scm",(void*)f_2929},
{"f_1812:batch_driver_scm",(void*)f_1812},
{"f_2922:batch_driver_scm",(void*)f_2922},
{"f_1816:batch_driver_scm",(void*)f_1816},
{"f_2902:batch_driver_scm",(void*)f_2902},
{"f_1820:batch_driver_scm",(void*)f_1820},
{"f_1831:batch_driver_scm",(void*)f_1831},
{"f_1834:batch_driver_scm",(void*)f_1834},
{"f_1837:batch_driver_scm",(void*)f_1837},
{"f_2861:batch_driver_scm",(void*)f_2861},
{"f_1840:batch_driver_scm",(void*)f_1840},
{"f_1843:batch_driver_scm",(void*)f_1843},
{"f_1864:batch_driver_scm",(void*)f_1864},
{"f_1892:batch_driver_scm",(void*)f_1892},
{"f_1898:batch_driver_scm",(void*)f_1898},
{"f_1902:batch_driver_scm",(void*)f_1902},
{"f_1905:batch_driver_scm",(void*)f_1905},
{"f_1908:batch_driver_scm",(void*)f_1908},
{"f_1911:batch_driver_scm",(void*)f_1911},
{"f_1919:batch_driver_scm",(void*)f_1919},
{"f_1922:batch_driver_scm",(void*)f_1922},
{"f_1925:batch_driver_scm",(void*)f_1925},
{"f_2829:batch_driver_scm",(void*)f_2829},
{"f_2837:batch_driver_scm",(void*)f_2837},
{"f_1928:batch_driver_scm",(void*)f_1928},
{"f_1931:batch_driver_scm",(void*)f_1931},
{"f_2744:batch_driver_scm",(void*)f_2744},
{"f_2773:batch_driver_scm",(void*)f_2773},
{"f_2822:batch_driver_scm",(void*)f_2822},
{"f_2790:batch_driver_scm",(void*)f_2790},
{"f_2794:batch_driver_scm",(void*)f_2794},
{"f_2799:batch_driver_scm",(void*)f_2799},
{"f_2820:batch_driver_scm",(void*)f_2820},
{"f_2785:batch_driver_scm",(void*)f_2785},
{"f_2776:batch_driver_scm",(void*)f_2776},
{"f_2759:batch_driver_scm",(void*)f_2759},
{"f_2763:batch_driver_scm",(void*)f_2763},
{"f_2767:batch_driver_scm",(void*)f_2767},
{"f_2755:batch_driver_scm",(void*)f_2755},
{"f_2735:batch_driver_scm",(void*)f_2735},
{"f_2739:batch_driver_scm",(void*)f_2739},
{"f_1934:batch_driver_scm",(void*)f_1934},
{"f_1937:batch_driver_scm",(void*)f_1937},
{"f_2728:batch_driver_scm",(void*)f_2728},
{"f_2732:batch_driver_scm",(void*)f_2732},
{"f_1940:batch_driver_scm",(void*)f_1940},
{"f_1943:batch_driver_scm",(void*)f_1943},
{"f_2705:batch_driver_scm",(void*)f_2705},
{"f_2725:batch_driver_scm",(void*)f_2725},
{"f_1949:batch_driver_scm",(void*)f_1949},
{"f_2698:batch_driver_scm",(void*)f_2698},
{"f_1952:batch_driver_scm",(void*)f_1952},
{"f_1955:batch_driver_scm",(void*)f_1955},
{"f_2666:batch_driver_scm",(void*)f_2666},
{"f_2540:batch_driver_scm",(void*)f_2540},
{"f_2656:batch_driver_scm",(void*)f_2656},
{"f_2544:batch_driver_scm",(void*)f_2544},
{"f_2548:batch_driver_scm",(void*)f_2548},
{"f_2567:batch_driver_scm",(void*)f_2567},
{"f_2552:batch_driver_scm",(void*)f_2552},
{"f_1961:batch_driver_scm",(void*)f_1961},
{"f_2513:batch_driver_scm",(void*)f_2513},
{"f_2518:batch_driver_scm",(void*)f_2518},
{"f_1964:batch_driver_scm",(void*)f_1964},
{"f_2507:batch_driver_scm",(void*)f_2507},
{"f_1967:batch_driver_scm",(void*)f_1967},
{"f_2501:batch_driver_scm",(void*)f_2501},
{"f_1970:batch_driver_scm",(void*)f_1970},
{"f_1973:batch_driver_scm",(void*)f_1973},
{"f_2486:batch_driver_scm",(void*)f_2486},
{"f_1976:batch_driver_scm",(void*)f_1976},
{"f_1981:batch_driver_scm",(void*)f_1981},
{"f_1984:batch_driver_scm",(void*)f_1984},
{"f_1987:batch_driver_scm",(void*)f_1987},
{"f_1990:batch_driver_scm",(void*)f_1990},
{"f_2467:batch_driver_scm",(void*)f_2467},
{"f_2474:batch_driver_scm",(void*)f_2474},
{"f_1993:batch_driver_scm",(void*)f_1993},
{"f_2464:batch_driver_scm",(void*)f_2464},
{"f_2460:batch_driver_scm",(void*)f_2460},
{"f_2002:batch_driver_scm",(void*)f_2002},
{"f_2005:batch_driver_scm",(void*)f_2005},
{"f_2410:batch_driver_scm",(void*)f_2410},
{"f_2450:batch_driver_scm",(void*)f_2450},
{"f_2442:batch_driver_scm",(void*)f_2442},
{"f_2413:batch_driver_scm",(void*)f_2413},
{"f_2421:batch_driver_scm",(void*)f_2421},
{"f_2424:batch_driver_scm",(void*)f_2424},
{"f_2427:batch_driver_scm",(void*)f_2427},
{"f_2433:batch_driver_scm",(void*)f_2433},
{"f_2436:batch_driver_scm",(void*)f_2436},
{"f_2439:batch_driver_scm",(void*)f_2439},
{"f_2008:batch_driver_scm",(void*)f_2008},
{"f_2401:batch_driver_scm",(void*)f_2401},
{"f_2404:batch_driver_scm",(void*)f_2404},
{"f_2383:batch_driver_scm",(void*)f_2383},
{"f_2389:batch_driver_scm",(void*)f_2389},
{"f_2392:batch_driver_scm",(void*)f_2392},
{"f_2395:batch_driver_scm",(void*)f_2395},
{"f_2011:batch_driver_scm",(void*)f_2011},
{"f_2377:batch_driver_scm",(void*)f_2377},
{"f_2014:batch_driver_scm",(void*)f_2014},
{"f_2370:batch_driver_scm",(void*)f_2370},
{"f_2017:batch_driver_scm",(void*)f_2017},
{"f_2367:batch_driver_scm",(void*)f_2367},
{"f_2363:batch_driver_scm",(void*)f_2363},
{"f_2332:batch_driver_scm",(void*)f_2332},
{"f_2359:batch_driver_scm",(void*)f_2359},
{"f_2355:batch_driver_scm",(void*)f_2355},
{"f_2336:batch_driver_scm",(void*)f_2336},
{"f_2345:batch_driver_scm",(void*)f_2345},
{"f_2348:batch_driver_scm",(void*)f_2348},
{"f_2020:batch_driver_scm",(void*)f_2020},
{"f_2023:batch_driver_scm",(void*)f_2023},
{"f_2320:batch_driver_scm",(void*)f_2320},
{"f_2324:batch_driver_scm",(void*)f_2324},
{"f_2026:batch_driver_scm",(void*)f_2026},
{"f_2032:batch_driver_scm",(void*)f_2032},
{"f_2038:batch_driver_scm",(void*)f_2038},
{"f_2041:batch_driver_scm",(void*)f_2041},
{"f_2044:batch_driver_scm",(void*)f_2044},
{"f_2049:batch_driver_scm",(void*)f_2049},
{"f_2056:batch_driver_scm",(void*)f_2056},
{"f_2284:batch_driver_scm",(void*)f_2284},
{"f_2059:batch_driver_scm",(void*)f_2059},
{"f_2063:batch_driver_scm",(void*)f_2063},
{"f_2066:batch_driver_scm",(void*)f_2066},
{"f_2069:batch_driver_scm",(void*)f_2069},
{"f_2161:batch_driver_scm",(void*)f_2161},
{"f_2272:batch_driver_scm",(void*)f_2272},
{"f_2164:batch_driver_scm",(void*)f_2164},
{"f_2170:batch_driver_scm",(void*)f_2170},
{"f_2173:batch_driver_scm",(void*)f_2173},
{"f_2176:batch_driver_scm",(void*)f_2176},
{"f_2255:batch_driver_scm",(void*)f_2255},
{"f_2179:batch_driver_scm",(void*)f_2179},
{"f_2182:batch_driver_scm",(void*)f_2182},
{"f_2185:batch_driver_scm",(void*)f_2185},
{"f_2199:batch_driver_scm",(void*)f_2199},
{"f_2203:batch_driver_scm",(void*)f_2203},
{"f_2209:batch_driver_scm",(void*)f_2209},
{"f_2212:batch_driver_scm",(void*)f_2212},
{"f_2215:batch_driver_scm",(void*)f_2215},
{"f_2218:batch_driver_scm",(void*)f_2218},
{"f_2221:batch_driver_scm",(void*)f_2221},
{"f_2240:batch_driver_scm",(void*)f_2240},
{"f_2224:batch_driver_scm",(void*)f_2224},
{"f_2227:batch_driver_scm",(void*)f_2227},
{"f_2193:batch_driver_scm",(void*)f_2193},
{"f_2075:batch_driver_scm",(void*)f_2075},
{"f_2089:batch_driver_scm",(void*)f_2089},
{"f_2093:batch_driver_scm",(void*)f_2093},
{"f_2096:batch_driver_scm",(void*)f_2096},
{"f_2115:batch_driver_scm",(void*)f_2115},
{"f_2132:batch_driver_scm",(void*)f_2132},
{"f_2135:batch_driver_scm",(void*)f_2135},
{"f_2141:batch_driver_scm",(void*)f_2141},
{"f_2144:batch_driver_scm",(void*)f_2144},
{"f_2083:batch_driver_scm",(void*)f_2083},
{"f_1883:batch_driver_scm",(void*)f_1883},
{"f_1876:batch_driver_scm",(void*)f_1876},
{"f_1852:batch_driver_scm",(void*)f_1852},
{"f_1535:batch_driver_scm",(void*)f_1535},
{"f_1565:batch_driver_scm",(void*)f_1565},
{"f_1560:batch_driver_scm",(void*)f_1560},
{"f_1537:batch_driver_scm",(void*)f_1537},
{"f_1541:batch_driver_scm",(void*)f_1541},
{"f_1555:batch_driver_scm",(void*)f_1555},
{"f_1549:batch_driver_scm",(void*)f_1549},
{"f_1544:batch_driver_scm",(void*)f_1544},
{"f_1529:batch_driver_scm",(void*)f_1529},
{"f_1512:batch_driver_scm",(void*)f_1512},
{"f_1502:batch_driver_scm",(void*)f_1502},
{"f_1472:batch_driver_scm",(void*)f_1472},
{"f_1478:batch_driver_scm",(void*)f_1478},
{"f_1492:batch_driver_scm",(void*)f_1492},
{"f_1496:batch_driver_scm",(void*)f_1496},
{"f_1392:batch_driver_scm",(void*)f_1392},
{"f_1461:batch_driver_scm",(void*)f_1461},
{"f_1457:batch_driver_scm",(void*)f_1457},
{"f_1441:batch_driver_scm",(void*)f_1441},
{"f_1433:batch_driver_scm",(void*)f_1433},
{"f_1402:batch_driver_scm",(void*)f_1402},
{"f_1343:batch_driver_scm",(void*)f_1343},
{"f_1389:batch_driver_scm",(void*)f_1389},
{"f_1347:batch_driver_scm",(void*)f_1347},
{"f_1353:batch_driver_scm",(void*)f_1353},
{"f_1368:batch_driver_scm",(void*)f_1368},
{"f_1364:batch_driver_scm",(void*)f_1364},
{"f_1350:batch_driver_scm",(void*)f_1350},
{"f_1331:batch_driver_scm",(void*)f_1331},
{"f_1338:batch_driver_scm",(void*)f_1338},
{"f_1316:batch_driver_scm",(void*)f_1316},
{"f_1323:batch_driver_scm",(void*)f_1323},
{"f_1326:batch_driver_scm",(void*)f_1326},
{"f_1294:batch_driver_scm",(void*)f_1294},
{"f_1301:batch_driver_scm",(void*)f_1301},
{"f_1314:batch_driver_scm",(void*)f_1314},
{"f_1279:batch_driver_scm",(void*)f_1279},
{"f_1283:batch_driver_scm",(void*)f_1283},
{"f_1292:batch_driver_scm",(void*)f_1292},
{"f_1270:batch_driver_scm",(void*)f_1270},
{"f_1165:batch_driver_scm",(void*)f_1165},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
