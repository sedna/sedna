/* Generated from srfi-1.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:35
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: srfi-1.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file usrfi-1.c
   unit: srfi_1
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[126];
static double C_possibly_force_alignment;


C_noret_decl(C_srfi_1_toplevel)
C_externexport void C_ccall C_srfi_1_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6719)
static void C_ccall f_6719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6672)
static void C_ccall f_6672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6672)
static void C_ccall f_6672r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6696)
static void C_ccall f_6696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6704)
static void C_ccall f_6704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6620)
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6656)
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6663)
static void C_ccall f_6663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6626)
static void C_ccall f_6626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6560)
static void C_ccall f_6560r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6566)
static void C_ccall f_6566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6578)
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6602)
static void C_ccall f_6602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6609)
static void C_ccall f_6609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6572)
static void C_ccall f_6572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6523)
static void C_ccall f_6523r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6544)
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6513)
static void C_ccall f_6513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6521)
static void C_ccall f_6521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6453)
static void C_ccall f_6453r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_ccall f_6430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6441)
static void C_ccall f_6441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6447)
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6369)
static void C_ccall f_6369r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6375)
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6399)
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6409)
static void C_ccall f_6409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6321)
static void C_ccall f_6321r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6327)
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6351)
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6363)
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6309)
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6239)
static void C_ccall f_6239r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6259)
static void C_fcall f_6259(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6181)
static void C_ccall f_6181r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6201)
static void C_fcall f_6201(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6223)
static void C_ccall f_6223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6169)
static void C_fcall f_6169(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6145)
static void C_ccall f_6145(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6151)
static C_word C_fcall f_6151(C_word t0,C_word t1);
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6111)
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6124)
static void C_ccall f_6124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_fcall f_6074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6099)
static void C_ccall f_6099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6029)
static void C_fcall f_6029(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6045)
static void C_ccall f_6045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5975)
static void C_fcall f_5975(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6000)
static void C_ccall f_6000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5908)
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5858)
static void C_fcall f_5858(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5738)
static void C_fcall f_5738(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5753)
static void C_fcall f_5753(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5769)
static void C_ccall f_5769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5681)
static void C_fcall f_5681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5705)
static void C_ccall f_5705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5669)
static void C_ccall f_5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5627)
static void C_fcall f_5627(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5636)
static void C_fcall f_5636(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5630)
static void C_ccall f_5630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5585)
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5591)
static void C_fcall f_5591(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5556)
static void C_fcall f_5556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5579)
static void C_ccall f_5579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5520)
static void C_fcall f_5520(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5412)
static void C_ccall f_5412(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5371)
static void C_ccall f_5371r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5328)
static void C_fcall f_5328(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5276)
static void C_fcall f_5276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_ccall f_5292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5249)
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5226)
static void C_ccall f_5226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5187)
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5152)
static void C_ccall f_5152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5099)
static void C_fcall f_5099(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_fcall f_4991(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4997)
static void C_fcall f_4997(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_fcall f_4946(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4952)
static void C_fcall f_4952(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4872)
static void C_fcall f_4872(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4899)
static void C_ccall f_4899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4745)
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4751)
static void C_fcall f_4751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4812)
static void C_fcall f_4812(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_fcall f_4773(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4709)
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4676)
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_fcall f_4642(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4664)
static void C_ccall f_4664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4671)
static void C_ccall f_4671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4541)
static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4597)
static void C_fcall f_4597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_fcall f_4557(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4569)
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4579)
static void C_ccall f_4579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4535)
static void C_ccall f_4535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_fcall f_4481(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4447)
static void C_fcall f_4447(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4460)
static void C_ccall f_4460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_fcall f_4426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4439)
static void C_ccall f_4439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4383)
static void C_fcall f_4383(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4335)
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4339)
static void C_ccall f_4339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4265)
static void C_fcall f_4265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4160)
static void C_ccall f_4160r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4206)
static void C_fcall f_4206(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_fcall f_4176(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4140)
static void C_fcall f_4140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_fcall f_4110(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4071)
static void C_fcall f_4071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_fcall f_4045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_fcall f_3481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3958)
static void C_ccall f_3958r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4005)
static void C_fcall f_4005(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_fcall f_3974(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3600)
static void C_fcall f_3600(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3639)
static void C_ccall f_3639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3633)
static void C_ccall f_3633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_3934)
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_fcall f_3900(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_3840)
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3862)
static void C_ccall f_3862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3800)
static void C_fcall f_3800(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3749)
static void C_fcall f_3749(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3767)
static void C_ccall f_3767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_fcall f_3508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3520)
static void C_fcall f_3520(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3559)
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3571)
static void C_ccall f_3571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3565)
static void C_ccall f_3565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_fcall f_3427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3439)
static void C_fcall f_3439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3397)
static C_word C_fcall f_3397(C_word t0,C_word t1);
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3367)
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3285)
static void C_ccall f_3285r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3291)
static void C_fcall f_3291(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3320)
static void C_ccall f_3320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_fcall f_3322(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3207)
static void C_fcall f_3207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3225)
static void C_ccall f_3225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3135)
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3163)
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3071)
static void C_fcall f_3071(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3015)
static void C_fcall f_3015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2988)
static C_word C_fcall f_2988(C_word t0);
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2957)
static void C_ccall f_2957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2898)
static void C_fcall f_2898(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static C_word C_fcall f_2866(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2817)
static void C_ccall f_2817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2789)
static C_word C_fcall f_2789(C_word t0,C_word t1);
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2736)
static C_word C_fcall f_2736(C_word t0,C_word t1);
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2699)
static void C_fcall f_2699(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2645)
static void C_ccall f_2645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2595)
static void C_ccall f_2595r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2552)
static C_word C_fcall f_2552(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2466)
static void C_fcall f_2466(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2493)
static void C_fcall f_2493(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2443)
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2407)
static C_word C_fcall f_2407(C_word t0,C_word t1);
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2350)
static C_word C_fcall f_2350(C_word t0,C_word t1);
C_noret_decl(f_2330)
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2330)
static void C_ccall f_2330r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_fcall f_2279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_fcall f_2274(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2228)
static void C_fcall f_2228(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2243)
static void C_fcall f_2243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2196)
static void C_fcall f_2196(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2166)
static void C_fcall f_2166(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2136)
static void C_fcall f_2136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_fcall f_2080(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;

C_noret_decl(trf_6259)
static void C_fcall trf_6259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6259(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6259(t0,t1,t2,t3);}

C_noret_decl(trf_6201)
static void C_fcall trf_6201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6201(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6201(t0,t1,t2,t3);}

C_noret_decl(trf_6169)
static void C_fcall trf_6169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6169(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6169(t0,t1,t2,t3);}

C_noret_decl(trf_6111)
static void C_fcall trf_6111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6111(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6111(t0,t1,t2,t3);}

C_noret_decl(trf_6074)
static void C_fcall trf_6074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6074(t0,t1,t2,t3);}

C_noret_decl(trf_6029)
static void C_fcall trf_6029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6029(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6029(t0,t1,t2,t3);}

C_noret_decl(trf_5975)
static void C_fcall trf_5975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5975(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5975(t0,t1,t2,t3);}

C_noret_decl(trf_5908)
static void C_fcall trf_5908(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5908(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5908(t0,t1,t2,t3);}

C_noret_decl(trf_5858)
static void C_fcall trf_5858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5858(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5858(t0,t1,t2,t3);}

C_noret_decl(trf_5738)
static void C_fcall trf_5738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5738(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5738(t0,t1);}

C_noret_decl(trf_5753)
static void C_fcall trf_5753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5753(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5753(t0,t1,t2,t3);}

C_noret_decl(trf_5681)
static void C_fcall trf_5681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5681(t0,t1,t2);}

C_noret_decl(trf_5627)
static void C_fcall trf_5627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5627(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5627(t0,t1);}

C_noret_decl(trf_5636)
static void C_fcall trf_5636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5636(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5636(t0,t1,t2,t3);}

C_noret_decl(trf_5591)
static void C_fcall trf_5591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5591(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5591(t0,t1,t2);}

C_noret_decl(trf_5556)
static void C_fcall trf_5556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5556(t0,t1,t2);}

C_noret_decl(trf_5520)
static void C_fcall trf_5520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5520(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5520(t0,t1,t2);}

C_noret_decl(trf_5328)
static void C_fcall trf_5328(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5328(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5328(t0,t1,t2);}

C_noret_decl(trf_5276)
static void C_fcall trf_5276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5276(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5276(t0,t1,t2);}

C_noret_decl(trf_5099)
static void C_fcall trf_5099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5099(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5099(t0,t1,t2,t3);}

C_noret_decl(trf_5049)
static void C_fcall trf_5049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5049(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5049(t0,t1,t2,t3);}

C_noret_decl(trf_4991)
static void C_fcall trf_4991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4991(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4991(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4997)
static void C_fcall trf_4997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4997(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4997(t0,t1,t2,t3);}

C_noret_decl(trf_4946)
static void C_fcall trf_4946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4946(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4946(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4952)
static void C_fcall trf_4952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4952(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4952(t0,t1,t2,t3);}

C_noret_decl(trf_4872)
static void C_fcall trf_4872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4872(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4872(t0,t1,t2);}

C_noret_decl(trf_4751)
static void C_fcall trf_4751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4751(t0,t1,t2);}

C_noret_decl(trf_4806)
static void C_fcall trf_4806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4806(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4806(t0,t1,t2,t3);}

C_noret_decl(trf_4812)
static void C_fcall trf_4812(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4812(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4812(t0,t1,t2);}

C_noret_decl(trf_4773)
static void C_fcall trf_4773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4773(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4773(t0,t1,t2,t3);}

C_noret_decl(trf_4709)
static void C_fcall trf_4709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4709(t0,t1,t2);}

C_noret_decl(trf_4676)
static void C_fcall trf_4676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4676(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4676(t0,t1,t2);}

C_noret_decl(trf_4642)
static void C_fcall trf_4642(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4642(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4642(t0,t1,t2);}

C_noret_decl(trf_4597)
static void C_fcall trf_4597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4597(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4597(t0,t1,t2);}

C_noret_decl(trf_4557)
static void C_fcall trf_4557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4557(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4557(t0,t1,t2);}

C_noret_decl(trf_4481)
static void C_fcall trf_4481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4481(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4481(t0,t1,t2,t3);}

C_noret_decl(trf_3678)
static void C_fcall trf_3678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3678(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3678(t0,t1,t2);}

C_noret_decl(trf_4447)
static void C_fcall trf_4447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4447(t0,t1,t2);}

C_noret_decl(trf_4426)
static void C_fcall trf_4426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4426(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4426(t0,t1,t2);}

C_noret_decl(trf_4301)
static void C_fcall trf_4301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4301(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4301(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4383)
static void C_fcall trf_4383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4383(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4383(t0,t1,t2,t3);}

C_noret_decl(trf_4335)
static void C_fcall trf_4335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4335(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4335(t0,t1,t2,t3);}

C_noret_decl(trf_4265)
static void C_fcall trf_4265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4265(t0,t1,t2,t3);}

C_noret_decl(trf_4206)
static void C_fcall trf_4206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4206(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4206(t0,t1,t2,t3);}

C_noret_decl(trf_4176)
static void C_fcall trf_4176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4176(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4176(t0,t1,t2,t3);}

C_noret_decl(trf_4140)
static void C_fcall trf_4140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4140(t0,t1,t2);}

C_noret_decl(trf_4110)
static void C_fcall trf_4110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4110(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4110(t0,t1,t2);}

C_noret_decl(trf_4071)
static void C_fcall trf_4071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4071(t0,t1,t2);}

C_noret_decl(trf_4045)
static void C_fcall trf_4045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4045(t0,t1,t2);}

C_noret_decl(trf_3481)
static void C_fcall trf_3481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3481(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3481(t0,t1,t2);}

C_noret_decl(trf_4005)
static void C_fcall trf_4005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4005(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4005(t0,t1,t2,t3);}

C_noret_decl(trf_3974)
static void C_fcall trf_3974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3974(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3974(t0,t1,t2,t3);}

C_noret_decl(trf_3600)
static void C_fcall trf_3600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3600(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3600(t0,t1,t2);}

C_noret_decl(trf_3934)
static void C_fcall trf_3934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3934(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3934(t0,t1,t2);}

C_noret_decl(trf_3900)
static void C_fcall trf_3900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3900(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3900(t0,t1,t2);}

C_noret_decl(trf_3840)
static void C_fcall trf_3840(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3840(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3840(t0,t1,t2,t3);}

C_noret_decl(trf_3800)
static void C_fcall trf_3800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3800(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3800(t0,t1,t2,t3);}

C_noret_decl(trf_3749)
static void C_fcall trf_3749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3749(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3749(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3508)
static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3508(t0,t1);}

C_noret_decl(trf_3520)
static void C_fcall trf_3520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3520(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3520(t0,t1,t2);}

C_noret_decl(trf_3427)
static void C_fcall trf_3427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3427(t0,t1);}

C_noret_decl(trf_3439)
static void C_fcall trf_3439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3439(t0,t1,t2);}

C_noret_decl(trf_3367)
static void C_fcall trf_3367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3367(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3367(t0,t1,t2,t3);}

C_noret_decl(trf_3291)
static void C_fcall trf_3291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3291(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3291(t0,t1,t2,t3);}

C_noret_decl(trf_3322)
static void C_fcall trf_3322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3322(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3322(t0,t1,t2,t3);}

C_noret_decl(trf_3207)
static void C_fcall trf_3207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3207(t0,t1,t2);}

C_noret_decl(trf_3135)
static void C_fcall trf_3135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3135(t0,t1,t2);}

C_noret_decl(trf_3071)
static void C_fcall trf_3071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3071(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3071(t0,t1,t2);}

C_noret_decl(trf_3015)
static void C_fcall trf_3015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3015(t0,t1,t2);}

C_noret_decl(trf_2898)
static void C_fcall trf_2898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2898(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2898(t0,t1,t2,t3);}

C_noret_decl(trf_2819)
static void C_fcall trf_2819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2819(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2819(t0,t1,t2,t3);}

C_noret_decl(trf_2699)
static void C_fcall trf_2699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2699(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2699(t0,t1,t2,t3);}

C_noret_decl(trf_2466)
static void C_fcall trf_2466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2466(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2466(t0,t1,t2,t3);}

C_noret_decl(trf_2493)
static void C_fcall trf_2493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2493(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2493(t0,t1,t2,t3);}

C_noret_decl(trf_2279)
static void C_fcall trf_2279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2279(t0,t1);}

C_noret_decl(trf_2274)
static void C_fcall trf_2274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2274(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2274(t0,t1,t2);}

C_noret_decl(trf_2228)
static void C_fcall trf_2228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2228(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2228(t0,t1,t2,t3);}

C_noret_decl(trf_2243)
static void C_fcall trf_2243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2243(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2243(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2196)
static void C_fcall trf_2196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2196(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2196(t0,t1,t2);}

C_noret_decl(trf_2166)
static void C_fcall trf_2166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2166(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2166(t0,t1,t2,t3);}

C_noret_decl(trf_2136)
static void C_fcall trf_2136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2136(t0,t1,t2,t3);}

C_noret_decl(trf_2080)
static void C_fcall trf_2080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2080(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2080(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr6rv)
static void C_fcall tr6rv(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6rv(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n+1);
t6=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_1_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_1_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1190)){
C_save(t1);
C_rereclaim2(1190*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,126);
lf[0]=C_h_intern(&lf[0],5,"xcons");
lf[1]=C_h_intern(&lf[1],9,"make-list");
lf[2]=C_h_intern(&lf[2],9,"\003syserror");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\037Too many arguments to MAKE-LIST");
lf[4]=C_h_intern(&lf[4],13,"list-tabulate");
lf[5]=C_h_intern(&lf[5],5,"cons*");
lf[6]=C_h_intern(&lf[6],9,"list-copy");
lf[7]=C_h_intern(&lf[7],4,"iota");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\023Negative step count");
lf[9]=C_h_intern(&lf[9],13,"circular-list");
lf[10]=C_h_intern(&lf[10],9,"last-pair");
lf[11]=C_h_intern(&lf[11],12,"proper-list\077");
lf[12]=C_h_intern(&lf[12],5,"list\077");
lf[13]=C_h_intern(&lf[13],12,"dotted-list\077");
lf[14]=C_h_intern(&lf[14],14,"circular-list\077");
lf[15]=C_h_intern(&lf[15],9,"not-pair\077");
lf[16]=C_h_intern(&lf[16],10,"null-list\077");
lf[17]=C_h_intern(&lf[17],5,"list=");
lf[18]=C_h_intern(&lf[18],7,"length+");
lf[19]=C_h_intern(&lf[19],3,"zip");
lf[20]=C_h_intern(&lf[20],3,"map");
lf[21]=C_h_intern(&lf[21],4,"list");
lf[22]=C_h_intern(&lf[22],5,"first");
lf[23]=C_h_intern(&lf[23],3,"car");
lf[24]=C_h_intern(&lf[24],6,"second");
lf[25]=C_h_intern(&lf[25],4,"cadr");
lf[26]=C_h_intern(&lf[26],5,"third");
lf[27]=C_h_intern(&lf[27],5,"caddr");
lf[28]=C_h_intern(&lf[28],6,"fourth");
lf[29]=C_h_intern(&lf[29],6,"cadddr");
lf[30]=C_h_intern(&lf[30],5,"fifth");
lf[31]=C_h_intern(&lf[31],5,"sixth");
lf[32]=C_h_intern(&lf[32],7,"seventh");
lf[33]=C_h_intern(&lf[33],6,"eighth");
lf[34]=C_h_intern(&lf[34],5,"ninth");
lf[35]=C_h_intern(&lf[35],5,"tenth");
lf[36]=C_h_intern(&lf[36],7,"car+cdr");
lf[37]=C_h_intern(&lf[37],4,"take");
lf[38]=C_h_intern(&lf[38],4,"drop");
lf[39]=C_h_intern(&lf[39],5,"take!");
lf[40]=C_h_intern(&lf[40],10,"take-right");
lf[41]=C_h_intern(&lf[41],10,"drop-right");
lf[42]=C_h_intern(&lf[42],11,"drop-right!");
lf[43]=C_h_intern(&lf[43],8,"split-at");
lf[44]=C_h_intern(&lf[44],9,"split-at!");
lf[45]=C_h_intern(&lf[45],4,"last");
lf[46]=C_h_intern(&lf[46],6,"unzip1");
lf[47]=C_h_intern(&lf[47],7,"\003sysmap");
lf[48]=C_h_intern(&lf[48],6,"unzip2");
lf[49]=C_h_intern(&lf[49],6,"unzip3");
lf[50]=C_h_intern(&lf[50],6,"unzip4");
lf[51]=C_h_intern(&lf[51],6,"unzip5");
lf[52]=C_h_intern(&lf[52],7,"append!");
lf[53]=C_h_intern(&lf[53],14,"append-reverse");
lf[54]=C_h_intern(&lf[54],15,"append-reverse!");
lf[55]=C_h_intern(&lf[55],11,"concatenate");
lf[56]=C_h_intern(&lf[56],12,"reduce-right");
lf[57]=C_h_intern(&lf[57],6,"append");
lf[58]=C_h_intern(&lf[58],12,"concatenate!");
lf[61]=C_h_intern(&lf[61],5,"count");
lf[62]=C_h_intern(&lf[62],12,"unfold-right");
lf[63]=C_h_intern(&lf[63],6,"unfold");
lf[64]=C_h_intern(&lf[64],5,"error");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\022Too many arguments");
lf[66]=C_h_intern(&lf[66],4,"fold");
lf[67]=C_h_intern(&lf[67],10,"fold-right");
lf[68]=C_h_intern(&lf[68],15,"pair-fold-right");
lf[69]=C_h_intern(&lf[69],9,"pair-fold");
lf[70]=C_h_intern(&lf[70],6,"reduce");
lf[71]=C_h_intern(&lf[71],10,"append-map");
lf[73]=C_h_intern(&lf[73],11,"append-map!");
lf[74]=C_h_intern(&lf[74],13,"pair-for-each");
lf[75]=C_h_intern(&lf[75],4,"map!");
lf[76]=C_h_intern(&lf[76],10,"filter-map");
lf[77]=C_h_intern(&lf[77],12,"map-in-order");
lf[78]=C_h_intern(&lf[78],6,"filter");
lf[79]=C_h_intern(&lf[79],7,"filter!");
lf[80]=C_h_intern(&lf[80],9,"partition");
lf[81]=C_h_intern(&lf[81],10,"partition!");
lf[82]=C_h_intern(&lf[82],6,"remove");
lf[83]=C_h_intern(&lf[83],7,"remove!");
lf[84]=C_h_intern(&lf[84],6,"delete");
lf[85]=C_h_intern(&lf[85],6,"equal\077");
lf[86]=C_h_intern(&lf[86],7,"delete!");
lf[87]=C_h_intern(&lf[87],6,"member");
lf[88]=C_h_intern(&lf[88],9,"find-tail");
lf[89]=C_h_intern(&lf[89],17,"delete-duplicates");
lf[90]=C_h_intern(&lf[90],18,"delete-duplicates!");
lf[91]=C_h_intern(&lf[91],5,"assoc");
lf[92]=C_h_intern(&lf[92],4,"find");
lf[93]=C_h_intern(&lf[93],10,"alist-cons");
lf[94]=C_h_intern(&lf[94],10,"alist-copy");
lf[95]=C_h_intern(&lf[95],12,"alist-delete");
lf[96]=C_h_intern(&lf[96],13,"alist-delete!");
lf[97]=C_h_intern(&lf[97],10,"take-while");
lf[98]=C_h_intern(&lf[98],10,"drop-while");
lf[99]=C_h_intern(&lf[99],11,"take-while!");
lf[100]=C_h_intern(&lf[100],4,"span");
lf[101]=C_h_intern(&lf[101],5,"span!");
lf[102]=C_h_intern(&lf[102],5,"break");
lf[103]=C_h_intern(&lf[103],6,"break!");
lf[104]=C_h_intern(&lf[104],3,"any");
lf[105]=C_h_intern(&lf[105],5,"every");
lf[106]=C_h_intern(&lf[106],10,"list-index");
lf[107]=C_h_intern(&lf[107],8,"reverse!");
lf[109]=C_h_intern(&lf[109],6,"lset<=");
lf[110]=C_h_intern(&lf[110],5,"lset=");
lf[111]=C_h_intern(&lf[111],11,"lset-adjoin");
lf[112]=C_h_intern(&lf[112],10,"lset-union");
lf[113]=C_h_intern(&lf[113],11,"lset-union!");
lf[114]=C_h_intern(&lf[114],17,"lset-intersection");
lf[115]=C_h_intern(&lf[115],3,"eq\077");
lf[116]=C_h_intern(&lf[116],18,"lset-intersection!");
lf[117]=C_h_intern(&lf[117],15,"lset-difference");
lf[118]=C_h_intern(&lf[118],5,"pair\077");
lf[119]=C_h_intern(&lf[119],16,"lset-difference!");
lf[120]=C_h_intern(&lf[120],8,"lset-xor");
lf[121]=C_h_intern(&lf[121],22,"lset-diff+intersection");
lf[122]=C_h_intern(&lf[122],9,"lset-xor!");
lf[123]=C_h_intern(&lf[123],23,"lset-diff+intersection!");
lf[124]=C_h_intern(&lf[124],17,"register-feature!");
lf[125]=C_h_intern(&lf[125],6,"srfi-1");
C_register_lf2(lf,126,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2060,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 45   register-feature! */
t3=*((C_word*)lf[124]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[125]);}

/* k2058 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word ab[204],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! xcons ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2062,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[1]+1 /* (set! make-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2068,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! list-tabulate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2123,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! cons* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2160,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[6]+1 /* (set! list-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2190,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[7]+1 /* (set! iota ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2220,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[9]+1 /* (set! circular-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2330,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[11]+1 /* (set! proper-list? ...) */,*((C_word*)lf[12]+1));
t10=C_mutate((C_word*)lf[13]+1 /* (set! dotted-list? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2344,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[14]+1 /* (set! circular-list? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2401,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[15]+1 /* (set! not-pair? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2440,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[16]+1 /* (set! null-list? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2443,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[17]+1 /* (set! list= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2446,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[18]+1 /* (set! length+ ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2546,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[19]+1 /* (set! zip ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2595,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[22]+1 /* (set! first ...) */,*((C_word*)lf[23]+1));
t18=C_mutate((C_word*)lf[24]+1 /* (set! second ...) */,*((C_word*)lf[25]+1));
t19=C_mutate((C_word*)lf[26]+1 /* (set! third ...) */,*((C_word*)lf[27]+1));
t20=C_mutate((C_word*)lf[28]+1 /* (set! fourth ...) */,*((C_word*)lf[29]+1));
t21=C_mutate((C_word*)lf[30]+1 /* (set! fifth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2605,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[31]+1 /* (set! sixth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2615,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[32]+1 /* (set! seventh ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2625,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[33]+1 /* (set! eighth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2635,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[34]+1 /* (set! ninth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2645,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[35]+1 /* (set! tenth ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2659,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[36]+1 /* (set! car+cdr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2673,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[37]+1 /* (set! take ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2690,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[38]+1 /* (set! drop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2727,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[39]+1 /* (set! take! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2756,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[40]+1 /* (set! take-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2779,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[41]+1 /* (set! drop-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2809,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[42]+1 /* (set! drop-right! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2847,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[43]+1 /* (set! split-at ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2889,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[44]+1 /* (set! split-at! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2941,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[45]+1 /* (set! last ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2972,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[10]+1 /* (set! last-pair ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2982,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[46]+1 /* (set! unzip1 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3003,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[48]+1 /* (set! unzip2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3009,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[49]+1 /* (set! unzip3 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3065,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[50]+1 /* (set! unzip4 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3129,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[51]+1 /* (set! unzip5 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3201,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[52]+1 /* (set! append! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3285,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[53]+1 /* (set! append-reverse ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3361,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[54]+1 /* (set! append-reverse! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3391,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[55]+1 /* (set! concatenate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3415,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[58]+1 /* (set! concatenate! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3421,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate(&lf[59] /* (set! cdrs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3427,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate(&lf[60] /* (set! cars+cdrs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3508,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[61]+1 /* (set! count ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3737,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[62]+1 /* (set! unfold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3830,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[63]+1 /* (set! unfold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3876,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[66]+1 /* (set! fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3958,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[67]+1 /* (set! fold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4029,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[68]+1 /* (set! pair-fold-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4094,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[69]+1 /* (set! pair-fold ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4160,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[70]+1 /* (set! reduce ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4225,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[56]+1 /* (set! reduce-right ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4245,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[71]+1 /* (set! append-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4289,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[73]+1 /* (set! append-map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4295,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate(&lf[72] /* (set! really-append-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4301,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[74]+1 /* (set! pair-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4410,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[75]+1 /* (set! map! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4469,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[76]+1 /* (set! filter-map ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4541,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[77]+1 /* (set! map-in-order ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4626,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[20]+1 /* (set! map ...) */,*((C_word*)lf[77]+1));
t67=C_mutate((C_word*)lf[78]+1 /* (set! filter ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4703,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[79]+1 /* (set! filter! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4745,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[80]+1 /* (set! partition ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4866,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[81]+1 /* (set! partition! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4934,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[82]+1 /* (set! remove ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5146,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[83]+1 /* (set! remove! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5162,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[84]+1 /* (set! delete ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5178,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[86]+1 /* (set! delete! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5209,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[87]+1 /* (set! member ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5240,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[89]+1 /* (set! delete-duplicates ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5267,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[90]+1 /* (set! delete-duplicates! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5319,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[91]+1 /* (set! assoc ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5371,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[93]+1 /* (set! alist-cons ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5402,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[94]+1 /* (set! alist-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5412,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[95]+1 /* (set! alist-delete ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5432,tmp=(C_word)a,a+=2,tmp));
t82=C_mutate((C_word*)lf[96]+1 /* (set! alist-delete! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5467,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[92]+1 /* (set! find ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5502,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[88]+1 /* (set! find-tail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5514,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[97]+1 /* (set! take-while ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5550,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[98]+1 /* (set! drop-while ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5585,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[99]+1 /* (set! take-while! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5617,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[100]+1 /* (set! span ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5675,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[101]+1 /* (set! span! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5728,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[102]+1 /* (set! break ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5792,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[103]+1 /* (set! break! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5808,tmp=(C_word)a,a+=2,tmp));
t92=C_mutate((C_word*)lf[104]+1 /* (set! any ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5824,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[105]+1 /* (set! every ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5941,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[106]+1 /* (set! list-index ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6058,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[107]+1 /* (set! reverse! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6145,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate(&lf[108] /* (set! lset2<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6169,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[109]+1 /* (set! lset<= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6181,tmp=(C_word)a,a+=2,tmp));
t98=C_mutate((C_word*)lf[110]+1 /* (set! lset= ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6239,tmp=(C_word)a,a+=2,tmp));
t99=C_mutate((C_word*)lf[111]+1 /* (set! lset-adjoin ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6303,tmp=(C_word)a,a+=2,tmp));
t100=C_mutate((C_word*)lf[112]+1 /* (set! lset-union ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6321,tmp=(C_word)a,a+=2,tmp));
t101=C_mutate((C_word*)lf[113]+1 /* (set! lset-union! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6369,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[114]+1 /* (set! lset-intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6420,tmp=(C_word)a,a+=2,tmp));
t103=C_mutate((C_word*)lf[116]+1 /* (set! lset-intersection! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6453,tmp=(C_word)a,a+=2,tmp));
t104=C_mutate((C_word*)lf[117]+1 /* (set! lset-difference ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6486,tmp=(C_word)a,a+=2,tmp));
t105=C_mutate((C_word*)lf[119]+1 /* (set! lset-difference! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6523,tmp=(C_word)a,a+=2,tmp));
t106=C_mutate((C_word*)lf[120]+1 /* (set! lset-xor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6560,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[122]+1 /* (set! lset-xor! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6614,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[121]+1 /* (set! lset-diff+intersection ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6672,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[123]+1 /* (set! lset-diff+intersection! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6712,tmp=(C_word)a,a+=2,tmp));
t110=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t110+1)))(2,t110,C_SCHEME_UNDEFINED);}

/* lset-diff+intersection! in k2058 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6712r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6712r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6712r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6719,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1638 every */
t6=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[16]+1),t4);}

/* k6717 in lset-diff+intersection! in k2058 */
static void C_ccall f_6719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6719,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 1638 values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* srfi-1.scm: 1639 values */
C_values(4,0,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6736,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1640 partition! */
t3=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}}}

/* a6735 in k6717 in lset-diff+intersection! in k2058 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6736,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6744,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6746,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1641 any */
t5=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6745 in a6735 in k6717 in lset-diff+intersection! in k2058 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6746,3,t0,t1,t2);}
/* srfi-1.scm: 1641 member */
t3=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6742 in a6735 in k6717 in lset-diff+intersection! in k2058 */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-diff+intersection in k2058 */
static void C_ccall f_6672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6672r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6672r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6672r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6679,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1629 every */
t6=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[16]+1),t4);}

/* k6677 in lset-diff+intersection in k2058 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6679,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 1629 values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],((C_word*)t0)[3]))){
/* srfi-1.scm: 1630 values */
C_values(4,0,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6696,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1631 partition */
t3=*((C_word*)lf[80]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[4]);}}}

/* a6695 in k6677 in lset-diff+intersection in k2058 */
static void C_ccall f_6696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6696,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6704,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1632 any */
t5=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6705 in a6695 in k6677 in lset-diff+intersection in k2058 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6706,3,t0,t1,t2);}
/* srfi-1.scm: 1632 member */
t3=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6702 in a6695 in k6677 in lset-diff+intersection in k2058 */
static void C_ccall f_6704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-xor! in k2058 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_6614r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6614r(t0,t1,t2,t3);}}

static void C_ccall f_6614r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6620,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1606 reduce */
t5=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a6619 in lset-xor! in k2058 */
static void C_ccall f_6620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6620,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6626,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6632,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6631 in a6619 in lset-xor! in k2058 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6632,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1617 lset-difference! */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1618 append! */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6656,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1619 pair-fold */
t5=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,t2,((C_word*)t0)[3]);}}}

/* a6655 in a6631 in a6619 in lset-xor! in k2058 */
static void C_ccall f_6656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6656,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6663,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1620 member */
t6=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6661 in a6655 in a6631 in a6619 in lset-xor! in k2058 */
static void C_ccall f_6663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* a6625 in a6619 in lset-xor! in k2058 */
static void C_ccall f_6626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6626,2,t0,t1);}
/* srfi-1.scm: 1616 lset-diff+intersection! */
t2=*((C_word*)lf[123]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lset-xor in k2058 */
static void C_ccall f_6560(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_6560r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6560r(t0,t1,t2,t3);}}

static void C_ccall f_6560r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1584 reduce */
t5=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a6565 in lset-xor in k2058 */
static void C_ccall f_6566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6566,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6572,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6578,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6577 in a6565 in lset-xor in k2058 */
static void C_ccall f_6578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6578,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1595 lset-difference */
t4=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1596 append */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6602,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1597 fold */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,t2,((C_word*)t0)[3]);}}}

/* a6601 in a6577 in a6565 in lset-xor in k2058 */
static void C_ccall f_6602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6602,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6609,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1598 member */
t5=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6607 in a6601 in a6577 in a6565 in lset-xor in k2058 */
static void C_ccall f_6609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6609,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3])));}

/* a6571 in a6565 in lset-xor in k2058 */
static void C_ccall f_6572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6572,2,t0,t1);}
/* srfi-1.scm: 1594 lset-diff+intersection */
t2=*((C_word*)lf[121]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lset-difference! in k2058 */
static void C_ccall f_6523(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_6523r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6523r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6523r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6527,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1573 filter */
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[118]+1),t4);}

/* k6525 in lset-difference! in k2058 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6527,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[3],t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6544,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1576 filter! */
t3=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}}}

/* a6543 in k6525 in lset-difference! in k2058 */
static void C_ccall f_6544(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6544,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1577 every */
t4=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a6549 in a6543 in k6525 in lset-difference! in k2058 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6550,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6558,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1577 member */
t4=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6556 in a6549 in a6543 in k6525 in lset-difference! in k2058 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-difference in k2058 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_6486r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6486r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6486r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6490,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1563 filter */
t6=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[118]+1),t4);}

/* k6488 in lset-difference in k2058 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6490,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[3],t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6507,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1566 filter */
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}}}

/* a6506 in k6488 in lset-difference in k2058 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6507,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6513,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1567 every */
t4=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a6512 in a6506 in k6488 in lset-difference in k2058 */
static void C_ccall f_6513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6513,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1567 member */
t4=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k6519 in a6512 in a6506 in k6488 in lset-difference in k2058 */
static void C_ccall f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* lset-intersection! in k2058 */
static void C_ccall f_6453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_6453r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6453r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6453r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6457,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1553 delete */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t3,t4,*((C_word*)lf[115]+1));}

/* k6455 in lset-intersection! in k2058 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1554 any */
t3=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[16]+1),t1);}

/* k6461 in k6455 in lset-intersection! in k2058 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6463,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6474,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1556 filter! */
t3=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[3]);}}}

/* a6473 in k6461 in k6455 in lset-intersection! in k2058 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6474,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6480,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1557 every */
t4=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a6479 in a6473 in k6461 in k6455 in lset-intersection! in k2058 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6480,3,t0,t1,t2);}
/* srfi-1.scm: 1557 member */
t3=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* lset-intersection in k2058 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_6420r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6420r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6420r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1544 delete */
t6=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t3,t4,*((C_word*)lf[115]+1));}

/* k6422 in lset-intersection in k2058 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1545 any */
t3=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[16]+1),t1);}

/* k6428 in k6422 in lset-intersection in k2058 */
static void C_ccall f_6430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6430,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1547 filter */
t3=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],t2,((C_word*)t0)[3]);}}}

/* a6440 in k6428 in k6422 in lset-intersection in k2058 */
static void C_ccall f_6441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6441,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6447,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1548 every */
t4=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a6446 in a6440 in k6428 in k6422 in lset-intersection in k2058 */
static void C_ccall f_6447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6447,3,t0,t1,t2);}
/* srfi-1.scm: 1548 member */
t3=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* lset-union! in k2058 */
static void C_ccall f_6369(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_6369r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6369r(t0,t1,t2,t3);}}

static void C_ccall f_6369r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6375,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1528 reduce */
t5=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a6374 in lset-union! in k2058 */
static void C_ccall f_6375(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6375,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1533 pair-fold */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,t3,t2);}}}}

/* a6398 in a6374 in lset-union! in k2058 */
static void C_ccall f_6399(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6399,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6409,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6414,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1535 any */
t7=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}

/* a6413 in a6398 in a6374 in lset-union! in k2058 */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6414,3,t0,t1,t2);}
/* srfi-1.scm: 1535 = */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k6407 in a6398 in a6374 in lset-union! in k2058 */
static void C_ccall f_6409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* lset-union in k2058 */
static void C_ccall f_6321(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_6321r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6321r(t0,t1,t2,t3);}}

static void C_ccall f_6321r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6327,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1515 reduce */
t5=*((C_word*)lf[70]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t4,C_SCHEME_END_OF_LIST,t3);}

/* a6326 in lset-union in k2058 */
static void C_ccall f_6327(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6327,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1520 fold */
t6=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,t3,t2);}}}}

/* a6350 in a6326 in lset-union in k2058 */
static void C_ccall f_6351(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6351,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6358,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6363,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1520 any */
t6=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t3);}

/* a6362 in a6350 in a6326 in lset-union in k2058 */
static void C_ccall f_6363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6363,3,t0,t1,t2);}
/* srfi-1.scm: 1520 = */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k6356 in a6350 in a6326 in lset-union in k2058 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6358,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3])));}

/* lset-adjoin in k2058 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_6303r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6303r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6303r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1509 fold */
t6=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,t3,t4);}

/* a6308 in lset-adjoin in k2058 */
static void C_ccall f_6309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6309,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6316,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1509 member */
t5=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,t3,((C_word*)t0)[2]);}

/* k6314 in a6308 in lset-adjoin in k2058 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6316,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3])));}

/* lset= in k2058 */
static void C_ccall f_6239(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6239r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6239r(t0,t1,t2,t3);}}

static void C_ccall f_6239r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(6);
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6259,a[2]=t2,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_6259(t11,t1,t6,t7);}}

/* lp in lset= in k2058 */
static void C_fcall f_6259(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6259,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(t2,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6281,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6281(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6290,a[2]=t2,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t9,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1503 ##srfi1#lset2<= */
f_6169(t10,((C_word*)t0)[2],t2,t6);}}}

/* k6288 in lp in lset= in k2058 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1503 ##srfi1#lset2<= */
f_6169(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_6281(2,t2,C_SCHEME_FALSE);}}

/* k6279 in lp in lset= in k2058 */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1504 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6259(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* lset<= in k2058 */
static void C_ccall f_6181(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_6181r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6181r(t0,t1,t2,t3);}}

static void C_ccall f_6181r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(6);
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6201,a[2]=t2,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_6201(t11,t1,t6,t7);}}

/* lp in lset<= in k2058 */
static void C_fcall f_6201(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6201,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(t6,t2);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6223,a[2]=t7,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6223(2,t10,t8);}
else{
/* srfi-1.scm: 1492 ##srfi1#lset2<= */
f_6169(t9,((C_word*)t0)[2],t2,t6);}}}

/* k6221 in lp in lset<= in k2058 */
static void C_ccall f_6223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1493 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6201(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##srfi1#lset2<= in k2058 */
static void C_fcall f_6169(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6169,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6175,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1483 every */
t6=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t5,t3);}

/* a6174 in ##srfi1#lset2<= in k2058 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6175,3,t0,t1,t2);}
/* srfi-1.scm: 1483 member */
t3=*((C_word*)lf[87]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* reverse! in k2058 */
static void C_ccall f_6145(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6145,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6151,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_6151(t2,C_SCHEME_END_OF_LIST));}

/* lp in reverse! in k2058 */
static C_word C_fcall f_6151(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_i_setslot(t1,C_fix(1),t2);
t6=t3;
t7=t1;
t1=t6;
t2=t7;
goto loop;}}

/* list-index in k2058 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_6058r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6058r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6058r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6074,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6074(t9,t1,t5,C_fix(0));}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6111,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6111(t8,t1,t3,C_fix(0));}}

/* lp in list-index in k2058 */
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6111,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6124,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1452 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6122 in lp in list-index in k2058 */
static void C_ccall f_6124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1452 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6111(t4,((C_word*)t0)[5],t2,t3);}}

/* lp in list-index in k2058 */
static void C_fcall f_6074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6074,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a6085 in lp in list-index in k2058 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6086,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6099,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k6097 in a6085 in lp in list-index in k2058 */
static void C_ccall f_6099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1447 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6074(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* a6079 in lp in list-index in k2058 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6080,2,t0,t1);}
/* srfi-1.scm: 1444 ##srfi1#cars+cdrs */
f_3508(t1,((C_word*)t0)[2]);}

/* every in k2058 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5941r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5941r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5941r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5953,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5963,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=(C_word)C_i_nullp(t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_word)C_slot(t3,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6029,a[2]=t9,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_6029(t11,t1,t6,t7);}}}

/* lp in every in k2058 */
static void C_fcall f_6029(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6029,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1435 pred */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6045,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1436 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k6043 in lp in every in k2058 */
static void C_ccall f_6045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1436 lp */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6029(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5962 in every in k2058 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5963,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[2],a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5975(t9,t1,t2,t3);}}

/* lp in a5962 in every in k2058 */
static void C_fcall f_5975(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5975,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5981,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5987,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5986 in lp in a5962 in every in k2058 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5987,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6000,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5998 in a5986 in lp in a5962 in every in k2058 */
static void C_ccall f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-1.scm: 1428 lp */
t2=((C_word*)((C_word*)t0)[5])[1];
f_5975(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5980 in lp in a5962 in every in k2058 */
static void C_ccall f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5981,2,t0,t1);}
/* srfi-1.scm: 1426 ##srfi1#cars+cdrs */
f_3508(t1,((C_word*)t0)[2]);}

/* a5952 in every in k2058 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5953,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-1.scm: 1423 ##srfi1#cars+cdrs */
f_3508(t1,t2);}

/* any in k2058 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5824r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5824r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5824r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5836,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5908,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5908(t10,t1,t5,t6);}}}

/* lp in any in k2058 */
static void C_fcall f_5908(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5908,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1408 pred */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 1409 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5919 in lp in any in k2058 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1409 lp */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5908(t4,((C_word*)t0)[4],t2,t3);}}

/* a5845 in any in k2058 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5846,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5858,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5858(t7,t1,t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* lp in a5845 in any in k2058 */
static void C_fcall f_5858(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5858,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5864,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5870,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a5869 in lp in a5845 in any in k2058 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5870,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5880,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5878 in a5869 in lp in a5845 in any in k2058 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* srfi-1.scm: 1401 lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5858(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a5863 in lp in a5845 in any in k2058 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
/* srfi-1.scm: 1399 ##srfi1#cars+cdrs */
f_3508(t1,((C_word*)t0)[2]);}

/* a5835 in any in k2058 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-1.scm: 1396 ##srfi1#cars+cdrs */
f_3508(t1,t2);}

/* break! in k2058 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5808,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5814,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1389 span! */
t5=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5813 in break! in k2058 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5814,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5822,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1389 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5820 in a5813 in break! in k2058 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* break in k2058 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5792,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5798,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1388 span */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5797 in break in k2058 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5798,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5806,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1388 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5804 in a5797 in break in k2058 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* span! in k2058 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5728,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5738,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_5738(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5786,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1378 pred */
t8=t2;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5784 in span! in k2058 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5738(t2,(C_word)C_i_not(t1));}

/* k5736 in span! in k2058 */
static void C_fcall f_5738(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5738,NULL,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 1378 values */
C_values(4,0,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5753,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5753(t7,t2,((C_word*)t0)[3],t3);}}

/* lp in k5736 in span! in k2058 */
static void C_fcall f_5753(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5753,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5769,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1382 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}

/* k5767 in lp in k5736 in span! in k2058 */
static void C_ccall f_5769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1382 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5753(t3,((C_word*)t0)[3],((C_word*)t0)[5],t2);}
else{
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(1),C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}}

/* k5742 in k5736 in span! in k2058 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1385 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* span in k2058 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5675,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5681,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5681(t7,t1,t3);}

/* recur in span in k2058 */
static void C_fcall f_5681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5681,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1369 values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5700,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1371 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k5698 in recur in span in k2058 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5700,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
/* srfi-1.scm: 1374 values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);}}

/* a5714 in k5698 in recur in span in k2058 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5715,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
/* srfi-1.scm: 1373 values */
C_values(4,0,t1,t4,t3);}

/* a5704 in k5698 in recur in span in k2058 */
static void C_ccall f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5705,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1372 recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5681(t3,t1,t2);}

/* take-while! in k2058 */
static void C_ccall f_5617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5617,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5627,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_5627(t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5669,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1358 pred */
t8=t2;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5667 in take-while! in k2058 */
static void C_ccall f_5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5627(t2,(C_word)C_i_not(t1));}

/* k5625 in take-while! in k2058 */
static void C_fcall f_5627(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5627,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5636(t7,t2,((C_word*)t0)[3],t3);}}

/* lp in k5625 in take-while! in k2058 */
static void C_fcall f_5636(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5636,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5652,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1362 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5650 in lp in k5625 in take-while! in k2058 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1362 lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5636(t3,((C_word*)t0)[3],((C_word*)t0)[5],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(1),C_SCHEME_END_OF_LIST));}}

/* k5628 in k5625 in take-while! in k2058 */
static void C_ccall f_5630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* drop-while in k2058 */
static void C_ccall f_5585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5585,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5591,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5591(t7,t1,t3);}

/* lp in drop-while in k2058 */
static void C_fcall f_5591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5591,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5604,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1352 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k5602 in lp in drop-while in k2058 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 1353 lp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5591(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* take-while in k2058 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5550,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5556,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5556(t7,t1,t3);}

/* recur in take-while in k2058 */
static void C_fcall f_5556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5556,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5572,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1344 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k5570 in recur in take-while in k2058 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5579,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1345 recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5556(t4,t2,t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5577 in k5570 in recur in take-while in k2058 */
static void C_ccall f_5579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5579,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* find-tail in k2058 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5514,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5520,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5520(t7,t1,t3);}

/* lp in find-tail in k2058 */
static void C_fcall f_5520(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5520,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1336 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k5531 in lp in find-tail in k2058 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1337 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5520(t3,((C_word*)t0)[4],t2);}}

/* find in k2058 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5502,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5506,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1329 find-tail */
t5=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k5504 in find in k2058 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_u_i_car(t1):C_SCHEME_FALSE));}

/* alist-delete! in k2058 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5467r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5467r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5467r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[85]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5476,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1322 filter! */
t8=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a5475 in alist-delete! in k2058 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5476,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1322 = */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k5482 in a5475 in alist-delete! in k2058 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* alist-delete in k2058 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5432r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5432r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5432r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[85]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5441,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1318 filter */
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a5440 in alist-delete in k2058 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5441,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5449,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1318 = */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}

/* k5447 in a5440 in alist-delete in k2058 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* alist-copy in k2058 */
static void C_ccall f_5412(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5412,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5418,tmp=(C_word)a,a+=2,tmp);
/* srfi-1.scm: 1313 ##sys#map */
t4=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a5417 in alist-copy in k2058 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5418,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* alist-cons in k2058 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5402,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,t5,t4));}

/* assoc in k2058 */
static void C_ccall f_5371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5371r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5371r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5371r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[85]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5380,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1308 find */
t8=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a5379 in assoc in k2058 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5380,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1308 = */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t3);}

/* delete-duplicates! in k2058 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5319r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5319r(t0,t1,t2,t3);}}

static void C_ccall f_5319r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[85]+1):(C_word)C_slot(t3,C_fix(0)));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5328,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5328(t9,t1,t2);}

/* recur in delete-duplicates! in k2058 */
static void C_fcall f_5328(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5328,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5344,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5357,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1298 delete! */
t7=*((C_word*)lf[86]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k5355 in recur in delete-duplicates! in k2058 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1298 recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5328(t2,((C_word*)t0)[2],t1);}

/* k5342 in recur in delete-duplicates! in k2058 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* delete-duplicates in k2058 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5267r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5267r(t0,t1,t2,t3);}}

static void C_ccall f_5267r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?*((C_word*)lf[85]+1):(C_word)C_slot(t3,C_fix(0)));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5276,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5276(t9,t1,t2);}

/* recur in delete-duplicates in k2058 */
static void C_fcall f_5276(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5276,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5292,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1288 delete */
t7=*((C_word*)lf[84]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t3,t4,((C_word*)t0)[2]);}}

/* k5303 in recur in delete-duplicates in k2058 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1288 recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5276(t2,((C_word*)t0)[2],t1);}

/* k5290 in recur in delete-duplicates in k2058 */
static void C_ccall f_5292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5292,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* member in k2058 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5240r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5240r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5240r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[85]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5249,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1263 find-tail */
t8=*((C_word*)lf[88]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a5248 in member in k2058 */
static void C_ccall f_5249(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5249,3,t0,t1,t2);}
/* srfi-1.scm: 1263 = */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* delete! in k2058 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5209r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5209r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5209r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[85]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5218,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1258 filter! */
t8=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a5217 in delete! in k2058 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5218,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5226,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1258 = */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k5224 in a5217 in delete! in k2058 */
static void C_ccall f_5226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* delete in k2058 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5178r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5178r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?*((C_word*)lf[85]+1):(C_word)C_slot(t4,C_fix(0)));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5187,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1254 filter */
t8=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t7,t3);}

/* a5186 in delete in k2058 */
static void C_ccall f_5187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5187,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5195,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1254 = */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}

/* k5193 in a5186 in delete in k2058 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* remove! in k2058 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5162,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5168,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1231 filter! */
t5=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5167 in remove! in k2058 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5168,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5176,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1231 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5174 in a5167 in remove! in k2058 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* remove in k2058 */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5146,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5152,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1230 filter */
t5=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a5151 in remove in k2058 */
static void C_ccall f_5152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5152,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5160,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1230 pred */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5158 in a5151 in remove in k2058 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* partition! in k2058 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4934,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 1187 values */
C_values(4,0,t1,t3,t3);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4946,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4991,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5040,a[2]=t5,a[3]=t1,a[4]=t2,a[5]=t7,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t11=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1212 pred */
t12=t2;
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* k5038 in partition! in k2058 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5040,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5049(t6,((C_word*)t0)[3],((C_word*)t0)[6],t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5099(t6,((C_word*)t0)[3],((C_word*)t0)[6],t2);}}

/* lp in k5038 in partition! in k2058 */
static void C_fcall f_5099(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5099,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1223 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* srfi-1.scm: 1222 values */
C_values(4,0,t1,t3,((C_word*)t0)[5]);}}

/* k5113 in lp in k5038 in partition! in k2058 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5115,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1224 scan-in */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4946(t4,t2,((C_word*)t0)[6],((C_word*)t0)[3],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1226 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5099(t3,((C_word*)t0)[7],((C_word*)t0)[6],t2);}}

/* k5116 in k5113 in lp in k5038 in partition! in k2058 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1225 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k5038 in partition! in k2058 */
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5049,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5065,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1216 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* srfi-1.scm: 1215 values */
C_values(4,0,t1,((C_word*)t0)[4],t3);}}

/* k5063 in lp in k5038 in partition! in k2058 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5065,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1216 lp */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5049(t3,((C_word*)t0)[5],((C_word*)t0)[7],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5075,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1217 scan-out */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4991(t4,t2,((C_word*)t0)[2],((C_word*)t0)[7],t3);}}

/* k5073 in k5063 in lp in k5038 in partition! in k2058 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 1218 values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* scan-out in partition! in k2058 */
static void C_fcall f_4991(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4991,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4997,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4997(t8,t1,t3,t4);}

/* lp in scan-out in partition! in k2058 */
static void C_fcall f_4997(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4997,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1205 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t3));}}

/* k5008 in lp in scan-out in partition! in k2058 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[7],C_fix(1),((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1207 scan-in */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4946(t4,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1208 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4997(t3,((C_word*)t0)[4],((C_word*)t0)[6],t2);}}

/* scan-in in partition! in k2058 */
static void C_fcall f_4946(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4946,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4952(t8,t1,t2,t4);}

/* lp in scan-in in partition! in k2058 */
static void C_fcall f_4952(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4952,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4965,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1196 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),t3));}}

/* k4963 in lp in scan-in in partition! in k2058 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1197 lp */
t3=((C_word*)((C_word*)t0)[6])[1];
f_4952(t3,((C_word*)t0)[5],((C_word*)t0)[7],t2);}
else{
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(1),((C_word*)t0)[7]);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* srfi-1.scm: 1199 scan-out */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4991(t4,((C_word*)t0)[5],((C_word*)t0)[2],((C_word*)t0)[7],t3);}}

/* partition in k2058 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4866,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4872,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4872(t7,t1,t3);}

/* recur in partition in k2058 */
static void C_fcall f_4872(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4872,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 1154 values */
C_values(4,0,t1,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4893,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4899,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a4898 in recur in partition in k2058 */
static void C_ccall f_4899(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4899,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4906,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 1158 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k4904 in a4898 in recur in partition in k2058 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4906,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]):((C_word*)t0)[3]);
/* srfi-1.scm: 1159 values */
C_values(4,0,((C_word*)t0)[2],t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]):((C_word*)t0)[3]);
/* srfi-1.scm: 1160 values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t3);}}

/* a4892 in recur in partition in k2058 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
/* srfi-1.scm: 1157 recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4872(t2,t1,((C_word*)t0)[2]);}

/* filter! in k2058 */
static void C_ccall f_4745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4745,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4751,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4751(t7,t1,t3);}

/* lp in filter! in k2058 */
static void C_fcall f_4751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4751,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1119 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k4858 in lp in filter! in k2058 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4806,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1143 scan-in */
t10=((C_word*)t3)[1];
f_4773(t10,t8,((C_word*)t0)[3],t9);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 1119 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4751(t3,((C_word*)t0)[4],t2);}}

/* k4850 in k4858 in lp in filter! in k2058 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* scan-out in k4858 in lp in filter! in k2058 */
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4806,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4812,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4812(t7,t1,t3);}

/* lp in scan-out in k4858 in lp in filter! in k2058 */
static void C_fcall f_4812(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4812,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1138 pred */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(1),t2));}}

/* k4823 in lp in scan-out in k4858 in lp in filter! in k2058 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_setslot(((C_word*)t0)[6],C_fix(1),((C_word*)t0)[5]);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1140 scan-in */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4773(t4,((C_word*)t0)[3],((C_word*)t0)[5],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1141 lp */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4812(t3,((C_word*)t0)[3],t2);}}

/* scan-in in k4858 in lp in filter! in k2058 */
static void C_fcall f_4773(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4773,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4786,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 1132 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k4784 in scan-in in k4858 in lp in filter! in k2058 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1133 scan-in */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4773(t3,((C_word*)t0)[4],((C_word*)t0)[6],t2);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-1.scm: 1134 scan-out */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4806(t3,((C_word*)t0)[4],((C_word*)t0)[2],t2);}}

/* filter in k2058 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4703,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4709,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4709(t7,t1,t3);}

/* recur in filter in k2058 */
static void C_fcall f_4709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4709,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 1068 pred */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k4726 in recur in filter in k2058 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 1069 recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4709(t3,t2,((C_word*)t0)[6]);}
else{
/* srfi-1.scm: 1072 recur */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4709(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k4729 in k4726 in recur in filter in k2058 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* map-in-order in k2058 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_4626r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4626r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4626r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4642,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4642(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4676,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4676(t8,t1,t3);}}

/* recur in map-in-order in k2058 */
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4676,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4689,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1046 f */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k4687 in recur in map-in-order in k2058 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4696,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1047 recur */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4676(t3,t2,((C_word*)t0)[2]);}

/* k4694 in k4687 in recur in map-in-order in k2058 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4696,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* recur in map-in-order in k2058 */
static void C_fcall f_4642(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4642,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4648,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a4653 in recur in map-in-order in k2058 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4654,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4664,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4662 in a4653 in recur in map-in-order in k2058 */
static void C_ccall f_4664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4671,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1039 recur */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4642(t3,t2,((C_word*)t0)[2]);}

/* k4669 in k4662 in a4653 in recur in map-in-order in k2058 */
static void C_ccall f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4647 in recur in map-in-order in k2058 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
/* srfi-1.scm: 1036 ##srfi1#cars+cdrs */
f_3508(t1,((C_word*)t0)[2]);}

/* filter-map in k2058 */
static void C_ccall f_4541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_4541r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4541r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4541r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4557,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4557(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4597,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4597(t8,t1,t3);}}

/* recur in filter-map in k2058 */
static void C_fcall f_4597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4597,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4607,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 1023 recur */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k4605 in recur in filter-map in k2058 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4607,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4610,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* srfi-1.scm: 1024 f */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4608 in k4605 in recur in filter-map in k2058 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4610,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]):((C_word*)t0)[2]));}

/* recur in filter-map in k2058 */
static void C_fcall f_4557(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4557,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a4568 in recur in filter-map in k2058 */
static void C_ccall f_4569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4569,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4579,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4577 in a4568 in recur in filter-map in k2058 */
static void C_ccall f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4579,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4589,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 1016 recur */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4557(t3,t2,((C_word*)t0)[2]);}
else{
/* srfi-1.scm: 1017 recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4557(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4587 in k4577 in a4568 in recur in filter-map in k2058 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a4562 in recur in filter-map in k2058 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
/* srfi-1.scm: 1014 ##srfi1#cars+cdrs */
f_3508(t1,((C_word*)t0)[2]);}

/* map! in k2058 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_4469r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4469r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4469r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4473,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4481,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4481(t9,t5,t3,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 1005 pair-for-each */
t7=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* a4526 in map! in k2058 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4527,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 1005 f */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4533 in a4526 in map! in k2058 */
static void C_ccall f_4535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* lp in map! in k2058 */
static void C_fcall f_4481(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4481,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4493,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a4498 in lp in map! in k2058 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4499,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4514,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
C_apply(5,0,t4,((C_word*)t0)[2],t5,t2);}

/* k4512 in a4498 in lp in map! in k2058 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],C_fix(0),t1);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 1002 lp */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4481(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* a4492 in lp in map! in k2058 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4493,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3678,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3678(t6,t1,t2);}

/* recur in a4492 in lp in map! in k2058 */
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3678,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3690,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
/* srfi-1.scm: 825  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* a3695 in recur in a4492 in lp in map! in k2058 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3696,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3702,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3708,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3707 in a3695 in recur in a4492 in lp in map! in k2058 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3708,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3720,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3719 in a3707 in a3695 in recur in a4492 in lp in map! in k2058 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3720,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
/* srfi-1.scm: 824  values */
C_values(4,0,t1,t4,t5);}

/* a3713 in a3707 in a3695 in recur in a4492 in lp in map! in k2058 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
/* srfi-1.scm: 823  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3678(t2,t1,((C_word*)t0)[2]);}

/* a3701 in a3695 in recur in a4492 in lp in map! in k2058 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3702,2,t0,t1);}
/* srfi-1.scm: 822  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a3689 in recur in a4492 in lp in map! in k2058 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
/* srfi-1.scm: 821  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k4471 in map! in k2058 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pair-for-each in k2058 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_4410r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4410r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4410r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_a_i_cons(&a,2,t3,t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4426,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4426(t9,t1,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4447,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_4447(t8,t1,t3);}}

/* lp in pair-for-each in k2058 */
static void C_fcall f_4447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4447,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_slot(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4460,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 991  proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k4458 in lp in pair-for-each in k2058 */
static void C_ccall f_4460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 992  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4447(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in pair-for-each in k2058 */
static void C_fcall f_4426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4426,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 982  ##srfi1#cdrs */
f_3427(t3,t2);}

/* k4428 in lp in pair-for-each in k2058 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4439,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4437 in k4428 in lp in pair-for-each in k2058 */
static void C_ccall f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 985  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4426(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##srfi1#really-append-map in k2058 */
static void C_fcall f_4301(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4301,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4313,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4323,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(t4))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_u_i_car(t4);
t7=(C_word)C_slot(t4,C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4383,a[2]=t3,a[3]=t9,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4383(t11,t1,t6,t7);}}}

/* recur in ##srfi1#really-append-map in k2058 */
static void C_fcall f_4383(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4383,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4387,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 972  f */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4385 in recur in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4387,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4400,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* srfi-1.scm: 974  recur */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4383(t5,t2,t3,t4);}}

/* k4398 in k4385 in recur in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 974  appender */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4322 in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4323,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4335,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4335(t7,t1,t2,t3);}}

/* recur in a4322 in ##srfi1#really-append-map in k2058 */
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4335,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4339,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}

/* k4337 in recur in a4322 in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4349 in k4337 in recur in a4322 in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4350,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4364,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 967  recur */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4335(t5,t4,t2,t3);}}

/* k4362 in a4349 in k4337 in recur in a4322 in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 967  appender */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4343 in k4337 in recur in a4322 in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
/* srfi-1.scm: 965  ##srfi1#cars+cdrs */
f_3508(t1,((C_word*)t0)[2]);}

/* a4312 in ##srfi1#really-append-map in k2058 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* srfi-1.scm: 961  ##srfi1#cars+cdrs */
f_3508(t1,t2);}

/* append-map! in k2058 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_4295r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4295r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4295r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* srfi-1.scm: 956  ##srfi1#really-append-map */
f_4301(t1,*((C_word*)lf[52]+1),t2,t3,t4);}

/* append-map in k2058 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_4289r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4289r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4289r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* srfi-1.scm: 954  ##srfi1#really-append-map */
f_4301(t1,*((C_word*)lf[57]+1),t2,t3,t4);}

/* reduce-right in k2058 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4245,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4265,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_4265(t10,t1,t5,t6);}}

/* recur in reduce-right in k2058 */
static void C_fcall f_4265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4265,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4279,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-1.scm: 945  recur */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4277 in recur in reduce-right in k2058 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 945  f */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* reduce in k2058 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4225,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
/* srfi-1.scm: 938  fold */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,t5,t6);}}

/* pair-fold in k2058 */
static void C_ccall f_4160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_4160r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4160r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4160r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4176,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_4176(t10,t1,t6,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4206,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4206(t9,t1,t4,t3);}}

/* lp in pair-fold in k2058 */
static void C_fcall f_4206(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4206,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4223,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 929  f */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}}

/* k4221 in lp in pair-fold in k2058 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 929  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4206(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in pair-fold in k2058 */
static void C_fcall f_4176(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4176,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4180,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 922  ##srfi1#cdrs */
f_3427(t4,t2);}

/* k4178 in lp in pair-fold in k2058 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4193,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
/* srfi-1.scm: 924  append! */
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k4195 in k4178 in lp in pair-fold in k2058 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4191 in k4178 in lp in pair-fold in k2058 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 924  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4176(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pair-fold-right in k2058 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5r,(void*)f_4094r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4094r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4094r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(10);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4110,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4110(t10,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4140,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4140(t9,t1,t4);}}

/* recur in pair-fold-right in k2058 */
static void C_fcall f_4140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4140,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4154,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 916  recur */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k4152 in recur in pair-fold-right in k2058 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 916  f */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in pair-fold-right in k2058 */
static void C_fcall f_4110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4110,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 911  ##srfi1#cdrs */
f_3427(t3,t2);}

/* k4112 in recur in pair-fold-right in k2058 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4127,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4135,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 913  recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4110(t4,t3,t1);}}

/* k4133 in k4112 in recur in pair-fold-right in k2058 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* srfi-1.scm: 913  append! */
t3=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4125 in k4112 in recur in pair-fold-right in k2058 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold-right in k2058 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr5r,(void*)f_4029r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4029r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4029r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(10);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4045,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_4045(t10,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4071,a[2]=t7,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_4071(t9,t1,t4);}}

/* recur in fold-right in k2058 */
static void C_fcall f_4071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4071,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4088,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 904  recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k4086 in recur in fold-right in k2058 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 904  kons */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in fold-right in k2058 */
static void C_fcall f_4045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4045,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 897  ##srfi1#cdrs */
f_3427(t3,t2);}

/* k4047 in recur in fold-right in k2058 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4062,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4066,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 899  recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4045(t4,t3,t1);}}

/* k4064 in k4047 in recur in fold-right in k2058 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3481,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3481(t6,((C_word*)t0)[2],t2);}

/* recur in k4064 in k4047 in recur in fold-right in k2058 */
static void C_fcall f_3481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3481,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_caar(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3499,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 785  recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* k3497 in recur in k4064 in k4047 in recur in fold-right in k2058 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4060 in k4047 in recur in fold-right in k2058 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fold in k2058 */
static void C_ccall f_3958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_3958r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3958r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3958r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_3974(t10,t1,t6,t3);}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4005,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4005(t9,t1,t4,t3);}}

/* lp in fold in k2058 */
static void C_fcall f_4005(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4005,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4023,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 890  kons */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t3);}}

/* k4021 in lp in fold in k2058 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 890  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4005(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in fold in k2058 */
static void C_fcall f_3974(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3974,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3980,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3985 in lp in fold in k2058 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3986,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4000,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t4,((C_word*)t0)[2],t2);}}

/* k3998 in a3985 in lp in fold in k2058 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 886  lp */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3974(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3979 in lp in fold in k2058 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3594,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 806  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t4);}

/* a3593 in a3979 in lp in fold in k2058 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3594,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3600,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3600(t6,t1,((C_word*)t0)[2]);}

/* recur in a3593 in a3979 in lp in fold in k2058 */
static void C_fcall f_3600(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3600,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* srfi-1.scm: 815  values */
C_values(4,0,t1,t3,C_SCHEME_END_OF_LIST);}}

/* a3617 in recur in a3593 in a3979 in lp in fold in k2058 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3618,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 811  abort */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3633,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3639,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3638 in a3617 in recur in a3593 in a3979 in lp in fold in k2058 */
static void C_ccall f_3639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3639,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3651,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3650 in a3638 in a3617 in recur in a3593 in a3979 in lp in fold in k2058 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3651,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
/* srfi-1.scm: 814  values */
C_values(4,0,t1,t4,t5);}

/* a3644 in a3638 in a3617 in recur in a3593 in a3979 in lp in fold in k2058 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
/* srfi-1.scm: 813  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3600(t2,t1,((C_word*)t0)[2]);}

/* a3632 in a3617 in recur in a3593 in a3979 in lp in fold in k2058 */
static void C_ccall f_3633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3633,2,t0,t1);}
/* srfi-1.scm: 812  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a3611 in recur in a3593 in a3979 in lp in fold in k2058 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3612,2,t0,t1);}
/* srfi-1.scm: 810  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* unfold in k2058 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_3876r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_3876r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3876r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_slot(t6,C_fix(1));
if(C_truep((C_word)C_i_pairp(t8))){
C_apply(10,0,t1,*((C_word*)lf[64]+1),lf[65],*((C_word*)lf[63]+1),t2,t3,t4,t5,t6);}
else{
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3900,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t10,a[6]=t7,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_3900(t12,t1,t5);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3934,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3934(t10,t1,t5);}}

/* recur in unfold in k2058 */
static void C_fcall f_3934(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3934,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 876  p */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3939 in recur in unfold in k2058 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 877  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3946 in k3939 in recur in unfold in k2058 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3952,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3956,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 877  g */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3954 in k3946 in k3939 in recur in unfold in k2058 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 877  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3934(t2,((C_word*)t0)[2],t1);}

/* k3950 in k3946 in k3939 in recur in unfold in k2058 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3952,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* recur in unfold in k2058 */
static void C_fcall f_3900(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3900,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* srfi-1.scm: 872  p */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3905 in recur in unfold in k2058 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
if(C_truep(t1)){
/* srfi-1.scm: 872  tail-gen */
t2=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 873  f */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k3915 in k3905 in recur in unfold in k2058 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3921,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3925,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 873  g */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3923 in k3915 in k3905 in recur in unfold in k2058 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 873  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3900(t2,((C_word*)t0)[2],t1);}

/* k3919 in k3915 in k3905 in recur in unfold in k2058 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unfold-right in k2058 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr6rv,(void*)f_3830r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest_vector(a,C_rest_count(0));
f_3830r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_3830r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(8);
t7=(C_word)C_vemptyp(t6);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(0)));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3840,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3840(t12,t1,t5,t8);}

/* lp in unfold-right in k2058 */
static void C_fcall f_3840(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3840,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* srfi-1.scm: 856  p */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3845 in lp in unfold-right in k2058 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3847,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-1.scm: 857  g */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3852 in k3845 in lp in unfold-right in k2058 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3862,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 858  f */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3860 in k3852 in k3845 in lp in unfold-right in k2058 */
static void C_ccall f_3862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3862,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* srfi-1.scm: 857  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3840(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* count in k2058 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_3737r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3737r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3737r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(6);
if(C_truep((C_word)C_i_pairp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3749,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3749(t8,t1,t3,t4,C_fix(0));}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3800,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3800(t8,t1,t3,C_fix(0));}}

/* lp in count in k2058 */
static void C_fcall f_3800(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3800,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3821,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
/* srfi-1.scm: 845  pred */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k3819 in lp in count in k2058 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
/* srfi-1.scm: 845  lp */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3800(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* lp in count in k2058 */
static void C_fcall f_3749(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3749,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3761,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a3766 in lp in count in k2058 */
static void C_ccall f_3767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3767,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3788,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_i_car(((C_word*)t0)[4]);
C_apply(5,0,t5,((C_word*)t0)[2],t6,t2);}}

/* k3786 in a3766 in lp in count in k2058 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1)):((C_word*)t0)[6]);
/* srfi-1.scm: 839  lp */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3749(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3760 in lp in count in k2058 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
/* srfi-1.scm: 837  ##srfi1#cars+cdrs */
f_3508(t1,((C_word*)t0)[2]);}

/* ##srfi1#cars+cdrs in k2058 */
static void C_fcall f_3508(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3508,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3514,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 792  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t3);}

/* a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3514,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3520,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3520(t6,t1,((C_word*)t0)[2]);}

/* recur in a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_fcall f_3520(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3520,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
/* srfi-1.scm: 801  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* a3537 in recur in a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3538,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 797  abort */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3559,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3558 in a3537 in recur in a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_ccall f_3559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3559,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3571,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3570 in a3558 in a3537 in recur in a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_ccall f_3571(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3571,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
/* srfi-1.scm: 800  values */
C_values(4,0,t1,t4,t5);}

/* a3564 in a3558 in a3537 in recur in a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_ccall f_3565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3565,2,t0,t1);}
/* srfi-1.scm: 799  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3520(t2,t1,((C_word*)t0)[2]);}

/* a3552 in a3537 in recur in a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
/* srfi-1.scm: 798  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a3531 in recur in a3513 in ##srfi1#cars+cdrs in k2058 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3532,2,t0,t1);}
/* srfi-1.scm: 796  car+cdr */
t2=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* ##srfi1#cdrs in k2058 */
static void C_fcall f_3427(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3427,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 774  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t3);}

/* a3432 in ##srfi1#cdrs in k2058 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3433,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3439,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3439(t6,t1,((C_word*)t0)[2]);}

/* recur in a3432 in ##srfi1#cdrs in k2058 */
static void C_fcall f_3439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3439,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 779  abort */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_slot(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3469,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 780  recur */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}}

/* k3467 in recur in a3432 in ##srfi1#cdrs in k2058 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* concatenate! in k2058 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3421,3,t0,t1,t2);}
/* srfi-1.scm: 751  reduce-right */
t3=*((C_word*)lf[56]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[52]+1),C_SCHEME_END_OF_LIST,t2);}

/* concatenate in k2058 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3415,3,t0,t1,t2);}
/* srfi-1.scm: 750  reduce-right */
t3=*((C_word*)lf[56]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[57]+1),C_SCHEME_END_OF_LIST,t2);}

/* append-reverse! in k2058 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3391,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3397,tmp=(C_word)a,a+=2,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3397(t2,t3));}

/* lp in append-reverse! in k2058 */
static C_word C_fcall f_3397(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_i_setslot(t1,C_fix(1),t2);
t6=t3;
t7=t1;
t1=t6;
t2=t7;
goto loop;}}

/* append-reverse in k2058 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3361,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3367,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3367(t7,t1,t2,t3);}

/* lp in append-reverse in k2058 */
static void C_fcall f_3367(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3367,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_a_i_cons(&a,2,t5,t3);
/* srfi-1.scm: 740  lp */
t8=t1;
t9=t4;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* append! in k2058 */
static void C_ccall f_3285(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_3285r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3285r(t0,t1,t2);}}

static void C_ccall f_3285r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3291,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3291(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* lp in append! in k2058 */
static void C_fcall f_3291(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3291,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3320,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* srfi-1.scm: 708  last-pair */
t7=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
/* srfi-1.scm: 705  lp */
t8=t1;
t9=t5;
t10=t4;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3318 in lp in append! in k2058 */
static void C_ccall f_3320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3320,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3322,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3322(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp2 in k3318 in lp in append! in k2058 */
static void C_fcall f_3322(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3322,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_i_setslot(t2,C_fix(1),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3345,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
/* srfi-1.scm: 714  last-pair */
t8=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t8=t7;
f_3345(2,t8,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}

/* k3343 in lp2 in k3318 in lp in append! in k2058 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-1.scm: 714  lp2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3322(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* unzip5 in k2058 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3201,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3207(t6,t1,t2);}

/* recur in unzip5 in k2058 */
static void C_fcall f_3207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3207,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 686  values */
C_values(7,0,t1,t2,t2,t2,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3225,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3235,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3234 in recur in unzip5 in k2058 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_3235,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_u_i_car(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t7,t2);
t9=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,t3);
t11=(C_word)C_u_i_caddr(((C_word*)t0)[2]);
t12=(C_word)C_a_i_cons(&a,2,t11,t4);
t13=(C_word)C_u_i_cadddr(((C_word*)t0)[2]);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
t15=(C_word)C_u_i_cddddr(((C_word*)t0)[2]);
t16=(C_word)C_u_i_car(t15);
t17=(C_word)C_a_i_cons(&a,2,t16,t6);
/* srfi-1.scm: 689  values */
C_values(7,0,t1,t8,t10,t12,t14,t17);}

/* a3224 in recur in unzip5 in k2058 */
static void C_ccall f_3225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3225,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 688  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3207(t3,t1,t2);}

/* unzip4 in k2058 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3129,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3135,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3135(t6,t1,t2);}

/* recur in unzip4 in k2058 */
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3135,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 676  values */
C_values(6,0,t1,t2,t2,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3163,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3162 in recur in unzip4 in k2058 */
static void C_ccall f_3163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3163,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_u_i_car(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t9=(C_word)C_a_i_cons(&a,2,t8,t3);
t10=(C_word)C_u_i_caddr(((C_word*)t0)[2]);
t11=(C_word)C_a_i_cons(&a,2,t10,t4);
t12=(C_word)C_u_i_cadddr(((C_word*)t0)[2]);
t13=(C_word)C_a_i_cons(&a,2,t12,t5);
/* srfi-1.scm: 679  values */
C_values(6,0,t1,t7,t9,t11,t13);}

/* a3152 in recur in unzip4 in k2058 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 678  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3135(t3,t1,t2);}

/* unzip3 in k2058 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3065,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3071,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3071(t6,t1,t2);}

/* recur in unzip3 in k2058 */
static void C_fcall f_3071(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3071,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 667  values */
C_values(5,0,t1,t2,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3089,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3099,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3098 in recur in unzip3 in k2058 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3099,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_u_i_car(((C_word*)t0)[2]);
t6=(C_word)C_a_i_cons(&a,2,t5,t2);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_i_caddr(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t9,t4);
/* srfi-1.scm: 670  values */
C_values(5,0,t1,t6,t8,t10);}

/* a3088 in recur in unzip3 in k2058 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 669  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3071(t3,t1,t2);}

/* unzip2 in k2058 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3009,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3015(t6,t1,t2);}

/* recur in unzip2 in k2058 */
static void C_fcall f_3015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3015,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* srfi-1.scm: 659  values */
C_values(4,0,t1,t2,t2);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3043,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3042 in recur in unzip2 in k2058 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3043,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t7=(C_word)C_a_i_cons(&a,2,t6,t3);
/* srfi-1.scm: 662  values */
C_values(4,0,t1,t5,t7);}

/* a3032 in recur in unzip2 in k2058 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 661  recur */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3015(t3,t1,t2);}

/* unzip1 in k2058 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3003,3,t0,t1,t2);}
/* map */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,*((C_word*)lf[23]+1),t2);}

/* last-pair in k2058 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2982,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2988,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2988(t2));}

/* lp in last-pair in k2058 */
static C_word C_fcall f_2988(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
t2=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t2))){
t4=t2;
t1=t4;
goto loop;}
else{
return(t1);}}

/* last in k2058 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2972,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2980,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-1.scm: 643  last-pair */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2978 in last in k2058 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_car(t1));}

/* split-at! in k2058 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2941,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[44]);
t5=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t5)){
/* srfi-1.scm: 636  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,t2);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2957,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* srfi-1.scm: 637  drop */
t8=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t2,t7);}}

/* k2955 in split-at! in k2058 */
static void C_ccall f_2957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_END_OF_LIST);
/* srfi-1.scm: 640  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* split-at in k2058 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2889,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[43]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2898,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2898(t8,t1,t2,t3);}

/* recur in split-at in k2058 */
static void C_fcall f_2898(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2898,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* srfi-1.scm: 629  values */
C_values(4,0,t1,C_SCHEME_END_OF_LIST,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2927,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a2926 in recur in split-at in k2058 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2927,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_car(((C_word*)t0)[2]);
t5=(C_word)C_a_i_cons(&a,2,t4,t2);
/* srfi-1.scm: 631  values */
C_values(4,0,t1,t5,t3);}

/* a2912 in recur in split-at in k2058 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* srfi-1.scm: 630  recur */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2898(t4,t1,t2,t3);}

/* drop-right! in k2058 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2847,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2851,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 570  drop */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2849 in drop-right! in k2058 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2851,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2866(t3,((C_word*)t0)[3],t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* lp in k2849 in drop-right! in k2058 */
static C_word C_fcall f_2866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(1));
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_END_OF_LIST);
return(((C_word*)t0)[2]);}}

/* drop-right in k2058 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2809,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2817,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 561  drop */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2815 in drop-right in k2058 */
static void C_ccall f_2817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2817,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2819,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2819(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* recur in k2815 in drop-right in k2058 */
static void C_fcall f_2819(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2819,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2837,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
/* srfi-1.scm: 563  recur */
t9=t5;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k2835 in recur in k2815 in drop-right in k2058 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2837,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* take-right in k2058 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2779,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2787,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 554  drop */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k2785 in take-right in k2058 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2789,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2789(((C_word*)t0)[2],t1));}

/* lp in k2785 in take-right in k2058 */
static C_word C_fcall f_2789(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_slot(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(t1);}}

/* take! in k2058 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2756,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[39]);
t5=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* srfi-1.scm: 545  drop */
t8=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t2,t7);}}

/* k2771 in take! in k2058 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_set_i_slot(t1,C_fix(1),C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* drop in k2058 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2727,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[38]);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2736,tmp=(C_word)a,a+=2,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_2736(t2,t3));}

/* iter in drop in k2058 */
static C_word C_fcall f_2736(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t3=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t3)){
return(t1);}
else{
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* take in k2058 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2690,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[37]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2699,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_2699(t8,t1,t2,t3);}

/* recur in take in k2058 */
static void C_fcall f_2699(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2699,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2717,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* srfi-1.scm: 533  recur */
t10=t6;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k2715 in recur in take in k2058 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* car+cdr in k2058 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2673,3,t0,t1,t2);}
t3=(C_word)C_i_check_pair_2(t2,lf[36]);
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 523  values */
C_values(4,0,t1,t4,t5);}

/* tenth in k2058 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2659,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=(C_word)C_u_i_cddddr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_cadr(t4));}

/* ninth in k2058 */
static void C_ccall f_2645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2645,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=(C_word)C_u_i_cddddr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u_i_car(t4));}

/* eighth in k2058 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2635,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_cadddr(t3));}

/* seventh in k2058 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2625,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_caddr(t3));}

/* sixth in k2058 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2615,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_cadr(t3));}

/* fifth in k2058 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2605,3,t0,t1,t2);}
t3=(C_word)C_u_i_cddddr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u_i_car(t3));}

/* zip in k2058 */
static void C_ccall f_2595(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2595r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2595r(t0,t1,t2,t3);}}

static void C_ccall f_2595r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_apply(6,0,t1,*((C_word*)lf[20]+1),*((C_word*)lf[21]+1),t2,t3);}

/* length+ in k2058 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2546,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2552,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2552(t2,t2,C_fix(0)));}

/* lp in length+ in k2058 */
static C_word C_fcall f_2552(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t4=(C_word)C_slot(t1,C_fix(1));
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t5,C_fix(1));
t9=(C_word)C_eqp(t6,t7);
if(C_truep(t9)){
return(C_SCHEME_FALSE);}
else{
t11=t6;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}
else{
return(t5);}}
else{
return(t3);}}

/* list= in k2058 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2446r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2446r(t0,t1,t2,t3);}}

static void C_ccall f_2446r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2466,a[2]=t2,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_2466(t10,t1,t5,t6);}}

/* lp1 in list= in k2058 */
static void C_fcall f_2466(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2466,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_eqp(t2,t5);
if(C_truep(t7)){
/* srfi-1.scm: 440  lp1 */
t12=t1;
t13=t5;
t14=t6;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t6,a[5]=t5,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2493(t11,t1,t2,t5);}}}

/* lp2 in lp1 in list= in k2058 */
static void C_fcall f_2493(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2493,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
/* srfi-1.scm: 444  lp1 */
t4=((C_word*)((C_word*)t0)[6])[1];
f_2466(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2521,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_car(t3);
/* srfi-1.scm: 446  = */
t7=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}}

/* k2519 in lp2 in lp1 in list= in k2058 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-1.scm: 447  lp2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2493(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* null-list? in k2058 */
static void C_ccall f_2443(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2443,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_null_list_p(t2));}

/* not-pair? in k2058 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2440,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not_pair_p(t2));}

/* circular-list? in k2058 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2401,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2407,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2407(t2,t2));}

/* lp in circular-list? in k2058 */
static C_word C_fcall f_2407(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
return(t6);}
else{
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* dotted-list? in k2058 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2344,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2350,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_2350(t2,t2));}

/* lp in dotted-list? in k2058 */
static C_word C_fcall f_2350(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,t5);
if(C_truep(t6)){
return(C_SCHEME_FALSE);}
else{
t10=t4;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=(C_word)C_i_nullp(t3);
return((C_word)C_i_not(t4));}}
else{
t3=(C_word)C_i_nullp(t1);
return((C_word)C_i_not(t3));}}

/* circular-list in k2058 */
static void C_ccall f_2330(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2330r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2330r(t0,t1,t2,t3);}}

static void C_ccall f_2330r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2341,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-1.scm: 377  last-pair */
t6=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2339 in circular-list in k2058 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(1),((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}

/* iota in k2058 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2220r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2220r(t0,t1,t2,t3);}}

static void C_ccall f_2220r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_number_2(t2,lf[7]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2227,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_lessp(t2,C_fix(0)))){
/* srfi-1.scm: 315  ##sys#error */
t6=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[7],lf[8],*((C_word*)lf[7]+1),t2);}
else{
t6=t5;
f_2227(2,t6,C_SCHEME_UNDEFINED);}}

/* k2225 in iota in k2058 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2274,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2279,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-start104135 */
t6=t5;
f_2279(t6,((C_word*)t0)[2]);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-step105131 */
t8=t4;
f_2274(t8,((C_word*)t0)[2],t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body102110 */
t10=t3;
f_2228(t10,((C_word*)t0)[2],t6,t8);}}}

/* def-start104 in k2225 in iota in k2058 */
static void C_fcall f_2279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2279,NULL,2,t0,t1);}
/* def-step105131 */
t2=((C_word*)t0)[2];
f_2274(t2,t1,C_fix(0));}

/* def-step105 in k2225 in iota in k2058 */
static void C_fcall f_2274(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2274,NULL,3,t0,t1,t2);}
/* body102110 */
t3=((C_word*)t0)[2];
f_2228(t3,t1,t2,C_fix(1));}

/* body102 in k2225 in iota in k2058 */
static void C_fcall f_2228(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2228,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t2,lf[7]);
t5=(C_word)C_i_check_number_2(t3,lf[7]);
t6=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[2],C_fix(1));
t7=(C_word)C_a_i_times(&a,2,t6,t3);
t8=(C_word)C_a_i_plus(&a,2,t2,t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2243,a[2]=t10,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_2243(t12,t1,((C_word*)t0)[2],t8,C_SCHEME_END_OF_LIST);}

/* doloop115 in body102 in k2225 in iota in k2058 */
static void C_fcall f_2243(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2243,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t6=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[3]);
t7=(C_word)C_a_i_cons(&a,2,t3,t4);
t9=t1;
t10=t5;
t11=t6;
t12=t7;
t1=t9;
t2=t10;
t3=t11;
t4=t12;
goto loop;}}

/* list-copy in k2058 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2190,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2196(t6,t1,t2);}

/* recur in list-copy in k2058 */
static void C_fcall f_2196(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2196,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2214,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
/* srfi-1.scm: 307  recur */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2212 in recur in list-copy in k2058 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* cons* in k2058 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2160r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2160r(t0,t1,t2,t3);}}

static void C_ccall f_2160r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2166(t7,t1,t2,t3);}

/* recur in cons* in k2058 */
static void C_fcall f_2166(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2166,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2180,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_slot(t3,C_fix(1));
/* srfi-1.scm: 299  recur */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2178 in recur in cons* in k2058 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* list-tabulate in k2058 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2123,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[4]);
t5=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2136,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_2136(t9,t1,t5,C_SCHEME_END_OF_LIST);}

/* doloop55 in list-tabulate in k2058 */
static void C_fcall f_2136(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2136,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2158,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* srfi-1.scm: 288  proc */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* k2156 in doloop55 in list-tabulate in k2058 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_2136(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* make-list in k2058 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2068r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2068r(t0,t1,t2,t3);}}

static void C_ccall f_2068r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t4=(C_word)C_i_check_exact_2(t2,lf[1]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2075,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_2075(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2075(2,t7,(C_word)C_u_i_car(t3));}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* srfi-1.scm: 271  ##sys#error */
t8=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[1],lf[3],t7);}}}

/* k2073 in make-list in k2058 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2080,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2080(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* doloop37 in k2073 in make-list in k2058 */
static void C_fcall f_2080(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2080,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t7=t1;
t8=t4;
t9=t5;
t1=t7;
t2=t8;
t3=t9;
goto loop;}}

/* xcons in k2058 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2062,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t3,t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[420] = {
{"toplevel:srfi_1_scm",(void*)C_srfi_1_toplevel},
{"f_2060:srfi_1_scm",(void*)f_2060},
{"f_6712:srfi_1_scm",(void*)f_6712},
{"f_6719:srfi_1_scm",(void*)f_6719},
{"f_6736:srfi_1_scm",(void*)f_6736},
{"f_6746:srfi_1_scm",(void*)f_6746},
{"f_6744:srfi_1_scm",(void*)f_6744},
{"f_6672:srfi_1_scm",(void*)f_6672},
{"f_6679:srfi_1_scm",(void*)f_6679},
{"f_6696:srfi_1_scm",(void*)f_6696},
{"f_6706:srfi_1_scm",(void*)f_6706},
{"f_6704:srfi_1_scm",(void*)f_6704},
{"f_6614:srfi_1_scm",(void*)f_6614},
{"f_6620:srfi_1_scm",(void*)f_6620},
{"f_6632:srfi_1_scm",(void*)f_6632},
{"f_6656:srfi_1_scm",(void*)f_6656},
{"f_6663:srfi_1_scm",(void*)f_6663},
{"f_6626:srfi_1_scm",(void*)f_6626},
{"f_6560:srfi_1_scm",(void*)f_6560},
{"f_6566:srfi_1_scm",(void*)f_6566},
{"f_6578:srfi_1_scm",(void*)f_6578},
{"f_6602:srfi_1_scm",(void*)f_6602},
{"f_6609:srfi_1_scm",(void*)f_6609},
{"f_6572:srfi_1_scm",(void*)f_6572},
{"f_6523:srfi_1_scm",(void*)f_6523},
{"f_6527:srfi_1_scm",(void*)f_6527},
{"f_6544:srfi_1_scm",(void*)f_6544},
{"f_6550:srfi_1_scm",(void*)f_6550},
{"f_6558:srfi_1_scm",(void*)f_6558},
{"f_6486:srfi_1_scm",(void*)f_6486},
{"f_6490:srfi_1_scm",(void*)f_6490},
{"f_6507:srfi_1_scm",(void*)f_6507},
{"f_6513:srfi_1_scm",(void*)f_6513},
{"f_6521:srfi_1_scm",(void*)f_6521},
{"f_6453:srfi_1_scm",(void*)f_6453},
{"f_6457:srfi_1_scm",(void*)f_6457},
{"f_6463:srfi_1_scm",(void*)f_6463},
{"f_6474:srfi_1_scm",(void*)f_6474},
{"f_6480:srfi_1_scm",(void*)f_6480},
{"f_6420:srfi_1_scm",(void*)f_6420},
{"f_6424:srfi_1_scm",(void*)f_6424},
{"f_6430:srfi_1_scm",(void*)f_6430},
{"f_6441:srfi_1_scm",(void*)f_6441},
{"f_6447:srfi_1_scm",(void*)f_6447},
{"f_6369:srfi_1_scm",(void*)f_6369},
{"f_6375:srfi_1_scm",(void*)f_6375},
{"f_6399:srfi_1_scm",(void*)f_6399},
{"f_6414:srfi_1_scm",(void*)f_6414},
{"f_6409:srfi_1_scm",(void*)f_6409},
{"f_6321:srfi_1_scm",(void*)f_6321},
{"f_6327:srfi_1_scm",(void*)f_6327},
{"f_6351:srfi_1_scm",(void*)f_6351},
{"f_6363:srfi_1_scm",(void*)f_6363},
{"f_6358:srfi_1_scm",(void*)f_6358},
{"f_6303:srfi_1_scm",(void*)f_6303},
{"f_6309:srfi_1_scm",(void*)f_6309},
{"f_6316:srfi_1_scm",(void*)f_6316},
{"f_6239:srfi_1_scm",(void*)f_6239},
{"f_6259:srfi_1_scm",(void*)f_6259},
{"f_6290:srfi_1_scm",(void*)f_6290},
{"f_6281:srfi_1_scm",(void*)f_6281},
{"f_6181:srfi_1_scm",(void*)f_6181},
{"f_6201:srfi_1_scm",(void*)f_6201},
{"f_6223:srfi_1_scm",(void*)f_6223},
{"f_6169:srfi_1_scm",(void*)f_6169},
{"f_6175:srfi_1_scm",(void*)f_6175},
{"f_6145:srfi_1_scm",(void*)f_6145},
{"f_6151:srfi_1_scm",(void*)f_6151},
{"f_6058:srfi_1_scm",(void*)f_6058},
{"f_6111:srfi_1_scm",(void*)f_6111},
{"f_6124:srfi_1_scm",(void*)f_6124},
{"f_6074:srfi_1_scm",(void*)f_6074},
{"f_6086:srfi_1_scm",(void*)f_6086},
{"f_6099:srfi_1_scm",(void*)f_6099},
{"f_6080:srfi_1_scm",(void*)f_6080},
{"f_5941:srfi_1_scm",(void*)f_5941},
{"f_6029:srfi_1_scm",(void*)f_6029},
{"f_6045:srfi_1_scm",(void*)f_6045},
{"f_5963:srfi_1_scm",(void*)f_5963},
{"f_5975:srfi_1_scm",(void*)f_5975},
{"f_5987:srfi_1_scm",(void*)f_5987},
{"f_6000:srfi_1_scm",(void*)f_6000},
{"f_5981:srfi_1_scm",(void*)f_5981},
{"f_5953:srfi_1_scm",(void*)f_5953},
{"f_5824:srfi_1_scm",(void*)f_5824},
{"f_5908:srfi_1_scm",(void*)f_5908},
{"f_5921:srfi_1_scm",(void*)f_5921},
{"f_5846:srfi_1_scm",(void*)f_5846},
{"f_5858:srfi_1_scm",(void*)f_5858},
{"f_5870:srfi_1_scm",(void*)f_5870},
{"f_5880:srfi_1_scm",(void*)f_5880},
{"f_5864:srfi_1_scm",(void*)f_5864},
{"f_5836:srfi_1_scm",(void*)f_5836},
{"f_5808:srfi_1_scm",(void*)f_5808},
{"f_5814:srfi_1_scm",(void*)f_5814},
{"f_5822:srfi_1_scm",(void*)f_5822},
{"f_5792:srfi_1_scm",(void*)f_5792},
{"f_5798:srfi_1_scm",(void*)f_5798},
{"f_5806:srfi_1_scm",(void*)f_5806},
{"f_5728:srfi_1_scm",(void*)f_5728},
{"f_5786:srfi_1_scm",(void*)f_5786},
{"f_5738:srfi_1_scm",(void*)f_5738},
{"f_5753:srfi_1_scm",(void*)f_5753},
{"f_5769:srfi_1_scm",(void*)f_5769},
{"f_5744:srfi_1_scm",(void*)f_5744},
{"f_5675:srfi_1_scm",(void*)f_5675},
{"f_5681:srfi_1_scm",(void*)f_5681},
{"f_5700:srfi_1_scm",(void*)f_5700},
{"f_5715:srfi_1_scm",(void*)f_5715},
{"f_5705:srfi_1_scm",(void*)f_5705},
{"f_5617:srfi_1_scm",(void*)f_5617},
{"f_5669:srfi_1_scm",(void*)f_5669},
{"f_5627:srfi_1_scm",(void*)f_5627},
{"f_5636:srfi_1_scm",(void*)f_5636},
{"f_5652:srfi_1_scm",(void*)f_5652},
{"f_5630:srfi_1_scm",(void*)f_5630},
{"f_5585:srfi_1_scm",(void*)f_5585},
{"f_5591:srfi_1_scm",(void*)f_5591},
{"f_5604:srfi_1_scm",(void*)f_5604},
{"f_5550:srfi_1_scm",(void*)f_5550},
{"f_5556:srfi_1_scm",(void*)f_5556},
{"f_5572:srfi_1_scm",(void*)f_5572},
{"f_5579:srfi_1_scm",(void*)f_5579},
{"f_5514:srfi_1_scm",(void*)f_5514},
{"f_5520:srfi_1_scm",(void*)f_5520},
{"f_5533:srfi_1_scm",(void*)f_5533},
{"f_5502:srfi_1_scm",(void*)f_5502},
{"f_5506:srfi_1_scm",(void*)f_5506},
{"f_5467:srfi_1_scm",(void*)f_5467},
{"f_5476:srfi_1_scm",(void*)f_5476},
{"f_5484:srfi_1_scm",(void*)f_5484},
{"f_5432:srfi_1_scm",(void*)f_5432},
{"f_5441:srfi_1_scm",(void*)f_5441},
{"f_5449:srfi_1_scm",(void*)f_5449},
{"f_5412:srfi_1_scm",(void*)f_5412},
{"f_5418:srfi_1_scm",(void*)f_5418},
{"f_5402:srfi_1_scm",(void*)f_5402},
{"f_5371:srfi_1_scm",(void*)f_5371},
{"f_5380:srfi_1_scm",(void*)f_5380},
{"f_5319:srfi_1_scm",(void*)f_5319},
{"f_5328:srfi_1_scm",(void*)f_5328},
{"f_5357:srfi_1_scm",(void*)f_5357},
{"f_5344:srfi_1_scm",(void*)f_5344},
{"f_5267:srfi_1_scm",(void*)f_5267},
{"f_5276:srfi_1_scm",(void*)f_5276},
{"f_5305:srfi_1_scm",(void*)f_5305},
{"f_5292:srfi_1_scm",(void*)f_5292},
{"f_5240:srfi_1_scm",(void*)f_5240},
{"f_5249:srfi_1_scm",(void*)f_5249},
{"f_5209:srfi_1_scm",(void*)f_5209},
{"f_5218:srfi_1_scm",(void*)f_5218},
{"f_5226:srfi_1_scm",(void*)f_5226},
{"f_5178:srfi_1_scm",(void*)f_5178},
{"f_5187:srfi_1_scm",(void*)f_5187},
{"f_5195:srfi_1_scm",(void*)f_5195},
{"f_5162:srfi_1_scm",(void*)f_5162},
{"f_5168:srfi_1_scm",(void*)f_5168},
{"f_5176:srfi_1_scm",(void*)f_5176},
{"f_5146:srfi_1_scm",(void*)f_5146},
{"f_5152:srfi_1_scm",(void*)f_5152},
{"f_5160:srfi_1_scm",(void*)f_5160},
{"f_4934:srfi_1_scm",(void*)f_4934},
{"f_5040:srfi_1_scm",(void*)f_5040},
{"f_5099:srfi_1_scm",(void*)f_5099},
{"f_5115:srfi_1_scm",(void*)f_5115},
{"f_5118:srfi_1_scm",(void*)f_5118},
{"f_5049:srfi_1_scm",(void*)f_5049},
{"f_5065:srfi_1_scm",(void*)f_5065},
{"f_5075:srfi_1_scm",(void*)f_5075},
{"f_4991:srfi_1_scm",(void*)f_4991},
{"f_4997:srfi_1_scm",(void*)f_4997},
{"f_5010:srfi_1_scm",(void*)f_5010},
{"f_4946:srfi_1_scm",(void*)f_4946},
{"f_4952:srfi_1_scm",(void*)f_4952},
{"f_4965:srfi_1_scm",(void*)f_4965},
{"f_4866:srfi_1_scm",(void*)f_4866},
{"f_4872:srfi_1_scm",(void*)f_4872},
{"f_4899:srfi_1_scm",(void*)f_4899},
{"f_4906:srfi_1_scm",(void*)f_4906},
{"f_4893:srfi_1_scm",(void*)f_4893},
{"f_4745:srfi_1_scm",(void*)f_4745},
{"f_4751:srfi_1_scm",(void*)f_4751},
{"f_4860:srfi_1_scm",(void*)f_4860},
{"f_4852:srfi_1_scm",(void*)f_4852},
{"f_4806:srfi_1_scm",(void*)f_4806},
{"f_4812:srfi_1_scm",(void*)f_4812},
{"f_4825:srfi_1_scm",(void*)f_4825},
{"f_4773:srfi_1_scm",(void*)f_4773},
{"f_4786:srfi_1_scm",(void*)f_4786},
{"f_4703:srfi_1_scm",(void*)f_4703},
{"f_4709:srfi_1_scm",(void*)f_4709},
{"f_4728:srfi_1_scm",(void*)f_4728},
{"f_4731:srfi_1_scm",(void*)f_4731},
{"f_4626:srfi_1_scm",(void*)f_4626},
{"f_4676:srfi_1_scm",(void*)f_4676},
{"f_4689:srfi_1_scm",(void*)f_4689},
{"f_4696:srfi_1_scm",(void*)f_4696},
{"f_4642:srfi_1_scm",(void*)f_4642},
{"f_4654:srfi_1_scm",(void*)f_4654},
{"f_4664:srfi_1_scm",(void*)f_4664},
{"f_4671:srfi_1_scm",(void*)f_4671},
{"f_4648:srfi_1_scm",(void*)f_4648},
{"f_4541:srfi_1_scm",(void*)f_4541},
{"f_4597:srfi_1_scm",(void*)f_4597},
{"f_4607:srfi_1_scm",(void*)f_4607},
{"f_4610:srfi_1_scm",(void*)f_4610},
{"f_4557:srfi_1_scm",(void*)f_4557},
{"f_4569:srfi_1_scm",(void*)f_4569},
{"f_4579:srfi_1_scm",(void*)f_4579},
{"f_4589:srfi_1_scm",(void*)f_4589},
{"f_4563:srfi_1_scm",(void*)f_4563},
{"f_4469:srfi_1_scm",(void*)f_4469},
{"f_4527:srfi_1_scm",(void*)f_4527},
{"f_4535:srfi_1_scm",(void*)f_4535},
{"f_4481:srfi_1_scm",(void*)f_4481},
{"f_4499:srfi_1_scm",(void*)f_4499},
{"f_4514:srfi_1_scm",(void*)f_4514},
{"f_4493:srfi_1_scm",(void*)f_4493},
{"f_3678:srfi_1_scm",(void*)f_3678},
{"f_3696:srfi_1_scm",(void*)f_3696},
{"f_3708:srfi_1_scm",(void*)f_3708},
{"f_3720:srfi_1_scm",(void*)f_3720},
{"f_3714:srfi_1_scm",(void*)f_3714},
{"f_3702:srfi_1_scm",(void*)f_3702},
{"f_3690:srfi_1_scm",(void*)f_3690},
{"f_4473:srfi_1_scm",(void*)f_4473},
{"f_4410:srfi_1_scm",(void*)f_4410},
{"f_4447:srfi_1_scm",(void*)f_4447},
{"f_4460:srfi_1_scm",(void*)f_4460},
{"f_4426:srfi_1_scm",(void*)f_4426},
{"f_4430:srfi_1_scm",(void*)f_4430},
{"f_4439:srfi_1_scm",(void*)f_4439},
{"f_4301:srfi_1_scm",(void*)f_4301},
{"f_4383:srfi_1_scm",(void*)f_4383},
{"f_4387:srfi_1_scm",(void*)f_4387},
{"f_4400:srfi_1_scm",(void*)f_4400},
{"f_4323:srfi_1_scm",(void*)f_4323},
{"f_4335:srfi_1_scm",(void*)f_4335},
{"f_4339:srfi_1_scm",(void*)f_4339},
{"f_4350:srfi_1_scm",(void*)f_4350},
{"f_4364:srfi_1_scm",(void*)f_4364},
{"f_4344:srfi_1_scm",(void*)f_4344},
{"f_4313:srfi_1_scm",(void*)f_4313},
{"f_4295:srfi_1_scm",(void*)f_4295},
{"f_4289:srfi_1_scm",(void*)f_4289},
{"f_4245:srfi_1_scm",(void*)f_4245},
{"f_4265:srfi_1_scm",(void*)f_4265},
{"f_4279:srfi_1_scm",(void*)f_4279},
{"f_4225:srfi_1_scm",(void*)f_4225},
{"f_4160:srfi_1_scm",(void*)f_4160},
{"f_4206:srfi_1_scm",(void*)f_4206},
{"f_4223:srfi_1_scm",(void*)f_4223},
{"f_4176:srfi_1_scm",(void*)f_4176},
{"f_4180:srfi_1_scm",(void*)f_4180},
{"f_4197:srfi_1_scm",(void*)f_4197},
{"f_4193:srfi_1_scm",(void*)f_4193},
{"f_4094:srfi_1_scm",(void*)f_4094},
{"f_4140:srfi_1_scm",(void*)f_4140},
{"f_4154:srfi_1_scm",(void*)f_4154},
{"f_4110:srfi_1_scm",(void*)f_4110},
{"f_4114:srfi_1_scm",(void*)f_4114},
{"f_4135:srfi_1_scm",(void*)f_4135},
{"f_4127:srfi_1_scm",(void*)f_4127},
{"f_4029:srfi_1_scm",(void*)f_4029},
{"f_4071:srfi_1_scm",(void*)f_4071},
{"f_4088:srfi_1_scm",(void*)f_4088},
{"f_4045:srfi_1_scm",(void*)f_4045},
{"f_4049:srfi_1_scm",(void*)f_4049},
{"f_4066:srfi_1_scm",(void*)f_4066},
{"f_3481:srfi_1_scm",(void*)f_3481},
{"f_3499:srfi_1_scm",(void*)f_3499},
{"f_4062:srfi_1_scm",(void*)f_4062},
{"f_3958:srfi_1_scm",(void*)f_3958},
{"f_4005:srfi_1_scm",(void*)f_4005},
{"f_4023:srfi_1_scm",(void*)f_4023},
{"f_3974:srfi_1_scm",(void*)f_3974},
{"f_3986:srfi_1_scm",(void*)f_3986},
{"f_4000:srfi_1_scm",(void*)f_4000},
{"f_3980:srfi_1_scm",(void*)f_3980},
{"f_3594:srfi_1_scm",(void*)f_3594},
{"f_3600:srfi_1_scm",(void*)f_3600},
{"f_3618:srfi_1_scm",(void*)f_3618},
{"f_3639:srfi_1_scm",(void*)f_3639},
{"f_3651:srfi_1_scm",(void*)f_3651},
{"f_3645:srfi_1_scm",(void*)f_3645},
{"f_3633:srfi_1_scm",(void*)f_3633},
{"f_3612:srfi_1_scm",(void*)f_3612},
{"f_3876:srfi_1_scm",(void*)f_3876},
{"f_3934:srfi_1_scm",(void*)f_3934},
{"f_3941:srfi_1_scm",(void*)f_3941},
{"f_3948:srfi_1_scm",(void*)f_3948},
{"f_3956:srfi_1_scm",(void*)f_3956},
{"f_3952:srfi_1_scm",(void*)f_3952},
{"f_3900:srfi_1_scm",(void*)f_3900},
{"f_3907:srfi_1_scm",(void*)f_3907},
{"f_3917:srfi_1_scm",(void*)f_3917},
{"f_3925:srfi_1_scm",(void*)f_3925},
{"f_3921:srfi_1_scm",(void*)f_3921},
{"f_3830:srfi_1_scm",(void*)f_3830},
{"f_3840:srfi_1_scm",(void*)f_3840},
{"f_3847:srfi_1_scm",(void*)f_3847},
{"f_3854:srfi_1_scm",(void*)f_3854},
{"f_3862:srfi_1_scm",(void*)f_3862},
{"f_3737:srfi_1_scm",(void*)f_3737},
{"f_3800:srfi_1_scm",(void*)f_3800},
{"f_3821:srfi_1_scm",(void*)f_3821},
{"f_3749:srfi_1_scm",(void*)f_3749},
{"f_3767:srfi_1_scm",(void*)f_3767},
{"f_3788:srfi_1_scm",(void*)f_3788},
{"f_3761:srfi_1_scm",(void*)f_3761},
{"f_3508:srfi_1_scm",(void*)f_3508},
{"f_3514:srfi_1_scm",(void*)f_3514},
{"f_3520:srfi_1_scm",(void*)f_3520},
{"f_3538:srfi_1_scm",(void*)f_3538},
{"f_3559:srfi_1_scm",(void*)f_3559},
{"f_3571:srfi_1_scm",(void*)f_3571},
{"f_3565:srfi_1_scm",(void*)f_3565},
{"f_3553:srfi_1_scm",(void*)f_3553},
{"f_3532:srfi_1_scm",(void*)f_3532},
{"f_3427:srfi_1_scm",(void*)f_3427},
{"f_3433:srfi_1_scm",(void*)f_3433},
{"f_3439:srfi_1_scm",(void*)f_3439},
{"f_3469:srfi_1_scm",(void*)f_3469},
{"f_3421:srfi_1_scm",(void*)f_3421},
{"f_3415:srfi_1_scm",(void*)f_3415},
{"f_3391:srfi_1_scm",(void*)f_3391},
{"f_3397:srfi_1_scm",(void*)f_3397},
{"f_3361:srfi_1_scm",(void*)f_3361},
{"f_3367:srfi_1_scm",(void*)f_3367},
{"f_3285:srfi_1_scm",(void*)f_3285},
{"f_3291:srfi_1_scm",(void*)f_3291},
{"f_3320:srfi_1_scm",(void*)f_3320},
{"f_3322:srfi_1_scm",(void*)f_3322},
{"f_3345:srfi_1_scm",(void*)f_3345},
{"f_3201:srfi_1_scm",(void*)f_3201},
{"f_3207:srfi_1_scm",(void*)f_3207},
{"f_3235:srfi_1_scm",(void*)f_3235},
{"f_3225:srfi_1_scm",(void*)f_3225},
{"f_3129:srfi_1_scm",(void*)f_3129},
{"f_3135:srfi_1_scm",(void*)f_3135},
{"f_3163:srfi_1_scm",(void*)f_3163},
{"f_3153:srfi_1_scm",(void*)f_3153},
{"f_3065:srfi_1_scm",(void*)f_3065},
{"f_3071:srfi_1_scm",(void*)f_3071},
{"f_3099:srfi_1_scm",(void*)f_3099},
{"f_3089:srfi_1_scm",(void*)f_3089},
{"f_3009:srfi_1_scm",(void*)f_3009},
{"f_3015:srfi_1_scm",(void*)f_3015},
{"f_3043:srfi_1_scm",(void*)f_3043},
{"f_3033:srfi_1_scm",(void*)f_3033},
{"f_3003:srfi_1_scm",(void*)f_3003},
{"f_2982:srfi_1_scm",(void*)f_2982},
{"f_2988:srfi_1_scm",(void*)f_2988},
{"f_2972:srfi_1_scm",(void*)f_2972},
{"f_2980:srfi_1_scm",(void*)f_2980},
{"f_2941:srfi_1_scm",(void*)f_2941},
{"f_2957:srfi_1_scm",(void*)f_2957},
{"f_2889:srfi_1_scm",(void*)f_2889},
{"f_2898:srfi_1_scm",(void*)f_2898},
{"f_2927:srfi_1_scm",(void*)f_2927},
{"f_2913:srfi_1_scm",(void*)f_2913},
{"f_2847:srfi_1_scm",(void*)f_2847},
{"f_2851:srfi_1_scm",(void*)f_2851},
{"f_2866:srfi_1_scm",(void*)f_2866},
{"f_2809:srfi_1_scm",(void*)f_2809},
{"f_2817:srfi_1_scm",(void*)f_2817},
{"f_2819:srfi_1_scm",(void*)f_2819},
{"f_2837:srfi_1_scm",(void*)f_2837},
{"f_2779:srfi_1_scm",(void*)f_2779},
{"f_2787:srfi_1_scm",(void*)f_2787},
{"f_2789:srfi_1_scm",(void*)f_2789},
{"f_2756:srfi_1_scm",(void*)f_2756},
{"f_2773:srfi_1_scm",(void*)f_2773},
{"f_2727:srfi_1_scm",(void*)f_2727},
{"f_2736:srfi_1_scm",(void*)f_2736},
{"f_2690:srfi_1_scm",(void*)f_2690},
{"f_2699:srfi_1_scm",(void*)f_2699},
{"f_2717:srfi_1_scm",(void*)f_2717},
{"f_2673:srfi_1_scm",(void*)f_2673},
{"f_2659:srfi_1_scm",(void*)f_2659},
{"f_2645:srfi_1_scm",(void*)f_2645},
{"f_2635:srfi_1_scm",(void*)f_2635},
{"f_2625:srfi_1_scm",(void*)f_2625},
{"f_2615:srfi_1_scm",(void*)f_2615},
{"f_2605:srfi_1_scm",(void*)f_2605},
{"f_2595:srfi_1_scm",(void*)f_2595},
{"f_2546:srfi_1_scm",(void*)f_2546},
{"f_2552:srfi_1_scm",(void*)f_2552},
{"f_2446:srfi_1_scm",(void*)f_2446},
{"f_2466:srfi_1_scm",(void*)f_2466},
{"f_2493:srfi_1_scm",(void*)f_2493},
{"f_2521:srfi_1_scm",(void*)f_2521},
{"f_2443:srfi_1_scm",(void*)f_2443},
{"f_2440:srfi_1_scm",(void*)f_2440},
{"f_2401:srfi_1_scm",(void*)f_2401},
{"f_2407:srfi_1_scm",(void*)f_2407},
{"f_2344:srfi_1_scm",(void*)f_2344},
{"f_2350:srfi_1_scm",(void*)f_2350},
{"f_2330:srfi_1_scm",(void*)f_2330},
{"f_2341:srfi_1_scm",(void*)f_2341},
{"f_2220:srfi_1_scm",(void*)f_2220},
{"f_2227:srfi_1_scm",(void*)f_2227},
{"f_2279:srfi_1_scm",(void*)f_2279},
{"f_2274:srfi_1_scm",(void*)f_2274},
{"f_2228:srfi_1_scm",(void*)f_2228},
{"f_2243:srfi_1_scm",(void*)f_2243},
{"f_2190:srfi_1_scm",(void*)f_2190},
{"f_2196:srfi_1_scm",(void*)f_2196},
{"f_2214:srfi_1_scm",(void*)f_2214},
{"f_2160:srfi_1_scm",(void*)f_2160},
{"f_2166:srfi_1_scm",(void*)f_2166},
{"f_2180:srfi_1_scm",(void*)f_2180},
{"f_2123:srfi_1_scm",(void*)f_2123},
{"f_2136:srfi_1_scm",(void*)f_2136},
{"f_2158:srfi_1_scm",(void*)f_2158},
{"f_2068:srfi_1_scm",(void*)f_2068},
{"f_2075:srfi_1_scm",(void*)f_2075},
{"f_2080:srfi_1_scm",(void*)f_2080},
{"f_2062:srfi_1_scm",(void*)f_2062},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
