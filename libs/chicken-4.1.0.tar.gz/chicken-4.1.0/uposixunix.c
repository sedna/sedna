/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:35
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: posixunix.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file uposixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[465];
static double C_possibly_force_alignment;


/* from k8930 in set-root-directory! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub3164(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3164(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from sleep in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub2712(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2712(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub2707(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2707(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub2703(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2703(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub2547(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2547(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k7897 */
static C_word C_fcall stub2538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub2532(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2532(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k7889 */
static C_word C_fcall stub2523(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2523(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from f_7874 in k7868 in process-fork in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub2509(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2509(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub2491(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2491(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2405(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2405(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7689 */
static C_word C_fcall stub2376(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2376(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from ttyname */
static C_word C_fcall stub2361(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2361(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from set-alarm! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub2312(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2312(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from ex0 */
static C_word C_fcall stub2303(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2303(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2295(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2295(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub2256(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2256(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub2214(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2214(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub2206(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2206(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub2190(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2190(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7276 */
static C_word C_fcall stub2143(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2143(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k7218 */
static C_word C_fcall stub2104(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub2104(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from get */
static C_word C_fcall stub2055(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2055(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k5910 in k5906 in file-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1468(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1468(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5651 in initialize-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1293(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1293(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from _ensure-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1234(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1234(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from _get-groups */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1228(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1228(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from group-member */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1186(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1186(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a8997 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1134(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1134(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a9015 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1125(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1125(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a9033 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1116(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1116(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a9051 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1107(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1107(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from fd_test in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from fd_set in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from fd_zero in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from fcntl */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from ##sys#file-select-one in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub46(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from ##sys#file-nonblocking! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub40(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub40(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from strerror */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9076)
static void C_ccall f_9076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9080)
static void C_ccall f_9080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9083)
static void C_ccall f_9083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9070)
static void C_ccall f_9070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5300)
static void C_ccall f_5300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9055)
static void C_ccall f_9055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9065)
static void C_ccall f_9065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9052)
static void C_ccall f_9052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5342)
static void C_ccall f_5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9047)
static void C_ccall f_9047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9029)
static void C_ccall f_9029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9001)
static void C_ccall f_9001(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9011)
static void C_ccall f_9011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5354)
static void C_ccall f_5354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8977)
static void C_ccall f_8977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8959)
static void C_ccall f_8959(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8966)
static void C_ccall f_8966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8936)
static void C_ccall f_8936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8932)
static void C_ccall f_8932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8684)
static void C_ccall f_8684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_8861)
static void C_fcall f_8861(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8867)
static void C_ccall f_8867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8856)
static void C_fcall f_8856(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8851)
static void C_fcall f_8851(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8686)
static void C_fcall f_8686(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8838)
static void C_ccall f_8838(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8846)
static void C_ccall f_8846(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8693)
static void C_fcall f_8693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8826)
static void C_ccall f_8826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8820)
static void C_ccall f_8820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8705)
static void C_fcall f_8705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8806)
static void C_ccall f_8806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8813)
static void C_ccall f_8813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8800)
static void C_ccall f_8800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8793)
static void C_ccall f_8793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8790)
static void C_ccall f_8790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8780)
static void C_ccall f_8780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8764)
static void C_ccall f_8764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8771)
static void C_ccall f_8771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8768)
static void C_ccall f_8768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8749)
static void C_ccall f_8749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8827)
static void C_ccall f_8827(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8627)
static void C_ccall f_8627(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8627)
static void C_ccall f_8627r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8639)
static void C_fcall f_8639(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8634)
static void C_fcall f_8634(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8629)
static void C_fcall f_8629(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8582)
static void C_fcall f_8582(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8577)
static void C_fcall f_8577(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8572)
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8509)
static void C_fcall f_8509(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8564)
static void C_ccall f_8564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8530)
static void C_ccall f_8530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8533)
static void C_ccall f_8533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8538)
static void C_ccall f_8538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8511)
static void C_fcall f_8511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8520)
static void C_ccall f_8520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8451)
static void C_ccall f_8451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8463)
static void C_ccall f_8463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8494)
static void C_ccall f_8494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8474)
static void C_ccall f_8474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8490)
static void C_ccall f_8490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8478)
static void C_ccall f_8478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8486)
static void C_ccall f_8486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8457)
static void C_ccall f_8457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8440)
static void C_fcall f_8440(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8444)
static void C_ccall f_8444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8429)
static void C_fcall f_8429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8433)
static void C_ccall f_8433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8384)
static void C_fcall f_8384(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8388)
static void C_ccall f_8388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8391)
static void C_ccall f_8391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8394)
static void C_ccall f_8394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8407)
static void C_ccall f_8407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8414)
static void C_ccall f_8414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8417)
static void C_ccall f_8417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8405)
static void C_ccall f_8405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8368)
static C_word C_fcall f_8368(C_word *a,C_word t0);
C_noret_decl(f_8351)
static void C_fcall f_8351(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8364)
static void C_ccall f_8364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8276)
static void C_ccall f_8276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8337)
static void C_fcall f_8337(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8317)
static void C_fcall f_8317(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8332)
static void C_ccall f_8332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8326)
static void C_ccall f_8326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8280)
static void C_fcall f_8280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8282)
static void C_ccall f_8282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8297)
static void C_ccall f_8297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8224)
static void C_ccall f_8224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8224)
static void C_ccall f_8224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8250)
static void C_ccall f_8250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8209)
static void C_ccall f_8209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8176)
static void C_ccall f_8176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8173)
static void C_ccall f_8173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8098)
static void C_ccall f_8098(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8098)
static void C_ccall f_8098r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8125)
static void C_ccall f_8125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8036)
static void C_fcall f_8036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8031)
static void C_fcall f_8031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7904)
static void C_fcall f_7904(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7914)
static void C_ccall f_7914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7922)
static void C_fcall f_7922(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7968)
static C_word C_fcall f_7968(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7935)
static void C_fcall f_7935(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_ccall f_7960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7938)
static void C_ccall f_7938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7894)
static C_word C_fcall f_7894(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7886)
static C_word C_fcall f_7886(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_7848)
static void C_ccall f_7848(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7848)
static void C_ccall f_7848r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7739)
static void C_ccall f_7739r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7745)
static void C_fcall f_7745(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7766)
static void C_ccall f_7766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7840)
static void C_ccall f_7840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7770)
static void C_ccall f_7770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7773)
static void C_ccall f_7773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7780)
static void C_ccall f_7780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7782)
static void C_fcall f_7782(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7799)
static void C_ccall f_7799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7809)
static void C_ccall f_7809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7813)
static void C_ccall f_7813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7760)
static void C_ccall f_7760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_ccall f_7734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7716)
static void C_ccall f_7716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7720)
static void C_ccall f_7720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7673)
static void C_ccall f_7673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7646)
static void C_fcall f_7646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7650)
static void C_ccall f_7650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7627)
static void C_ccall f_7627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7634)
static void C_ccall f_7634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7568)
static void C_ccall f_7568r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7578)
static void C_ccall f_7578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7565)
static void C_ccall f_7565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7549)
static void C_ccall f_7549r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7541)
static void C_ccall f_7541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7526)
static void C_ccall f_7526(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7511)
static void C_ccall f_7511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7472)
static void C_ccall f_7472r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7489)
static void C_ccall f_7489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7417)
static void C_ccall f_7417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7436)
static void C_ccall f_7436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7374)
static void C_ccall f_7374(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7351)
static void C_ccall f_7351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7332)
static void C_fcall f_7332(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7326)
static void C_ccall f_7326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_7224)
static void C_ccall f_7224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_7228)
static void C_ccall f_7228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7240)
static void C_ccall f_7240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7146)
static void C_fcall f_7146(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7150)
static void C_ccall f_7150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_fcall f_7158(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7184)
static void C_ccall f_7184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7188)
static void C_ccall f_7188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7176)
static void C_ccall f_7176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7133)
static void C_ccall f_7133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7108)
static void C_ccall f_7108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7119)
static void C_ccall f_7119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7123)
static void C_ccall f_7123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7046)
static void C_fcall f_7046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7011)
static void C_ccall f_7011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6989)
static void C_ccall f_6989r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6978)
static void C_ccall f_6978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6959)
static void C_ccall f_6959r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6963)
static void C_ccall f_6963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6941)
static void C_fcall f_6941(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6870)
static void C_fcall f_6870(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6889)
static void C_ccall f_6889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_fcall f_6895(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6831)
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6859)
static void C_ccall f_6859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6848)
static void C_ccall f_6848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6575)
static void C_ccall f_6575r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6771)
static void C_fcall f_6771(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6766)
static void C_fcall f_6766(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6761)
static void C_fcall f_6761(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6577)
static void C_fcall f_6577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6581)
static void C_ccall f_6581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6688)
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6705)
static void C_fcall f_6705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6715)
static void C_ccall f_6715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6629)
static void C_fcall f_6629(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6654)
static void C_ccall f_6654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6636)
static void C_ccall f_6636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6583)
static void C_fcall f_6583(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6599)
static void C_ccall f_6599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6096)
static void C_ccall f_6096r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6500)
static void C_fcall f_6500(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_fcall f_6495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6490)
static void C_fcall f_6490(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6485)
static void C_fcall f_6485(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6098)
static void C_fcall f_6098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6102)
static void C_ccall f_6102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6358)
static void C_ccall f_6358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6364)
static void C_fcall f_6364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6450)
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6366)
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6373)
static void C_ccall f_6373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6383)
static void C_ccall f_6383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6290)
static void C_fcall f_6290(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6292)
static void C_fcall f_6292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6340)
static void C_ccall f_6340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6273)
static void C_ccall f_6273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6252)
static void C_ccall f_6252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6231)
static void C_ccall f_6231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6225)
static void C_ccall f_6225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_fcall f_6140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6152)
static void C_fcall f_6152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6168)
static void C_ccall f_6168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6132)
static C_word C_fcall f_6132(C_word t0);
C_noret_decl(f_6109)
static void C_fcall f_6109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6069)
static void C_ccall f_6069r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6076)
static void C_fcall f_6076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6024)
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_ccall f_6063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6046)
static void C_ccall f_6046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_fcall f_5981(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5944)
static void C_fcall f_5944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5912)
static void C_ccall f_5912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5901)
static void C_ccall f_5901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5860)
static void C_ccall f_5860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5778)
static void C_fcall f_5778(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5772)
static void C_ccall f_5772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5746)
static void C_ccall f_5746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5742)
static void C_ccall f_5742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5657)
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5653)
static void C_ccall f_5653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5591)
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_fcall f_5600(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5528)
static void C_ccall f_5528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_fcall f_5543(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static C_word C_fcall f_5525(C_word t0);
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_fcall f_5457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_fcall f_5480(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5475)
static void C_ccall f_5475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5356)
static void C_ccall f_5356r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_fcall f_5363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5373)
static void C_ccall f_5373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_ccall f_5302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5335)
static void C_ccall f_5335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5284)
static void C_ccall f_5284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5237)
static void C_fcall f_5237(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5124)
static void C_ccall f_5124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5090)
static void C_ccall f_5090r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5060)
static void C_ccall f_5060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5075)
static void C_ccall f_5075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5065)
static void C_ccall f_5065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4980)
static void C_ccall f_4980r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_fcall f_4929(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_fcall f_4923(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static C_word C_fcall f_4911(C_word t0);
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4901)
static void C_ccall f_4901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_fcall f_4721(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4876)
static void C_ccall f_4876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_fcall f_4784(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4837)
static void C_ccall f_4837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4765)
static void C_ccall f_4765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_fcall f_4610(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4681)
static void C_ccall f_4681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4690)
static void C_ccall f_4690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4678)
static void C_fcall f_4678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4655)
static void C_ccall f_4655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_fcall f_4538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static C_word C_fcall f_4527(C_word t0);
C_noret_decl(f_4522)
static void C_fcall f_4522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4481)
static void C_ccall f_4481r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4409)
static void C_fcall f_4409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_fcall f_4404(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4306)
static void C_fcall f_4306(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_fcall f_4337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4350)
static void C_ccall f_4350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_fcall f_4359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4369)
static void C_ccall f_4369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4181)
static void C_ccall f_4181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4187)
static void C_ccall f_4187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4118)
static void C_ccall f_4118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4096)
static void C_ccall f_4096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4078)
static void C_ccall f_4078(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3998)
static void C_ccall f_3998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_fcall f_3924(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3956)
static void C_ccall f_3956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_fcall f_3757(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_fcall f_3796(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_fcall f_3800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static C_word C_fcall f_3730(C_word t0,C_word t1);
C_noret_decl(f_3728)
static C_word C_fcall f_3728(C_word t0,C_word t1);
C_noret_decl(f_3726)
static C_word C_fcall f_3726(C_word t0);
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3577)
static void C_ccall f_3577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8861)
static void C_fcall trf_8861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8861(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8861(t0,t1);}

C_noret_decl(trf_8856)
static void C_fcall trf_8856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8856(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8856(t0,t1,t2);}

C_noret_decl(trf_8851)
static void C_fcall trf_8851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8851(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8851(t0,t1,t2,t3);}

C_noret_decl(trf_8686)
static void C_fcall trf_8686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8686(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8686(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8693)
static void C_fcall trf_8693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8693(t0,t1);}

C_noret_decl(trf_8705)
static void C_fcall trf_8705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8705(t0,t1,t2,t3);}

C_noret_decl(trf_8639)
static void C_fcall trf_8639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8639(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8639(t0,t1);}

C_noret_decl(trf_8634)
static void C_fcall trf_8634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8634(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8634(t0,t1,t2);}

C_noret_decl(trf_8629)
static void C_fcall trf_8629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8629(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8629(t0,t1,t2,t3);}

C_noret_decl(trf_8582)
static void C_fcall trf_8582(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8582(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8582(t0,t1);}

C_noret_decl(trf_8577)
static void C_fcall trf_8577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8577(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8577(t0,t1,t2);}

C_noret_decl(trf_8572)
static void C_fcall trf_8572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8572(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8572(t0,t1,t2,t3);}

C_noret_decl(trf_8509)
static void C_fcall trf_8509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8509(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8509(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8511)
static void C_fcall trf_8511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8511(t0,t1,t2);}

C_noret_decl(trf_8440)
static void C_fcall trf_8440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8440(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8440(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8429)
static void C_fcall trf_8429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8429(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8429(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8384)
static void C_fcall trf_8384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8384(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8384(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8351)
static void C_fcall trf_8351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8351(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8351(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8337)
static void C_fcall trf_8337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8337(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8337(t0,t1,t2,t3);}

C_noret_decl(trf_8317)
static void C_fcall trf_8317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8317(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8317(t0,t1,t2);}

C_noret_decl(trf_8280)
static void C_fcall trf_8280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8280(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8280(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8036)
static void C_fcall trf_8036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8036(t0,t1);}

C_noret_decl(trf_8031)
static void C_fcall trf_8031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8031(t0,t1,t2);}

C_noret_decl(trf_7904)
static void C_fcall trf_7904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7904(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7904(t0,t1,t2,t3);}

C_noret_decl(trf_7922)
static void C_fcall trf_7922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7922(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7922(t0,t1,t2,t3);}

C_noret_decl(trf_7935)
static void C_fcall trf_7935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7935(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7935(t0,t1);}

C_noret_decl(trf_7745)
static void C_fcall trf_7745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7745(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7745(t0,t1,t2);}

C_noret_decl(trf_7782)
static void C_fcall trf_7782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7782(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7782(t0,t1,t2);}

C_noret_decl(trf_7646)
static void C_fcall trf_7646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7646(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7646(t0,t1,t2);}

C_noret_decl(trf_7332)
static void C_fcall trf_7332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7332(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7332(t0,t1,t2);}

C_noret_decl(trf_7146)
static void C_fcall trf_7146(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7146(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7146(t0,t1,t2);}

C_noret_decl(trf_7158)
static void C_fcall trf_7158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7158(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7158(t0,t1,t2);}

C_noret_decl(trf_7046)
static void C_fcall trf_7046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7046(t0,t1);}

C_noret_decl(trf_6941)
static void C_fcall trf_6941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6941(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6941(t0,t1,t2,t3);}

C_noret_decl(trf_6870)
static void C_fcall trf_6870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6870(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6870(t0,t1,t2,t3);}

C_noret_decl(trf_6895)
static void C_fcall trf_6895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6895(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6895(t0,t1);}

C_noret_decl(trf_6771)
static void C_fcall trf_6771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6771(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6771(t0,t1);}

C_noret_decl(trf_6766)
static void C_fcall trf_6766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6766(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6766(t0,t1,t2);}

C_noret_decl(trf_6761)
static void C_fcall trf_6761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6761(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6761(t0,t1,t2,t3);}

C_noret_decl(trf_6577)
static void C_fcall trf_6577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6577(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6577(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6705)
static void C_fcall trf_6705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6705(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6705(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6629)
static void C_fcall trf_6629(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6629(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6629(t0,t1);}

C_noret_decl(trf_6583)
static void C_fcall trf_6583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6583(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6583(t0,t1,t2,t3);}

C_noret_decl(trf_6500)
static void C_fcall trf_6500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6500(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6500(t0,t1);}

C_noret_decl(trf_6495)
static void C_fcall trf_6495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6495(t0,t1,t2);}

C_noret_decl(trf_6490)
static void C_fcall trf_6490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6490(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6490(t0,t1,t2,t3);}

C_noret_decl(trf_6485)
static void C_fcall trf_6485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6485(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6485(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6098)
static void C_fcall trf_6098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6098(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6098(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6364)
static void C_fcall trf_6364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6364(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6364(t0,t1,t2);}

C_noret_decl(trf_6290)
static void C_fcall trf_6290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6290(t0,t1);}

C_noret_decl(trf_6292)
static void C_fcall trf_6292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6292(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6292(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6140)
static void C_fcall trf_6140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6140(t0,t1);}

C_noret_decl(trf_6152)
static void C_fcall trf_6152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6152(t0,t1);}

C_noret_decl(trf_6109)
static void C_fcall trf_6109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6109(t0,t1);}

C_noret_decl(trf_6076)
static void C_fcall trf_6076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6076(t0,t1);}

C_noret_decl(trf_5981)
static void C_fcall trf_5981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5981(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5981(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5944)
static void C_fcall trf_5944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5944(t0,t1,t2);}

C_noret_decl(trf_5778)
static void C_fcall trf_5778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5778(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5778(t0,t1,t2,t3);}

C_noret_decl(trf_5600)
static void C_fcall trf_5600(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5600(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5600(t0,t1,t2,t3);}

C_noret_decl(trf_5543)
static void C_fcall trf_5543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5543(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5543(t0,t1,t2);}

C_noret_decl(trf_5457)
static void C_fcall trf_5457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5457(t0,t1);}

C_noret_decl(trf_5480)
static void C_fcall trf_5480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5480(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5480(t0,t1,t2);}

C_noret_decl(trf_5363)
static void C_fcall trf_5363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5363(t0,t1);}

C_noret_decl(trf_5237)
static void C_fcall trf_5237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5237(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5237(t0,t1,t2,t3);}

C_noret_decl(trf_4929)
static void C_fcall trf_4929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4929(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4929(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4923)
static void C_fcall trf_4923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4923(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4923(t0,t1);}

C_noret_decl(trf_4721)
static void C_fcall trf_4721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4721(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4721(t0,t1);}

C_noret_decl(trf_4740)
static void C_fcall trf_4740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4740(t0,t1);}

C_noret_decl(trf_4784)
static void C_fcall trf_4784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4784(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4784(t0,t1);}

C_noret_decl(trf_4610)
static void C_fcall trf_4610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4610(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4610(t0,t1,t2,t3);}

C_noret_decl(trf_4678)
static void C_fcall trf_4678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4678(t0,t1);}

C_noret_decl(trf_4538)
static void C_fcall trf_4538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4538(t0,t1);}

C_noret_decl(trf_4522)
static void C_fcall trf_4522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4522(t0,t1);}

C_noret_decl(trf_4409)
static void C_fcall trf_4409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4409(t0,t1);}

C_noret_decl(trf_4404)
static void C_fcall trf_4404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4404(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4404(t0,t1,t2);}

C_noret_decl(trf_4306)
static void C_fcall trf_4306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4306(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4306(t0,t1,t2,t3);}

C_noret_decl(trf_4337)
static void C_fcall trf_4337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4337(t0,t1);}

C_noret_decl(trf_4359)
static void C_fcall trf_4359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4359(t0,t1);}

C_noret_decl(trf_3924)
static void C_fcall trf_3924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3924(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3924(t0,t1,t2,t3);}

C_noret_decl(trf_3757)
static void C_fcall trf_3757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3757(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3757(t0,t1);}

C_noret_decl(trf_3796)
static void C_fcall trf_3796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3796(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3796(t0,t1);}

C_noret_decl(trf_3800)
static void C_fcall trf_3800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3800(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3360)){
C_save(t1);
C_rereclaim2(3360*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,465);
lf[0]=C_h_intern(&lf[0],13,"string-append");
lf[2]=C_h_intern(&lf[2],15,"\003syssignal-hook");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[4]=C_h_intern(&lf[4],17,"\003syspeek-c-string");
lf[5]=C_h_intern(&lf[5],16,"\003sysupdate-errno");
lf[6]=C_h_intern(&lf[6],15,"\003sysposix-error");
lf[7]=C_h_intern(&lf[7],21,"\003sysfile-nonblocking!");
lf[8]=C_h_intern(&lf[8],19,"\003sysfile-select-one");
lf[9]=C_h_intern(&lf[9],8,"pipe/buf");
lf[10]=C_h_intern(&lf[10],11,"fcntl/dupfd");
lf[11]=C_h_intern(&lf[11],11,"fcntl/getfd");
lf[12]=C_h_intern(&lf[12],11,"fcntl/setfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfl");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfl");
lf[15]=C_h_intern(&lf[15],11,"open/rdonly");
lf[16]=C_h_intern(&lf[16],11,"open/wronly");
lf[17]=C_h_intern(&lf[17],9,"open/rdwr");
lf[18]=C_h_intern(&lf[18],9,"open/read");
lf[19]=C_h_intern(&lf[19],10,"open/write");
lf[20]=C_h_intern(&lf[20],10,"open/creat");
lf[21]=C_h_intern(&lf[21],11,"open/append");
lf[22]=C_h_intern(&lf[22],9,"open/excl");
lf[23]=C_h_intern(&lf[23],11,"open/noctty");
lf[24]=C_h_intern(&lf[24],13,"open/nonblock");
lf[25]=C_h_intern(&lf[25],10,"open/trunc");
lf[26]=C_h_intern(&lf[26],9,"open/sync");
lf[27]=C_h_intern(&lf[27],10,"open/fsync");
lf[28]=C_h_intern(&lf[28],11,"open/binary");
lf[29]=C_h_intern(&lf[29],9,"open/text");
lf[30]=C_h_intern(&lf[30],10,"perm/irusr");
lf[31]=C_h_intern(&lf[31],10,"perm/iwusr");
lf[32]=C_h_intern(&lf[32],10,"perm/ixusr");
lf[33]=C_h_intern(&lf[33],10,"perm/irgrp");
lf[34]=C_h_intern(&lf[34],10,"perm/iwgrp");
lf[35]=C_h_intern(&lf[35],10,"perm/ixgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iroth");
lf[37]=C_h_intern(&lf[37],10,"perm/iwoth");
lf[38]=C_h_intern(&lf[38],10,"perm/ixoth");
lf[39]=C_h_intern(&lf[39],10,"perm/irwxu");
lf[40]=C_h_intern(&lf[40],10,"perm/irwxg");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxo");
lf[42]=C_h_intern(&lf[42],10,"perm/isvtx");
lf[43]=C_h_intern(&lf[43],10,"perm/isuid");
lf[44]=C_h_intern(&lf[44],10,"perm/isgid");
lf[45]=C_h_intern(&lf[45],12,"file-control");
lf[46]=C_h_intern(&lf[46],11,"\000file-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[48]=C_h_intern(&lf[48],9,"file-open");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[50]=C_h_intern(&lf[50],17,"\003sysmake-c-string");
lf[51]=C_h_intern(&lf[51],20,"\003sysexpand-home-path");
lf[52]=C_h_intern(&lf[52],10,"file-close");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[54]=C_h_intern(&lf[54],11,"make-string");
lf[55]=C_h_intern(&lf[55],9,"file-read");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[57]=C_h_intern(&lf[57],11,"\000type-error");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[59]=C_h_intern(&lf[59],10,"file-write");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],12,"file-mkstemp");
lf[63]=C_h_intern(&lf[63],13,"\003syssubstring");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[65]=C_h_intern(&lf[65],11,"file-select");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[67]=C_h_intern(&lf[67],12,"\003sysfor-each");
lf[68]=C_h_intern(&lf[68],8,"seek/set");
lf[69]=C_h_intern(&lf[69],8,"seek/end");
lf[70]=C_h_intern(&lf[70],8,"seek/cur");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[74]=C_h_intern(&lf[74],9,"file-stat");
lf[75]=C_h_intern(&lf[75],9,"file-size");
lf[76]=C_h_intern(&lf[76],22,"file-modification-time");
lf[77]=C_h_intern(&lf[77],16,"file-access-time");
lf[78]=C_h_intern(&lf[78],16,"file-change-time");
lf[79]=C_h_intern(&lf[79],10,"file-owner");
lf[80]=C_h_intern(&lf[80],16,"file-permissions");
lf[81]=C_h_intern(&lf[81],13,"regular-file\077");
lf[82]=C_h_intern(&lf[82],14,"symbolic-link\077");
lf[83]=C_h_intern(&lf[83],13,"stat-regular\077");
lf[84]=C_h_intern(&lf[84],15,"stat-directory\077");
lf[85]=C_h_intern(&lf[85],17,"character-device\077");
lf[86]=C_h_intern(&lf[86],17,"stat-char-device\077");
lf[87]=C_h_intern(&lf[87],13,"block-device\077");
lf[88]=C_h_intern(&lf[88],18,"stat-block-device\077");
lf[89]=C_h_intern(&lf[89],5,"fifo\077");
lf[90]=C_h_intern(&lf[90],10,"stat-fifo\077");
lf[91]=C_h_intern(&lf[91],13,"stat-symlink\077");
lf[92]=C_h_intern(&lf[92],7,"socket\077");
lf[93]=C_h_intern(&lf[93],12,"stat-socket\077");
lf[94]=C_h_intern(&lf[94],18,"set-file-position!");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[96]=C_h_intern(&lf[96],6,"stream");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[98]=C_h_intern(&lf[98],5,"port\077");
lf[99]=C_h_intern(&lf[99],13,"\000bounds-error");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[101]=C_h_intern(&lf[101],13,"file-position");
lf[102]=C_h_intern(&lf[102],16,"create-directory");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[107]=C_h_intern(&lf[107],12,"file-exists\077");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[109]=C_h_intern(&lf[109],12,"string-split");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[111]=C_h_intern(&lf[111],16,"change-directory");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[113]=C_h_intern(&lf[113],16,"delete-directory");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[115]=C_h_intern(&lf[115],10,"string-ref");
lf[116]=C_h_intern(&lf[116],6,"string");
lf[117]=C_h_intern(&lf[117],9,"directory");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[119]=C_h_intern(&lf[119],16,"\003sysmake-pointer");
lf[120]=C_h_intern(&lf[120],17,"current-directory");
lf[121]=C_h_intern(&lf[121],10,"directory\077");
lf[122]=C_h_intern(&lf[122],13,"\003sysfile-info");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[124]=C_h_intern(&lf[124],5,"null\077");
lf[125]=C_h_intern(&lf[125],6,"char=\077");
lf[126]=C_h_intern(&lf[126],8,"string=\077");
lf[127]=C_h_intern(&lf[127],16,"char-alphabetic\077");
lf[128]=C_h_intern(&lf[128],18,"string-intersperse");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[130]=C_h_intern(&lf[130],24,"get-environment-variable");
lf[131]=C_h_intern(&lf[131],17,"current-user-name");
lf[132]=C_h_intern(&lf[132],9,"condition");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[134]=C_h_intern(&lf[134],22,"with-exception-handler");
lf[135]=C_h_intern(&lf[135],30,"call-with-current-continuation");
lf[136]=C_h_intern(&lf[136],14,"canonical-path");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[140]=C_h_intern(&lf[140],7,"reverse");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[151]=C_h_intern(&lf[151],5,"\000text");
lf[152]=C_h_intern(&lf[152],9,"\003syserror");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[155]=C_h_intern(&lf[155],13,"\003sysmake-port");
lf[156]=C_h_intern(&lf[156],21,"\003sysstream-port-class");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[158]=C_h_intern(&lf[158],15,"open-input-pipe");
lf[159]=C_h_intern(&lf[159],7,"\000binary");
lf[160]=C_h_intern(&lf[160],16,"open-output-pipe");
lf[161]=C_h_intern(&lf[161],16,"close-input-pipe");
lf[162]=C_h_intern(&lf[162],23,"close-input/output-pipe");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[164]=C_h_intern(&lf[164],14,"\003syscheck-port");
lf[165]=C_h_intern(&lf[165],17,"close-output-pipe");
lf[166]=C_h_intern(&lf[166],20,"call-with-input-pipe");
lf[167]=C_h_intern(&lf[167],21,"call-with-output-pipe");
lf[168]=C_h_intern(&lf[168],20,"with-input-from-pipe");
lf[169]=C_h_intern(&lf[169],18,"\003sysstandard-input");
lf[170]=C_h_intern(&lf[170],19,"with-output-to-pipe");
lf[171]=C_h_intern(&lf[171],19,"\003sysstandard-output");
lf[172]=C_h_intern(&lf[172],11,"create-pipe");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[174]=C_h_intern(&lf[174],11,"signal/term");
lf[175]=C_h_intern(&lf[175],11,"signal/kill");
lf[176]=C_h_intern(&lf[176],10,"signal/int");
lf[177]=C_h_intern(&lf[177],10,"signal/hup");
lf[178]=C_h_intern(&lf[178],10,"signal/fpe");
lf[179]=C_h_intern(&lf[179],10,"signal/ill");
lf[180]=C_h_intern(&lf[180],11,"signal/segv");
lf[181]=C_h_intern(&lf[181],11,"signal/abrt");
lf[182]=C_h_intern(&lf[182],11,"signal/trap");
lf[183]=C_h_intern(&lf[183],11,"signal/quit");
lf[184]=C_h_intern(&lf[184],11,"signal/alrm");
lf[185]=C_h_intern(&lf[185],13,"signal/vtalrm");
lf[186]=C_h_intern(&lf[186],11,"signal/prof");
lf[187]=C_h_intern(&lf[187],9,"signal/io");
lf[188]=C_h_intern(&lf[188],10,"signal/urg");
lf[189]=C_h_intern(&lf[189],11,"signal/chld");
lf[190]=C_h_intern(&lf[190],11,"signal/cont");
lf[191]=C_h_intern(&lf[191],11,"signal/stop");
lf[192]=C_h_intern(&lf[192],11,"signal/tstp");
lf[193]=C_h_intern(&lf[193],11,"signal/pipe");
lf[194]=C_h_intern(&lf[194],11,"signal/xcpu");
lf[195]=C_h_intern(&lf[195],11,"signal/xfsz");
lf[196]=C_h_intern(&lf[196],11,"signal/usr1");
lf[197]=C_h_intern(&lf[197],11,"signal/usr2");
lf[198]=C_h_intern(&lf[198],12,"signal/winch");
lf[199]=C_h_intern(&lf[199],12,"signals-list");
lf[200]=C_h_intern(&lf[200],18,"\003sysinterrupt-hook");
lf[201]=C_h_intern(&lf[201],14,"signal-handler");
lf[202]=C_h_intern(&lf[202],19,"set-signal-handler!");
lf[203]=C_h_intern(&lf[203],16,"set-signal-mask!");
lf[204]=C_h_intern(&lf[204],14,"\000process-error");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[206]=C_h_intern(&lf[206],11,"signal-mask");
lf[207]=C_h_intern(&lf[207],14,"signal-masked\077");
lf[208]=C_h_intern(&lf[208],12,"signal-mask!");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[210]=C_h_intern(&lf[210],14,"signal-unmask!");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[212]=C_h_intern(&lf[212],18,"system-information");
lf[213]=C_h_intern(&lf[213],25,"\003syspeek-nonnull-c-string");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[215]=C_h_intern(&lf[215],15,"current-user-id");
lf[216]=C_h_intern(&lf[216],25,"current-effective-user-id");
lf[217]=C_h_intern(&lf[217],16,"current-group-id");
lf[218]=C_h_intern(&lf[218],26,"current-effective-group-id");
lf[219]=C_h_intern(&lf[219],16,"user-information");
lf[220]=C_h_intern(&lf[220],6,"vector");
lf[221]=C_h_intern(&lf[221],4,"list");
lf[222]=C_h_intern(&lf[222],27,"current-effective-user-name");
lf[223]=C_h_intern(&lf[223],17,"group-information");
lf[225]=C_h_intern(&lf[225],10,"get-groups");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[229]=C_h_intern(&lf[229],11,"set-groups!");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[232]=C_h_intern(&lf[232],17,"initialize-groups");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[234]=C_h_intern(&lf[234],10,"errno/perm");
lf[235]=C_h_intern(&lf[235],11,"errno/noent");
lf[236]=C_h_intern(&lf[236],10,"errno/srch");
lf[237]=C_h_intern(&lf[237],10,"errno/intr");
lf[238]=C_h_intern(&lf[238],8,"errno/io");
lf[239]=C_h_intern(&lf[239],12,"errno/noexec");
lf[240]=C_h_intern(&lf[240],10,"errno/badf");
lf[241]=C_h_intern(&lf[241],11,"errno/child");
lf[242]=C_h_intern(&lf[242],11,"errno/nomem");
lf[243]=C_h_intern(&lf[243],11,"errno/acces");
lf[244]=C_h_intern(&lf[244],11,"errno/fault");
lf[245]=C_h_intern(&lf[245],10,"errno/busy");
lf[246]=C_h_intern(&lf[246],12,"errno/notdir");
lf[247]=C_h_intern(&lf[247],11,"errno/isdir");
lf[248]=C_h_intern(&lf[248],11,"errno/inval");
lf[249]=C_h_intern(&lf[249],11,"errno/mfile");
lf[250]=C_h_intern(&lf[250],11,"errno/nospc");
lf[251]=C_h_intern(&lf[251],11,"errno/spipe");
lf[252]=C_h_intern(&lf[252],10,"errno/pipe");
lf[253]=C_h_intern(&lf[253],11,"errno/again");
lf[254]=C_h_intern(&lf[254],10,"errno/rofs");
lf[255]=C_h_intern(&lf[255],11,"errno/exist");
lf[256]=C_h_intern(&lf[256],16,"errno/wouldblock");
lf[257]=C_h_intern(&lf[257],10,"errno/2big");
lf[258]=C_h_intern(&lf[258],12,"errno/deadlk");
lf[259]=C_h_intern(&lf[259],9,"errno/dom");
lf[260]=C_h_intern(&lf[260],10,"errno/fbig");
lf[261]=C_h_intern(&lf[261],11,"errno/ilseq");
lf[262]=C_h_intern(&lf[262],11,"errno/mlink");
lf[263]=C_h_intern(&lf[263],17,"errno/nametoolong");
lf[264]=C_h_intern(&lf[264],11,"errno/nfile");
lf[265]=C_h_intern(&lf[265],11,"errno/nodev");
lf[266]=C_h_intern(&lf[266],11,"errno/nolck");
lf[267]=C_h_intern(&lf[267],11,"errno/nosys");
lf[268]=C_h_intern(&lf[268],14,"errno/notempty");
lf[269]=C_h_intern(&lf[269],11,"errno/notty");
lf[270]=C_h_intern(&lf[270],10,"errno/nxio");
lf[271]=C_h_intern(&lf[271],11,"errno/range");
lf[272]=C_h_intern(&lf[272],10,"errno/xdev");
lf[273]=C_h_intern(&lf[273],16,"change-file-mode");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[275]=C_h_intern(&lf[275],17,"change-file-owner");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[277]=C_h_intern(&lf[277],17,"file-read-access\077");
lf[278]=C_h_intern(&lf[278],18,"file-write-access\077");
lf[279]=C_h_intern(&lf[279],20,"file-execute-access\077");
lf[280]=C_h_intern(&lf[280],14,"create-session");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[282]=C_h_intern(&lf[282],16,"process-group-id");
lf[283]=C_h_intern(&lf[283],20,"create-symbolic-link");
lf[284]=C_h_intern(&lf[284],18,"create-symbol-link");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[286]=C_h_intern(&lf[286],9,"substring");
lf[287]=C_h_intern(&lf[287],18,"read-symbolic-link");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[289]=C_h_intern(&lf[289],9,"file-link");
lf[290]=C_h_intern(&lf[290],9,"hard-link");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[292]=C_h_intern(&lf[292],12,"fileno/stdin");
lf[293]=C_h_intern(&lf[293],13,"fileno/stdout");
lf[294]=C_h_intern(&lf[294],13,"fileno/stderr");
lf[295]=C_h_intern(&lf[295],7,"\000append");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[303]=C_h_intern(&lf[303],16,"open-input-file*");
lf[304]=C_h_intern(&lf[304],17,"open-output-file*");
lf[305]=C_h_intern(&lf[305],12,"port->fileno");
lf[306]=C_h_intern(&lf[306],6,"socket");
lf[307]=C_h_intern(&lf[307],20,"\003systcp-port->fileno");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[310]=C_h_intern(&lf[310],25,"\003syspeek-unsigned-integer");
lf[311]=C_h_intern(&lf[311],16,"duplicate-fileno");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[313]=C_h_intern(&lf[313],15,"make-input-port");
lf[314]=C_h_intern(&lf[314],14,"set-port-name!");
lf[315]=C_h_intern(&lf[315],21,"\003syscustom-input-port");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[317]=C_h_intern(&lf[317],17,"\003systhread-yield!");
lf[318]=C_h_intern(&lf[318],25,"\003systhread-block-for-i/o!");
lf[319]=C_h_intern(&lf[319],18,"\003syscurrent-thread");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[324]=C_h_intern(&lf[324],17,"\003sysstring-append");
lf[325]=C_h_intern(&lf[325],15,"\003sysmake-string");
lf[326]=C_h_intern(&lf[326],20,"\003sysscan-buffer-line");
lf[327]=C_h_intern(&lf[327],4,"noop");
lf[328]=C_h_intern(&lf[328],16,"make-output-port");
lf[329]=C_h_intern(&lf[329],22,"\003syscustom-output-port");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[332]=C_h_intern(&lf[332],13,"file-truncate");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[335]=C_h_intern(&lf[335],4,"lock");
lf[336]=C_h_intern(&lf[336],9,"file-lock");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[338]=C_h_intern(&lf[338],18,"file-lock/blocking");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[340]=C_h_intern(&lf[340],14,"file-test-lock");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[342]=C_h_intern(&lf[342],11,"file-unlock");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[344]=C_h_intern(&lf[344],11,"create-fifo");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[347]=C_h_intern(&lf[347],6,"setenv");
lf[348]=C_h_intern(&lf[348],8,"unsetenv");
lf[349]=C_h_intern(&lf[349],25,"get-environment-variables");
lf[350]=C_h_intern(&lf[350],19,"current-environment");
lf[351]=C_h_intern(&lf[351],9,"prot/read");
lf[352]=C_h_intern(&lf[352],10,"prot/write");
lf[353]=C_h_intern(&lf[353],9,"prot/exec");
lf[354]=C_h_intern(&lf[354],9,"prot/none");
lf[355]=C_h_intern(&lf[355],9,"map/fixed");
lf[356]=C_h_intern(&lf[356],10,"map/shared");
lf[357]=C_h_intern(&lf[357],11,"map/private");
lf[358]=C_h_intern(&lf[358],13,"map/anonymous");
lf[359]=C_h_intern(&lf[359],8,"map/file");
lf[360]=C_h_intern(&lf[360],18,"map-file-to-memory");
lf[361]=C_h_intern(&lf[361],4,"mmap");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[363]=C_h_intern(&lf[363],20,"\003syspointer->address");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[365]=C_h_intern(&lf[365],16,"\003sysnull-pointer");
lf[366]=C_h_intern(&lf[366],22,"unmap-file-from-memory");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[368]=C_h_intern(&lf[368],26,"memory-mapped-file-pointer");
lf[369]=C_h_intern(&lf[369],19,"memory-mapped-file\077");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[372]=C_h_intern(&lf[372],19,"seconds->local-time");
lf[373]=C_h_intern(&lf[373],18,"\003sysdecode-seconds");
lf[374]=C_h_intern(&lf[374],17,"seconds->utc-time");
lf[375]=C_h_intern(&lf[375],15,"seconds->string");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[377]=C_h_intern(&lf[377],12,"time->string");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[380]=C_h_intern(&lf[380],12,"string->time");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[382]=C_h_intern(&lf[382],19,"local-time->seconds");
lf[383]=C_h_intern(&lf[383],15,"\003syscons-flonum");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[385]=C_h_intern(&lf[385],17,"utc-time->seconds");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[387]=C_h_intern(&lf[387],27,"local-timezone-abbreviation");
lf[388]=C_h_intern(&lf[388],5,"_exit");
lf[389]=C_h_intern(&lf[389],10,"set-alarm!");
lf[390]=C_h_intern(&lf[390],19,"set-buffering-mode!");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[392]=C_h_intern(&lf[392],5,"\000full");
lf[393]=C_h_intern(&lf[393],5,"\000line");
lf[394]=C_h_intern(&lf[394],5,"\000none");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[396]=C_h_intern(&lf[396],14,"terminal-port\077");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[399]=C_h_intern(&lf[399],13,"terminal-name");
lf[400]=C_h_intern(&lf[400],13,"terminal-size");
lf[401]=C_h_intern(&lf[401],6,"\000error");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[403]=C_h_intern(&lf[403],17,"\003sysmake-locative");
lf[404]=C_h_intern(&lf[404],8,"location");
lf[405]=C_h_intern(&lf[405],13,"get-host-name");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[407]=C_h_intern(&lf[407],6,"regexp");
lf[408]=C_h_intern(&lf[408],12,"string-match");
lf[409]=C_h_intern(&lf[409],12,"glob->regexp");
lf[410]=C_h_intern(&lf[410],13,"make-pathname");
lf[411]=C_h_intern(&lf[411],18,"decompose-pathname");
lf[412]=C_h_intern(&lf[412],4,"glob");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[415]=C_h_intern(&lf[415],12,"process-fork");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[417]=C_h_intern(&lf[417],24,"pathname-strip-directory");
lf[418]=C_h_intern(&lf[418],15,"process-execute");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[420]=C_h_intern(&lf[420],16,"\003sysprocess-wait");
lf[421]=C_h_intern(&lf[421],12,"process-wait");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[423]=C_h_intern(&lf[423],18,"current-process-id");
lf[424]=C_h_intern(&lf[424],17,"parent-process-id");
lf[425]=C_h_intern(&lf[425],5,"sleep");
lf[426]=C_h_intern(&lf[426],14,"process-signal");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[428]=C_h_intern(&lf[428],17,"\003sysshell-command");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[431]=C_h_intern(&lf[431],27,"\003sysshell-command-arguments");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[433]=C_h_intern(&lf[433],11,"process-run");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[435]=C_h_intern(&lf[435],11,"\003sysprocess");
lf[436]=C_h_intern(&lf[436],7,"process");
lf[437]=C_h_intern(&lf[437],8,"process*");
lf[438]=C_h_intern(&lf[438],10,"find-files");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[442]=C_h_intern(&lf[442],16,"\003sysdynamic-wind");
lf[443]=C_h_intern(&lf[443],13,"pathname-file");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[445]=C_h_intern(&lf[445],7,"regexp\077");
lf[446]=C_h_intern(&lf[446],19,"set-root-directory!");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[449]=C_h_intern(&lf[449],21,"set-process-group-id!");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[451]=C_h_intern(&lf[451],18,"getter-with-setter");
lf[452]=C_h_intern(&lf[452],26,"effective-group-id!-setter");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[454]=C_h_intern(&lf[454],12,"set-user-id!");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[456]=C_h_intern(&lf[456],25,"effective-user-id!-setter");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[459]=C_h_intern(&lf[459],23,"\003sysuser-interrupt-hook");
lf[460]=C_h_intern(&lf[460],11,"make-vector");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[463]=C_h_intern(&lf[463],17,"register-feature!");
lf[464]=C_h_intern(&lf[464],5,"posix");
C_register_lf2(lf,465,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3434,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3432 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3435 in k3432 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3438 in k3435 in k3432 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 501  register-feature! */
t3=*((C_word*)lf[463]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[464]);}

/* k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word ab[79],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=*((C_word*)lf[0]+1);
t3=C_mutate(&lf[1] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3459,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1 /* (set! posix-error ...) */,lf[1]);
t5=C_mutate((C_word*)lf[7]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3477,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[8]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3480,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[9]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[10]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[11]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[15]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[16]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[17]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[18]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[19]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[20]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[21]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[22]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[23]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[24]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[25]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[26]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[27]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[28]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[29]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[30]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[31]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[32]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[33]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[34]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[35]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[36]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[37]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[38]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[39]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[40]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[42]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[43]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[44]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[45]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3521,tmp=(C_word)a,a+=2,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[48]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3560,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[52]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3598,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[54]+1);
t49=C_mutate((C_word*)lf[55]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[59]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3655,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[62]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3694,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3726,tmp=(C_word)a,a+=2,tmp);
t53=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3728,tmp=(C_word)a,a+=2,tmp);
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3730,tmp=(C_word)a,a+=2,tmp);
t55=C_mutate((C_word*)lf[65]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3732,a[2]=t53,a[3]=t54,a[4]=t52,tmp=(C_word)a,a+=5,tmp));
t56=C_mutate((C_word*)lf[68]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[69]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[70]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[71] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3924,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[74]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3961,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[75]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3986,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[76]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3992,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[77]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3998,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[78]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4004,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[79]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4010,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[80]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4016,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[81]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4022,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[82]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4031,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[83]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4040,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[84]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4049,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[85]+1 /* (set! character-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4058,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[86]+1 /* (set! stat-char-device? ...) */,*((C_word*)lf[85]+1));
t73=C_mutate((C_word*)lf[87]+1 /* (set! block-device? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4068,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[88]+1 /* (set! stat-block-device? ...) */,*((C_word*)lf[87]+1));
t75=C_mutate((C_word*)lf[89]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4078,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[90]+1 /* (set! stat-fifo? ...) */,*((C_word*)lf[89]+1));
t77=C_mutate((C_word*)lf[91]+1 /* (set! stat-symlink? ...) */,*((C_word*)lf[82]+1));
t78=C_mutate((C_word*)lf[92]+1 /* (set! socket? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4089,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[93]+1 /* (set! stat-socket? ...) */,*((C_word*)lf[92]+1));
t80=C_mutate((C_word*)lf[94]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4099,tmp=(C_word)a,a+=2,tmp));
t81=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t82=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9076,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 845  getter-with-setter */
t83=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t83+1)))(4,t83,t81,t82,*((C_word*)lf[94]+1));}

/* a9075 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9076,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9080,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9092,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 847  port? */
t5=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9090 in a9075 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[96]);
t4=((C_word*)t0)[2];
f_9080(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_9080(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 852  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[57],lf[101],lf[462],((C_word*)t0)[3]);}}}

/* k9078 in a9075 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9083,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 854  posix-error */
t3=lf[1];
f_3459(6,t3,t2,lf[46],lf[101],lf[461],((C_word*)t0)[2]);}
else{
t3=t2;
f_9083(2,t3,C_SCHEME_UNDEFINED);}}

/* k9081 in k9078 in a9075 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[150],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=C_mutate((C_word*)lf[101]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[102]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4161,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[111]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4256,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[113]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4280,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[115]+1);
t7=*((C_word*)lf[54]+1);
t8=*((C_word*)lf[116]+1);
t9=C_mutate((C_word*)lf[117]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4304,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[121]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4458,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[54]+1);
t12=C_mutate((C_word*)lf[120]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4481,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[124]+1);
t14=*((C_word*)lf[125]+1);
t15=*((C_word*)lf[126]+1);
t16=*((C_word*)lf[127]+1);
t17=*((C_word*)lf[115]+1);
t18=*((C_word*)lf[0]+1);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4522,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4527,tmp=(C_word)a,a+=2,tmp);
t21=*((C_word*)lf[130]+1);
t22=*((C_word*)lf[131]+1);
t23=*((C_word*)lf[120]+1);
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4538,a[2]=t23,tmp=(C_word)a,a+=3,tmp);
t25=C_mutate((C_word*)lf[136]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4594,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,tmp=(C_word)a,a+=13,tmp));
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4911,tmp=(C_word)a,a+=2,tmp);
t27=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4923,tmp=(C_word)a,a+=2,tmp);
t28=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4929,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[158]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4944,a[2]=t27,a[3]=t28,a[4]=t26,tmp=(C_word)a,a+=5,tmp));
t30=C_mutate((C_word*)lf[160]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4980,a[2]=t27,a[3]=t28,a[4]=t26,tmp=(C_word)a,a+=5,tmp));
t31=C_mutate((C_word*)lf[161]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5016,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[165]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[161]+1));
t33=*((C_word*)lf[158]+1);
t34=*((C_word*)lf[160]+1);
t35=*((C_word*)lf[161]+1);
t36=*((C_word*)lf[165]+1);
t37=C_mutate((C_word*)lf[166]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5032,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t38=C_mutate((C_word*)lf[167]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5056,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t39=C_mutate((C_word*)lf[168]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5080,a[2]=t33,a[3]=t35,tmp=(C_word)a,a+=4,tmp));
t40=C_mutate((C_word*)lf[170]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5100,a[2]=t34,a[3]=t36,tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[172]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5120,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[174]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[175]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[176]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[177]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[178]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[179]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[180]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[181]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[182]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[183]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[184]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[185]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[186]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[187]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[188]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[189]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[190]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[191]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[192]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[193]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[194]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[195]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[196]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[197]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[198]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[174]+1),*((C_word*)lf[175]+1),*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1),*((C_word*)lf[191]+1),*((C_word*)lf[192]+1),*((C_word*)lf[193]+1),*((C_word*)lf[194]+1),*((C_word*)lf[195]+1),*((C_word*)lf[196]+1),*((C_word*)lf[197]+1),*((C_word*)lf[198]+1));
t68=C_mutate((C_word*)lf[199]+1 /* (set! signals-list ...) */,t67);
t69=*((C_word*)lf[200]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5165,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1175 make-vector */
t71=*((C_word*)lf[460]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5165,2,t0,t1);}
t2=C_mutate((C_word*)lf[201]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5167,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[202]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5176,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[200]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[203]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5207,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[206]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5231,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[207]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5263,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[208]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5269,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[210]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5284,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9070,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1231 set-signal-handler! */
t12=*((C_word*)lf[202]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,*((C_word*)lf[176]+1),t11);}

/* a9069 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9070,3,t0,t1,t2);}
/* posixunix.scm: 1233 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[459]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5300,2,t0,t1);}
t2=C_mutate((C_word*)lf[212]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5302,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5342,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9052,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9055,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1257 getter-with-setter */
t6=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a9054 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9055,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9065,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1261 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9063 in a9054 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1262 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[454],lf[458],((C_word*)t0)[2]);}

/* a9051 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9052,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1107(C_SCHEME_UNDEFINED));}

/* k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5342,2,t0,t1);}
t2=C_mutate((C_word*)lf[215]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9034,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9037,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1265 getter-with-setter */
t6=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a9036 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9037,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9047,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1269 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9045 in a9036 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1270 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[456],lf[457],((C_word*)t0)[2]);}

/* a9033 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9034,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1116(C_SCHEME_UNDEFINED));}

/* k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=C_mutate((C_word*)lf[216]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9016,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9019,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1274 getter-with-setter */
t6=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a9018 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9019,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9029,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1278 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9027 in a9018 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1279 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[454],lf[455],((C_word*)t0)[2]);}

/* a9015 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9016,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1125(C_SCHEME_UNDEFINED));}

/* k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5350,2,t0,t1);}
t2=C_mutate((C_word*)lf[217]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8998,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9001,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1282 getter-with-setter */
t6=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a9000 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9001(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9001,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9011,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1286 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9009 in a9000 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1287 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[452],lf[453],((C_word*)t0)[2]);}

/* a8997 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8998,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1134(C_SCHEME_UNDEFINED));}

/* k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5354,2,t0,t1);}
t2=C_mutate((C_word*)lf[218]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[219]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5356,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[131]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5416,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[222]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5430,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[223]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5450,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[224] /* (set! _ensure-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5525,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[225]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5528,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[229]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5591,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[232]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5657,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[234]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[235]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[236]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[237]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[238]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[239]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[240]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[241]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[242]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[243]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[244]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[245]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[246]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[247]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[248]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[249]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[250]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[251]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[252]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[253]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[254]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[255]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[256]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[257] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[258] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[259] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[260] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[261] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[262] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[263] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[264] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[265] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[266] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[267] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[268] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[269] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[270] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[271] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[272] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[273]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5721,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[275]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5748,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5778,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[277]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5802,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[278]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5808,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[279]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5814,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[280]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5820,tmp=(C_word)a,a+=2,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8959,tmp=(C_word)a,a+=2,tmp);
t59=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8977,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1502 getter-with-setter */
t60=*((C_word*)lf[451]+1);
((C_proc4)(void*)(*((C_word*)t60+1)))(4,t60,t57,t58,t59);}

/* a8976 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8977,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[449]);
t5=(C_word)C_i_check_exact_2(t3,lf[449]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8993,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1514 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k8991 in a8976 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[449],lf[450],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8958 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8959(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8959,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[282]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8966,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8972,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1507 ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_8966(2,t6,C_SCHEME_UNDEFINED);}}

/* k8970 in a8958 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1508 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[282],lf[448],((C_word*)t0)[2]);}

/* k8964 in a8958 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5837,2,t0,t1);}
t2=C_mutate((C_word*)lf[282]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[283]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5839,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[286]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_u_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1535 make-string */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[190],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5876,2,t0,t1);}
t2=C_mutate((C_word*)lf[287]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5877,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[289]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5919,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[292]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[293]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[294]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5944,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5981,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[303]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5996,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[304]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[305]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6024,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[311]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6069,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[313]+1);
t14=*((C_word*)lf[314]+1);
t15=C_mutate((C_word*)lf[315]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6096,a[2]=t13,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[328]+1);
t17=*((C_word*)lf[314]+1);
t18=C_mutate((C_word*)lf[329]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6575,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=C_mutate((C_word*)lf[332]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6831,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6870,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6941,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[336]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6959,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[338]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6974,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[340]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6989,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[342]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7011,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[344]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7039,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[89]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7082,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[347]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7108,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[348]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7125,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[349]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7140,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[350]+1 /* (set! current-environment ...) */,*((C_word*)lf[349]+1));
t32=C_mutate((C_word*)lf[351]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[352]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[353]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[354]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[355]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[356]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[357]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[358]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[359]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[360]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7224,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[366]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7282,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[368]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7317,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[369]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7326,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate(&lf[370] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7332,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[372]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7351,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[374]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7360,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[375]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7374,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[377]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7410,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[380]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7472,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[382]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7511,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[385]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7526,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[387]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7541,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[388]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7549,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[389]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7565,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[390]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7568,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[396]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7627,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate(&lf[397] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7646,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[399]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7673,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[400]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7692,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[405]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7727,tmp=(C_word)a,a+=2,tmp));
t62=*((C_word*)lf[407]+1);
t63=*((C_word*)lf[408]+1);
t64=*((C_word*)lf[409]+1);
t65=*((C_word*)lf[117]+1);
t66=*((C_word*)lf[410]+1);
t67=*((C_word*)lf[411]+1);
t68=C_mutate((C_word*)lf[412]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7739,a[2]=t64,a[3]=t62,a[4]=t65,a[5]=t63,a[6]=t66,a[7]=t67,tmp=(C_word)a,a+=8,tmp));
t69=C_mutate((C_word*)lf[415]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7848,tmp=(C_word)a,a+=2,tmp));
t70=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7886,tmp=(C_word)a,a+=2,tmp);
t71=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7894,tmp=(C_word)a,a+=2,tmp);
t72=*((C_word*)lf[417]+1);
t73=C_mutate((C_word*)lf[418]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7902,a[2]=t72,a[3]=t71,a[4]=t70,tmp=(C_word)a,a+=5,tmp));
t74=C_mutate((C_word*)lf[420]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8081,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[421]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8098,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[423]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8173,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[424]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8176,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[425]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8179,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[426]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8182,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[428]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8209,tmp=(C_word)a,a+=2,tmp));
t81=C_mutate((C_word*)lf[431]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8218,tmp=(C_word)a,a+=2,tmp));
t82=*((C_word*)lf[415]+1);
t83=*((C_word*)lf[418]+1);
t84=C_mutate((C_word*)lf[433]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8224,a[2]=t82,a[3]=t83,tmp=(C_word)a,a+=4,tmp));
t85=*((C_word*)lf[172]+1);
t86=*((C_word*)lf[421]+1);
t87=*((C_word*)lf[415]+1);
t88=*((C_word*)lf[418]+1);
t89=*((C_word*)lf[311]+1);
t90=*((C_word*)lf[52]+1);
t91=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8280,a[2]=t86,tmp=(C_word)a,a+=3,tmp);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8317,a[2]=t85,tmp=(C_word)a,a+=3,tmp);
t93=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8337,a[2]=t90,tmp=(C_word)a,a+=3,tmp);
t94=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8351,a[2]=t90,tmp=(C_word)a,a+=3,tmp);
t95=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8368,tmp=(C_word)a,a+=2,tmp);
t96=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8384,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=t95,tmp=(C_word)a,a+=7,tmp);
t97=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8429,a[2]=t93,tmp=(C_word)a,a+=3,tmp);
t98=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8440,a[2]=t93,tmp=(C_word)a,a+=3,tmp);
t99=C_mutate((C_word*)lf[435]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8451,a[2]=t98,a[3]=t91,a[4]=t97,a[5]=t96,tmp=(C_word)a,a+=6,tmp));
t100=C_set_block_item(lf[436] /* process */,0,C_SCHEME_UNDEFINED);
t101=C_set_block_item(lf[437] /* process* */,0,C_SCHEME_UNDEFINED);
t102=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8509,tmp=(C_word)a,a+=2,tmp);
t103=C_mutate((C_word*)lf[436]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8570,a[2]=t102,tmp=(C_word)a,a+=3,tmp));
t104=C_mutate((C_word*)lf[437]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8627,a[2]=t102,tmp=(C_word)a,a+=3,tmp));
t105=*((C_word*)lf[412]+1);
t106=*((C_word*)lf[408]+1);
t107=*((C_word*)lf[410]+1);
t108=*((C_word*)lf[121]+1);
t109=C_mutate((C_word*)lf[438]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8684,a[2]=t108,a[3]=t107,a[4]=t105,a[5]=t106,tmp=(C_word)a,a+=6,tmp));
t110=C_mutate((C_word*)lf[446]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8936,tmp=(C_word)a,a+=2,tmp));
t111=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t111+1)))(2,t111,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8936,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[446]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8932,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* ##sys#make-c-string */
t6=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t6=t5;
f_8932(2,t6,C_SCHEME_FALSE);}}

/* k8930 in set-root-directory! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub3164(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2396 posix-error */
t3=lf[1];
f_3459(6,t3,((C_word*)t0)[3],lf[46],lf[446],lf[447],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8684(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_8684r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8684r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8684r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8851,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8856,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8861,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action30543145 */
t9=t8;
f_8861(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id30553141 */
t11=t7;
f_8856(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit30563136 */
t13=t6;
f_8851(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body30523062 */
t15=t5;
f_8686(t15,t1,t9,t11,t13);}}}}

/* def-action3054 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8861(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8861,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8867,tmp=(C_word)a,a+=2,tmp);
/* def-id30553141 */
t3=((C_word*)t0)[2];
f_8856(t3,t1,t2);}

/* a8866 in def-action3054 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8867(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8867,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id3055 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8856(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8856,NULL,3,t0,t1,t2);}
/* def-limit30563136 */
t3=((C_word*)t0)[2];
f_8851(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit3056 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8851(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8851,NULL,4,t0,t1,t2,t3);}
/* body30523062 */
t4=((C_word*)t0)[2];
f_8686(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8686(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8686,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[438]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8693,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_8693(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8846,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_8693(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8838,tmp=(C_word)a,a+=2,tmp));}}

/* f_8838 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8838(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8838,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_8846 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8846(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8846,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8693,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_8826(2,t4,t2);}
else{
/* posixunix.scm: 2368 regexp? */
t4=*((C_word*)lf[445]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}

/* k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8826,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8827,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8820,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2371 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[444]);}

/* k8818 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2371 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8703,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8705,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8705(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8705(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8705,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2377 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8724,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2378 pathname-file */
t3=*((C_word*)lf[443]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8806,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2385 pproc */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8804 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8806,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8813,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2385 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2386 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8705(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k8811 in k8804 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2385 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8705(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8800,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[439]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[440]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2378 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8705(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2379 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8749,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8751,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8780,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[442]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8790,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8793,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2384 pproc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k8791 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2384 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8790(2,t2,((C_word*)t0)[2]);}}

/* k8788 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2384 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8705(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8779 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8780,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8755 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8778,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2382 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[441]);}

/* k8776 in a8755 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2382 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8762 in a8755 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8768,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2383 pproc */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k8769 in k8762 in a8755 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2383 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_8768(2,t2,((C_word*)t0)[2]);}}

/* k8766 in k8762 in a8755 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2382 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8705(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8750 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8747 in k8737 in k8798 in k8722 in loop in k8701 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2380 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8705(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_8827 in k8824 in k8691 in body3052 in find-files in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8827(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8827,3,t0,t1,t2);}
/* posixunix.scm: 2369 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8627(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_8627r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8627r(t0,t1,t2,t3);}}

static void C_ccall f_8627r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8629,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8634,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8639,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args30073023 */
t7=t6;
f_8639(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env30083019 */
t9=t5;
f_8634(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body30053014 */
t11=t4;
f_8629(t11,t1,t7,t9);}}}

/* def-args3007 in process* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8639,NULL,2,t0,t1);}
/* def-env30083019 */
t2=((C_word*)t0)[2];
f_8634(t2,t1,C_SCHEME_FALSE);}

/* def-env3008 in process* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8634(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8634,NULL,3,t0,t1,t2);}
/* body30053014 */
t3=((C_word*)t0)[2];
f_8629(t3,t1,t2,C_SCHEME_FALSE);}

/* body3005 in process* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8629(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8629,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2346 %process */
f_8509(t1,lf[437],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8570(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_8570r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8570r(t0,t1,t2,t3);}}

static void C_ccall f_8570r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8572,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8577,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8582,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args29632979 */
t7=t6;
f_8582(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env29642975 */
t9=t5;
f_8577(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body29612970 */
t11=t4;
f_8572(t11,t1,t7,t9);}}}

/* def-args2963 in process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8582(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8582,NULL,2,t0,t1);}
/* def-env29642975 */
t2=((C_word*)t0)[2];
f_8577(t2,t1,C_SCHEME_FALSE);}

/* def-env2964 in process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8577(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8577,NULL,3,t0,t1,t2);}
/* body29612970 */
t3=((C_word*)t0)[2];
f_8572(t3,t1,t2,C_SCHEME_FALSE);}

/* body2961 in process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8572(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8572,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2343 %process */
f_8509(t1,lf[436],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8509(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8509,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8511,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8530,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2332 chkstrlst */
t12=t9;
f_8511(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8564,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2334 ##sys#shell-command-arguments */
t13=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t7)[1]);}}

/* k8562 in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8564,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2335 ##sys#shell-command */
t4=*((C_word*)lf[428]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k8566 in k8562 in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8530(2,t3,t2);}

/* k8528 in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2336 chkstrlst */
t3=((C_word*)t0)[2];
f_8511(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8533(2,t3,C_SCHEME_UNDEFINED);}}

/* k8531 in k8528 in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8538,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8543 in k8531 in k8528 in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8544,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2339 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2340 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8537 in k8531 in k8528 in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8538,2,t0,t1);}
/* posixunix.scm: 2337 ##sys#process */
t2=*((C_word*)lf[435]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8511,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8519 in chkstrlst in %process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8520,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8451,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8457,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a8462 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8463,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8474,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8494,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2313 make-on-close */
t12=((C_word*)t0)[3];
f_8280(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8492 in a8462 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2312 input-port */
t2=((C_word*)t0)[7];
f_8429(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8472 in a8462 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8478,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8490,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2315 make-on-close */
t4=((C_word*)t0)[6];
f_8280(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8488 in k8472 in a8462 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2314 output-port */
t2=((C_word*)t0)[7];
f_8440(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8476 in k8472 in a8462 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8482,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8486,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2318 make-on-close */
t4=((C_word*)t0)[3];
f_8280(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8484 in k8476 in k8472 in a8462 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2317 input-port */
t2=((C_word*)t0)[7];
f_8429(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8480 in k8476 in k8472 in a8462 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2311 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8456 in ##sys#process in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8457,2,t0,t1);}
/* posixunix.scm: 2306 spawn */
t2=((C_word*)t0)[8];
f_8384(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8440(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8440,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8444,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2302 connect-parent */
t8=((C_word*)t0)[2];
f_8337(t8,t7,t4,t5);}

/* k8442 in output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2303 ##sys#custom-output-port */
t2=*((C_word*)lf[329]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8429,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8433,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2298 connect-parent */
t8=((C_word*)t0)[2];
f_8337(t8,t7,t4,t5);}

/* k8431 in input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2299 ##sys#custom-input-port */
t2=*((C_word*)lf[315]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8384(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8384,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2285 needed-pipe */
t9=((C_word*)t0)[2];
f_8317(t9,t8,t6);}

/* k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2286 needed-pipe */
t3=((C_word*)t0)[2];
f_8317(t3,t2,((C_word*)t0)[5]);}

/* k8389 in k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2287 needed-pipe */
t3=((C_word*)t0)[2];
f_8317(t3,t2,((C_word*)t0)[6]);}

/* k8392 in k8389 in k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8394,2,t0,t1);}
t2=f_8368(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8405,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2290 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8406 in k8392 in k8389 in k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8411,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2292 connect-child */
t3=((C_word*)t0)[7];
f_8351(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[292]+1));}

/* k8409 in a8406 in k8392 in k8389 in k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8414,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_8368(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2293 connect-child */
t4=((C_word*)t0)[5];
f_8351(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[293]+1));}

/* k8412 in k8409 in a8406 in k8392 in k8389 in k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8417,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_8368(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2294 connect-child */
t4=((C_word*)t0)[3];
f_8351(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[294]+1));}

/* k8415 in k8412 in k8409 in a8406 in k8392 in k8389 in k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2295 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8403 in k8392 in k8389 in k8386 in spawn in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2288 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_8368(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_u_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8351(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8351,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8364,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2276 file-close */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k8362 in connect-child in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8364,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8276,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2250 duplicate-fileno */
t6=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k8274 in k8362 in connect-child in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2251 file-close */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8337(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8337,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8350,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2270 file-close */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8348 in connect-parent in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8317(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8317,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8332,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a8331 in needed-pipe in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8332,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a8325 in needed-pipe in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8326,2,t0,t1);}
/* posixunix.scm: 2265 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* make-on-close in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8280(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8280,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8282,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,tmp=(C_word)a,a+=9,tmp));}

/* f_8282 in make-on-close in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8282,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a8302 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8303,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2260 ##sys#signal-hook */
t5=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[204],((C_word*)t0)[3],lf[434],((C_word*)t0)[2],t4);}}

/* a8296 */
static void C_ccall f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8297,2,t0,t1);}
/* posixunix.scm: 2258 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8224r(t0,t1,t2,t3);}}

static void C_ccall f_8224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8231,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2214 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k8229 in process-run in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8231,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2216 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8250,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2218 ##sys#shell-command */
t4=*((C_word*)lf[428]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8248 in k8229 in process-run in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8254,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2218 ##sys#shell-command-arguments */
t3=*((C_word*)lf[431]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8252 in k8248 in k8229 in process-run in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2218 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8218,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[432],t2));}

/* ##sys#shell-command in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8213,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2204 get-environment-variable */
t3=*((C_word*)lf[130]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[430]);}

/* k8211 in ##sys#shell-command in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[429]));}

/* process-signal in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8182r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8182r(t0,t1,t2,t3);}}

static void C_ccall f_8182r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[426]);
t7=(C_word)C_i_check_exact_2(t5,lf[426]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2201 posix-error */
t10=lf[1];
f_3459(7,t10,t1,lf[204],lf[426],lf[427],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8179,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub2712(C_SCHEME_UNDEFINED,t2));}

/* parent-process-id in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8176,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2707(C_SCHEME_UNDEFINED));}

/* current-process-id in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8173,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2703(C_SCHEME_UNDEFINED));}

/* process-wait in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8098(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_8098r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8098r(t0,t1,t2);}}

static void C_ccall f_8098r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t2,C_fix(1)));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[421]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8125,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8131,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t13,t14);}

/* a8130 in process-wait in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8131,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2187 posix-error */
t6=lf[1];
f_3459(6,t6,t1,lf[204],lf[421],lf[422],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2188 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8124 in process-wait in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8125,2,t0,t1);}
/* posixunix.scm: 2185 ##sys#process-wait */
t2=*((C_word*)lf[420]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8081,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2172 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_7902r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7902r(t0,t1,t2,t3);}}

static void C_ccall f_7902r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8031,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8036,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist25692637 */
t7=t6;
f_8036(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist25702633 */
t9=t5;
f_8031(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body25672576 */
t11=t4;
f_7904(t11,t1,t7,t9);}}}

/* def-arglist2569 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8036,NULL,2,t0,t1);}
/* def-envlist25702633 */
t2=((C_word*)t0)[2];
f_8031(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist2570 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8031,NULL,3,t0,t1,t2);}
/* body25672576 */
t3=((C_word*)t0)[2];
f_7904(t3,t1,t2,C_SCHEME_FALSE);}

/* body2567 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7904(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7904,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[418]);
t5=(C_word)C_i_check_list_2(t2,lf[418]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7914,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2140 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}

/* k7912 in body2567 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7914,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_7886(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7922,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_7922(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop2582 in k7912 in body2567 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7922(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7922,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_7886(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7935,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[418]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7968,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=t5;
f_7935(t8,f_7968(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_7935(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[418]);
t6=(C_word)C_block_size(t4);
t7=f_7886(t3,t4,t6);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop2593 in doloop2582 in k7912 in body2567 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_7968(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(f_7894(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[418]);
t5=(C_word)C_block_size(t3);
t6=f_7894(t2,t3,t5);
t7=(C_word)C_slot(t1,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k7933 in doloop2582 in k7912 in body2567 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7935(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7935,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7960,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2154 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k7958 in k7933 in doloop2582 in k7912 in body2567 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2154 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7936 in k7933 in doloop2582 in k7912 in body2567 in process-execute in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub2532(C_SCHEME_UNDEFINED);
t5=(C_word)stub2547(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2161 posix-error */
t6=lf[1];
f_3459(6,t6,((C_word*)t0)[3],lf[204],lf[418],lf[419],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_7894(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub2538(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* setarg in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_7886(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub2523(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* process-fork in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7848(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7848r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7848r(t0,t1,t2);}}

static void C_ccall f_7848r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub2491(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2125 posix-error */
t5=lf[1];
f_3459(5,t5,t1,lf[204],lf[415],lf[416]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k7868 in process-fork in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7874,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_7874 in k7868 in process-fork in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7874,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub2509(C_SCHEME_UNDEFINED,t2));}

/* glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7739(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_7739r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7739r(t0,t1,t2);}}

static void C_ccall f_7739r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_7745(t6,t1,t2);}

/* conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7745(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7745,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7760,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7766,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7840,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[414]);
/* posixunix.scm: 2110 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k7838 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2110 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7768 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2111 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7771 in k7768 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7780,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[413]);
/* posixunix.scm: 2112 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7778 in k7771 in k7768 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7780,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7782(t5,((C_word*)t0)[2],t1);}

/* loop in k7778 in k7771 in k7768 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7782(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7782,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixunix.scm: 2113 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7745(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixunix.scm: 2114 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7797 in loop in k7778 in k7771 in k7768 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7799,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7809,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixunix.scm: 2115 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixunix.scm: 2116 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7782(t3,((C_word*)t0)[6],t2);}}

/* k7807 in k7797 in loop in k7778 in k7771 in k7768 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7813,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 2115 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7782(t4,t2,t3);}

/* k7811 in k7807 in k7797 in loop in k7778 in k7771 in k7768 in a7765 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7813,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7759 in conc-loop in glob in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7760,2,t0,t1);}
/* posixunix.scm: 2109 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7731,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub2405(t3),C_fix(0));}

/* k7729 in get-host-name in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7731,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7734,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7734(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2091 posix-error */
t3=lf[1];
f_3459(5,t3,t2,lf[401],lf[405],lf[406]);}}

/* k7732 in k7729 in get-host-name in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7692,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7696,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2072 ##sys#terminal-check */
f_7646(t3,lf[400],t2);}

/* k7694 in terminal-size in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7716,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[403]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[404]);}

/* k7714 in k7694 in terminal-size in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[403]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[404]);}

/* k7718 in k7714 in k7694 in terminal-size in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_pointer_argumentp(t3);
t5=(C_word)C_i_foreign_pointer_argumentp(t1);
t6=(C_word)stub2376(C_SCHEME_UNDEFINED,t2,t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* posixunix.scm: 2079 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2080 posix-error */
t8=lf[1];
f_3459(6,t8,((C_word*)t0)[4],lf[401],lf[400],lf[402],((C_word*)t0)[6]);}}

/* terminal-name in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7673,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7677,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2064 ##sys#terminal-check */
f_7646(t3,lf[399],t2);}

/* k7675 in terminal-name in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7677,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t5=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2361(t4,t3),C_fix(0));}

/* ##sys#terminal-check in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7646(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7646,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7650,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2056 ##sys#check-port */
t5=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7648 in ##sys#terminal-check in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[96],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2059 ##sys#error */
t5=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[398],((C_word*)t0)[4]);}}

/* terminal-port? in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7627,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7631,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2051 ##sys#check-port */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[396]);}

/* k7629 in terminal-port? in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2052 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7632 in k7629 in terminal-port? in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7568r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7568r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7568r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7572,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2036 ##sys#check-port */
t6=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[390]);}

/* k7570 in set-buffering-mode! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7572,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[392]);
if(C_truep(t6)){
t7=t5;
f_7578(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[393]);
if(C_truep(t7)){
t8=t5;
f_7578(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[394]);
if(C_truep(t8)){
t9=t5;
f_7578(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2042 ##sys#error */
t9=*((C_word*)lf[152]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[390],lf[395],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k7576 in k7570 in set-buffering-mode! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[390]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[96],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2048 ##sys#error */
t6=*((C_word*)lf[152]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[390],lf[391],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7565,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub2312(C_SCHEME_UNDEFINED,t2));}

/* _exit in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7549(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7549r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7549r(t0,t1,t2);}}

static void C_ccall f_7549r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2303(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7541,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub2295(t2),C_fix(0));}

/* utc-time->seconds in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7526(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7526,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7530,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2004 check-time-vector */
f_7332(t3,lf[385],t2);}

/* k7528 in utc-time->seconds in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 2006 ##sys#cons-flonum */
t2=*((C_word*)lf[383]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2007 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[385],lf[386],((C_word*)t0)[3]);}}

/* local-time->seconds in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7511,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7515,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1998 check-time-vector */
f_7332(t3,lf[382],t2);}

/* k7513 in local-time->seconds in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 2000 ##sys#cons-flonum */
t2=*((C_word*)lf[383]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2001 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[382],lf[384],((C_word*)t0)[3]);}}

/* string->time in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7472(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7472r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7472r(t0,t1,t2,t3);}}

static void C_ccall f_7472r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(4);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?lf[381]:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[380]);
t7=(C_word)C_i_check_string_2(t5,lf[380]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7489,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1995 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k7487 in string->time in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7493,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1995 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7491 in k7487 in string->time in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7493,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2256(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7410r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7410r(t0,t1,t2,t3);}}

static void C_ccall f_7410r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7417,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1979 check-time-vector */
f_7332(t6,lf[377],t2);}

/* k7415 in time->string in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7417,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[377]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7436,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1983 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2206(t4,t3),C_fix(0));}}

/* k7437 in k7415 in time->string in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1987 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1988 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[377],lf[379],((C_word*)t0)[2]);}}

/* k7434 in k7415 in time->string in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7436,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub2214(t3,t2,t1),C_fix(0));}

/* k7424 in k7415 in time->string in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1984 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[377],lf[378],((C_word*)t0)[2]);}}

/* seconds->string in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7374(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7374,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[375]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7381,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,(C_word)stub2190(t6,t5),C_fix(0));}

/* k7379 in seconds->string in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1972 ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1973 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[375],lf[376],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7360,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[374]);
/* posixunix.scm: 1964 ##sys#decode-seconds */
t4=*((C_word*)lf[373]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7351,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[372]);
/* posixunix.scm: 1960 ##sys#decode-seconds */
t4=*((C_word*)lf[373]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7332(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7332,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1956 ##sys#error */
t6=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[371],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* memory-mapped-file? in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7326,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[361]));}

/* memory-mapped-file-pointer in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7317,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[361],lf[368]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7282r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7282r(t0,t1,t2,t3);}}

static void C_ccall f_7282r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_i_check_structure_2(t2,lf[361],lf[366]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)stub2143(C_SCHEME_UNDEFINED,t8,t6);
t10=(C_word)C_eqp(C_fix(0),t9);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1942 posix-error */
t11=lf[1];
f_3459(7,t11,t1,lf[46],lf[366],lf[367],t2,t6);}}

/* map-file-to-memory in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_7224r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_7224r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_7224r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7228,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_7228(2,t10,t2);}
else{
/* posixunix.scm: 1927 ##sys#null-pointer */
t10=*((C_word*)lf[365]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k7226 in map-file-to-memory in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7228,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7234,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_7234(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1930 ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[57],lf[360],lf[364],t1);}}

/* k7232 in k7226 in map-file-to-memory in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7234,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)stub2104(t7,t8,t3,t4,t5,t6,((C_word*)t0)[3]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7240,a[2]=((C_word*)t0)[7],a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1932 ##sys#pointer->address */
t12=*((C_word*)lf[363]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t9);}

/* k7251 in k7232 in k7226 in map-file-to-memory in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1933 posix-error */
t3=lf[1];
f_3459(11,t3,((C_word*)t0)[8],lf[46],lf[360],lf[362],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_7240(2,t3,C_SCHEME_UNDEFINED);}}

/* k7238 in k7232 in k7226 in map-file-to-memory in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7240,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[361],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7140,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7146,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_7146(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7146(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7146,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7150,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub2055(t5,t4),C_fix(0));}

/* k7148 in loop in get-environment-variables in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7150,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7158,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7158(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k7148 in loop in get-environment-variables in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7158(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7158,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7184,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1891 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1894 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k7182 in scan in k7148 in loop in get-environment-variables in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7188,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1892 ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k7186 in k7182 in scan in k7148 in loop in get-environment-variables in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7188,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7176,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1893 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7146(t5,t3,t4);}

/* k7174 in k7186 in k7182 in scan in k7148 in loop in get-environment-variables in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7176,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7125,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[348]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7133,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1880 ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7131 in unsetenv in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7108,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[347]);
t5=(C_word)C_i_check_string_2(t3,lf[347]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7119,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1875 ##sys#make-c-string */
t7=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7117 in setenv in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7123,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1875 ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7121 in k7117 in setenv in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7082,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[89]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7089,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7106,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1863 ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7104 in fifo? in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1863 ##sys#file-info */
t2=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7087 in fifo? in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1866 posix-error */
t2=lf[1];
f_3459(6,t2,((C_word*)t0)[3],lf[46],lf[89],lf[346],((C_word*)t0)[2]);}}

/* create-fifo in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7039r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7039r(t0,t1,t2,t3);}}

static void C_ccall f_7039r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[344]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7046,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_7046(t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_7046(t7,(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k7044 in create-fifo in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7046,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[344]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7067,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1857 ##sys#expand-home-path */
t5=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k7065 in k7044 in create-fifo in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1857 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7061 in k7044 in create-fifo in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1858 posix-error */
t3=lf[1];
f_3459(7,t3,((C_word*)t0)[3],lf[46],lf[344],lf[345],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7011,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[335],lf[342]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1847 posix-error */
t9=lf[1];
f_3459(6,t9,t1,lf[46],lf[342],lf[343],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6989(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6989r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6989r(t0,t1,t2,t3);}}

static void C_ccall f_6989r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1838 setup */
f_6870(t4,t2,t3,lf[340]);}

/* k6991 in file-test-lock in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1840 err */
f_6941(((C_word*)t0)[3],lf[341],t1,lf[340]);}}

/* file-lock/blocking in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6974r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6974r(t0,t1,t2,t3);}}

static void C_ccall f_6974r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6978,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1832 setup */
f_6870(t4,t2,t3,lf[338]);}

/* k6976 in file-lock/blocking in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1834 err */
f_6941(((C_word*)t0)[2],lf[339],t1,lf[338]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6959(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6959r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6959r(t0,t1,t2,t3);}}

static void C_ccall f_6959r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6963,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1826 setup */
f_6870(t4,t2,t3,lf[336]);}

/* k6961 in file-lock in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1828 err */
f_6941(((C_word*)t0)[2],lf[337],t1,lf[336]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6941(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6941,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1823 posix-error */
t8=lf[1];
f_3459(8,t8,t1,lf[46],t4,t2,t5,t6,t7);}

/* setup in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6870(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6870,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_u_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_u_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t8,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6889,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1815 ##sys#check-port */
t16=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}

/* k6887 in setup in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6889,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_6895(t6,t5);}
else{
t5=t3;
f_6895(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k6893 in k6887 in setup in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6895(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6895,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[335],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6831(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6831,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[332]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6848,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6855,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6859,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1798 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6848(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1800 ##sys#error */
t6=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[332],lf[334],t2);}}}

/* k6857 in file-truncate in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1798 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6853 in file-truncate in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6848(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6846 in file-truncate in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1802 posix-error */
t2=lf[1];
f_3459(7,t2,((C_word*)t0)[4],lf[46],lf[332],lf[333],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr5r,(void*)f_6575r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6575r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6575r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6761,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6766,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6771,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?18291920 */
t10=t9;
f_6771(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi18301916 */
t12=t8;
f_6766(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close18311911 */
t14=t7;
f_6761(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body18271837 */
t16=t6;
f_6577(t16,t1,t10,t12,t14);}}}}

/* def-nonblocking?1829 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6771(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6771,NULL,2,t0,t1);}
/* def-bufi18301916 */
t2=((C_word*)t0)[2];
f_6766(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1830 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6766(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6766,NULL,3,t0,t1,t2);}
/* def-on-close18311911 */
t3=((C_word*)t0)[2];
f_6761(t3,t1,t2,C_fix(0));}

/* def-on-close1831 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6761(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6761,NULL,4,t0,t1,t2,t3);}
/* body18271837 */
t4=((C_word*)t0)[2];
f_6577(t4,t1,t2,t3,*((C_word*)lf[327]+1));}

/* body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6577(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6577,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6581,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1740 ##sys#file-nonblocking! */
t6=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_6581(2,t6,C_SCHEME_UNDEFINED);}}

/* k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6581,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6629(t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6673,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6687,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1759 ##sys#make-string */
t12=*((C_word*)lf[325]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6687(2,t12,((C_word*)t0)[6]);}}}

/* k6685 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6629(t4,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6688,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));}

/* f_6688 in k6685 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6688,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6705,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6705(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1775 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6583(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6705(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6705,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6715,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1765 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6583(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_difference(t4,t2);
/* posixunix.scm: 1770 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6713 in loop */
static void C_ccall f_6715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1767 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6705(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6673 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6673,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1758 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6583(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6627 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6629(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6629,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6633,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6644,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1778 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}

/* a6664 in k6627 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6665,2,t0,t1);}
/* posixunix.scm: 1788 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* a6643 in k6627 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6644,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6654,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1785 posix-error */
t3=lf[1];
f_3459(7,t3,t2,lf[46],((C_word*)t0)[3],lf[331],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6654(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6652 in a6643 in k6627 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1786 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6637 in k6627 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6638(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6638,3,t0,t1,t2);}
/* posixunix.scm: 1780 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k6631 in k6627 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6636,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1789 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6634 in k6631 in k6627 in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6583(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6583,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6599,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1748 ##sys#thread-yield! */
t8=*((C_word*)lf[317]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1750 posix-error */
t7=lf[1];
f_3459(7,t7,t1,((C_word*)t0)[3],lf[46],lf[330],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6618,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1752 ##sys#substring */
t7=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6616 in poke in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1752 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6583(t3,((C_word*)t0)[2],t1,t2);}

/* k6597 in poke in k6579 in body1827 in ##sys#custom-output-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1749 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6583(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6096(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_6096r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6096r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6096r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(19);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6098,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6485,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6490,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6495,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6500,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?15901788 */
t11=t10;
f_6500(t11,t1);}
else{
t11=(C_word)C_u_i_car(t5);
t12=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi15911784 */
t13=t9;
f_6495(t13,t1,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close15921779 */
t15=t8;
f_6490(t15,t1,t11,t13);}
else{
t15=(C_word)C_u_i_car(t14);
t16=(C_word)C_slot(t14,C_fix(1));
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?15931773 */
t17=t7;
f_6485(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_u_i_car(t16);
t18=(C_word)C_slot(t16,C_fix(1));
/* body15881599 */
t19=t6;
f_6098(t19,t1,t11,t13,t15,t17);}}}}}

/* def-nonblocking?1590 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6500(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6500,NULL,2,t0,t1);}
/* def-bufi15911784 */
t2=((C_word*)t0)[2];
f_6495(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1591 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6495,NULL,3,t0,t1,t2);}
/* def-on-close15921779 */
t3=((C_word*)t0)[2];
f_6490(t3,t1,t2,C_fix(1));}

/* def-on-close1592 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6490(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6490,NULL,4,t0,t1,t2,t3);}
/* def-more?15931773 */
t4=((C_word*)t0)[2];
f_6485(t4,t1,t2,t3,*((C_word*)lf[327]+1));}

/* def-more?1593 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6485(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6485,NULL,5,t0,t1,t2,t3,t4);}
/* body15881599 */
t5=((C_word*)t0)[2];
f_6098(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6098(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6098,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6102,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1614 ##sys#file-nonblocking! */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_6102(2,t7,C_SCHEME_UNDEFINED);}}

/* k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6102,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1616 ##sys#make-string */
t5=*((C_word*)lf[325]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_6108(2,t5,((C_word*)t0)[10]);}}

/* k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6108,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6109,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6132,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6222,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6227,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6240,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6252,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6273,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6282,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6358,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1664 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t18+1)))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6358,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6364,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_6364(t7,t1,C_SCHEME_FALSE);}

/* loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6364,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6444,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6460,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1729 fetch */
t5=((C_word*)t0)[5];
f_6140(t5,t4);}}

/* k6458 in loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1731 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6364(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a6449 in loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6450(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6450,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1726 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6364(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a6443 in loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
/* posixunix.scm: 1724 ##sys#scan-buffer-line */
t2=*((C_word*)lf[326]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6366,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_6373(2,t8,(C_truep(t7)?t7:lf[323]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6416,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1706 ##sys#make-string */
t8=*((C_word*)lf[325]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k6414 in bumper in loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_u_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1712 ##sys#string-append */
t6=*((C_word*)lf[324]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_6373(2,t6,t1);}}

/* k6371 in bumper in loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6383,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1716 fetch */
t5=((C_word*)t0)[3];
f_6140(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_u_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1721 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k6381 in k6371 in bumper in loop in a6357 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1717 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6281 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6282,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6290,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_6290(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_6290(t8,(C_word)C_u_fixnum_difference(t7,t5));}}

/* k6288 in a6281 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6290,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6292,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_6292(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k6288 in a6281 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6292(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6292,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* posixunix.scm: 1692 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6340,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1694 fetch */
t7=((C_word*)t0)[2];
f_6140(t7,t6);}}}

/* k6338 in loop in k6288 in a6281 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1697 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6292(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a6272 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1682 fetch */
t3=((C_word*)t0)[2];
f_6140(t3,t2);}

/* k6275 in a6272 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1683 peek */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_6132(((C_word*)t0)[2]));}

/* a6251 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6252,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6262,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1679 posix-error */
t3=lf[1];
f_3459(7,t3,t2,lf[46],((C_word*)t0)[3],lf[322],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6262(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6260 in a6251 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1680 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6239 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6240,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1674 ready? */
t3=((C_word*)t0)[2];
f_6109(t3,t1);}}

/* a6226 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6231,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1666 fetch */
t3=((C_word*)t0)[2];
f_6140(t3,t2);}

/* k6229 in a6226 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_6132(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k6220 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6222,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6225,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1733 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6223 in k6220 in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6140,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6152,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6152(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6152,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6168,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1641 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[318]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[319]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1644 posix-error */
t5=lf[1];
f_3459(7,t5,t1,lf[46],((C_word*)t0)[6],lf[320],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1648 more? */
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k6187 in loop in fetch in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6189,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1650 ##sys#thread-yield! */
t3=*((C_word*)lf[317]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6198,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_6198(2,t8,t7);}
else{
/* posixunix.scm: 1656 posix-error */
t7=lf[1];
f_3459(7,t7,t4,lf[46],((C_word*)t0)[3],lf[321],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_6198(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6196 in k6187 in loop in fetch in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6190 in k6187 in loop in fetch in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1651 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6152(t2,((C_word*)t0)[2]);}

/* k6166 in loop in fetch in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1642 ##sys#thread-yield! */
t3=*((C_word*)lf[317]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6169 in k6166 in loop in fetch in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1643 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6152(t2,((C_word*)t0)[2]);}

/* peek in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_6132(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6109,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1622 ##sys#file-select-one */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6111 in ready? in k6106 in k6100 in body1588 in ##sys#custom-input-port in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1626 posix-error */
t4=lf[1];
f_3459(7,t4,((C_word*)t0)[5],lf[46],((C_word*)t0)[4],lf[316],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6069(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6069r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6069r(t0,t1,t2,t3);}}

static void C_ccall f_6069r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[311]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6076,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_6076(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[311]);
t8=t5;
f_6076(t8,(C_word)C_dup2(t2,t6));}}

/* k6074 in duplicate-fileno in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6076,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6079,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1607 posix-error */
t3=lf[1];
f_3459(6,t3,t2,lf[46],lf[311],lf[312],((C_word*)t0)[2]);}
else{
t3=t2;
f_6079(2,t3,C_SCHEME_UNDEFINED);}}

/* k6077 in k6074 in duplicate-fileno in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6024(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6024,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6028,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1589 ##sys#check-port */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[305]);}

/* k6026 in port->fileno in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[306],t2);
if(C_truep(t3)){
/* posixunix.scm: 1590 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[307]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1591 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k6061 in k6026 in port->fileno in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6063,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1596 posix-error */
t2=lf[1];
f_3459(6,t2,((C_word*)t0)[3],lf[57],lf[305],lf[308],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6046,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1594 posix-error */
t4=lf[1];
f_3459(6,t4,t3,lf[46],lf[305],lf[309],((C_word*)t0)[2]);}
else{
t4=t3;
f_6046(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6044 in k6061 in k6026 in port->fileno in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6010r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6010r(t0,t1,t2,t3);}}

static void C_ccall f_6010r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[304]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6022,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1585 mode */
f_5944(t5,C_SCHEME_FALSE,t3);}

/* k6020 in open-output-file* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6022,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1585 check */
f_5981(((C_word*)t0)[2],lf[304],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5996r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5996r(t0,t1,t2,t3);}}

static void C_ccall f_5996r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[303]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6008,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1581 mode */
f_5944(t5,C_SCHEME_TRUE,t3);}

/* k6006 in open-input-file* in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6008,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1581 check */
f_5981(((C_word*)t0)[2],lf[303],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5981(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5981,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1574 posix-error */
t6=lf[1];
f_3459(6,t6,t1,lf[46],t2,lf[301],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5994,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1575 ##sys#make-port */
t7=*((C_word*)lf[155]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[156]+1),lf[302],lf[96]);}}

/* k5992 in check in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5944(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5944,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5952,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[295]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1568 ##sys#error */
t8=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[296],t5);}
else{
t8=t4;
f_5952(2,t8,lf[297]);}}
else{
/* posixunix.scm: 1569 ##sys#error */
t7=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[298],t5);}}
else{
t5=t4;
f_5952(2,t5,(C_truep(t2)?lf[299]:lf[300]));}}

/* k5950 in mode in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1564 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5919,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[289]);
t5=(C_word)C_i_check_string_2(t3,lf[289]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5908,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_5908(2,t9,C_SCHEME_FALSE);}}

/* k5906 in file-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_5912(2,t3,C_SCHEME_FALSE);}}

/* k5910 in k5906 in file-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1468(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1549 posix-error */
t3=lf[1];
f_3459(7,t3,((C_word*)t0)[4],lf[46],lf[290],lf[291],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5877,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[287]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5885,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5901,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1538 ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k5899 in read-symbolic-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1538 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5883 in read-symbolic-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5888,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1540 posix-error */
t4=lf[1];
f_3459(6,t4,t3,lf[46],lf[287],lf[288],((C_word*)t0)[2]);}
else{
t4=t3;
f_5888(2,t4,C_SCHEME_UNDEFINED);}}

/* k5886 in k5883 in read-symbolic-link in k5874 in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1541 substring */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5839,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[283]);
t5=(C_word)C_i_check_string_2(t3,lf[283]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5860,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5872,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1526 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5870 in create-symbolic-link in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1526 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5858 in create-symbolic-link in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1527 ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5866 in k5858 in create-symbolic-link in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1527 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5862 in k5858 in create-symbolic-link in k5835 in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1529 posix-error */
t3=lf[1];
f_3459(7,t3,((C_word*)t0)[4],lf[46],lf[284],lf[285],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5820,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5824,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5830,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1497 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5824(2,t4,C_SCHEME_UNDEFINED);}}

/* k5828 in create-session in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1498 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[280],lf[281]);}

/* k5822 in create-session in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5814,3,t0,t1,t2);}
/* posixunix.scm: 1492 check */
f_5778(t1,t2,C_fix((C_word)X_OK),lf[279]);}

/* file-write-access? in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5808,3,t0,t1,t2);}
/* posixunix.scm: 1491 check */
f_5778(t1,t2,C_fix((C_word)W_OK),lf[278]);}

/* file-read-access? in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5802,3,t0,t1,t2);}
/* posixunix.scm: 1490 check */
f_5778(t1,t2,C_fix((C_word)R_OK),lf[277]);}

/* check in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5778(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5778,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5796,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5800,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1487 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5798 in check in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1487 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5794 in check in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5796,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5788,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5788(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1488 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5786 in k5794 in check in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5748,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[275]);
t6=(C_word)C_i_check_exact_2(t3,lf[275]);
t7=(C_word)C_i_check_exact_2(t4,lf[275]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5772,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5776,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1477 ##sys#expand-home-path */
t10=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5774 in change-file-owner in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1477 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5770 in change-file-owner in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1478 posix-error */
t3=lf[1];
f_3459(8,t3,((C_word*)t0)[3],lf[46],lf[275],lf[276],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5721,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[273]);
t5=(C_word)C_i_check_exact_2(t3,lf[273]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5742,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5746,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1469 ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5744 in change-file-mode in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1469 ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5740 in change-file-mode in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1470 posix-error */
t3=lf[1];
f_3459(7,t3,((C_word*)t0)[3],lf[46],lf[273],lf[274],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5657,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[232]);
t5=(C_word)C_i_check_exact_2(t3,lf[232]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5653,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_5653(2,t9,C_SCHEME_FALSE);}}

/* k5651 in initialize-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5653,2,t0,t1);}
t2=(C_word)stub1293(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1390 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5671 in k5651 in initialize-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1391 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[232],lf[233],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5591(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5591,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5595,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_5525(t4);
if(C_truep(t5)){
t6=t3;
f_5595(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1373 ##sys#error */
t6=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[229],lf[231]);}}

/* k5593 in set-groups! in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5600,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5600(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop1269 in k5593 in set-groups! in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5600(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5600,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5616,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1378 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[229]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5614 in doloop1269 in k5593 in set-groups! in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1379 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[229],lf[230],((C_word*)t0)[2]);}

/* get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5528,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5532,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5586,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1359 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5532(2,t4,C_SCHEME_UNDEFINED);}}

/* k5584 in get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1360 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[225],lf[228]);}

/* k5530 in get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_5525(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_5535(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1362 ##sys#error */
t4=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[225],lf[227]);}}

/* k5533 in k5530 in get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)stub1228(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5567,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1364 ##sys#update-errno */
t5=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_5538(2,t4,C_SCHEME_UNDEFINED);}}

/* k5565 in k5533 in k5530 in get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1365 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[225],lf[226]);}

/* k5536 in k5533 in k5530 in get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5538,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5543,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5543(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5536 in k5533 in k5530 in get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5543(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5543,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5557,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1369 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k5555 in loop in k5536 in k5533 in k5530 in get-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_5525(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub1234(C_SCHEME_UNDEFINED,t1));}

/* group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5450r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5450r(t0,t1,t2,t3);}}

static void C_ccall f_5450r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5457,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_5457(t7,(C_word)C_getgrgid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[223]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5508,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1333 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k5506 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5457(t2,(C_word)C_getgrnam(t1));}

/* k5455 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5457,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5465 in k5455 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5471,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k5469 in k5465 in k5455 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5475,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5480,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5480(t6,t2,C_fix(0));}

/* loop in k5469 in k5465 in k5455 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5480(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5480,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5484,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub1186(t5,t4),C_fix(0));}

/* k5482 in loop in k5469 in k5465 in k5455 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5484,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5494,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1342 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5480(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5492 in k5482 in loop in k5469 in k5465 in k5455 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5473 in k5469 in k5465 in k5455 in group-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[220]+1):*((C_word*)lf[221]+1));
t3=t2;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5442,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1318 current-effective-user-id */
t4=*((C_word*)lf[216]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5440 in current-effective-user-name in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1318 user-information */
t2=*((C_word*)lf[219]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5436 in current-effective-user-name in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5424,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5428,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1315 current-user-id */
t4=*((C_word*)lf[215]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5426 in current-user-name in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1315 user-information */
t2=*((C_word*)lf[219]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5422 in current-user-name in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5356(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5356r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5356r(t0,t1,t2,t3);}}

static void C_ccall f_5356r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5363,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_5363(t7,(C_word)C_getpwuid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[219]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5402,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1303 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k5400 in user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5363(t2,(C_word)C_getpwnam(t1));}

/* k5361 in user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5363,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5371 in k5361 in user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5377,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k5375 in k5371 in k5361 in user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5381,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k5379 in k5375 in k5371 in k5361 in user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5385,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5383 in k5379 in k5375 in k5371 in k5361 in user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5389,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k5387 in k5383 in k5379 in k5375 in k5371 in k5361 in user-information in k5352 in k5348 in k5344 in k5340 in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[220]+1):*((C_word*)lf[221]+1));
t3=t2;
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5306,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1248 ##sys#update-errno */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_5306(2,t3,C_SCHEME_UNDEFINED);}}

/* k5333 in system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1249 ##sys#error */
t2=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[212],lf[214]);}

/* k5304 in system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k5311 in k5304 in system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5317,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k5315 in k5311 in k5304 in system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5321,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k5319 in k5315 in k5311 in k5304 in system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5325,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k5323 in k5319 in k5315 in k5311 in k5304 in system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5329,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k5327 in k5323 in k5319 in k5315 in k5311 in k5304 in system-information in k5298 in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5284,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[210]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1227 posix-error */
t5=lf[1];
f_3459(5,t5,t1,lf[204],lf[210],lf[211]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5269,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[208]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1221 posix-error */
t5=lf[1];
f_3459(5,t5,t1,lf[204],lf[208],lf[209]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5263,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[207]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5231,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5237,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5237(t5,t1,*((C_word*)lf[199]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5237(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5237,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1211 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5207,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[203]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5214,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5225,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5224 in set-signal-mask! in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5225,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[203]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k5212 in set-signal-mask! in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1204 posix-error */
t2=lf[1];
f_3459(5,t2,((C_word*)t0)[2],lf[204],lf[203],lf[205]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5189,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5199,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1190 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1192 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k5197 in ##sys#interrupt-hook in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1191 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5176,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[202]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k5163 in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5167,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[201]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5124,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1107 posix-error */
t3=lf[1];
f_3459(5,t3,t2,lf[46],lf[172],lf[173]);}
else{
t3=t2;
f_5124(2,t3,C_SCHEME_UNDEFINED);}}

/* k5122 in create-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1108 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5100r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5100r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5100r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[171]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5104,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5102 in with-output-to-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5104,2,t0,t1);}
t2=C_mutate((C_word*)lf[171]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5110,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1095 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5109 in k5102 in with-output-to-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5110r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5110r(t0,t1,t2);}}

static void C_ccall f_5110r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5114,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1097 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5112 in a5109 in k5102 in with-output-to-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[171]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5080r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5080r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5080r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[169]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5084,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5082 in with-input-from-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5084,2,t0,t1);}
t2=C_mutate((C_word*)lf[169]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5090,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1085 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5089 in k5082 in with-input-from-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5090(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5090r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5090r(t0,t1,t2);}}

static void C_ccall f_5090r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5094,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1087 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5092 in a5089 in k5082 in with-input-from-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[169]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5056r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5056r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5056r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5060,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5058 in call-with-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5065,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5071,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1075 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5070 in k5058 in call-with-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5071r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5071r(t0,t1,t2);}}

static void C_ccall f_5071r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5075,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1078 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5073 in a5070 in k5058 in call-with-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5064 in k5058 in call-with-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5065,2,t0,t1);}
/* posixunix.scm: 1076 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5032r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5032r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5032r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5036,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5034 in call-with-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5041,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1067 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5046 in k5034 in call-with-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5047r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5047r(t0,t1,t2);}}

static void C_ccall f_5047r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5051,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1070 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5049 in a5046 in k5034 in call-with-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5040 in k5034 in call-with-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5041,2,t0,t1);}
/* posixunix.scm: 1068 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5020,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1054 ##sys#check-port */
t4=*((C_word*)lf[164]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[161]);}

/* k5018 in close-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5020,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5023,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1056 posix-error */
t5=lf[1];
f_3459(6,t5,t3,lf[46],lf[162],lf[163],((C_word*)t0)[3]);}
else{
t5=t3;
f_5023(2,t5,C_SCHEME_UNDEFINED);}}

/* k5021 in k5018 in close-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4980(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4980r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4980r(t0,t1,t2,t3);}}

static void C_ccall f_4980r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[160]);
t5=f_4911(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4994,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5001,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1049 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[159]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5011,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1050 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1051 badmode */
f_4923(t6,t5);}}}

/* k5009 in open-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4994(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k4999 in open-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4994(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k4992 in open-output-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1045 check */
f_4929(((C_word*)t0)[3],lf[160],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_4944r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4944r(t0,t1,t2,t3);}}

static void C_ccall f_4944r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[158]);
t5=f_4911(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4958,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[151]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4965,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1038 ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[159]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4975,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1039 ##sys#make-c-string */
t10=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1040 badmode */
f_4923(t6,t5);}}}

/* k4973 in open-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4975,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4958(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k4963 in open-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4958(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k4956 in open-input-pipe in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1034 check */
f_4929(((C_word*)t0)[3],lf[158],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4929(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4929,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1026 posix-error */
t6=lf[1];
f_3459(6,t6,t1,lf[46],t2,lf[154],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4942,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1027 ##sys#make-port */
t7=*((C_word*)lf[155]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[156]+1),lf[157],lf[96]);}}

/* k4940 in check in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4923(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4923,NULL,2,t1,t2);}
/* posixunix.scm: 1023 ##sys#error */
t3=*((C_word*)lf[152]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[153],t2);}

/* mode in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_4911(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[151]));}

/* canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4594,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[136]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4601,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4715,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 971  cwd */
t8=((C_word*)t0)[6];
f_4538(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4901,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 973  sref */
t10=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_4721(t9,C_SCHEME_FALSE);}}}

/* k4899 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 973  sep? */
t2=((C_word*)t0)[3];
f_4721(t2,f_4527(t1));}

/* k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4721(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4721,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_4601(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 976  cwd */
t5=((C_word*)t0)[8];
f_4538(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4876,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4887,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 977  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4885 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4874 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4876,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 978  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4740(t2,C_SCHEME_FALSE);}}

/* k4881 in k4874 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 978  sep? */
t2=((C_word*)t0)[3];
f_4740(t2,f_4527(t1));}

/* k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4740,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4747,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 980  get-environment-variable */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[148]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 985  cwd */
t5=((C_word*)t0)[6];
f_4538(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4869,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 986  sref */
t7=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4867 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4846 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4865,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_4784(t2,C_SCHEME_FALSE);}}

/* k4863 in k4846 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 987  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4852 in k4846 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 988  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_4784(t2,C_SCHEME_FALSE);}}

/* k4859 in k4852 in k4846 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  sep? */
t2=((C_word*)t0)[3];
f_4784(t2,f_4527(t1));}

/* k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4784(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4784,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 989  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4845,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 990  sref */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k4843 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 990  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4822 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4824,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 991  sref */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4797(2,t2,C_SCHEME_FALSE);}}

/* k4839 in k4822 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 991  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4828 in k4822 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4830,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4837,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 992  sref */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4797(2,t2,C_SCHEME_FALSE);}}

/* k4835 in k4828 in k4822 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  char=? */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4795 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 993  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4821,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 994  sref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k4819 in k4795 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
t2=f_4527(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_4601(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 997  cwd */
t4=((C_word*)t0)[2];
f_4538(t4,t3);}}

/* k4815 in k4819 in k4795 in k4782 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 997  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[150],((C_word*)t0)[2]);}

/* k4776 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 985  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[149],((C_word*)t0)[2]);}

/* k4745 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4750(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4765,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 981  user */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4763 in k4745 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 981  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[147],t1);}

/* k4748 in k4745 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4754,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 982  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4752 in k4748 in k4745 in k4738 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 979  sappend */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4732 in k4719 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  sappend */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[146],((C_word*)t0)[2]);}

/* k4713 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 971  sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[145]);}

/* k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[144]);}

/* k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_4610(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4610(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4610,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 1000 null? */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4623,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1001 null? */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4678,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1012 string=? */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[143],t5);}}

/* k4679 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4681,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4678(t2,(C_word)C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1014 string=? */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[142],t3);}}

/* k4688 in k4679 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4678(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_u_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4678(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k4676 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1010 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4610(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4621 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[137]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 1003 sref */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k4657 in k4621 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=f_4527(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4640,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[139],((C_word*)t0)[2]);
/* posixunix.scm: 1006 reverse */
t6=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4655,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1009 reverse */
t5=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4653 in k4657 in k4621 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1009 isperse */
f_4522(((C_word*)t0)[2],t1);}

/* k4649 in k4657 in k4621 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1007 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[141],t1);}

/* k4638 in k4657 in k4621 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1006 isperse */
f_4522(((C_word*)t0)[2],t1);}

/* k4634 in k4657 in k4621 in k4615 in loop in k4606 in k4599 in canonical-path in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 sappend */
t2=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[138],t1);}

/* cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4538,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4545,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[135]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a4546 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4553,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4571,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a4570 in a4546 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a4582 in a4570 in a4546 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4583r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4583r(t0,t1,t2);}}

static void C_ccall f_4583r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k789795 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a4588 in a4582 in a4570 in a4546 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4576 in a4570 in a4546 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
/* posixunix.scm: 966  cw */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a4552 in a4546 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4553,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4559,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k789795 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a4558 in a4552 in a4546 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4559,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[132]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[133]);}

/* k4543 in cwd in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* sep? in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_4527(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4522(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4522,NULL,2,t1,t2);}
/* string-intersperse */
t3=*((C_word*)lf[128]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[129]);}

/* current-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4481(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_4481r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_4481r(t0,t1,t2);}}

static void C_ccall f_4481r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixunix.scm: 945  change-directory */
t5=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4494,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 946  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k4492 in current-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 949  ##sys#substring */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 950  posix-error */
t3=lf[1];
f_3459(5,t3,((C_word*)t0)[2],lf[46],lf[120],lf[123]);}}

/* directory? in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4458,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[121]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4465,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4479,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 938  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4477 in directory? in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 938  ##sys#file-info */
t2=*((C_word*)lf[122]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4463 in directory? in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_4304r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4304r(t0,t1,t2);}}

static void C_ccall f_4304r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4404,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4409,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec637694 */
t6=t5;
f_4409(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?638690 */
t8=t4;
f_4404(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body635644 */
t10=t3;
f_4306(t10,t1,t6,t8);}}}

/* def-spec637 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4409,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4417,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 911  current-directory */
t3=*((C_word*)lf[120]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4415 in def-spec637 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?638690 */
t2=((C_word*)t0)[3];
f_4404(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?638 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4404(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4404,NULL,3,t0,t1,t2);}
/* body635644 */
t3=((C_word*)t0)[2];
f_4306(t3,t1,t2,C_SCHEME_FALSE);}

/* body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4306(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4306,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[117]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 913  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 914  ##sys#make-pointer */
t3=*((C_word*)lf[119]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 915  ##sys#make-pointer */
t3=*((C_word*)lf[119]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4323,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4403,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 916  ##sys#expand-home-path */
t4=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4401 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 916  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4321 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4323,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 918  posix-error */
t3=lf[1];
f_3459(6,t3,((C_word*)t0)[7],lf[46],lf[117],lf[118],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4337(t6,((C_word*)t0)[7]);}}

/* loop in k4321 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4337,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 926  ##sys#substring */
t5=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k4345 in loop in k4321 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 927  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k4348 in k4345 in loop in k4321 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 928  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_4353(2,t3,C_SCHEME_FALSE);}}

/* k4351 in k4348 in k4345 in loop in k4321 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_4359(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_4359(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_4359(t4,C_SCHEME_FALSE);}}

/* k4357 in k4351 in k4348 in k4345 in loop in k4321 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4359,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 933  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4337(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4369,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 934  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4337(t3,t2);}}

/* k4367 in k4357 in k4351 in k4348 in k4345 in loop in k4321 in k4317 in k4314 in k4311 in body635 in directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4369,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4280,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[113]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4302,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 904  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4300 in delete-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 904  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4296 in delete-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 905  posix-error */
t3=lf[1];
f_3459(6,t3,((C_word*)t0)[3],lf[46],lf[113],lf[114],((C_word*)t0)[2]);}}

/* change-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4256,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[111]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4274,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4278,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 898  ##sys#expand-home-path */
t6=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4276 in change-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 898  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4272 in change-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 899  posix-error */
t3=lf[1];
f_3459(6,t3,((C_word*)t0)[3],lf[46],lf[111],lf[112],((C_word*)t0)[2]);}}

/* create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4161r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4161r(t0,t1,t2,t3);}}

static void C_ccall f_4161r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(9);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(C_word)C_i_check_string_2(t2,lf[102]);
if(C_truep(t5)){
t7=t2;
t8=lf[103];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4176,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4228,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 886  string-split */
t12=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t7,lf[110]);}
else{
t7=t2;
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4242,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 862  ##sys#make-c-string */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t7);}}

/* k4240 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 863  posix-error */
t3=lf[1];
f_3459(6,t3,((C_word*)t0)[3],lf[46],lf[102],lf[104],((C_word*)t0)[2]);}}

/* k4226 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4175 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4181,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 884  string-append */
t4=*((C_word*)lf[0]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[108],t2);}

/* k4179 in a4175 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4181,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4187,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4204,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 867  file-exists? */
t6=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k4202 in k4179 in a4175 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 868  ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4187(2,t2,C_SCHEME_FALSE);}}

/* k4222 in k4202 in k4179 in a4175 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 869  posix-error */
t3=lf[1];
f_3459(6,t3,((C_word*)t0)[3],lf[46],lf[102],lf[105],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4187(2,t4,t3);}
else{
/* posixunix.scm: 872  posix-error */
t4=lf[1];
f_3459(6,t4,((C_word*)t0)[3],lf[46],lf[102],lf[106],((C_word*)t0)[2]);}}}

/* k4185 in k4179 in a4175 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4187,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 862  ##sys#make-c-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4199 in k4185 in k4179 in a4175 in create-directory in k4157 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 863  posix-error */
t3=lf[1];
f_3459(6,t3,((C_word*)t0)[3],lf[46],lf[102],lf[104],((C_word*)t0)[2]);}}

/* set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4099r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4099r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4099r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[94]);
t8=(C_word)C_i_check_exact_2(t6,lf[94]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4112,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 836  ##sys#signal-hook */
t10=*((C_word*)lf[2]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[99],lf[94],lf[100],t3,t2);}
else{
t10=t9;
f_4112(2,t10,C_SCHEME_UNDEFINED);}}

/* k4110 in set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 837  port? */
t4=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k4122 in k4110 in set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[96]);
t4=((C_word*)t0)[4];
f_4118(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_4118(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 841  ##sys#signal-hook */
t2=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[57],lf[94],lf[97],((C_word*)t0)[5]);}}}

/* k4116 in k4110 in set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 842  posix-error */
t2=lf[1];
f_3459(7,t2,((C_word*)t0)[4],lf[46],lf[94],lf[95],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* socket? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4089,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4096,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 826  ##sys#stat */
f_3924(t4,t2,C_SCHEME_FALSE,lf[92]);}

/* k4094 in socket? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* f_4078 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4078(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4078,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4085,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 818  ##sys#stat */
f_3924(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k4083 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* block-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4068,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4075,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 811  ##sys#stat */
f_3924(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k4073 in block-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* character-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4058,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4065,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 804  ##sys#stat */
f_3924(t4,t2,C_SCHEME_FALSE,lf[85]);}

/* k4063 in character-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4049,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4056,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 799  ##sys#stat */
f_3924(t4,t2,C_SCHEME_FALSE,lf[84]);}

/* k4054 in stat-directory? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4040,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4047,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 794  ##sys#stat */
f_3924(t4,t2,C_SCHEME_FALSE,lf[83]);}

/* k4045 in stat-regular? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4031,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[82]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 789  ##sys#stat */
f_3924(t4,t2,C_SCHEME_TRUE,lf[82]);}

/* k4036 in symbolic-link? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4022,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[81]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 784  ##sys#stat */
f_3924(t4,t2,C_SCHEME_TRUE,lf[81]);}

/* k4027 in regular-file? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4016,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4020,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_3924(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k4018 in file-permissions in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4010,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4014,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_3924(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k4012 in file-owner in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4004,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4008,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_3924(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k4006 in file-change-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3998,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4002,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_3924(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k4000 in file-access-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3992,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3996,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_3924(t3,t2,C_SCHEME_FALSE,lf[76]);}

/* k3994 in file-modification-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3986,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3990,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 775  ##sys#stat */
f_3924(t3,t2,C_SCHEME_FALSE,lf[75]);}

/* k3988 in file-size in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3961r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3961r(t0,t1,t2,t3);}}

static void C_ccall f_3961r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* posixunix.scm: 768  ##sys#stat */
f_3924(t4,t2,t6,lf[74]);}

/* k3963 in file-stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3924(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3924,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3928,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3928(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3949,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3956,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 759  ##sys#expand-home-path */
t8=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 763  ##sys#signal-hook */
t6=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[57],lf[73],t2);}}}

/* k3954 in ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 759  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3947 in ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3928(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3926 in ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 765  posix-error */
t2=lf[1];
f_3459(6,t2,((C_word*)t0)[4],lf[46],((C_word*)t0)[3],lf[72],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3732r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3732r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3732r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(15);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_3726(C_fix(0));
t10=f_3726(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3748,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_3748(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 688  fd_set */
t14=t12;
f_3748(2,t14,f_3728(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[65]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a3904 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3905,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[65]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 695  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3728(C_fix(0),t2));}

/* k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3754(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 700  fd_set */
t5=t3;
f_3754(2,t5,f_3728(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[65]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a3878 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3879,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[65]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 707  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_3728(C_fix(1),t2));}

/* k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[65]);
t4=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_3757(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_3757(t4,(C_word)C_C_select(t3));}}

/* k3755 in k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3757(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3757,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 714  posix-error */
t2=lf[1];
f_3459(7,t2,((C_word*)t0)[5],lf[46],lf[65],lf[66],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 715  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 720  fd_test */
t4=t3;
f_3796(t4,f_3730(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3837,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3839,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t8=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_3796(t4,C_SCHEME_FALSE);}}}}

/* a3838 in k3755 in k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3839,3,t0,t1,t2);}
t3=f_3730(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3835 in k3755 in k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3796(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3794 in k3755 in k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3796,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3800,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 726  fd_test */
t3=t2;
f_3800(t3,f_3730(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3812,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3814,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_3800(t3,C_SCHEME_FALSE);}}

/* a3813 in k3794 in k3755 in k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3814,3,t0,t1,t2);}
t3=f_3730(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3810 in k3794 in k3755 in k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3800(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3798 in k3794 in k3755 in k3752 in k3746 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 717  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_3730(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub252(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_set in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_3728(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub245(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_zero in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_3726(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub239(C_SCHEME_UNDEFINED,t1));}

/* file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3694,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[62]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3701,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 666  ##sys#make-c-string */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3699 in file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3701,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3707,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 670  posix-error */
t6=lf[1];
f_3459(6,t6,t4,lf[46],lf[62],lf[64],((C_word*)t0)[2]);}
else{
t6=t4;
f_3707(2,t6,C_SCHEME_UNDEFINED);}}

/* k3705 in k3699 in file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 671  ##sys#substring */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k3712 in k3705 in k3699 in file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 671  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3655r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3655r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3655r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[59]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3662,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_3662(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 655  ##sys#signal-hook */
t8=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[57],lf[59],lf[61],t3);}}

/* k3660 in file-write in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[59]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3671,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 660  posix-error */
t8=lf[1];
f_3459(7,t8,t6,lf[46],lf[59],lf[60],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_3671(2,t8,C_SCHEME_UNDEFINED);}}

/* k3669 in k3660 in file-write in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3613r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3613r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3613r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[55]);
t6=(C_word)C_i_check_exact_2(t3,lf[55]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3623,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_3623(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixunix.scm: 643  make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k3621 in file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_3626(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 645  ##sys#signal-hook */
t4=*((C_word*)lf[2]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[57],lf[55],lf[58],t1);}}

/* k3624 in k3621 in file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3626,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3629,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 648  posix-error */
t5=lf[1];
f_3459(7,t5,t3,lf[46],lf[55],lf[56],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_3629(2,t5,C_SCHEME_UNDEFINED);}}

/* k3627 in k3624 in k3621 in file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3629,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3598,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[52]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 636  posix-error */
t4=lf[1];
f_3459(6,t4,t1,lf[46],lf[52],lf[53],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3560r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3560r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3560r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[48]);
t8=(C_word)C_i_check_exact_2(t3,lf[48]);
t9=(C_word)C_i_check_exact_2(t6,lf[48]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3577,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3590,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 627  ##sys#expand-home-path */
t12=*((C_word*)lf[51]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k3588 in file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 627  ##sys#make-c-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3575 in file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3577,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3580,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 629  posix-error */
t5=lf[1];
f_3459(8,t5,t3,lf[46],lf[48],lf[49],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_3580(2,t5,C_SCHEME_UNDEFINED);}}

/* k3578 in k3575 in file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3521r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3521r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3521r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_exact_2(t2,lf[45]);
t8=(C_word)C_i_check_exact_2(t3,lf[45]);
t9=t2;
t10=t3;
t11=(C_word)stub124(C_SCHEME_UNDEFINED,t9,t10,t6);
t12=(C_word)C_eqp(t11,C_fix(-1));
if(C_truep(t12)){
/* posixunix.scm: 617  posix-error */
t13=lf[1];
f_3459(7,t13,t1,lf[46],lf[45],lf[47],t2,t3);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t11);}}

/* ##sys#file-select-one in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3480,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub46(C_SCHEME_UNDEFINED,t2));}

/* ##sys#file-nonblocking! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3477,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub40(C_SCHEME_UNDEFINED,t2));}

/* posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_3459r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3459r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3459r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3463,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 507  ##sys#update-errno */
t7=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3461 in posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub23(t4,t1),C_fix(0));}

/* k3472 in k3461 in posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 508  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[3],t1);}

/* k3468 in k3461 in posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[2]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[606] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_3434:posixunix_scm",(void*)f_3434},
{"f_3437:posixunix_scm",(void*)f_3437},
{"f_3440:posixunix_scm",(void*)f_3440},
{"f_3443:posixunix_scm",(void*)f_3443},
{"f_3446:posixunix_scm",(void*)f_3446},
{"f_3449:posixunix_scm",(void*)f_3449},
{"f_3452:posixunix_scm",(void*)f_3452},
{"f_9076:posixunix_scm",(void*)f_9076},
{"f_9092:posixunix_scm",(void*)f_9092},
{"f_9080:posixunix_scm",(void*)f_9080},
{"f_9083:posixunix_scm",(void*)f_9083},
{"f_4159:posixunix_scm",(void*)f_4159},
{"f_5165:posixunix_scm",(void*)f_5165},
{"f_9070:posixunix_scm",(void*)f_9070},
{"f_5300:posixunix_scm",(void*)f_5300},
{"f_9055:posixunix_scm",(void*)f_9055},
{"f_9065:posixunix_scm",(void*)f_9065},
{"f_9052:posixunix_scm",(void*)f_9052},
{"f_5342:posixunix_scm",(void*)f_5342},
{"f_9037:posixunix_scm",(void*)f_9037},
{"f_9047:posixunix_scm",(void*)f_9047},
{"f_9034:posixunix_scm",(void*)f_9034},
{"f_5346:posixunix_scm",(void*)f_5346},
{"f_9019:posixunix_scm",(void*)f_9019},
{"f_9029:posixunix_scm",(void*)f_9029},
{"f_9016:posixunix_scm",(void*)f_9016},
{"f_5350:posixunix_scm",(void*)f_5350},
{"f_9001:posixunix_scm",(void*)f_9001},
{"f_9011:posixunix_scm",(void*)f_9011},
{"f_8998:posixunix_scm",(void*)f_8998},
{"f_5354:posixunix_scm",(void*)f_5354},
{"f_8977:posixunix_scm",(void*)f_8977},
{"f_8993:posixunix_scm",(void*)f_8993},
{"f_8959:posixunix_scm",(void*)f_8959},
{"f_8972:posixunix_scm",(void*)f_8972},
{"f_8966:posixunix_scm",(void*)f_8966},
{"f_5837:posixunix_scm",(void*)f_5837},
{"f_5876:posixunix_scm",(void*)f_5876},
{"f_8936:posixunix_scm",(void*)f_8936},
{"f_8932:posixunix_scm",(void*)f_8932},
{"f_8684:posixunix_scm",(void*)f_8684},
{"f_8861:posixunix_scm",(void*)f_8861},
{"f_8867:posixunix_scm",(void*)f_8867},
{"f_8856:posixunix_scm",(void*)f_8856},
{"f_8851:posixunix_scm",(void*)f_8851},
{"f_8686:posixunix_scm",(void*)f_8686},
{"f_8838:posixunix_scm",(void*)f_8838},
{"f_8846:posixunix_scm",(void*)f_8846},
{"f_8693:posixunix_scm",(void*)f_8693},
{"f_8826:posixunix_scm",(void*)f_8826},
{"f_8820:posixunix_scm",(void*)f_8820},
{"f_8703:posixunix_scm",(void*)f_8703},
{"f_8705:posixunix_scm",(void*)f_8705},
{"f_8724:posixunix_scm",(void*)f_8724},
{"f_8806:posixunix_scm",(void*)f_8806},
{"f_8813:posixunix_scm",(void*)f_8813},
{"f_8800:posixunix_scm",(void*)f_8800},
{"f_8739:posixunix_scm",(void*)f_8739},
{"f_8793:posixunix_scm",(void*)f_8793},
{"f_8790:posixunix_scm",(void*)f_8790},
{"f_8780:posixunix_scm",(void*)f_8780},
{"f_8756:posixunix_scm",(void*)f_8756},
{"f_8778:posixunix_scm",(void*)f_8778},
{"f_8764:posixunix_scm",(void*)f_8764},
{"f_8771:posixunix_scm",(void*)f_8771},
{"f_8768:posixunix_scm",(void*)f_8768},
{"f_8751:posixunix_scm",(void*)f_8751},
{"f_8749:posixunix_scm",(void*)f_8749},
{"f_8827:posixunix_scm",(void*)f_8827},
{"f_8627:posixunix_scm",(void*)f_8627},
{"f_8639:posixunix_scm",(void*)f_8639},
{"f_8634:posixunix_scm",(void*)f_8634},
{"f_8629:posixunix_scm",(void*)f_8629},
{"f_8570:posixunix_scm",(void*)f_8570},
{"f_8582:posixunix_scm",(void*)f_8582},
{"f_8577:posixunix_scm",(void*)f_8577},
{"f_8572:posixunix_scm",(void*)f_8572},
{"f_8509:posixunix_scm",(void*)f_8509},
{"f_8564:posixunix_scm",(void*)f_8564},
{"f_8568:posixunix_scm",(void*)f_8568},
{"f_8530:posixunix_scm",(void*)f_8530},
{"f_8533:posixunix_scm",(void*)f_8533},
{"f_8544:posixunix_scm",(void*)f_8544},
{"f_8538:posixunix_scm",(void*)f_8538},
{"f_8511:posixunix_scm",(void*)f_8511},
{"f_8520:posixunix_scm",(void*)f_8520},
{"f_8451:posixunix_scm",(void*)f_8451},
{"f_8463:posixunix_scm",(void*)f_8463},
{"f_8494:posixunix_scm",(void*)f_8494},
{"f_8474:posixunix_scm",(void*)f_8474},
{"f_8490:posixunix_scm",(void*)f_8490},
{"f_8478:posixunix_scm",(void*)f_8478},
{"f_8486:posixunix_scm",(void*)f_8486},
{"f_8482:posixunix_scm",(void*)f_8482},
{"f_8457:posixunix_scm",(void*)f_8457},
{"f_8440:posixunix_scm",(void*)f_8440},
{"f_8444:posixunix_scm",(void*)f_8444},
{"f_8429:posixunix_scm",(void*)f_8429},
{"f_8433:posixunix_scm",(void*)f_8433},
{"f_8384:posixunix_scm",(void*)f_8384},
{"f_8388:posixunix_scm",(void*)f_8388},
{"f_8391:posixunix_scm",(void*)f_8391},
{"f_8394:posixunix_scm",(void*)f_8394},
{"f_8407:posixunix_scm",(void*)f_8407},
{"f_8411:posixunix_scm",(void*)f_8411},
{"f_8414:posixunix_scm",(void*)f_8414},
{"f_8417:posixunix_scm",(void*)f_8417},
{"f_8405:posixunix_scm",(void*)f_8405},
{"f_8368:posixunix_scm",(void*)f_8368},
{"f_8351:posixunix_scm",(void*)f_8351},
{"f_8364:posixunix_scm",(void*)f_8364},
{"f_8276:posixunix_scm",(void*)f_8276},
{"f_8337:posixunix_scm",(void*)f_8337},
{"f_8350:posixunix_scm",(void*)f_8350},
{"f_8317:posixunix_scm",(void*)f_8317},
{"f_8332:posixunix_scm",(void*)f_8332},
{"f_8326:posixunix_scm",(void*)f_8326},
{"f_8280:posixunix_scm",(void*)f_8280},
{"f_8282:posixunix_scm",(void*)f_8282},
{"f_8303:posixunix_scm",(void*)f_8303},
{"f_8297:posixunix_scm",(void*)f_8297},
{"f_8224:posixunix_scm",(void*)f_8224},
{"f_8231:posixunix_scm",(void*)f_8231},
{"f_8250:posixunix_scm",(void*)f_8250},
{"f_8254:posixunix_scm",(void*)f_8254},
{"f_8218:posixunix_scm",(void*)f_8218},
{"f_8209:posixunix_scm",(void*)f_8209},
{"f_8213:posixunix_scm",(void*)f_8213},
{"f_8182:posixunix_scm",(void*)f_8182},
{"f_8179:posixunix_scm",(void*)f_8179},
{"f_8176:posixunix_scm",(void*)f_8176},
{"f_8173:posixunix_scm",(void*)f_8173},
{"f_8098:posixunix_scm",(void*)f_8098},
{"f_8131:posixunix_scm",(void*)f_8131},
{"f_8125:posixunix_scm",(void*)f_8125},
{"f_8081:posixunix_scm",(void*)f_8081},
{"f_7902:posixunix_scm",(void*)f_7902},
{"f_8036:posixunix_scm",(void*)f_8036},
{"f_8031:posixunix_scm",(void*)f_8031},
{"f_7904:posixunix_scm",(void*)f_7904},
{"f_7914:posixunix_scm",(void*)f_7914},
{"f_7922:posixunix_scm",(void*)f_7922},
{"f_7968:posixunix_scm",(void*)f_7968},
{"f_7935:posixunix_scm",(void*)f_7935},
{"f_7960:posixunix_scm",(void*)f_7960},
{"f_7938:posixunix_scm",(void*)f_7938},
{"f_7894:posixunix_scm",(void*)f_7894},
{"f_7886:posixunix_scm",(void*)f_7886},
{"f_7848:posixunix_scm",(void*)f_7848},
{"f_7870:posixunix_scm",(void*)f_7870},
{"f_7874:posixunix_scm",(void*)f_7874},
{"f_7739:posixunix_scm",(void*)f_7739},
{"f_7745:posixunix_scm",(void*)f_7745},
{"f_7766:posixunix_scm",(void*)f_7766},
{"f_7840:posixunix_scm",(void*)f_7840},
{"f_7770:posixunix_scm",(void*)f_7770},
{"f_7773:posixunix_scm",(void*)f_7773},
{"f_7780:posixunix_scm",(void*)f_7780},
{"f_7782:posixunix_scm",(void*)f_7782},
{"f_7799:posixunix_scm",(void*)f_7799},
{"f_7809:posixunix_scm",(void*)f_7809},
{"f_7813:posixunix_scm",(void*)f_7813},
{"f_7760:posixunix_scm",(void*)f_7760},
{"f_7727:posixunix_scm",(void*)f_7727},
{"f_7731:posixunix_scm",(void*)f_7731},
{"f_7734:posixunix_scm",(void*)f_7734},
{"f_7692:posixunix_scm",(void*)f_7692},
{"f_7696:posixunix_scm",(void*)f_7696},
{"f_7716:posixunix_scm",(void*)f_7716},
{"f_7720:posixunix_scm",(void*)f_7720},
{"f_7673:posixunix_scm",(void*)f_7673},
{"f_7677:posixunix_scm",(void*)f_7677},
{"f_7646:posixunix_scm",(void*)f_7646},
{"f_7650:posixunix_scm",(void*)f_7650},
{"f_7627:posixunix_scm",(void*)f_7627},
{"f_7631:posixunix_scm",(void*)f_7631},
{"f_7634:posixunix_scm",(void*)f_7634},
{"f_7568:posixunix_scm",(void*)f_7568},
{"f_7572:posixunix_scm",(void*)f_7572},
{"f_7578:posixunix_scm",(void*)f_7578},
{"f_7565:posixunix_scm",(void*)f_7565},
{"f_7549:posixunix_scm",(void*)f_7549},
{"f_7541:posixunix_scm",(void*)f_7541},
{"f_7526:posixunix_scm",(void*)f_7526},
{"f_7530:posixunix_scm",(void*)f_7530},
{"f_7511:posixunix_scm",(void*)f_7511},
{"f_7515:posixunix_scm",(void*)f_7515},
{"f_7472:posixunix_scm",(void*)f_7472},
{"f_7489:posixunix_scm",(void*)f_7489},
{"f_7493:posixunix_scm",(void*)f_7493},
{"f_7410:posixunix_scm",(void*)f_7410},
{"f_7417:posixunix_scm",(void*)f_7417},
{"f_7439:posixunix_scm",(void*)f_7439},
{"f_7436:posixunix_scm",(void*)f_7436},
{"f_7426:posixunix_scm",(void*)f_7426},
{"f_7374:posixunix_scm",(void*)f_7374},
{"f_7381:posixunix_scm",(void*)f_7381},
{"f_7360:posixunix_scm",(void*)f_7360},
{"f_7351:posixunix_scm",(void*)f_7351},
{"f_7332:posixunix_scm",(void*)f_7332},
{"f_7326:posixunix_scm",(void*)f_7326},
{"f_7317:posixunix_scm",(void*)f_7317},
{"f_7282:posixunix_scm",(void*)f_7282},
{"f_7224:posixunix_scm",(void*)f_7224},
{"f_7228:posixunix_scm",(void*)f_7228},
{"f_7234:posixunix_scm",(void*)f_7234},
{"f_7253:posixunix_scm",(void*)f_7253},
{"f_7240:posixunix_scm",(void*)f_7240},
{"f_7140:posixunix_scm",(void*)f_7140},
{"f_7146:posixunix_scm",(void*)f_7146},
{"f_7150:posixunix_scm",(void*)f_7150},
{"f_7158:posixunix_scm",(void*)f_7158},
{"f_7184:posixunix_scm",(void*)f_7184},
{"f_7188:posixunix_scm",(void*)f_7188},
{"f_7176:posixunix_scm",(void*)f_7176},
{"f_7125:posixunix_scm",(void*)f_7125},
{"f_7133:posixunix_scm",(void*)f_7133},
{"f_7108:posixunix_scm",(void*)f_7108},
{"f_7119:posixunix_scm",(void*)f_7119},
{"f_7123:posixunix_scm",(void*)f_7123},
{"f_7082:posixunix_scm",(void*)f_7082},
{"f_7106:posixunix_scm",(void*)f_7106},
{"f_7089:posixunix_scm",(void*)f_7089},
{"f_7039:posixunix_scm",(void*)f_7039},
{"f_7046:posixunix_scm",(void*)f_7046},
{"f_7067:posixunix_scm",(void*)f_7067},
{"f_7063:posixunix_scm",(void*)f_7063},
{"f_7011:posixunix_scm",(void*)f_7011},
{"f_6989:posixunix_scm",(void*)f_6989},
{"f_6993:posixunix_scm",(void*)f_6993},
{"f_6974:posixunix_scm",(void*)f_6974},
{"f_6978:posixunix_scm",(void*)f_6978},
{"f_6959:posixunix_scm",(void*)f_6959},
{"f_6963:posixunix_scm",(void*)f_6963},
{"f_6941:posixunix_scm",(void*)f_6941},
{"f_6870:posixunix_scm",(void*)f_6870},
{"f_6889:posixunix_scm",(void*)f_6889},
{"f_6895:posixunix_scm",(void*)f_6895},
{"f_6831:posixunix_scm",(void*)f_6831},
{"f_6859:posixunix_scm",(void*)f_6859},
{"f_6855:posixunix_scm",(void*)f_6855},
{"f_6848:posixunix_scm",(void*)f_6848},
{"f_6575:posixunix_scm",(void*)f_6575},
{"f_6771:posixunix_scm",(void*)f_6771},
{"f_6766:posixunix_scm",(void*)f_6766},
{"f_6761:posixunix_scm",(void*)f_6761},
{"f_6577:posixunix_scm",(void*)f_6577},
{"f_6581:posixunix_scm",(void*)f_6581},
{"f_6687:posixunix_scm",(void*)f_6687},
{"f_6688:posixunix_scm",(void*)f_6688},
{"f_6705:posixunix_scm",(void*)f_6705},
{"f_6715:posixunix_scm",(void*)f_6715},
{"f_6673:posixunix_scm",(void*)f_6673},
{"f_6629:posixunix_scm",(void*)f_6629},
{"f_6665:posixunix_scm",(void*)f_6665},
{"f_6644:posixunix_scm",(void*)f_6644},
{"f_6654:posixunix_scm",(void*)f_6654},
{"f_6638:posixunix_scm",(void*)f_6638},
{"f_6633:posixunix_scm",(void*)f_6633},
{"f_6636:posixunix_scm",(void*)f_6636},
{"f_6583:posixunix_scm",(void*)f_6583},
{"f_6618:posixunix_scm",(void*)f_6618},
{"f_6599:posixunix_scm",(void*)f_6599},
{"f_6096:posixunix_scm",(void*)f_6096},
{"f_6500:posixunix_scm",(void*)f_6500},
{"f_6495:posixunix_scm",(void*)f_6495},
{"f_6490:posixunix_scm",(void*)f_6490},
{"f_6485:posixunix_scm",(void*)f_6485},
{"f_6098:posixunix_scm",(void*)f_6098},
{"f_6102:posixunix_scm",(void*)f_6102},
{"f_6108:posixunix_scm",(void*)f_6108},
{"f_6358:posixunix_scm",(void*)f_6358},
{"f_6364:posixunix_scm",(void*)f_6364},
{"f_6460:posixunix_scm",(void*)f_6460},
{"f_6450:posixunix_scm",(void*)f_6450},
{"f_6444:posixunix_scm",(void*)f_6444},
{"f_6366:posixunix_scm",(void*)f_6366},
{"f_6416:posixunix_scm",(void*)f_6416},
{"f_6373:posixunix_scm",(void*)f_6373},
{"f_6383:posixunix_scm",(void*)f_6383},
{"f_6282:posixunix_scm",(void*)f_6282},
{"f_6290:posixunix_scm",(void*)f_6290},
{"f_6292:posixunix_scm",(void*)f_6292},
{"f_6340:posixunix_scm",(void*)f_6340},
{"f_6273:posixunix_scm",(void*)f_6273},
{"f_6277:posixunix_scm",(void*)f_6277},
{"f_6252:posixunix_scm",(void*)f_6252},
{"f_6262:posixunix_scm",(void*)f_6262},
{"f_6240:posixunix_scm",(void*)f_6240},
{"f_6227:posixunix_scm",(void*)f_6227},
{"f_6231:posixunix_scm",(void*)f_6231},
{"f_6222:posixunix_scm",(void*)f_6222},
{"f_6225:posixunix_scm",(void*)f_6225},
{"f_6140:posixunix_scm",(void*)f_6140},
{"f_6152:posixunix_scm",(void*)f_6152},
{"f_6189:posixunix_scm",(void*)f_6189},
{"f_6198:posixunix_scm",(void*)f_6198},
{"f_6192:posixunix_scm",(void*)f_6192},
{"f_6168:posixunix_scm",(void*)f_6168},
{"f_6171:posixunix_scm",(void*)f_6171},
{"f_6132:posixunix_scm",(void*)f_6132},
{"f_6109:posixunix_scm",(void*)f_6109},
{"f_6113:posixunix_scm",(void*)f_6113},
{"f_6069:posixunix_scm",(void*)f_6069},
{"f_6076:posixunix_scm",(void*)f_6076},
{"f_6079:posixunix_scm",(void*)f_6079},
{"f_6024:posixunix_scm",(void*)f_6024},
{"f_6028:posixunix_scm",(void*)f_6028},
{"f_6063:posixunix_scm",(void*)f_6063},
{"f_6046:posixunix_scm",(void*)f_6046},
{"f_6010:posixunix_scm",(void*)f_6010},
{"f_6022:posixunix_scm",(void*)f_6022},
{"f_5996:posixunix_scm",(void*)f_5996},
{"f_6008:posixunix_scm",(void*)f_6008},
{"f_5981:posixunix_scm",(void*)f_5981},
{"f_5994:posixunix_scm",(void*)f_5994},
{"f_5944:posixunix_scm",(void*)f_5944},
{"f_5952:posixunix_scm",(void*)f_5952},
{"f_5919:posixunix_scm",(void*)f_5919},
{"f_5908:posixunix_scm",(void*)f_5908},
{"f_5912:posixunix_scm",(void*)f_5912},
{"f_5877:posixunix_scm",(void*)f_5877},
{"f_5901:posixunix_scm",(void*)f_5901},
{"f_5885:posixunix_scm",(void*)f_5885},
{"f_5888:posixunix_scm",(void*)f_5888},
{"f_5839:posixunix_scm",(void*)f_5839},
{"f_5872:posixunix_scm",(void*)f_5872},
{"f_5860:posixunix_scm",(void*)f_5860},
{"f_5868:posixunix_scm",(void*)f_5868},
{"f_5864:posixunix_scm",(void*)f_5864},
{"f_5820:posixunix_scm",(void*)f_5820},
{"f_5830:posixunix_scm",(void*)f_5830},
{"f_5824:posixunix_scm",(void*)f_5824},
{"f_5814:posixunix_scm",(void*)f_5814},
{"f_5808:posixunix_scm",(void*)f_5808},
{"f_5802:posixunix_scm",(void*)f_5802},
{"f_5778:posixunix_scm",(void*)f_5778},
{"f_5800:posixunix_scm",(void*)f_5800},
{"f_5796:posixunix_scm",(void*)f_5796},
{"f_5788:posixunix_scm",(void*)f_5788},
{"f_5748:posixunix_scm",(void*)f_5748},
{"f_5776:posixunix_scm",(void*)f_5776},
{"f_5772:posixunix_scm",(void*)f_5772},
{"f_5721:posixunix_scm",(void*)f_5721},
{"f_5746:posixunix_scm",(void*)f_5746},
{"f_5742:posixunix_scm",(void*)f_5742},
{"f_5657:posixunix_scm",(void*)f_5657},
{"f_5653:posixunix_scm",(void*)f_5653},
{"f_5673:posixunix_scm",(void*)f_5673},
{"f_5591:posixunix_scm",(void*)f_5591},
{"f_5595:posixunix_scm",(void*)f_5595},
{"f_5600:posixunix_scm",(void*)f_5600},
{"f_5616:posixunix_scm",(void*)f_5616},
{"f_5528:posixunix_scm",(void*)f_5528},
{"f_5586:posixunix_scm",(void*)f_5586},
{"f_5532:posixunix_scm",(void*)f_5532},
{"f_5535:posixunix_scm",(void*)f_5535},
{"f_5567:posixunix_scm",(void*)f_5567},
{"f_5538:posixunix_scm",(void*)f_5538},
{"f_5543:posixunix_scm",(void*)f_5543},
{"f_5557:posixunix_scm",(void*)f_5557},
{"f_5525:posixunix_scm",(void*)f_5525},
{"f_5450:posixunix_scm",(void*)f_5450},
{"f_5508:posixunix_scm",(void*)f_5508},
{"f_5457:posixunix_scm",(void*)f_5457},
{"f_5467:posixunix_scm",(void*)f_5467},
{"f_5471:posixunix_scm",(void*)f_5471},
{"f_5480:posixunix_scm",(void*)f_5480},
{"f_5484:posixunix_scm",(void*)f_5484},
{"f_5494:posixunix_scm",(void*)f_5494},
{"f_5475:posixunix_scm",(void*)f_5475},
{"f_5430:posixunix_scm",(void*)f_5430},
{"f_5442:posixunix_scm",(void*)f_5442},
{"f_5438:posixunix_scm",(void*)f_5438},
{"f_5416:posixunix_scm",(void*)f_5416},
{"f_5428:posixunix_scm",(void*)f_5428},
{"f_5424:posixunix_scm",(void*)f_5424},
{"f_5356:posixunix_scm",(void*)f_5356},
{"f_5402:posixunix_scm",(void*)f_5402},
{"f_5363:posixunix_scm",(void*)f_5363},
{"f_5373:posixunix_scm",(void*)f_5373},
{"f_5377:posixunix_scm",(void*)f_5377},
{"f_5381:posixunix_scm",(void*)f_5381},
{"f_5385:posixunix_scm",(void*)f_5385},
{"f_5389:posixunix_scm",(void*)f_5389},
{"f_5302:posixunix_scm",(void*)f_5302},
{"f_5335:posixunix_scm",(void*)f_5335},
{"f_5306:posixunix_scm",(void*)f_5306},
{"f_5313:posixunix_scm",(void*)f_5313},
{"f_5317:posixunix_scm",(void*)f_5317},
{"f_5321:posixunix_scm",(void*)f_5321},
{"f_5325:posixunix_scm",(void*)f_5325},
{"f_5329:posixunix_scm",(void*)f_5329},
{"f_5284:posixunix_scm",(void*)f_5284},
{"f_5269:posixunix_scm",(void*)f_5269},
{"f_5263:posixunix_scm",(void*)f_5263},
{"f_5231:posixunix_scm",(void*)f_5231},
{"f_5237:posixunix_scm",(void*)f_5237},
{"f_5207:posixunix_scm",(void*)f_5207},
{"f_5225:posixunix_scm",(void*)f_5225},
{"f_5214:posixunix_scm",(void*)f_5214},
{"f_5189:posixunix_scm",(void*)f_5189},
{"f_5199:posixunix_scm",(void*)f_5199},
{"f_5176:posixunix_scm",(void*)f_5176},
{"f_5167:posixunix_scm",(void*)f_5167},
{"f_5120:posixunix_scm",(void*)f_5120},
{"f_5124:posixunix_scm",(void*)f_5124},
{"f_5100:posixunix_scm",(void*)f_5100},
{"f_5104:posixunix_scm",(void*)f_5104},
{"f_5110:posixunix_scm",(void*)f_5110},
{"f_5114:posixunix_scm",(void*)f_5114},
{"f_5080:posixunix_scm",(void*)f_5080},
{"f_5084:posixunix_scm",(void*)f_5084},
{"f_5090:posixunix_scm",(void*)f_5090},
{"f_5094:posixunix_scm",(void*)f_5094},
{"f_5056:posixunix_scm",(void*)f_5056},
{"f_5060:posixunix_scm",(void*)f_5060},
{"f_5071:posixunix_scm",(void*)f_5071},
{"f_5075:posixunix_scm",(void*)f_5075},
{"f_5065:posixunix_scm",(void*)f_5065},
{"f_5032:posixunix_scm",(void*)f_5032},
{"f_5036:posixunix_scm",(void*)f_5036},
{"f_5047:posixunix_scm",(void*)f_5047},
{"f_5051:posixunix_scm",(void*)f_5051},
{"f_5041:posixunix_scm",(void*)f_5041},
{"f_5016:posixunix_scm",(void*)f_5016},
{"f_5020:posixunix_scm",(void*)f_5020},
{"f_5023:posixunix_scm",(void*)f_5023},
{"f_4980:posixunix_scm",(void*)f_4980},
{"f_5011:posixunix_scm",(void*)f_5011},
{"f_5001:posixunix_scm",(void*)f_5001},
{"f_4994:posixunix_scm",(void*)f_4994},
{"f_4944:posixunix_scm",(void*)f_4944},
{"f_4975:posixunix_scm",(void*)f_4975},
{"f_4965:posixunix_scm",(void*)f_4965},
{"f_4958:posixunix_scm",(void*)f_4958},
{"f_4929:posixunix_scm",(void*)f_4929},
{"f_4942:posixunix_scm",(void*)f_4942},
{"f_4923:posixunix_scm",(void*)f_4923},
{"f_4911:posixunix_scm",(void*)f_4911},
{"f_4594:posixunix_scm",(void*)f_4594},
{"f_4901:posixunix_scm",(void*)f_4901},
{"f_4721:posixunix_scm",(void*)f_4721},
{"f_4887:posixunix_scm",(void*)f_4887},
{"f_4876:posixunix_scm",(void*)f_4876},
{"f_4883:posixunix_scm",(void*)f_4883},
{"f_4740:posixunix_scm",(void*)f_4740},
{"f_4869:posixunix_scm",(void*)f_4869},
{"f_4848:posixunix_scm",(void*)f_4848},
{"f_4865:posixunix_scm",(void*)f_4865},
{"f_4854:posixunix_scm",(void*)f_4854},
{"f_4861:posixunix_scm",(void*)f_4861},
{"f_4784:posixunix_scm",(void*)f_4784},
{"f_4845:posixunix_scm",(void*)f_4845},
{"f_4824:posixunix_scm",(void*)f_4824},
{"f_4841:posixunix_scm",(void*)f_4841},
{"f_4830:posixunix_scm",(void*)f_4830},
{"f_4837:posixunix_scm",(void*)f_4837},
{"f_4797:posixunix_scm",(void*)f_4797},
{"f_4821:posixunix_scm",(void*)f_4821},
{"f_4817:posixunix_scm",(void*)f_4817},
{"f_4778:posixunix_scm",(void*)f_4778},
{"f_4747:posixunix_scm",(void*)f_4747},
{"f_4765:posixunix_scm",(void*)f_4765},
{"f_4750:posixunix_scm",(void*)f_4750},
{"f_4754:posixunix_scm",(void*)f_4754},
{"f_4734:posixunix_scm",(void*)f_4734},
{"f_4715:posixunix_scm",(void*)f_4715},
{"f_4601:posixunix_scm",(void*)f_4601},
{"f_4608:posixunix_scm",(void*)f_4608},
{"f_4610:posixunix_scm",(void*)f_4610},
{"f_4617:posixunix_scm",(void*)f_4617},
{"f_4681:posixunix_scm",(void*)f_4681},
{"f_4690:posixunix_scm",(void*)f_4690},
{"f_4678:posixunix_scm",(void*)f_4678},
{"f_4623:posixunix_scm",(void*)f_4623},
{"f_4659:posixunix_scm",(void*)f_4659},
{"f_4655:posixunix_scm",(void*)f_4655},
{"f_4651:posixunix_scm",(void*)f_4651},
{"f_4640:posixunix_scm",(void*)f_4640},
{"f_4636:posixunix_scm",(void*)f_4636},
{"f_4538:posixunix_scm",(void*)f_4538},
{"f_4547:posixunix_scm",(void*)f_4547},
{"f_4571:posixunix_scm",(void*)f_4571},
{"f_4583:posixunix_scm",(void*)f_4583},
{"f_4589:posixunix_scm",(void*)f_4589},
{"f_4577:posixunix_scm",(void*)f_4577},
{"f_4553:posixunix_scm",(void*)f_4553},
{"f_4559:posixunix_scm",(void*)f_4559},
{"f_4545:posixunix_scm",(void*)f_4545},
{"f_4527:posixunix_scm",(void*)f_4527},
{"f_4522:posixunix_scm",(void*)f_4522},
{"f_4481:posixunix_scm",(void*)f_4481},
{"f_4494:posixunix_scm",(void*)f_4494},
{"f_4458:posixunix_scm",(void*)f_4458},
{"f_4479:posixunix_scm",(void*)f_4479},
{"f_4465:posixunix_scm",(void*)f_4465},
{"f_4304:posixunix_scm",(void*)f_4304},
{"f_4409:posixunix_scm",(void*)f_4409},
{"f_4417:posixunix_scm",(void*)f_4417},
{"f_4404:posixunix_scm",(void*)f_4404},
{"f_4306:posixunix_scm",(void*)f_4306},
{"f_4313:posixunix_scm",(void*)f_4313},
{"f_4316:posixunix_scm",(void*)f_4316},
{"f_4319:posixunix_scm",(void*)f_4319},
{"f_4403:posixunix_scm",(void*)f_4403},
{"f_4323:posixunix_scm",(void*)f_4323},
{"f_4337:posixunix_scm",(void*)f_4337},
{"f_4347:posixunix_scm",(void*)f_4347},
{"f_4350:posixunix_scm",(void*)f_4350},
{"f_4353:posixunix_scm",(void*)f_4353},
{"f_4359:posixunix_scm",(void*)f_4359},
{"f_4369:posixunix_scm",(void*)f_4369},
{"f_4280:posixunix_scm",(void*)f_4280},
{"f_4302:posixunix_scm",(void*)f_4302},
{"f_4298:posixunix_scm",(void*)f_4298},
{"f_4256:posixunix_scm",(void*)f_4256},
{"f_4278:posixunix_scm",(void*)f_4278},
{"f_4274:posixunix_scm",(void*)f_4274},
{"f_4161:posixunix_scm",(void*)f_4161},
{"f_4242:posixunix_scm",(void*)f_4242},
{"f_4228:posixunix_scm",(void*)f_4228},
{"f_4176:posixunix_scm",(void*)f_4176},
{"f_4181:posixunix_scm",(void*)f_4181},
{"f_4204:posixunix_scm",(void*)f_4204},
{"f_4224:posixunix_scm",(void*)f_4224},
{"f_4187:posixunix_scm",(void*)f_4187},
{"f_4201:posixunix_scm",(void*)f_4201},
{"f_4099:posixunix_scm",(void*)f_4099},
{"f_4112:posixunix_scm",(void*)f_4112},
{"f_4124:posixunix_scm",(void*)f_4124},
{"f_4118:posixunix_scm",(void*)f_4118},
{"f_4089:posixunix_scm",(void*)f_4089},
{"f_4096:posixunix_scm",(void*)f_4096},
{"f_4078:posixunix_scm",(void*)f_4078},
{"f_4085:posixunix_scm",(void*)f_4085},
{"f_4068:posixunix_scm",(void*)f_4068},
{"f_4075:posixunix_scm",(void*)f_4075},
{"f_4058:posixunix_scm",(void*)f_4058},
{"f_4065:posixunix_scm",(void*)f_4065},
{"f_4049:posixunix_scm",(void*)f_4049},
{"f_4056:posixunix_scm",(void*)f_4056},
{"f_4040:posixunix_scm",(void*)f_4040},
{"f_4047:posixunix_scm",(void*)f_4047},
{"f_4031:posixunix_scm",(void*)f_4031},
{"f_4038:posixunix_scm",(void*)f_4038},
{"f_4022:posixunix_scm",(void*)f_4022},
{"f_4029:posixunix_scm",(void*)f_4029},
{"f_4016:posixunix_scm",(void*)f_4016},
{"f_4020:posixunix_scm",(void*)f_4020},
{"f_4010:posixunix_scm",(void*)f_4010},
{"f_4014:posixunix_scm",(void*)f_4014},
{"f_4004:posixunix_scm",(void*)f_4004},
{"f_4008:posixunix_scm",(void*)f_4008},
{"f_3998:posixunix_scm",(void*)f_3998},
{"f_4002:posixunix_scm",(void*)f_4002},
{"f_3992:posixunix_scm",(void*)f_3992},
{"f_3996:posixunix_scm",(void*)f_3996},
{"f_3986:posixunix_scm",(void*)f_3986},
{"f_3990:posixunix_scm",(void*)f_3990},
{"f_3961:posixunix_scm",(void*)f_3961},
{"f_3965:posixunix_scm",(void*)f_3965},
{"f_3924:posixunix_scm",(void*)f_3924},
{"f_3956:posixunix_scm",(void*)f_3956},
{"f_3949:posixunix_scm",(void*)f_3949},
{"f_3928:posixunix_scm",(void*)f_3928},
{"f_3732:posixunix_scm",(void*)f_3732},
{"f_3905:posixunix_scm",(void*)f_3905},
{"f_3748:posixunix_scm",(void*)f_3748},
{"f_3879:posixunix_scm",(void*)f_3879},
{"f_3754:posixunix_scm",(void*)f_3754},
{"f_3757:posixunix_scm",(void*)f_3757},
{"f_3839:posixunix_scm",(void*)f_3839},
{"f_3837:posixunix_scm",(void*)f_3837},
{"f_3796:posixunix_scm",(void*)f_3796},
{"f_3814:posixunix_scm",(void*)f_3814},
{"f_3812:posixunix_scm",(void*)f_3812},
{"f_3800:posixunix_scm",(void*)f_3800},
{"f_3730:posixunix_scm",(void*)f_3730},
{"f_3728:posixunix_scm",(void*)f_3728},
{"f_3726:posixunix_scm",(void*)f_3726},
{"f_3694:posixunix_scm",(void*)f_3694},
{"f_3701:posixunix_scm",(void*)f_3701},
{"f_3707:posixunix_scm",(void*)f_3707},
{"f_3714:posixunix_scm",(void*)f_3714},
{"f_3655:posixunix_scm",(void*)f_3655},
{"f_3662:posixunix_scm",(void*)f_3662},
{"f_3671:posixunix_scm",(void*)f_3671},
{"f_3613:posixunix_scm",(void*)f_3613},
{"f_3623:posixunix_scm",(void*)f_3623},
{"f_3626:posixunix_scm",(void*)f_3626},
{"f_3629:posixunix_scm",(void*)f_3629},
{"f_3598:posixunix_scm",(void*)f_3598},
{"f_3560:posixunix_scm",(void*)f_3560},
{"f_3590:posixunix_scm",(void*)f_3590},
{"f_3577:posixunix_scm",(void*)f_3577},
{"f_3580:posixunix_scm",(void*)f_3580},
{"f_3521:posixunix_scm",(void*)f_3521},
{"f_3480:posixunix_scm",(void*)f_3480},
{"f_3477:posixunix_scm",(void*)f_3477},
{"f_3459:posixunix_scm",(void*)f_3459},
{"f_3463:posixunix_scm",(void*)f_3463},
{"f_3474:posixunix_scm",(void*)f_3474},
{"f_3470:posixunix_scm",(void*)f_3470},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
