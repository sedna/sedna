/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:40
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: setup-api.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature chicken-compile-shared -dynamic -emit-import-library setup-api -ignore-repository -output-file setup-api.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 regex utils posix srfi_13 extras ports data_structures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[318];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,49,49,56,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,25),40,115,101,116,117,112,45,97,112,105,35,99,114,111,115,115,45,99,104,105,99,107,101,110,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,49,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,108,111,111,112,32,100,105,114,49,54,56,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,27),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,45,48,32,100,105,114,49,54,52,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,49,55,55,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,15),40,102,95,52,56,49,54,32,100,105,114,49,56,49,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,15),40,102,95,52,56,50,52,32,100,105,114,49,56,52,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,7),40,97,50,48,48,56,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,121,101,115,45,111,114,45,110,111,63,32,115,116,114,49,57,54,32,46,32,116,109,112,49,57,53,49,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,7),40,97,50,48,52,51,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,50,48,51,51,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,50,51,55,32,114,120,50,51,56,32,115,117,98,115,116,50,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,102,105,120,109,97,107,101,116,97,114,103,101,116,32,102,105,108,101,50,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,15),40,115,109,111,111,116,104,32,108,115,116,50,56,52,41,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,50,50,50,54,32,99,109,100,50,56,56,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,50,56,49,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,102,111,114,109,45,101,114,114,111,114,32,115,51,57,52,32,112,51,57,53,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,108,105,110,101,45,101,114,114,111,114,32,115,51,57,56,32,112,51,57,57,32,110,52,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,50,53,56,55,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,14),40,97,50,53,56,49,32,101,120,110,53,55,48,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,50,54,49,54,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,50,54,51,49,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,20),40,97,50,54,50,53,32,46,32,97,114,103,115,53,54,52,53,55,54,41,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,50,54,49,48,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,15),40,97,50,53,55,53,32,107,53,54,51,53,54,56,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,14),40,97,50,54,55,50,32,100,101,112,53,51,56,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,12),40,97,50,55,48,49,32,100,53,50,57,41,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,13),40,109,97,116,99,104,63,32,115,51,55,49,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,105,110,101,115,51,55,54,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,102,95,50,53,50,49,32,115,53,49,48,32,105,110,100,101,110,116,53,49,49,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,15),40,97,50,55,52,52,32,105,116,101,109,53,57,55,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,12),40,97,50,55,55,54,32,102,53,57,51,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,97,50,52,49,52,32,100,101,112,52,54,51,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,97,50,51,52,53,32,108,105,110,101,52,50,49,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,109,97,107,101,47,112,114,111,99,47,104,101,108,112,101,114,32,115,112,101,99,53,48,48,32,97,114,103,118,53,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,47,112,114,111,99,32,103,54,48,55,54,48,56,54,49,57,32,46,32,114,118,97,114,54,48,57,54,50,48,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,7),40,97,50,57,52,52,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,97,50,57,53,51,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,55,50,53,32,102,105,108,101,115,55,50,54,32,105,110,102,111,55,50,55,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,55,57,57,32,101,114,114,56,48,57,32,112,114,101,102,105,120,56,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,112,114,101,102,105,120,56,48,50,32,37,101,114,114,55,57,55,56,52,50,41,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,114,114,56,48,49,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,55,56,56,32,116,111,55,56,57,32,46,32,116,109,112,55,56,55,55,57,48,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,56,53,54,32,116,111,56,53,55,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,56,55,48,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,56,55,57,32,102,105,108,101,56,56,48,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,12),40,97,51,50,51,57,32,102,56,56,53,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,56,56,51,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,13),40,97,51,51,57,48,32,102,49,48,50,56,41,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,13),40,97,51,52,51,52,32,102,49,48,49,57,41,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,97,51,52,53,53,32,102,57,54,52,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,56),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,57,52,48,32,102,105,108,101,115,57,52,49,32,46,32,116,109,112,57,51,57,57,52,50,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,13),40,101,120,105,102,121,32,102,49,48,54,57,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,13),40,97,51,54,54,49,32,102,49,48,56,52,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,97,51,55,48,56,32,102,49,48,56,48,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,49,48,53,50,32,102,105,108,101,115,49,48,53,51,32,46,32,116,109,112,49,48,53,49,49,48,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,13),40,97,51,56,51,49,32,102,49,49,51,52,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,49,48,57,32,102,105,108,101,115,49,49,49,48,32,46,32,116,109,112,49,49,48,56,49,49,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,49,54,54,49,49,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,49,56,53,41,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,7),40,97,52,49,48,55,41,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,7),40,97,52,49,49,51,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,52,49,49,54,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,7),40,97,52,49,50,50,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,52,49,50,53,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,52,49,50,56,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,50,49,49,32,46,32,116,109,112,49,50,49,48,49,50,49,50,41,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,99,104,105,99,107,101,110,45,118,101,114,115,105,111,110,32,118,49,50,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,117,112,103,114,97,100,101,45,109,101,115,115,97,103,101,32,101,120,116,49,50,54,51,32,109,115,103,49,50,54,52,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,50,55,49,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,97,114,103,115,49,50,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,51,48,56,32,112,114,111,99,49,51,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,51,49,50,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,13),40,97,52,51,48,54,32,120,49,51,50,49,41,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,51,49,57,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,51,51,49,32,112,50,49,51,51,50,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,51,49,53,32,118,50,49,51,49,54,41,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,52,49,50,49,52,49,51,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,29),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,52,51,48,41,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,38),40,115,101,116,117,112,45,97,112,105,35,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,13),40,97,52,54,51,50,32,102,49,53,48,54,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,53,48,50,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,52,56,48,32,46,32,116,109,112,49,52,55,57,49,52,56,49,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,53,50,50,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,53,51,49,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,51,57,52,41,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,13),40,97,52,55,51,56,32,120,49,51,55,52,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1721)
static void C_ccall f_1721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1725)
static void C_ccall f_1725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_ccall f_4855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1749)
static void C_ccall f_1749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_fcall f_1752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4739)
static void C_ccall f_4739(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4755)
static void C_fcall f_4755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4792)
static void C_ccall f_4792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4785)
static void C_ccall f_4785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_fcall f_4762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4463)
static void C_ccall f_4463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_fcall f_4717(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4625)
static void C_ccall f_4625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4633)
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4628)
static void C_ccall f_4628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4540)
static void C_fcall f_4540(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_fcall f_4545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_ccall f_4572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4564)
static void C_ccall f_4564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4519)
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4479)
static void C_ccall f_4479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_fcall f_4301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4171)
static void C_fcall f_4171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4184)
static void C_fcall f_4184(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_ccall f_4196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_fcall f_4202(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4230)
static void C_ccall f_4230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4217)
static void C_fcall f_4217(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_fcall f_4155(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4123)
static void C_ccall f_4123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4039)
static void C_ccall f_4039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4042)
static void C_ccall f_4042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4048)
static void C_ccall f_4048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4085)
static void C_ccall f_4085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3970)
static void C_fcall f_3970(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_fcall f_3915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3935)
static void C_ccall f_3935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3779)
static void C_ccall f_3779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3783)
static void C_ccall f_3783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3792)
static void C_ccall f_3792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_ccall f_3795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_ccall f_3798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3801)
static void C_ccall f_3801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3745)
static void C_ccall f_3745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_fcall f_3628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_fcall f_3298(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3585)
static void C_ccall f_3585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_fcall f_3556(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_ccall f_3575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3487)
static void C_fcall f_3487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3430)
static void C_ccall f_3430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_fcall f_3234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3240)
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3256)
static void C_fcall f_3256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_fcall f_3209(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3169)
static void C_ccall f_3169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3084)
static void C_fcall f_3084(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_fcall f_3075(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_fcall f_2984(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3048)
static void C_fcall f_3048(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2868)
static void C_fcall f_2868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_ccall f_2884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_fcall f_2500(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_fcall f_2504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2356)
static void C_ccall f_2356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2415)
static void C_ccall f_2415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2519)
static void C_ccall f_2519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2772)
static void C_ccall f_2772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2257)
static void C_fcall f_2257(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2270)
static void C_fcall f_2270(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2677)
static void C_ccall f_2677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2646)
static void C_ccall f_2646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2606)
static void C_ccall f_2606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_fcall f_2312(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2302)
static void C_fcall f_2302(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_fcall f_2170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_fcall f_2177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2098)
static void C_ccall f_2098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2087)
static void C_ccall f_2087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_fcall f_2050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_fcall f_1947(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_fcall f_1963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4839)
static void C_ccall f_4839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_fcall f_1916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_fcall f_1884(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1890)
static void C_fcall f_1890(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_fcall f_1897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1833)
static void C_fcall f_1833(C_word t0) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1752)
static void C_fcall trf_1752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1752(t0,t1);}

C_noret_decl(trf_4755)
static void C_fcall trf_4755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4755(t0,t1);}

C_noret_decl(trf_4762)
static void C_fcall trf_4762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4762(t0,t1);}

C_noret_decl(trf_4717)
static void C_fcall trf_4717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4717(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4717(t0,t1);}

C_noret_decl(trf_4621)
static void C_fcall trf_4621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4621(t0,t1,t2);}

C_noret_decl(trf_4540)
static void C_fcall trf_4540(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4540(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4540(t0,t1);}

C_noret_decl(trf_4545)
static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4545(t0,t1);}

C_noret_decl(trf_4335)
static void C_fcall trf_4335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4335(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4335(t0,t1,t2,t3);}

C_noret_decl(trf_4301)
static void C_fcall trf_4301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4301(t0,t1);}

C_noret_decl(trf_4171)
static void C_fcall trf_4171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4171(t0,t1,t2);}

C_noret_decl(trf_4184)
static void C_fcall trf_4184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4184(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4184(t0,t1);}

C_noret_decl(trf_4202)
static void C_fcall trf_4202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4202(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4202(t0,t1);}

C_noret_decl(trf_4217)
static void C_fcall trf_4217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4217(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4217(t0,t1);}

C_noret_decl(trf_4155)
static void C_fcall trf_4155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4155(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4155(t0,t1,t2);}

C_noret_decl(trf_3970)
static void C_fcall trf_3970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3970(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3970(t0,t1);}

C_noret_decl(trf_3915)
static void C_fcall trf_3915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3915(t0,t1);}

C_noret_decl(trf_3628)
static void C_fcall trf_3628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3628(t0,t1);}

C_noret_decl(trf_3298)
static void C_fcall trf_3298(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3298(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3298(t0,t1);}

C_noret_decl(trf_3556)
static void C_fcall trf_3556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3556(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3556(t0,t1);}

C_noret_decl(trf_3487)
static void C_fcall trf_3487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3487(t0,t1);}

C_noret_decl(trf_3234)
static void C_fcall trf_3234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3234(t0,t1);}

C_noret_decl(trf_3256)
static void C_fcall trf_3256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3256(t0,t1);}

C_noret_decl(trf_3209)
static void C_fcall trf_3209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3209(t0,t1,t2);}

C_noret_decl(trf_3084)
static void C_fcall trf_3084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3084(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3084(t0,t1);}

C_noret_decl(trf_3075)
static void C_fcall trf_3075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3075(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3075(t0,t1,t2);}

C_noret_decl(trf_2984)
static void C_fcall trf_2984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2984(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2984(t0,t1,t2,t3);}

C_noret_decl(trf_3048)
static void C_fcall trf_3048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3048(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3048(t0,t1);}

C_noret_decl(trf_2868)
static void C_fcall trf_2868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2868(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2868(t0,t1,t2,t3);}

C_noret_decl(trf_2500)
static void C_fcall trf_2500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2500(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2500(t0,t1,t2);}

C_noret_decl(trf_2504)
static void C_fcall trf_2504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2504(t0,t1);}

C_noret_decl(trf_2257)
static void C_fcall trf_2257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2257(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2257(t0,t1,t2);}

C_noret_decl(trf_2270)
static void C_fcall trf_2270(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2270(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2270(t0,t1);}

C_noret_decl(trf_2312)
static void C_fcall trf_2312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2312(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2312(t0,t1,t2,t3);}

C_noret_decl(trf_2302)
static void C_fcall trf_2302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2302(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2302(t0,t1,t2);}

C_noret_decl(trf_2170)
static void C_fcall trf_2170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2170(t0,t1);}

C_noret_decl(trf_2177)
static void C_fcall trf_2177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2177(t0,t1);}

C_noret_decl(trf_2050)
static void C_fcall trf_2050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2050(t0,t1);}

C_noret_decl(trf_1947)
static void C_fcall trf_1947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1947(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1947(t0,t1);}

C_noret_decl(trf_1963)
static void C_fcall trf_1963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1963(t0,t1);}

C_noret_decl(trf_1916)
static void C_fcall trf_1916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1916(t0,t1);}

C_noret_decl(trf_1884)
static void C_fcall trf_1884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1884(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1884(t0,t1,t2);}

C_noret_decl(trf_1890)
static void C_fcall trf_1890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1890(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1890(t0,t1,t2);}

C_noret_decl(trf_1897)
static void C_fcall trf_1897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1897(t0,t1);}

C_noret_decl(trf_1833)
static void C_fcall trf_1833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1833(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1833(t0);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1392)){
C_save(t1);
C_rereclaim2(1392*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,318);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[15]=C_h_intern(&lf[15],24,"setup-api#host-extension");
lf[18]=C_h_intern(&lf[18],24,"setup-api#chicken-prefix");
lf[19]=C_h_intern(&lf[19],19,"setup-api#shellpath");
lf[20]=C_h_intern(&lf[20],2,"qs");
lf[21]=C_h_intern(&lf[21],18,"normalize-pathname");
lf[22]=C_h_intern(&lf[22],23,"setup-api#cross-chicken");
lf[24]=C_h_intern(&lf[24],30,"setup-api#setup-root-directory");
lf[25]=C_h_intern(&lf[25],28,"setup-api#setup-verbose-mode");
lf[26]=C_h_intern(&lf[26],28,"setup-api#setup-install-mode");
lf[27]=C_h_intern(&lf[27],28,"setup-api#setup-verbose-flag");
lf[28]=C_h_intern(&lf[28],28,"setup-api#setup-install-flag");
lf[29]=C_h_intern(&lf[29],22,"setup-api#program-path");
lf[30]=C_h_intern(&lf[30],28,"setup-api#keep-intermediates");
lf[37]=C_h_intern(&lf[37],4,"copy");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[39]=C_h_intern(&lf[39],4,"move");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[44]=C_h_intern(&lf[44],2,"mv");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[47]=C_h_intern(&lf[47],22,"setup-api#sudo-install");
lf[48]=C_h_intern(&lf[48],5,"print");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo cp -r");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo rm -fr");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\007sudo mv");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo chmod");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo ranlib");
lf[55]=C_h_intern(&lf[55],16,"create-directory");
lf[56]=C_h_intern(&lf[56],18,"pathname-directory");
lf[57]=C_h_intern(&lf[57],10,"directory\077");
lf[58]=C_h_intern(&lf[58],6,"printf");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\035  creating directory `~a\047~%~!");
lf[61]=C_h_intern(&lf[61],7,"sprintf");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\013mkdir -p ~a");
lf[63]=C_h_intern(&lf[63],34,"setup-api#create-directory/parents");
lf[64]=C_h_intern(&lf[64],21,"setup-api#abort-setup");
lf[65]=C_h_intern(&lf[65],20,"setup-api#yes-or-no\077");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000(~%Please enter \042yes\042, \042no\042 or \042abort\042.~%");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[72]=C_h_intern(&lf[72],9,"read-line");
lf[73]=C_h_intern(&lf[73],12,"flush-output");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\005[~A] ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\024~%~A (yes/no/abort) ");
lf[76]=C_h_intern(&lf[76],15,"\003sysget-keyword");
lf[77]=C_h_intern(&lf[77],6,"\000abort");
lf[78]=C_h_intern(&lf[78],8,"\000default");
lf[79]=C_h_intern(&lf[79],15,"setup-api#patch");
lf[80]=C_h_intern(&lf[80],10,"write-line");
lf[81]=C_h_intern(&lf[81],17,"string-substitute");
lf[82]=C_h_intern(&lf[82],20,"with-input-from-file");
lf[83]=C_h_intern(&lf[83],19,"with-output-to-file");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\010~A ~A ~A");
lf[85]=C_h_intern(&lf[85],21,"create-temporary-file");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\021patching ~A ...~%");
lf[87]=C_h_intern(&lf[87],21,"setup-api#run-verbose");
lf[89]=C_h_intern(&lf[89],26,"pathname-replace-extension");
lf[90]=C_h_intern(&lf[90],26,"\003sysload-dynamic-extension");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[93]=C_h_intern(&lf[93],18,"pathname-extension");
lf[94]=C_h_intern(&lf[94],17,"setup-api#execute");
lf[95]=C_h_intern(&lf[95],18,"string-intersperse");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_h_intern(&lf[103],5,"cons*");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[106]=C_h_intern(&lf[106],13,"make-pathname");
lf[107]=C_h_intern(&lf[107],7,"\003sysmap");
lf[108]=C_h_intern(&lf[108],8,"->string");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\010  ~A~%~!");
lf[110]=C_h_intern(&lf[110],12,"\003sysfor-each");
lf[112]=C_h_intern(&lf[112],5,"error");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\006~a: ~s");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\023~a: ~s for line: ~a");
lf[117]=C_h_intern(&lf[117],6,"signal");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\035make: Failed to make ~a: ~a~%");
lf[119]=C_h_intern(&lf[119],22,"with-exception-handler");
lf[120]=C_h_intern(&lf[120],30,"call-with-current-continuation");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\025make: ~amaking ~a~a~%");
lf[122]=C_h_intern(&lf[122],13,"string-append");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\010 changed");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000# just because (reason: ~a date: ~a)");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\017 does not exist");
lf[128]=C_h_intern(&lf[128],22,"file-modification-time");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\034dependancy ~a was not made~%");
lf[130]=C_h_intern(&lf[130],12,"file-exists\077");
lf[131]=C_h_intern(&lf[131],3,"any");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\031don\047t know how to make ~a");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\025make: ~achecking ~a~%");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\017make: made ~a~%");
lf[136]=C_h_intern(&lf[136],7,"reverse");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[139]=C_h_intern(&lf[139],4,"caar");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[141]=C_h_intern(&lf[141],27,"condition-property-accessor");
lf[142]=C_h_intern(&lf[142],3,"exn");
lf[143]=C_h_intern(&lf[143],7,"message");
lf[144]=C_h_intern(&lf[144],19,"condition-predicate");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\047argument is not a string or string list");
lf[146]=C_h_intern(&lf[146],5,"every");
lf[147]=C_h_intern(&lf[147],7,"string\077");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000#command part of line is not a thunk");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\037dependency item is not a string");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000!second part of line is not a list");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\0004line does not start with a string or list of strings");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000$list is not a list with 2 or 3 parts");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\036specification is an empty list");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\033specification is not a list");
lf[155]=C_h_intern(&lf[155],12,"vector->list");
lf[156]=C_h_intern(&lf[156],19,"setup-api#make/proc");
lf[157]=C_h_intern(&lf[157],9,"\003syserror");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\0000no matching clause in call to \047case-lambda\047 form");
lf[159]=C_h_intern(&lf[159],29,"setup-api#installation-prefix");
lf[161]=C_h_intern(&lf[161],5,"files");
lf[162]=C_h_intern(&lf[162],3,"a+r");
lf[163]=C_h_intern(&lf[163],2,"pp");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[165]=C_h_intern(&lf[165],15,"repository-path");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\033writing info ~A -> ~S ...~%");
lf[168]=C_h_intern(&lf[168],10,"\003sysappend");
lf[169]=C_h_intern(&lf[169],19,"setup-api#copy-file");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[171]=C_h_intern(&lf[171],7,"warning");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[173]=C_h_intern(&lf[173],5,"glob\077");
lf[175]=C_h_intern(&lf[175],14,"string-prefix\077");
lf[176]=C_h_intern(&lf[176],19,"setup-api#move-file");
lf[177]=C_h_intern(&lf[177],22,"setup-api#remove-file*");
lf[179]=C_h_intern(&lf[179],18,"absolute-pathname\077");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[182]=C_h_intern(&lf[182],27,"setup-api#install-extension");
lf[183]=C_h_intern(&lf[183],13,"documentation");
lf[184]=C_h_intern(&lf[184],8,"examples");
lf[185]=C_h_intern(&lf[185],7,"newline");
lf[186]=C_h_intern(&lf[186],4,"a+rx");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\037\012* Installing example files in ");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000%\012* Installing documentation files in ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\021share/chicken/doc");
lf[192]=C_h_intern(&lf[192],6,"static");
lf[193]=C_h_intern(&lf[193],6,"macosx");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[195]=C_h_intern(&lf[195],16,"software-version");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[197]=C_h_intern(&lf[197],25,"setup-api#install-program");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[204]=C_h_intern(&lf[204],24,"setup-api#install-script");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\016lib/chicken/~a");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[209]=C_h_intern(&lf[209],3,"a+x");
lf[210]=C_h_intern(&lf[210],21,"setup-api#try-compile");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\005~A ~A");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[214]=C_h_intern(&lf[214],6,"system");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[220]=C_h_intern(&lf[220],4,"conc");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[231]=C_h_intern(&lf[231],7,"display");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[234]=C_h_intern(&lf[234],13,"\000compile-only");
lf[235]=C_h_intern(&lf[235],5,"\000verb");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[237]=C_h_intern(&lf[237],8,"\000ldflags");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[239]=C_h_intern(&lf[239],7,"\000cflags");
lf[240]=C_h_intern(&lf[240],3,"\000cc");
lf[241]=C_h_intern(&lf[241],4,"\000c++");
lf[242]=C_h_intern(&lf[242],34,"setup-api#required-chicken-version");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000(CHICKEN version ~a or higher is required");
lf[244]=C_h_intern(&lf[244],20,"setup-api#version>=\077");
lf[245]=C_h_intern(&lf[245],15,"chicken-version");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000uthe required extension `~s\047 ~a - please run~%~%  chicken-install ~a~%~%and "
"repeat the current installation operation.");
lf[248]=C_h_intern(&lf[248],36,"setup-api#required-extension-version");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\0007is older than ~a, which is what this extension requires");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000%has no associated version information");
lf[251]=C_h_intern(&lf[251],7,"version");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\020is not installed");
lf[253]=C_h_intern(&lf[253],21,"extension-information");
lf[254]=C_h_intern(&lf[254],30,"required-extension-information");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\023bad argument format");
lf[256]=C_h_intern(&lf[256],22,"setup-api#test-compile");
lf[257]=C_h_intern(&lf[257],22,"setup-api#find-library");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000T#ifdef __cplusplus~%extern \042C\042~%#endif~%char ~a();~%int main() { ~a(); retu"
"rn 0; }~%");
lf[260]=C_h_intern(&lf[260],21,"setup-api#find-header");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\047#include <~a>\012int main() { return 0; }\012");
lf[262]=C_h_intern(&lf[262],19,"string-split-fields");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[264]=C_h_intern(&lf[264],6,"\000infix");
lf[265]=C_h_intern(&lf[265],8,"string>\077");
lf[266]=C_h_intern(&lf[266],36,"setup-api#extension-name-and-version");
lf[267]=C_h_intern(&lf[267],24,"setup-api#extension-name");
lf[268]=C_h_intern(&lf[268],27,"setup-api#extension-version");
lf[269]=C_h_intern(&lf[269],12,"string-null\077");
lf[270]=C_h_intern(&lf[270],19,"setup-api#read-info");
lf[271]=C_h_intern(&lf[271],4,"read");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\013.setup-info");
lf[273]=C_h_intern(&lf[273],36,"setup-api#create-temporary-directory");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install-");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[277]=C_h_intern(&lf[277],24,"get-environment-variable");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[281]=C_h_intern(&lf[281],26,"setup-api#remove-directory");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\016sudo rm -fr ~a");
lf[283]=C_h_intern(&lf[283],16,"delete-directory");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[286]=C_h_intern(&lf[286],11,"delete-file");
lf[287]=C_h_intern(&lf[287],9,"directory");
lf[288]=C_h_intern(&lf[288],16,"remove-directory");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[290]=C_h_intern(&lf[290],26,"setup-api#remove-extension");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000-shell command failed with nonzero exit status");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[295]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[298]=C_h_intern(&lf[298],14,"make-parameter");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[301]=C_h_intern(&lf[301],4,"exit");
lf[302]=C_h_intern(&lf[302],17,"current-directory");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\012/usr/local");
lf[304]=C_h_intern(&lf[304],12,"string-match");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\012(.*)/bin/\077");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\003doc");
lf[308]=C_h_intern(&lf[308],17,"\003syspeek-c-string");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\021share/chicken/doc");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[313]=C_h_intern(&lf[313],17,"register-feature!");
lf[314]=C_h_intern(&lf[314],13,"chicken-setup");
lf[315]=C_h_intern(&lf[315],7,"windows");
lf[316]=C_h_intern(&lf[316],14,"build-platform");
lf[317]=C_h_intern(&lf[317],13,"software-type");
C_register_lf2(lf,318,create_ptable());
t2=C_mutate(&lf[0] /* (set! c716 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1645,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1643 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1646 in k1643 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1649 in k1646 in k1643 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4918,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[3],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM),C_fix(0));}

/* k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4906,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=C_mutate(&lf[6] /* (set! setup-api#*installed-executables* ...) */,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=C_mutate(&lf[7] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}

/* k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}

/* k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
t2=C_mutate(&lf[9] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}

/* k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=C_mutate(&lf[10] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1712,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1712,2,t0,t1);}
t2=C_mutate(&lf[11] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[13] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4874,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 85   software-type */
((C_proc2)C_retrieve_symbol_proc(lf[317]))(2,*((C_word*)lf[317]+1),t6);}

/* k4872 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,lf[315]);
if(C_truep(t2)){
/* setup-api.scm: 86   build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[316]))(2,*((C_word*)lf[316]+1),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
f_1718(2,t3,C_SCHEME_FALSE);}}

/* k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1721,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 88   register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[313]))(3,*((C_word*)lf[313]+1),t3,lf[314]);}

/* k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 90   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t2,C_SCHEME_FALSE);}

/* k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1725,2,t0,t1);}
t2=C_mutate((C_word*)lf[15]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 93   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t3,lf[312]);}

/* k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 94   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t2,t1,lf[311]);}
else{
t3=t2;
f_1732(2,t3,C_SCHEME_FALSE);}}

/* k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1735(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=C_mutate(&lf[16] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 98   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t3,lf[310]);}

/* k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 99   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t2,t1,lf[309]);}
else{
t3=t2;
f_1742(2,t3,C_SCHEME_FALSE);}}

/* k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1745(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* k4853 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 100  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),((C_word*)t0)[2],t1,lf[307]);}

/* k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=C_mutate(&lf[17] /* (set! setup-api#*doc-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 105  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t3,lf[306]);}

/* k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1752(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4842,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 106  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[304]))(4,*((C_word*)lf[304]+1),t3,lf[305],C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}}

/* k4840 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1752(t2,(C_truep(t1)?(C_word)C_i_cadr(t1):lf[303]));}

/* k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1752,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[18]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate((C_word*)lf[19]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[22]+1 /* (set! setup-api#cross-chicken ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1764,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 117  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[302]))(2,*((C_word*)lf[302]+1),t5);}

/* k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=C_mutate(&lf[23] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 119  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t3,C_retrieve2(lf[23],"setup-api#*base-directory*"));}

/* k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1777,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 120  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t3,C_SCHEME_FALSE);}

/* k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! setup-api#setup-verbose-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 121  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t3,C_SCHEME_TRUE);}

/* k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! setup-api#setup-install-mode ...) */,t1);
t3=C_mutate((C_word*)lf[27]+1 /* (set! setup-api#setup-verbose-flag ...) */,C_retrieve(lf[25]));
t4=C_mutate((C_word*)lf[28]+1 /* (set! setup-api#setup-install-flag ...) */,C_retrieve(lf[26]));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 124  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"));}

/* k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 125  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t3,C_SCHEME_FALSE);}

/* k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=lf[31] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t4=lf[32] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t5=lf[33] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t6=lf[34] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t7=lf[35] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t8=C_mutate(&lf[36] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[47]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 178  user-install-setup */
f_1833(t10);}

/* k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_retrieve(lf[55]);
t7=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=t6,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4816,a[2]=t5,a[3]=t3,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4824,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[63]+1 /* (set! setup-api#create-directory/parents ...) */,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 200  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t11,C_retrieve(lf[301]));}

/* k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=C_mutate((C_word*)lf[64]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate((C_word*)lf[65]+1 /* (set! setup-api#yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1935,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[79]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2015,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 235  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),t5,C_SCHEME_TRUE);}

/* k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate(&lf[88] /* (set! setup-api#fixmaketarget ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2170,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[94]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[111] /* (set! setup-api#make:form-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2302,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[114] /* (set! setup-api#make:line-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2312,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[116] /* (set! setup-api#make:make/proc/helper ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2500,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[156]+1 /* (set! setup-api#make/proc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2790,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4812,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 438  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t10,lf[300]);}

/* k4810 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_FALSE);
/* setup-api.scm: 438  make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[298]))(3,*((C_word*)lf[298]+1),((C_word*)t0)[2],t2);}

/* k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[60],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=C_mutate((C_word*)lf[159]+1 /* (set! setup-api#installation-prefix ...) */,t1);
t3=C_mutate(&lf[160] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2868,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[169]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[176]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3132,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[177]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3187,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[178] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[180] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3234,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[182]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[197]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[204]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3779,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[166] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3915,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[174] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3970,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[210]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4023,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[242]+1 /* (set! setup-api#required-chicken-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4135,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[246] /* (set! setup-api#upgrade-message ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4155,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[248]+1 /* (set! setup-api#required-extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4165,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[256]+1 /* (set! setup-api#test-compile ...) */,C_retrieve(lf[210]));
t19=C_mutate((C_word*)lf[257]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4274,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[260]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4288,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[244]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4298,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4739,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 705  make-parameter */
((C_proc4)C_retrieve_symbol_proc(lf[298]))(4,*((C_word*)lf[298]+1),t22,lf[299],t23);}

/* a4738 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4739(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4739,3,t0,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[295]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4755,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_4755(t7,(C_word)C_i_nequalp(C_fix(2),t6));}
else{
t6=t5;
f_4755(t6,C_SCHEME_FALSE);}}}

/* k4753 in a4738 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4755,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4762,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4785,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 713  ensure-string */
f_4762(t5,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 715  warning */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),t2,lf[297],((C_word*)t0)[3]);}}

/* k4790 in k4753 in a4738 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 716  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[266]))(2,*((C_word*)lf[266]+1),((C_word*)t0)[2]);}

/* k4783 in k4753 in a4738 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4789,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 713  ensure-string */
f_4762(t2,((C_word*)t0)[2]);}

/* k4787 in k4783 in k4753 in a4738 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4789,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* ensure-string in k4753 in a4738 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4762(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4762,NULL,2,t1,t2);}
t3=(C_word)C_i_not(t2);
t4=(C_truep(t3)?t3:(C_word)C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[296]);}
else{
/* setup-api.scm: 712  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t1,t2);}}

/* k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4463,2,t0,t1);}
t2=C_mutate((C_word*)lf[266]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate((C_word*)lf[267]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4465,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[268]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4475,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[270]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4519,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[273]+1 /* (set! setup-api#create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4533,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[281]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[290]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4686,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[60] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4717,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* setup-api#$system in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4717(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4717,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4721,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4734,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
/* setup-api.scm: 771  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[122]+1)))(5,*((C_word*)lf[122]+1),t4,lf[293],t2,lf[294]);}
else{
t5=t4;
f_4734(2,t5,t2);}}

/* k4732 in setup-api#$system in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 769  system */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),((C_word*)t0)[2],t1);}

/* k4719 in setup-api#$system in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-api.scm: 774  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[112]+1)))(5,*((C_word*)lf[112]+1),((C_word*)t0)[3],lf[292],t1,((C_word*)t0)[2]);}}

/* setup-api#remove-extension in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4686,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4715,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 764  read-info */
((C_proc3)C_retrieve_symbol_proc(lf[270]))(3,*((C_word*)lf[270]+1),t3,t2);}

/* k4713 in setup-api#remove-extension in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(C_word)C_i_assq(lf[161],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
/* for-each */
t5=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve(lf[177]),t4);}
else{
t4=t3;
f_4693(2,t4,C_SCHEME_FALSE);}}

/* k4691 in k4713 in setup-api#remove-extension in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 766  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[165]))(2,*((C_word*)lf[165]+1),t3);}

/* k4702 in k4691 in k4713 in setup-api#remove-extension in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 766  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[106]))(5,*((C_word*)lf[106]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[291]);}

/* k4698 in k4691 in k4713 in setup-api#remove-extension in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 766  remove-file* */
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4586r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4586r(t0,t1,t2,t3);}}

static void C_ccall f_4586r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4590,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4590(2,t5,C_SCHEME_TRUE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4590(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4665,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 744  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[130]))(3,*((C_word*)lf[130]+1),t2,((C_word*)t0)[2]);}

/* k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4616,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 749  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4621,a[2]=t3,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4621(t5,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 746  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[112]+1)))(5,*((C_word*)lf[112]+1),((C_word*)t0)[4],lf[288],lf[289],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* walk in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4621,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4625,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 752  directory */
((C_proc4)C_retrieve_symbol_proc(lf[287]))(4,*((C_word*)lf[287]+1),t3,t2,C_SCHEME_TRUE);}

/* k4623 in walk in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4628,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li86),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a4632 in k4623 in walk in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4633,3,t0,t1,t2);}
t3=(C_word)C_i_string_equal_p(lf[284],t2);
t4=(C_truep(t3)?t3:(C_word)C_i_string_equal_p(lf[285],t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4646,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 756  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t5,((C_word*)t0)[2],t2);}}

/* k4644 in a4632 in k4623 in walk in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4652,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 757  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t2,t1);}

/* k4650 in k4644 in a4632 in k4623 in walk in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 758  walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4621(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* setup-api.scm: 759  delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4626 in k4623 in walk in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 761  delete-directory */
((C_proc3)C_retrieve_symbol_proc(lf[283]))(3,*((C_word*)lf[283]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4614 in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 749  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],lf[282],t1);}

/* k4610 in k4663 in k4588 in setup-api#remove-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 749  $system */
f_4717(((C_word*)t0)[2],t1);}

/* setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4537,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 733  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,lf[280]);}

/* k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_4540(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4575,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 734  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t3,lf[279]);}}

/* k4573 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_4540(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4581,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 735  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[277]))(3,*((C_word*)lf[277]+1),t2,lf[278]);}}

/* k4579 in k4573 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4540(t2,(C_truep(t1)?t1:lf[276]));}

/* k4538 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4540(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4540,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4545,a[2]=t1,a[3]=t3,a[4]=((C_word)li84),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4545(t5,((C_word*)t0)[2]);}

/* loop in k4538 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4545,NULL,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4552,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4572,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 739  number->string */
C_number_to_string(4,0,t5,t2,C_fix(16));}

/* k4570 in loop in k4538 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 739  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[122]+1)))(4,*((C_word*)lf[122]+1),((C_word*)t0)[2],lf[275],t1);}

/* k4566 in loop in k4538 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 739  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[106]))(5,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[274]);}

/* k4550 in loop in k4538 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4558,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 740  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[130]))(3,*((C_word*)lf[130]+1),t2,t1);}

/* k4556 in k4550 in loop in k4538 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4558,2,t0,t1);}
if(C_truep(t1)){
/* setup-api.scm: 740  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4545(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 741  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),t2,((C_word*)t0)[2]);}}

/* k4562 in k4556 in k4550 in loop in k4538 in k4535 in setup-api#create-temporary-directory in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#read-info in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4519,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 729  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[165]))(2,*((C_word*)lf[165]+1),t4);}

/* k4529 in setup-api#read-info in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 729  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[106]))(5,*((C_word*)lf[106]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[272]);}

/* k4525 in setup-api#read-info in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 728  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),((C_word*)t0)[2],t1,*((C_word*)lf[271]+1));}

/* setup-api#extension-version in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4475r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4475r(t0,t1,t2);}}

static void C_ccall f_4475r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4479,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4479(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4479(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4477 in setup-api#extension-version in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4498,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 722  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[266]))(2,*((C_word*)lf[266]+1),t2);}

/* k4496 in k4477 in setup-api#extension-version in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4498,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4488,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 723  string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[269]))(3,*((C_word*)lf[269]+1),t3,t2);}

/* k4486 in k4496 in k4477 in setup-api#extension-version in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[4])){
/* setup-api.scm: 724  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#extension-name in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4473,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 719  extension-name-and-version */
((C_proc2)C_retrieve_symbol_proc(lf[266]))(2,*((C_word*)lf[266]+1),t2);}

/* k4471 in setup-api#extension-name in k4461 in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(t1));}

/* setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4298,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4301,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4329,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 689  version->list */
f_4301(t5,t2);}

/* k4327 in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4333,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 690  version->list */
f_4301(t2,((C_word*)t0)[2]);}

/* k4331 in k4327 in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4333,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4335,a[2]=t3,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4335(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4331 in k4327 in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4335(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4335,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_nullp(t3));}
else{
t4=(C_word)C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_numberp(t5))){
t6=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_numberp(t6))){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_i_greaterp(t7,t8);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_nequalp(t10,t11))){
t12=(C_word)C_i_cdr(t2);
t13=(C_word)C_i_cdr(t3);
/* setup-api.scm: 697  loop */
t20=t1;
t21=t12;
t22=t13;
t1=t20;
t2=t21;
t3=t22;
goto loop;}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_numberp(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
/* setup-api.scm: 699  string>? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[265]+1)))(4,*((C_word*)lf[265]+1),t8,t9,t10);}}}}}

/* k4413 in loop in k4331 in k4327 in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_string_equal_p(t2,t3))){
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* setup-api.scm: 702  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4335(t6,((C_word*)t0)[5],t4,t5);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* version->list in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4301(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4301,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4307,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4318,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4322,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 688  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t5,t2);}

/* k4320 in version->list in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 688  string-split-fields */
((C_proc5)C_retrieve_symbol_proc(lf[262]))(5,*((C_word*)lf[262]+1),((C_word*)t0)[2],lf[263],t1,lf[264]);}

/* k4316 in version->list in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4306 in version->list in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4307,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4311,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 687  string->number */
C_string_to_number(3,0,t3,t2);}

/* k4309 in a4306 in version->list in setup-api#version>=? in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* setup-api#find-header in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4288,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4296,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 682  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t3,lf[261],t2);}

/* k4294 in setup-api#find-header in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 681  test-compile */
((C_proc5)C_retrieve_symbol_proc(lf[256]))(5,*((C_word*)lf[256]+1),((C_word*)t0)[2],t1,lf[234],C_SCHEME_TRUE);}

/* setup-api#find-library in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4274,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4282,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 677  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t4,lf[259],t3,t3);}

/* k4280 in setup-api#find-library in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4286,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 678  conc */
((C_proc4)C_retrieve_symbol_proc(lf[220]))(4,*((C_word*)lf[220]+1),t2,lf[258],((C_word*)t0)[2]);}

/* k4284 in k4280 in setup-api#find-library in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 676  test-compile */
((C_proc5)C_retrieve_symbol_proc(lf[256]))(5,*((C_word*)lf[256]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[237],t1);}

/* setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_4165r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4165r(t0,t1,t2);}}

static void C_ccall f_4165r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4171,a[2]=t4,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4171(t6,t1,t2);}

/* loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4171,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4184,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
t5=t3;
f_4184(t5,(C_word)C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_4184(t4,C_SCHEME_FALSE);}}}

/* k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4184(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4184,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4196,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 659  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t5,t2);}
else{
/* setup-api.scm: 671  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[112]+1)))(5,*((C_word*)lf[112]+1),((C_word*)t0)[3],lf[254],lf[255],((C_word*)t0)[4]);}}

/* k4194 in k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[251],t1))){
t3=(C_word)C_i_assq(lf[251],t1);
t4=t2;
f_4202(t4,(C_word)C_i_cadr(t3));}
else{
t3=t2;
f_4202(t3,C_SCHEME_FALSE);}}
else{
/* setup-api.scm: 669  upgrade-message */
f_4155(((C_word*)t0)[6],((C_word*)t0)[5],lf[252]);}}

/* k4200 in k4194 in k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4202(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4202,NULL,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 663  version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),t4,((C_word*)t0)[4],t1);}
else{
/* setup-api.scm: 662  upgrade-message */
f_4155(((C_word*)t0)[6],((C_word*)t0)[5],lf[250]);}}

/* k4228 in k4200 in k4194 in k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 663  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4217(t2,C_SCHEME_FALSE);}}

/* k4239 in k4228 in k4200 in k4194 in k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 663  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,((C_word*)t0)[2]);}

/* k4243 in k4239 in k4228 in k4200 in k4194 in k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_4217(t3,(C_word)C_i_not(t2));}

/* k4215 in k4200 in k4194 in k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4217(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4217,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 666  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,lf[249],((C_word*)t0)[4]);}
else{
/* setup-api.scm: 668  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4171(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k4222 in k4215 in k4200 in k4194 in k4182 in loop in setup-api#required-extension-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 664  upgrade-message */
f_4155(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#upgrade-message in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_4155(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4155,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4163,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 648  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[61]))(6,*((C_word*)lf[61]+1),t4,lf[247],t2,t3,t2);}

/* k4161 in setup-api#upgrade-message in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 647  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* setup-api#required-chicken-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4135,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4142,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4153,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 643  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[245]))(2,*((C_word*)lf[245]+1),t4);}

/* k4151 in setup-api#required-chicken-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 643  version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[244]))(4,*((C_word*)lf[244]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4140 in setup-api#required-chicken-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4149,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 644  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,lf[243],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4147 in k4140 in setup-api#required-chicken-version in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 644  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4023r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4023r(t0,t1,t2,t3);}}

static void C_ccall f_4023r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4027,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),t4,lf[241],t3);}

/* k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=t1,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t2,lf[240],((C_word*)t0)[2],t3);}

/* a4128 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[2])?C_retrieve2(lf[8],"setup-api#*cxx*"):C_retrieve2(lf[7],"setup-api#*cc*")));}

/* k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4126,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t2,lf[239],((C_word*)t0)[2],t3);}

/* a4125 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[238]);}

/* k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4123,a[2]=((C_word)li67),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t2,lf[237],((C_word*)t0)[2],t3);}

/* a4122 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4123,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[236]);}

/* k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t2,lf[235],((C_word*)t0)[2],t3);}

/* a4116 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4117,2,t0,t1);}
/* setup-api.scm: 620  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t1);}

/* k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4114,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t2,lf[234],((C_word*)t0)[2],t3);}

/* a4113 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 621  create-temporary-file */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t2,lf[233]);}

/* k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* setup-api.scm: 622  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),t2,t1,lf[232]);}

/* k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[2],a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 624  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[83]))(4,*((C_word*)lf[83]+1),t2,((C_word*)t0)[8],t3);}

/* a4107 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
/* display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[231]+1)))(3,*((C_word*)lf[231]+1),t1,((C_word*)t0)[2]);}

/* k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4085,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[5])?lf[216]:lf[217]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4099,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t5;
f_4099(2,t6,lf[227]);}
else{
/* setup-api.scm: 633  conc */
((C_proc8)C_retrieve_symbol_proc(lf[220]))(8,*((C_word*)lf[220]+1),t5,lf[228],C_retrieve2(lf[11],"setup-api#*target-lib-home*"),lf[229],((C_word*)t0)[2],lf[230],C_retrieve2(lf[10],"setup-api#*target-libs*"));}}

/* k4097 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?lf[218]:lf[219]);
/* setup-api.scm: 626  conc */
((C_proc15)C_retrieve_symbol_proc(lf[220]))(15,*((C_word*)lf[220]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[221],((C_word*)t0)[4],lf[222],((C_word*)t0)[3],lf[223],C_retrieve2(lf[9],"setup-api#*target-cflags*"),lf[224],((C_word*)t0)[2],lf[225],t1,lf[226],t2);}

/* k4083 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4088,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 636  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t2,t1,lf[215]);}
else{
t3=t2;
f_4088(2,t3,C_SCHEME_UNDEFINED);}}

/* k4086 in k4083 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 625  system */
((C_proc3)C_retrieve_symbol_proc(lf[214]))(3,*((C_word*)lf[214]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_zerop(t1);
t4=(C_truep(t3)?lf[212]:lf[213]);
/* setup-api.scm: 638  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t2,t4);}
else{
t3=t2;
f_4057(2,t3,C_SCHEME_UNDEFINED);}}

/* k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4067,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 639  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t4,((C_word*)t0)[2]);}

/* k4069 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 639  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),((C_word*)t0)[2],lf[211],C_retrieve2(lf[32],"setup-api#*remove-command*"),t1);}

/* k4065 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 639  $system */
f_4717(((C_word*)t0)[2],t1);}

/* k4058 in k4055 in k4052 in k4049 in k4046 in k4043 in k4040 in k4037 in k4034 in k4031 in k4028 in k4025 in setup-api#try-compile in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_zerop(((C_word*)t0)[2]));}

/* setup-api#ensure-directory in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3970(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3970,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3974,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 609  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),t3,t2);}

/* k3972 in setup-api#ensure-directory in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3983,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 610  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[130]))(3,*((C_word*)lf[130]+1),t3,t1);}
else{
t3=t2;
f_3977(2,t3,C_SCHEME_FALSE);}}

/* k3981 in k3972 in setup-api#ensure-directory in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 611  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 614  create-directory/parents */
((C_proc3)C_retrieve_symbol_proc(lf[63]))(3,*((C_word*)lf[63]+1),t2,((C_word*)t0)[2]);}}

/* k3993 in k3981 in k3972 in setup-api#ensure-directory in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3995,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
f_3977(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 616  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}}

/* k4019 in k3993 in k3981 in k3972 in setup-api#ensure-directory in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[209],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3987 in k3981 in k3972 in setup-api#ensure-directory in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_3977(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-api.scm: 612  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],lf[208]);}}

/* k3975 in k3972 in setup-api#ensure-directory in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#repo-path in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3915(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3915,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3919,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_3919(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_3919(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3917 in setup-api#repo-path in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* setup-api.scm: 600  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t3);}
else{
t4=t3;
f_3928(2,t4,C_SCHEME_FALSE);}}

/* k3926 in k3917 in setup-api#repo-path in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3935,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 602  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t2);}
else{
/* setup-api.scm: 604  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[165]))(2,*((C_word*)lf[165]+1),((C_word*)t0)[2]);}}

/* k3933 in k3926 in k3917 in setup-api#repo-path in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3939,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fudge(C_fix(42));
/* setup-api.scm: 603  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,lf[207],t3);}

/* k3937 in k3933 in k3926 in k3917 in setup-api#repo-path in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 601  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3920 in k3917 in setup-api#repo-path in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3925,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 605  ensure-directory */
f_3970(t2,t1);}

/* k3923 in k3920 in k3917 in setup-api#repo-path in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3779(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3779r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3779r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3779r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3783,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3783(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3783(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 577  setup-install-mode */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t2);}

/* k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3789,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 578  check-filelist */
f_3234(t2,t4);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3795,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 583  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t2);}

/* k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3881,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 581  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t3,t1,lf[206]);}
else{
/* setup-api.scm: 582  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}}

/* k3879 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 581  ensure-directory */
f_3970(((C_word*)t0)[2],t1);}

/* k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3832,a[2]=t1,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3831 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3832,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3839,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 586  make-dest-pathname */
f_3209(t5,((C_word*)t0)[2],t2);}

/* k3837 in a3831 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3842,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 587  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t2,((C_word*)t0)[2],t1);}

/* k3840 in k3837 in a3831 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3845(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 589  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}}

/* k3866 in k3840 in k3837 in a3831 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[162],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3843 in k3840 in k3837 in a3831 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3799 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3804(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3830,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 593  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t3,t1,lf[205]);}}

/* k3828 in k3799 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3830,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[186],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3802 in k3799 in k3796 in k3793 in k3790 in k3787 in k3781 in setup-api#install-script in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 594  write-info */
f_2868(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3622r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3622r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3622r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3626,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3626(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3626(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3628,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3642,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 552  setup-install-mode */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t3);}

/* k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3642,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3645,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 553  check-filelist */
f_3234(t2,t4);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3648,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 558  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t2);}

/* k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3745,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 556  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t3,t1,lf[203]);}
else{
/* setup-api.scm: 557  program-path */
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t2);}}

/* k3743 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 556  ensure-directory */
f_3970(((C_word*)t0)[2],t1);}

/* k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3654,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[3],a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3654(2,t3,((C_word*)t0)[2]);}}

/* a3708 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3709,3,t0,t1,t2);}
if(C_truep((C_word)C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* setup-api.scm: 562  exify */
f_3628(t3,t4);}
else{
/* setup-api.scm: 563  exify */
f_3628(t1,t2);}}

/* k3721 in a3708 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3727,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 562  exify */
f_3628(t2,t3);}

/* k3725 in k3721 in a3708 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3727,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k3652 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[2],a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a3661 in k3652 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3662,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3669,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 568  make-dest-pathname */
f_3209(t5,((C_word*)t0)[2],t2);}

/* k3667 in a3661 in k3652 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3672,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 569  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t2,((C_word*)t0)[2],t1);}

/* k3670 in k3667 in a3661 in k3652 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3675(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3698,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 571  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}}

/* k3696 in k3670 in k3667 in a3661 in k3652 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3698,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[162],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3673 in k3670 in k3667 in a3661 in k3652 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3655 in k3652 in k3649 in k3646 in k3643 in k3640 in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 574  write-info */
f_2868(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* exify in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3628(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3628,NULL,2,t1,t2);}
t3=(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[198]:C_SCHEME_FALSE);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3288,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3288(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3288(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3286 in exify in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 494  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t2,((C_word*)t0)[2]);}

/* k3293 in k3286 in exify in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=t1;
if(C_truep(t3)){
if(C_truep((C_word)C_i_equalp(lf[199],t1))){
t4=t2;
f_3298(t4,C_retrieve(lf[90]));}
else{
t4=(C_word)C_i_equalp(lf[200],t1);
t5=t2;
f_3298(t5,(C_truep(t4)?(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))?lf[201]:lf[202]):t1));}}
else{
t4=t2;
f_3298(t4,((C_word*)t0)[2]);}}

/* k3296 in k3293 in k3286 in exify in k3624 in setup-api#install-program in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3298(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 493  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3337r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3337r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3337r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3341,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3341(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3341(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 504  setup-install-mode */
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t2);}

/* k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_listp(((C_word*)t0)[2]);
t4=(C_truep(t3)?((C_word*)t0)[2]:(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* setup-api.scm: 505  check-filelist */
f_3234(t2,t4);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3353,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 506  repo-path */
f_3915(t2,C_SCHEME_END_OF_LIST);}

/* k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 507  repo-path */
f_3915(t2,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3456,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3456,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3463,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 510  make-dest-pathname */
f_3209(t5,((C_word*)t0)[2],t2);}

/* k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3556,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[14],"setup-api#*windows*"))){
t4=t3;
f_3556(t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3585,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 512  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t4,t1);}}

/* k3583 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3556(t2,(C_word)C_i_equalp(lf[196],t1));}

/* k3554 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3556(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3556,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3575,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 513  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3466(2,t2,C_SCHEME_UNDEFINED);}}

/* k3573 in k3554 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3575,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t4);}

/* k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* setup-api.scm: 514  copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t2;
f_3472(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3553,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 516  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}}

/* k3551 in k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[162],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3470 in k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=(C_word)C_i_assq(lf[192],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3487,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 518  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t5);}
else{
t4=t3;
f_3478(2,t4,C_SCHEME_FALSE);}}

/* k3528 in k3470 in k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[193]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_equalp(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3522,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 520  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
f_3487(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_3487(t3,C_SCHEME_FALSE);}}

/* k3520 in k3528 in k3470 in k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3487(t2,(C_word)C_i_equalp(t1,lf[194]));}

/* k3485 in k3470 in k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3487,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 521  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3478(2,t2,C_SCHEME_UNDEFINED);}}

/* k3504 in k3485 in k3470 in k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3506,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[35],"setup-api#*ranlib-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t4);}

/* k3476 in k3470 in k3467 in k3464 in k3461 in a3455 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 522  make-dest-pathname */
f_3209(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3362,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 524  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t2);}

/* k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 526  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t3,t1,lf[191]);}
else{
t3=t2;
f_3365(2,t3,C_retrieve2(lf[17],"setup-api#*doc-path*"));}}

/* k3452 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 526  ensure-directory */
f_3970(((C_word*)t0)[2],t1);}

/* k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
t2=(C_word)C_i_assq(lf[183],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3371,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3427,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 529  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t4,lf[189],t1,lf[190]);}
else{
t4=t3;
f_3371(2,t4,C_SCHEME_FALSE);}}

/* k3425 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3430,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[3],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a3434 in k3425 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3435,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 532  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t3,((C_word*)t0)[2],t2);}

/* k3441 in a3434 in k3425 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 532  copy-file */
((C_proc5)C_retrieve_symbol_proc(lf[169]))(5,*((C_word*)lf[169]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3428 in k3425 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 534  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[185]+1)))(2,*((C_word*)lf[185]+1),((C_word*)t0)[2]);}

/* k3369 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=(C_word)C_i_assq(lf[184],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3383,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 536  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[48]+1)))(5,*((C_word*)lf[48]+1),t4,lf[187],((C_word*)t0)[2],lf[188]);}
else{
t4=t3;
f_3377(2,t4,C_SCHEME_FALSE);}}

/* k3381 in k3369 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[3],a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* for-each */
t5=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a3390 in k3381 in k3369 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3391,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3395,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 539  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t3,((C_word*)t0)[2],t2);}

/* k3393 in a3390 in k3381 in k3369 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3398,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 540  copy-file */
((C_proc5)C_retrieve_symbol_proc(lf[169]))(5,*((C_word*)lf[169]+1),t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3396 in k3393 in a3390 in k3381 in k3369 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[186],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[3],t5);}}

/* k3384 in k3381 in k3369 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 544  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[185]+1)))(2,*((C_word*)lf[185]+1),((C_word*)t0)[2]);}

/* k3375 in k3369 in k3363 in k3360 in k3357 in k3354 in k3351 in k3348 in k3345 in k3339 in setup-api#install-extension in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 545  write-info */
f_2868(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#check-filelist in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3234(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3234,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3240,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a3239 in setup-api#check-filelist in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3240,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3253,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
/* setup-api.scm: 487  every */
((C_proc4)C_retrieve_symbol_proc(lf[146]))(4,*((C_word*)lf[146]+1),t3,*((C_word*)lf[147]+1),t2);}
else{
t4=t3;
f_3253(2,t4,C_SCHEME_FALSE);}}}

/* k3251 in a3239 in setup-api#check-filelist in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3253,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t2;
f_3256(t5,(C_word)C_a_i_list(&a,2,t3,t4));}
else{
t3=t2;
f_3256(t3,C_SCHEME_FALSE);}}}

/* k3254 in k3251 in a3239 in setup-api#check-filelist in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3256(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* setup-api.scm: 489  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],lf[181],((C_word*)t0)[2]);}}

/* setup-api#make-dest-pathname in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3209(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3209,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_listp(t3))){
t4=(C_word)C_i_cadr(t3);
/* setup-api.scm: 479  make-dest-pathname */
t7=t1;
t8=t2;
t9=t4;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3229,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 480  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[179]))(3,*((C_word*)lf[179]+1),t4,t3);}}

/* k3227 in setup-api#make-dest-pathname in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* setup-api.scm: 482  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* setup-api#remove-file* in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3187,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3207,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 475  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,t2);}

/* k3205 in setup-api#remove-file* in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*remove-command*"),t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t4);}

/* setup-api#move-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3132,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3139,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_cadr(t2);
/* setup-api.scm: 470  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t6,t3,t7);}
else{
t7=t6;
f_3139(2,t7,t3);}}

/* k3137 in setup-api#move-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 471  ensure-directory */
f_3970(t2,t1);}

/* k3140 in k3137 in setup-api#move-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 472  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3159 in k3140 in k3137 in setup-api#move-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3169,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 472  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3167 in k3159 in k3140 in k3137 in setup-api#move-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3169,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_2982r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2982r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2982r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2984,a[2]=t3,a[3]=t2,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3075,a[2]=t5,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3084,a[2]=t6,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-err801845 */
t8=t7;
f_3084(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-prefix802841 */
t10=t6;
f_3075(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body799808 */
t12=t5;
f_2984(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-err801 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3084(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3084,NULL,2,t0,t1);}
/* def-prefix802841 */
t2=((C_word*)t0)[2];
f_3075(t2,t1,C_SCHEME_TRUE);}

/* def-prefix802 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3075(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3075,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3083,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 453  installation-prefix */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t3);}

/* k3081 in def-prefix802 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body799808 */
t2=((C_word*)t0)[4];
f_2984(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2984(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2984,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(((C_word*)t0)[3]);
t5=(C_truep(t4)?(C_word)C_i_car(((C_word*)t0)[3]):((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2991,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 456  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t6,((C_word*)t0)[2],t7);}
else{
t7=t6;
f_2991(2,t7,((C_word*)t0)[2]);}}

/* k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3048,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 457  string-prefix? */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),t4,((C_word*)t0)[2],t1);}
else{
t4=t3;
f_3048(t4,C_SCHEME_FALSE);}}

/* k3056 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3048(t2,(C_word)C_i_not(t1));}

/* k3046 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_3048(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 458  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2994(2,t2,((C_word*)t0)[2]);}}

/* k2992 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 460  ensure-directory */
f_3970(t2,t1);}

/* k2995 in k2992 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 461  glob? */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[3]);}

/* k3001 in k2995 in k2992 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3006(2,t3,t1);}
else{
/* setup-api.scm: 461  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[130]))(3,*((C_word*)lf[130]+1),t2,((C_word*)t0)[3]);}}

/* k3004 in k3001 in k2995 in k2992 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3006,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3009,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3025,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 463  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 465  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[5],lf[170],((C_word*)t0)[3]);}
else{
/* setup-api.scm: 466  warning */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),((C_word*)t0)[5],lf[172],((C_word*)t0)[3]);}}}

/* k3023 in k3004 in k3001 in k2995 in k2992 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 463  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k3031 in k3023 in k3004 in k3001 in k2995 in k2992 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*copy-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k3007 in k3004 in k3001 in k2995 in k2992 in k2989 in body799 in setup-api#copy-file in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2868(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2868,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2980,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_END_OF_LIST);}

/* k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[161],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t4=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2976,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2965,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 443  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t4);}

/* k2963 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 443  printf */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[4],lf[167],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2875(2,t2,C_SCHEME_UNDEFINED);}}

/* k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 444  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,((C_word*)t0)[2]);}

/* k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2962,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 445  repo-path */
f_3915(t3,(C_word)C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k2960 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2837,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* setup-api.scm: 434  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[165]))(2,*((C_word*)lf[165]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2837(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2835 in k2960 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 435  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[106]))(5,*((C_word*)lf[106]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[164]);}

/* k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2884,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[12],"setup-api#*sudo*"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 447  create-temporary-file */
((C_proc2)C_retrieve_symbol_proc(lf[85]))(2,*((C_word*)lf[85]+1),t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 450  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[83]))(4,*((C_word*)lf[83]+1),t2,t1,t3);}}

/* a2953 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
/* pp */
((C_proc3)C_retrieve_symbol_proc(lf[163]))(3,*((C_word*)lf[163]+1),t1,((C_word*)t0)[2]);}

/* k2911 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2916,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2945,a[2]=((C_word*)t0)[2],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 448  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[83]))(4,*((C_word*)lf[83]+1),t2,t1,t3);}

/* a2944 in k2911 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2945,2,t0,t1);}
/* pp */
((C_proc3)C_retrieve_symbol_proc(lf[163]))(3,*((C_word*)lf[163]+1),t1,((C_word*)t0)[2]);}

/* k2914 in k2911 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 449  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2933 in k2914 in k2911 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 449  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2941 in k2933 in k2914 in k2911 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*move-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* k2882 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2884,2,t0,t1);}
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 451  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}}

/* k2908 in k2882 in k2879 in k2876 in k2873 in k2974 in k2978 in setup-api#write-info in k2864 in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[162],t2);
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=(C_word)C_a_i_list(&a,1,t4);
/* setup-api#execute */
((C_proc3)C_retrieve_symbol_proc(lf[94]))(3,*((C_word*)lf[94]+1),((C_word*)t0)[2],t5);}

/* setup-api#make/proc in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2790r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2790r(t0,t1,t2,t3);}}

static void C_ccall f_2790r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_length(t3);
switch(t4){
case C_fix(0):
t5=t2;
/* setup-api.scm: 393  make:make/proc/helper */
f_2500(t1,t5,C_SCHEME_END_OF_LIST);
case C_fix(1):
t5=t2;
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2822,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t6))){
/* setup-api.scm: 398  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[155]+1)))(3,*((C_word*)lf[155]+1),t8,t6);}
else{
t9=t8;
f_2822(2,t9,t6);}
default:
/* ##sys#error */
t5=*((C_word*)lf[157]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[158]);}}

/* k2820 in setup-api#make/proc in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 395  make:make/proc/helper */
f_2500(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2500(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2500,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2504,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_vectorp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 327  vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[155]+1)))(3,*((C_word*)lf[155]+1),t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_2504(t6,C_SCHEME_UNDEFINED);}}

/* k2786 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2504(t3,t2);}

/* k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2504,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2332,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2332(2,t6,t4);}
else{
/* setup-api.scm: 299  make:form-error */
f_2302(t5,lf[154],t3);}}

/* k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_pairp(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2341(2,t4,t2);}
else{
/* setup-api.scm: 300  make:form-error */
f_2302(t3,lf[153],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
f_2507(2,t2,C_SCHEME_FALSE);}}

/* k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 301  every */
((C_proc4)C_retrieve_symbol_proc(lf[146]))(4,*((C_word*)lf[146]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2507(2,t2,C_SCHEME_FALSE);}}

/* a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2346,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2353,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t4=(C_word)C_i_length(t2);
/* setup-api.scm: 303  <= */
C_less_or_equal_p(5,0,t3,C_fix(2),t4,C_fix(3));}
else{
t4=t3;
f_2353(2,t4,C_SCHEME_FALSE);}}

/* k2351 in a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2356(2,t3,t1);}
else{
/* setup-api.scm: 304  make:form-error */
f_2302(t2,lf[152],((C_word*)t0)[3]);}}

/* k2354 in k2351 in a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2356,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_stringp(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2365(2,t5,t3);}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_listp(t5))){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
/* setup-api.scm: 307  every */
((C_proc4)C_retrieve_symbol_proc(lf[146]))(4,*((C_word*)lf[146]+1),t4,*((C_word*)lf[147]+1),t6);}
else{
t6=t4;
f_2365(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2363 in k2354 in k2351 in a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2368(2,t3,t1);}
else{
/* setup-api.scm: 308  make:form-error */
f_2302(t2,lf[151],((C_word*)t0)[3]);}}

/* k2366 in k2363 in k2354 in k2351 in a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2368,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(C_word)C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2377,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2377(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* setup-api.scm: 311  make:line-error */
f_2312(t6,lf[150],t7,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2405 in k2366 in k2363 in k2354 in k2351 in a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2377(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2415,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* setup-api.scm: 312  every */
((C_proc4)C_retrieve_symbol_proc(lf[146]))(4,*((C_word*)lf[146]+1),((C_word*)t0)[3],t2,t3);}}

/* a2414 in k2405 in k2366 in k2363 in k2354 in k2351 in a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2415,3,t0,t1,t2);}
t3=(C_word)C_i_stringp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* setup-api.scm: 314  make:form-error */
f_2302(t1,lf[149],t2);}}

/* k2375 in k2366 in k2363 in k2354 in k2351 in a2345 in k2339 in k2330 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_closurep(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* setup-api.scm: 318  make:line-error */
f_2312(((C_word*)t0)[3],lf[148],t6,((C_word*)t0)[2]);}}}

/* k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(C_word)C_i_stringp(t3);
if(C_truep(t4)){
t5=t2;
f_2510(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 323  every */
((C_proc4)C_retrieve_symbol_proc(lf[146]))(4,*((C_word*)lf[146]+1),t5,*((C_word*)lf[147]+1),t3);}}

/* k2490 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2510(2,t2,t1);}
else{
/* setup-api.scm: 324  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],lf[145],((C_word*)t0)[2]);}}

/* k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t9,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 331  condition-predicate */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t11,lf[142]);}

/* k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-api.scm: 332  condition-property-accessor */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),t3,lf[142],lf[143]);}

/* k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2519,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word)li33),tmp=(C_word)a,a+=8,tmp));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
/* setup-api.scm: 383  make-file */
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],lf[137]);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2772,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 384  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[139]+1)))(3,*((C_word*)lf[139]+1),t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2777,a[2]=((C_word*)t0)[7],a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[2])[1]);}}}

/* a2776 in k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2777,3,t0,t1,t2);}
/* setup-api.scm: 385  make-file */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[140]);}

/* k2770 in k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 384  make-file */
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[138]);}

/* k2732 in k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 386  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k2738 in k2732 in k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2745,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 389  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[136]+1)))(3,*((C_word*)lf[136]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2751 in k2738 in k2732 in k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2744 in k2738 in k2732 in k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2745,3,t0,t1,t2);}
/* setup-api.scm: 388  printf */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),t1,lf[135],t2);}

/* f_2521 in k2517 in k2513 in k2508 in k2505 in k2502 in setup-api#make:make/proc/helper in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2521,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=t2;
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2248,a[2]=t5,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2257,a[2]=t7,a[3]=t9,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2257(t11,t4,t6);}

/* loop */
static void C_fcall f_2257(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2257,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_stringp(t5))){
t6=(C_word)C_i_car(t3);
t7=t4;
f_2270(t7,(C_word)C_a_i_list(&a,1,t6));}
else{
t6=t4;
f_2270(t6,(C_word)C_i_car(t3));}}}

/* k2268 in loop */
static void C_fcall f_2270(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2270,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 291  any */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t2,((C_word*)t0)[2],t1);}

/* k2274 in k2268 in loop */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* setup-api.scm: 293  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2257(t3,((C_word*)t0)[5],t2);}}

/* match? */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2248,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2523 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* setup-api.scm: 336  fixmaketarget */
f_2170(t2,((C_word*)t0)[7]);}

/* k2526 in k2523 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2728,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 337  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[130]))(3,*((C_word*)lf[130]+1),t3,t1);}

/* k2726 in k2526 in k2523 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 338  file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[128]))(3,*((C_word*)lf[128]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2531(2,t2,C_SCHEME_FALSE);}}

/* k2529 in k2526 in k2523 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 339  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k2720 in k2529 in k2526 in k2523 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 340  printf */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[4],lf[134],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_2534(2,t2,C_SCHEME_UNDEFINED);}}

/* k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
if(C_truep(((C_word*)t0)[11])){
t2=(C_word)C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2543,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2704,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 343  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[122]+1)))(4,*((C_word*)lf[122]+1),t4,lf[132],((C_word*)t0)[4]);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 381  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,lf[133],((C_word*)t0)[3]);}}}

/* k2717 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 381  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* k2702 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2705,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li30),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2701 in k2702 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2705,3,t0,t1,t2);}
/* setup-api.scm: 344  make-file */
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2549,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_2549(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[11],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 348  any */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t3,t4,((C_word*)t0)[2]);}}

/* a2672 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2673,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2677,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 349  fixmaketarget */
f_2170(t3,t2);}

/* k2675 in a2672 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2680,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2693,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 350  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[130]))(3,*((C_word*)lf[130]+1),t3,t1);}

/* k2691 in k2675 in a2672 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2680(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 351  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),t2,lf[129],((C_word*)t0)[2]);}}

/* k2698 in k2691 in k2675 in a2672 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 351  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* k2678 in k2675 in a2672 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 352  file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[128]))(3,*((C_word*)lf[128]+1),t2,((C_word*)t0)[2]);}

/* k2688 in k2678 in k2675 in a2672 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_greaterp(t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[10]);
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2568,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2639,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* setup-api.scm: 359  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t6);}}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2637 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
/* setup-api.scm: 367  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[122]+1)))(5,*((C_word*)lf[122]+1),t2,lf[123],((C_word*)t0)[2],lf[124]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2668,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 369  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t4,lf[125],((C_word*)t0)[2],((C_word*)t0)[3]);}}
else{
/* setup-api.scm: 365  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[122]+1)))(5,*((C_word*)lf[122]+1),t2,lf[126],((C_word*)t0)[4],lf[127]);}}
else{
t2=((C_word*)t0)[6];
f_2568(2,t2,C_SCHEME_UNDEFINED);}}

/* k2666 in k2637 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 369  string-append */
((C_proc3)C_retrieve_proc(*((C_word*)lf[122]+1)))(3,*((C_word*)lf[122]+1),((C_word*)t0)[2],t1);}

/* k2644 in k2637 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 360  printf */
((C_proc6)C_retrieve_symbol_proc(lf[58]))(6,*((C_word*)lf[58]+1),((C_word*)t0)[4],lf[121],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li28),tmp=(C_word)a,a+=7,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[120]+1)))(3,*((C_word*)lf[120]+1),t2,t3);}

/* a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2576,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2582,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li23),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2611,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[119]))(4,*((C_word*)lf[119]+1),t1,t3,t4);}

/* a2610 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2617,a[2]=((C_word*)t0)[3],a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2625 in a2610 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2626r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2626r(t0,t1,t2);}}

static void C_ccall f_2626r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2632,a[2]=t2,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
/* k563568 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2631 in a2625 in a2610 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2616 in a2610 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2617,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=t2;
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a2581 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2582,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
/* k563568 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2587 in a2581 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 375  exn? */
t6=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}

/* k2604 in a2587 in a2581 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 376  exn-message */
t2=((C_word*)((C_word*)t0)[4])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2603(2,t2,((C_word*)t0)[2]);}}

/* k2601 in a2587 in a2581 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 373  printf */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[3],lf[118],((C_word*)t0)[2],t1);}

/* k2590 in a2587 in a2581 in a2575 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 378  signal */
((C_proc3)C_retrieve_symbol_proc(lf[117]))(3,*((C_word*)lf[117]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2572 in k2566 in k2547 in k2541 in k2532 in k2529 in k2526 in k2523 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#make:line-error in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2312(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2312,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2320,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 296  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[61]))(6,*((C_word*)lf[61]+1),t5,lf[115],t2,t3,t4);}

/* k2318 in setup-api#make:line-error in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 296  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* setup-api#make:form-error in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2302(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2302,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 295  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[61]))(5,*((C_word*)lf[61]+1),t4,lf[113],t2,t3);}

/* k2308 in setup-api#make:form-error in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 295  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2196,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2199,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2227,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,t2);}

/* k2242 in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2226 in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2227,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2231,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 265  run-verbose */
((C_proc2)C_retrieve_symbol_proc(lf[87]))(2,*((C_word*)lf[87]+1),t4);}

/* k2235 in a2226 in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 265  printf */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),((C_word*)t0)[3],lf[109],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2231(2,t2,C_SCHEME_UNDEFINED);}}

/* k2229 in a2226 in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 266  $system */
f_4717(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2199,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2203,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve(lf[108]),t2);}

/* k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(t1);
if(C_truep((C_word)C_i_string_equal_p(t3,lf[97]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2121,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2143,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
t8=(C_word)C_i_cdr(t7);
/* setup-api.scm: 241  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t6,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t8);}
else{
t4=(C_word)C_i_assoc(t3,C_retrieve2(lf[6],"setup-api#*installed-executables*"));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_cdr(t4);
/* setup-api.scm: 250  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[106]))(4,*((C_word*)lf[106]+1),t5,C_retrieve2(lf[16],"setup-api#*chicken-bin-path*"),t6);}
else{
t5=t2;
f_2214(2,t5,t3);}}}

/* k2162 in k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 250  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k2141 in k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 240  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k2123 in k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2139,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 245  keep-intermediates */
((C_proc2)C_retrieve_symbol_proc(lf[30]))(2,*((C_word*)lf[30]+1),t2);}

/* k2137 in k2123 in k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=(C_truep(t1)?lf[99]:lf[100]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2136,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 246  host-extension */
((C_proc2)C_retrieve_symbol_proc(lf[15]))(2,*((C_word*)lf[15]+1),t3);}

/* k2134 in k2137 in k2123 in k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[101]:lf[102]);
/* setup-api.scm: 240  cons* */
((C_proc8)C_retrieve_symbol_proc(lf[103]))(8,*((C_word*)lf[103]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[104],lf[105],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* k2119 in k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 239  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t1,lf[98]);}

/* k2212 in k2201 in smooth in setup-api#execute in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
/* setup-api.scm: 262  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],t3,lf[96]);}

/* setup-api#fixmaketarget in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2170(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2170,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2194,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 254  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t4,t2);}

/* k2192 in setup-api#fixmaketarget in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_equalp(lf[91],t1))){
t2=(C_word)C_i_string_equal_p(lf[92],C_retrieve(lf[90]));
t3=((C_word*)t0)[2];
f_2177(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2177(t2,C_SCHEME_FALSE);}}

/* k2175 in setup-api#fixmaketarget in k2103 in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 256  pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_retrieve(lf[90]));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2015,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2019,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2098,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 218  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t6);}

/* k2096 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 218  printf */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),((C_word*)t0)[3],lf[86],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2019(2,t2,C_SCHEME_UNDEFINED);}}

/* k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2019,2,t0,t1);}
if(C_truep((C_word)C_i_listp(((C_word*)t0)[5]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 220  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[83]))(4,*((C_word*)lf[83]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 229  create-temporary-file */
((C_proc2)C_retrieve_symbol_proc(lf[85]))(2,*((C_word*)lf[85]+1),t2);}}

/* k2071 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2076,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,t1,t1);
/* setup-api.scm: 230  patch */
((C_proc5)C_retrieve_symbol_proc(lf[79]))(5,*((C_word*)lf[79]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2074 in k2071 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2087,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 232  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}

/* k2085 in k2074 in k2071 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2091,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 233  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k2089 in k2085 in k2074 in k2071 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 232  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[61]))(6,*((C_word*)lf[61]+1),((C_word*)t0)[3],lf[84],C_retrieve2(lf[33],"setup-api#*move-command*"),((C_word*)t0)[2],t1);}

/* k2081 in k2074 in k2071 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 231  $system */
f_4717(((C_word*)t0)[2],t1);}

/* a2033 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 222  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),t1,t2,t3);}

/* a2043 in a2033 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li12),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2050(t5,t1);}

/* loop in a2043 in a2033 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_2050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2050,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 225  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[72]))(2,*((C_word*)lf[72]+1),t2);}

/* k2052 in loop in a2043 in a2033 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 227  string-substitute */
((C_proc6)C_retrieve_symbol_proc(lf[81]))(6,*((C_word*)lf[81]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}}

/* k2068 in k2052 in loop in a2043 in a2033 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 227  write-line */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),((C_word*)t0)[2],t1);}

/* k2061 in k2052 in loop in a2043 in a2033 in k2017 in setup-api#patch in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 228  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2050(t2,((C_word*)t0)[2]);}

/* setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1935r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1935r(t0,t1,t2,t3);}}

static void C_ccall f_1935r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1939,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),t4,lf[78],t3);}

/* k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2009,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t2,lf[77],((C_word*)t0)[2],t3);}

/* a2008 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
/* setup-api.scm: 202  abort-setup */
((C_proc2)C_retrieve_symbol_proc(lf[64]))(2,*((C_word*)lf[64]+1),t1);}

/* k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1947(t5,((C_word*)t0)[2]);}

/* loop in k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1947(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1947,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 204  printf */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),t2,lf[75],((C_word*)t0)[2]);}

/* k1949 in loop in k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-api.scm: 205  printf */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),t2,lf[74],((C_word*)t0)[2]);}
else{
t3=t2;
f_1954(2,t3,C_SCHEME_UNDEFINED);}}

/* k1952 in k1949 in loop in k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 206  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[73]+1)))(2,*((C_word*)lf[73]+1),t2);}

/* k1955 in k1952 in k1949 in loop in k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api.scm: 207  read-line */
((C_proc2)C_retrieve_symbol_proc(lf[72]))(2,*((C_word*)lf[72]+1),t2);}

/* k1958 in k1955 in k1952 in k1949 in loop in k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[70]);
t6=t4;
f_1963(t6,t5);}
else{
t5=(C_truep(((C_word*)t0)[2])?(C_word)C_i_string_equal_p(lf[71],((C_word*)t3)[1]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_set_block_item(t3,0,((C_word*)t0)[2]);
t7=t4;
f_1963(t7,t6);}
else{
t6=t4;
f_1963(t6,C_SCHEME_UNDEFINED);}}}

/* k1961 in k1958 in k1955 in k1952 in k1949 in loop in k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1963,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_string_ci_equal_p(lf[66],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[67],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_string_ci_equal_p(lf[68],((C_word*)((C_word*)t0)[5])[1]))){
/* setup-api.scm: 212  abort */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 214  printf */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t2,lf[69]);}}}}

/* k1985 in k1961 in k1958 in k1955 in k1952 in k1949 in loop in k1940 in k1937 in setup-api#yes-or-no? in k1931 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 215  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1947(t2,((C_word*)t0)[2]);}

/* f_4824 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4824,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4828,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 197  verb */
f_1916(t3,t2);}

/* k4826 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4839,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 198  shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}

/* k4837 in k4826 */
static void C_ccall f_4839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 198  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[61]))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],lf[62],t1);}

/* k4833 in k4826 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 198  $system */
f_4717(((C_word*)t0)[2],t1);}

/* f_4816 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4816,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4820,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-api.scm: 194  verb */
f_1916(t3,t2);}

/* k4818 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 195  create-directory-0 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1884(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* verb in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1916(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1916,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1923,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 191  setup-verbose-mode */
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t3);}

/* k1921 in verb in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api.scm: 191  printf */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),((C_word*)t0)[3],lf[59],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* create-directory-0 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1884(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1884,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1890,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1890(t6,t1,t2);}

/* loop in create-directory-0 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1890(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1890,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1914,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 187  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t4,t2);}
else{
t4=t3;
f_1897(t4,C_SCHEME_FALSE);}}

/* k1912 in loop in create-directory-0 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1897(t2,(C_word)C_i_not(t1));}

/* k1895 in loop in create-directory-0 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1897,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1907,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-api.scm: 188  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[56]))(3,*((C_word*)lf[56]+1),t3,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1905 in k1895 in loop in create-directory-0 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 188  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1890(t2,((C_word*)t0)[2],t1);}

/* k1898 in k1895 in loop in create-directory-0 in k1879 in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 189  create-directory */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#sudo-install in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1859r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1859r(t0,t1,t2);}}

static void C_ccall f_1859r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
if(C_truep((C_word)C_vemptyp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[12],"setup-api#*sudo*"));}
else{
if(C_truep((C_word)C_i_vector_ref(t2,C_fix(0)))){
t3=t1;
t4=lf[12] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t5=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
/* setup-api.scm: 151  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),t3,lf[49]);}
else{
t5=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[50]);
t6=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[51]);
t7=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[52]);
t8=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[53]);
t9=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[54]);
t10=t3;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}
else{
/* setup-api.scm: 175  user-install-setup */
f_1833(t1);}}}

/* setup-api#user-install-setup in k1793 in k1789 in k1783 in k1779 in k1775 in k1771 in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_fcall f_1833(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1833,NULL,1,t1);}
t2=lf[12] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[13],"setup-api#*windows-shell*"))){
t3=t1;
t4=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[37]);
t5=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[38]);
t6=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[39]);
t7=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[40]);
t8=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[41]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t3=t1;
t4=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[42]);
t5=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[43]);
t6=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[44]);
t7=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[45]);
t8=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[46]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* setup-api#cross-chicken in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fudge(C_fix(39)));}

/* setup-api#shellpath in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1754,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1762,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-api.scm: 112  normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t2);}

/* k1760 in setup-api#shellpath in k1750 in k1747 in k1743 in k1740 in k1737 in k1733 in k1730 in k1727 in k1723 in k1719 in k1716 in k1710 in k1706 in k1702 in k1698 in k1694 in k4904 in k4908 in k4912 in k4916 in k1685 in k1682 in k1679 in k1676 in k1673 in k1670 in k1667 in k1664 in k1661 in k1658 in k1655 in k1652 in k1649 in k1646 in k1643 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api.scm: 112  qs */
((C_proc3)C_retrieve_symbol_proc(lf[20]))(3,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[410] = {
{"toplevel:setup_api_scm",(void*)C_toplevel},
{"f_1645:setup_api_scm",(void*)f_1645},
{"f_1648:setup_api_scm",(void*)f_1648},
{"f_1651:setup_api_scm",(void*)f_1651},
{"f_1654:setup_api_scm",(void*)f_1654},
{"f_1657:setup_api_scm",(void*)f_1657},
{"f_1660:setup_api_scm",(void*)f_1660},
{"f_1663:setup_api_scm",(void*)f_1663},
{"f_1666:setup_api_scm",(void*)f_1666},
{"f_1669:setup_api_scm",(void*)f_1669},
{"f_1672:setup_api_scm",(void*)f_1672},
{"f_1675:setup_api_scm",(void*)f_1675},
{"f_1678:setup_api_scm",(void*)f_1678},
{"f_1681:setup_api_scm",(void*)f_1681},
{"f_1684:setup_api_scm",(void*)f_1684},
{"f_1687:setup_api_scm",(void*)f_1687},
{"f_4918:setup_api_scm",(void*)f_4918},
{"f_4914:setup_api_scm",(void*)f_4914},
{"f_4910:setup_api_scm",(void*)f_4910},
{"f_4906:setup_api_scm",(void*)f_4906},
{"f_1696:setup_api_scm",(void*)f_1696},
{"f_1700:setup_api_scm",(void*)f_1700},
{"f_1704:setup_api_scm",(void*)f_1704},
{"f_1708:setup_api_scm",(void*)f_1708},
{"f_1712:setup_api_scm",(void*)f_1712},
{"f_4874:setup_api_scm",(void*)f_4874},
{"f_1718:setup_api_scm",(void*)f_1718},
{"f_1721:setup_api_scm",(void*)f_1721},
{"f_1725:setup_api_scm",(void*)f_1725},
{"f_1729:setup_api_scm",(void*)f_1729},
{"f_1732:setup_api_scm",(void*)f_1732},
{"f_1735:setup_api_scm",(void*)f_1735},
{"f_1739:setup_api_scm",(void*)f_1739},
{"f_1742:setup_api_scm",(void*)f_1742},
{"f_4855:setup_api_scm",(void*)f_4855},
{"f_1745:setup_api_scm",(void*)f_1745},
{"f_1749:setup_api_scm",(void*)f_1749},
{"f_4842:setup_api_scm",(void*)f_4842},
{"f_1752:setup_api_scm",(void*)f_1752},
{"f_1773:setup_api_scm",(void*)f_1773},
{"f_1777:setup_api_scm",(void*)f_1777},
{"f_1781:setup_api_scm",(void*)f_1781},
{"f_1785:setup_api_scm",(void*)f_1785},
{"f_1791:setup_api_scm",(void*)f_1791},
{"f_1795:setup_api_scm",(void*)f_1795},
{"f_1881:setup_api_scm",(void*)f_1881},
{"f_1933:setup_api_scm",(void*)f_1933},
{"f_2105:setup_api_scm",(void*)f_2105},
{"f_4812:setup_api_scm",(void*)f_4812},
{"f_2866:setup_api_scm",(void*)f_2866},
{"f_4739:setup_api_scm",(void*)f_4739},
{"f_4755:setup_api_scm",(void*)f_4755},
{"f_4792:setup_api_scm",(void*)f_4792},
{"f_4785:setup_api_scm",(void*)f_4785},
{"f_4789:setup_api_scm",(void*)f_4789},
{"f_4762:setup_api_scm",(void*)f_4762},
{"f_4463:setup_api_scm",(void*)f_4463},
{"f_4717:setup_api_scm",(void*)f_4717},
{"f_4734:setup_api_scm",(void*)f_4734},
{"f_4721:setup_api_scm",(void*)f_4721},
{"f_4686:setup_api_scm",(void*)f_4686},
{"f_4715:setup_api_scm",(void*)f_4715},
{"f_4693:setup_api_scm",(void*)f_4693},
{"f_4704:setup_api_scm",(void*)f_4704},
{"f_4700:setup_api_scm",(void*)f_4700},
{"f_4586:setup_api_scm",(void*)f_4586},
{"f_4590:setup_api_scm",(void*)f_4590},
{"f_4665:setup_api_scm",(void*)f_4665},
{"f_4621:setup_api_scm",(void*)f_4621},
{"f_4625:setup_api_scm",(void*)f_4625},
{"f_4633:setup_api_scm",(void*)f_4633},
{"f_4646:setup_api_scm",(void*)f_4646},
{"f_4652:setup_api_scm",(void*)f_4652},
{"f_4628:setup_api_scm",(void*)f_4628},
{"f_4616:setup_api_scm",(void*)f_4616},
{"f_4612:setup_api_scm",(void*)f_4612},
{"f_4533:setup_api_scm",(void*)f_4533},
{"f_4537:setup_api_scm",(void*)f_4537},
{"f_4575:setup_api_scm",(void*)f_4575},
{"f_4581:setup_api_scm",(void*)f_4581},
{"f_4540:setup_api_scm",(void*)f_4540},
{"f_4545:setup_api_scm",(void*)f_4545},
{"f_4572:setup_api_scm",(void*)f_4572},
{"f_4568:setup_api_scm",(void*)f_4568},
{"f_4552:setup_api_scm",(void*)f_4552},
{"f_4558:setup_api_scm",(void*)f_4558},
{"f_4564:setup_api_scm",(void*)f_4564},
{"f_4519:setup_api_scm",(void*)f_4519},
{"f_4531:setup_api_scm",(void*)f_4531},
{"f_4527:setup_api_scm",(void*)f_4527},
{"f_4475:setup_api_scm",(void*)f_4475},
{"f_4479:setup_api_scm",(void*)f_4479},
{"f_4498:setup_api_scm",(void*)f_4498},
{"f_4488:setup_api_scm",(void*)f_4488},
{"f_4465:setup_api_scm",(void*)f_4465},
{"f_4473:setup_api_scm",(void*)f_4473},
{"f_4298:setup_api_scm",(void*)f_4298},
{"f_4329:setup_api_scm",(void*)f_4329},
{"f_4333:setup_api_scm",(void*)f_4333},
{"f_4335:setup_api_scm",(void*)f_4335},
{"f_4415:setup_api_scm",(void*)f_4415},
{"f_4301:setup_api_scm",(void*)f_4301},
{"f_4322:setup_api_scm",(void*)f_4322},
{"f_4318:setup_api_scm",(void*)f_4318},
{"f_4307:setup_api_scm",(void*)f_4307},
{"f_4311:setup_api_scm",(void*)f_4311},
{"f_4288:setup_api_scm",(void*)f_4288},
{"f_4296:setup_api_scm",(void*)f_4296},
{"f_4274:setup_api_scm",(void*)f_4274},
{"f_4282:setup_api_scm",(void*)f_4282},
{"f_4286:setup_api_scm",(void*)f_4286},
{"f_4165:setup_api_scm",(void*)f_4165},
{"f_4171:setup_api_scm",(void*)f_4171},
{"f_4184:setup_api_scm",(void*)f_4184},
{"f_4196:setup_api_scm",(void*)f_4196},
{"f_4202:setup_api_scm",(void*)f_4202},
{"f_4230:setup_api_scm",(void*)f_4230},
{"f_4241:setup_api_scm",(void*)f_4241},
{"f_4245:setup_api_scm",(void*)f_4245},
{"f_4217:setup_api_scm",(void*)f_4217},
{"f_4224:setup_api_scm",(void*)f_4224},
{"f_4155:setup_api_scm",(void*)f_4155},
{"f_4163:setup_api_scm",(void*)f_4163},
{"f_4135:setup_api_scm",(void*)f_4135},
{"f_4153:setup_api_scm",(void*)f_4153},
{"f_4142:setup_api_scm",(void*)f_4142},
{"f_4149:setup_api_scm",(void*)f_4149},
{"f_4023:setup_api_scm",(void*)f_4023},
{"f_4027:setup_api_scm",(void*)f_4027},
{"f_4129:setup_api_scm",(void*)f_4129},
{"f_4030:setup_api_scm",(void*)f_4030},
{"f_4126:setup_api_scm",(void*)f_4126},
{"f_4033:setup_api_scm",(void*)f_4033},
{"f_4123:setup_api_scm",(void*)f_4123},
{"f_4036:setup_api_scm",(void*)f_4036},
{"f_4117:setup_api_scm",(void*)f_4117},
{"f_4039:setup_api_scm",(void*)f_4039},
{"f_4114:setup_api_scm",(void*)f_4114},
{"f_4042:setup_api_scm",(void*)f_4042},
{"f_4045:setup_api_scm",(void*)f_4045},
{"f_4048:setup_api_scm",(void*)f_4048},
{"f_4108:setup_api_scm",(void*)f_4108},
{"f_4051:setup_api_scm",(void*)f_4051},
{"f_4099:setup_api_scm",(void*)f_4099},
{"f_4085:setup_api_scm",(void*)f_4085},
{"f_4088:setup_api_scm",(void*)f_4088},
{"f_4054:setup_api_scm",(void*)f_4054},
{"f_4057:setup_api_scm",(void*)f_4057},
{"f_4071:setup_api_scm",(void*)f_4071},
{"f_4067:setup_api_scm",(void*)f_4067},
{"f_4060:setup_api_scm",(void*)f_4060},
{"f_3970:setup_api_scm",(void*)f_3970},
{"f_3974:setup_api_scm",(void*)f_3974},
{"f_3983:setup_api_scm",(void*)f_3983},
{"f_3995:setup_api_scm",(void*)f_3995},
{"f_4021:setup_api_scm",(void*)f_4021},
{"f_3989:setup_api_scm",(void*)f_3989},
{"f_3977:setup_api_scm",(void*)f_3977},
{"f_3915:setup_api_scm",(void*)f_3915},
{"f_3919:setup_api_scm",(void*)f_3919},
{"f_3928:setup_api_scm",(void*)f_3928},
{"f_3935:setup_api_scm",(void*)f_3935},
{"f_3939:setup_api_scm",(void*)f_3939},
{"f_3922:setup_api_scm",(void*)f_3922},
{"f_3925:setup_api_scm",(void*)f_3925},
{"f_3779:setup_api_scm",(void*)f_3779},
{"f_3783:setup_api_scm",(void*)f_3783},
{"f_3789:setup_api_scm",(void*)f_3789},
{"f_3792:setup_api_scm",(void*)f_3792},
{"f_3795:setup_api_scm",(void*)f_3795},
{"f_3881:setup_api_scm",(void*)f_3881},
{"f_3798:setup_api_scm",(void*)f_3798},
{"f_3832:setup_api_scm",(void*)f_3832},
{"f_3839:setup_api_scm",(void*)f_3839},
{"f_3842:setup_api_scm",(void*)f_3842},
{"f_3868:setup_api_scm",(void*)f_3868},
{"f_3845:setup_api_scm",(void*)f_3845},
{"f_3801:setup_api_scm",(void*)f_3801},
{"f_3830:setup_api_scm",(void*)f_3830},
{"f_3804:setup_api_scm",(void*)f_3804},
{"f_3622:setup_api_scm",(void*)f_3622},
{"f_3626:setup_api_scm",(void*)f_3626},
{"f_3642:setup_api_scm",(void*)f_3642},
{"f_3645:setup_api_scm",(void*)f_3645},
{"f_3648:setup_api_scm",(void*)f_3648},
{"f_3745:setup_api_scm",(void*)f_3745},
{"f_3651:setup_api_scm",(void*)f_3651},
{"f_3709:setup_api_scm",(void*)f_3709},
{"f_3723:setup_api_scm",(void*)f_3723},
{"f_3727:setup_api_scm",(void*)f_3727},
{"f_3654:setup_api_scm",(void*)f_3654},
{"f_3662:setup_api_scm",(void*)f_3662},
{"f_3669:setup_api_scm",(void*)f_3669},
{"f_3672:setup_api_scm",(void*)f_3672},
{"f_3698:setup_api_scm",(void*)f_3698},
{"f_3675:setup_api_scm",(void*)f_3675},
{"f_3657:setup_api_scm",(void*)f_3657},
{"f_3628:setup_api_scm",(void*)f_3628},
{"f_3288:setup_api_scm",(void*)f_3288},
{"f_3295:setup_api_scm",(void*)f_3295},
{"f_3298:setup_api_scm",(void*)f_3298},
{"f_3337:setup_api_scm",(void*)f_3337},
{"f_3341:setup_api_scm",(void*)f_3341},
{"f_3347:setup_api_scm",(void*)f_3347},
{"f_3350:setup_api_scm",(void*)f_3350},
{"f_3353:setup_api_scm",(void*)f_3353},
{"f_3356:setup_api_scm",(void*)f_3356},
{"f_3456:setup_api_scm",(void*)f_3456},
{"f_3463:setup_api_scm",(void*)f_3463},
{"f_3585:setup_api_scm",(void*)f_3585},
{"f_3556:setup_api_scm",(void*)f_3556},
{"f_3575:setup_api_scm",(void*)f_3575},
{"f_3466:setup_api_scm",(void*)f_3466},
{"f_3469:setup_api_scm",(void*)f_3469},
{"f_3553:setup_api_scm",(void*)f_3553},
{"f_3472:setup_api_scm",(void*)f_3472},
{"f_3530:setup_api_scm",(void*)f_3530},
{"f_3522:setup_api_scm",(void*)f_3522},
{"f_3487:setup_api_scm",(void*)f_3487},
{"f_3506:setup_api_scm",(void*)f_3506},
{"f_3478:setup_api_scm",(void*)f_3478},
{"f_3359:setup_api_scm",(void*)f_3359},
{"f_3362:setup_api_scm",(void*)f_3362},
{"f_3454:setup_api_scm",(void*)f_3454},
{"f_3365:setup_api_scm",(void*)f_3365},
{"f_3427:setup_api_scm",(void*)f_3427},
{"f_3435:setup_api_scm",(void*)f_3435},
{"f_3443:setup_api_scm",(void*)f_3443},
{"f_3430:setup_api_scm",(void*)f_3430},
{"f_3371:setup_api_scm",(void*)f_3371},
{"f_3383:setup_api_scm",(void*)f_3383},
{"f_3391:setup_api_scm",(void*)f_3391},
{"f_3395:setup_api_scm",(void*)f_3395},
{"f_3398:setup_api_scm",(void*)f_3398},
{"f_3386:setup_api_scm",(void*)f_3386},
{"f_3377:setup_api_scm",(void*)f_3377},
{"f_3234:setup_api_scm",(void*)f_3234},
{"f_3240:setup_api_scm",(void*)f_3240},
{"f_3253:setup_api_scm",(void*)f_3253},
{"f_3256:setup_api_scm",(void*)f_3256},
{"f_3209:setup_api_scm",(void*)f_3209},
{"f_3229:setup_api_scm",(void*)f_3229},
{"f_3187:setup_api_scm",(void*)f_3187},
{"f_3207:setup_api_scm",(void*)f_3207},
{"f_3132:setup_api_scm",(void*)f_3132},
{"f_3139:setup_api_scm",(void*)f_3139},
{"f_3142:setup_api_scm",(void*)f_3142},
{"f_3161:setup_api_scm",(void*)f_3161},
{"f_3169:setup_api_scm",(void*)f_3169},
{"f_2982:setup_api_scm",(void*)f_2982},
{"f_3084:setup_api_scm",(void*)f_3084},
{"f_3075:setup_api_scm",(void*)f_3075},
{"f_3083:setup_api_scm",(void*)f_3083},
{"f_2984:setup_api_scm",(void*)f_2984},
{"f_2991:setup_api_scm",(void*)f_2991},
{"f_3058:setup_api_scm",(void*)f_3058},
{"f_3048:setup_api_scm",(void*)f_3048},
{"f_2994:setup_api_scm",(void*)f_2994},
{"f_2997:setup_api_scm",(void*)f_2997},
{"f_3003:setup_api_scm",(void*)f_3003},
{"f_3006:setup_api_scm",(void*)f_3006},
{"f_3025:setup_api_scm",(void*)f_3025},
{"f_3033:setup_api_scm",(void*)f_3033},
{"f_3009:setup_api_scm",(void*)f_3009},
{"f_2868:setup_api_scm",(void*)f_2868},
{"f_2980:setup_api_scm",(void*)f_2980},
{"f_2976:setup_api_scm",(void*)f_2976},
{"f_2965:setup_api_scm",(void*)f_2965},
{"f_2875:setup_api_scm",(void*)f_2875},
{"f_2878:setup_api_scm",(void*)f_2878},
{"f_2962:setup_api_scm",(void*)f_2962},
{"f_2837:setup_api_scm",(void*)f_2837},
{"f_2881:setup_api_scm",(void*)f_2881},
{"f_2954:setup_api_scm",(void*)f_2954},
{"f_2913:setup_api_scm",(void*)f_2913},
{"f_2945:setup_api_scm",(void*)f_2945},
{"f_2916:setup_api_scm",(void*)f_2916},
{"f_2935:setup_api_scm",(void*)f_2935},
{"f_2943:setup_api_scm",(void*)f_2943},
{"f_2884:setup_api_scm",(void*)f_2884},
{"f_2910:setup_api_scm",(void*)f_2910},
{"f_2790:setup_api_scm",(void*)f_2790},
{"f_2822:setup_api_scm",(void*)f_2822},
{"f_2500:setup_api_scm",(void*)f_2500},
{"f_2788:setup_api_scm",(void*)f_2788},
{"f_2504:setup_api_scm",(void*)f_2504},
{"f_2332:setup_api_scm",(void*)f_2332},
{"f_2341:setup_api_scm",(void*)f_2341},
{"f_2346:setup_api_scm",(void*)f_2346},
{"f_2353:setup_api_scm",(void*)f_2353},
{"f_2356:setup_api_scm",(void*)f_2356},
{"f_2365:setup_api_scm",(void*)f_2365},
{"f_2368:setup_api_scm",(void*)f_2368},
{"f_2407:setup_api_scm",(void*)f_2407},
{"f_2415:setup_api_scm",(void*)f_2415},
{"f_2377:setup_api_scm",(void*)f_2377},
{"f_2507:setup_api_scm",(void*)f_2507},
{"f_2492:setup_api_scm",(void*)f_2492},
{"f_2510:setup_api_scm",(void*)f_2510},
{"f_2515:setup_api_scm",(void*)f_2515},
{"f_2519:setup_api_scm",(void*)f_2519},
{"f_2777:setup_api_scm",(void*)f_2777},
{"f_2772:setup_api_scm",(void*)f_2772},
{"f_2734:setup_api_scm",(void*)f_2734},
{"f_2740:setup_api_scm",(void*)f_2740},
{"f_2753:setup_api_scm",(void*)f_2753},
{"f_2745:setup_api_scm",(void*)f_2745},
{"f_2521:setup_api_scm",(void*)f_2521},
{"f_2257:setup_api_scm",(void*)f_2257},
{"f_2270:setup_api_scm",(void*)f_2270},
{"f_2276:setup_api_scm",(void*)f_2276},
{"f_2248:setup_api_scm",(void*)f_2248},
{"f_2525:setup_api_scm",(void*)f_2525},
{"f_2528:setup_api_scm",(void*)f_2528},
{"f_2728:setup_api_scm",(void*)f_2728},
{"f_2531:setup_api_scm",(void*)f_2531},
{"f_2722:setup_api_scm",(void*)f_2722},
{"f_2534:setup_api_scm",(void*)f_2534},
{"f_2719:setup_api_scm",(void*)f_2719},
{"f_2704:setup_api_scm",(void*)f_2704},
{"f_2705:setup_api_scm",(void*)f_2705},
{"f_2543:setup_api_scm",(void*)f_2543},
{"f_2673:setup_api_scm",(void*)f_2673},
{"f_2677:setup_api_scm",(void*)f_2677},
{"f_2693:setup_api_scm",(void*)f_2693},
{"f_2700:setup_api_scm",(void*)f_2700},
{"f_2680:setup_api_scm",(void*)f_2680},
{"f_2690:setup_api_scm",(void*)f_2690},
{"f_2549:setup_api_scm",(void*)f_2549},
{"f_2639:setup_api_scm",(void*)f_2639},
{"f_2668:setup_api_scm",(void*)f_2668},
{"f_2646:setup_api_scm",(void*)f_2646},
{"f_2568:setup_api_scm",(void*)f_2568},
{"f_2576:setup_api_scm",(void*)f_2576},
{"f_2611:setup_api_scm",(void*)f_2611},
{"f_2626:setup_api_scm",(void*)f_2626},
{"f_2632:setup_api_scm",(void*)f_2632},
{"f_2617:setup_api_scm",(void*)f_2617},
{"f_2582:setup_api_scm",(void*)f_2582},
{"f_2588:setup_api_scm",(void*)f_2588},
{"f_2606:setup_api_scm",(void*)f_2606},
{"f_2603:setup_api_scm",(void*)f_2603},
{"f_2592:setup_api_scm",(void*)f_2592},
{"f_2574:setup_api_scm",(void*)f_2574},
{"f_2312:setup_api_scm",(void*)f_2312},
{"f_2320:setup_api_scm",(void*)f_2320},
{"f_2302:setup_api_scm",(void*)f_2302},
{"f_2310:setup_api_scm",(void*)f_2310},
{"f_2196:setup_api_scm",(void*)f_2196},
{"f_2244:setup_api_scm",(void*)f_2244},
{"f_2227:setup_api_scm",(void*)f_2227},
{"f_2237:setup_api_scm",(void*)f_2237},
{"f_2231:setup_api_scm",(void*)f_2231},
{"f_2199:setup_api_scm",(void*)f_2199},
{"f_2203:setup_api_scm",(void*)f_2203},
{"f_2164:setup_api_scm",(void*)f_2164},
{"f_2143:setup_api_scm",(void*)f_2143},
{"f_2125:setup_api_scm",(void*)f_2125},
{"f_2139:setup_api_scm",(void*)f_2139},
{"f_2136:setup_api_scm",(void*)f_2136},
{"f_2121:setup_api_scm",(void*)f_2121},
{"f_2214:setup_api_scm",(void*)f_2214},
{"f_2170:setup_api_scm",(void*)f_2170},
{"f_2194:setup_api_scm",(void*)f_2194},
{"f_2177:setup_api_scm",(void*)f_2177},
{"f_2015:setup_api_scm",(void*)f_2015},
{"f_2098:setup_api_scm",(void*)f_2098},
{"f_2019:setup_api_scm",(void*)f_2019},
{"f_2073:setup_api_scm",(void*)f_2073},
{"f_2076:setup_api_scm",(void*)f_2076},
{"f_2087:setup_api_scm",(void*)f_2087},
{"f_2091:setup_api_scm",(void*)f_2091},
{"f_2083:setup_api_scm",(void*)f_2083},
{"f_2034:setup_api_scm",(void*)f_2034},
{"f_2044:setup_api_scm",(void*)f_2044},
{"f_2050:setup_api_scm",(void*)f_2050},
{"f_2054:setup_api_scm",(void*)f_2054},
{"f_2070:setup_api_scm",(void*)f_2070},
{"f_2063:setup_api_scm",(void*)f_2063},
{"f_1935:setup_api_scm",(void*)f_1935},
{"f_1939:setup_api_scm",(void*)f_1939},
{"f_2009:setup_api_scm",(void*)f_2009},
{"f_1942:setup_api_scm",(void*)f_1942},
{"f_1947:setup_api_scm",(void*)f_1947},
{"f_1951:setup_api_scm",(void*)f_1951},
{"f_1954:setup_api_scm",(void*)f_1954},
{"f_1957:setup_api_scm",(void*)f_1957},
{"f_1960:setup_api_scm",(void*)f_1960},
{"f_1963:setup_api_scm",(void*)f_1963},
{"f_1987:setup_api_scm",(void*)f_1987},
{"f_4824:setup_api_scm",(void*)f_4824},
{"f_4828:setup_api_scm",(void*)f_4828},
{"f_4839:setup_api_scm",(void*)f_4839},
{"f_4835:setup_api_scm",(void*)f_4835},
{"f_4816:setup_api_scm",(void*)f_4816},
{"f_4820:setup_api_scm",(void*)f_4820},
{"f_1916:setup_api_scm",(void*)f_1916},
{"f_1923:setup_api_scm",(void*)f_1923},
{"f_1884:setup_api_scm",(void*)f_1884},
{"f_1890:setup_api_scm",(void*)f_1890},
{"f_1914:setup_api_scm",(void*)f_1914},
{"f_1897:setup_api_scm",(void*)f_1897},
{"f_1907:setup_api_scm",(void*)f_1907},
{"f_1900:setup_api_scm",(void*)f_1900},
{"f_1859:setup_api_scm",(void*)f_1859},
{"f_1833:setup_api_scm",(void*)f_1833},
{"f_1764:setup_api_scm",(void*)f_1764},
{"f_1754:setup_api_scm",(void*)f_1754},
{"f_1762:setup_api_scm",(void*)f_1762},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
