/* Generated from eval.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:35
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: eval.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file ueval.c
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_EGG_HOME
# define C_INSTALL_EGG_HOME    "."
#endif

#ifndef C_INSTALL_SHARE_HOME
# define C_INSTALL_SHARE_HOME NULL
#endif


#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_expand_toplevel)
C_externimport void C_ccall C_expand_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[400];
static double C_possibly_force_alignment;


/* from ##sys#clear-trace-buffer in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static C_word C_fcall stub2781(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2781(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_clear_trace_buffer();
return C_r;}

C_noret_decl(C_eval_toplevel)
C_externexport void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_10231)
static void C_ccall f_10231r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_10235)
static void C_fcall f_10235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10260)
static void C_ccall f_10260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10250)
static void C_ccall f_10250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10258)
static void C_ccall f_10258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10243)
static void C_ccall f_10243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10241)
static void C_ccall f_10241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6784)
static void C_ccall f_6784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10225)
static void C_ccall f_10225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10221)
static void C_ccall f_10221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10217)
static void C_ccall f_10217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10213)
static void C_ccall f_10213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10203)
static void C_fcall f_10203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7312)
static void C_fcall f_7312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10181)
static void C_ccall f_10181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10173)
static void C_ccall f_10173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10175)
static void C_ccall f_10175(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10142)
static void C_ccall f_10142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10162)
static void C_ccall f_10162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10158)
static void C_ccall f_10158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10148)
static void C_ccall f_10148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7677)
static void C_ccall f_7677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10088)
static void C_ccall f_10088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10102)
static void C_fcall f_10102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10138)
static void C_ccall f_10138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10134)
static void C_ccall f_10134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10122)
static void C_ccall f_10122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10126)
static void C_ccall f_10126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10096)
static void C_ccall f_10096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8520)
static void C_ccall f_8520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9991)
static void C_ccall f_9991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10028)
static void C_fcall f_10028(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10031)
static void C_ccall f_10031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10054)
static void C_ccall f_10054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10040)
static void C_ccall f_10040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10037)
static void C_ccall f_10037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9994)
static void C_fcall f_9994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8523)
static void C_ccall f_8523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9989)
static void C_ccall f_9989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8932)
static void C_ccall f_8932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8936)
static void C_ccall f_8936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9985)
static void C_ccall f_9985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8939)
static void C_ccall f_8939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8943)
static void C_ccall f_8943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9977)
static void C_ccall f_9977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9232)
static void C_ccall f_9232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9595)
static void C_ccall f_9595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9968)
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9975)
static void C_ccall f_9975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9958)
static void C_ccall f_9958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9943)
static void C_ccall f_9943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9947)
static void C_ccall f_9947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9952)
static void C_ccall f_9952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9956)
static void C_ccall f_9956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9921)
static void C_ccall f_9921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9925)
static void C_ccall f_9925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9930)
static void C_ccall f_9930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9934)
static void C_ccall f_9934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9941)
static void C_ccall f_9941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9895)
static void C_ccall f_9895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9901)
static void C_ccall f_9901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9905)
static void C_ccall f_9905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9908)
static void C_ccall f_9908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9915)
static void C_ccall f_9915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9879)
static void C_ccall f_9879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9885)
static void C_ccall f_9885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9893)
static void C_ccall f_9893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9842)
static void C_ccall f_9842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9846)
static void C_ccall f_9846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9851)
static void C_ccall f_9851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9855)
static void C_ccall f_9855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9877)
static void C_ccall f_9877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9873)
static void C_ccall f_9873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9869)
static void C_ccall f_9869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9858)
static void C_ccall f_9858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9816)
static void C_ccall f_9816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9822)
static void C_ccall f_9822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9826)
static void C_ccall f_9826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9840)
static void C_ccall f_9840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9829)
static void C_ccall f_9829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9836)
static void C_ccall f_9836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9803)
static C_word C_fcall f_9803(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_9777)
static void C_ccall f_9777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9781)
static void C_ccall f_9781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9790)
static void C_ccall f_9790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9801)
static void C_ccall f_9801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9797)
static void C_ccall f_9797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9761)
static void C_ccall f_9761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9767)
static void C_ccall f_9767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9775)
static void C_ccall f_9775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9740)
static void C_fcall f_9740(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9744)
static void C_ccall f_9744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9681)
static void C_fcall f_9681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9691)
static void C_ccall f_9691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9716)
static void C_ccall f_9716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9728)
static void C_ccall f_9728(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9728)
static void C_ccall f_9728r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9734)
static void C_ccall f_9734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9722)
static void C_ccall f_9722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9697)
static void C_ccall f_9697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9703)
static void C_ccall f_9703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9707)
static void C_ccall f_9707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9710)
static void C_ccall f_9710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9714)
static void C_ccall f_9714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9689)
static void C_ccall f_9689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9606)
static void C_ccall f_9606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9616)
static void C_ccall f_9616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9619)
static void C_ccall f_9619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9633)
static void C_fcall f_9633(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9651)
static void C_ccall f_9651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9620)
static void C_fcall f_9620(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9597)
static void C_ccall f_9597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9253)
static void C_ccall f_9253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9297)
static void C_ccall f_9297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9300)
static void C_ccall f_9300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9580)
static void C_ccall f_9580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9584)
static void C_ccall f_9584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9588)
static void C_ccall f_9588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9382)
static void C_ccall f_9382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9388)
static void C_fcall f_9388(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9563)
static void C_ccall f_9563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9569)
static void C_ccall f_9569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9395)
static void C_ccall f_9395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9401)
static void C_ccall f_9401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9558)
static void C_ccall f_9558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9410)
static void C_ccall f_9410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9413)
static void C_ccall f_9413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9428)
static void C_ccall f_9428(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9428)
static void C_ccall f_9428r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_9446)
static void C_fcall f_9446(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9462)
static void C_ccall f_9462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9470)
static void C_ccall f_9470(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9474)
static void C_ccall f_9474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9477)
static void C_ccall f_9477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9489)
static void C_ccall f_9489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9492)
static void C_ccall f_9492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9480)
static void C_ccall f_9480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9465)
static void C_ccall f_9465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9432)
static void C_ccall f_9432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9278)
static void C_fcall f_9278(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9283)
static void C_ccall f_9283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9435)
static void C_ccall f_9435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9419)
static void C_ccall f_9419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9317)
static void C_ccall f_9317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9330)
static void C_ccall f_9330(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_9330)
static void C_ccall f_9330r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9337)
static void C_ccall f_9337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9340)
static void C_ccall f_9340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9352)
static void C_fcall f_9352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9361)
static void C_ccall f_9361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9355)
static void C_ccall f_9355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9343)
static void C_ccall f_9343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9346)
static void C_ccall f_9346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9308)
static C_word C_fcall f_9308(C_word t0);
C_noret_decl(f_9302)
static C_word C_fcall f_9302(C_word t0);
C_noret_decl(f_9256)
static void C_fcall f_9256(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9262)
static void C_ccall f_9262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9250)
static void C_ccall f_9250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9234)
static void C_ccall f_9234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9245)
static void C_ccall f_9245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9215)
static void C_ccall f_9215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9224)
static void C_ccall f_9224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9219)
static void C_ccall f_9219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9155)
static void C_ccall f_9155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9159)
static void C_ccall f_9159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9162)
static void C_ccall f_9162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9165)
static void C_ccall f_9165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9168)
static void C_ccall f_9168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9171)
static void C_ccall f_9171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9174)
static void C_ccall f_9174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9177)
static void C_ccall f_9177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9180)
static void C_ccall f_9180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9183)
static void C_ccall f_9183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9134)
static void C_fcall f_9134(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9138)
static void C_ccall f_9138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9141)
static void C_ccall f_9141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_fcall f_9110(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9116)
static void C_fcall f_9116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8968)
static void C_ccall f_8968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8968)
static void C_ccall f_8968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9039)
static void C_ccall f_9039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9096)
static void C_ccall f_9096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9089)
static void C_fcall f_9089(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9049)
static void C_ccall f_9049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9051)
static void C_fcall f_9051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9075)
static void C_ccall f_9075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9061)
static void C_ccall f_9061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9009)
static void C_fcall f_9009(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8974)
static void C_fcall f_8974(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8996)
static void C_ccall f_8996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8987)
static void C_ccall f_8987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8949)
static void C_fcall f_8949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8953)
static void C_ccall f_8953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8916)
static void C_fcall f_8916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8918)
static void C_ccall f_8918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8878)
static void C_ccall f_8878r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8885)
static void C_ccall f_8885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8892)
static void C_ccall f_8892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8834)
static void C_ccall f_8834(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8834)
static void C_ccall f_8834r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8867)
static void C_ccall f_8867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8854)
static void C_ccall f_8854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8831)
static void C_ccall f_8831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8712)
static void C_ccall f_8712(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8712)
static void C_ccall f_8712r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8806)
static void C_ccall f_8806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8816)
static void C_ccall f_8816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8804)
static void C_ccall f_8804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8733)
static void C_fcall f_8733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8757)
static void C_fcall f_8757(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8776)
static void C_ccall f_8776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8604)
static void C_ccall f_8604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_8604)
static void C_ccall f_8604r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8619)
static void C_fcall f_8619(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8646)
static void C_fcall f_8646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8640)
static void C_ccall f_8640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8588)
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8529)
static void C_ccall f_8529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8537)
static void C_fcall f_8537(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8557)
static void C_fcall f_8557(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8481)
static void C_ccall f_8481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8513)
static void C_ccall f_8513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8499)
static void C_ccall f_8499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7974)
static void C_ccall f_7974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8349)
static void C_fcall f_8349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8358)
static void C_ccall f_8358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8388)
static void C_ccall f_8388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8390)
static void C_fcall f_8390(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8427)
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8417)
static void C_ccall f_8417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8412)
static void C_ccall f_8412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8408)
static void C_ccall f_8408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_fcall f_8043(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8206)
static void C_ccall f_8206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8311)
static void C_ccall f_8311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8318)
static void C_ccall f_8318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8218)
static void C_ccall f_8218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8237)
static void C_fcall f_8237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8259)
static void C_ccall f_8259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8245)
static void C_fcall f_8245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_ccall f_8225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8120)
static void C_ccall f_8120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8138)
static void C_fcall f_8138(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8150)
static void C_fcall f_8150(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8146)
static void C_ccall f_8146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8077)
static void C_fcall f_8077(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8073)
static void C_ccall f_8073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8060)
static void C_ccall f_8060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_fcall f_8002(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8021)
static void C_ccall f_8021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8018)
static void C_fcall f_8018(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8014)
static void C_ccall f_8014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_fcall f_7977(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7996)
static void C_ccall f_7996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7990)
static void C_ccall f_7990(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7925)
static void C_ccall f_7925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7931)
static void C_fcall f_7931(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7945)
static void C_ccall f_7945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7948)
static void C_fcall f_7948(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7955)
static void C_ccall f_7955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7886)
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7890)
static void C_ccall f_7890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7917)
static void C_ccall f_7917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7902)
static void C_ccall f_7902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7879)
static void C_ccall f_7879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7839)
static void C_ccall f_7839r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7852)
static void C_ccall f_7852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7775)
static void C_fcall f_7775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7680)
static void C_ccall f_7680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7684)
static void C_ccall f_7684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7732)
static void C_ccall f_7732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7734)
static void C_fcall f_7734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7747)
static void C_ccall f_7747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7686)
static void C_fcall f_7686(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7690)
static void C_ccall f_7690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7725)
static void C_ccall f_7725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7696)
static void C_ccall f_7696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7706)
static void C_ccall f_7706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7622)
static void C_fcall f_7622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7647)
static void C_ccall f_7647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7544)
static void C_fcall f_7544(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7583)
static void C_ccall f_7583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7570)
static void C_ccall f_7570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7526)
static C_word C_fcall f_7526(C_word t0);
C_noret_decl(f_7520)
static void C_fcall f_7520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7432)
static void C_ccall f_7432r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_ccall f_7449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7326)
static void C_ccall f_7326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7330)
static void C_ccall f_7330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7426)
static void C_ccall f_7426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_fcall f_7339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_ccall f_7408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7342)
static void C_ccall f_7342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7391)
static void C_ccall f_7391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7397)
static void C_ccall f_7397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7350)
static void C_fcall f_7350(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7384)
static void C_ccall f_7384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7363)
static void C_ccall f_7363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7366)
static void C_fcall f_7366(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7286)
static void C_ccall f_7286r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_ccall f_7290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7304)
static void C_ccall f_7304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7293)
static void C_ccall f_7293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7296)
static void C_ccall f_7296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7250)
static void C_ccall f_7250(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7250)
static void C_ccall f_7250r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7258)
static void C_ccall f_7258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7228)
static void C_ccall f_7228(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7228)
static void C_ccall f_7228r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6832)
static void C_ccall f_6832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_7183)
static void C_fcall f_7183(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7178)
static void C_fcall f_7178(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6834)
static void C_fcall f_6834(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7177)
static void C_ccall f_7177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6838)
static void C_fcall f_6838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7099)
static void C_ccall f_7099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7114)
static void C_ccall f_7114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7117)
static void C_fcall f_7117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7120)
static void C_ccall f_7120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7126)
static void C_ccall f_7126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7129)
static void C_ccall f_7129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7135)
static void C_ccall f_7135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6841)
static void C_ccall f_6841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7090)
static void C_ccall f_7090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7081)
static void C_ccall f_7081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7035)
static void C_ccall f_7035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7010)
static void C_ccall f_7010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6883)
static void C_ccall f_6883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6887)
static void C_ccall f_6887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7001)
static void C_ccall f_7001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6899)
static void C_ccall f_6899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6902)
static void C_ccall f_6902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6905)
static void C_ccall f_6905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6910)
static void C_fcall f_6910(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6966)
static void C_ccall f_6966(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6966)
static void C_ccall f_6966r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6975)
static void C_ccall f_6975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6979)
static void C_ccall f_6979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6950)
static void C_ccall f_6950r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6961)
static void C_ccall f_6961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6954)
static void C_ccall f_6954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6923)
static void C_ccall f_6923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6892)
static void C_ccall f_6892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6872)
static void C_ccall f_6872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6853)
static void C_ccall f_6853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6786)
static void C_fcall f_6786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6796)
static C_word C_fcall f_6796(C_word t0,C_word t1);
C_noret_decl(f_6711)
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6723)
static void C_fcall f_6723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6736)
static void C_ccall f_6736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6718)
static void C_ccall f_6718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6705)
static void C_ccall f_6705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6621)
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6634)
static void C_fcall f_6634(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6624)
static void C_fcall f_6624(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6611)
static void C_ccall f_6611r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6360)
static void C_fcall f_6360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6364)
static void C_ccall f_6364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6553)
static void C_ccall f_6553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6565)
static void C_ccall f_6565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6510)
static void C_ccall f_6510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6513)
static void C_ccall f_6513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6516)
static void C_ccall f_6516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_ccall f_6519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6520)
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6543)
static void C_ccall f_6543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6546)
static void C_ccall f_6546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6468)
static void C_ccall f_6468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6474)
static void C_ccall f_6474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6494)
static void C_ccall f_6494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6497)
static void C_ccall f_6497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6433)
static void C_ccall f_6433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6436)
static void C_ccall f_6436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6448)
static void C_ccall f_6448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6452)
static void C_ccall f_6452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6455)
static void C_ccall f_6455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6386)
static void C_ccall f_6386(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6334)
static C_word C_fcall f_6334(C_word t0,C_word t1);
C_noret_decl(f_3926)
static void C_fcall f_3926(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_fcall f_4109(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_ccall f_4132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6131)
static void C_fcall f_6131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_ccall f_6114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6083)
static void C_ccall f_6083(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6072)
static void C_ccall f_6072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6031)
static void C_ccall f_6031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6015)
static void C_ccall f_6015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5908)
static void C_ccall f_5908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5914)
static void C_ccall f_5914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5921)
static void C_fcall f_5921(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5895)
static void C_ccall f_5895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5833)
static void C_ccall f_5833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5781)
static void C_ccall f_5781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5805)
static C_word C_fcall f_5805(C_word t0);
C_noret_decl(f_5794)
static void C_fcall f_5794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5645)
static void C_ccall f_5645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5773)
static void C_ccall f_5773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_ccall f_5648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5651)
static void C_ccall f_5651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5689)
static void C_fcall f_5689(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_ccall f_5762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5747)
static void C_ccall f_5747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5709)
static void C_fcall f_5709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5659)
static void C_ccall f_5659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5663)
static void C_ccall f_5663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5666)
static void C_ccall f_5666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5673)
static void C_ccall f_5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_fcall f_5590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_fcall f_5509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5512)
static void C_ccall f_5512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5483)
static void C_ccall f_5483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5451)
static void C_ccall f_5451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5402)
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5392)
static void C_ccall f_5392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5366)
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5352)
static void C_ccall f_5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_6288)
static void C_fcall f_6288(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
C_noret_decl(f_5248)
static void C_ccall f_5248r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4596)
static void C_ccall f_4596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4602)
static void C_ccall f_4602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_ccall f_4903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4605)
static void C_ccall f_4605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4840)
static void C_ccall f_4840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4845)
static void C_ccall f_4845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_fcall f_4857(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4882)
static void C_ccall f_4882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4776)
static void C_ccall f_4776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_ccall f_4797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4805)
static void C_ccall f_4805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4648)
static void C_ccall f_4648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4652)
static void C_ccall f_4652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4672)
static void C_ccall f_4672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4614)
static void C_ccall f_4614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4472)
static void C_ccall f_4472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4490)
static void C_ccall f_4490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4540)
static void C_ccall f_4540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4505)
static void C_ccall f_4505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_ccall f_4480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_ccall f_4425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4405)
static void C_ccall f_4405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4250)
static void C_ccall f_4250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4214)
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_fcall f_3996(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_fcall f_3991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3992)
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_ccall f_3971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3946)
static void C_ccall f_3946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3875)
static void C_fcall f_3875(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3907)
static void C_ccall f_3907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3884)
static void C_ccall f_3884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_fcall f_3869(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3863)
static C_word C_fcall f_3863(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3857)
static C_word C_fcall f_3857(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3773)
static void C_fcall f_3773(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_fcall f_3785(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3827)
static C_word C_fcall f_3827(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_3758)
static void C_fcall f_3758(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_fcall f_3719(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3732)
static void C_fcall f_3732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3706)
static void C_ccall f_3706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3569)
static void C_fcall f_3569(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3579)
static void C_ccall f_3579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3543)
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_ccall f_3551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3487)
static void C_ccall f_3487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_fcall f_3495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static C_word C_fcall f_3438(C_word t0,C_word t1);
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9958,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))),*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9943,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9921,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9895,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9879,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9842,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9816,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x,s=0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9777,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x,s=0+3,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9761,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x,s=0,*a=C_alloc(s);
C_callback_adjust_stack(a,s);
return C_truep(C_callback_wrapper((void *)f_9749,0));}

C_noret_decl(trf_10235)
static void C_fcall trf_10235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10235(t0,t1);}

C_noret_decl(trf_10203)
static void C_fcall trf_10203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10203(t0,t1);}

C_noret_decl(trf_7312)
static void C_fcall trf_7312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7312(t0,t1);}

C_noret_decl(trf_10102)
static void C_fcall trf_10102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10102(t0,t1,t2);}

C_noret_decl(trf_10028)
static void C_fcall trf_10028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10028(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10028(t0,t1);}

C_noret_decl(trf_9994)
static void C_fcall trf_9994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9994(t0,t1);}

C_noret_decl(trf_9740)
static void C_fcall trf_9740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9740(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9740(t0,t1,t2);}

C_noret_decl(trf_9681)
static void C_fcall trf_9681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9681(t0,t1);}

C_noret_decl(trf_9633)
static void C_fcall trf_9633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9633(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9633(t0,t1);}

C_noret_decl(trf_9620)
static void C_fcall trf_9620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9620(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9620(t0,t1);}

C_noret_decl(trf_9388)
static void C_fcall trf_9388(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9388(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9388(t0,t1);}

C_noret_decl(trf_9446)
static void C_fcall trf_9446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9446(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9446(t0,t1,t2,t3);}

C_noret_decl(trf_9278)
static void C_fcall trf_9278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9278(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9278(t0,t1);}

C_noret_decl(trf_9352)
static void C_fcall trf_9352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9352(t0,t1);}

C_noret_decl(trf_9256)
static void C_fcall trf_9256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9256(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9256(t0,t1);}

C_noret_decl(trf_9134)
static void C_fcall trf_9134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9134(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9134(t0,t1,t2,t3);}

C_noret_decl(trf_9110)
static void C_fcall trf_9110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9110(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9110(t0,t1,t2);}

C_noret_decl(trf_9116)
static void C_fcall trf_9116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9116(t0,t1,t2);}

C_noret_decl(trf_9089)
static void C_fcall trf_9089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9089(t0,t1);}

C_noret_decl(trf_9051)
static void C_fcall trf_9051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9051(t0,t1,t2);}

C_noret_decl(trf_9009)
static void C_fcall trf_9009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9009(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9009(t0,t1,t2);}

C_noret_decl(trf_8974)
static void C_fcall trf_8974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8974(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8974(t0,t1,t2,t3);}

C_noret_decl(trf_8949)
static void C_fcall trf_8949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8949(t0,t1);}

C_noret_decl(trf_8916)
static void C_fcall trf_8916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8916(t0,t1);}

C_noret_decl(trf_8733)
static void C_fcall trf_8733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8733(t0,t1,t2,t3);}

C_noret_decl(trf_8757)
static void C_fcall trf_8757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8757(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8757(t0,t1,t2,t3);}

C_noret_decl(trf_8619)
static void C_fcall trf_8619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8619(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8619(t0,t1,t2);}

C_noret_decl(trf_8646)
static void C_fcall trf_8646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8646(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8646(t0,t1,t2);}

C_noret_decl(trf_8537)
static void C_fcall trf_8537(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8537(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8537(t0,t1,t2);}

C_noret_decl(trf_8557)
static void C_fcall trf_8557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8557(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8557(t0,t1);}

C_noret_decl(trf_8349)
static void C_fcall trf_8349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8349(t0,t1);}

C_noret_decl(trf_8390)
static void C_fcall trf_8390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8390(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8390(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8043)
static void C_fcall trf_8043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8043(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8043(t0,t1,t2);}

C_noret_decl(trf_8237)
static void C_fcall trf_8237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8237(t0,t1);}

C_noret_decl(trf_8245)
static void C_fcall trf_8245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8245(t0,t1);}

C_noret_decl(trf_8138)
static void C_fcall trf_8138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8138(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8138(t0,t1);}

C_noret_decl(trf_8150)
static void C_fcall trf_8150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8150(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8150(t0,t1);}

C_noret_decl(trf_8077)
static void C_fcall trf_8077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8077(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8077(t0,t1);}

C_noret_decl(trf_8002)
static void C_fcall trf_8002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8002(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8002(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8018)
static void C_fcall trf_8018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8018(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8018(t0,t1);}

C_noret_decl(trf_7977)
static void C_fcall trf_7977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7977(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7977(t0,t1,t2,t3);}

C_noret_decl(trf_7931)
static void C_fcall trf_7931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7931(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7931(t0,t1,t2);}

C_noret_decl(trf_7948)
static void C_fcall trf_7948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7948(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7948(t0,t1);}

C_noret_decl(trf_7775)
static void C_fcall trf_7775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7775(t0,t1);}

C_noret_decl(trf_7734)
static void C_fcall trf_7734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7734(t0,t1,t2);}

C_noret_decl(trf_7686)
static void C_fcall trf_7686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7686(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7686(t0,t1,t2);}

C_noret_decl(trf_7622)
static void C_fcall trf_7622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7622(t0,t1,t2);}

C_noret_decl(trf_7544)
static void C_fcall trf_7544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7544(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7544(t0,t1,t2);}

C_noret_decl(trf_7520)
static void C_fcall trf_7520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7520(t0,t1);}

C_noret_decl(trf_7339)
static void C_fcall trf_7339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7339(t0,t1);}

C_noret_decl(trf_7350)
static void C_fcall trf_7350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7350(t0,t1,t2);}

C_noret_decl(trf_7366)
static void C_fcall trf_7366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7366(t0,t1);}

C_noret_decl(trf_7183)
static void C_fcall trf_7183(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7183(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7183(t0,t1);}

C_noret_decl(trf_7178)
static void C_fcall trf_7178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7178(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7178(t0,t1,t2);}

C_noret_decl(trf_6834)
static void C_fcall trf_6834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6834(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6834(t0,t1,t2,t3);}

C_noret_decl(trf_6838)
static void C_fcall trf_6838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6838(t0,t1);}

C_noret_decl(trf_7117)
static void C_fcall trf_7117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7117(t0,t1);}

C_noret_decl(trf_6910)
static void C_fcall trf_6910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6910(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6910(t0,t1,t2);}

C_noret_decl(trf_6786)
static void C_fcall trf_6786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6786(t0,t1);}

C_noret_decl(trf_6723)
static void C_fcall trf_6723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6723(t0,t1,t2);}

C_noret_decl(trf_6634)
static void C_fcall trf_6634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6634(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6634(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6624)
static void C_fcall trf_6624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6624(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6624(t0,t1);}

C_noret_decl(trf_6360)
static void C_fcall trf_6360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6360(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6360(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3926)
static void C_fcall trf_3926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3926(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_3926(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_4109)
static void C_fcall trf_4109(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4109(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4109(t0,t1);}

C_noret_decl(trf_6131)
static void C_fcall trf_6131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6131(t0,t1);}

C_noret_decl(trf_5977)
static void C_fcall trf_5977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5977(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5977(t0,t1,t2);}

C_noret_decl(trf_5921)
static void C_fcall trf_5921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5921(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5921(t0,t1);}

C_noret_decl(trf_5794)
static void C_fcall trf_5794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5794(t0,t1);}

C_noret_decl(trf_5689)
static void C_fcall trf_5689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5689(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5689(t0,t1,t2,t3);}

C_noret_decl(trf_5709)
static void C_fcall trf_5709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5709(t0,t1,t2);}

C_noret_decl(trf_5590)
static void C_fcall trf_5590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5590(t0,t1);}

C_noret_decl(trf_5509)
static void C_fcall trf_5509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5509(t0,t1);}

C_noret_decl(trf_6288)
static void C_fcall trf_6288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6288(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6288(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4857)
static void C_fcall trf_4857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4857(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4857(t0,t1,t2,t3);}

C_noret_decl(trf_3996)
static void C_fcall trf_3996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3996(t0,t1);}

C_noret_decl(trf_3991)
static void C_fcall trf_3991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3991(t0,t1);}

C_noret_decl(trf_3875)
static void C_fcall trf_3875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3875(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3875(t0,t1);}

C_noret_decl(trf_3869)
static void C_fcall trf_3869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3869(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3869(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3773)
static void C_fcall trf_3773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3773(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3773(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3785)
static void C_fcall trf_3785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3785(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3785(t0,t1,t2,t3);}

C_noret_decl(trf_3758)
static void C_fcall trf_3758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3758(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3758(t0,t1,t2,t3);}

C_noret_decl(trf_3719)
static void C_fcall trf_3719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3719(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3719(t0,t1,t2,t3);}

C_noret_decl(trf_3732)
static void C_fcall trf_3732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3732(t0,t1);}

C_noret_decl(trf_3621)
static void C_fcall trf_3621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3621(t0,t1,t2);}

C_noret_decl(trf_3569)
static void C_fcall trf_3569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3569(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3569(t0,t1,t2);}

C_noret_decl(trf_3495)
static void C_fcall trf_3495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3495(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr6r)
static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5rv)
static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6535)){
C_save(t1);
C_rereclaim2(6535*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,400);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],2,"pp");
lf[2]=C_h_intern(&lf[2],5,"print");
lf[3]=C_h_intern(&lf[3],24,"\003syscore-library-modules");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\007lolevel\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005files\376\003\000\000\002\376\001\000\000\003tcp\376\003\000\000"
"\002\376\001\000\000\005regex\376\003\000\000\002\376\001\000\000\014regex-extras\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\006srfi-4"
"\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\007srfi-14\376\003\000\000\002\376\001\000\000\007srfi-18\376\003\000\000\002\376\001\000\000\017data-structures\376\003\000\000"
"\002\376\001\000\000\005ports\376\003\000\000\002\376\001\000\000\016chicken-syntax\376\377\016");
lf[5]=C_h_intern(&lf[5],28,"\003sysexplicit-library-modules");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[10]=C_h_intern(&lf[10],18,"\003syschicken-prefix");
lf[11]=C_h_intern(&lf[11],17,"\003sysstring-append");
lf[12]=C_h_intern(&lf[12],12,"chicken-home");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\015share/chicken");
lf[15]=C_h_intern(&lf[15],15,"\003syshash-symbol");
lf[16]=C_h_intern(&lf[16],18,"\003syshash-table-ref");
lf[17]=C_h_intern(&lf[17],19,"\003syshash-table-set!");
lf[18]=C_h_intern(&lf[18],22,"\003syshash-table-update!");
lf[19]=C_h_intern(&lf[19],23,"\003syshash-table-for-each");
lf[20]=C_h_intern(&lf[20],12,"\003sysfor-each");
lf[21]=C_h_intern(&lf[21],28,"\003sysarbitrary-unbound-symbol");
lf[22]=C_h_intern(&lf[22],23,"\003syshash-table-location");
lf[23]=C_h_intern(&lf[23],20,"\003syseval-environment");
lf[24]=C_h_intern(&lf[24],26,"\003sysenvironment-is-mutable");
lf[25]=C_h_intern(&lf[25],18,"\003syseval-decorator");
lf[26]=C_h_intern(&lf[26],20,"\003sysmake-lambda-info");
lf[27]=C_h_intern(&lf[27],17,"get-output-string");
lf[28]=C_h_intern(&lf[28],5,"write");
lf[29]=C_h_intern(&lf[29],18,"open-output-string");
lf[30]=C_h_intern(&lf[30],19,"\003sysdecorate-lambda");
lf[31]=C_h_intern(&lf[31],19,"\003sysunbound-in-eval");
lf[32]=C_h_intern(&lf[32],20,"\003syseval-debug-level");
lf[33]=C_h_intern(&lf[33],7,"reverse");
lf[34]=C_h_intern(&lf[34],20,"with-input-from-file");
lf[35]=C_h_intern(&lf[35],7,"display");
lf[36]=C_h_intern(&lf[36],22,"\003syscompile-to-closure");
lf[37]=C_h_intern(&lf[37],7,"\003sysget");
lf[38]=C_h_intern(&lf[38],16,"\004coremacro-alias");
lf[39]=C_h_intern(&lf[39],19,"\003sysundefined-value");
lf[40]=C_h_intern(&lf[40],18,"\003syscurrent-thread");
lf[41]=C_h_intern(&lf[41],18,"\003syscurrent-module");
lf[42]=C_h_intern(&lf[42],21,"\003sysmacro-environment");
lf[43]=C_h_intern(&lf[43],28,"\003syscurrent-meta-environment");
lf[44]=C_h_intern(&lf[44],16,"\003sysdynamic-wind");
lf[45]=C_h_intern(&lf[45],26,"\003sysmeta-macro-environment");
lf[46]=C_h_intern(&lf[46],9,"\003syserror");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\020unbound variable");
lf[48]=C_h_intern(&lf[48],21,"\003syssyntax-error-hook");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000!reference to undefined identifier");
lf[50]=C_h_intern(&lf[50],32,"\003syssymbol-has-toplevel-binding\077");
lf[51]=C_h_intern(&lf[51],14,"\004coreprimitive");
lf[52]=C_h_intern(&lf[52],21,"\003sysalias-global-hook");
lf[53]=C_h_intern(&lf[53],5,"quote");
lf[54]=C_h_intern(&lf[54],16,"\003sysstrip-syntax");
lf[55]=C_h_intern(&lf[55],16,"\003syscheck-syntax");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[57]=C_h_intern(&lf[57],6,"syntax");
lf[58]=C_h_intern(&lf[58],11,"\004coresyntax");
lf[59]=C_h_intern(&lf[59],15,"\004coreglobal-ref");
lf[60]=C_h_intern(&lf[60],10,"\004corecheck");
lf[61]=C_h_intern(&lf[61],14,"\004coreimmutable");
lf[62]=C_h_intern(&lf[62],14,"\004coreundefined");
lf[63]=C_h_intern(&lf[63],2,"if");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002if\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\001\376\001\000\000\001_");
lf[66]=C_h_intern(&lf[66],5,"begin");
lf[67]=C_h_intern(&lf[67],10,"\004corebegin");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[69]=C_h_intern(&lf[69],10,"\003sysappend");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[71]=C_h_intern(&lf[71],4,"set!");
lf[72]=C_h_intern(&lf[72],9,"\004coreset!");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000 assignment to immutable variable");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\042assignment of undefined identifier");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[76]=C_h_intern(&lf[76],3,"let");
lf[77]=C_h_intern(&lf[77],8,"\004corelet");
lf[78]=C_h_intern(&lf[78],15,"\003sysmake-vector");
lf[79]=C_h_intern(&lf[79],7,"\003sysmap");
lf[80]=C_h_intern(&lf[80],21,"\003syscanonicalize-body");
lf[81]=C_h_intern(&lf[81],6,"append");
lf[82]=C_h_intern(&lf[82],3,"map");
lf[83]=C_h_intern(&lf[83],4,"cons");
lf[84]=C_h_intern(&lf[84],6,"gensym");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[86]=C_h_intern(&lf[86],6,"letrec");
lf[87]=C_h_intern(&lf[87],11,"\004coreletrec");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[90]=C_h_intern(&lf[90],6,"lambda");
lf[91]=C_h_intern(&lf[91],11,"\004corelambda");
lf[92]=C_h_intern(&lf[92],1,"\077");
lf[93]=C_h_intern(&lf[93],10,"\003sysvector");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\022bad argument count");
lf[96]=C_h_intern(&lf[96],25,"\003sysdecompose-lambda-list");
lf[97]=C_h_intern(&lf[97],31,"\003sysexpand-extended-lambda-list");
lf[98]=C_h_intern(&lf[98],25,"\003sysextended-lambda-list\077");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[100]=C_h_intern(&lf[100],10,"let-syntax");
lf[101]=C_h_intern(&lf[101],18,"\003syser-transformer");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012let-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000\000\001_"
"\376\377\001\000\000\000\001");
lf[103]=C_h_intern(&lf[103],13,"letrec-syntax");
lf[104]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015letrec-syntax\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\000\000\000\002\376\001\000"
"\000\001_\376\377\001\000\000\000\001");
lf[105]=C_h_intern(&lf[105],13,"define-syntax");
lf[106]=C_h_intern(&lf[106],22,"define-compiled-syntax");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[108]=C_h_intern(&lf[108],28,"\003sysextend-macro-environment");
lf[109]=C_h_intern(&lf[109],23,"\003syscurrent-environment");
lf[110]=C_h_intern(&lf[110],26,"\003sysregister-syntax-export");
lf[111]=C_h_intern(&lf[111],5,"caadr");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\001\000\000\013lambda-list\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[113]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[114]=C_h_intern(&lf[114],27,"\004coredefine-compiler-syntax");
lf[115]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[116]=C_h_intern(&lf[116],24,"\004corelet-compiler-syntax");
lf[117]=C_h_intern(&lf[117],11,"\004coremodule");
lf[118]=C_h_intern(&lf[118],29,"\003sysinitial-macro-environment");
lf[119]=C_h_intern(&lf[119],19,"\003sysfinalize-module");
lf[120]=C_h_intern(&lf[120],19,"\003sysregister-module");
lf[121]=C_h_intern(&lf[121],6,"module");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\031modules may not be nested");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid export syntax");
lf[124]=C_h_intern(&lf[124],16,"\004coreloop-lambda");
lf[125]=C_h_intern(&lf[125],17,"\004corenamed-lambda");
lf[126]=C_h_intern(&lf[126],23,"\004corerequire-for-syntax");
lf[127]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[128]=C_h_intern(&lf[128],11,"\003sysrequire");
lf[129]=C_h_intern(&lf[129],31,"\003syslookup-runtime-requirements");
lf[130]=C_h_intern(&lf[130],22,"\004corerequire-extension");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[132]=C_h_intern(&lf[132],22,"\003sysdo-the-right-thing");
lf[133]=C_h_intern(&lf[133],24,"\004coreelaborationtimeonly");
lf[134]=C_h_intern(&lf[134],23,"\004coreelaborationtimetoo");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[136]=C_h_intern(&lf[136],19,"\004corecompiletimetoo");
lf[137]=C_h_intern(&lf[137],20,"\004corecompiletimeonly");
lf[138]=C_h_intern(&lf[138],13,"\004corecallunit");
lf[139]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[140]=C_h_intern(&lf[140],12,"\004coredeclare");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[142]=C_h_intern(&lf[142],10,"\000compiling");
lf[143]=C_h_intern(&lf[143],12,"\003sysfeatures");
lf[144]=C_h_intern(&lf[144],28,"\010compilerprocess-declaration");
lf[145]=C_h_intern(&lf[145],8,"\003syswarn");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000,declarations are ignored in interpreted code");
lf[147]=C_h_intern(&lf[147],13,"define-inline");
lf[148]=C_h_intern(&lf[148],15,"define-constant");
lf[149]=C_h_intern(&lf[149],6,"define");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[151]=C_h_intern(&lf[151],8,"\004coreapp");
lf[152]=C_h_intern(&lf[152],8,"location");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000%cannot evaluate compiler-special-form");
lf[154]=C_h_intern(&lf[154],11,"\004coreinline");
lf[155]=C_h_intern(&lf[155],20,"\004coreinline_allocate");
lf[156]=C_h_intern(&lf[156],19,"\004coreforeign-lambda");
lf[157]=C_h_intern(&lf[157],28,"\004coredefine-foreign-variable");
lf[158]=C_h_intern(&lf[158],29,"\004coredefine-external-variable");
lf[159]=C_h_intern(&lf[159],17,"\004corelet-location");
lf[160]=C_h_intern(&lf[160],22,"\004coreforeign-primitive");
lf[161]=C_h_intern(&lf[161],20,"\004coreforeign-lambda*");
lf[162]=C_h_intern(&lf[162],24,"\004coredefine-foreign-type");
lf[163]=C_h_intern(&lf[163],10,"\003sysexpand");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal non-atomic object");
lf[165]=C_h_intern(&lf[165],11,"\003sysnumber\077");
lf[166]=C_h_intern(&lf[166],8,"keyword\077");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\024malformed expression");
lf[168]=C_h_intern(&lf[168],16,"\003syseval-handler");
lf[169]=C_h_intern(&lf[169],12,"eval-handler");
lf[170]=C_h_intern(&lf[170],4,"eval");
lf[171]=C_h_intern(&lf[171],24,"\003syssyntax-error-culprit");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\032illegal lambda-list syntax");
lf[173]=C_h_intern(&lf[173],12,"load-verbose");
lf[174]=C_h_intern(&lf[174],14,"\003sysabort-load");
lf[175]=C_h_intern(&lf[175],27,"\003syscurrent-source-filename");
lf[176]=C_h_intern(&lf[176],21,"\003syscurrent-load-path");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[178]=C_h_intern(&lf[178],18,"\003sysdload-disabled");
lf[179]=C_h_intern(&lf[179],22,"set-dynamic-load-mode!");
lf[180]=C_h_intern(&lf[180],21,"\003sysset-dlopen-flags!");
lf[181]=C_h_intern(&lf[181],6,"global");
lf[182]=C_h_intern(&lf[182],5,"local");
lf[183]=C_h_intern(&lf[183],4,"lazy");
lf[184]=C_h_intern(&lf[184],3,"now");
lf[185]=C_h_intern(&lf[185],15,"\003syssignal-hook");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid dynamic-load mode");
lf[187]=C_h_intern(&lf[187],4,"read");
lf[188]=C_h_intern(&lf[188],7,"newline");
lf[189]=C_h_intern(&lf[189],12,"flush-output");
lf[190]=C_h_intern(&lf[190],15,"open-input-file");
lf[191]=C_h_intern(&lf[191],16,"close-input-port");
lf[192]=C_h_intern(&lf[192],13,"string-append");
lf[193]=C_h_intern(&lf[193],8,"\003sysload");
lf[194]=C_h_intern(&lf[194],31,"\003sysread-error-with-line-number");
lf[195]=C_h_intern(&lf[195],17,"\003sysdisplay-times");
lf[196]=C_h_intern(&lf[196],14,"\003sysstop-timer");
lf[197]=C_h_intern(&lf[197],15,"\003sysstart-timer");
lf[198]=C_h_intern(&lf[198],4,"load");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\036unable to load compiled module");
lf[200]=C_h_intern(&lf[200],9,"peek-char");
lf[201]=C_h_intern(&lf[201],13,"\003syssubstring");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[203]=C_h_intern(&lf[203],30,"call-with-current-continuation");
lf[204]=C_h_intern(&lf[204],9,"\003sysdload");
lf[205]=C_h_intern(&lf[205],17,"\003sysmake-c-string");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[207]=C_h_intern(&lf[207],11,"\000file-error");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\012; loading ");
lf[211]=C_h_intern(&lf[211],13,"\003sysfile-info");
lf[212]=C_h_intern(&lf[212],26,"\003sysload-dynamic-extension");
lf[213]=C_h_intern(&lf[213],11,"\000type-error");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a port or string");
lf[215]=C_h_intern(&lf[215],5,"port\077");
lf[216]=C_h_intern(&lf[216],20,"\003sysexpand-home-path");
lf[217]=C_h_intern(&lf[217],13,"load-relative");
lf[218]=C_h_intern(&lf[218],12,"load-noisily");
lf[219]=C_h_intern(&lf[219],15,"\003sysget-keyword");
lf[220]=C_h_intern(&lf[220],8,"\000printer");
lf[221]=C_h_intern(&lf[221],5,"\000time");
lf[222]=C_h_intern(&lf[222],10,"\000evaluator");
lf[223]=C_h_intern(&lf[223],26,"\003sysload-library-extension");
lf[224]=C_h_intern(&lf[224],6,"cygwin");
lf[225]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014cygchicken-0\376\377\016");
lf[226]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012libchicken\376\377\016");
lf[227]=C_h_intern(&lf[227],34,"\003sysdefault-dynamic-load-libraries");
lf[228]=C_h_intern(&lf[228],22,"dynamic-load-libraries");
lf[229]=C_h_intern(&lf[229],16,"\003sysload-library");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\005 ...\012");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\022; loading library ");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[234]=C_h_intern(&lf[234],24,"\003sysstring->c-identifier");
lf[235]=C_h_intern(&lf[235],16,"\003sys->feature-id");
lf[236]=C_h_intern(&lf[236],12,"load-library");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\026unable to load library");
lf[238]=C_h_intern(&lf[238],31,"\003syscanonicalize-extension-path");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension path");
lf[240]=C_h_intern(&lf[240],18,"\003syssymbol->string");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[244]=C_h_intern(&lf[244],19,"\003sysrepository-path");
lf[245]=C_h_intern(&lf[245],15,"repository-path");
lf[246]=C_h_intern(&lf[246],12,"file-exists\077");
lf[247]=C_h_intern(&lf[247],18,"\003sysfind-extension");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[249]=C_h_intern(&lf[249],21,"\003sysinclude-pathnames");
lf[250]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001.\376\377\016");
lf[251]=C_h_intern(&lf[251],21,"\003sysloaded-extensions");
lf[252]=C_h_intern(&lf[252],14,"string->symbol");
lf[253]=C_h_intern(&lf[253],18,"\003sysload-extension");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot load extension");
lf[255]=C_h_intern(&lf[255],11,"\003sysprovide");
lf[256]=C_h_intern(&lf[256],7,"provide");
lf[257]=C_h_intern(&lf[257],13,"\003sysprovided\077");
lf[258]=C_h_intern(&lf[258],9,"provided\077");
lf[259]=C_h_intern(&lf[259],7,"require");
lf[260]=C_h_intern(&lf[260],25,"\003sysextension-information");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[264]=C_h_intern(&lf[264],21,"extension-information");
lf[265]=C_h_intern(&lf[265],18,"require-at-runtime");
lf[266]=C_h_intern(&lf[266],12,"vector->list");
lf[267]=C_h_intern(&lf[267],14,"dynamic/syntax");
lf[268]=C_h_intern(&lf[268],7,"dynamic");
lf[269]=C_h_intern(&lf[269],11,"lset-adjoin");
lf[270]=C_h_intern(&lf[270],3,"eq\077");
lf[271]=C_h_intern(&lf[271],26,"\010compilerfile-requirements");
lf[272]=C_h_intern(&lf[272],6,"import");
lf[273]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\006srfi-2\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\007srfi-10\376\003\000\000\002\376\001\000\000\007srfi"
"-12\376\003\000\000\002\376\001\000\000\007srfi-23\376\003\000\000\002\376\001\000\000\007srfi-28\376\003\000\000\002\376\001\000\000\007srfi-30\376\003\000\000\002\376\001\000\000\007srfi-31\376\003\000\000\002\376\001\000\000"
"\007srfi-39\376\003\000\000\002\376\001\000\000\007srfi-69\376\003\000\000\002\376\001\000\000\007srfi-98\376\377\016");
lf[274]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[275]=C_h_intern(&lf[275],4,"uses");
lf[276]=C_h_intern(&lf[276],17,"require-extension");
lf[277]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006srfi-6\376\003\000\000\002\376\001\000\000\006srfi-8\376\003\000\000\002\376\001\000\000\006srfi-9\376\003\000\000\002\376\001\000\000\007srfi-11\376\003\000\000\002\376\001\000\000\007srfi-"
"15\376\003\000\000\002\376\001\000\000\007srfi-16\376\003\000\000\002\376\001\000\000\007srfi-17\376\003\000\000\002\376\001\000\000\007srfi-26\376\003\000\000\002\376\001\000\000\007srfi-55\376\377\016");
lf[278]=C_h_intern(&lf[278],12,"\003sysfeature\077");
lf[279]=C_h_intern(&lf[279],24,"\003sysextension-specifiers");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\035undefined extension specifier");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid extension specifier");
lf[282]=C_h_intern(&lf[282],24,"set-extension-specifier!");
lf[283]=C_h_intern(&lf[283],11,"string-copy");
lf[286]=C_h_intern(&lf[286],11,"environment");
lf[288]=C_h_intern(&lf[288],16,"\003sysenvironment\077");
lf[289]=C_h_intern(&lf[289],18,"\003syscopy-env-table");
lf[290]=C_h_intern(&lf[290],23,"\003sysenvironment-symbols");
lf[291]=C_h_intern(&lf[291],18,"\003syswalk-namespace");
lf[292]=C_h_intern(&lf[292],23,"interaction-environment");
lf[293]=C_h_intern(&lf[293],25,"scheme-report-environment");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[295]=C_h_intern(&lf[295],11,"make-vector");
lf[296]=C_h_intern(&lf[296],16,"null-environment");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\026no support for version");
lf[298]=C_h_intern(&lf[298],28,"\003sysresolve-include-filename");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\013 major GCs\012");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\013 minor GCs\012");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\013 mutations\012");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\027 seconds in (major) GC\012");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\021 seconds elapsed\012");
lf[306]=C_h_intern(&lf[306],18,"\003sysrepl-eval-hook");
lf[307]=C_h_intern(&lf[307],27,"\003sysrepl-print-length-limit");
lf[308]=C_h_intern(&lf[308],18,"\003sysrepl-read-hook");
lf[309]=C_h_intern(&lf[309],19,"\003sysrepl-print-hook");
lf[310]=C_h_intern(&lf[310],16,"\003syswrite-char-0");
lf[311]=C_h_intern(&lf[311],9,"\003sysprint");
lf[312]=C_h_intern(&lf[312],27,"\003syswith-print-length-limit");
lf[313]=C_h_intern(&lf[313],11,"repl-prompt");
lf[314]=C_h_intern(&lf[314],20,"\003sysread-prompt-hook");
lf[315]=C_h_intern(&lf[315],16,"\003sysflush-output");
lf[316]=C_h_intern(&lf[316],19,"\003sysstandard-output");
lf[317]=C_h_intern(&lf[317],22,"\003sysclear-trace-buffer");
lf[318]=C_h_intern(&lf[318],16,"print-call-chain");
lf[319]=C_h_intern(&lf[319],5,"reset");
lf[320]=C_h_intern(&lf[320],4,"repl");
lf[321]=C_h_intern(&lf[321],18,"\003sysstandard-error");
lf[322]=C_h_intern(&lf[322],18,"\003sysstandard-input");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\006\012Error");
lf[326]=C_h_intern(&lf[326],17,"\003syserror-handler");
lf[327]=C_h_intern(&lf[327],20,"\003syswarnings-enabled");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\005 (in ");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000FWarning: the following toplevel variables are referenced but unbound:\012");
lf[331]=C_h_intern(&lf[331],15,"\003sysread-char-0");
lf[332]=C_h_intern(&lf[332],15,"\003syspeek-char-0");
lf[333]=C_h_intern(&lf[333],21,"\003sysenable-qualifiers");
lf[334]=C_h_intern(&lf[334],17,"\003sysreset-handler");
lf[335]=C_h_intern(&lf[335],28,"\003syssharp-comma-reader-ctors");
lf[336]=C_h_intern(&lf[336],18,"define-reader-ctor");
lf[337]=C_h_intern(&lf[337],18,"\003sysuser-read-hook");
lf[338]=C_h_intern(&lf[338],9,"read-char");
lf[339]=C_h_intern(&lf[339],14,"\003sysread-error");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000!invalid sharp-comma external form");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000!undefined sharp-comma constructor");
lf[344]=C_h_intern(&lf[344],19,"print-error-message");
lf[345]=C_h_intern(&lf[345],22,"with-exception-handler");
lf[347]=C_h_intern(&lf[347],6,"\003sysgc");
lf[349]=C_h_intern(&lf[349],13,"thread-yield!");
lf[352]=C_h_intern(&lf[352],17,"open-input-string");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000(Error: not enough room for result string");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\010No error");
lf[363]=C_h_intern(&lf[363],15,"\003sysmake-string");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\004#;> ");
lf[365]=C_h_intern(&lf[365],14,"make-parameter");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007\000srfi-8\376\003\000\000\002\376\001\000\000\007\000srfi-6\376\003\000\000\002\376\001\000\000\007\000srfi-2\376\003\000\000\002\376\001\000\000\007\000srfi-0\376\003\000\000\002\376\001\000\000\010\000s"
"rfi-10\376\003\000\000\002\376\001\000\000\007\000srfi-9\376\003\000\000\002\376\001\000\000\010\000srfi-55\376\003\000\000\002\376\001\000\000\010\000srfi-61\376\377\016");
lf[367]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\014dynamic-wind\376\003\000\000\002\376\001\000\000\006values\376\003\000\000\002\376\001\000\000\020call-with-values\376\003\000\000\002\376\001\000\000\004eval\376\003"
"\000\000\002\376\001\000\000\031scheme-report-environment\376\003\000\000\002\376\001\000\000\020null-environment\376\003\000\000\002\376\001\000\000\027interaction"
"-environment\376\377\016");
lf[368]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003not\376\003\000\000\002\376\001\000\000\010boolean\077\376\003\000\000\002\376\001\000\000\003eq\077\376\003\000\000\002\376\001\000\000\004eqv\077\376\003\000\000\002\376\001\000\000\006equal\077\376\003\000\000\002\376"
"\001\000\000\005pair\077\376\003\000\000\002\376\001\000\000\004cons\376\003\000\000\002\376\001\000\000\003car\376\003\000\000\002\376\001\000\000\003cdr\376\003\000\000\002\376\001\000\000\004caar\376\003\000\000\002\376\001\000\000\004cadr\376\003\000"
"\000\002\376\001\000\000\004cdar\376\003\000\000\002\376\001\000\000\004cddr\376\003\000\000\002\376\001\000\000\005caaar\376\003\000\000\002\376\001\000\000\005caadr\376\003\000\000\002\376\001\000\000\005cadar\376\003\000\000\002\376\001\000\000\005"
"caddr\376\003\000\000\002\376\001\000\000\005cdaar\376\003\000\000\002\376\001\000\000\005cdadr\376\003\000\000\002\376\001\000\000\005cddar\376\003\000\000\002\376\001\000\000\005cdddr\376\003\000\000\002\376\001\000\000\006caaaa"
"r\376\003\000\000\002\376\001\000\000\006caaadr\376\003\000\000\002\376\001\000\000\006caadar\376\003\000\000\002\376\001\000\000\006caaddr\376\003\000\000\002\376\001\000\000\006cadaar\376\003\000\000\002\376\001\000\000\006cadad"
"r\376\003\000\000\002\376\001\000\000\006cadddr\376\003\000\000\002\376\001\000\000\006cdaaar\376\003\000\000\002\376\001\000\000\006cdaadr\376\003\000\000\002\376\001\000\000\006cdadar\376\003\000\000\002\376\001\000\000\006cdadd"
"r\376\003\000\000\002\376\001\000\000\006cddaar\376\003\000\000\002\376\001\000\000\006cddadr\376\003\000\000\002\376\001\000\000\006cdddar\376\003\000\000\002\376\001\000\000\006cddddr\376\003\000\000\002\376\001\000\000\010set-c"
"ar!\376\003\000\000\002\376\001\000\000\010set-cdr!\376\003\000\000\002\376\001\000\000\005null\077\376\003\000\000\002\376\001\000\000\005list\077\376\003\000\000\002\376\001\000\000\004list\376\003\000\000\002\376\001\000\000\006lengt"
"h\376\003\000\000\002\376\001\000\000\011list-tail\376\003\000\000\002\376\001\000\000\010list-ref\376\003\000\000\002\376\001\000\000\006append\376\003\000\000\002\376\001\000\000\007reverse\376\003\000\000\002\376\001\000\000"
"\004memq\376\003\000\000\002\376\001\000\000\004memv\376\003\000\000\002\376\001\000\000\006member\376\003\000\000\002\376\001\000\000\004assq\376\003\000\000\002\376\001\000\000\004assv\376\003\000\000\002\376\001\000\000\005assoc\376\003"
"\000\000\002\376\001\000\000\007symbol\077\376\003\000\000\002\376\001\000\000\016symbol->string\376\003\000\000\002\376\001\000\000\016string->symbol\376\003\000\000\002\376\001\000\000\007number\077"
"\376\003\000\000\002\376\001\000\000\010integer\077\376\003\000\000\002\376\001\000\000\006exact\077\376\003\000\000\002\376\001\000\000\005real\077\376\003\000\000\002\376\001\000\000\010complex\077\376\003\000\000\002\376\001\000\000\010ine"
"xact\077\376\003\000\000\002\376\001\000\000\011rational\077\376\003\000\000\002\376\001\000\000\005zero\077\376\003\000\000\002\376\001\000\000\004odd\077\376\003\000\000\002\376\001\000\000\005even\077\376\003\000\000\002\376\001\000\000\011po"
"sitive\077\376\003\000\000\002\376\001\000\000\011negative\077\376\003\000\000\002\376\001\000\000\003max\376\003\000\000\002\376\001\000\000\003min\376\003\000\000\002\376\001\000\000\001+\376\003\000\000\002\376\001\000\000\001-\376\003\000\000\002\376"
"\001\000\000\001*\376\003\000\000\002\376\001\000\000\001/\376\003\000\000\002\376\001\000\000\001=\376\003\000\000\002\376\001\000\000\001>\376\003\000\000\002\376\001\000\000\001<\376\003\000\000\002\376\001\000\000\002>=\376\003\000\000\002\376\001\000\000\002<=\376\003\000\000\002\376\001"
"\000\000\010quotient\376\003\000\000\002\376\001\000\000\011remainder\376\003\000\000\002\376\001\000\000\006modulo\376\003\000\000\002\376\001\000\000\003gcd\376\003\000\000\002\376\001\000\000\003lcm\376\003\000\000\002\376\001\000"
"\000\003abs\376\003\000\000\002\376\001\000\000\005floor\376\003\000\000\002\376\001\000\000\007ceiling\376\003\000\000\002\376\001\000\000\010truncate\376\003\000\000\002\376\001\000\000\005round\376\003\000\000\002\376\001\000\000\016"
"exact->inexact\376\003\000\000\002\376\001\000\000\016inexact->exact\376\003\000\000\002\376\001\000\000\003exp\376\003\000\000\002\376\001\000\000\003log\376\003\000\000\002\376\001\000\000\004expt\376\003"
"\000\000\002\376\001\000\000\004sqrt\376\003\000\000\002\376\001\000\000\003sin\376\003\000\000\002\376\001\000\000\003cos\376\003\000\000\002\376\001\000\000\003tan\376\003\000\000\002\376\001\000\000\004asin\376\003\000\000\002\376\001\000\000\004acos\376"
"\003\000\000\002\376\001\000\000\004atan\376\003\000\000\002\376\001\000\000\016number->string\376\003\000\000\002\376\001\000\000\016string->number\376\003\000\000\002\376\001\000\000\005char\077\376\003\000\000"
"\002\376\001\000\000\006char=\077\376\003\000\000\002\376\001\000\000\006char>\077\376\003\000\000\002\376\001\000\000\006char<\077\376\003\000\000\002\376\001\000\000\007char>=\077\376\003\000\000\002\376\001\000\000\007char<=\077\376\003"
"\000\000\002\376\001\000\000\011char-ci=\077\376\003\000\000\002\376\001\000\000\011char-ci<\077\376\003\000\000\002\376\001\000\000\011char-ci>\077\376\003\000\000\002\376\001\000\000\012char-ci>=\077\376\003\000\000\002"
"\376\001\000\000\012char-ci<=\077\376\003\000\000\002\376\001\000\000\020char-alphabetic\077\376\003\000\000\002\376\001\000\000\020char-whitespace\077\376\003\000\000\002\376\001\000\000\015cha"
"r-numeric\077\376\003\000\000\002\376\001\000\000\020char-upper-case\077\376\003\000\000\002\376\001\000\000\020char-lower-case\077\376\003\000\000\002\376\001\000\000\013char-upc"
"ase\376\003\000\000\002\376\001\000\000\015char-downcase\376\003\000\000\002\376\001\000\000\015char->integer\376\003\000\000\002\376\001\000\000\015integer->char\376\003\000\000\002\376\001\000"
"\000\007string\077\376\003\000\000\002\376\001\000\000\010string=\077\376\003\000\000\002\376\001\000\000\010string>\077\376\003\000\000\002\376\001\000\000\010string<\077\376\003\000\000\002\376\001\000\000\011string>"
"=\077\376\003\000\000\002\376\001\000\000\011string<=\077\376\003\000\000\002\376\001\000\000\013string-ci=\077\376\003\000\000\002\376\001\000\000\013string-ci<\077\376\003\000\000\002\376\001\000\000\013string-"
"ci>\077\376\003\000\000\002\376\001\000\000\014string-ci>=\077\376\003\000\000\002\376\001\000\000\014string-ci<=\077\376\003\000\000\002\376\001\000\000\013make-string\376\003\000\000\002\376\001\000\000\015s"
"tring-length\376\003\000\000\002\376\001\000\000\012string-ref\376\003\000\000\002\376\001\000\000\013string-set!\376\003\000\000\002\376\001\000\000\015string-append\376\003\000\000"
"\002\376\001\000\000\013string-copy\376\003\000\000\002\376\001\000\000\014string->list\376\003\000\000\002\376\001\000\000\014list->string\376\003\000\000\002\376\001\000\000\011substring"
"\376\003\000\000\002\376\001\000\000\014string-fill!\376\003\000\000\002\376\001\000\000\007vector\077\376\003\000\000\002\376\001\000\000\013make-vector\376\003\000\000\002\376\001\000\000\012vector-ref"
"\376\003\000\000\002\376\001\000\000\013vector-set!\376\003\000\000\002\376\001\000\000\006string\376\003\000\000\002\376\001\000\000\006vector\376\003\000\000\002\376\001\000\000\015vector-length\376\003\000\000"
"\002\376\001\000\000\014vector->list\376\003\000\000\002\376\001\000\000\014list->vector\376\003\000\000\002\376\001\000\000\014vector-fill!\376\003\000\000\002\376\001\000\000\012procedur"
"e\077\376\003\000\000\002\376\001\000\000\003map\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\005apply\376\003\000\000\002\376\001\000\000\005force\376\003\000\000\002\376\001\000\000\036call-wi"
"th-current-continuation\376\003\000\000\002\376\001\000\000\013input-port\077\376\003\000\000\002\376\001\000\000\014output-port\077\376\003\000\000\002\376\001\000\000\022curr"
"ent-input-port\376\003\000\000\002\376\001\000\000\023current-output-port\376\003\000\000\002\376\001\000\000\024call-with-input-file\376\003\000\000\002\376\001"
"\000\000\025call-with-output-file\376\003\000\000\002\376\001\000\000\017open-input-file\376\003\000\000\002\376\001\000\000\020open-output-file\376\003\000\000\002"
"\376\001\000\000\020close-input-port\376\003\000\000\002\376\001\000\000\021close-output-port\376\003\000\000\002\376\001\000\000\004load\376\003\000\000\002\376\001\000\000\004read\376\003\000\000"
"\002\376\001\000\000\013eof-object\077\376\003\000\000\002\376\001\000\000\011read-char\376\003\000\000\002\376\001\000\000\011peek-char\376\003\000\000\002\376\001\000\000\005write\376\003\000\000\002\376\001\000\000\007"
"display\376\003\000\000\002\376\001\000\000\012write-char\376\003\000\000\002\376\001\000\000\007newline\376\003\000\000\002\376\001\000\000\024with-input-from-file\376\003\000\000\002\376"
"\001\000\000\023with-output-to-file\376\003\000\000\002\376\001\000\000\024\003syscall-with-values\376\003\000\000\002\376\001\000\000\012\003sysvalues\376\003\000\000\002\376\001"
"\000\000\020\003sysdynamic-wind\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\003\000\000\002\376\001\000\000\020\003syslist->vector\376\003\000\000\002\376\001\000\000\010\003syslis"
"t\376\003\000\000\002\376\001\000\000\012\003sysappend\376\003\000\000\002\376\001\000\000\010\003syscons\376\003\000\000\002\376\001\000\000\020\003sysmake-promise\376\377\016");
lf[369]=C_h_intern(&lf[369],18,"\003sysnumber->string");
lf[370]=C_h_intern(&lf[370],5,"error");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\031invalid extension version");
lf[372]=C_h_intern(&lf[372],7,"version");
lf[373]=C_h_intern(&lf[373],2,"id");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\0003installed extension does not match required version");
lf[375]=C_h_intern(&lf[375],9,"string>=\077");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\035invalid version specification");
lf[377]=C_h_intern(&lf[377],12,"list->vector");
lf[378]=C_h_intern(&lf[378],18,"\003sysstring->symbol");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\005srfi-");
lf[380]=C_h_intern(&lf[380],4,"srfi");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[382]=C_h_intern(&lf[382],24,"get-environment-variable");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\022CHICKEN_REPOSITORY");
lf[384]=C_h_intern(&lf[384],14,"build-platform");
lf[385]=C_h_intern(&lf[385],7,"windows");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\004.dll");
lf[387]=C_h_intern(&lf[387],6,"macosx");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003.sl");
lf[390]=C_h_intern(&lf[390],4,"hpux");
lf[391]=C_h_intern(&lf[391],4,"hppa");
lf[392]=C_h_intern(&lf[392],12,"machine-type");
lf[393]=C_h_intern(&lf[393],16,"software-version");
lf[394]=C_h_intern(&lf[394],13,"software-type");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\012C_toplevel");
lf[396]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
C_register_lf2(lf,400,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3337,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_expand_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3335 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3337,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3339,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! core-library-modules ...) */,lf[4]);
t4=C_set_block_item(lf[5] /* explicit-library-modules */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate(&lf[6] /* (set! constant103 ...) */,lf[7]);
t6=C_mutate(&lf[8] /* (set! constant115 ...) */,lf[9]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 129  get-environment-variable */
t8=*((C_word*)lf[382]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[399]);}

/* k3368 in k3335 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_block_size(t1);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(C_word)C_subchar(t1,t4);
t6=(C_word)C_u_i_memq(t5,lf[396]);
t7=(C_truep(t6)?lf[397]:lf[398]);
/* eval.scm: 130  ##sys#string-append */
t8=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t2,t1,t7);}
else{
t3=t2;
f_3373(2,t3,C_SCHEME_FALSE);}}

/* k3371 in k3368 in k3335 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3373,2,t0,t1);}
t2=C_mutate((C_word*)lf[10]+1 /* (set! chicken-prefix ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3374,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[12]+1 /* (set! chicken-home ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3401,tmp=(C_word)a,a+=2,tmp));
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[15]+1 /* (set! hash-symbol ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3413,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[16]+1 /* (set! hash-table-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3428,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3483,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[18]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3543,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[19]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3563,tmp=(C_word)a,a+=2,tmp));
t13=(C_word)C_slot(lf[21],C_fix(0));
t14=C_mutate((C_word*)lf[22]+1 /* (set! hash-table-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3609,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[23] /* eval-environment */,0,C_SCHEME_FALSE);
t16=C_set_block_item(lf[24] /* environment-is-mutable */,0,C_SCHEME_FALSE);
t17=C_mutate((C_word*)lf[25]+1 /* (set! eval-decorator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3669,tmp=(C_word)a,a+=2,tmp));
t18=C_set_block_item(lf[31] /* unbound-in-eval */,0,C_SCHEME_FALSE);
t19=C_set_block_item(lf[32] /* eval-debug-level */,0,C_fix(1));
t20=*((C_word*)lf[28]+1);
t21=*((C_word*)lf[33]+1);
t22=*((C_word*)lf[29]+1);
t23=*((C_word*)lf[27]+1);
t24=*((C_word*)lf[34]+1);
t25=(C_word)C_slot(lf[21],C_fix(0));
t26=*((C_word*)lf[35]+1);
t27=C_mutate((C_word*)lf[36]+1 /* (set! compile-to-closure ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3713,a[2]=t21,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6608,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10231,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 816  make-parameter */
t30=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t30+1)))(3,t30,t28,t29);}

/* a10230 in k3371 in k3368 in k3335 */
static void C_ccall f_10231(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10231r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10231r(t0,t1,t2,t3);}}

static void C_ccall f_10231r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[24]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10235,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[286]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_10235(t15,t14);}
else{
t10=t8;
f_10235(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_10235(t9,C_SCHEME_UNDEFINED);}}

/* k10233 in a10230 in k3371 in k3368 in k3335 */
static void C_fcall f_10235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10235,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10241,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10243,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10260,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t14=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a10259 in k10233 in a10230 in k3371 in k3368 in k3335 */
static void C_ccall f_10260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10260,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[24]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[23]+1));
t4=C_mutate((C_word*)lf[24]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[23]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a10249 in k10233 in a10230 in k3371 in k3368 in k3335 */
static void C_ccall f_10250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10258,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 828  ##sys#current-environment */
t3=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10256 in a10249 in k10233 in a10230 in k3371 in k3368 in k3335 */
static void C_ccall f_10258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 828  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* a10242 in k10233 in a10230 in k3371 in k3368 in k3335 */
static void C_ccall f_10243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10243,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[24]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[23]+1));
t4=C_mutate((C_word*)lf[24]+1 /* (set! environment-is-mutable ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[23]+1 /* (set! eval-environment ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k10239 in k10233 in a10230 in k3371 in k3368 in k3335 */
static void C_ccall f_10241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6608,2,t0,t1);}
t2=C_mutate((C_word*)lf[168]+1 /* (set! eval-handler ...) */,t1);
t3=C_mutate((C_word*)lf[169]+1 /* (set! eval-handler ...) */,*((C_word*)lf[168]+1));
t4=C_mutate((C_word*)lf[170]+1 /* (set! eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6611,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[33]+1);
t6=C_mutate((C_word*)lf[96]+1 /* (set! decompose-lambda-list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6621,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 860  make-parameter */
t9=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=C_mutate((C_word*)lf[173]+1 /* (set! load-verbose ...) */,t1);
t3=C_mutate((C_word*)lf[174]+1 /* (set! abort-load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6705,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[175] /* current-source-filename */,0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[176]+1 /* (set! current-load-path ...) */,lf[177]);
t6=C_set_block_item(lf[178] /* dload-disabled */,0,C_SCHEME_FALSE);
t7=C_mutate((C_word*)lf[179]+1 /* (set! set-dynamic-load-mode! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6711,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[187]+1);
t9=*((C_word*)lf[28]+1);
t10=*((C_word*)lf[35]+1);
t11=*((C_word*)lf[188]+1);
t12=*((C_word*)lf[189]+1);
t13=*((C_word*)lf[170]+1);
t14=*((C_word*)lf[190]+1);
t15=*((C_word*)lf[191]+1);
t16=*((C_word*)lf[192]+1);
t17=*((C_word*)lf[173]+1);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6784,a[2]=((C_word*)t0)[2],a[3]=t17,a[4]=t10,a[5]=t12,a[6]=t14,a[7]=t15,a[8]=t9,a[9]=t11,a[10]=t8,a[11]=t13,tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 894  ##sys#make-c-string */
t19=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[395]);}

/* k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6786,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[193]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6832,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp));
t4=C_mutate((C_word*)lf[198]+1 /* (set! load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7228,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[217]+1 /* (set! load-relative ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7250,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[218]+1 /* (set! load-noisily ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7286,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10225,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 987  software-type */
t9=*((C_word*)lf[394]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}

/* k10223 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10225,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[385]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7312(t3,lf[386]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 988  software-version */
t4=*((C_word*)lf[393]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10219 in k10223 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10221,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[387]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_7312(t3,lf[388]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10203,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10217,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 989  software-version */
t5=*((C_word*)lf[393]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10215 in k10219 in k10223 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10217,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[390]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 990  machine-type */
t4=*((C_word*)lf[392]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_10203(t3,C_SCHEME_FALSE);}}

/* k10211 in k10215 in k10219 in k10223 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10203(t2,(C_word)C_eqp(t1,lf[391]));}

/* k10201 in k10219 in k10223 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_10203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7312(t2,(C_truep(t1)?lf[389]:lf[6]));}

/* k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7312,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[223]+1 /* (set! load-library-extension ...) */,t1);
t3=C_mutate((C_word*)lf[212]+1 /* (set! load-dynamic-extension ...) */,lf[6]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 996  build-platform */
t5=*((C_word*)lf[384]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7317,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[224]);
t3=(C_truep(t2)?lf[225]:lf[226]);
t4=C_mutate((C_word*)lf[227]+1 /* (set! default-dynamic-load-libraries ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10173,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10181,tmp=(C_word)a,a+=2,tmp);
/* map */
t8=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,*((C_word*)lf[227]+1));}

/* a10180 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10181,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[223]+1));}

/* k10171 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10175,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1001 make-parameter */
t3=*((C_word*)lf[365]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a10174 in k10171 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10175(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10175,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7324,2,t0,t1);}
t2=C_mutate((C_word*)lf[228]+1 /* (set! dynamic-load-libraries ...) */,t1);
t3=*((C_word*)lf[173]+1);
t4=*((C_word*)lf[192]+1);
t5=*((C_word*)lf[228]+1);
t6=*((C_word*)lf[35]+1);
t7=C_mutate((C_word*)lf[229]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7326,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[236]+1 /* (set! load-library ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7432,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[33]+1);
t10=*((C_word*)lf[192]+1);
t11=C_mutate((C_word*)lf[238]+1 /* (set! canonicalize-extension-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7517,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7677,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10142,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1089 get-environment-variable */
t14=*((C_word*)lf[382]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,lf[383]);}

/* k10140 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10145,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_10145(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10158,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10162,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_fudge(C_fix(42));
t7=(C_truep(t6)?t6:C_fix(4));
/* eval.scm: 1093 ##sys#number->string */
t8=*((C_word*)lf[369]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t5,t7);}}

/* k10160 in k10140 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1091 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[381],t1);}

/* k10156 in k10140 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1090 ##sys#chicken-prefix */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10146 in k10140 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10148,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10145(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_EGG_HOME),C_fix(0));}}

/* k10143 in k10140 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1088 make-parameter */
t2=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7677,2,t0,t1);}
t2=C_mutate((C_word*)lf[244]+1 /* (set! repository-path ...) */,t1);
t3=C_mutate((C_word*)lf[245]+1 /* (set! repository-path ...) */,*((C_word*)lf[244]+1));
t4=*((C_word*)lf[246]+1);
t5=*((C_word*)lf[192]+1);
t6=C_mutate((C_word*)lf[247]+1 /* (set! find-extension ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7680,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[251] /* loaded-extensions */,0,C_SCHEME_END_OF_LIST);
t8=*((C_word*)lf[252]+1);
t9=C_mutate((C_word*)lf[253]+1 /* (set! load-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7771,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[255]+1 /* (set! provide ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7839,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[256]+1 /* (set! provide ...) */,*((C_word*)lf[255]+1));
t12=C_mutate((C_word*)lf[257]+1 /* (set! provided? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7859,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[258]+1 /* (set! provided? ...) */,*((C_word*)lf[257]+1));
t14=C_mutate((C_word*)lf[128]+1 /* (set! require ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7873,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[259]+1 /* (set! require ...) */,*((C_word*)lf[128]+1));
t16=*((C_word*)lf[34]+1);
t17=*((C_word*)lf[246]+1);
t18=*((C_word*)lf[192]+1);
t19=*((C_word*)lf[187]+1);
t20=C_mutate((C_word*)lf[260]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7886,a[2]=t18,a[3]=t17,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=C_mutate((C_word*)lf[264]+1 /* (set! extension-information ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7919,tmp=(C_word)a,a+=2,tmp));
t22=*((C_word*)lf[34]+1);
t23=*((C_word*)lf[187]+1);
t24=C_mutate((C_word*)lf[129]+1 /* (set! lookup-runtime-requirements ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7925,tmp=(C_word)a,a+=2,tmp));
t25=*((C_word*)lf[266]+1);
t26=C_mutate((C_word*)lf[132]+1 /* (set! do-the-right-thing ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7974,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(lf[279] /* extension-specifiers */,0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[282]+1 /* (set! set-extension-specifier! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8481,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8520,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[377]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10088,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1297 set-extension-specifier! */
t32=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[380],t31);}

/* a10087 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10088,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10096,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10102,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_10102(t9,t4,t5);}

/* loop in a10087 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_10102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10102,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[276]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10122,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10134,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10138,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1307 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k10136 in loop in a10087 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1307 ##sys#string-append */
t2=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[379],t1);}

/* k10132 in loop in a10087 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1307 ##sys#string->symbol */
t2=*((C_word*)lf[378]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10120 in loop in a10087 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10126,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1308 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10102(t4,t2,t3);}

/* k10124 in k10120 in loop in a10087 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10126,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10094 in a10087 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1301 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8523,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9991,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1313 set-extension-specifier! */
t4=*((C_word*)lf[282]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[372],t3);}

/* a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9991,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9994,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10028,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_listp(t2))){
t6=(C_word)C_i_length(t2);
t7=t5;
f_10028(t7,(C_word)C_eqp(C_fix(3),t6));}
else{
t6=t5;
f_10028(t6,C_SCHEME_FALSE);}}

/* k10026 in a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_10028(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10028,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* eval.scm: 1322 extension-information */
t4=*((C_word*)lf[264]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
/* eval.scm: 1327 ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[376],((C_word*)t0)[3]);}}

/* k10029 in k10026 in a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10031,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[372],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10037,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10040,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1324 ->string */
f_9994(t5,t6);}
else{
t5=t4;
f_10040(2,t5,C_SCHEME_FALSE);}}

/* k10052 in k10029 in k10026 in a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10058,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1324 ->string */
f_9994(t2,t3);}

/* k10056 in k10052 in k10029 in k10026 in a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1324 string>=? */
t2=*((C_word*)lf[375]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10038 in k10029 in k10026 in a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10037(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
/* eval.scm: 1325 error */
t3=*((C_word*)lf[370]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[374],*((C_word*)lf[373]+1),((C_word*)t0)[2],t2);}}

/* k10035 in k10029 in k10026 in a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_10037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[373]+1));}

/* ->string in a9990 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9994(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9994,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
if(C_truep((C_word)C_i_numberp(t2))){
/* eval.scm: 1319 ##sys#number->string */
t3=*((C_word*)lf[369]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
/* eval.scm: 1320 error */
t3=*((C_word*)lf[370]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[371],t2);}}}}

/* k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8523,2,t0,t1);}
t2=*((C_word*)lf[283]+1);
t3=C_mutate((C_word*)lf[234]+1 /* (set! string->c-identifier ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8525,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8581,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1346 make-vector */
t5=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8581,2,t0,t1);}
t2=C_mutate(&lf[284] /* (set! r4rs-environment ...) */,t1);
t3=lf[285] /* r5rs-environment */ =C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[286],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[287] /* (set! interaction-environment ...) */,t4);
t6=C_mutate((C_word*)lf[288]+1 /* (set! environment? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8588,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[289]+1 /* (set! copy-env-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8604,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[290]+1 /* (set! environment-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8712,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[292]+1 /* (set! interaction-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8831,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[293]+1 /* (set! scheme-report-environment ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8834,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[295]+1);
t12=C_mutate((C_word*)lf[296]+1 /* (set! null-environment ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8878,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8916,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8932,a[2]=t13,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9989,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1430 initb */
f_8916(t15,lf[284]);}

/* k9987 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[368]);}

/* k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1451 ##sys#copy-env-table */
t3=*((C_word*)lf[289]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[284],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8936,2,t0,t1);}
t2=C_mutate(&lf[285] /* (set! r5rs-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8939,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9985,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1453 initb */
f_8916(t4,lf[285]);}

/* k9983 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[367]);}

/* k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8943,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1460 chicken-home */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8943,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t3=C_mutate((C_word*)lf[249]+1 /* (set! include-pathnames ...) */,t2);
t4=*((C_word*)lf[192]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8949,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[298]+1 /* (set! resolve-include-filename ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8968,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[35]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9110,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9134,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[195]+1 /* (set! display-times ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9155,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1529 append */
t12=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,lf[366],*((C_word*)lf[143]+1));}

/* k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9210,2,t0,t1);}
t2=C_mutate((C_word*)lf[143]+1 /* (set! features ...) */,t1);
t3=C_set_block_item(lf[306] /* repl-eval-hook */,0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[307] /* repl-print-length-limit */,0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[308] /* repl-read-hook */,0,C_SCHEME_FALSE);
t6=C_mutate((C_word*)lf[309]+1 /* (set! repl-print-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9215,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9977,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1543 make-parameter */
t9=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9976 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9977,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[364]);}

/* k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9232,2,t0,t1);}
t2=C_mutate((C_word*)lf[313]+1 /* (set! repl-prompt ...) */,t1);
t3=*((C_word*)lf[313]+1);
t4=C_mutate((C_word*)lf[314]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9234,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[317]+1 /* (set! clear-trace-buffer ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9250,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[170]+1);
t7=*((C_word*)lf[187]+1);
t8=*((C_word*)lf[203]+1);
t9=*((C_word*)lf[318]+1);
t10=*((C_word*)lf[189]+1);
t11=*((C_word*)lf[173]+1);
t12=*((C_word*)lf[319]+1);
t13=C_mutate((C_word*)lf[320]+1 /* (set! repl ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9253,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t11,a[6]=t9,a[7]=t10,tmp=(C_word)a,a+=8,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9595,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1660 make-vector */
t15=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9595,2,t0,t1);}
t2=C_mutate((C_word*)lf[335]+1 /* (set! sharp-comma-reader-ctors ...) */,t1);
t3=C_mutate((C_word*)lf[336]+1 /* (set! define-reader-ctor ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9597,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[337]+1);
t5=*((C_word*)lf[338]+1);
t6=*((C_word*)lf[187]+1);
t7=C_mutate((C_word*)lf[337]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9606,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=lf[342] /* last-error */ =C_SCHEME_FALSE;;
t9=C_mutate(&lf[343] /* (set! run-safe ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9681,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[346] /* (set! store-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9740,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[348] /* (set! CHICKEN_yield ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9749,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[350] /* (set! CHICKEN_eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9761,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[351] /* (set! CHICKEN_eval_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9777,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[353] /* (set! store-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9803,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[355] /* (set! CHICKEN_eval_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9816,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[356] /* (set! CHICKEN_eval_string_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9842,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[357] /* (set! CHICKEN_apply ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9879,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[358] /* (set! CHICKEN_apply_to_string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9895,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[359] /* (set! CHICKEN_read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9921,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[360] /* (set! CHICKEN_load ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9943,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[361] /* (set! CHICKEN_get_error_message ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9958,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[26]+1 /* (set! make-lambda-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9968,tmp=(C_word)a,a+=2,tmp));
t23=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9968,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9975,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1791 ##sys#make-string */
t5=*((C_word*)lf[363]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k9973 in ##sys#make-lambda-info in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9958,4,t0,t1,t2,t3);}
t4=lf[342];
t5=(C_truep(t4)?t4:lf[362]);
/* eval.scm: 1784 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_9803(t5,t3,t2));}

/* CHICKEN_load in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9943,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9947,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9945 in CHICKEN_load in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9952,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1781 run-safe */
f_9681(((C_word*)t0)[2],t2);}

/* a9951 in k9945 in CHICKEN_load in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9956,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1781 load */
t3=*((C_word*)lf[198]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9954 in a9951 in k9945 in CHICKEN_load in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9921,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9925,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9923 in CHICKEN_read in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9925,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9930,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1775 run-safe */
f_9681(((C_word*)t0)[2],t3);}

/* a9929 in k9923 in CHICKEN_read in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9934,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1777 open-input-string */
t3=*((C_word*)lf[352]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9932 in a9929 in k9923 in CHICKEN_read in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1778 read */
t3=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k9939 in k9932 in a9929 in k9923 in CHICKEN_read in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1778 store-result */
f_9740(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_9895,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9901,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1768 run-safe */
f_9681(t1,t6);}

/* a9900 in CHICKEN_apply_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1770 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9903 in a9900 in CHICKEN_apply_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9908,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9919,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9917 in k9903 in a9900 in CHICKEN_apply_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1771 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9906 in k9903 in a9900 in CHICKEN_apply_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1772 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9913 in k9906 in k9903 in a9900 in CHICKEN_apply_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1772 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9803(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9879(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9879,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9885,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1763 run-safe */
f_9681(t1,t5);}

/* a9884 in CHICKEN_apply in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9893,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9891 in a9884 in CHICKEN_apply in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1763 store-result */
f_9740(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9842(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9842,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9846,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9846,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9851,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1754 run-safe */
f_9681(((C_word*)t0)[2],t4);}

/* a9850 in k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1756 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9853 in a9850 in k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9858,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9869,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9873,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9877,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1757 open-input-string */
t6=*((C_word*)lf[352]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k9875 in k9853 in a9850 in k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1757 read */
t2=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9871 in k9853 in a9850 in k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1757 eval */
t2=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9867 in k9853 in a9850 in k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1757 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9856 in k9853 in a9850 in k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1758 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9863 in k9856 in k9853 in a9850 in k9844 in CHICKEN_eval_string_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1758 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9803(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9816,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9822,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1745 run-safe */
f_9681(t1,t5);}

/* a9821 in CHICKEN_eval_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9826,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1747 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9824 in a9821 in CHICKEN_eval_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9829,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9840,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1748 eval */
t4=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9838 in k9824 in a9821 in CHICKEN_eval_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1748 write */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9827 in k9824 in a9821 in CHICKEN_eval_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1749 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9834 in k9827 in k9824 in a9821 in CHICKEN_eval_to_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1749 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_9803(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static C_word C_fcall f_9803(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[342] /* (set! last-error ...) */,lf[354]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9777,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9781,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9779 in CHICKEN_eval_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9781,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9786,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1726 run-safe */
f_9681(((C_word*)t0)[2],t3);}

/* a9785 in k9779 in CHICKEN_eval_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9790,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1728 open-input-string */
t3=*((C_word*)lf[352]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9788 in a9785 in k9779 in CHICKEN_eval_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9801,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1729 read */
t4=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k9799 in k9788 in a9785 in k9779 in CHICKEN_eval_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1729 eval */
t2=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9795 in k9788 in a9785 in k9779 in CHICKEN_eval_string in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1729 store-result */
f_9740(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9761,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9767,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1721 run-safe */
f_9681(t1,t4);}

/* a9766 in CHICKEN_eval in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9775,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1723 eval */
t3=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9773 in a9766 in CHICKEN_eval in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1723 store-result */
f_9740(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9755,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1718 run-safe */
f_9681(t1,t2);}

/* a9754 in CHICKEN_yield in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1718 thread-yield! */
t3=*((C_word*)lf[349]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9757 in a9754 in CHICKEN_yield in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9740(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9740,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9744,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1712 ##sys#gc */
t5=*((C_word*)lf[347]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k9742 in store-result in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9681(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9681,NULL,2,t1,t2);}
t3=lf[342] /* last-error */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9689,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9691,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
t6=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9691,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9697,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9716,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[345]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a9715 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9722,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a9727 in a9715 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9728(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_9728r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9728r(t0,t1,t2);}}

static void C_ccall f_9728r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9734,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k29963001 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9733 in a9727 in a9715 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9734,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a9721 in a9715 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9722,2,t0,t1);}
/* eval.scm: 1705 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a9696 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9697,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9703,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k29963001 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9702 in a9696 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9707,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1701 open-output-string */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9705 in a9702 in a9696 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9710,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1702 print-error-message */
t3=*((C_word*)lf[344]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k9708 in k9705 in a9702 in a9696 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9714,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1703 get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9712 in k9708 in k9705 in a9702 in a9696 in a9690 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[342] /* (set! last-error ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k9687 in run-safe in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9606,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9616,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1672 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 1684 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k9614 in ##sys#user-read-hook in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9619,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1673 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9617 in k9614 in ##sys#user-read-hook in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9620,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9633,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_9633(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_9633(t6,(C_word)C_i_not(t5));}}

/* k9631 in k9617 in k9614 in ##sys#user-read-hook in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9633(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9633,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1676 err */
t2=((C_word*)t0)[5];
f_9620(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9651,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1680 ##sys#hash-table-ref */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[335]+1),t2);}
else{
/* eval.scm: 1679 err */
t3=((C_word*)t0)[5];
f_9620(t3,((C_word*)t0)[4]);}}}

/* k9649 in k9631 in k9617 in k9614 in ##sys#user-read-hook in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 1683 ##sys#read-error */
t2=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[341],((C_word*)t0)[2]);}}

/* err in k9617 in k9614 in ##sys#user-read-hook in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9620(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9620,NULL,2,t0,t1);}
/* eval.scm: 1674 ##sys#read-error */
t2=*((C_word*)lf[339]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[340],((C_word*)t0)[2]);}

/* define-reader-ctor in k9593 in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9597,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[336]);
/* eval.scm: 1664 ##sys#hash-table-set! */
t5=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[335]+1),t2,t3);}

/* repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9256,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[322]+1);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[316]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[321]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9297,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t8,a[11]=t6,a[12]=t4,tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1573 ##sys#error-handler */
t10=*((C_word*)lf[326]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9300,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1574 ##sys#reset-handler */
t3=*((C_word*)lf[334]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9300,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[31]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9302,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9308,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9317,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t6,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9382,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9580,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1588 ##sys#dynamic-wind */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t7,t8,t9);}

/* a9579 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9584,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1652 load-verbose */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k9582 in a9579 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9584,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! unbound-in-eval ...) */,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1654 ##sys#error-handler */
t4=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k9586 in k9582 in a9579 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1655 ##sys#reset-handler */
t2=*((C_word*)lf[334]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9382,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_9388(t5,t1);}

/* loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9388(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9388,NULL,2,t0,t1);}
t2=f_9302(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9563,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1611 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9562 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9563,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9569,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1613 ##sys#reset-handler */
t4=*((C_word*)lf[334]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a9568 in a9562 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9569,2,t0,t1);}
t2=C_set_block_item(lf[194] /* read-error-with-line-number */,0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[333] /* enable-qualifiers */,0,C_SCHEME_TRUE);
t4=f_9308(((C_word*)t0)[3]);
/* eval.scm: 1618 c */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,C_SCHEME_FALSE);}

/* k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1619 ##sys#read-prompt-hook */
t3=*((C_word*)lf[314]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9401,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[308]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9401,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9410,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9558,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1622 ##sys#peek-char-0 */
t4=*((C_word*)lf[332]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[322]+1));}}

/* k9556 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 1623 ##sys#read-char-0 */
t3=*((C_word*)lf[331]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[322]+1));}
else{
t3=((C_word*)t0)[2];
f_9410(2,t3,C_SCHEME_UNDEFINED);}}

/* k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1624 ##sys#clear-trace-buffer */
t3=*((C_word*)lf[317]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9413,2,t0,t1);}
t2=C_set_block_item(lf[31] /* unbound-in-eval */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9428,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9428(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_9428r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9428r(t0,t1,t2);}}

static void C_ccall f_9428r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9432,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(*((C_word*)lf[327]+1))?(C_word)C_i_pairp(*((C_word*)lf[31]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9446,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_9446(t8,t3,*((C_word*)lf[31]+1),C_SCHEME_END_OF_LIST);}
else{
t5=t3;
f_9432(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9446(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9446,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9450,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9462,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1631 ##sys#print */
t6=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[330],C_SCHEME_FALSE,*((C_word*)lf[321]+1));}
else{
t5=t4;
f_9450(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(C_word)C_u_i_caar(t2);
t6=(C_word)C_u_i_memq(t5,t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9512,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_9512(2,t8,t6);}
else{
t8=(C_word)C_u_i_caar(t2);
/* eval.scm: 1646 ##sys#symbol-has-toplevel-binding? */
t9=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}}

/* k9510 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9512,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1647 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9446(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* eval.scm: 1648 loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9446(t5,((C_word*)t0)[3],t2,t4);}}

/* k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9465,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9470,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9469 in k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9470(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9470,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9474,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1636 ##sys#print */
t4=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[329],C_SCHEME_FALSE,*((C_word*)lf[321]+1));}

/* k9472 in a9469 in k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_car(((C_word*)t0)[2]);
/* eval.scm: 1637 ##sys#print */
t4=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[321]+1));}

/* k9475 in k9472 in a9469 in k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9480,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_slot(((C_word*)t0)[2],C_fix(1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9489,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1639 ##sys#print */
t4=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[328],C_SCHEME_FALSE,*((C_word*)lf[321]+1));}
else{
t3=t2;
f_9480(2,t3,C_SCHEME_UNDEFINED);}}

/* k9487 in k9475 in k9472 in a9469 in k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9492,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 1640 ##sys#print */
t4=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_TRUE,*((C_word*)lf[321]+1));}

/* k9490 in k9487 in k9475 in k9472 in a9469 in k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1641 ##sys#write-char-0 */
t2=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(41),*((C_word*)lf[321]+1));}

/* k9478 in k9475 in k9472 in a9469 in k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1642 ##sys#write-char-0 */
t2=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[321]+1));}

/* k9463 in k9460 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1644 ##sys#flush-output */
t2=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[321]+1));}

/* k9448 in loop in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(9));}

/* k9430 in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_i_nullp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9278,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_9278(t6,t4);}
else{
t6=(C_word)C_u_i_car(t3);
t7=t5;
f_9278(t7,(C_word)C_eqp(C_SCHEME_UNDEFINED,t6));}}

/* k9276 in k9430 in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9278(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9278,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_9435(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9283,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a9282 in k9276 in k9430 in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9283,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[316]+1));}

/* k9433 in k9430 in a9427 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1650 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9388(t2,((C_word*)t0)[2]);}

/* a9418 in k9411 in k9408 in k9399 in k9396 in k9393 in loop in a9381 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9419,2,t0,t1);}
t2=*((C_word*)lf[306]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9322,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1590 load-verbose */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9322,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9325,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1591 load-verbose */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1592 ##sys#error-handler */
t3=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9330(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_9330r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9330r(t0,t1,t2,t3);}}

static void C_ccall f_9330r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=f_9308(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9337,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1595 ##sys#print */
t6=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[325],C_SCHEME_FALSE,*((C_word*)lf[321]+1));}

/* k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9377,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1597 ##sys#print */
t4=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[324],C_SCHEME_FALSE,*((C_word*)lf[321]+1));}
else{
t3=t2;
f_9340(2,t3,C_SCHEME_UNDEFINED);}}

/* k9375 in k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1598 ##sys#print */
t2=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[321]+1));}

/* k9338 in k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9343,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9352,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=t3;
f_9352(t5,(C_word)C_i_nullp(t4));}
else{
t4=t3;
f_9352(t4,C_SCHEME_FALSE);}}

/* k9350 in k9338 in k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9352,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1601 ##sys#print */
t3=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[323],C_SCHEME_FALSE,*((C_word*)lf[321]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1604 ##sys#write-char-0 */
t3=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[321]+1));}}

/* k9359 in k9350 in k9338 in k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1605 write-err */
f_9256(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9353 in k9350 in k9338 in k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1602 write-err */
f_9256(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9341 in k9338 in k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1606 print-call-chain */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[321]+1));}

/* k9344 in k9341 in k9338 in k9335 in a9329 in k9323 in k9320 in a9316 in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1607 flush-output */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[321]+1));}

/* resetports in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static C_word C_fcall f_9308(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[322]+1 /* (set! standard-input ...) */,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[316]+1 /* (set! standard-output ...) */,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[321]+1 /* (set! standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k9298 in k9295 in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static C_word C_fcall f_9302(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[322]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[316]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[321]+1));
return(t3);}

/* write-err in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9256(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9256,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9262,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a9261 in write-err in repl in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9262,3,t0,t1,t2);}
/* ##sys#repl-print-hook */
t3=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[321]+1));}

/* ##sys#clear-trace-buffer in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9250,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2781(C_SCHEME_UNDEFINED));}

/* ##sys#read-prompt-hook in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9238,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9245,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9248,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1548 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9246 in ##sys#read-prompt-hook in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9243 in ##sys#read-prompt-hook in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1548 ##sys#print */
t2=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,*((C_word*)lf[316]+1));}

/* k9236 in ##sys#read-prompt-hook in k9230 in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1549 ##sys#flush-output */
t2=*((C_word*)lf[315]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[316]+1));}

/* ##sys#repl-print-hook in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9215,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9219,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9224,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1540 ##sys#with-print-length-limit */
t6=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[307]+1),t5);}

/* a9223 in ##sys#repl-print-hook in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9224,2,t0,t1);}
/* ##sys#print */
t2=*((C_word*)lf[311]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k9217 in ##sys#repl-print-hook in k9208 in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1541 ##sys#write-char-0 */
t2=*((C_word*)lf[310]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9155,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9159,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1514 display-rj */
t5=((C_word*)t0)[2];
f_9134(t5,t3,t4,C_fix(8));}

/* k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1515 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[305]);}

/* k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1516 display-rj */
t4=((C_word*)t0)[2];
f_9134(t4,t2,t3,C_fix(8));}

/* k9163 in k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1517 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[304]);}

/* k9166 in k9163 in k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1518 display-rj */
t4=((C_word*)t0)[2];
f_9134(t4,t2,t3,C_fix(8));}

/* k9169 in k9166 in k9163 in k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1519 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[303]);}

/* k9172 in k9169 in k9166 in k9163 in k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1520 display-rj */
t4=((C_word*)t0)[2];
f_9134(t4,t2,t3,C_fix(8));}

/* k9175 in k9172 in k9169 in k9166 in k9163 in k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1521 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[302]);}

/* k9178 in k9175 in k9172 in k9169 in k9166 in k9163 in k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9183,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1522 display-rj */
t4=((C_word*)t0)[2];
f_9134(t4,t2,t3,C_fix(8));}

/* k9181 in k9178 in k9175 in k9172 in k9169 in k9166 in k9163 in k9160 in k9157 in ##sys#display-times in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1523 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[301]);}

/* display-rj in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9134(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9134,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9138,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_9138(2,t5,lf[300]);}
else{
/* eval.scm: 1509 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k9136 in display-rj in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9138,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9141,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1511 spaces */
t5=((C_word*)t0)[2];
f_9110(t5,t3,t4);}

/* k9139 in k9136 in display-rj in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1512 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9110,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9116,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9116(t6,t1,t2);}

/* doloop2719 in spaces in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9116(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9116,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9126,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1506 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k9124 in doloop2719 in spaces in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9116(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8968(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4rv,(void*)f_8968r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_8968r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8968r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t4,C_fix(0)));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8974,a[2]=t8,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9009,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9039,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t10,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1482 test */
t12=t10;
f_9009(t12,t11,t2);}

/* k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9039,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9049,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9086,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1486 ##sys#repository-path */
t4=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_9049(2,t3,*((C_word*)lf[249]+1));}}}

/* k9084 in k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9089,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1488 ##sys#repository-path */
t4=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_9089(t3,C_SCHEME_END_OF_LIST);}}

/* k9094 in k9084 in k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9096,2,t0,t1);}
t2=((C_word*)t0)[2];
f_9089(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k9087 in k9084 in k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1484 ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[249]+1),t1);}

/* k9047 in k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9049,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_9051(t5,((C_word*)t0)[2],t1);}

/* loop in k9047 in k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9051,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9061,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9075,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1492 string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,lf[299],((C_word*)t0)[5]);}}

/* k9073 in loop in k9047 in k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1492 test */
t2=((C_word*)t0)[3];
f_9009(t2,((C_word*)t0)[2],t1);}

/* k9059 in loop in k9047 in k9037 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_9061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1495 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9051(t3,((C_word*)t0)[4],t2);}}

/* test in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_9009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9009,NULL,3,t0,t1,t2);}
t3=(C_word)C_fudge(C_fix(24));
t4=(C_truep(t3)?(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[8],*((C_word*)lf[212]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[212]+1),lf[8])):(C_word)C_a_i_list(&a,1,lf[8]));
/* eval.scm: 1477 test2 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8974(t5,t1,t2,t4);}

/* test2 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8974(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8974,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8987,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1471 exists? */
f_8949(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8990,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1472 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k8988 in test2 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1473 exists? */
f_8949(t2,t1);}

/* k8994 in k8988 in test2 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1475 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8974(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k8985 in test2 in ##sys#resolve-include-filename in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8949(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8949,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8953,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1466 ##sys#file-info */
t4=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8951 in exists? in k8941 in k8937 in k8934 in k8930 in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8916(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8916,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8918,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_8918 in initb in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8918,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8922,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1427 ##sys#hash-table-location */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8920 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8878(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8878r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8878r(t0,t1,t2,t3);}}

static void C_ccall f_8878r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8885,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1418 ##sys#error */
t8=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[296],lf[297],t2);}
else{
t8=t5;
f_8885(2,t8,C_SCHEME_UNDEFINED);}}

/* k8883 in null-environment in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8892,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1421 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8890 in k8883 in null-environment in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8892,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[286],t1,t3));}

/* scheme-report-environment in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8834(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8834r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8834r(t0,t1,t2,t3);}}

static void C_ccall f_8834r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,lf[293]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8854,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1409 ##sys#copy-env-table */
t9=*((C_word*)lf[289]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[284],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8867,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1410 ##sys#copy-env-table */
t9=*((C_word*)lf[289]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[285],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1411 ##sys#error */
t8=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[293],lf[294],t2);}}

/* k8865 in scheme-report-environment in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8867,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[286],t1,((C_word*)t0)[2]));}

/* k8852 in scheme-report-environment in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8854,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[286],t1,((C_word*)t0)[2]));}

/* interaction-environment in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8831,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[287]);}

/* ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8712(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8712r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8712r(t0,t1,t2,t3);}}

static void C_ccall f_8712r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(10);
t4=(C_word)C_i_check_structure(t2,lf[286]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_header_size(t7));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8733,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8733(t12,t1,C_fix(0),C_SCHEME_END_OF_LIST);}
else{
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8804,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8806,a[2]=t9,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1396 ##sys#walk-namespace */
t12=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}

/* a8805 in ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8806,3,t0,t1,t2);}
t3=(C_word)C_i_not(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8816,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8816(2,t5,t3);}
else{
/* eval.scm: 1398 pred */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k8814 in a8805 in ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8816,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k8802 in ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* doloop2542 in ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8733(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8733,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8751,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_slot(((C_word*)t0)[3],t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8757,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_8757(t10,t5,t6,t3);}}

/* loop in doloop2542 in ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8757(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8757,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_i_not(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8776,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_8776(2,t8,t6);}
else{
/* eval.scm: 1390 pred */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}}}

/* k8774 in loop in doloop2542 in ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8776,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* eval.scm: 1391 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8757(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1392 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8757(t3,((C_word*)t0)[2],t2,((C_word*)t0)[4]);}}

/* k8749 in doloop2542 in ##sys#environment-symbols in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_8733(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#copy-env-table in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5rv,(void*)f_8604r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_8604r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_8604r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_SCHEME_FALSE);
t8=(C_word)C_block_size(t2);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8614,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t2,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1357 ##sys#make-vector */
t10=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,C_SCHEME_END_OF_LIST);}

/* k8612 in ##sys#copy-env-table in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8614,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8619,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_8619(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop2502 in k8612 in ##sys#copy-env-table in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8619(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8619,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[7]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8640,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8646,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8646(t8,t3,t4);}}

/* copy in doloop2502 in k8612 in ##sys#copy-env-table in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8646(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8646,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_i_not(((C_word*)t0)[5]);
t6=(C_truep(t5)?t5:(C_word)C_u_i_memq(t4,((C_word*)t0)[5]));
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t9=(C_word)C_a_i_vector(&a,3,t4,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8679,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1372 copy */
t14=t10;
t15=t11;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1373 copy */
t14=t1;
t15=t7;
t1=t14;
t2=t15;
goto loop;}}}

/* k8677 in copy in doloop2502 in k8612 in ##sys#copy-env-table in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8679,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8638 in doloop2502 in k8612 in ##sys#copy-env-table in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8619(t4,((C_word*)t0)[2],t3);}

/* ##sys#environment? in k8579 in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8588,3,t0,t1,t2);}
if(C_truep((C_word)C_i_structurep(t2,lf[286]))){
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#string->c-identifier in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8525,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8529,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1335 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8527 in ##sys#string->c-identifier in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8529,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8537,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_8537(t6,((C_word*)t0)[2],C_fix(0));}

/* doloop2453 in k8527 in ##sys#string->c-identifier in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8537(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8537,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8557,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_8557(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_8557(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k8555 in doloop2453 in k8527 in ##sys#string->c-identifier in k8521 in k8518 in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8557(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8537(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8481,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[282]);
t5=(C_word)C_u_i_assq(t2,*((C_word*)lf[279]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8499,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8513,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[279]+1));
t9=C_mutate((C_word*)lf[279]+1 /* (set! extension-specifiers ...) */,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a8512 in set-extension-specifier! in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8513,3,t0,t1,t2);}
/* eval.scm: 1291 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a8498 in set-extension-specifier! in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8499,3,t0,t1,t2);}
/* eval.scm: 1289 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7974,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7977,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8002,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8043,a[2]=t5,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8349,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_u_i_car(t2);
t10=t8;
f_8349(t10,(C_word)C_i_symbolp(t9));}
else{
t9=t8;
f_8349(t9,C_SCHEME_FALSE);}}

/* k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8349,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[279]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8358,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[7]);}
else{
/* eval.scm: 1277 ##sys#error */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],lf[280],((C_word*)t0)[7]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
/* eval.scm: 1279 doit */
t2=((C_word*)t0)[2];
f_8043(t2,((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
/* eval.scm: 1280 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],lf[281],((C_word*)t0)[7]);}}}

/* k8356 in k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8358,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[198],t2);
/* eval.scm: 1265 values */
C_values(4,0,((C_word*)t0)[5],t3,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8388,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1267 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1276 ##sys#do-the-right-thing */
t2=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);}}}

/* k8386 in k8356 in k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8388,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8390,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_8390(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k8386 in k8356 in k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8390(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8390,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8408,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8412,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1271 reverse */
t7=*((C_word*)lf[33]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8417,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8427,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a8426 in loop in k8386 in k8356 in k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8427(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8427,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1273 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8390(t7,t1,t4,t5,t6);}

/* a8416 in loop in k8386 in k8356 in k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8417,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
/* eval.scm: 1272 ##sys#do-the-right-thing */
t3=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8410 in loop in k8386 in k8356 in k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8406 in loop in k8386 in k8356 in k8347 in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8408,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 1271 values */
C_values(4,0,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8043(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8043,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[273]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_8053(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[3])){
t5=t4;
f_8053(2,t5,(C_word)C_u_i_memq(t2,lf[277]));}
else{
/* eval.scm: 1214 ##sys#feature? */
t5=*((C_word*)lf[278]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8053,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8060,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1215 impform */
t3=((C_word*)t0)[5];
f_8002(t3,t2,lf[274],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[3]+1)))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8073,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8077,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[275],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8077(t7,(C_word)C_a_i_cons(&a,2,lf[140],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[53],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_8077(t8,(C_word)C_a_i_cons(&a,2,lf[229],t7));}}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[5]+1)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1225 ##sys#extension-information */
t3=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[276]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1237 ##sys#extension-information */
t3=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[276]);}}}}

/* k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8206,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[57],t1);
t3=(C_word)C_u_i_assq(lf[265],t1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8218,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
/* eval.scm: 1241 add-req */
t5=((C_word*)t0)[2];
f_7977(t5,t4,((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t5=t4;
f_8218(2,t5,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8311,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1255 add-req */
t3=((C_word*)t0)[2];
f_7977(t3,t2,((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k8309 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8318,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[53],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[128],t5);
/* eval.scm: 1257 impform */
t7=((C_word*)t0)[2];
f_8002(t7,t2,t6,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k8316 in k8309 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1256 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8237,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[53],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[126],t7);
t9=t4;
f_8237(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_8237(t5,C_SCHEME_END_OF_LIST);}}

/* k8235 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8237,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8241,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8245,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(((C_word*)t0)[4])?C_SCHEME_FALSE:((C_word*)t0)[3]);
if(C_truep(t4)){
t5=t3;
f_8245(t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8259,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8263,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8265,tmp=(C_word)a,a+=2,tmp);
t8=(C_truep(((C_word*)t0)[4])?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));
/* map */
t9=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}

/* a8264 in k8235 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8265,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[53],t3));}

/* k8261 in k8235 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8257 in k8235 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8259,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[128],t1);
t3=((C_word*)t0)[2];
f_8245(t3,(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}

/* k8243 in k8235 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8239 in k8235 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8231 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8233,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 1243 impform */
t3=((C_word*)t0)[4];
f_8002(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8223 in k8216 in k8204 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1242 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8118 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8120,2,t0,t1);}
t2=(C_word)C_u_i_assq(lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8134,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[53],t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,lf[126],t7);
t9=t4;
f_8138(t9,(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}
else{
t5=t4;
f_8138(t5,C_SCHEME_END_OF_LIST);}}

/* k8136 in k8118 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8138(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8138,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8146,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8150,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[275],t4);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=t3;
f_8150(t7,(C_word)C_a_i_cons(&a,2,lf[140],t6));}
else{
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[53],t4);
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=t3;
f_8150(t8,(C_word)C_a_i_cons(&a,2,lf[229],t7));}}

/* k8148 in k8136 in k8118 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8150(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1230 impform */
t2=((C_word*)t0)[4];
f_8002(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8144 in k8136 in k8118 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8146,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8132 in k8118 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8134,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 1227 values */
C_values(4,0,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k8075 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1218 impform */
t2=((C_word*)t0)[4];
f_8002(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k8071 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1217 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k8058 in k8051 in doit in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1215 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* impform in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8002(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8002,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8014,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8018,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8021,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t8=(C_word)C_i_not(t4);
if(C_truep(t8)){
t9=t7;
f_8021(2,t9,t8);}
else{
/* eval.scm: 1207 ##sys#current-module */
t9=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}}
else{
t8=t7;
f_8021(2,t8,C_SCHEME_FALSE);}}

/* k8019 in impform in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8021,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[272],t2);
t4=((C_word*)t0)[2];
f_8018(t4,(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[2];
f_8018(t2,C_SCHEME_END_OF_LIST);}}

/* k8016 in impform in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_8018(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8012 in impform in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_8014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8014,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[67],t2));}

/* add-req in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7977(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7977,NULL,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=(C_truep(t3)?lf[267]:lf[268]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7990,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1199 ##sys#hash-table-update! */
t7=*((C_word*)lf[18]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t1,*((C_word*)lf[271]+1),t4,t5,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* a7995 in add-req in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7996,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7989 in add-req in ##sys#do-the-right-thing in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7990(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7990,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[269]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[270]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7925,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7931,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7931(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7931(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7931,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7945,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1188 ##sys#extension-information */
t5=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k7943 in loop1 in ##sys#lookup-runtime-requirements in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[265],t1);
t4=t2;
f_7948(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_7948(t3,C_SCHEME_FALSE);}}

/* k7946 in k7943 in loop1 in ##sys#lookup-runtime-requirements in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7948(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7948,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7955,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1192 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7931(t5,t3,t4);}

/* k7953 in k7946 in k7943 in loop1 in ##sys#lookup-runtime-requirements in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1187 append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7919,3,t0,t1,t2);}
/* eval.scm: 1178 ##sys#extension-information */
t3=*((C_word*)lf[260]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[264]);}

/* ##sys#extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7886(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7886,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7890,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1170 ##sys#repository-path */
t5=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7888 in ##sys#extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7896,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1171 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7894 in k7888 in ##sys#extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1172 string-append */
t3=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],lf[262],t1,lf[263]);}

/* k7897 in k7894 in k7888 in ##sys#extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7917,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1173 string-append */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,lf[261]);}

/* k7915 in k7897 in k7894 in k7888 in ##sys#extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1173 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7900 in k7897 in k7894 in k7888 in ##sys#extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7902,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_7909 in k7900 in k7897 in k7894 in k7888 in ##sys#extension-information in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7909,3,t0,t1,t2);}
/* with-input-from-file2128 */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#require in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7873(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7873r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7873r(t0,t1,t2);}}

static void C_ccall f_7873r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7879,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7878 in ##sys#require in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7879,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[253]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[259]);}

/* ##sys#provided? in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7859,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7870,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1151 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[258]);}

/* k7868 in ##sys#provided? in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[251]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7839(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_7839r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7839r(t0,t1,t2);}}

static void C_ccall f_7839r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7845,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a7844 in ##sys#provide in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7845,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[256]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7852,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1144 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[256]);}

/* k7850 in a7844 in ##sys#provide in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7852,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[251]+1));
t3=C_mutate((C_word*)lf[251]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_7771r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7771r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7775,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t5)[1]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7834,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1125 string->symbol */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t5)[1]);}
else{
t7=t6;
f_7775(t7,(C_word)C_i_check_symbol_2(((C_word*)t5)[1],t3));}}

/* k7832 in ##sys#load-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7775(t3,t2);}

/* k7773 in ##sys#load-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7775,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7778,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1127 ##sys#canonicalize-extension-path */
t3=*((C_word*)lf[238]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[2]);}

/* k7776 in k7773 in ##sys#load-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7778,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[251]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[3]+1)))){
/* eval.scm: 1130 ##sys#load-library */
t3=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7796,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1132 ##sys#find-extension */
t4=*((C_word*)lf[247]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k7794 in k7776 in k7773 in ##sys#load-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7796,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1134 ##sys#load */
t3=*((C_word*)lf[193]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_TRUE:(C_word)C_u_i_car(t2));
if(C_truep(t4)){
/* eval.scm: 1137 ##sys#error */
t5=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[3],lf[254],((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}

/* k7800 in k7794 in k7776 in k7773 in ##sys#load-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[251]+1));
t3=C_mutate((C_word*)lf[251]+1 /* (set! loaded-extensions ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7680,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7684,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1102 ##sys#repository-path */
t5=*((C_word*)lf[244]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7732,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(t1)?(C_word)C_a_i_list(&a,1,t1):C_SCHEME_END_OF_LIST);
t5=(C_truep(((C_word*)t0)[2])?*((C_word*)lf[249]+1):C_SCHEME_END_OF_LIST);
/* eval.scm: 1111 ##sys#append */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,t5,lf[250]);}

/* k7730 in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7732,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7734,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7734(t5,((C_word*)t0)[2],t1);}

/* loop in k7730 in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7734,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7747,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1117 check */
t5=((C_word*)t0)[2];
f_7686(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7745 in loop in k7730 in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1118 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7734(t3,((C_word*)t0)[4],t2);}}

/* check in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7686(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7686,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7690,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1104 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[248],((C_word*)t0)[2]);}

/* k7688 in check in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7696,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[178]+1);
if(C_truep(t3)){
t4=t2;
f_7696(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7725,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1108 ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t1,*((C_word*)lf[212]+1));}
else{
t4=t2;
f_7696(2,t4,C_SCHEME_FALSE);}}}
else{
t3=t2;
f_7696(2,t3,C_SCHEME_FALSE);}}

/* k7723 in k7688 in check in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1108 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7694 in k7688 in check in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7699,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7699(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7706,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1109 ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[8]);}}

/* k7704 in k7694 in k7688 in check in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1109 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7697 in k7694 in k7688 in check in k7682 in ##sys#find-extension in k7675 in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7517,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7520,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7526,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7539,a[2]=t1,a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t7=t6;
f_7539(2,t7,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1064 ##sys#symbol->string */
t7=*((C_word*)lf[240]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7622,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7622(t10,t6,t2);}
else{
t7=t6;
f_7539(2,t7,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7622(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7622,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[241]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1071 ##sys#symbol->string */
t5=*((C_word*)lf[240]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_7639(2,t5,t3);}
else{
/* eval.scm: 1073 err */
t5=((C_word*)t0)[2];
f_7520(t5,t4);}}}}

/* k7637 in loop in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7639,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[242]:lf[243]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7647,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1077 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7622(t7,t5,t6);}

/* k7645 in k7637 in loop in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1069 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7537 in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7539,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7544,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7544(t5,((C_word*)t0)[2],t1);}

/* check in k7537 in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7544(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7544,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1080 err */
t5=((C_word*)t0)[4];
f_7520(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=f_7526(t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7570,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1082 ##sys#substring */
t8=*((C_word*)lf[201]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=f_7526(t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7583,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1084 ##sys#substring */
t12=*((C_word*)lf[201]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k7581 in check in k7537 in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1084 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7544(t2,((C_word*)t0)[2],t1);}

/* k7568 in check in k7537 in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1082 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_7544(t2,((C_word*)t0)[2],t1);}

/* sep? in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static C_word C_fcall f_7526(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_eqp(C_make_character(92),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(47),t1)));}

/* err in ##sys#canonicalize-extension-path in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7520,NULL,2,t0,t1);}
/* eval.scm: 1061 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[239],((C_word*)t0)[2]);}

/* load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7432(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7432r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7432r(t0,t1,t2,t3);}}

static void C_ccall f_7432r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[236]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7439,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1040 ##sys#load-library */
t8=*((C_word*)lf[229]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k7437 in load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7439,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k7447 in k7437 in load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1041 ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[236],lf[237],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7326,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7330,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1013 ##sys#->feature-id */
t5=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7330,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[143]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_7339(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7422,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1018 ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[223]+1));}}}

/* k7420 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7426,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1019 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7424 in k7420 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7426,2,t0,t1);}
t2=((C_word*)t0)[3];
f_7339(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7339,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7404,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7408,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1024 ##sys#string->c-identifier */
t6=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k7406 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1022 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[232],t1,lf[233]);}

/* k7402 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1021 ##sys#make-c-string */
t2=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7345,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7391,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1026 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k7389 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7391,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1027 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[231]);}
else{
t2=((C_word*)t0)[3];
f_7345(2,t2,C_SCHEME_UNDEFINED);}}

/* k7392 in k7389 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1028 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7395 in k7392 in k7389 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1029 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[230]);}

/* k7343 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7345,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7350,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7350(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k7343 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7350(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7350,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7363,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7384,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1032 ##sys#make-c-string */
t6=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k7382 in loop in k7343 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1032 ##sys#dload */
t2=*((C_word*)lf[204]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7361 in loop in k7343 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7363,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7366,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[143]+1)))){
t3=t2;
f_7366(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[143]+1));
t4=C_mutate((C_word*)lf[143]+1 /* (set! features ...) */,t3);
t5=t2;
f_7366(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1035 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7350(t3,((C_word*)t0)[5],t2);}}

/* k7364 in k7361 in loop in k7343 in k7340 in k7337 in k7328 in ##sys#load-library in k7322 in k7315 in k7310 in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7286(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_7286r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7286r(t0,t1,t2,t3);}}

static void C_ccall f_7286r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7290,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7307,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[219]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[222],t3,t5);}

/* a7306 in load-noisily in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7307,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7288 in load-noisily in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7293,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7304,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[219]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[221],((C_word*)t0)[2],t3);}

/* a7303 in k7288 in load-noisily in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7304,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7291 in k7288 in load-noisily in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7296,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7301,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[219]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[220],((C_word*)t0)[2],t3);}

/* a7300 in k7291 in k7288 in load-noisily in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7301,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k7294 in k7291 in k7288 in load-noisily in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 984  ##sys#load */
t2=*((C_word*)lf[193]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1);}

/* load-relative in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7250(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7250r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7250r(t0,t1,t2,t3);}}

static void C_ccall f_7250r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7258,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_subchar(t2,C_fix(0));
if(C_truep((C_truep((C_word)C_eqp(t5,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t5,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t6=t4;
f_7258(2,t6,t2);}
else{
/* eval.scm: 980  ##sys#string-append */
t6=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,*((C_word*)lf[176]+1),t2);}}

/* k7256 in load-relative in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
/* eval.scm: 977  ##sys#load */
t5=*((C_word*)lf[193]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,t4,C_SCHEME_FALSE);}

/* load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7228(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7228r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7228r(t0,t1,t2,t3);}}

static void C_ccall f_7228r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* eval.scm: 974  ##sys#load */
t6=*((C_word*)lf[193]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t5,C_SCHEME_FALSE);}

/* ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6832r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6832r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(24);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t4,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=t3,tmp=(C_word)a,a+=16,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7178,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7183,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer15701756 */
t10=t9;
f_7183(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer15711752 */
t12=t8;
f_7178(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body15681577 */
t14=t7;
f_6834(t14,t1,t10,t12);}}}

/* def-timer1570 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7183(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7183,NULL,2,t0,t1);}
/* def-printer15711752 */
t2=((C_word*)t0)[2];
f_7178(t2,t1,C_SCHEME_FALSE);}

/* def-printer1571 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7178(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7178,NULL,3,t0,t1,t2);}
/* body15681577 */
t3=((C_word*)t0)[2];
f_6834(t3,t1,t2,C_SCHEME_FALSE);}

/* body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_6834(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6834,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6838,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],a[16]=t1,a[17]=((C_word*)t0)[14],a[18]=((C_word*)t0)[15],tmp=(C_word)a,a+=19,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7177,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 906  ##sys#expand-home-path */
t6=*((C_word*)lf[216]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=t4;
f_6838(t5,C_SCHEME_UNDEFINED);}}

/* k7175 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6838(t3,t2);}

/* k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_6838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6838,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_6841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],tmp=(C_word)a,a+=19,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7099,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 909  port? */
t6=*((C_word*)lf[215]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* k7097 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7099,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6841(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 911  ##sys#file-info */
t3=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
/* eval.scm: 902  ##sys#signal-hook */
t3=*((C_word*)lf[185]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],lf[213],lf[198],lf[214],t2);}}}

/* k7112 in k7097 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t2;
f_7117(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_7117(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_7117(t3,C_SCHEME_FALSE);}}

/* k7115 in k7112 in k7097 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_7117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7117,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6841(2,t2,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 917  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[212]+1));}}

/* k7118 in k7115 in k7112 in k7097 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[178]+1);
if(C_truep(t3)){
t4=t2;
f_7126(2,t4,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_fudge(C_fix(24)))){
/* eval.scm: 920  ##sys#file-info */
t4=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t1);}
else{
t4=t2;
f_7126(2,t4,C_SCHEME_FALSE);}}}

/* k7124 in k7118 in k7115 in k7112 in k7097 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7126,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6841(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 922  ##sys#string-append */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[8]);}}

/* k7127 in k7124 in k7118 in k7115 in k7112 in k7097 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 923  ##sys#file-info */
t3=*((C_word*)lf[211]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k7133 in k7127 in k7124 in k7118 in k7115 in k7112 in k7097 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6841(2,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[5];
f_6841(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6841,2,t0,t1);}
t2=((C_word*)t0)[18];
t3=(C_truep(t2)?t2:((C_word*)t0)[17]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6847,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=t3,a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],a[14]=t1,a[15]=((C_word*)t0)[16],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 928  ##sys#signal-hook */
t7=*((C_word*)lf[185]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[207],lf[198],lf[208],((C_word*)((C_word*)t0)[7])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7090,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 929  load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k7088 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7090,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[5]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7078,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 930  display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[210]);}
else{
t3=((C_word*)t0)[3];
f_6847(2,t3,C_SCHEME_UNDEFINED);}}

/* k7076 in k7088 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 931  display */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7079 in k7076 in k7088 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 932  display */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[209]);}

/* k7082 in k7079 in k7076 in k7088 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 933  flush-output */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7063,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 935  ##sys#make-c-string */
t5=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_6850(2,t3,C_SCHEME_FALSE);}}

/* k7061 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 935  ##sys#dload */
t2=*((C_word*)lf[204]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k7033 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7035,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_6850(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 936  has-sep? */
f_6786(t2,((C_word*)t0)[3]);}}

/* k7057 in k7033 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7059,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_6850(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7055,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 937  ##sys#string-append */
t4=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[206],((C_word*)t0)[2]);}}

/* k7053 in k7057 in k7033 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 937  ##sys#make-c-string */
t2=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7049 in k7057 in k7033 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 937  ##sys#dload */
t2=*((C_word*)lf[204]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6853,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_6853(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 938  call-with-current-continuation */
t4=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6858,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[13];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6862,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t6,a[15]=t4,a[16]=t2,tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[13])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7022,a[2]=((C_word*)t0)[13],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 944  has-sep? */
f_6786(t8,((C_word*)t0)[13]);}
else{
t8=t7;
f_6862(2,t8,C_SCHEME_FALSE);}}

/* k7020 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(t1,C_fix(1));
/* eval.scm: 945  ##sys#substring */
t3=*((C_word*)lf[201]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
f_6862(2,t2,lf[202]);}}

/* k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6862,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6863,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6872,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t13,a[7]=t11,a[8]=t9,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7010,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
/* ##sys#dynamic-wind */
t17=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a7009 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7010,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[194]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[175]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[176]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[174]+1));
t6=C_mutate((C_word*)lf[194]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[175]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[176]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[174]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6887,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 947  open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6887(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6892,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7001,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 948  ##sys#dynamic-wind */
t5=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a7000 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_7001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7001,2,t0,t1);}
/* eval.scm: 970  close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6899,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 951  peek-char */
t3=*((C_word*)lf[200]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6995,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_6902(2,t4,C_SCHEME_UNDEFINED);}}

/* k6993 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 953  ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[198],lf[199],((C_word*)t0)[2],t1);}

/* k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 954  read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6905,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6910,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_6910(t5,((C_word*)t0)[2],t1);}

/* doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_6910(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6910,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 957  printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_6920(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6923,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6932,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 958  ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a6965 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6966(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_6966r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6966r(t0,t1,t2);}}

static void C_ccall f_6966r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6974 in a6965 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6975,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6979,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 967  write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6977 in a6974 in a6965 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 968  newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a6931 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6932,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6939,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[197]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 962  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6937 in a6931 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6950,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6949 in k6937 in a6931 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6950(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6950r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6950r(t0,t1,t2);}}

static void C_ccall f_6950r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6954,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6961,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[196]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6959 in a6949 in k6937 in a6931 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
t2=*((C_word*)lf[195]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6952 in a6949 in k6937 in a6931 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6943 in k6937 in a6931 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6944,2,t0,t1);}
/* eval.scm: 961  evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k6921 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 955  read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6928 in k6921 in k6918 in doloop1705 in k6903 in k6900 in k6897 in a6894 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_6910(t2,((C_word*)t0)[2],t1);}

/* a6891 in k6885 in a6882 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6892,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a6871 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6872,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,*((C_word*)lf[194]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[175]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[176]+1));
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[174]+1));
t6=C_mutate((C_word*)lf[194]+1 /* (set! read-error-with-line-number ...) */,((C_word*)((C_word*)t0)[5])[1]);
t7=C_mutate((C_word*)lf[175]+1 /* (set! current-source-filename ...) */,((C_word*)((C_word*)t0)[4])[1]);
t8=C_mutate((C_word*)lf[176]+1 /* (set! current-load-path ...) */,((C_word*)((C_word*)t0)[3])[1]);
t9=C_mutate((C_word*)lf[174]+1 /* (set! abort-load ...) */,((C_word*)((C_word*)t0)[2])[1]);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}

/* f_6863 in k6860 in a6857 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6863,2,t0,t1);}
/* eval.scm: 946  abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k6851 in k6848 in k6845 in k6839 in k6836 in body1568 in ##sys#load in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* has-sep? in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_6786(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6786,NULL,2,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6796,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_6796(t5,t4));}

/* loop in has-sep? in k6782 in k6701 in k6606 in k3371 in k3368 in k3335 */
static C_word C_fcall f_6796(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
if(C_truep((C_truep((C_word)C_eqp(t2,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
return(t1);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* set-dynamic-load-mode! in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6711,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6718,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6723,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_6723(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_6723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6723,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6736,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[181]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_6736(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[182]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_6736(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[183]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_6736(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[184]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_6736(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 880  ##sys#signal-hook */
t10=*((C_word*)lf[185]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[179],lf[186],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6734 in loop in set-dynamic-load-mode! in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 881  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6723(t3,((C_word*)t0)[2],t2);}

/* k6716 in set-dynamic-load-mode! in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 882  ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[180]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_6705 in k6701 in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6705,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6621,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6624,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6634,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_6634(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_6634(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6634,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6648,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 849  reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6667,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 851  reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 853  loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 852  err */
t6=((C_word*)t0)[2];
f_6624(t6,t1);}}}
else{
/* eval.scm: 850  err */
t6=((C_word*)t0)[2];
f_6624(t6,t1);}}}

/* k6665 in loop in ##sys#decompose-lambda-list in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 851  k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6646 in loop in ##sys#decompose-lambda-list in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 849  k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k6606 in k3371 in k3368 in k3335 */
static void C_fcall f_6624(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6624,NULL,2,t0,t1);}
t2=C_set_block_item(lf[171] /* syntax-error-culprit */,0,C_SCHEME_FALSE);
/* eval.scm: 846  ##sys#syntax-error-hook */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[172],((C_word*)t0)[2]);}

/* eval in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6611(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6611r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6611r(t0,t1,t2,t3);}}

static void C_ccall f_6611r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6619,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 834  ##sys#eval-handler */
t5=*((C_word*)lf[168]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6617 in eval in k6606 in k3371 in k3368 in k3335 */
static void C_ccall f_6619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+38)){
C_save_and_reclaim((void*)tr5rv,(void*)f_3713r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_3713r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word *a=C_alloc(38);
t6=(C_word)C_vemptyp(t5);
t7=(C_truep(t6)?C_SCHEME_FALSE:(C_word)C_slot(t5,C_fix(0)));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3719,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3758,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3773,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3857,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3863,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3869,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3875,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3926,a[2]=t20,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=t16,a[6]=t15,a[7]=t18,a[8]=t14,a[9]=((C_word*)t0)[3],a[10]=t12,tmp=(C_word)a,a+=11,tmp));
t22=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6360,a[2]=t18,a[3]=t13,tmp=(C_word)a,a+=4,tmp));
t23=(C_word)C_fixnum_greaterp(*((C_word*)lf[32]+1),C_fix(0));
/* eval.scm: 813  compile */
t24=((C_word*)t18)[1];
f_3926(t24,t1,t2,t3,C_SCHEME_FALSE,t23,t7,t4);}

/* compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_6360(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6360,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6364,a[2]=t6,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[3],a[8]=t1,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 777  compile */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3926(t9,t7,t8,t3,C_SCHEME_FALSE,t4,t5,t6);}

/* k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6364,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6334,tmp=(C_word)a,a+=2,tmp);
t4=f_6334(t2,C_fix(0));
t5=((C_word*)t0)[9];
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 782  ##sys#syntax-error-hook */
t6=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],lf[167],((C_word*)t0)[9]);
case C_fix(0):
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6386,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
case C_fix(1):
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6405,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 786  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3926(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(2):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 790  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3926(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(3):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 795  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3926(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
case C_fix(4):
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t7=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 801  compile */
t8=((C_word*)((C_word*)t0)[4])[1];
f_3926(t8,t6,t7,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);
default:
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6553,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 808  ##sys#map */
t8=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t2);}}

/* a6576 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6577,3,t0,t1,t2);}
/* eval.scm: 808  compile */
t3=((C_word*)((C_word*)t0)[6])[1];
f_3926(t3,t1,t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6551 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6553,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6554,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6554 in k6551 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6554,3,t0,t1,t2);}
t3=f_3857(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6565,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6563 */
static void C_ccall f_6565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6569,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 811  ##sys#map */
t4=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a6570 in k6563 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6571,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k6567 in k6563 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6508 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 802  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3926(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6511 in k6508 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 803  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3926(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6514 in k6511 in k6508 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6519,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 804  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3926(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(3)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[11],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k6517 in k6514 in k6511 in k6508 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6519,2,t0,t1);}
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp));}

/* f_6520 in k6517 in k6514 in k6511 in k6508 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6520,3,t0,t1,t2);}
t3=f_3857(((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6529 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6535,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6533 in k6529 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6537 in k6533 in k6529 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6541 in k6537 in k6533 in k6529 */
static void C_ccall f_6543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6546,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6544 in k6541 in k6537 in k6533 in k6529 */
static void C_ccall f_6546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6466 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 796  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3926(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6469 in k6466 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6474,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 797  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3926(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[10],((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k6472 in k6469 in k6466 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6474,2,t0,t1);}
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));}

/* f_6475 in k6472 in k6469 in k6466 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6475,3,t0,t1,t2);}
t3=f_3857(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6484 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k6488 in k6484 */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6492 in k6488 in k6484 */
static void C_ccall f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6497,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6495 in k6492 in k6488 in k6484 */
static void C_ccall f_6497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6431 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6436,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 791  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3926(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[7],((C_word*)t0)[2]);}

/* k6434 in k6431 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6436,2,t0,t1);}
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));}

/* f_6437 in k6434 in k6431 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6437,3,t0,t1,t2);}
t3=f_3857(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6448,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6446 */
static void C_ccall f_6448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6450 in k6446 */
static void C_ccall f_6452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6455,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6453 in k6450 in k6446 */
static void C_ccall f_6455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6403 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6405,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6406,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));}

/* f_6406 in k6403 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6406,3,t0,t1,t2);}
t3=f_3857(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6417,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6415 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6420,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6418 in k6415 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_6386 in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6386(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6386,3,t0,t1,t2);}
t3=f_3857(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 785  fn */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6394 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k6362 in compile-call in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static C_word C_fcall f_6334(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3926(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3926,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=((C_word*)t0)[8],a[11]=t6,a[12]=((C_word*)t0)[9],a[13]=t7,a[14]=t3,a[15]=((C_word*)t0)[10],a[16]=t2,a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* eval.scm: 285  keyword? */
t9=*((C_word*)lf[166]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[17];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[16]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3946,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[16],a[5]=((C_word*)t0)[15],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[17],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[17],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
/* eval.scm: 311  ##sys#number? */
t3=*((C_word*)lf[165]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[16]);}}}

/* k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4060,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4068,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4076,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4084,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[16],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[16]))){
t2=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[16])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4097,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4099,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4109,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=t3;
f_4109(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[16]);
t5=t3;
f_4109(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[16])));}}}}

/* k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_4109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4109,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[16];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[15]))){
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=f_3863(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* eval.scm: 329  ##sys#expand */
t5=*((C_word*)lf[163]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[15],((C_word*)t0)[11],C_SCHEME_FALSE);}
else{
t3=f_3863(((C_word*)t0)[13],((C_word*)t0)[15],((C_word*)t0)[12]);
/* eval.scm: 754  compile-call */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6360(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[9],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11]);}}
else{
/* eval.scm: 326  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[16],lf[164],((C_word*)t0)[15]);}}}

/* k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4132,2,t0,t1);}
t2=*((C_word*)lf[39]+1);
t3=(C_word)C_eqp(t1,((C_word*)t0)[15]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_slot(((C_word*)t0)[15],C_fix(0));
/* eval.scm: 333  rename */
t6=((C_word*)t0)[4];
f_3758(t6,t4,t5,((C_word*)t0)[13]);}
else{
/* eval.scm: 332  compile */
t4=((C_word*)((C_word*)t0)[12])[1];
f_3926(t4,((C_word*)t0)[14],t1,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}}

/* k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4147,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[53]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 339  ##sys#check-syntax */
t4=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,t3,lf[53],((C_word*)t0)[14],lf[56],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t3=(C_word)C_eqp(t1,lf[57]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(t1,lf[58]));
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t6=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}
else{
t5=(C_word)C_eqp(t1,lf[59]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
if(C_truep(*((C_word*)lf[23]+1))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 358  ##sys#hash-table-location */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,*((C_word*)lf[23]+1),t6,C_SCHEME_TRUE);}
else{
t7=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4256,a[2]=t6,tmp=(C_word)a,a+=3,tmp));}}
else{
t6=(C_word)C_eqp(t1,lf[60]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 363  compile */
t8=((C_word*)((C_word*)t0)[12])[1];
f_3926(t8,((C_word*)t0)[15],t7,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t7=(C_word)C_eqp(t1,lf[61]);
if(C_truep(t7)){
t8=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 366  compile */
t9=((C_word*)((C_word*)t0)[12])[1];
f_3926(t9,((C_word*)t0)[15],t8,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t8=(C_word)C_eqp(t1,lf[62]);
if(C_truep(t8)){
t9=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4290,tmp=(C_word)a,a+=2,tmp));}
else{
t9=(C_word)C_eqp(t1,lf[63]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 371  ##sys#check-syntax */
t11=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t10,lf[63],((C_word*)t0)[14],lf[65],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t10=(C_word)C_eqp(t1,lf[66]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t1,lf[67]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 380  ##sys#check-syntax */
t13=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t13+1)))(7,t13,t12,lf[66],((C_word*)t0)[14],lf[70],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t12=(C_word)C_eqp(t1,lf[71]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t1,lf[72]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4472,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 396  ##sys#check-syntax */
t15=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t15+1)))(7,t15,t14,lf[71],((C_word*)t0)[14],lf[75],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t14=(C_word)C_eqp(t1,lf[76]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t1,lf[77]));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4584,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 420  ##sys#check-syntax */
t17=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t17+1)))(7,t17,t16,lf[76],((C_word*)t0)[14],lf[85],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t16=(C_word)C_eqp(t1,lf[86]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t1,lf[87]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[14],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 472  ##sys#check-syntax */
t19=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,lf[86],((C_word*)t0)[14],lf[89]);}
else{
t18=(C_word)C_eqp(t1,lf[90]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(t1,lf[91]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 487  ##sys#check-syntax */
t21=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t21+1)))(7,t21,t20,lf[90],((C_word*)t0)[14],lf[99],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t20=(C_word)C_eqp(t1,lf[100]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 582  ##sys#check-syntax */
t22=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t22+1)))(7,t22,t21,lf[100],((C_word*)t0)[14],lf[102],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t21=(C_word)C_eqp(t1,lf[103]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 597  ##sys#check-syntax */
t23=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t23+1)))(7,t23,t22,lf[103],((C_word*)t0)[14],lf[104],C_SCHEME_FALSE,((C_word*)t0)[13]);}
else{
t22=(C_word)C_eqp(t1,lf[105]);
t23=(C_truep(t22)?t22:(C_word)C_eqp(t1,lf[106]));
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t25=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],a[4]=t24,tmp=(C_word)a,a+=5,tmp);
t26=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t28=t25;
f_5590(t28,(C_word)C_i_pairp(t27));}
else{
t27=t25;
f_5590(t27,C_SCHEME_FALSE);}}
else{
t24=(C_word)C_eqp(t1,lf[114]);
if(C_truep(t24)){
/* eval.scm: 636  compile */
t25=((C_word*)((C_word*)t0)[12])[1];
f_3926(t25,((C_word*)t0)[15],lf[115],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t25=(C_word)C_eqp(t1,lf[116]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t27=(C_word)C_u_i_cddr(((C_word*)t0)[14]);
/* eval.scm: 640  ##sys#canonicalize-body */
t28=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t28+1)))(5,t28,t26,t27,((C_word*)t0)[13],C_SCHEME_FALSE);}
else{
t26=(C_word)C_eqp(t1,lf[117]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[14],tmp=(C_word)a,a+=8,tmp);
t28=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 644  rename */
t29=((C_word*)t0)[4];
f_3758(t29,t27,t28,((C_word*)t0)[13]);}
else{
t27=(C_word)C_eqp(t1,lf[124]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 689  rename */
t29=((C_word*)t0)[4];
f_3758(t29,t28,lf[90],((C_word*)t0)[13]);}
else{
t28=(C_word)C_eqp(t1,lf[125]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 692  rename */
t30=((C_word*)t0)[4];
f_3758(t30,t29,lf[90],((C_word*)t0)[13]);}
else{
t29=(C_word)C_eqp(t1,lf[126]);
if(C_truep(t29)){
t30=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t32=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
/* map */
t33=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t30,t31,t32);}
else{
t30=(C_word)C_eqp(t1,lf[130]);
if(C_truep(t30)){
t31=(C_word)C_u_i_caddr(((C_word*)t0)[14]);
t32=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5971,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t33=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5977,a[2]=t35,a[3]=t31,tmp=(C_word)a,a+=4,tmp));
t37=((C_word*)t35)[1];
f_5977(t37,t32,t33);}
else{
t31=(C_word)C_eqp(t1,lf[133]);
t32=(C_truep(t31)?t31:(C_word)C_eqp(t1,lf[134]));
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6031,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t34=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 718  eval/meta */
f_3875(t33,t34);}
else{
t33=(C_word)C_eqp(t1,lf[136]);
if(C_truep(t33)){
t34=(C_word)C_u_i_cadr(((C_word*)t0)[14]);
/* eval.scm: 722  compile */
t35=((C_word*)((C_word*)t0)[12])[1];
f_3926(t35,((C_word*)t0)[15],t34,((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t34=(C_word)C_eqp(t1,lf[137]);
t35=(C_truep(t34)?t34:(C_word)C_eqp(t1,lf[138]));
if(C_truep(t35)){
/* eval.scm: 725  compile */
t36=((C_word*)((C_word*)t0)[12])[1];
f_3926(t36,((C_word*)t0)[15],lf[139],((C_word*)t0)[11],C_SCHEME_FALSE,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[13]);}
else{
t36=(C_word)C_eqp(t1,lf[140]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6072,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[15],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_u_i_memq(lf[142],*((C_word*)lf[143]+1)))){
t38=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6083,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
t39=(C_word)C_slot(((C_word*)t0)[14],C_fix(1));
/* for-each */
t40=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t40+1)))(4,t40,t37,t38,t39);}
else{
/* eval.scm: 730  ##sys#warn */
t38=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t38+1)))(4,t38,t37,lf[146],((C_word*)t0)[14]);}}
else{
t37=(C_word)C_eqp(t1,lf[147]);
t38=(C_truep(t37)?t37:(C_word)C_eqp(t1,lf[148]));
if(C_truep(t38)){
t39=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6114,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 734  rename */
t40=((C_word*)t0)[4];
f_3758(t40,t39,lf[149],((C_word*)t0)[13]);}
else{
t39=(C_word)C_eqp(t1,lf[51]);
t40=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6131,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t39)){
t41=t40;
f_6131(t41,t39);}
else{
t41=(C_word)C_eqp(t1,lf[154]);
if(C_truep(t41)){
t42=t40;
f_6131(t42,t41);}
else{
t42=(C_word)C_eqp(t1,lf[155]);
if(C_truep(t42)){
t43=t40;
f_6131(t43,t42);}
else{
t43=(C_word)C_eqp(t1,lf[156]);
if(C_truep(t43)){
t44=t40;
f_6131(t44,t43);}
else{
t44=(C_word)C_eqp(t1,lf[157]);
if(C_truep(t44)){
t45=t40;
f_6131(t45,t44);}
else{
t45=(C_word)C_eqp(t1,lf[158]);
if(C_truep(t45)){
t46=t40;
f_6131(t46,t45);}
else{
t46=(C_word)C_eqp(t1,lf[159]);
if(C_truep(t46)){
t47=t40;
f_6131(t47,t46);}
else{
t47=(C_word)C_eqp(t1,lf[160]);
if(C_truep(t47)){
t48=t40;
f_6131(t48,t47);}
else{
t48=(C_word)C_eqp(t1,lf[161]);
t49=t40;
f_6131(t49,(C_truep(t48)?t48:(C_word)C_eqp(t1,lf[162])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k6129 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_6131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 741  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[9],lf[150],((C_word*)t0)[8]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[151]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* eval.scm: 744  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6360(t4,((C_word*)t0)[9],t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[152]);
if(C_truep(t3)){
/* eval.scm: 748  ##sys#syntax-error-hook */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[9],lf[153],((C_word*)t0)[8]);}
else{
/* eval.scm: 750  compile-call */
t4=((C_word*)((C_word*)t0)[6])[1];
f_6360(t4,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k6112 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k6116 in k6112 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6118,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 734  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3926(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6082 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6083(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6083,3,t0,t1,t2);}
/* eval.scm: 729  ##compiler#process-declaration */
t3=*((C_word*)lf[144]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k6070 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 731  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],lf[141],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6029 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 719  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],lf[135],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_5977(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5977,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[131]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5989,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5999,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5998 in loop in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5999,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6015,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 714  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5977(t6,t4,t5);}

/* k6013 in a5998 in loop in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6015,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[67],t3));}

/* a5988 in loop in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5989,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 713  ##sys#do-the-right-thing */
t3=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5969 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 708  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5946 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5947,3,t0,t1,t2);}
/* eval.scm: 696  eval/meta */
f_3875(t1,t2);}

/* k5906 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5911,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[128]+1),t1);}

/* k5909 in k5906 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5914,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 699  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[129]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5912 in k5909 in k5906 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5921(t3,lf[127]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5931,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5935,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5937,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t1);}}

/* a5936 in k5912 in k5909 in k5906 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5937,3,t0,t1,t2);}
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[53],t3));}

/* k5933 in k5912 in k5909 in k5906 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5929 in k5912 in k5909 in k5906 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5921(t2,(C_word)C_a_i_cons(&a,2,lf[128],t1));}

/* k5919 in k5912 in k5909 in k5906 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_5921(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 700  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5889 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
/* ##sys#append */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5893 in k5889 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
/* eval.scm: 692  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3926(t4,((C_word*)t0)[6],t2,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5860 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* ##sys#append */
t4=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5864 in k5860 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
/* eval.scm: 689  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3926(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5639,2,t0,t1);}
t2=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5645,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_5645(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5781,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5833,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 659  ##sys#strip-syntax */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}}

/* k5831 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5780 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5781,3,t0,t1,t2);}
if(C_truep((C_word)C_i_symbolp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5794,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5805,tmp=(C_word)a,a+=2,tmp);
t5=t3;
f_5794(t5,f_5805(t2));}
else{
t4=t3;
f_5794(t4,C_SCHEME_FALSE);}}}

/* loop in a5780 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static C_word C_fcall f_5805(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_i_car(t1);
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k5792 in a5780 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_5794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
/* eval.scm: 656  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[121],lf[123],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5648,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5773,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 660  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5771 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 661  ##sys#syntax-error-hook */
t2=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[121],lf[122],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5648(2,t2,C_SCHEME_UNDEFINED);}}

/* k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5648,2,t0,t1);}
t2=*((C_word*)lf[41]+1);
t3=*((C_word*)lf[109]+1);
t4=*((C_word*)lf[42]+1);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5651,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 663  ##sys#register-module */
t6=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5651,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[118]+1);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t7,a[6]=t5,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,((C_word*)t0)[2],t8,t9,t8);}

/* a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5679,2,t0,t1);}
t2=(C_word)C_u_i_cdddr(((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5689(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_5689(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5689,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5699,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 668  reverse */
t5=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5762,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 685  ##sys#current-environment */
t8=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k5768 in loop in a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 682  compile */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3926(t2,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_FALSE,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5760 in loop in a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5762,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 680  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5689(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5697 in loop in a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5702,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5747,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 669  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5745 in k5697 in loop in a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 669  ##sys#finalize-module */
t2=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5700 in k5697 in loop in a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5703,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_5703 in k5700 in k5697 in loop in a5678 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5703,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5709,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5709(t6,t1,((C_word*)t0)[2]);}

/* loop2 */
static void C_fcall f_5709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5709,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,*((C_word*)lf[39]+1));}
else{
t3=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5731,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=t4;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,((C_word*)t0)[2]);}}}

/* k5729 in loop2 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 677  loop2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5709(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap1092 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* g109510961107 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5654 in swap1092 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5659,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g109510961107 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[8])[1]);}

/* k5657 in k5654 in swap1092 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5659,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g109710981108 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5661 in k5657 in k5654 in swap1092 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5666,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g109710981108 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k5664 in k5661 in k5657 in k5654 in swap1092 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5666,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g109911001109 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5668 in k5664 in k5661 in k5657 in k5654 in swap1092 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5673,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g109911001109 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k5671 in k5668 in k5664 in k5661 in k5657 in k5654 in swap1092 in k5649 in k5646 in k5643 in k5637 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5624 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 639  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5588 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_5590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[112]:lf[113]);
/* eval.scm: 615  ##sys#check-syntax */
t3=*((C_word*)lf[55]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,((C_word*)t0)[4],lf[105],((C_word*)t0)[3],t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
/* eval.scm: 621  caadr */
t4=*((C_word*)lf[111]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}
else{
t4=t2;
f_5506(2,t4,(C_word)C_u_i_cadr(((C_word*)t0)[2]));}}

/* k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5509,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5547,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 623  rename */
t5=((C_word*)t0)[3];
f_3758(t5,t4,lf[90],((C_word*)t0)[5]);}
else{
t4=t2;
f_5509(t4,(C_word)C_u_i_caddr(((C_word*)t0)[2]));}}

/* k5545 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5547,2,t0,t1);}
t2=(C_word)C_u_i_cdadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5559,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k5557 in k5545 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
f_5509(t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_5509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5509,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5512,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 625  rename */
t3=((C_word*)t0)[3];
f_3758(t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k5510 in k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 627  ##sys#current-module */
t4=*((C_word*)lf[41]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5535 in k5510 in k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 626  ##sys#register-syntax-export */
t2=*((C_word*)lf[110]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5513 in k5510 in k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 631  ##sys#current-environment */
t4=*((C_word*)lf[109]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5523 in k5513 in k5510 in k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5529,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5533,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 632  eval/meta */
f_3875(t3,((C_word*)t0)[2]);}

/* k5531 in k5523 in k5513 in k5510 in k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 632  ##sys#er-transformer */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5527 in k5523 in k5513 in k5510 in k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 629  ##sys#extend-macro-environment */
t2=*((C_word*)lf[108]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5516 in k5513 in k5510 in k5507 in k5504 in k5501 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 633  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],lf[107],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5467,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t5=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a5466 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5467,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5479,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5483,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 603  eval/meta */
f_3875(t5,t6);}

/* k5481 in a5466 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 602  ##sys#er-transformer */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5477 in a5466 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5479,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],C_SCHEME_FALSE,t1));}

/* k5436 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5441,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 605  append */
t3=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5439 in k5436 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5457,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5456 in k5439 in k5436 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5457,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(t3,C_fix(0),((C_word*)t0)[2]));}

/* k5442 in k5439 in k5436 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 611  ##sys#canonicalize-body */
t4=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k5449 in k5442 in k5439 in k5436 in k5433 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 610  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5380 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5385,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a5401 in k5380 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5402,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5414,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5418,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_cadr(t2);
/* eval.scm: 589  eval/meta */
f_3875(t5,t6);}

/* k5416 in a5401 in k5380 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 588  ##sys#er-transformer */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5412 in a5401 in k5380 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5398 in k5380 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 583  append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5383 in k5380 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5392,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 593  ##sys#canonicalize-body */
t4=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,t1,C_SCHEME_FALSE);}

/* k5390 in k5383 in k5380 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 592  compile */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3926(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5018,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[7];
t9=(C_truep(t8)?t8:lf[92]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5030,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=t10,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5355,a[2]=t11,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 491  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k5353 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5366,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5030(2,t2,C_SCHEME_UNDEFINED);}}

/* a5365 in k5353 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5366,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5359 in k5353 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5360,2,t0,t1);}
/* eval.scm: 494  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[97]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],*((C_word*)lf[48]+1),((C_word*)t0)[2]);}

/* k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5035,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 496  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5035,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5039,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t4,a[10]=t1,a[11]=t3,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[84]+1),t2);}

/* k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5042,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5352,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 500  map */
t4=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[83]+1),((C_word*)t0)[2],t1);}

/* k5350 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 500  append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5042,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5048,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5344,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 504  ##sys#canonicalize-body */
t5=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[2])[1],t1,C_SCHEME_FALSE);}

/* k5342 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[6];
t3=(C_truep(t2)?t2:((C_word*)t0)[5]);
/* eval.scm: 503  ##sys#compile-to-closure */
t4=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
t2=((C_word*)t0)[8];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(1):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(2):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
case C_fix(3):
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp)):(C_truep(((C_word*)t0)[6])?(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp):(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp))));}}

/* f_5306 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5306,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5312,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 573  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5311 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5312r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5312r(t0,t1,t2);}}

static void C_ccall f_5312r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5336,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t5,*((C_word*)lf[93]+1),t2);}
else{
/* eval.scm: 577  ##sys#error */
t5=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[95],((C_word*)t0)[4],t3);}}

/* k5334 in a5311 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5283 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5289,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 566  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5288 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr2r,(void*)f_5289r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5289r(t0,t1,t2);}}

static void C_ccall f_5289r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(14);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5301,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5305,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t6=t4;
f_5305(2,t6,(C_word)C_a_i_list(&a,1,t2));}
else{
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6288,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6288(t9,t4,t5,C_fix(0),t2,C_SCHEME_FALSE);}}

/* doloop1301 in a5288 */
static void C_fcall f_6288(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6288,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t6)){
t7=(C_word)C_a_i_list(&a,1,t4);
t8=(C_word)C_i_setslot(t5,C_fix(1),t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[3]);}
else{
t7=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6317,a[2]=t4,a[3]=t8,a[4]=t7,a[5]=t1,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t4);
if(C_truep(t10)){
/* eval.scm: 763  ##sys#error */
t11=*((C_word*)lf[46]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t9,lf[94],t2,t3);}
else{
t11=t9;
f_6317(2,t11,(C_word)C_slot(t4,C_fix(1)));}}}

/* k6315 in doloop1301 in a5288 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_6288(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5303 in a5288 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[93]+1),t1);}

/* k5299 in a5288 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5261 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5261,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 559  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5266 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5267,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5279,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 561  ##sys#vector */
t7=*((C_word*)lf[93]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t2,t3,t4,t5);}

/* k5277 in a5266 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_5242 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5242,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 554  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5247 */
static void C_ccall f_5248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_5248r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_5248r(t0,t1,t2,t3,t4,t5,t6);}}

static void C_ccall f_5248r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_5214 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5214,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 548  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5219 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5220,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5195 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5195,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 543  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5200 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_5201r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5201r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_5201r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_5167 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5167,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 537  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5172 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5173,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5148 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5148,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 532  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5153 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_5154r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5154r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5154r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_5120 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5120,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 526  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5125 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5126,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_5101 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5101,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 521  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5106 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_5107r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5107r(t0,t1,t2,t3);}}

static void C_ccall f_5107r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_5077 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5077,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5083,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 516  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5082 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5083,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_5058 in k5046 in k5040 in k5037 in a5034 in k5028 in k5016 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5058,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 511  decorate */
f_3869(t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5063 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5064r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5064r(t0,t1,t2);}}

static void C_ccall f_5064r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4927 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4929,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4950,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4998,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 477  ##sys#map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4997 in k4927 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4998,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[88]));}

/* k4948 in k4927 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4976,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 480  ##sys#map */
t5=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a4975 in k4948 in k4927 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4976,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,lf[72],t6));}

/* k4956 in k4948 in k4927 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4974,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4972 in k4956 in k4948 in k4927 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=(C_word)C_a_i_cons(&a,2,lf[77],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4952 in k4948 in k4927 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=(C_word)C_a_i_cons(&a,2,lf[77],t2);
/* eval.scm: 475  compile */
t4=((C_word*)((C_word*)t0)[8])[1];
f_3926(t4,((C_word*)t0)[7],t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4593,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4913,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4912 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4913,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4596,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* map */
t3=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[84]+1),t1);}

/* k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4596,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 426  map */
t5=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[83]+1),((C_word*)t0)[7],t1);}

/* k4909 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 426  append */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4903,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 428  ##sys#canonicalize-body */
t5=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,t1,C_SCHEME_FALSE);}

/* k4901 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 427  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4605,2,t0,t1);}
switch(((C_word*)t0)[10]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4614,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 433  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4648,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 436  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 440  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[8]);
t4=(C_word)C_u_i_car(((C_word*)t0)[7]);
/* eval.scm: 448  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4840,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* map */
t4=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[8]);}}

/* a4886 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4887,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 462  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t1,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4838 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4840,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4841,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4841 in k4838 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4841,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 464  ##sys#make-vector */
t4=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4843 */
static void C_ccall f_4845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4848,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4857(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* doloop851 in k4843 */
static void C_fcall f_4857(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4857,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4882,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4880 in doloop851 in k4843 */
static void C_ccall f_4882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4857(t5,((C_word*)t0)[2],t3,t4);}

/* k4846 in k4843 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4762 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 449  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4765 in k4762 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 451  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3926(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4771 in k4765 in k4762 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4776,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t1,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 452  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4774 in k4771 in k4765 in k4762 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4776,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4777 in k4774 in k4771 in k4765 in k4762 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4777,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4791 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4795 in k4791 */
static void C_ccall f_4797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4799 in k4795 in k4791 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4803 in k4799 in k4795 in k4791 */
static void C_ccall f_4805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4805,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4695 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[10]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 441  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4698 in k4695 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4700,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 443  compile */
t6=((C_word*)((C_word*)t0)[6])[1];
f_3926(t6,t3,t4,((C_word*)t0)[5],t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4704 in k4698 in k4695 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4707 in k4704 in k4698 in k4695 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4707,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4721 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4725 in k4721 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4729 in k4725 in k4721 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4731,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4646 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4651,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cadadr(((C_word*)t0)[8]);
t4=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 437  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t3,((C_word*)t0)[5],t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4649 in k4646 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4652,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4652 in k4649 in k4646 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4652,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4668,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4666 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4672,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4670 in k4666 */
static void C_ccall f_4672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4672,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4612 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4614,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4615,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4615 in k4612 in k4603 in k4600 in k4594 in k4591 in k4582 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4615,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4631,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4629 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4472,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4486,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4486,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4490,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[8]);
/* eval.scm: 399  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3926(t6,t4,t5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4490,2,t0,t1);}
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4547,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4560,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp)));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4499,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 401  ##sys#alias-global-hook */
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_TRUE);}}

/* k4497 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4499,2,t0,t1);}
if(C_truep(*((C_word*)lf[23]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4505,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 403  ##sys#hash-table-location */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[23]+1),t1,*((C_word*)lf[24]+1));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}}

/* f_4532 in k4497 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4532,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4540,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4538 */
static void C_ccall f_4540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4503 in k4497 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4508(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 407  ##sys#error */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[74],((C_word*)t0)[2]);}}

/* k4506 in k4503 in k4497 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4508,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4515,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4524 in k4506 in k4503 in k4497 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
/* eval.scm: 410  ##sys#error */
t2=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[73],((C_word*)t0)[2]);}

/* f_4515 in k4506 in k4503 in k4497 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4515,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4521 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4560 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4560,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4566 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4547 in k4488 in a4485 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4547,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4557 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4479 in k4470 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4480,2,t0,t1);}
/* eval.scm: 398  lookup */
t2=((C_word*)t0)[5];
f_3773(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4360,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 384  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3926(t4,((C_word*)t0)[6],lf[68],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 385  compile */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3926(t5,((C_word*)t0)[6],t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 386  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3926(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4419,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 390  compile */
t6=((C_word*)((C_word*)t0)[7])[1];
f_3926(t6,t4,t5,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4417 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 391  compile */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3926(t4,t2,t3,((C_word*)t0)[6],C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4420 in k4417 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_slot(t4,C_fix(1));
/* ##sys#append */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_SCHEME_END_OF_LIST);}

/* k4442 in k4420 in k4417 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[67],t1);
/* eval.scm: 392  compile */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3926(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4423 in k4420 in k4417 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4426 in k4423 in k4420 in k4417 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4426,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4428 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4431 in k4428 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4395 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4400,a[2]=t1,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 387  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3926(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4398 in k4395 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4401 in k4398 in k4395 in k4358 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4401,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4405,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4403 */
static void C_ccall f_4405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4298 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
/* eval.scm: 372  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3926(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4301 in k4298 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[7]);
/* eval.scm: 373  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3926(t4,t2,t3,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4304 in k4301 in k4298 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4309,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[7]);
/* eval.scm: 375  compile */
t5=((C_word*)((C_word*)t0)[6])[1];
f_3926(t5,t2,t4,((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* eval.scm: 376  compile */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3926(t4,t2,lf[64],((C_word*)t0)[5],C_SCHEME_FALSE,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4307 in k4304 in k4301 in k4298 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4309,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4310 in k4307 in k4304 in k4301 in k4298 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4310,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4315 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4290 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4290,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4256 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4256,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4248 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4250,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4251,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_4251 in k4248 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* f_4234 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 340  ##sys#strip-syntax */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
switch(t1){
case C_fix(-1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4166,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4174,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4182,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4190,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4198,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4206,tmp=(C_word)a,a+=2,tmp));
default:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4214,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=t1,tmp=(C_word)a,a+=3,tmp)));}}

/* f_4216 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4214 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4214(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4214,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4206 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4198 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4190 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4190,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4182 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4174 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4166 in k4157 in k4154 in k4145 in k4130 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4166,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_4110 in k4107 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4099 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4099,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4097 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4086 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4084 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4084,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4076 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4068 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_4060 in k4051 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3952,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4043,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3962,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_u_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4020,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 291  ##sys#get */
t7=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,lf[51]);}
else{
/* eval.scm: 290  ##sys#alias-global-hook */
t6=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_FALSE);}}}

/* k4018 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3962(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3962,2,t0,t1);}
if(C_truep(*((C_word*)lf[23]+1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3968,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 293  ##sys#hash-table-location */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[23]+1),t1,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3991,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3996,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[31]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4011,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 306  ##sys#symbol-has-toplevel-binding? */
t5=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
t4=t3;
f_3996(t4,C_SCHEME_FALSE);}}}

/* k4009 in k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3996(t2,(C_word)C_i_not(t1));}

/* k3994 in k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3996,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t2,*((C_word*)lf[31]+1));
t4=C_mutate((C_word*)lf[31]+1 /* (set! unbound-in-eval ...) */,t3);
t5=((C_word*)t0)[2];
f_3991(t5,t4);}
else{
t2=((C_word*)t0)[2];
f_3991(t2,C_SCHEME_UNDEFINED);}}

/* k3989 in k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3991,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3992,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_3992 in k3989 in k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3992(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3992,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3966 in k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3971(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 294  ##sys#syntax-error-hook */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[49],((C_word*)t0)[2]);}}

/* k3969 in k3966 in k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));}

/* f_3972 in k3969 in k3966 in k3960 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 301  ##sys#error */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[47],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_4043 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4043,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_4034 in a3951 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4034,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3945 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3946,2,t0,t1);}
/* eval.scm: 287  lookup */
t2=((C_word*)t0)[5];
f_3773(t2,t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_3934 in k3931 in compile in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3875(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3875,NULL,2,t1,t2);}
t3=*((C_word*)lf[41]+1);
t4=*((C_word*)lf[42]+1);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3879,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 270  ##sys#meta-macro-environment */
t8=*((C_word*)lf[45]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3880,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t6=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[2],t4,t5,t4);}

/* a3899 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3907,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 274  ##sys#current-meta-environment */
t4=*((C_word*)lf[43]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3909 in a3899 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 271  ##sys#compile-to-closure */
t2=*((C_word*)lf[36]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1);}

/* k3905 in a3899 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* swap489 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* g492493501 */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3882 in swap489 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* g492493501 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[6])[1]);}

/* k3885 in k3882 in swap489 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g494495502 */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3889 in k3885 in k3882 in swap489 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g494495502 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3892 in k3889 in k3885 in k3882 in swap489 in k3877 in eval/meta in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* decorate in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3869(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3869,NULL,5,t1,t2,t3,t4,t5);}
/* eval.scm: 266  ##sys#eval-decorator */
t6=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,t2,t3,t4,t5);}

/* emit-syntax-trace-info in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static C_word C_fcall f_3863(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[40]+1)):C_SCHEME_UNDEFINED));}

/* emit-trace-info in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static C_word C_fcall f_3857(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_truep(t1)?(C_word)C_emit_eval_trace_info(t2,t3,*((C_word*)lf[40]+1)):C_SCHEME_UNDEFINED));}

/* lookup in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3773(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3773,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3777,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 244  rename */
t6=((C_word*)t0)[2];
f_3758(t6,t5,t2,t4);}

/* k3775 in lookup in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3777,2,t0,t1);}
t2=*((C_word*)lf[39]+1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3785,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3785(t6,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* loop in k3775 in lookup in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3785(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3785,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 247  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3827,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3827(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 248  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 249  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in k3775 in lookup in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static C_word C_fcall f_3827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* rename in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3758(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3758,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3762,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 239  find-id */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3719(t5,t4,t2,t3);}

/* k3760 in rename in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3762,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 240  ##sys#get */
t3=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[38]);}}

/* k3766 in k3760 in rename in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* find-id in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3719(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3719,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3732,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caar(t3);
t6=(C_word)C_eqp(t2,t5);
if(C_truep(t6)){
t7=(C_word)C_u_i_cdar(t3);
t8=t4;
f_3732(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t4;
f_3732(t7,C_SCHEME_FALSE);}}}

/* k3730 in find-id in ##sys#compile-to-closure in k3371 in k3368 in k3335 */
static void C_fcall f_3732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_cdar(((C_word*)t0)[4]));}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 236  find-id */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3719(t3,((C_word*)t0)[5],((C_word*)t0)[2],t2);}}

/* ##sys#eval-decorator in k3371 in k3368 in k3335 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3669,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3675,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3688,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 208  ##sys#decorate-lambda */
t8=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t6,t7);}

/* a3687 in ##sys#eval-decorator in k3371 in k3368 in k3335 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3688,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3696,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 215  open-output-string */
t6=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3698 in a3687 in ##sys#eval-decorator in k3371 in k3368 in k3335 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 216  write */
t3=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3701 in k3698 in a3687 in ##sys#eval-decorator in k3371 in k3368 in k3335 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3706,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 217  get-output-string */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3704 in k3701 in k3698 in a3687 in ##sys#eval-decorator in k3371 in k3368 in k3335 */
static void C_ccall f_3706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 214  ##sys#make-lambda-info */
t2=*((C_word*)lf[26]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3694 in a3687 in ##sys#eval-decorator in k3371 in k3368 in k3335 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3674 in ##sys#eval-decorator in k3371 in k3368 in k3335 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3675,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* ##sys#hash-table-location in k3371 in k3368 in k3335 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3609,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3613,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 188  ##sys#hash-symbol */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3611 in ##sys#hash-table-location in k3371 in k3368 in k3335 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3621,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3621(t6,((C_word*)t0)[2],t2);}

/* loop in k3611 in ##sys#hash-table-location in k3371 in k3368 in k3335 */
static void C_fcall f_3621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3621,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 199  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k3371 in k3368 in k3335 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3563,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3569,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3569(t8,t1,C_fix(0));}

/* doloop286 in ##sys#hash-table-for-each in k3371 in k3368 in k3335 */
static void C_fcall f_3569(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3569,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3579,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3588,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 182  ##sys#for-each */
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3587 in doloop286 in ##sys#hash-table-for-each in k3371 in k3368 in k3335 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3588,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 182  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3577 in doloop286 in ##sys#hash-table-for-each in k3371 in k3368 in k3335 */
static void C_ccall f_3579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3569(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-update! in k3371 in k3368 in k3335 */
static void C_ccall f_3543(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3543,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3551,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3555,a[2]=t5,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 176  ##sys#hash-table-ref */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,t3);}

/* k3553 in ##sys#hash-table-update! in k3371 in k3368 in k3335 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3558(2,t3,t1);}
else{
/* eval.scm: 176  valufunc */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3556 in k3553 in ##sys#hash-table-update! in k3371 in k3368 in k3335 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 176  updtfunc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3549 in ##sys#hash-table-update! in k3371 in k3368 in k3335 */
static void C_ccall f_3551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 176  ##sys#hash-table-set! */
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#hash-table-set! in k3371 in k3368 in k3335 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3483,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3487,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 166  ##sys#hash-symbol */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3485 in ##sys#hash-table-set! in k3371 in k3368 in k3335 */
static void C_ccall f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3495,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3495(t6,((C_word*)t0)[2],t2);}

/* loop in k3485 in ##sys#hash-table-set! in k3371 in k3368 in k3335 */
static void C_fcall f_3495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3495,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(0));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t7,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 173  loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}}}

/* ##sys#hash-table-ref in k3371 in k3368 in k3335 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3428,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3481,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 159  ##sys#hash-symbol */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3479 in ##sys#hash-table-ref in k3371 in k3368 in k3335 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3438(t3,t2));}

/* loop in k3479 in ##sys#hash-table-ref in k3371 in k3368 in k3335 */
static C_word C_fcall f_3438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
t2=(C_word)C_eqp(C_SCHEME_END_OF_LIST,t1);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t1,C_fix(0));
return((C_word)C_slot(t6,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t9=t6;
t1=t9;
goto loop;}}}

/* ##sys#hash-symbol in k3371 in k3368 in k3335 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3413,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,(C_word)C_hash_string(t6));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}}

/* chicken-home in k3371 in k3368 in k3335 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 141  ##sys#chicken-prefix */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[14]);}

/* k3403 in chicken-home in k3371 in k3368 in k3335 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}}

/* ##sys#chicken-prefix in k3371 in k3368 in k3335 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3374r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3374r(t0,t1,t2);}}

static void C_ccall f_3374r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(((C_word*)t0)[2])){
if(C_truep(t4)){
/* eval.scm: 135  ##sys#string-append */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,((C_word*)t0)[2],t4);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[2]);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* d in k3335 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3339r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3339r(t0,t1,t2,t3);}}

static void C_ccall f_3339r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_i_nullp(t3))){
/* eval.scm: 38   pp */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
C_apply(5,0,t1,*((C_word*)lf[2]+1),t2,t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[767] = {
{"toplevel:eval_scm",(void*)C_eval_toplevel},
{"f_3337:eval_scm",(void*)f_3337},
{"f_3370:eval_scm",(void*)f_3370},
{"f_3373:eval_scm",(void*)f_3373},
{"f_10231:eval_scm",(void*)f_10231},
{"f_10235:eval_scm",(void*)f_10235},
{"f_10260:eval_scm",(void*)f_10260},
{"f_10250:eval_scm",(void*)f_10250},
{"f_10258:eval_scm",(void*)f_10258},
{"f_10243:eval_scm",(void*)f_10243},
{"f_10241:eval_scm",(void*)f_10241},
{"f_6608:eval_scm",(void*)f_6608},
{"f_6703:eval_scm",(void*)f_6703},
{"f_6784:eval_scm",(void*)f_6784},
{"f_10225:eval_scm",(void*)f_10225},
{"f_10221:eval_scm",(void*)f_10221},
{"f_10217:eval_scm",(void*)f_10217},
{"f_10213:eval_scm",(void*)f_10213},
{"f_10203:eval_scm",(void*)f_10203},
{"f_7312:eval_scm",(void*)f_7312},
{"f_7317:eval_scm",(void*)f_7317},
{"f_10181:eval_scm",(void*)f_10181},
{"f_10173:eval_scm",(void*)f_10173},
{"f_10175:eval_scm",(void*)f_10175},
{"f_7324:eval_scm",(void*)f_7324},
{"f_10142:eval_scm",(void*)f_10142},
{"f_10162:eval_scm",(void*)f_10162},
{"f_10158:eval_scm",(void*)f_10158},
{"f_10148:eval_scm",(void*)f_10148},
{"f_10145:eval_scm",(void*)f_10145},
{"f_7677:eval_scm",(void*)f_7677},
{"f_10088:eval_scm",(void*)f_10088},
{"f_10102:eval_scm",(void*)f_10102},
{"f_10138:eval_scm",(void*)f_10138},
{"f_10134:eval_scm",(void*)f_10134},
{"f_10122:eval_scm",(void*)f_10122},
{"f_10126:eval_scm",(void*)f_10126},
{"f_10096:eval_scm",(void*)f_10096},
{"f_8520:eval_scm",(void*)f_8520},
{"f_9991:eval_scm",(void*)f_9991},
{"f_10028:eval_scm",(void*)f_10028},
{"f_10031:eval_scm",(void*)f_10031},
{"f_10054:eval_scm",(void*)f_10054},
{"f_10058:eval_scm",(void*)f_10058},
{"f_10040:eval_scm",(void*)f_10040},
{"f_10037:eval_scm",(void*)f_10037},
{"f_9994:eval_scm",(void*)f_9994},
{"f_8523:eval_scm",(void*)f_8523},
{"f_8581:eval_scm",(void*)f_8581},
{"f_9989:eval_scm",(void*)f_9989},
{"f_8932:eval_scm",(void*)f_8932},
{"f_8936:eval_scm",(void*)f_8936},
{"f_9985:eval_scm",(void*)f_9985},
{"f_8939:eval_scm",(void*)f_8939},
{"f_8943:eval_scm",(void*)f_8943},
{"f_9210:eval_scm",(void*)f_9210},
{"f_9977:eval_scm",(void*)f_9977},
{"f_9232:eval_scm",(void*)f_9232},
{"f_9595:eval_scm",(void*)f_9595},
{"f_9968:eval_scm",(void*)f_9968},
{"f_9975:eval_scm",(void*)f_9975},
{"f_9958:eval_scm",(void*)f_9958},
{"f_9943:eval_scm",(void*)f_9943},
{"f_9947:eval_scm",(void*)f_9947},
{"f_9952:eval_scm",(void*)f_9952},
{"f_9956:eval_scm",(void*)f_9956},
{"f_9921:eval_scm",(void*)f_9921},
{"f_9925:eval_scm",(void*)f_9925},
{"f_9930:eval_scm",(void*)f_9930},
{"f_9934:eval_scm",(void*)f_9934},
{"f_9941:eval_scm",(void*)f_9941},
{"f_9895:eval_scm",(void*)f_9895},
{"f_9901:eval_scm",(void*)f_9901},
{"f_9905:eval_scm",(void*)f_9905},
{"f_9919:eval_scm",(void*)f_9919},
{"f_9908:eval_scm",(void*)f_9908},
{"f_9915:eval_scm",(void*)f_9915},
{"f_9879:eval_scm",(void*)f_9879},
{"f_9885:eval_scm",(void*)f_9885},
{"f_9893:eval_scm",(void*)f_9893},
{"f_9842:eval_scm",(void*)f_9842},
{"f_9846:eval_scm",(void*)f_9846},
{"f_9851:eval_scm",(void*)f_9851},
{"f_9855:eval_scm",(void*)f_9855},
{"f_9877:eval_scm",(void*)f_9877},
{"f_9873:eval_scm",(void*)f_9873},
{"f_9869:eval_scm",(void*)f_9869},
{"f_9858:eval_scm",(void*)f_9858},
{"f_9865:eval_scm",(void*)f_9865},
{"f_9816:eval_scm",(void*)f_9816},
{"f_9822:eval_scm",(void*)f_9822},
{"f_9826:eval_scm",(void*)f_9826},
{"f_9840:eval_scm",(void*)f_9840},
{"f_9829:eval_scm",(void*)f_9829},
{"f_9836:eval_scm",(void*)f_9836},
{"f_9803:eval_scm",(void*)f_9803},
{"f_9777:eval_scm",(void*)f_9777},
{"f_9781:eval_scm",(void*)f_9781},
{"f_9786:eval_scm",(void*)f_9786},
{"f_9790:eval_scm",(void*)f_9790},
{"f_9801:eval_scm",(void*)f_9801},
{"f_9797:eval_scm",(void*)f_9797},
{"f_9761:eval_scm",(void*)f_9761},
{"f_9767:eval_scm",(void*)f_9767},
{"f_9775:eval_scm",(void*)f_9775},
{"f_9749:eval_scm",(void*)f_9749},
{"f_9755:eval_scm",(void*)f_9755},
{"f_9759:eval_scm",(void*)f_9759},
{"f_9740:eval_scm",(void*)f_9740},
{"f_9744:eval_scm",(void*)f_9744},
{"f_9681:eval_scm",(void*)f_9681},
{"f_9691:eval_scm",(void*)f_9691},
{"f_9716:eval_scm",(void*)f_9716},
{"f_9728:eval_scm",(void*)f_9728},
{"f_9734:eval_scm",(void*)f_9734},
{"f_9722:eval_scm",(void*)f_9722},
{"f_9697:eval_scm",(void*)f_9697},
{"f_9703:eval_scm",(void*)f_9703},
{"f_9707:eval_scm",(void*)f_9707},
{"f_9710:eval_scm",(void*)f_9710},
{"f_9714:eval_scm",(void*)f_9714},
{"f_9689:eval_scm",(void*)f_9689},
{"f_9606:eval_scm",(void*)f_9606},
{"f_9616:eval_scm",(void*)f_9616},
{"f_9619:eval_scm",(void*)f_9619},
{"f_9633:eval_scm",(void*)f_9633},
{"f_9651:eval_scm",(void*)f_9651},
{"f_9620:eval_scm",(void*)f_9620},
{"f_9597:eval_scm",(void*)f_9597},
{"f_9253:eval_scm",(void*)f_9253},
{"f_9297:eval_scm",(void*)f_9297},
{"f_9300:eval_scm",(void*)f_9300},
{"f_9580:eval_scm",(void*)f_9580},
{"f_9584:eval_scm",(void*)f_9584},
{"f_9588:eval_scm",(void*)f_9588},
{"f_9382:eval_scm",(void*)f_9382},
{"f_9388:eval_scm",(void*)f_9388},
{"f_9563:eval_scm",(void*)f_9563},
{"f_9569:eval_scm",(void*)f_9569},
{"f_9395:eval_scm",(void*)f_9395},
{"f_9398:eval_scm",(void*)f_9398},
{"f_9401:eval_scm",(void*)f_9401},
{"f_9558:eval_scm",(void*)f_9558},
{"f_9410:eval_scm",(void*)f_9410},
{"f_9413:eval_scm",(void*)f_9413},
{"f_9428:eval_scm",(void*)f_9428},
{"f_9446:eval_scm",(void*)f_9446},
{"f_9512:eval_scm",(void*)f_9512},
{"f_9462:eval_scm",(void*)f_9462},
{"f_9470:eval_scm",(void*)f_9470},
{"f_9474:eval_scm",(void*)f_9474},
{"f_9477:eval_scm",(void*)f_9477},
{"f_9489:eval_scm",(void*)f_9489},
{"f_9492:eval_scm",(void*)f_9492},
{"f_9480:eval_scm",(void*)f_9480},
{"f_9465:eval_scm",(void*)f_9465},
{"f_9450:eval_scm",(void*)f_9450},
{"f_9432:eval_scm",(void*)f_9432},
{"f_9278:eval_scm",(void*)f_9278},
{"f_9283:eval_scm",(void*)f_9283},
{"f_9435:eval_scm",(void*)f_9435},
{"f_9419:eval_scm",(void*)f_9419},
{"f_9317:eval_scm",(void*)f_9317},
{"f_9322:eval_scm",(void*)f_9322},
{"f_9325:eval_scm",(void*)f_9325},
{"f_9330:eval_scm",(void*)f_9330},
{"f_9337:eval_scm",(void*)f_9337},
{"f_9377:eval_scm",(void*)f_9377},
{"f_9340:eval_scm",(void*)f_9340},
{"f_9352:eval_scm",(void*)f_9352},
{"f_9361:eval_scm",(void*)f_9361},
{"f_9355:eval_scm",(void*)f_9355},
{"f_9343:eval_scm",(void*)f_9343},
{"f_9346:eval_scm",(void*)f_9346},
{"f_9308:eval_scm",(void*)f_9308},
{"f_9302:eval_scm",(void*)f_9302},
{"f_9256:eval_scm",(void*)f_9256},
{"f_9262:eval_scm",(void*)f_9262},
{"f_9250:eval_scm",(void*)f_9250},
{"f_9234:eval_scm",(void*)f_9234},
{"f_9248:eval_scm",(void*)f_9248},
{"f_9245:eval_scm",(void*)f_9245},
{"f_9238:eval_scm",(void*)f_9238},
{"f_9215:eval_scm",(void*)f_9215},
{"f_9224:eval_scm",(void*)f_9224},
{"f_9219:eval_scm",(void*)f_9219},
{"f_9155:eval_scm",(void*)f_9155},
{"f_9159:eval_scm",(void*)f_9159},
{"f_9162:eval_scm",(void*)f_9162},
{"f_9165:eval_scm",(void*)f_9165},
{"f_9168:eval_scm",(void*)f_9168},
{"f_9171:eval_scm",(void*)f_9171},
{"f_9174:eval_scm",(void*)f_9174},
{"f_9177:eval_scm",(void*)f_9177},
{"f_9180:eval_scm",(void*)f_9180},
{"f_9183:eval_scm",(void*)f_9183},
{"f_9134:eval_scm",(void*)f_9134},
{"f_9138:eval_scm",(void*)f_9138},
{"f_9141:eval_scm",(void*)f_9141},
{"f_9110:eval_scm",(void*)f_9110},
{"f_9116:eval_scm",(void*)f_9116},
{"f_9126:eval_scm",(void*)f_9126},
{"f_8968:eval_scm",(void*)f_8968},
{"f_9039:eval_scm",(void*)f_9039},
{"f_9086:eval_scm",(void*)f_9086},
{"f_9096:eval_scm",(void*)f_9096},
{"f_9089:eval_scm",(void*)f_9089},
{"f_9049:eval_scm",(void*)f_9049},
{"f_9051:eval_scm",(void*)f_9051},
{"f_9075:eval_scm",(void*)f_9075},
{"f_9061:eval_scm",(void*)f_9061},
{"f_9009:eval_scm",(void*)f_9009},
{"f_8974:eval_scm",(void*)f_8974},
{"f_8990:eval_scm",(void*)f_8990},
{"f_8996:eval_scm",(void*)f_8996},
{"f_8987:eval_scm",(void*)f_8987},
{"f_8949:eval_scm",(void*)f_8949},
{"f_8953:eval_scm",(void*)f_8953},
{"f_8916:eval_scm",(void*)f_8916},
{"f_8918:eval_scm",(void*)f_8918},
{"f_8922:eval_scm",(void*)f_8922},
{"f_8878:eval_scm",(void*)f_8878},
{"f_8885:eval_scm",(void*)f_8885},
{"f_8892:eval_scm",(void*)f_8892},
{"f_8834:eval_scm",(void*)f_8834},
{"f_8867:eval_scm",(void*)f_8867},
{"f_8854:eval_scm",(void*)f_8854},
{"f_8831:eval_scm",(void*)f_8831},
{"f_8712:eval_scm",(void*)f_8712},
{"f_8806:eval_scm",(void*)f_8806},
{"f_8816:eval_scm",(void*)f_8816},
{"f_8804:eval_scm",(void*)f_8804},
{"f_8733:eval_scm",(void*)f_8733},
{"f_8757:eval_scm",(void*)f_8757},
{"f_8776:eval_scm",(void*)f_8776},
{"f_8751:eval_scm",(void*)f_8751},
{"f_8604:eval_scm",(void*)f_8604},
{"f_8614:eval_scm",(void*)f_8614},
{"f_8619:eval_scm",(void*)f_8619},
{"f_8646:eval_scm",(void*)f_8646},
{"f_8679:eval_scm",(void*)f_8679},
{"f_8640:eval_scm",(void*)f_8640},
{"f_8588:eval_scm",(void*)f_8588},
{"f_8525:eval_scm",(void*)f_8525},
{"f_8529:eval_scm",(void*)f_8529},
{"f_8537:eval_scm",(void*)f_8537},
{"f_8557:eval_scm",(void*)f_8557},
{"f_8481:eval_scm",(void*)f_8481},
{"f_8513:eval_scm",(void*)f_8513},
{"f_8499:eval_scm",(void*)f_8499},
{"f_7974:eval_scm",(void*)f_7974},
{"f_8349:eval_scm",(void*)f_8349},
{"f_8358:eval_scm",(void*)f_8358},
{"f_8388:eval_scm",(void*)f_8388},
{"f_8390:eval_scm",(void*)f_8390},
{"f_8427:eval_scm",(void*)f_8427},
{"f_8417:eval_scm",(void*)f_8417},
{"f_8412:eval_scm",(void*)f_8412},
{"f_8408:eval_scm",(void*)f_8408},
{"f_8043:eval_scm",(void*)f_8043},
{"f_8053:eval_scm",(void*)f_8053},
{"f_8206:eval_scm",(void*)f_8206},
{"f_8311:eval_scm",(void*)f_8311},
{"f_8318:eval_scm",(void*)f_8318},
{"f_8218:eval_scm",(void*)f_8218},
{"f_8237:eval_scm",(void*)f_8237},
{"f_8265:eval_scm",(void*)f_8265},
{"f_8263:eval_scm",(void*)f_8263},
{"f_8259:eval_scm",(void*)f_8259},
{"f_8245:eval_scm",(void*)f_8245},
{"f_8241:eval_scm",(void*)f_8241},
{"f_8233:eval_scm",(void*)f_8233},
{"f_8225:eval_scm",(void*)f_8225},
{"f_8120:eval_scm",(void*)f_8120},
{"f_8138:eval_scm",(void*)f_8138},
{"f_8150:eval_scm",(void*)f_8150},
{"f_8146:eval_scm",(void*)f_8146},
{"f_8134:eval_scm",(void*)f_8134},
{"f_8077:eval_scm",(void*)f_8077},
{"f_8073:eval_scm",(void*)f_8073},
{"f_8060:eval_scm",(void*)f_8060},
{"f_8002:eval_scm",(void*)f_8002},
{"f_8021:eval_scm",(void*)f_8021},
{"f_8018:eval_scm",(void*)f_8018},
{"f_8014:eval_scm",(void*)f_8014},
{"f_7977:eval_scm",(void*)f_7977},
{"f_7996:eval_scm",(void*)f_7996},
{"f_7990:eval_scm",(void*)f_7990},
{"f_7925:eval_scm",(void*)f_7925},
{"f_7931:eval_scm",(void*)f_7931},
{"f_7945:eval_scm",(void*)f_7945},
{"f_7948:eval_scm",(void*)f_7948},
{"f_7955:eval_scm",(void*)f_7955},
{"f_7919:eval_scm",(void*)f_7919},
{"f_7886:eval_scm",(void*)f_7886},
{"f_7890:eval_scm",(void*)f_7890},
{"f_7896:eval_scm",(void*)f_7896},
{"f_7899:eval_scm",(void*)f_7899},
{"f_7917:eval_scm",(void*)f_7917},
{"f_7902:eval_scm",(void*)f_7902},
{"f_7909:eval_scm",(void*)f_7909},
{"f_7873:eval_scm",(void*)f_7873},
{"f_7879:eval_scm",(void*)f_7879},
{"f_7859:eval_scm",(void*)f_7859},
{"f_7870:eval_scm",(void*)f_7870},
{"f_7839:eval_scm",(void*)f_7839},
{"f_7845:eval_scm",(void*)f_7845},
{"f_7852:eval_scm",(void*)f_7852},
{"f_7771:eval_scm",(void*)f_7771},
{"f_7834:eval_scm",(void*)f_7834},
{"f_7775:eval_scm",(void*)f_7775},
{"f_7778:eval_scm",(void*)f_7778},
{"f_7796:eval_scm",(void*)f_7796},
{"f_7802:eval_scm",(void*)f_7802},
{"f_7680:eval_scm",(void*)f_7680},
{"f_7684:eval_scm",(void*)f_7684},
{"f_7732:eval_scm",(void*)f_7732},
{"f_7734:eval_scm",(void*)f_7734},
{"f_7747:eval_scm",(void*)f_7747},
{"f_7686:eval_scm",(void*)f_7686},
{"f_7690:eval_scm",(void*)f_7690},
{"f_7725:eval_scm",(void*)f_7725},
{"f_7696:eval_scm",(void*)f_7696},
{"f_7706:eval_scm",(void*)f_7706},
{"f_7699:eval_scm",(void*)f_7699},
{"f_7517:eval_scm",(void*)f_7517},
{"f_7622:eval_scm",(void*)f_7622},
{"f_7639:eval_scm",(void*)f_7639},
{"f_7647:eval_scm",(void*)f_7647},
{"f_7539:eval_scm",(void*)f_7539},
{"f_7544:eval_scm",(void*)f_7544},
{"f_7583:eval_scm",(void*)f_7583},
{"f_7570:eval_scm",(void*)f_7570},
{"f_7526:eval_scm",(void*)f_7526},
{"f_7520:eval_scm",(void*)f_7520},
{"f_7432:eval_scm",(void*)f_7432},
{"f_7439:eval_scm",(void*)f_7439},
{"f_7449:eval_scm",(void*)f_7449},
{"f_7326:eval_scm",(void*)f_7326},
{"f_7330:eval_scm",(void*)f_7330},
{"f_7422:eval_scm",(void*)f_7422},
{"f_7426:eval_scm",(void*)f_7426},
{"f_7339:eval_scm",(void*)f_7339},
{"f_7408:eval_scm",(void*)f_7408},
{"f_7404:eval_scm",(void*)f_7404},
{"f_7342:eval_scm",(void*)f_7342},
{"f_7391:eval_scm",(void*)f_7391},
{"f_7394:eval_scm",(void*)f_7394},
{"f_7397:eval_scm",(void*)f_7397},
{"f_7345:eval_scm",(void*)f_7345},
{"f_7350:eval_scm",(void*)f_7350},
{"f_7384:eval_scm",(void*)f_7384},
{"f_7363:eval_scm",(void*)f_7363},
{"f_7366:eval_scm",(void*)f_7366},
{"f_7286:eval_scm",(void*)f_7286},
{"f_7307:eval_scm",(void*)f_7307},
{"f_7290:eval_scm",(void*)f_7290},
{"f_7304:eval_scm",(void*)f_7304},
{"f_7293:eval_scm",(void*)f_7293},
{"f_7301:eval_scm",(void*)f_7301},
{"f_7296:eval_scm",(void*)f_7296},
{"f_7250:eval_scm",(void*)f_7250},
{"f_7258:eval_scm",(void*)f_7258},
{"f_7228:eval_scm",(void*)f_7228},
{"f_6832:eval_scm",(void*)f_6832},
{"f_7183:eval_scm",(void*)f_7183},
{"f_7178:eval_scm",(void*)f_7178},
{"f_6834:eval_scm",(void*)f_6834},
{"f_7177:eval_scm",(void*)f_7177},
{"f_6838:eval_scm",(void*)f_6838},
{"f_7099:eval_scm",(void*)f_7099},
{"f_7114:eval_scm",(void*)f_7114},
{"f_7117:eval_scm",(void*)f_7117},
{"f_7120:eval_scm",(void*)f_7120},
{"f_7126:eval_scm",(void*)f_7126},
{"f_7129:eval_scm",(void*)f_7129},
{"f_7135:eval_scm",(void*)f_7135},
{"f_6841:eval_scm",(void*)f_6841},
{"f_7090:eval_scm",(void*)f_7090},
{"f_7078:eval_scm",(void*)f_7078},
{"f_7081:eval_scm",(void*)f_7081},
{"f_7084:eval_scm",(void*)f_7084},
{"f_6847:eval_scm",(void*)f_6847},
{"f_7063:eval_scm",(void*)f_7063},
{"f_7035:eval_scm",(void*)f_7035},
{"f_7059:eval_scm",(void*)f_7059},
{"f_7055:eval_scm",(void*)f_7055},
{"f_7051:eval_scm",(void*)f_7051},
{"f_6850:eval_scm",(void*)f_6850},
{"f_6858:eval_scm",(void*)f_6858},
{"f_7022:eval_scm",(void*)f_7022},
{"f_6862:eval_scm",(void*)f_6862},
{"f_7010:eval_scm",(void*)f_7010},
{"f_6883:eval_scm",(void*)f_6883},
{"f_6887:eval_scm",(void*)f_6887},
{"f_7001:eval_scm",(void*)f_7001},
{"f_6895:eval_scm",(void*)f_6895},
{"f_6899:eval_scm",(void*)f_6899},
{"f_6995:eval_scm",(void*)f_6995},
{"f_6902:eval_scm",(void*)f_6902},
{"f_6905:eval_scm",(void*)f_6905},
{"f_6910:eval_scm",(void*)f_6910},
{"f_6920:eval_scm",(void*)f_6920},
{"f_6966:eval_scm",(void*)f_6966},
{"f_6975:eval_scm",(void*)f_6975},
{"f_6979:eval_scm",(void*)f_6979},
{"f_6932:eval_scm",(void*)f_6932},
{"f_6939:eval_scm",(void*)f_6939},
{"f_6950:eval_scm",(void*)f_6950},
{"f_6961:eval_scm",(void*)f_6961},
{"f_6954:eval_scm",(void*)f_6954},
{"f_6944:eval_scm",(void*)f_6944},
{"f_6923:eval_scm",(void*)f_6923},
{"f_6930:eval_scm",(void*)f_6930},
{"f_6892:eval_scm",(void*)f_6892},
{"f_6872:eval_scm",(void*)f_6872},
{"f_6863:eval_scm",(void*)f_6863},
{"f_6853:eval_scm",(void*)f_6853},
{"f_6786:eval_scm",(void*)f_6786},
{"f_6796:eval_scm",(void*)f_6796},
{"f_6711:eval_scm",(void*)f_6711},
{"f_6723:eval_scm",(void*)f_6723},
{"f_6736:eval_scm",(void*)f_6736},
{"f_6718:eval_scm",(void*)f_6718},
{"f_6705:eval_scm",(void*)f_6705},
{"f_6621:eval_scm",(void*)f_6621},
{"f_6634:eval_scm",(void*)f_6634},
{"f_6667:eval_scm",(void*)f_6667},
{"f_6648:eval_scm",(void*)f_6648},
{"f_6624:eval_scm",(void*)f_6624},
{"f_6611:eval_scm",(void*)f_6611},
{"f_6619:eval_scm",(void*)f_6619},
{"f_3713:eval_scm",(void*)f_3713},
{"f_6360:eval_scm",(void*)f_6360},
{"f_6364:eval_scm",(void*)f_6364},
{"f_6577:eval_scm",(void*)f_6577},
{"f_6553:eval_scm",(void*)f_6553},
{"f_6554:eval_scm",(void*)f_6554},
{"f_6565:eval_scm",(void*)f_6565},
{"f_6571:eval_scm",(void*)f_6571},
{"f_6569:eval_scm",(void*)f_6569},
{"f_6510:eval_scm",(void*)f_6510},
{"f_6513:eval_scm",(void*)f_6513},
{"f_6516:eval_scm",(void*)f_6516},
{"f_6519:eval_scm",(void*)f_6519},
{"f_6520:eval_scm",(void*)f_6520},
{"f_6531:eval_scm",(void*)f_6531},
{"f_6535:eval_scm",(void*)f_6535},
{"f_6539:eval_scm",(void*)f_6539},
{"f_6543:eval_scm",(void*)f_6543},
{"f_6546:eval_scm",(void*)f_6546},
{"f_6468:eval_scm",(void*)f_6468},
{"f_6471:eval_scm",(void*)f_6471},
{"f_6474:eval_scm",(void*)f_6474},
{"f_6475:eval_scm",(void*)f_6475},
{"f_6486:eval_scm",(void*)f_6486},
{"f_6490:eval_scm",(void*)f_6490},
{"f_6494:eval_scm",(void*)f_6494},
{"f_6497:eval_scm",(void*)f_6497},
{"f_6433:eval_scm",(void*)f_6433},
{"f_6436:eval_scm",(void*)f_6436},
{"f_6437:eval_scm",(void*)f_6437},
{"f_6448:eval_scm",(void*)f_6448},
{"f_6452:eval_scm",(void*)f_6452},
{"f_6455:eval_scm",(void*)f_6455},
{"f_6405:eval_scm",(void*)f_6405},
{"f_6406:eval_scm",(void*)f_6406},
{"f_6417:eval_scm",(void*)f_6417},
{"f_6420:eval_scm",(void*)f_6420},
{"f_6386:eval_scm",(void*)f_6386},
{"f_6396:eval_scm",(void*)f_6396},
{"f_6334:eval_scm",(void*)f_6334},
{"f_3926:eval_scm",(void*)f_3926},
{"f_3933:eval_scm",(void*)f_3933},
{"f_4053:eval_scm",(void*)f_4053},
{"f_4109:eval_scm",(void*)f_4109},
{"f_4132:eval_scm",(void*)f_4132},
{"f_4147:eval_scm",(void*)f_4147},
{"f_6131:eval_scm",(void*)f_6131},
{"f_6114:eval_scm",(void*)f_6114},
{"f_6118:eval_scm",(void*)f_6118},
{"f_6083:eval_scm",(void*)f_6083},
{"f_6072:eval_scm",(void*)f_6072},
{"f_6031:eval_scm",(void*)f_6031},
{"f_5977:eval_scm",(void*)f_5977},
{"f_5999:eval_scm",(void*)f_5999},
{"f_6015:eval_scm",(void*)f_6015},
{"f_5989:eval_scm",(void*)f_5989},
{"f_5971:eval_scm",(void*)f_5971},
{"f_5947:eval_scm",(void*)f_5947},
{"f_5908:eval_scm",(void*)f_5908},
{"f_5911:eval_scm",(void*)f_5911},
{"f_5914:eval_scm",(void*)f_5914},
{"f_5937:eval_scm",(void*)f_5937},
{"f_5935:eval_scm",(void*)f_5935},
{"f_5931:eval_scm",(void*)f_5931},
{"f_5921:eval_scm",(void*)f_5921},
{"f_5891:eval_scm",(void*)f_5891},
{"f_5895:eval_scm",(void*)f_5895},
{"f_5862:eval_scm",(void*)f_5862},
{"f_5866:eval_scm",(void*)f_5866},
{"f_5639:eval_scm",(void*)f_5639},
{"f_5833:eval_scm",(void*)f_5833},
{"f_5781:eval_scm",(void*)f_5781},
{"f_5805:eval_scm",(void*)f_5805},
{"f_5794:eval_scm",(void*)f_5794},
{"f_5645:eval_scm",(void*)f_5645},
{"f_5773:eval_scm",(void*)f_5773},
{"f_5648:eval_scm",(void*)f_5648},
{"f_5651:eval_scm",(void*)f_5651},
{"f_5679:eval_scm",(void*)f_5679},
{"f_5689:eval_scm",(void*)f_5689},
{"f_5770:eval_scm",(void*)f_5770},
{"f_5762:eval_scm",(void*)f_5762},
{"f_5699:eval_scm",(void*)f_5699},
{"f_5747:eval_scm",(void*)f_5747},
{"f_5702:eval_scm",(void*)f_5702},
{"f_5703:eval_scm",(void*)f_5703},
{"f_5709:eval_scm",(void*)f_5709},
{"f_5731:eval_scm",(void*)f_5731},
{"f_5652:eval_scm",(void*)f_5652},
{"f_5656:eval_scm",(void*)f_5656},
{"f_5659:eval_scm",(void*)f_5659},
{"f_5663:eval_scm",(void*)f_5663},
{"f_5666:eval_scm",(void*)f_5666},
{"f_5670:eval_scm",(void*)f_5670},
{"f_5673:eval_scm",(void*)f_5673},
{"f_5626:eval_scm",(void*)f_5626},
{"f_5590:eval_scm",(void*)f_5590},
{"f_5503:eval_scm",(void*)f_5503},
{"f_5506:eval_scm",(void*)f_5506},
{"f_5547:eval_scm",(void*)f_5547},
{"f_5559:eval_scm",(void*)f_5559},
{"f_5509:eval_scm",(void*)f_5509},
{"f_5512:eval_scm",(void*)f_5512},
{"f_5537:eval_scm",(void*)f_5537},
{"f_5515:eval_scm",(void*)f_5515},
{"f_5525:eval_scm",(void*)f_5525},
{"f_5533:eval_scm",(void*)f_5533},
{"f_5529:eval_scm",(void*)f_5529},
{"f_5518:eval_scm",(void*)f_5518},
{"f_5435:eval_scm",(void*)f_5435},
{"f_5467:eval_scm",(void*)f_5467},
{"f_5483:eval_scm",(void*)f_5483},
{"f_5479:eval_scm",(void*)f_5479},
{"f_5438:eval_scm",(void*)f_5438},
{"f_5441:eval_scm",(void*)f_5441},
{"f_5457:eval_scm",(void*)f_5457},
{"f_5444:eval_scm",(void*)f_5444},
{"f_5451:eval_scm",(void*)f_5451},
{"f_5382:eval_scm",(void*)f_5382},
{"f_5402:eval_scm",(void*)f_5402},
{"f_5418:eval_scm",(void*)f_5418},
{"f_5414:eval_scm",(void*)f_5414},
{"f_5400:eval_scm",(void*)f_5400},
{"f_5385:eval_scm",(void*)f_5385},
{"f_5392:eval_scm",(void*)f_5392},
{"f_5018:eval_scm",(void*)f_5018},
{"f_5355:eval_scm",(void*)f_5355},
{"f_5366:eval_scm",(void*)f_5366},
{"f_5360:eval_scm",(void*)f_5360},
{"f_5030:eval_scm",(void*)f_5030},
{"f_5035:eval_scm",(void*)f_5035},
{"f_5039:eval_scm",(void*)f_5039},
{"f_5352:eval_scm",(void*)f_5352},
{"f_5042:eval_scm",(void*)f_5042},
{"f_5344:eval_scm",(void*)f_5344},
{"f_5048:eval_scm",(void*)f_5048},
{"f_5306:eval_scm",(void*)f_5306},
{"f_5312:eval_scm",(void*)f_5312},
{"f_5336:eval_scm",(void*)f_5336},
{"f_5283:eval_scm",(void*)f_5283},
{"f_5289:eval_scm",(void*)f_5289},
{"f_6288:eval_scm",(void*)f_6288},
{"f_6317:eval_scm",(void*)f_6317},
{"f_5305:eval_scm",(void*)f_5305},
{"f_5301:eval_scm",(void*)f_5301},
{"f_5261:eval_scm",(void*)f_5261},
{"f_5267:eval_scm",(void*)f_5267},
{"f_5279:eval_scm",(void*)f_5279},
{"f_5242:eval_scm",(void*)f_5242},
{"f_5248:eval_scm",(void*)f_5248},
{"f_5214:eval_scm",(void*)f_5214},
{"f_5220:eval_scm",(void*)f_5220},
{"f_5195:eval_scm",(void*)f_5195},
{"f_5201:eval_scm",(void*)f_5201},
{"f_5167:eval_scm",(void*)f_5167},
{"f_5173:eval_scm",(void*)f_5173},
{"f_5148:eval_scm",(void*)f_5148},
{"f_5154:eval_scm",(void*)f_5154},
{"f_5120:eval_scm",(void*)f_5120},
{"f_5126:eval_scm",(void*)f_5126},
{"f_5101:eval_scm",(void*)f_5101},
{"f_5107:eval_scm",(void*)f_5107},
{"f_5077:eval_scm",(void*)f_5077},
{"f_5083:eval_scm",(void*)f_5083},
{"f_5058:eval_scm",(void*)f_5058},
{"f_5064:eval_scm",(void*)f_5064},
{"f_4929:eval_scm",(void*)f_4929},
{"f_4998:eval_scm",(void*)f_4998},
{"f_4950:eval_scm",(void*)f_4950},
{"f_4976:eval_scm",(void*)f_4976},
{"f_4958:eval_scm",(void*)f_4958},
{"f_4974:eval_scm",(void*)f_4974},
{"f_4954:eval_scm",(void*)f_4954},
{"f_4584:eval_scm",(void*)f_4584},
{"f_4913:eval_scm",(void*)f_4913},
{"f_4593:eval_scm",(void*)f_4593},
{"f_4596:eval_scm",(void*)f_4596},
{"f_4911:eval_scm",(void*)f_4911},
{"f_4602:eval_scm",(void*)f_4602},
{"f_4903:eval_scm",(void*)f_4903},
{"f_4605:eval_scm",(void*)f_4605},
{"f_4887:eval_scm",(void*)f_4887},
{"f_4840:eval_scm",(void*)f_4840},
{"f_4841:eval_scm",(void*)f_4841},
{"f_4845:eval_scm",(void*)f_4845},
{"f_4857:eval_scm",(void*)f_4857},
{"f_4882:eval_scm",(void*)f_4882},
{"f_4848:eval_scm",(void*)f_4848},
{"f_4764:eval_scm",(void*)f_4764},
{"f_4767:eval_scm",(void*)f_4767},
{"f_4773:eval_scm",(void*)f_4773},
{"f_4776:eval_scm",(void*)f_4776},
{"f_4777:eval_scm",(void*)f_4777},
{"f_4793:eval_scm",(void*)f_4793},
{"f_4797:eval_scm",(void*)f_4797},
{"f_4801:eval_scm",(void*)f_4801},
{"f_4805:eval_scm",(void*)f_4805},
{"f_4697:eval_scm",(void*)f_4697},
{"f_4700:eval_scm",(void*)f_4700},
{"f_4706:eval_scm",(void*)f_4706},
{"f_4707:eval_scm",(void*)f_4707},
{"f_4723:eval_scm",(void*)f_4723},
{"f_4727:eval_scm",(void*)f_4727},
{"f_4731:eval_scm",(void*)f_4731},
{"f_4648:eval_scm",(void*)f_4648},
{"f_4651:eval_scm",(void*)f_4651},
{"f_4652:eval_scm",(void*)f_4652},
{"f_4668:eval_scm",(void*)f_4668},
{"f_4672:eval_scm",(void*)f_4672},
{"f_4614:eval_scm",(void*)f_4614},
{"f_4615:eval_scm",(void*)f_4615},
{"f_4631:eval_scm",(void*)f_4631},
{"f_4472:eval_scm",(void*)f_4472},
{"f_4486:eval_scm",(void*)f_4486},
{"f_4490:eval_scm",(void*)f_4490},
{"f_4499:eval_scm",(void*)f_4499},
{"f_4532:eval_scm",(void*)f_4532},
{"f_4540:eval_scm",(void*)f_4540},
{"f_4505:eval_scm",(void*)f_4505},
{"f_4508:eval_scm",(void*)f_4508},
{"f_4524:eval_scm",(void*)f_4524},
{"f_4515:eval_scm",(void*)f_4515},
{"f_4523:eval_scm",(void*)f_4523},
{"f_4560:eval_scm",(void*)f_4560},
{"f_4568:eval_scm",(void*)f_4568},
{"f_4547:eval_scm",(void*)f_4547},
{"f_4559:eval_scm",(void*)f_4559},
{"f_4480:eval_scm",(void*)f_4480},
{"f_4360:eval_scm",(void*)f_4360},
{"f_4419:eval_scm",(void*)f_4419},
{"f_4422:eval_scm",(void*)f_4422},
{"f_4444:eval_scm",(void*)f_4444},
{"f_4425:eval_scm",(void*)f_4425},
{"f_4426:eval_scm",(void*)f_4426},
{"f_4430:eval_scm",(void*)f_4430},
{"f_4433:eval_scm",(void*)f_4433},
{"f_4397:eval_scm",(void*)f_4397},
{"f_4400:eval_scm",(void*)f_4400},
{"f_4401:eval_scm",(void*)f_4401},
{"f_4405:eval_scm",(void*)f_4405},
{"f_4300:eval_scm",(void*)f_4300},
{"f_4303:eval_scm",(void*)f_4303},
{"f_4306:eval_scm",(void*)f_4306},
{"f_4309:eval_scm",(void*)f_4309},
{"f_4310:eval_scm",(void*)f_4310},
{"f_4317:eval_scm",(void*)f_4317},
{"f_4290:eval_scm",(void*)f_4290},
{"f_4256:eval_scm",(void*)f_4256},
{"f_4250:eval_scm",(void*)f_4250},
{"f_4251:eval_scm",(void*)f_4251},
{"f_4234:eval_scm",(void*)f_4234},
{"f_4156:eval_scm",(void*)f_4156},
{"f_4159:eval_scm",(void*)f_4159},
{"f_4216:eval_scm",(void*)f_4216},
{"f_4214:eval_scm",(void*)f_4214},
{"f_4206:eval_scm",(void*)f_4206},
{"f_4198:eval_scm",(void*)f_4198},
{"f_4190:eval_scm",(void*)f_4190},
{"f_4182:eval_scm",(void*)f_4182},
{"f_4174:eval_scm",(void*)f_4174},
{"f_4166:eval_scm",(void*)f_4166},
{"f_4110:eval_scm",(void*)f_4110},
{"f_4099:eval_scm",(void*)f_4099},
{"f_4097:eval_scm",(void*)f_4097},
{"f_4086:eval_scm",(void*)f_4086},
{"f_4084:eval_scm",(void*)f_4084},
{"f_4076:eval_scm",(void*)f_4076},
{"f_4068:eval_scm",(void*)f_4068},
{"f_4060:eval_scm",(void*)f_4060},
{"f_3952:eval_scm",(void*)f_3952},
{"f_4020:eval_scm",(void*)f_4020},
{"f_3962:eval_scm",(void*)f_3962},
{"f_4011:eval_scm",(void*)f_4011},
{"f_3996:eval_scm",(void*)f_3996},
{"f_3991:eval_scm",(void*)f_3991},
{"f_3992:eval_scm",(void*)f_3992},
{"f_3968:eval_scm",(void*)f_3968},
{"f_3971:eval_scm",(void*)f_3971},
{"f_3972:eval_scm",(void*)f_3972},
{"f_4043:eval_scm",(void*)f_4043},
{"f_4034:eval_scm",(void*)f_4034},
{"f_3946:eval_scm",(void*)f_3946},
{"f_3934:eval_scm",(void*)f_3934},
{"f_3875:eval_scm",(void*)f_3875},
{"f_3879:eval_scm",(void*)f_3879},
{"f_3900:eval_scm",(void*)f_3900},
{"f_3911:eval_scm",(void*)f_3911},
{"f_3907:eval_scm",(void*)f_3907},
{"f_3880:eval_scm",(void*)f_3880},
{"f_3884:eval_scm",(void*)f_3884},
{"f_3887:eval_scm",(void*)f_3887},
{"f_3891:eval_scm",(void*)f_3891},
{"f_3894:eval_scm",(void*)f_3894},
{"f_3869:eval_scm",(void*)f_3869},
{"f_3863:eval_scm",(void*)f_3863},
{"f_3857:eval_scm",(void*)f_3857},
{"f_3773:eval_scm",(void*)f_3773},
{"f_3777:eval_scm",(void*)f_3777},
{"f_3785:eval_scm",(void*)f_3785},
{"f_3827:eval_scm",(void*)f_3827},
{"f_3758:eval_scm",(void*)f_3758},
{"f_3762:eval_scm",(void*)f_3762},
{"f_3768:eval_scm",(void*)f_3768},
{"f_3719:eval_scm",(void*)f_3719},
{"f_3732:eval_scm",(void*)f_3732},
{"f_3669:eval_scm",(void*)f_3669},
{"f_3688:eval_scm",(void*)f_3688},
{"f_3700:eval_scm",(void*)f_3700},
{"f_3703:eval_scm",(void*)f_3703},
{"f_3706:eval_scm",(void*)f_3706},
{"f_3696:eval_scm",(void*)f_3696},
{"f_3675:eval_scm",(void*)f_3675},
{"f_3609:eval_scm",(void*)f_3609},
{"f_3613:eval_scm",(void*)f_3613},
{"f_3621:eval_scm",(void*)f_3621},
{"f_3563:eval_scm",(void*)f_3563},
{"f_3569:eval_scm",(void*)f_3569},
{"f_3588:eval_scm",(void*)f_3588},
{"f_3579:eval_scm",(void*)f_3579},
{"f_3543:eval_scm",(void*)f_3543},
{"f_3555:eval_scm",(void*)f_3555},
{"f_3558:eval_scm",(void*)f_3558},
{"f_3551:eval_scm",(void*)f_3551},
{"f_3483:eval_scm",(void*)f_3483},
{"f_3487:eval_scm",(void*)f_3487},
{"f_3495:eval_scm",(void*)f_3495},
{"f_3428:eval_scm",(void*)f_3428},
{"f_3481:eval_scm",(void*)f_3481},
{"f_3438:eval_scm",(void*)f_3438},
{"f_3413:eval_scm",(void*)f_3413},
{"f_3401:eval_scm",(void*)f_3401},
{"f_3405:eval_scm",(void*)f_3405},
{"f_3374:eval_scm",(void*)f_3374},
{"f_3339:eval_scm",(void*)f_3339},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
