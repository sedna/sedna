/* Generated from chicken-status.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:40
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: chicken-status.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -ignore-repository -output-file chicken-status.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils ports regex files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[55];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_382)
static void C_ccall f_382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_388)
static void C_ccall f_388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_391)
static void C_ccall f_391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_394)
static void C_ccall f_394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_403)
static void C_ccall f_403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_409)
static void C_ccall f_409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_412)
static void C_ccall f_412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_415)
static void C_ccall f_415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_ccall f_418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_678)
static void C_fcall f_678(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_722)
static void C_fcall f_722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_fcall f_767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_814)
static void C_ccall f_814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_799)
static void C_ccall f_799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_793)
static void C_ccall f_793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_789)
static void C_ccall f_789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_761)
static void C_ccall f_761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_453)
static void C_ccall f_453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_449)
static void C_ccall f_449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_445)
static void C_ccall f_445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_437)
static void C_ccall f_437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_431)
static void C_ccall f_431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_662)
static void C_fcall f_662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_666)
static void C_ccall f_666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_632)
static void C_ccall f_632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_646)
static void C_ccall f_646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_660)
static void C_ccall f_660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_644)
static void C_ccall f_644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_640)
static void C_ccall f_640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_568)
static void C_ccall f_568(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_545)
static void C_ccall f_545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_562)
static void C_ccall f_562r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_548)
static void C_ccall f_548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_630)
static void C_fcall f_630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_572)
static void C_ccall f_572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_622)
static void C_ccall f_622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_ccall f_577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_618)
static void C_ccall f_618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_611)
static void C_ccall f_611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_591)
static void C_ccall f_591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_595)
static void C_ccall f_595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_455)
static void C_fcall f_455(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_487)
static void C_fcall f_487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_fcall f_482(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_457)
static void C_fcall f_457(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_464)
static void C_ccall f_464(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_678)
static void C_fcall trf_678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_678(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_678(t0,t1,t2,t3);}

C_noret_decl(trf_722)
static void C_fcall trf_722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_722(t0,t1);}

C_noret_decl(trf_767)
static void C_fcall trf_767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_767(t0,t1);}

C_noret_decl(trf_662)
static void C_fcall trf_662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_662(t0,t1);}

C_noret_decl(trf_630)
static void C_fcall trf_630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_630(t0,t1);}

C_noret_decl(trf_455)
static void C_fcall trf_455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_455(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_455(t0,t1,t2,t3);}

C_noret_decl(trf_487)
static void C_fcall trf_487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_487(t0,t1);}

C_noret_decl(trf_482)
static void C_fcall trf_482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_482(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_482(t0,t1,t2);}

C_noret_decl(trf_457)
static void C_fcall trf_457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_457(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_457(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(359)){
C_save(t1);
C_rereclaim2(359*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,55);
lf[1]=C_h_intern(&lf[1],13,"string-append");
lf[2]=C_h_intern(&lf[2],11,"make-string");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[6]=C_h_intern(&lf[6],7,"version");
lf[7]=C_h_intern(&lf[7],5,"print");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\012 version: ");
lf[9]=C_h_intern(&lf[9],8,"->string");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[11]=C_h_intern(&lf[11],19,"setup-api#read-info");
lf[12]=C_h_intern(&lf[12],12,"\003sysfor-each");
lf[13]=C_h_intern(&lf[13],4,"sort");
lf[14]=C_h_intern(&lf[14],8,"string<\077");
lf[15]=C_h_intern(&lf[15],13,"terminal-size");
lf[16]=C_h_intern(&lf[16],14,"terminal-port\077");
lf[17]=C_h_intern(&lf[17],19,"current-output-port");
lf[19]=C_h_intern(&lf[19],5,"files");
lf[20]=C_h_intern(&lf[20],10,"append-map");
lf[22]=C_h_intern(&lf[22],4,"exit");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\312usage: chicken-status [OPTION | PATTERN] ...\012\012  -h   -help                 "
"   show this message\012  -v   -version                 show version and exit\012  -f "
"  -files                   list installed files");
lf[24]=C_h_intern(&lf[24],25,"\003sysimplicit-exit-handler");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\006(none)");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002.*\376\377\016");
lf[27]=C_h_intern(&lf[27],17,"delete-duplicates");
lf[28]=C_h_intern(&lf[28],8,"string=\077");
lf[29]=C_h_intern(&lf[29],11,"concatenate");
lf[30]=C_h_intern(&lf[30],4,"grep");
lf[31]=C_h_intern(&lf[31],7,"\003sysmap");
lf[32]=C_h_intern(&lf[32],13,"pathname-file");
lf[33]=C_h_intern(&lf[33],4,"glob");
lf[34]=C_h_intern(&lf[34],13,"make-pathname");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[37]=C_h_intern(&lf[37],15,"repository-path");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002-f");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\006-files");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[43]=C_h_intern(&lf[43],15,"chicken-version");
lf[44]=C_h_intern(&lf[44],6,"append");
lf[45]=C_h_intern(&lf[45],17,"lset-intersection");
lf[46]=C_h_intern(&lf[46],3,"eq\077");
lf[47]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000f\376\377\016");
lf[48]=C_h_intern(&lf[48],16,"\003sysstring->list");
lf[49]=C_h_intern(&lf[49],9,"substring");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[52]=C_h_intern(&lf[52],22,"command-line-arguments");
lf[53]=C_h_intern(&lf[53],11,"\003sysrequire");
lf[54]=C_h_intern(&lf[54],9,"setup-api");
C_register_lf2(lf,55,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k377 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k380 in k377 */
static void C_ccall f_382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k383 in k380 in k377 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_388,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k386 in k383 in k380 in k377 */
static void C_ccall f_388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_391,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_394,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_403,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_406,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_415,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[53]))(3,*((C_word*)lf[53]+1),t2,lf[54]);}

/* k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_418,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_455,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[5] /* (set! main#list-installed-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_568,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[18] /* (set! main#list-installed-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_632,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[21] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_662,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_864,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_874,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 129  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[52]))(2,*((C_word*)lf[52]+1),t7);}

/* k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_874,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_678,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_678(t7,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_678(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_678,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_688,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?lf[26]:t3);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_424,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_445,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_449,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_453,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 38   repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[37]))(2,*((C_word*)lf[37]+1),t10);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[38]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_722,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_722(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[50]);
t8=t6;
f_722(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[51])));}}}

/* k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_722,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-status.scm: 112  usage */
f_662(((C_word*)t0)[7],C_fix(0));}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[39]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[40]));
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-status.scm: 115  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_678(t6,((C_word*)t0)[7],t5,((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[41]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[42]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_754,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 117  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[43]))(2,*((C_word*)lf[43]+1),t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t7))){
t8=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t9=t6;
f_767(t9,(C_word)C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_767(t8,C_SCHEME_FALSE);}}}}}

/* k765 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_814,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 122  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-status.scm: 126  usage */
f_662(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* chicken-status.scm: 127  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_678(t4,((C_word*)t0)[4],t2,t3);}}

/* k812 in k765 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[48]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k774 in k765 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-status.scm: 123  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[45]))(5,*((C_word*)lf[45]+1),t2,*((C_word*)lf[46]+1),lf[47],t1);}

/* k808 in k774 in k765 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_789,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_793,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_799,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 125  usage */
f_662(((C_word*)t0)[5],C_fix(1));}}

/* a798 in k808 in k774 in k765 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_799,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k791 in k808 in k774 in k765 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-status.scm: 124  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[44]+1)))(4,*((C_word*)lf[44]+1),((C_word*)t0)[2],t1,t2);}

/* k787 in k808 in k774 in k765 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 124  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_678(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k759 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 117  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],t1);}

/* k752 in k720 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 118  exit */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[2],C_fix(0));}

/* k451 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[34]))(5,*((C_word*)lf[34]+1),((C_word*)t0)[2],t1,lf[35],lf[36]);}

/* k447 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 38   glob */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k443 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[32]),t1);}

/* k422 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_431,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_435,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_437,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a436 in k422 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_437,3,t0,t1,t2);}
/* grep */
((C_proc4)C_retrieve_symbol_proc(lf[30]))(4,*((C_word*)lf[30]+1),t1,t2,((C_word*)t0)[2]);}

/* k433 in k422 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 40   concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],t1);}

/* k429 in k422 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 39   delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[27]))(4,*((C_word*)lf[27]+1),((C_word*)t0)[2],t1,*((C_word*)lf[28]+1));}

/* k686 in loop in k872 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-status.scm: 105  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[3],lf[25]);}
else{
t2=(C_truep(((C_word*)((C_word*)t0)[2])[1])?C_retrieve2(lf[18],"main#list-installed-files"):C_retrieve2(lf[5],"main#list-installed-eggs"));
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t1);}}

/* k862 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[24]))(2,*((C_word*)lf[24]+1),t3);}

/* k868 in k862 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k865 in k862 in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_662(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_662,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_666,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 87   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t3,lf[23]);}

/* k664 in main#usage in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 95   exit */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#list-installed-files in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_632,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_640,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_644,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_646,tmp=(C_word)a,a+=2,tmp);
/* chicken-status.scm: 77   append-map */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t4,t5,t2);}

/* a645 in main#list-installed-files in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_646,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_660,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 79   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k658 in a645 in main#list-installed-files in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_assq(lf[19],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_cdr(t2):C_SCHEME_END_OF_LIST));}

/* k642 in main#list-installed-files in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 76   sort */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,*((C_word*)lf[14]+1));}

/* k638 in main#list-installed-files in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[7]+1),t1);}

/* main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_568(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_568,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_572,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_630,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_539,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-status.scm: 53   current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[17]+1)))(2,*((C_word*)lf[17]+1),t5);}

/* k537 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_545,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 54   terminal-port? */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,t1);}

/* k543 in k537 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_545,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_548,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_556,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_562,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[3];
f_630(t2,C_fix(80));}}

/* a561 in k543 in k537 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_562(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_562r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_562r(t0,t1,t2);}}

static void C_ccall f_562r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_vector_ref(t2,C_fix(1)));}

/* a555 in k543 in k537 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
/* chicken-status.scm: 55   terminal-size */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t1,((C_word*)t0)[2]);}

/* k546 in k543 in k537 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_zerop(t1);
t3=((C_word*)t0)[2];
f_630(t3,(C_truep(t2)?C_fix(80):t1));}

/* k628 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_630,NULL,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,t1,C_fix(2));
C_quotient(4,0,((C_word*)t0)[2],t2,C_fix(2));}

/* k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_577,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_622,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 71   sort */
((C_proc4)C_retrieve_symbol_proc(lf[13]))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[2],*((C_word*)lf[14]+1));}

/* k620 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a576 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_577,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_618,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-status.scm: 63   setup-api#read-info */
((C_proc3)C_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t3,t2);}

/* k616 in a576 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_618,2,t0,t1);}
t2=(C_word)C_i_assq(lf[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_591,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_611,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-status.scm: 66   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),t4,((C_word*)t0)[2],lf[10]);}
else{
/* chicken-status.scm: 70   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k609 in k616 in a576 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_611,2,t0,t1);}
/* chicken-status.scm: 66   format-string */
f_455(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,C_make_character(46)));}

/* k589 in k616 in a576 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_591,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_595,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_599,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_603,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-status.scm: 68   ->string */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t4,t5);}

/* k601 in k589 in k616 in a576 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 68   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[2],lf[8],t1);}

/* k597 in k589 in k616 in a576 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_599,2,t0,t1);}
/* chicken-status.scm: 67   format-string */
f_455(((C_word*)t0)[3],t1,((C_word*)t0)[2],(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,C_make_character(46)));}

/* k593 in k589 in k616 in a576 in k570 in main#list-installed-eggs in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-status.scm: 65   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[7]+1)))(4,*((C_word*)lf[7]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#format-string in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_455(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_455,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_457,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_482,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_487,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right220242 */
t8=t7;
f_487(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc221238 */
t10=t6;
f_482(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body218227 */
t12=t5;
f_457(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[4],t11);}}}}

/* def-right220 in main#format-string in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_487,NULL,2,t0,t1);}
/* def-padc221238 */
t2=((C_word*)t0)[2];
f_482(t2,t1,C_SCHEME_FALSE);}

/* def-padc221 in main#format-string in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_482(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_482,NULL,3,t0,t1,t2);}
/* body218227 */
t3=((C_word*)t0)[2];
f_457(t3,t1,t2,C_make_character(32));}

/* body218 in main#format-string in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_fcall f_457(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_457,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_464,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-status.scm: 45   make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[2]+1)))(4,*((C_word*)lf[2]+1),t5,t7,t3);}

/* k462 in body218 in main#format-string in k416 in k413 in k410 in k407 in k404 in k401 in k398 in k395 in k392 in k389 in k386 in k383 in k380 in k377 */
static void C_ccall f_464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-status.scm: 47   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-status.scm: 48   string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[1]+1)))(4,*((C_word*)lf[1]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[67] = {
{"toplevel:chicken_status_scm",(void*)C_toplevel},
{"f_379:chicken_status_scm",(void*)f_379},
{"f_382:chicken_status_scm",(void*)f_382},
{"f_385:chicken_status_scm",(void*)f_385},
{"f_388:chicken_status_scm",(void*)f_388},
{"f_391:chicken_status_scm",(void*)f_391},
{"f_394:chicken_status_scm",(void*)f_394},
{"f_397:chicken_status_scm",(void*)f_397},
{"f_400:chicken_status_scm",(void*)f_400},
{"f_403:chicken_status_scm",(void*)f_403},
{"f_406:chicken_status_scm",(void*)f_406},
{"f_409:chicken_status_scm",(void*)f_409},
{"f_412:chicken_status_scm",(void*)f_412},
{"f_415:chicken_status_scm",(void*)f_415},
{"f_418:chicken_status_scm",(void*)f_418},
{"f_874:chicken_status_scm",(void*)f_874},
{"f_678:chicken_status_scm",(void*)f_678},
{"f_722:chicken_status_scm",(void*)f_722},
{"f_767:chicken_status_scm",(void*)f_767},
{"f_814:chicken_status_scm",(void*)f_814},
{"f_776:chicken_status_scm",(void*)f_776},
{"f_810:chicken_status_scm",(void*)f_810},
{"f_799:chicken_status_scm",(void*)f_799},
{"f_793:chicken_status_scm",(void*)f_793},
{"f_789:chicken_status_scm",(void*)f_789},
{"f_761:chicken_status_scm",(void*)f_761},
{"f_754:chicken_status_scm",(void*)f_754},
{"f_453:chicken_status_scm",(void*)f_453},
{"f_449:chicken_status_scm",(void*)f_449},
{"f_445:chicken_status_scm",(void*)f_445},
{"f_424:chicken_status_scm",(void*)f_424},
{"f_437:chicken_status_scm",(void*)f_437},
{"f_435:chicken_status_scm",(void*)f_435},
{"f_431:chicken_status_scm",(void*)f_431},
{"f_688:chicken_status_scm",(void*)f_688},
{"f_864:chicken_status_scm",(void*)f_864},
{"f_870:chicken_status_scm",(void*)f_870},
{"f_867:chicken_status_scm",(void*)f_867},
{"f_662:chicken_status_scm",(void*)f_662},
{"f_666:chicken_status_scm",(void*)f_666},
{"f_632:chicken_status_scm",(void*)f_632},
{"f_646:chicken_status_scm",(void*)f_646},
{"f_660:chicken_status_scm",(void*)f_660},
{"f_644:chicken_status_scm",(void*)f_644},
{"f_640:chicken_status_scm",(void*)f_640},
{"f_568:chicken_status_scm",(void*)f_568},
{"f_539:chicken_status_scm",(void*)f_539},
{"f_545:chicken_status_scm",(void*)f_545},
{"f_562:chicken_status_scm",(void*)f_562},
{"f_556:chicken_status_scm",(void*)f_556},
{"f_548:chicken_status_scm",(void*)f_548},
{"f_630:chicken_status_scm",(void*)f_630},
{"f_572:chicken_status_scm",(void*)f_572},
{"f_622:chicken_status_scm",(void*)f_622},
{"f_577:chicken_status_scm",(void*)f_577},
{"f_618:chicken_status_scm",(void*)f_618},
{"f_611:chicken_status_scm",(void*)f_611},
{"f_591:chicken_status_scm",(void*)f_591},
{"f_603:chicken_status_scm",(void*)f_603},
{"f_599:chicken_status_scm",(void*)f_599},
{"f_595:chicken_status_scm",(void*)f_595},
{"f_455:chicken_status_scm",(void*)f_455},
{"f_487:chicken_status_scm",(void*)f_487},
{"f_482:chicken_status_scm",(void*)f_482},
{"f_457:chicken_status_scm",(void*)f_457},
{"f_464:chicken_status_scm",(void*)f_464},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
