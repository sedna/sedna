/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:40
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: chicken-profile.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -output-file chicken-profile.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 srfi_13 srfi_69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[92];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_301)
static void C_ccall f_301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_304)
static void C_ccall f_304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_307)
static void C_ccall f_307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_310)
static void C_ccall f_310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_313)
static void C_ccall f_313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_316)
static void C_ccall f_316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_319)
static void C_ccall f_319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_322)
static void C_ccall f_322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_325)
static void C_ccall f_325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_328)
static void C_ccall f_328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_331)
static void C_ccall f_331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_387)
static void C_fcall f_387(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_589)
static void C_fcall f_589(C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_775)
static void C_ccall f_775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_fcall f_740(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_518)
static void C_ccall f_518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_509)
static void C_ccall f_509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_fcall f_461(C_word t0,C_word t1) C_noret;
C_noret_decl(f_481)
static void C_ccall f_481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_442)
static void C_fcall f_442(C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_422)
static void C_ccall f_422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_420)
static void C_ccall f_420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_fcall f_397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1206)
static void C_fcall f_1206(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1213)
static void C_fcall f_1213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_fcall f_1011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1152)
static void C_ccall f_1152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1084)
static void C_ccall f_1084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_ccall f_1054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1037)
static void C_ccall f_1037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_fcall f_939(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_986)
static void C_ccall f_986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_962)
static void C_ccall f_962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_891)
static void C_fcall f_891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_fcall f_886(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_861)
static void C_fcall f_861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_868)
static void C_ccall f_868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_796)
static void C_ccall f_796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_808)
static void C_fcall f_808(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_825)
static void C_ccall f_825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_799)
static void C_ccall f_799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_716)
static void C_ccall f_716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_720)
static void C_ccall f_720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_679)
static void C_ccall f_679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_650)
static void C_ccall f_650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_615)
static void C_ccall f_615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_340)
static void C_fcall f_340(C_word t0) C_noret;
C_noret_decl(f_351)
static void C_ccall f_351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_387)
static void C_fcall trf_387(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_387(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_387(t0,t1,t2);}

C_noret_decl(trf_589)
static void C_fcall trf_589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_589(t0,t1);}

C_noret_decl(trf_740)
static void C_fcall trf_740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_740(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_740(t0,t1,t2);}

C_noret_decl(trf_461)
static void C_fcall trf_461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_461(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_461(t0,t1);}

C_noret_decl(trf_442)
static void C_fcall trf_442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_442(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_442(t0,t1);}

C_noret_decl(trf_397)
static void C_fcall trf_397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_397(t0,t1);}

C_noret_decl(trf_1206)
static void C_fcall trf_1206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1206(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1206(t0,t1);}

C_noret_decl(trf_1213)
static void C_fcall trf_1213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1213(t0,t1);}

C_noret_decl(trf_1011)
static void C_fcall trf_1011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1011(t0,t1);}

C_noret_decl(trf_939)
static void C_fcall trf_939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_939(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_939(t0,t1,t2);}

C_noret_decl(trf_891)
static void C_fcall trf_891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_891(t0,t1);}

C_noret_decl(trf_886)
static void C_fcall trf_886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_886(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_886(t0,t1,t2);}

C_noret_decl(trf_861)
static void C_fcall trf_861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_861(t0,t1,t2,t3);}

C_noret_decl(trf_808)
static void C_fcall trf_808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_808(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_808(t0,t1,t2);}

C_noret_decl(trf_340)
static void C_fcall trf_340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_340(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_340(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(396)){
C_save(t1);
C_rereclaim2(396*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,92);
lf[8]=C_h_intern(&lf[8],4,"exit");
lf[9]=C_h_intern(&lf[9],7,"display");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[14]=C_h_intern(&lf[14],19,"\003sysprint-to-string");
lf[19]=C_h_intern(&lf[19],8,"string<\077");
lf[20]=C_h_intern(&lf[20],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],17,"hash-table->alist");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],15,"hash-table-set!");
lf[25]=C_h_intern(&lf[25],3,"map");
lf[26]=C_h_intern(&lf[26],22,"hash-table-ref/default");
lf[27]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[28]=C_h_intern(&lf[28],15,"make-hash-table");
lf[29]=C_h_intern(&lf[29],3,"eq\077");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_h_intern(&lf[32],11,"make-string");
lf[33]=C_h_intern(&lf[33],9,"\003syserror");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],9,"substring");
lf[39]=C_h_intern(&lf[39],8,"truncate");
lf[40]=C_h_intern(&lf[40],4,"expt");
lf[41]=C_h_intern(&lf[41],25,"\003sysimplicit-exit-handler");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[47]=C_h_intern(&lf[47],5,"print");
lf[48]=C_h_intern(&lf[48],11,"string-join");
lf[49]=C_h_intern(&lf[49],12,"\003sysfor-each");
lf[50]=C_h_intern(&lf[50],6,"reduce");
lf[51]=C_h_intern(&lf[51],1,"+");
lf[52]=C_h_intern(&lf[52],3,"max");
lf[53]=C_h_intern(&lf[53],7,"\003sysmap");
lf[54]=C_h_intern(&lf[54],13,"string-length");
lf[55]=C_h_intern(&lf[55],4,"fold");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[57]=C_h_intern(&lf[57],28,"\003syssymbol->qualified-string");
lf[58]=C_h_intern(&lf[58],6,"remove");
lf[59]=C_h_intern(&lf[59],4,"take");
lf[60]=C_h_intern(&lf[60],4,"sort");
lf[61]=C_h_intern(&lf[61],6,"append");
lf[62]=C_h_intern(&lf[62],20,"with-input-from-file");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[65]=C_h_intern(&lf[65],5,"error");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[67]=C_h_intern(&lf[67],22,"file-modification-time");
lf[68]=C_h_intern(&lf[68],4,"glob");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[78]=C_h_intern(&lf[78],15,"chicken-version");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[91]=C_h_intern(&lf[91],22,"command-line-arguments");
C_register_lf2(lf,92,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_301,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k299 */
static void C_ccall f_301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k302 in k299 */
static void C_ccall f_304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k305 in k302 in k299 */
static void C_ccall f_307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k308 in k305 in k302 in k299 */
static void C_ccall f_310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_325,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_331,2,t0,t1);}
t2=lf[0] /* sort-by */ =C_SCHEME_FALSE;;
t3=lf[1] /* file */ =C_SCHEME_FALSE;;
t4=lf[2] /* no-unused */ =C_SCHEME_FALSE;;
t5=lf[3] /* seconds-digits */ =C_fix(3);;
t6=lf[4] /* average-digits */ =C_fix(3);;
t7=lf[5] /* percent-digits */ =C_fix(3);;
t8=lf[6] /* top */ =C_fix(0);;
t9=C_mutate(&lf[7] /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_340,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* (set! sort-by-calls ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_615,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[16] /* (set! sort-by-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_650,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17] /* (set! sort-by-avg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_679,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[18] /* (set! sort-by-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_708,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[16],"sort-by-time"));
t15=C_mutate(&lf[21] /* (set! read-profile ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_792,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[30] /* (set! format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_859,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[35] /* (set! format-real ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_939,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1258,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 234  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[91]))(2,*((C_word*)lf[91]+1),t19);}

/* k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_387,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_387(t5,((C_word*)t0)[2],t1);}

/* loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_387(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_387,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_397,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[1],"file"))){
t4=t3;
f_397(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 73   glob */
((C_proc3)C_retrieve_symbol_proc(lf[68]))(3,*((C_word*)lf[68]+1),t4,lf[69]);}}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_442,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_461,a[2]=t7,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_484,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[72]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[73]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[74]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-profile.scm: 93   print-usage */
f_340(t9);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[75]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[76]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_502,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_509,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 95   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[78]))(2,*((C_word*)lf[78]+1),t11);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[79]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_518,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_525,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 98   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[78]))(2,*((C_word*)lf[78]+1),t11);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[80]))){
t10=lf[2] /* no-unused */ =C_SCHEME_TRUE;;
t11=t9;
f_484(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[81]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_542,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 101  next-number */
t11=t8;
f_461(t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[82]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[15],"sort-by-calls"));
t11=t9;
f_484(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[83]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[16],"sort-by-time"));
t11=t9;
f_484(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[84]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[17],"sort-by-avg"));
t11=t9;
f_484(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[85]))){
t10=C_mutate(&lf[0] /* (set! sort-by ...) */,C_retrieve2(lf[18],"sort-by-name"));
t11=t9;
f_484(2,t11,t10);}
else{
if(C_truep((C_word)C_i_string_equal_p(t3,lf[86]))){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_583,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 106  next-arg */
t11=t7;
f_442(t11,t10);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_589,a[2]=t3,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_string_length(t3);
if(C_truep((C_word)C_i_greaterp(t11,C_fix(1)))){
t12=(C_word)C_i_string_ref(t3,C_fix(0));
t13=t10;
f_589(t13,(C_word)C_eqp(C_make_character(45),t12));}
else{
t12=t10;
f_589(t12,C_SCHEME_FALSE);}}}}}}}}}}}}}

/* k587 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* chicken-profile.scm: 108  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[65]+1)))(4,*((C_word*)lf[65]+1),((C_word*)t0)[3],lf[90],((C_word*)t0)[2]);}
else{
if(C_truep(C_retrieve2(lf[1],"file"))){
/* chicken-profile.scm: 109  print-usage */
f_340(((C_word*)t0)[3]);}
else{
t2=C_mutate(&lf[1] /* (set! file ...) */,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_484(2,t3,t2);}}}

/* k581 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_583,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[87] /* (set! arg-digit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_775,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 148  arg-digit */
t5=C_retrieve2(lf[87],"arg-digit");
f_740(t5,t4,C_fix(0));}
else{
/* chicken-profile.scm: 151  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[65]+1)))(4,*((C_word*)lf[65]+1),((C_word*)t0)[2],lf[89],t1);}}

/* k773 in k581 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_775,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! seconds-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_779,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 149  arg-digit */
t4=C_retrieve2(lf[87],"arg-digit");
f_740(t4,t3,C_fix(1));}

/* k777 in k773 in k581 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_779,2,t0,t1);}
t2=C_mutate(&lf[4] /* (set! average-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 150  arg-digit */
t4=C_retrieve2(lf[87],"arg-digit");
f_740(t4,t3,C_fix(2));}

/* k781 in k777 in k773 in k581 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5] /* (set! percent-digits ...) */,t1);
t3=((C_word*)t0)[2];
f_484(2,t3,t2);}

/* arg-digit in k581 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_740(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_740,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t4=(C_word)C_fix((C_word)C_character_code(t3));
t5=(C_word)C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_750,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 145  <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k748 in arg-digit in k581 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
/* chicken-profile.scm: 147  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[65]+1)))(4,*((C_word*)lf[65]+1),((C_word*)t0)[3],lf[88],((C_word*)t0)[2]);}}

/* k540 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[6] /* (set! top ...) */,t1);
t3=((C_word*)t0)[2];
f_484(2,t3,t2);}

/* k523 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 98   print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k516 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 99   exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* k507 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 95   print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[47]+1)))(4,*((C_word*)lf[47]+1),((C_word*)t0)[2],lf[77],t1);}

/* k500 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 96   exit */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),((C_word*)t0)[2]);}

/* k482 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 111  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_387(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* next-number in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_461(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_461,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_465,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_481,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 90   next-arg */
t4=((C_word*)t0)[2];
f_442(t4,t3);}

/* k479 in next-number in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 90   string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k463 in next-number in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_greaterp(t1,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-profile.scm: 91   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[65]+1)))(4,*((C_word*)lf[65]+1),((C_word*)t0)[3],lf[71],((C_word*)t0)[2]);}}

/* next-arg in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_442(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_442,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* chicken-profile.scm: 85   error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[65]+1)))(4,*((C_word*)lf[65]+1),t1,lf[70],((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k402 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
/* chicken-profile.scm: 75   error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[65]+1)))(3,*((C_word*)lf[65]+1),t2,lf[66]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_422,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 76   sort */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t3,t1,t4);}}

/* a421 in k402 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_422,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_430,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 78   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[67]))(3,*((C_word*)lf[67]+1),t4,t2);}

/* k428 in a421 in k402 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_434,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 79   file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[67]))(3,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2]);}

/* k432 in k428 in a421 in k402 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_greaterp(((C_word*)t0)[2],t1));}

/* k418 in k402 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_407(2,t2,(C_word)C_i_car(t1));}

/* k405 in k402 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[1] /* (set! file ...) */,t1);
t3=((C_word*)t0)[2];
f_397(t3,t2);}

/* k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_397,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 184  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[47]+1)))(5,*((C_word*)lf[47]+1),t3,lf[63],C_retrieve2(lf[1],"file"),lf[64]);}

/* k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 185  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t2,C_retrieve2(lf[1],"file"),C_retrieve2(lf[21],"read-profile"));}

/* k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1005,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1237,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 186  fold */
((C_proc5)C_retrieve_symbol_proc(lf[55]))(5,*((C_word*)lf[55]+1),t2,t3,C_fix(0),t1);}

/* a1236 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1237,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
/* chicken-profile.scm: 187  max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[52]+1)))(4,*((C_word*)lf[52]+1),t1,t4,t3);}

/* k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1188,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1187 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1188,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1206,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=(C_word)C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1206(t7,(C_truep(t6)?(C_word)C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1206(t6,C_SCHEME_FALSE);}}

/* k1204 in a1187 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_1206(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1206,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1213,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1213(t5,(C_word)C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1213(t4,C_SCHEME_FALSE);}}

/* k1211 in k1204 in a1187 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_1213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1213,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
/* chicken-profile.scm: 191  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1184 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 190  sort */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[0],"sort-by"));}

/* k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1174,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm: 200  < */
C_lessp(5,0,t5,C_fix(0),C_retrieve2(lf[6],"top"),t6);}

/* k1172 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 201  take */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t2,((C_word*)((C_word*)t0)[3])[1],C_retrieve2(lf[6],"top"));}
else{
t2=((C_word*)t0)[2];
f_1011(t2,C_SCHEME_UNDEFINED);}}

/* k1176 in k1172 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1011(t3,t2);}

/* k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_1011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1011,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1094,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1152,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1154,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm: 212  remove */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),t4,t5,((C_word*)((C_word*)t0)[3])[1]);}

/* a1153 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1154,3,t0,t1,t2);}
if(C_truep((C_word)C_i_cadr(t2))){
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_retrieve2(lf[2],"no-unused"):C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1150 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1093 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1094,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_cadddr(t2);
t6=(C_word)C_i_list_ref(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1114,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 207  ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t7,t8);}

/* k1112 in a1093 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken-profile.scm: 208  number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1118(2,t3,lf[56]);}}

/* k1116 in k1112 in a1093 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 209  format-real */
f_939(t2,t3,C_retrieve2(lf[3],"seconds-digits"));}

/* k1120 in k1116 in k1112 in a1093 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm: 210  format-real */
f_939(t2,t3,C_retrieve2(lf[4],"average-digits"));}

/* k1124 in k1120 in k1116 in k1112 in a1093 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1130,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 211  format-real */
f_939(t2,((C_word*)t0)[2],C_retrieve2(lf[5],"percent-digits"));}

/* k1128 in k1124 in k1120 in k1116 in k1112 in a1093 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1130,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_a_i_list(&a,5,lf[42],lf[43],lf[44],lf[45],lf[46]);
t4=(C_word)C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1024,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 220  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t5,C_fix(2),C_make_character(32));}

/* k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1076,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm: 221  fold */
((C_proc5)C_retrieve_symbol_proc(lf[55]))(5,*((C_word*)lf[55]+1),t2,t3,t4,t5);}

/* a1075 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1076,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1084,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[53]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[54]+1),t2);}

/* k1082 in a1075 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 223  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],*((C_word*)lf[52]+1),t1,((C_word*)t0)[2]);}

/* k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1044,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm: 228  print-row */
t4=t2;
f_1029(3,t4,t3,((C_word*)t0)[2]);}

/* k1042 in k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1062,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 229  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[50]))(5,*((C_word*)lf[50]+1),t4,*((C_word*)lf[51]+1),C_fix(0),((C_word*)t0)[2]);}

/* k1060 in k1042 in k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1062,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t4=(C_word)C_a_i_times(&a,2,C_fix(2),t3);
t5=(C_word)C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm: 229  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),((C_word*)t0)[2],t5,C_make_character(45));}

/* k1052 in k1042 in k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 229  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k1045 in k1042 in k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* print-row in k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1029,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1037,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 227  map */
((C_proc6)C_retrieve_proc(*((C_word*)lf[25]+1)))(6,*((C_word*)lf[25]+1),t4,C_retrieve2(lf[30],"format-string"),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1039 in print-row in k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  string-join */
((C_proc4)C_retrieve_symbol_proc(lf[48]))(4,*((C_word*)lf[48]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1035 in print-row in k1025 in k1022 in k1013 in k1009 in k1006 in k1003 in k1000 in k997 in k395 in loop in k1256 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 227  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k1246 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1254,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[41]))(2,*((C_word*)lf[41]+1),t3);}

/* k1252 in k1246 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1249 in k1246 in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_939(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_939,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_993,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm: 172  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t4,t2);}

/* k991 in format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(C_word)C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_950,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm: 174  number->string */
C_number_to_string(3,0,t3,t2);}

/* k948 in k991 in format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[36]:lf[37]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_958,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_962,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_974,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_982,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  - */
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k980 in k948 in k991 in format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 180  expt */
((C_proc4)C_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,C_fix(10),((C_word*)t0)[2]);}

/* k984 in k980 in k948 in k991 in format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_986,2,t0,t1);}
t2=(C_word)C_a_i_times(&a,2,((C_word*)t0)[3],t1);
/* chicken-profile.scm: 179  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2);}

/* k972 in k948 in k991 in format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_inexact_to_exact(t1);
/* chicken-profile.scm: 177  number->string */
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k960 in k948 in k991 in format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_962,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* chicken-profile.scm: 176  substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[38]+1)))(5,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k956 in k948 in k991 in format-real in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 173  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[31]+1)))(5,*((C_word*)lf[31]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_859r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_859r(t0,t1,t2,t3,t4);}}

static void C_ccall f_859r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_861,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_891,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-right149171 */
t8=t7;
f_891(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-padc150167 */
t10=t6;
f_886(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body147156 */
t12=t5;
f_861(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[34],t11);}}}}

/* def-right149 in format-string in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_891,NULL,2,t0,t1);}
/* def-padc150167 */
t2=((C_word*)t0)[2];
f_886(t2,t1,C_SCHEME_FALSE);}

/* def-padc150 in format-string in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_886(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_886,NULL,3,t0,t1,t2);}
/* body147156 */
t3=((C_word*)t0)[2];
f_861(t3,t1,t2,C_make_character(32));}

/* body147 in format-string in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_861,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_868,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_difference(((C_word*)t0)[2],t4);
t7=(C_word)C_i_fixnum_max(C_fix(0),t6);
/* chicken-profile.scm: 166  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t5,t7,t3);}

/* k866 in body147 in format-string in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-profile.scm: 168  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-profile.scm: 169  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_796,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm: 154  make-hash-table */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,*((C_word*)lf[29]+1));}

/* k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_799,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_806,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t3);}

/* k804 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_806,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_808,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_808(t5,((C_word*)t0)[2],t1);}

/* doloop107 in k804 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_808(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_808,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_818,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_833,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_835,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_849,a[2]=t6,a[3]=t5,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_car(t2);
/* chicken-profile.scm: 160  hash-table-ref/default */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t7,((C_word*)t0)[2],t8,lf[27]);}}

/* k847 in doloop107 in k804 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-profile.scm: 159  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* a834 in doloop107 in k804 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_835,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t2)?(C_truep(t3)?(C_word)C_a_i_plus(&a,2,t2,t3):C_SCHEME_FALSE):C_SCHEME_FALSE));}

/* k831 in doloop107 in k804 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 157  hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k816 in doloop107 in k804 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm: 155  read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t2);}

/* k823 in k816 in doloop107 in k804 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_808(t2,((C_word*)t0)[2],t1);}

/* k797 in k794 in read-profile in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 162  hash-table->alist */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-name in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_708,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_716,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-profile.scm: 135  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t4,t5);}

/* k714 in sort-by-name in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_720,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-profile.scm: 135  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,t3);}

/* k718 in k714 in sort-by-name in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 135  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[19]+1)))(4,*((C_word*)lf[19]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sort-by-avg in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_679(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_679,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadddr(t2);
t5=(C_word)C_i_cadddr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-time in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_650,4,t0,t1,t2,t3);}
t4=(C_word)C_i_caddr(t2);
t5=(C_word)C_i_caddr(t3);
if(C_truep((C_word)C_i_nequalp(t4,t5))){
t6=(C_word)C_i_cadr(t2);
t7=(C_word)C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_greaterp(t4,t5));}}

/* sort-by-calls in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_615,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cadr(t2);
t5=(C_word)C_i_cadr(t3);
if(C_truep((C_word)C_i_eqvp(t4,t5))){
t6=(C_word)C_i_caddr(t2);
t7=(C_word)C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t4)?(C_truep(t5)?(C_word)C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE));}}

/* print-usage in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_fcall f_340(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_340,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_351,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[5],"percent-digits"),t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
t7=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[4],"average-digits"),t6);
t8=(C_word)C_a_i_cons(&a,2,lf[12],t7);
t9=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[3],"seconds-digits"),t8);
t10=(C_word)C_a_i_cons(&a,2,lf[13],t9);
/* chicken-profile.scm: 45   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),t3,t10);}

/* k349 in print-usage in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 45   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),((C_word*)t0)[2],t1);}

/* k342 in print-usage in k329 in k326 in k323 in k320 in k317 in k314 in k311 in k308 in k305 in k302 in k299 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm: 65   exit */
((C_proc3)C_retrieve_symbol_proc(lf[8]))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[106] = {
{"toplevel:chicken_profile_scm",(void*)C_toplevel},
{"f_301:chicken_profile_scm",(void*)f_301},
{"f_304:chicken_profile_scm",(void*)f_304},
{"f_307:chicken_profile_scm",(void*)f_307},
{"f_310:chicken_profile_scm",(void*)f_310},
{"f_313:chicken_profile_scm",(void*)f_313},
{"f_316:chicken_profile_scm",(void*)f_316},
{"f_319:chicken_profile_scm",(void*)f_319},
{"f_322:chicken_profile_scm",(void*)f_322},
{"f_325:chicken_profile_scm",(void*)f_325},
{"f_328:chicken_profile_scm",(void*)f_328},
{"f_331:chicken_profile_scm",(void*)f_331},
{"f_1258:chicken_profile_scm",(void*)f_1258},
{"f_387:chicken_profile_scm",(void*)f_387},
{"f_589:chicken_profile_scm",(void*)f_589},
{"f_583:chicken_profile_scm",(void*)f_583},
{"f_775:chicken_profile_scm",(void*)f_775},
{"f_779:chicken_profile_scm",(void*)f_779},
{"f_783:chicken_profile_scm",(void*)f_783},
{"f_740:chicken_profile_scm",(void*)f_740},
{"f_750:chicken_profile_scm",(void*)f_750},
{"f_542:chicken_profile_scm",(void*)f_542},
{"f_525:chicken_profile_scm",(void*)f_525},
{"f_518:chicken_profile_scm",(void*)f_518},
{"f_509:chicken_profile_scm",(void*)f_509},
{"f_502:chicken_profile_scm",(void*)f_502},
{"f_484:chicken_profile_scm",(void*)f_484},
{"f_461:chicken_profile_scm",(void*)f_461},
{"f_481:chicken_profile_scm",(void*)f_481},
{"f_465:chicken_profile_scm",(void*)f_465},
{"f_442:chicken_profile_scm",(void*)f_442},
{"f_404:chicken_profile_scm",(void*)f_404},
{"f_422:chicken_profile_scm",(void*)f_422},
{"f_430:chicken_profile_scm",(void*)f_430},
{"f_434:chicken_profile_scm",(void*)f_434},
{"f_420:chicken_profile_scm",(void*)f_420},
{"f_407:chicken_profile_scm",(void*)f_407},
{"f_397:chicken_profile_scm",(void*)f_397},
{"f_999:chicken_profile_scm",(void*)f_999},
{"f_1002:chicken_profile_scm",(void*)f_1002},
{"f_1237:chicken_profile_scm",(void*)f_1237},
{"f_1005:chicken_profile_scm",(void*)f_1005},
{"f_1188:chicken_profile_scm",(void*)f_1188},
{"f_1206:chicken_profile_scm",(void*)f_1206},
{"f_1213:chicken_profile_scm",(void*)f_1213},
{"f_1186:chicken_profile_scm",(void*)f_1186},
{"f_1008:chicken_profile_scm",(void*)f_1008},
{"f_1174:chicken_profile_scm",(void*)f_1174},
{"f_1178:chicken_profile_scm",(void*)f_1178},
{"f_1011:chicken_profile_scm",(void*)f_1011},
{"f_1154:chicken_profile_scm",(void*)f_1154},
{"f_1152:chicken_profile_scm",(void*)f_1152},
{"f_1094:chicken_profile_scm",(void*)f_1094},
{"f_1114:chicken_profile_scm",(void*)f_1114},
{"f_1118:chicken_profile_scm",(void*)f_1118},
{"f_1122:chicken_profile_scm",(void*)f_1122},
{"f_1126:chicken_profile_scm",(void*)f_1126},
{"f_1130:chicken_profile_scm",(void*)f_1130},
{"f_1015:chicken_profile_scm",(void*)f_1015},
{"f_1024:chicken_profile_scm",(void*)f_1024},
{"f_1076:chicken_profile_scm",(void*)f_1076},
{"f_1084:chicken_profile_scm",(void*)f_1084},
{"f_1027:chicken_profile_scm",(void*)f_1027},
{"f_1044:chicken_profile_scm",(void*)f_1044},
{"f_1062:chicken_profile_scm",(void*)f_1062},
{"f_1054:chicken_profile_scm",(void*)f_1054},
{"f_1047:chicken_profile_scm",(void*)f_1047},
{"f_1029:chicken_profile_scm",(void*)f_1029},
{"f_1041:chicken_profile_scm",(void*)f_1041},
{"f_1037:chicken_profile_scm",(void*)f_1037},
{"f_1248:chicken_profile_scm",(void*)f_1248},
{"f_1254:chicken_profile_scm",(void*)f_1254},
{"f_1251:chicken_profile_scm",(void*)f_1251},
{"f_939:chicken_profile_scm",(void*)f_939},
{"f_993:chicken_profile_scm",(void*)f_993},
{"f_950:chicken_profile_scm",(void*)f_950},
{"f_982:chicken_profile_scm",(void*)f_982},
{"f_986:chicken_profile_scm",(void*)f_986},
{"f_974:chicken_profile_scm",(void*)f_974},
{"f_962:chicken_profile_scm",(void*)f_962},
{"f_958:chicken_profile_scm",(void*)f_958},
{"f_859:chicken_profile_scm",(void*)f_859},
{"f_891:chicken_profile_scm",(void*)f_891},
{"f_886:chicken_profile_scm",(void*)f_886},
{"f_861:chicken_profile_scm",(void*)f_861},
{"f_868:chicken_profile_scm",(void*)f_868},
{"f_792:chicken_profile_scm",(void*)f_792},
{"f_796:chicken_profile_scm",(void*)f_796},
{"f_806:chicken_profile_scm",(void*)f_806},
{"f_808:chicken_profile_scm",(void*)f_808},
{"f_849:chicken_profile_scm",(void*)f_849},
{"f_835:chicken_profile_scm",(void*)f_835},
{"f_833:chicken_profile_scm",(void*)f_833},
{"f_818:chicken_profile_scm",(void*)f_818},
{"f_825:chicken_profile_scm",(void*)f_825},
{"f_799:chicken_profile_scm",(void*)f_799},
{"f_708:chicken_profile_scm",(void*)f_708},
{"f_716:chicken_profile_scm",(void*)f_716},
{"f_720:chicken_profile_scm",(void*)f_720},
{"f_679:chicken_profile_scm",(void*)f_679},
{"f_650:chicken_profile_scm",(void*)f_650},
{"f_615:chicken_profile_scm",(void*)f_615},
{"f_340:chicken_profile_scm",(void*)f_340},
{"f_351:chicken_profile_scm",(void*)f_351},
{"f_344:chicken_profile_scm",(void*)f_344},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
