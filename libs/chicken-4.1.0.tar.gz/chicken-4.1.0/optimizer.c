/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:38
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: optimizer.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[316];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_ccall f_3690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13060)
static void C_ccall f_13060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_13068)
static void C_ccall f_13068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13073)
static void C_fcall f_13073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13118)
static void C_ccall f_13118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13122)
static void C_ccall f_13122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13083)
static void C_ccall f_13083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13107)
static void C_ccall f_13107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13092)
static void C_fcall f_13092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5672)
static void C_ccall f_5672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12099)
static void C_ccall f_12099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_12133)
static void C_ccall f_12133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12235)
static void C_ccall f_12235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12245)
static void C_fcall f_12245(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12309)
static void C_ccall f_12309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12338)
static void C_fcall f_12338(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12461)
static void C_ccall f_12461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12354)
static void C_fcall f_12354(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12401)
static void C_ccall f_12401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12391)
static void C_ccall f_12391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12399)
static void C_ccall f_12399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12531)
static void C_ccall f_12531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_12544)
static void C_ccall f_12544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12579)
static void C_ccall f_12579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12563)
static void C_ccall f_12563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12567)
static void C_ccall f_12567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12556)
static void C_ccall f_12556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12745)
static void C_ccall f_12745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_12758)
static void C_ccall f_12758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12764)
static void C_ccall f_12764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12810)
static void C_ccall f_12810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12802)
static void C_ccall f_12802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12786)
static void C_ccall f_12786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12790)
static void C_ccall f_12790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12794)
static void C_ccall f_12794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5675)
static void C_ccall f_5675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11777)
static void C_ccall f_11777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_11799)
static void C_ccall f_11799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11854)
static void C_ccall f_11854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11824)
static void C_ccall f_11824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11846)
static void C_ccall f_11846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11850)
static void C_ccall f_11850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11842)
static void C_ccall f_11842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11822)
static void C_ccall f_11822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11948)
static void C_ccall f_11948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_11962)
static void C_ccall f_11962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5678)
static void C_ccall f_5678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6006)
static void C_ccall f_6006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11751)
static void C_ccall f_11751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11593)
static void C_ccall f_11593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11597)
static void C_ccall f_11597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11600)
static void C_ccall f_11600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11603)
static void C_ccall f_11603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11606)
static void C_ccall f_11606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11609)
static void C_ccall f_11609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11612)
static void C_ccall f_11612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11618)
static void C_fcall f_11618(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10705)
static void C_ccall f_10705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11544)
static void C_ccall f_11544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11554)
static void C_ccall f_11554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11561)
static void C_ccall f_11561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11577)
static void C_ccall f_11577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10708)
static void C_ccall f_10708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11542)
static void C_ccall f_11542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11538)
static void C_ccall f_11538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11534)
static void C_ccall f_11534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11530)
static void C_ccall f_11530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11526)
static void C_ccall f_11526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11522)
static void C_ccall f_11522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11518)
static void C_ccall f_11518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11386)
static void C_ccall f_11386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11390)
static void C_ccall f_11390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11393)
static void C_ccall f_11393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11403)
static void C_ccall f_11403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11447)
static void C_ccall f_11447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11427)
static void C_ccall f_11427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10714)
static void C_ccall f_10714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11359)
static void C_ccall f_11359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11369)
static void C_ccall f_11369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10717)
static void C_ccall f_10717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11346)
static void C_ccall f_11346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11350)
static void C_ccall f_11350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10720)
static void C_ccall f_10720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10722)
static void C_ccall f_10722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_10728)
static void C_ccall f_10728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11328)
static void C_ccall f_11328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11332)
static void C_ccall f_11332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11317)
static void C_ccall f_11317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11324)
static void C_ccall f_11324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10750)
static void C_fcall f_10750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10753)
static void C_ccall f_10753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10784)
static void C_ccall f_10784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10787)
static void C_ccall f_10787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10790)
static void C_ccall f_10790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10793)
static void C_ccall f_10793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10796)
static void C_ccall f_10796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10799)
static void C_ccall f_10799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10802)
static void C_ccall f_10802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10896)
static void C_fcall f_10896(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10957)
static void C_ccall f_10957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11261)
static C_word C_fcall f_11261(C_word t0,C_word t1);
C_noret_decl(f_11175)
static void C_ccall f_11175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11178)
static void C_ccall f_11178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11145)
static void C_ccall f_11145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11108)
static void C_ccall f_11108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11071)
static void C_ccall f_11071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11034)
static void C_ccall f_11034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11009)
static void C_ccall f_11009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10984)
static void C_ccall f_10984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10963)
static void C_ccall f_10963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10906)
static void C_ccall f_10906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10909)
static void C_ccall f_10909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10928)
static void C_ccall f_10928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10924)
static void C_ccall f_10924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10833)
static void C_fcall f_10833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10876)
static void C_ccall f_10876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10847)
static void C_fcall f_10847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10886)
static C_word C_fcall f_10886(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_10814)
static void C_fcall f_10814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10804)
static C_word C_fcall f_10804(C_word t0);
C_noret_decl(f_10758)
static void C_fcall f_10758(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10762)
static void C_ccall f_10762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10775)
static void C_ccall f_10775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10765)
static void C_ccall f_10765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10653)
static void C_ccall f_10653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_10653)
static void C_ccall f_10653r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10657)
static void C_ccall f_10657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10683)
static void C_ccall f_10683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10665)
static void C_ccall f_10665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10639)
static void C_ccall f_10639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10643)
static void C_ccall f_10643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10647)
static void C_ccall f_10647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10541)
static void C_ccall f_10541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10544)
static void C_ccall f_10544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10547)
static void C_ccall f_10547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10550)
static void C_ccall f_10550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10553)
static void C_ccall f_10553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10556)
static void C_ccall f_10556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10559)
static void C_ccall f_10559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10562)
static void C_ccall f_10562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10565)
static void C_ccall f_10565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10627)
static void C_ccall f_10627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10568)
static void C_ccall f_10568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10571)
static void C_ccall f_10571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9604)
static void C_fcall f_9604(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9622)
static void C_ccall f_9622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9628)
static void C_ccall f_9628(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9608)
static void C_ccall f_9608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10574)
static void C_ccall f_10574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10616)
static void C_ccall f_10616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10614)
static void C_ccall f_10614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10577)
static void C_ccall f_10577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10580)
static void C_ccall f_10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10583)
static void C_ccall f_10583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10607)
static void C_ccall f_10607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10586)
static void C_ccall f_10586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10589)
static void C_ccall f_10589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10592)
static void C_ccall f_10592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10595)
static void C_ccall f_10595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10598)
static void C_ccall f_10598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10601)
static void C_ccall f_10601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10394)
static void C_fcall f_10394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10400)
static void C_ccall f_10400(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10512)
static void C_ccall f_10512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10521)
static void C_ccall f_10521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10524)
static void C_ccall f_10524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10419)
static void C_ccall f_10419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10424)
static void C_fcall f_10424(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10465)
static void C_fcall f_10465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10462)
static void C_ccall f_10462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10447)
static void C_ccall f_10447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10458)
static void C_ccall f_10458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10454)
static void C_ccall f_10454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10307)
static void C_fcall f_10307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10369)
static void C_ccall f_10369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10365)
static void C_ccall f_10365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10335)
static void C_ccall f_10335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10058)
static void C_fcall f_10058(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10072)
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10079)
static void C_ccall f_10079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10082)
static void C_ccall f_10082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10091)
static void C_ccall f_10091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10098)
static void C_ccall f_10098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10101)
static void C_ccall f_10101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10197)
static void C_ccall f_10197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10283)
static void C_ccall f_10283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10302)
static void C_ccall f_10302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10298)
static void C_ccall f_10298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10264)
static void C_ccall f_10264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10253)
static void C_ccall f_10253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10240)
static void C_ccall f_10240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10223)
static void C_ccall f_10223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10216)
static void C_ccall f_10216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10182)
static void C_ccall f_10182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10104)
static void C_ccall f_10104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10153)
static void C_ccall f_10153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10141)
static void C_ccall f_10141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10137)
static void C_ccall f_10137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10070)
static void C_ccall f_10070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9857)
static void C_fcall f_9857(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10044)
static void C_ccall f_10044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9922)
static void C_ccall f_9922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9999)
static void C_ccall f_9999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10004)
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10042)
static void C_ccall f_10042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9866)
static void C_ccall f_9866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9904)
static void C_ccall f_9904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9909)
static void C_ccall f_9909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9886)
static void C_ccall f_9886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9864)
static void C_ccall f_9864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10034)
static void C_ccall f_10034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10020)
static void C_ccall f_10020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10018)
static void C_ccall f_10018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9924)
static void C_ccall f_9924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9992)
static void C_ccall f_9992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9990)
static void C_ccall f_9990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9978)
static void C_ccall f_9978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9944)
static void C_ccall f_9944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9968)
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9966)
static void C_ccall f_9966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9962)
static void C_ccall f_9962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9954)
static void C_ccall f_9954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9638)
static void C_fcall f_9638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9644)
static void C_fcall f_9644(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9663)
static void C_fcall f_9663(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9830)
static void C_ccall f_9830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9760)
static void C_ccall f_9760(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9776)
static void C_ccall f_9776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9806)
static void C_ccall f_9806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9796)
static void C_ccall f_9796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9754)
static void C_ccall f_9754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9725)
static void C_ccall f_9725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9674)
static void C_fcall f_9674(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9695)
static void C_ccall f_9695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9642)
static void C_ccall f_9642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9394)
static void C_fcall f_9394(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9400)
static void C_fcall f_9400(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9419)
static void C_fcall f_9419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9521)
static void C_ccall f_9521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9478)
static void C_fcall f_9478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9487)
static void C_ccall f_9487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_fcall f_9430(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9451)
static void C_ccall f_9451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9448)
static void C_ccall f_9448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9295)
static void C_fcall f_9295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9301)
static void C_ccall f_9301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9345)
static void C_ccall f_9345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9350)
static void C_fcall f_9350(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9357)
static void C_ccall f_9357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9384)
static void C_ccall f_9384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9380)
static void C_ccall f_9380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9372)
static void C_ccall f_9372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9370)
static void C_ccall f_9370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9335)
static void C_ccall f_9335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9313)
static void C_ccall f_9313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9320)
static void C_ccall f_9320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9098)
static void C_fcall f_9098(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9252)
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9277)
static void C_ccall f_9277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9267)
static void C_ccall f_9267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9250)
static void C_ccall f_9250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_fcall f_9101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9223)
static void C_ccall f_9223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_fcall f_9169(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_ccall f_9151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9126)
static void C_fcall f_9126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9129)
static void C_fcall f_9129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9134)
static void C_ccall f_9134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8998)
static void C_fcall f_8998(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9004)
static void C_ccall f_9004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9035)
static void C_fcall f_9035(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9039)
static void C_ccall f_9039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9043)
static void C_ccall f_9043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9002)
static void C_ccall f_9002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7900)
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8990)
static void C_ccall f_8990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8993)
static void C_ccall f_8993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_fcall f_7903(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8059)
static void C_ccall f_8059(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8039)
static void C_ccall f_8039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7959)
static void C_ccall f_7959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7965)
static void C_ccall f_7965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7971)
static void C_ccall f_7971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7928)
static void C_ccall f_7928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8065)
static void C_fcall f_8065(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8475)
static void C_ccall f_8475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8482)
static void C_ccall f_8482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8068)
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8462)
static void C_ccall f_8462(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8449)
static void C_ccall f_8449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8405)
static void C_ccall f_8405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8344)
static void C_fcall f_8344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8316)
static void C_fcall f_8316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8321)
static void C_ccall f_8321(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8263)
static void C_ccall f_8263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8269)
static void C_fcall f_8269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8228)
static void C_fcall f_8228(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8233)
static void C_ccall f_8233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8206)
static void C_ccall f_8206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8172)
static void C_ccall f_8172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8135)
static void C_ccall f_8135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8151)
static void C_ccall f_8151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8117)
static void C_ccall f_8117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_fcall f_8484(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8980)
static void C_ccall f_8980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8978)
static void C_ccall f_8978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8488)
static void C_ccall f_8488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8498)
static void C_ccall f_8498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8504)
static void C_fcall f_8504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8513)
static void C_ccall f_8513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8519)
static void C_ccall f_8519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8695)
static void C_ccall f_8695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8870)
static void C_ccall f_8870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8873)
static void C_ccall f_8873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8739)
static void C_ccall f_8739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8794)
static void C_ccall f_8794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8797)
static void C_ccall f_8797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8824)
static void C_ccall f_8824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8800)
static void C_ccall f_8800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8803)
static void C_ccall f_8803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8748)
static void C_ccall f_8748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_ccall f_8754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8522)
static void C_ccall f_8522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8677)
static void C_ccall f_8677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8675)
static void C_ccall f_8675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8618)
static void C_ccall f_8618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8628)
static void C_ccall f_8628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8525)
static void C_ccall f_8525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8537)
static void C_ccall f_8537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8576)
static void C_ccall f_8576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8540)
static void C_ccall f_8540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8543)
static void C_ccall f_8543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_7774)
static void C_ccall f_7774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7796)
static void C_ccall f_7796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7822)
static void C_fcall f_7822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7871)
static void C_ccall f_7871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6053)
static void C_fcall f_6053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7842)
static void C_ccall f_7842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7846)
static void C_ccall f_7846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7816)
static void C_ccall f_7816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7802)
static void C_ccall f_7802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_ccall f_7800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7749)
static void C_ccall f_7749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7736)
static void C_fcall f_7736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7575)
static void C_ccall f_7575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7659)
static void C_ccall f_7659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7628)
static void C_ccall f_7628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7626)
static void C_ccall f_7626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_ccall f_7502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7542)
static void C_ccall f_7542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7515)
static void C_ccall f_7515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7441)
static void C_ccall f_7441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7420)
static void C_ccall f_7420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7385)
static void C_ccall f_7385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7331)
static void C_ccall f_7331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7269)
static void C_ccall f_7269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7289)
static void C_fcall f_7289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7226)
static void C_fcall f_7226(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7032)
static void C_ccall f_7032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6988)
static void C_fcall f_6988(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6991)
static void C_ccall f_6991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6903)
static void C_ccall f_6903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6946)
static void C_ccall f_6946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6939)
static void C_ccall f_6939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6856)
static void C_fcall f_6856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6869)
static void C_ccall f_6869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6862)
static void C_ccall f_6862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6757)
static void C_ccall f_6757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6635)
static void C_fcall f_6635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6638)
static void C_fcall f_6638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6629)
static void C_ccall f_6629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6550)
static void C_ccall f_6550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6472)
static void C_ccall f_6472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6385)
static void C_ccall f_6385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6329)
static void C_ccall f_6329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6342)
static void C_ccall f_6342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6221)
static void C_fcall f_6221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6218)
static void C_fcall f_6218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_fcall f_6088(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6022)
static void C_ccall f_6022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5680)
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5684)
static void C_ccall f_5684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5993)
static void C_ccall f_5993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6002)
static void C_ccall f_6002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5998)
static void C_ccall f_5998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5961)
static void C_ccall f_5961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5953)
static void C_ccall f_5953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5734)
static void C_ccall f_5734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5893)
static void C_ccall f_5893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5737)
static void C_ccall f_5737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5760)
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5773)
static void C_fcall f_5773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5816)
static void C_ccall f_5816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5752)
static void C_ccall f_5752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_fcall f_5686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5692)
static void C_fcall f_5692(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5716)
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5665)
static void C_ccall f_5665r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5458)
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5474)
static void C_ccall f_5474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5480)
static void C_fcall f_5480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_fcall f_5495(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_fcall f_5507(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_fcall f_5516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5431)
static void C_fcall f_5431(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5427)
static C_word C_fcall f_5427(C_word t0);
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5328)
static void C_ccall f_5328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5338)
static void C_ccall f_5338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5341)
static void C_ccall f_5341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5377)
static void C_ccall f_5377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5353)
static void C_ccall f_5353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_fcall f_5309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_fcall f_4275(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5225)
static void C_ccall f_5225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5297)
static void C_ccall f_5297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_fcall f_5269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_fcall f_5240(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5259)
static void C_ccall f_5259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4617)
static void C_ccall f_4617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4798)
static void C_fcall f_4798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5121)
static void C_ccall f_5121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_fcall f_4819(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5025)
static void C_fcall f_5025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5028)
static void C_ccall f_5028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_ccall f_5040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_fcall f_4880(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4857)
static void C_ccall f_4857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_fcall f_4704(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4713)
static void C_ccall f_4713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_fcall f_4659(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4529)
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4498)
static void C_ccall f_4498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4401)
static void C_ccall f_4401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4378)
static void C_fcall f_4378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_fcall f_4339(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_ccall f_4333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4227)
static void C_ccall f_4227(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4217)
static void C_ccall f_4217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4192)
static void C_ccall f_4192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4168)
static void C_ccall f_4168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_fcall f_4172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_fcall f_3969(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3973)
static void C_ccall f_3973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_fcall f_4012(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static C_word C_fcall f_3965(C_word t0);
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3939)
static void C_fcall f_3939(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3698)
static void C_ccall f_3698(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3763)
static void C_ccall f_3763(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3778)
static void C_fcall f_3778(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3830)
static void C_fcall f_3830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_fcall f_3803(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static void C_fcall f_3766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3735)
static void C_ccall f_3735r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_13073)
static void C_fcall trf_13073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13073(t0,t1,t2);}

C_noret_decl(trf_13092)
static void C_fcall trf_13092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13092(t0,t1);}

C_noret_decl(trf_12245)
static void C_fcall trf_12245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12245(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12245(t0,t1,t2,t3);}

C_noret_decl(trf_12338)
static void C_fcall trf_12338(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12338(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_12338(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12354)
static void C_fcall trf_12354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12354(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12354(t0,t1);}

C_noret_decl(trf_11618)
static void C_fcall trf_11618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11618(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11618(t0,t1);}

C_noret_decl(trf_10750)
static void C_fcall trf_10750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10750(t0,t1);}

C_noret_decl(trf_10896)
static void C_fcall trf_10896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10896(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10896(t0,t1,t2);}

C_noret_decl(trf_10833)
static void C_fcall trf_10833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10833(t0,t1,t2);}

C_noret_decl(trf_10847)
static void C_fcall trf_10847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10847(t0,t1);}

C_noret_decl(trf_10814)
static void C_fcall trf_10814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10814(t0,t1);}

C_noret_decl(trf_10758)
static void C_fcall trf_10758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10758(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_10758(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9604)
static void C_fcall trf_9604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9604(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9604(t0,t1,t2,t3);}

C_noret_decl(trf_10394)
static void C_fcall trf_10394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10394(t0,t1,t2);}

C_noret_decl(trf_10424)
static void C_fcall trf_10424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10424(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10424(t0,t1,t2,t3);}

C_noret_decl(trf_10465)
static void C_fcall trf_10465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10465(t0,t1);}

C_noret_decl(trf_10307)
static void C_fcall trf_10307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10307(t0,t1,t2);}

C_noret_decl(trf_10058)
static void C_fcall trf_10058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10058(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10058(t0,t1,t2,t3);}

C_noret_decl(trf_9857)
static void C_fcall trf_9857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9857(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9857(t0,t1,t2);}

C_noret_decl(trf_9638)
static void C_fcall trf_9638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9638(t0,t1,t2);}

C_noret_decl(trf_9644)
static void C_fcall trf_9644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9644(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9644(t0,t1,t2,t3);}

C_noret_decl(trf_9663)
static void C_fcall trf_9663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9663(t0,t1);}

C_noret_decl(trf_9674)
static void C_fcall trf_9674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9674(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9674(t0,t1,t2,t3);}

C_noret_decl(trf_9394)
static void C_fcall trf_9394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9394(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9394(t0,t1,t2);}

C_noret_decl(trf_9400)
static void C_fcall trf_9400(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9400(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9400(t0,t1,t2,t3);}

C_noret_decl(trf_9419)
static void C_fcall trf_9419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9419(t0,t1);}

C_noret_decl(trf_9478)
static void C_fcall trf_9478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9478(t0,t1);}

C_noret_decl(trf_9430)
static void C_fcall trf_9430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9430(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9430(t0,t1,t2,t3);}

C_noret_decl(trf_9295)
static void C_fcall trf_9295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9295(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9295(t0,t1,t2,t3);}

C_noret_decl(trf_9350)
static void C_fcall trf_9350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9350(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9350(t0,t1,t2,t3);}

C_noret_decl(trf_9098)
static void C_fcall trf_9098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9098(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9098(t0,t1,t2);}

C_noret_decl(trf_9101)
static void C_fcall trf_9101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9101(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9101(t0,t1,t2,t3);}

C_noret_decl(trf_9169)
static void C_fcall trf_9169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9169(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9169(t0,t1,t2,t3);}

C_noret_decl(trf_9126)
static void C_fcall trf_9126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9126(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9126(t0,t1);}

C_noret_decl(trf_9129)
static void C_fcall trf_9129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9129(t0,t1);}

C_noret_decl(trf_8998)
static void C_fcall trf_8998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8998(t0,t1);}

C_noret_decl(trf_9035)
static void C_fcall trf_9035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9035(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9035(t0,t1);}

C_noret_decl(trf_7903)
static void C_fcall trf_7903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7903(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7903(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8065)
static void C_fcall trf_8065(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8065(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8065(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8068)
static void C_fcall trf_8068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8068(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8068(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8344)
static void C_fcall trf_8344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8344(t0,t1);}

C_noret_decl(trf_8316)
static void C_fcall trf_8316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8316(t0,t1);}

C_noret_decl(trf_8269)
static void C_fcall trf_8269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8269(t0,t1);}

C_noret_decl(trf_8228)
static void C_fcall trf_8228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8228(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8228(t0,t1);}

C_noret_decl(trf_8484)
static void C_fcall trf_8484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8484(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8484(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8504)
static void C_fcall trf_8504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8504(t0,t1);}

C_noret_decl(trf_7822)
static void C_fcall trf_7822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7822(t0,t1,t2,t3);}

C_noret_decl(trf_6053)
static void C_fcall trf_6053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6053(t0,t1);}

C_noret_decl(trf_7736)
static void C_fcall trf_7736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7736(t0,t1);}

C_noret_decl(trf_7289)
static void C_fcall trf_7289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7289(t0,t1);}

C_noret_decl(trf_7226)
static void C_fcall trf_7226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7226(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7226(t0,t1);}

C_noret_decl(trf_6988)
static void C_fcall trf_6988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6988(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6988(t0,t1);}

C_noret_decl(trf_6856)
static void C_fcall trf_6856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6856(t0,t1);}

C_noret_decl(trf_6635)
static void C_fcall trf_6635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6635(t0,t1);}

C_noret_decl(trf_6638)
static void C_fcall trf_6638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6638(t0,t1);}

C_noret_decl(trf_6221)
static void C_fcall trf_6221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6221(t0,t1);}

C_noret_decl(trf_6218)
static void C_fcall trf_6218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6218(t0,t1);}

C_noret_decl(trf_6088)
static void C_fcall trf_6088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6088(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6088(t0,t1);}

C_noret_decl(trf_5773)
static void C_fcall trf_5773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5773(t0,t1);}

C_noret_decl(trf_5686)
static void C_fcall trf_5686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5686(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5686(t0,t1,t2,t3);}

C_noret_decl(trf_5692)
static void C_fcall trf_5692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5692(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5692(t0,t1,t2,t3);}

C_noret_decl(trf_5480)
static void C_fcall trf_5480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5480(t0,t1);}

C_noret_decl(trf_5495)
static void C_fcall trf_5495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5495(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5495(t0,t1);}

C_noret_decl(trf_5507)
static void C_fcall trf_5507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5507(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5507(t0,t1);}

C_noret_decl(trf_5516)
static void C_fcall trf_5516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5516(t0,t1);}

C_noret_decl(trf_5431)
static void C_fcall trf_5431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5431(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5431(t0,t1,t2,t3);}

C_noret_decl(trf_5309)
static void C_fcall trf_5309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5309(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5309(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4275)
static void C_fcall trf_4275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4275(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4275(t0,t1,t2);}

C_noret_decl(trf_5269)
static void C_fcall trf_5269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5269(t0,t1);}

C_noret_decl(trf_5240)
static void C_fcall trf_5240(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5240(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5240(t0,t1);}

C_noret_decl(trf_4798)
static void C_fcall trf_4798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4798(t0,t1);}

C_noret_decl(trf_4819)
static void C_fcall trf_4819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4819(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4819(t0,t1);}

C_noret_decl(trf_5025)
static void C_fcall trf_5025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5025(t0,t1);}

C_noret_decl(trf_4880)
static void C_fcall trf_4880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4880(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4880(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4704)
static void C_fcall trf_4704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4704(t0,t1);}

C_noret_decl(trf_4659)
static void C_fcall trf_4659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4659(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4659(t0,t1);}

C_noret_decl(trf_4378)
static void C_fcall trf_4378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4378(t0,t1);}

C_noret_decl(trf_4300)
static void C_fcall trf_4300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4300(t0,t1,t2);}

C_noret_decl(trf_4339)
static void C_fcall trf_4339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4339(t0,t1);}

C_noret_decl(trf_4172)
static void C_fcall trf_4172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4172(t0,t1);}

C_noret_decl(trf_3969)
static void C_fcall trf_3969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3969(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3969(t0,t1,t2);}

C_noret_decl(trf_4012)
static void C_fcall trf_4012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4012(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4012(t0,t1);}

C_noret_decl(trf_3939)
static void C_fcall trf_3939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3939(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3939(t0,t1,t2,t3);}

C_noret_decl(trf_3778)
static void C_fcall trf_3778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3778(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3778(t0,t1,t2,t3);}

C_noret_decl(trf_3830)
static void C_fcall trf_3830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3830(t0,t1);}

C_noret_decl(trf_3803)
static void C_fcall trf_3803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3803(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3803(t0,t1);}

C_noret_decl(trf_3766)
static void C_fcall trf_3766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3766(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2546)){
C_save(t1);
C_rereclaim2(2546*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,316);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],34,"\010compilerscan-toplevel-assignments");
lf[3]=C_h_intern(&lf[3],8,"\003sysput!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_h_intern(&lf[5],21,"\010compileralways-bound");
lf[6]=C_h_intern(&lf[6],12,"\003sysfor-each");
lf[7]=C_h_intern(&lf[7],18,"\010compilerdebugging");
lf[8]=C_h_intern(&lf[8],1,"o");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[10]=C_h_intern(&lf[10],13,"\004corevariable");
lf[11]=C_h_intern(&lf[11],2,"if");
lf[12]=C_h_intern(&lf[12],3,"let");
lf[13]=C_h_intern(&lf[13],6,"append");
lf[14]=C_h_intern(&lf[14],6,"lambda");
lf[15]=C_h_intern(&lf[15],13,"\004corecallunit");
lf[16]=C_h_intern(&lf[16],9,"\004corecall");
lf[17]=C_h_intern(&lf[17],4,"set!");
lf[18]=C_h_intern(&lf[18],9,"\004corecond");
lf[19]=C_h_intern(&lf[19],11,"\004coreswitch");
lf[20]=C_h_intern(&lf[20],30,"call-with-current-continuation");
lf[21]=C_h_intern(&lf[21],1,"p");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[23]=C_h_intern(&lf[23],24,"\010compilersimplifications");
lf[24]=C_h_intern(&lf[24],23,"\010compilersimplified-ops");
lf[25]=C_h_intern(&lf[25],41,"\010compilerperform-high-level-optimizations");
lf[26]=C_h_intern(&lf[26],12,"\010compilerget");
lf[27]=C_h_intern(&lf[27],5,"quote");
lf[28]=C_h_intern(&lf[28],10,"alist-cons");
lf[29]=C_h_intern(&lf[29],4,"caar");
lf[30]=C_h_intern(&lf[30],7,"\003sysmap");
lf[31]=C_h_intern(&lf[31],19,"\010compilermatch-node");
lf[32]=C_h_intern(&lf[32],3,"any");
lf[33]=C_h_intern(&lf[33],18,"\003syshash-table-ref");
lf[34]=C_h_intern(&lf[34],30,"\010compilerbroken-constant-nodes");
lf[35]=C_h_intern(&lf[35],11,"lset-adjoin");
lf[36]=C_h_intern(&lf[36],3,"eq\077");
lf[37]=C_h_intern(&lf[37],4,"node");
lf[38]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[39]=C_h_intern(&lf[39],14,"\010compilerqnode");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[41]=C_h_intern(&lf[41],4,"eval");
lf[42]=C_h_intern(&lf[42],22,"with-exception-handler");
lf[43]=C_h_intern(&lf[43],5,"every");
lf[44]=C_h_intern(&lf[44],9,"foldable\077");
lf[45]=C_h_intern(&lf[45],7,"\003sysget");
lf[46]=C_h_intern(&lf[46],18,"\010compilerintrinsic");
lf[47]=C_h_intern(&lf[47],5,"value");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[49]=C_h_intern(&lf[49],16,"\010compilervarnode");
lf[50]=C_h_intern(&lf[50],11,"collapsable");
lf[51]=C_h_intern(&lf[51],10,"replacable");
lf[52]=C_h_intern(&lf[52],9,"replacing");
lf[53]=C_h_intern(&lf[53],12,"contractable");
lf[54]=C_h_intern(&lf[54],9,"removable");
lf[55]=C_h_intern(&lf[55],11,"\004corelambda");
lf[56]=C_h_intern(&lf[56],6,"unused");
lf[57]=C_h_intern(&lf[57],9,"partition");
lf[58]=C_h_intern(&lf[58],26,"\010compilerbuild-lambda-list");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[60]=C_h_intern(&lf[60],13,"explicit-rest");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[62]=C_h_intern(&lf[62],30,"\010compilerdecompose-lambda-list");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[64]=C_h_intern(&lf[64],21,"has-unused-parameters");
lf[65]=C_h_intern(&lf[65],31,"\010compilerinline-lambda-bindings");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[67]=C_h_intern(&lf[67],24,"\010compilercheck-signature");
lf[68]=C_h_intern(&lf[68],30,"\010compilerconstant-declarations");
lf[69]=C_h_intern(&lf[69],14,"\004coreundefined");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[73]=C_h_intern(&lf[73],37,"\010compilerexpression-has-side-effects\077");
lf[74]=C_h_intern(&lf[74],8,"assigned");
lf[75]=C_h_intern(&lf[75],10,"references");
lf[76]=C_h_intern(&lf[76],7,"unknown");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#procedure can be inlined (globally)");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure can be inlined");
lf[80]=C_h_intern(&lf[80],1,"i");
lf[81]=C_h_intern(&lf[81],22,"\010compilerinline-global");
lf[82]=C_h_intern(&lf[82],14,"append-reverse");
lf[83]=C_h_intern(&lf[83],6,"gensym");
lf[84]=C_h_intern(&lf[84],1,"t");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[86]=C_h_intern(&lf[86],8,"split-at");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[88]=C_h_intern(&lf[88],20,"\004coreinline_allocate");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[90]=C_h_intern(&lf[90],21,"\010compilerllist-length");
lf[91]=C_h_intern(&lf[91],23,"\010compilerinline-locally");
lf[92]=C_h_intern(&lf[92],3,"yes");
lf[93]=C_h_intern(&lf[93],2,"no");
lf[94]=C_h_intern(&lf[94],24,"\010compilerinline-max-size");
lf[95]=C_h_intern(&lf[95],15,"\010compilerinline");
lf[96]=C_h_intern(&lf[96],9,"inlinable");
lf[97]=C_h_intern(&lf[97],6,"simple");
lf[98]=C_h_intern(&lf[98],11,"local-value");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[100]=C_h_intern(&lf[100],26,"\010compilervariable-visible\077");
lf[101]=C_h_intern(&lf[101],6,"global");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[105]=C_h_intern(&lf[105],5,"print");
lf[106]=C_h_intern(&lf[106],7,"newline");
lf[107]=C_h_intern(&lf[107],6,"print*");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[111]=C_h_intern(&lf[111],34,"\010compilerperform-pre-optimization!");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[113]=C_h_intern(&lf[113],24,"node-subexpressions-set!");
lf[114]=C_h_intern(&lf[114],7,"reverse");
lf[115]=C_h_intern(&lf[115],20,"node-parameters-set!");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[117]=C_h_intern(&lf[117],3,"not");
lf[118]=C_h_intern(&lf[118],10,"call-sites");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[120]=C_h_intern(&lf[120],24,"register-simplifications");
lf[121]=C_h_intern(&lf[121],19,"\003syshash-table-set!");
lf[122]=C_h_intern(&lf[122],38,"\010compilerreorganize-recursive-bindings");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[124]=C_h_intern(&lf[124],10,"fold-right");
lf[125]=C_h_intern(&lf[125],4,"fold");
lf[126]=C_h_intern(&lf[126],25,"\010compilertopological-sort");
lf[127]=C_h_intern(&lf[127],6,"lset<=");
lf[128]=C_h_intern(&lf[128],10,"filter-map");
lf[129]=C_h_intern(&lf[129],6,"filter");
lf[130]=C_h_intern(&lf[130],10,"append-map");
lf[131]=C_h_intern(&lf[131],28,"\010compilerscan-used-variables");
lf[132]=C_h_intern(&lf[132],8,"for-each");
lf[133]=C_h_intern(&lf[133],3,"map");
lf[134]=C_h_intern(&lf[134],4,"cons");
lf[135]=C_h_intern(&lf[135],27,"\010compilersubstitution-table");
lf[136]=C_h_intern(&lf[136],16,"\010compilerrewrite");
lf[137]=C_h_intern(&lf[137],28,"\010compilersimplify-named-call");
lf[138]=C_h_intern(&lf[138],37,"\010compilerinline-substitutions-enabled");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_h_intern(&lf[142],6,"unsafe");
lf[143]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[144]=C_h_intern(&lf[144],6,"vector");
lf[145]=C_h_intern(&lf[145],14,"rest-parameter");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[147]=C_h_intern(&lf[147],11,"number-type");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[150]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[152]=C_h_intern(&lf[152],6,"fixnum");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_h_intern(&lf[154],21,"\010compilerfold-boolean");
lf[155]=C_h_intern(&lf[155],6,"flonum");
lf[156]=C_h_intern(&lf[156],7,"generic");
lf[157]=C_h_intern(&lf[157],5,"cons*");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_h_intern(&lf[159],9,"\004coreproc");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_h_intern(&lf[168],19,"\010compilerfold-inner");
lf[169]=C_h_intern(&lf[169],6,"remove");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_h_intern(&lf[174],5,"fifth");
lf[175]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[176]=C_h_intern(&lf[176],13,"\010compilerbomb");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[178]=C_h_intern(&lf[178],34,"\010compilertransform-direct-lambdas!");
lf[179]=C_h_intern(&lf[179],19,"\010compilercopy-node!");
lf[180]=C_h_intern(&lf[180],16,"\004coredirect_call");
lf[181]=C_h_intern(&lf[181],4,"quit");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[183]=C_h_intern(&lf[183],15,"lset-difference");
lf[184]=C_h_intern(&lf[184],15,"node-class-set!");
lf[185]=C_h_intern(&lf[185],12,"\004corerecurse");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[187]=C_h_intern(&lf[187],4,"take");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[190]=C_h_intern(&lf[190],11,"\004corereturn");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[192]=C_h_intern(&lf[192],18,"\004coredirect_lambda");
lf[193]=C_h_intern(&lf[193],6,"cdaddr");
lf[194]=C_h_intern(&lf[194],6,"caaddr");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[197]=C_h_intern(&lf[197],6,"unzip1");
lf[198]=C_h_intern(&lf[198],16,"\003sysmake-promise");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[200]=C_h_intern(&lf[200],5,"boxed");
lf[201]=C_h_intern(&lf[201],15,"\004coreinline_ref");
lf[202]=C_h_intern(&lf[202],37,"\010compilerestimate-foreign-result-size");
lf[203]=C_h_intern(&lf[203],19,"\004coreinline_loc_ref");
lf[204]=C_h_intern(&lf[204],5,"lset=");
lf[205]=C_h_intern(&lf[205],6,"delete");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[207]=C_h_intern(&lf[207],32,"\010compilerperform-lambda-lifting!");
lf[208]=C_h_intern(&lf[208],23,"\003syshash-table-for-each");
lf[209]=C_h_intern(&lf[209],1,"+");
lf[210]=C_h_intern(&lf[210],17,"delete-duplicates");
lf[211]=C_h_intern(&lf[211],14,"\004coreprimitive");
lf[212]=C_h_intern(&lf[212],7,"delete!");
lf[213]=C_h_intern(&lf[213],11,"concatenate");
lf[214]=C_h_intern(&lf[214],5,"count");
lf[215]=C_h_intern(&lf[215],22,"\010compilerhide-variable");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[219]=C_h_intern(&lf[219],12,"pretty-print");
lf[220]=C_h_intern(&lf[220],1,"l");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[231]=C_h_intern(&lf[231],35,"\010compilercompiler-syntax-statistics");
lf[232]=C_h_intern(&lf[232],24,"\003syscompiler-syntax-hook");
lf[233]=C_h_intern(&lf[233],13,"alist-update!");
lf[234]=C_h_intern(&lf[234],9,"alist-ref");
lf[235]=C_h_intern(&lf[235],14,"\010compilerr-c-s");
lf[236]=C_h_intern(&lf[236],24,"\010compilercompiler-syntax");
lf[237]=C_h_intern(&lf[237],18,"\003syser-transformer");
lf[238]=C_h_intern(&lf[238],7,"display");
lf[239]=C_h_intern(&lf[239],5,"write");
lf[240]=C_h_intern(&lf[240],7,"fprintf");
lf[241]=C_h_intern(&lf[241],14,"number->string");
lf[242]=C_h_intern(&lf[242],10,"write-char");
lf[243]=C_h_intern(&lf[243],18,"open-output-string");
lf[244]=C_h_intern(&lf[244],17,"get-output-string");
lf[245]=C_h_intern(&lf[245],30,"\010compilercompile-format-string");
lf[246]=C_h_intern(&lf[246],17,"extended-bindings");
lf[247]=C_h_intern(&lf[247],25,"\010compilercompiler-warning");
lf[248]=C_h_intern(&lf[248],6,"syntax");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\036(~a) in format string ~s~a, ~\077");
lf[250]=C_h_intern(&lf[250],7,"sprintf");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\013 in line ~a");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[253]=C_h_intern(&lf[253],17,"\010compilerget-line");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[255]=C_h_intern(&lf[255],20,"reverse-list->string");
lf[256]=C_h_intern(&lf[256],10,"\003sysappend");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\0000too many arguments to formatted output procedure");
lf[258]=C_h_intern(&lf[258],16,"\003sysflush-output");
lf[259]=C_h_intern(&lf[259],9,"\003sysapply");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000$illegal format-string character `~c\047");
lf[261]=C_h_intern(&lf[261],3,"out");
lf[262]=C_h_intern(&lf[262],5,"cadar");
lf[263]=C_h_intern(&lf[263],7,"call/cc");
lf[264]=C_h_intern(&lf[264],6,"printf");
lf[265]=C_h_intern(&lf[265],19,"\003sysstandard-output");
lf[266]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006printf\376\003\000\000\002\376\001\000\000\010#%printf\376\377\016");
lf[267]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007fprintf\376\003\000\000\002\376\001\000\000\011#%fprintf\376\377\016");
lf[268]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\377\016");
lf[269]=C_h_intern(&lf[269],6,"format");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007sprintf\376\003\000\000\002\376\001\000\000\011#%sprintf\376\003\000\000\002\376\001\000\000\006format\376\003\000\000\002\376\001\000\000\010#%format\376\377\016");
lf[271]=C_h_intern(&lf[271],19,"\003sysprimitive-alias");
lf[272]=C_h_intern(&lf[272],4,"list");
lf[273]=C_h_intern(&lf[273],3,"tmp");
lf[274]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\003#%o\376\377\016");
lf[275]=C_h_intern(&lf[275],8,"\003sysslot");
lf[276]=C_h_intern(&lf[276],8,"\004coreapp");
lf[277]=C_h_intern(&lf[277],17,"standard-bindings");
lf[278]=C_h_intern(&lf[278],5,"pair\077");
lf[279]=C_h_intern(&lf[279],5,"begin");
lf[280]=C_h_intern(&lf[280],3,"lst");
lf[281]=C_h_intern(&lf[281],4,"loop");
lf[282]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010for-each\376\003\000\000\002\376\001\000\000\014\003sysfor-each\376\003\000\000\002\376\001\000\000\012#%for-each\376\377\016");
lf[283]=C_h_intern(&lf[283],11,"make-vector");
lf[284]=C_h_intern(&lf[284],3,"var");
lf[285]=C_h_intern(&lf[285],1,"y");
lf[286]=C_h_intern(&lf[286],2,"d2");
lf[287]=C_h_intern(&lf[287],1,"z");
lf[288]=C_h_intern(&lf[288],2,"d3");
lf[289]=C_h_intern(&lf[289],2,"d1");
lf[290]=C_h_intern(&lf[290],2,"op");
lf[291]=C_h_intern(&lf[291],5,"clist");
lf[292]=C_h_intern(&lf[292],34,"\010compilermembership-test-operators");
lf[293]=C_h_intern(&lf[293],32,"\010compilermembership-unfold-limit");
lf[294]=C_h_intern(&lf[294],4,"var1");
lf[295]=C_h_intern(&lf[295],4,"var0");
lf[296]=C_h_intern(&lf[296],6,"const1");
lf[297]=C_h_intern(&lf[297],4,"var2");
lf[298]=C_h_intern(&lf[298],6,"const2");
lf[299]=C_h_intern(&lf[299],4,"rest");
lf[300]=C_h_intern(&lf[300],5,"body2");
lf[301]=C_h_intern(&lf[301],5,"body1");
lf[302]=C_h_intern(&lf[302],27,"\010compilereq-inline-operator");
lf[303]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[304]=C_h_intern(&lf[304],19,"\010compilerimmediate\077");
lf[305]=C_h_intern(&lf[305],5,"const");
lf[306]=C_h_intern(&lf[306],1,"n");
lf[307]=C_h_intern(&lf[307],7,"clauses");
lf[308]=C_h_intern(&lf[308],4,"body");
lf[309]=C_h_intern(&lf[309],1,"d");
lf[310]=C_h_intern(&lf[310],4,"more");
lf[311]=C_h_intern(&lf[311],4,"args");
lf[312]=C_h_intern(&lf[312],1,"a");
lf[313]=C_h_intern(&lf[313],1,"b");
lf[314]=C_h_intern(&lf[314],1,"c");
lf[315]=C_h_intern(&lf[315],4,"cdar");
C_register_lf2(lf,316,create_ptable());
t2=C_mutate(&lf[0] /* (set! c144 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3681,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3679 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3682 in k3679 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3685 in k3682 in k3679 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3693,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3698,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 140  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[283]+1)))(4,*((C_word*)lf[283]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! simplifications ...) */,t1);
t3=C_set_block_item(lf[24] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[25]+1 /* (set! perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3936,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[111]+1 /* (set! perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5424,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[120]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5665,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_cons(&a,2,lf[312],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[10],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[313],lf[314]);
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[309],t12);
t14=(C_word)C_a_i_cons(&a,2,lf[16],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[309],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,lf[314],t15);
t17=(C_word)C_a_i_cons(&a,2,lf[313],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[312],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13060,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t18,t20);
t22=(C_word)C_a_i_cons(&a,2,t14,t21);
/* optimizer.scm: 504  register-simplifications */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),t7,lf[16],t22);}

/* a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_13060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_13060,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13068,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 510  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t7,C_retrieve(lf[135]),t3);}

/* k13066 in a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_13068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13068,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_13073(t6,((C_word*)t0)[2],t2);}

/* loop in k13066 in a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_13073(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13073,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13083,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13118,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 512  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t4,t2);}}

/* k13116 in loop in k13066 in a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_13118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13122,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 512  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[315]+1)))(3,*((C_word*)lf[315]+1),t2,((C_word*)t0)[2]);}

/* k13120 in k13116 in loop in k13066 in a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_13122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 512  simplify-named-call */
((C_proc9)C_retrieve_symbol_proc(lf[137]))(9,*((C_word*)lf[137]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k13081 in loop in k13066 in a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_13083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13083,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[24]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13092,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_13092(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13107,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 517  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[24]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 519  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_13073(t3,((C_word*)t0)[4],t2);}}

/* k13105 in k13081 in loop in k13066 in a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_13107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[24]+1 /* (set! simplified-ops ...) */,t1);
t3=((C_word*)t0)[2];
f_13092(t3,t2);}

/* k13090 in k13081 in loop in k13066 in a13059 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_13092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[10],t6);
t8=(C_word)C_a_i_cons(&a,2,lf[296],C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,lf[27],t9);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t7,t11);
t13=(C_word)C_a_i_cons(&a,2,t4,t12);
t14=(C_word)C_a_i_cons(&a,2,lf[139],t13);
t15=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t16=(C_word)C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=(C_word)C_a_i_cons(&a,2,lf[10],t16);
t18=(C_word)C_a_i_cons(&a,2,lf[297],C_SCHEME_END_OF_LIST);
t19=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t20=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(C_word)C_a_i_cons(&a,2,lf[10],t21);
t23=(C_word)C_a_i_cons(&a,2,lf[298],C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=(C_word)C_a_i_cons(&a,2,lf[27],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t22,t26);
t28=(C_word)C_a_i_cons(&a,2,t19,t27);
t29=(C_word)C_a_i_cons(&a,2,lf[139],t28);
t30=(C_word)C_a_i_cons(&a,2,lf[297],C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=(C_word)C_a_i_cons(&a,2,lf[10],t31);
t33=(C_word)C_a_i_cons(&a,2,lf[299],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[300],t33);
t35=(C_word)C_a_i_cons(&a,2,t32,t34);
t36=(C_word)C_a_i_cons(&a,2,lf[286],t35);
t37=(C_word)C_a_i_cons(&a,2,lf[11],t36);
t38=(C_word)C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=(C_word)C_a_i_cons(&a,2,t29,t38);
t40=(C_word)C_a_i_cons(&a,2,t18,t39);
t41=(C_word)C_a_i_cons(&a,2,lf[12],t40);
t42=(C_word)C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=(C_word)C_a_i_cons(&a,2,lf[301],t42);
t44=(C_word)C_a_i_cons(&a,2,t17,t43);
t45=(C_word)C_a_i_cons(&a,2,lf[289],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[11],t45);
t47=(C_word)C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=(C_word)C_a_i_cons(&a,2,t14,t47);
t49=(C_word)C_a_i_cons(&a,2,t3,t48);
t50=(C_word)C_a_i_cons(&a,2,lf[12],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[299],C_SCHEME_END_OF_LIST);
t52=(C_word)C_a_i_cons(&a,2,lf[286],t51);
t53=(C_word)C_a_i_cons(&a,2,lf[289],t52);
t54=(C_word)C_a_i_cons(&a,2,lf[300],t53);
t55=(C_word)C_a_i_cons(&a,2,lf[301],t54);
t56=(C_word)C_a_i_cons(&a,2,lf[298],t55);
t57=(C_word)C_a_i_cons(&a,2,lf[296],t56);
t58=(C_word)C_a_i_cons(&a,2,lf[290],t57);
t59=(C_word)C_a_i_cons(&a,2,lf[297],t58);
t60=(C_word)C_a_i_cons(&a,2,lf[294],t59);
t61=(C_word)C_a_i_cons(&a,2,lf[295],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12745,tmp=(C_word)a,a+=2,tmp);
t63=(C_word)C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=(C_word)C_a_i_cons(&a,2,t61,t63);
t65=(C_word)C_a_i_cons(&a,2,t50,t64);
t66=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t67=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t68=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t69=(C_word)C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=(C_word)C_a_i_cons(&a,2,lf[10],t69);
t71=(C_word)C_a_i_cons(&a,2,lf[305],C_SCHEME_END_OF_LIST);
t72=(C_word)C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=(C_word)C_a_i_cons(&a,2,lf[27],t72);
t74=(C_word)C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=(C_word)C_a_i_cons(&a,2,t70,t74);
t76=(C_word)C_a_i_cons(&a,2,t67,t75);
t77=(C_word)C_a_i_cons(&a,2,lf[139],t76);
t78=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t79=(C_word)C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=(C_word)C_a_i_cons(&a,2,lf[10],t79);
t81=(C_word)C_a_i_cons(&a,2,lf[306],C_SCHEME_END_OF_LIST);
t82=(C_word)C_a_i_cons(&a,2,lf[295],C_SCHEME_END_OF_LIST);
t83=(C_word)C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=(C_word)C_a_i_cons(&a,2,lf[10],t83);
t85=(C_word)C_a_i_cons(&a,2,t84,lf[307]);
t86=(C_word)C_a_i_cons(&a,2,t81,t85);
t87=(C_word)C_a_i_cons(&a,2,lf[19],t86);
t88=(C_word)C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=(C_word)C_a_i_cons(&a,2,lf[308],t88);
t90=(C_word)C_a_i_cons(&a,2,t80,t89);
t91=(C_word)C_a_i_cons(&a,2,lf[309],t90);
t92=(C_word)C_a_i_cons(&a,2,lf[11],t91);
t93=(C_word)C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=(C_word)C_a_i_cons(&a,2,t77,t93);
t95=(C_word)C_a_i_cons(&a,2,t66,t94);
t96=(C_word)C_a_i_cons(&a,2,lf[12],t95);
t97=(C_word)C_a_i_cons(&a,2,lf[307],C_SCHEME_END_OF_LIST);
t98=(C_word)C_a_i_cons(&a,2,lf[306],t97);
t99=(C_word)C_a_i_cons(&a,2,lf[308],t98);
t100=(C_word)C_a_i_cons(&a,2,lf[309],t99);
t101=(C_word)C_a_i_cons(&a,2,lf[305],t100);
t102=(C_word)C_a_i_cons(&a,2,lf[295],t101);
t103=(C_word)C_a_i_cons(&a,2,lf[290],t102);
t104=(C_word)C_a_i_cons(&a,2,lf[284],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12531,tmp=(C_word)a,a+=2,tmp);
t106=(C_word)C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=(C_word)C_a_i_cons(&a,2,t104,t106);
t108=(C_word)C_a_i_cons(&a,2,t96,t107);
t109=(C_word)C_a_i_cons(&a,2,lf[294],C_SCHEME_END_OF_LIST);
t110=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=(C_word)C_a_i_cons(&a,2,lf[69],t110);
t112=(C_word)C_a_i_cons(&a,2,lf[310],C_SCHEME_END_OF_LIST);
t113=(C_word)C_a_i_cons(&a,2,t111,t112);
t114=(C_word)C_a_i_cons(&a,2,t109,t113);
t115=(C_word)C_a_i_cons(&a,2,lf[12],t114);
t116=(C_word)C_a_i_cons(&a,2,lf[310],C_SCHEME_END_OF_LIST);
t117=(C_word)C_a_i_cons(&a,2,lf[294],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12235,tmp=(C_word)a,a+=2,tmp);
t119=(C_word)C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=(C_word)C_a_i_cons(&a,2,t117,t119);
t121=(C_word)C_a_i_cons(&a,2,t115,t120);
t122=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t123=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t124=(C_word)C_a_i_cons(&a,2,t123,lf[311]);
t125=(C_word)C_a_i_cons(&a,2,lf[139],t124);
t126=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t127=(C_word)C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=(C_word)C_a_i_cons(&a,2,lf[10],t127);
t129=(C_word)C_a_i_cons(&a,2,lf[285],C_SCHEME_END_OF_LIST);
t130=(C_word)C_a_i_cons(&a,2,lf[71],t129);
t131=(C_word)C_a_i_cons(&a,2,t128,t130);
t132=(C_word)C_a_i_cons(&a,2,lf[309],t131);
t133=(C_word)C_a_i_cons(&a,2,lf[11],t132);
t134=(C_word)C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=(C_word)C_a_i_cons(&a,2,t125,t134);
t136=(C_word)C_a_i_cons(&a,2,t122,t135);
t137=(C_word)C_a_i_cons(&a,2,lf[12],t136);
t138=(C_word)C_a_i_cons(&a,2,lf[285],C_SCHEME_END_OF_LIST);
t139=(C_word)C_a_i_cons(&a,2,lf[71],t138);
t140=(C_word)C_a_i_cons(&a,2,lf[309],t139);
t141=(C_word)C_a_i_cons(&a,2,lf[311],t140);
t142=(C_word)C_a_i_cons(&a,2,lf[290],t141);
t143=(C_word)C_a_i_cons(&a,2,lf[284],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12099,tmp=(C_word)a,a+=2,tmp);
t145=(C_word)C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=(C_word)C_a_i_cons(&a,2,t143,t145);
t147=(C_word)C_a_i_cons(&a,2,t137,t146);
/* optimizer.scm: 522  register-simplifications */
((C_proc7)C_retrieve_symbol_proc(lf[120]))(7,*((C_word*)lf[120]+1),t2,lf[12],t65,t108,t121,t147);}

/* a12098 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_12099,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[302])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12133,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 657  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t9,t2,t3,lf[75]);}}

/* k12131 in a12098 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12133,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[37],lf[11],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12235,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12245,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_12245(t9,t1,t5,t4);}

/* loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_12245(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12245,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[69]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
/* optimizer.scm: 603  loop1 */
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[17]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12309,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 605  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k12307 in loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12309,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12338,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_12338(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k12307 in loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_12338(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12338,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12354,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[12]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12461,a[2]=t10,a[3]=t3,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t8);
/* optimizer.scm: 616  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t14,((C_word*)t0)[2],t15,lf[75]);}
else{
t14=t11;
f_12354(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_12354(t13,C_SCHEME_FALSE);}}

/* k12459 in loop2 in k12307 in loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_12354(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[17],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_12354(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_12354(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_12354(t2,C_SCHEME_FALSE);}}}

/* k12352 in loop2 in k12307 in loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_12354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12354,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 620  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_12338(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12391,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12401,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a12400 in k12352 in loop2 in k12307 in loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12401,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a12390 in k12352 in loop2 in k12307 in loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 625  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2]);}

/* k12397 in a12390 in k12352 in loop2 in k12307 in loop1 in a12234 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 625  reorganize-recursive-bindings */
((C_proc5)C_retrieve_symbol_proc(lf[122]))(5,*((C_word*)lf[122]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a12530 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12531(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_12531,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[302])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12544,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 569  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k12542 in a12530 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12544,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12579,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 570  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12577 in k12542 in a12530 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12579,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12556,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 574  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12561 in k12577 in k12542 in a12530 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12567,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 575  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k12565 in k12561 in k12577 in k12542 in a12530 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 574  cons* */
((C_proc6)C_retrieve_symbol_proc(lf[157]))(6,*((C_word*)lf[157]+1),((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12554 in k12577 in k12542 in a12530 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12556,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[19],((C_word*)t0)[2],t1));}

/* a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_12745,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[302])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12758,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 542  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k12756 in a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12758,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 543  immediate? */
((C_proc3)C_retrieve_symbol_proc(lf[304]))(3,*((C_word*)lf[304]+1),t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12762 in k12756 in a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12764,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 544  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12808 in k12762 in k12756 in a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12810,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12802,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 545  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[75]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12800 in k12808 in k12762 in k12756 in a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12802,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 549  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k12784 in k12800 in k12808 in k12762 in k12756 in a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 550  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k12788 in k12784 in k12800 in k12808 in k12762 in k12756 in a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12794,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 552  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k12792 in k12788 in k12784 in k12800 in k12808 in k12762 in k12756 in a12744 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_12794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12794,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[19],lf[303],t2));}

/* k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[10],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[285],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,lf[286],t7);
t9=(C_word)C_a_i_cons(&a,2,lf[16],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[10],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[287],C_SCHEME_END_OF_LIST);
t14=(C_word)C_a_i_cons(&a,2,t12,t13);
t15=(C_word)C_a_i_cons(&a,2,lf[288],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[16],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,t9,t17);
t19=(C_word)C_a_i_cons(&a,2,lf[71],t18);
t20=(C_word)C_a_i_cons(&a,2,lf[289],t19);
t21=(C_word)C_a_i_cons(&a,2,lf[11],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[284],C_SCHEME_END_OF_LIST);
t23=(C_word)C_a_i_cons(&a,2,lf[287],t22);
t24=(C_word)C_a_i_cons(&a,2,lf[285],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[71],t24);
t26=(C_word)C_a_i_cons(&a,2,lf[288],t25);
t27=(C_word)C_a_i_cons(&a,2,lf[286],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[289],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11948,tmp=(C_word)a,a+=2,tmp);
t30=(C_word)C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=(C_word)C_a_i_cons(&a,2,t28,t30);
t32=(C_word)C_a_i_cons(&a,2,t21,t31);
t33=(C_word)C_a_i_cons(&a,2,lf[290],C_SCHEME_END_OF_LIST);
t34=(C_word)C_a_i_cons(&a,2,lf[291],C_SCHEME_END_OF_LIST);
t35=(C_word)C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=(C_word)C_a_i_cons(&a,2,lf[27],t35);
t37=(C_word)C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=(C_word)C_a_i_cons(&a,2,lf[71],t37);
t39=(C_word)C_a_i_cons(&a,2,t33,t38);
t40=(C_word)C_a_i_cons(&a,2,lf[139],t39);
t41=(C_word)C_a_i_cons(&a,2,lf[287],C_SCHEME_END_OF_LIST);
t42=(C_word)C_a_i_cons(&a,2,lf[285],t41);
t43=(C_word)C_a_i_cons(&a,2,t40,t42);
t44=(C_word)C_a_i_cons(&a,2,lf[289],t43);
t45=(C_word)C_a_i_cons(&a,2,lf[11],t44);
t46=(C_word)C_a_i_cons(&a,2,lf[287],C_SCHEME_END_OF_LIST);
t47=(C_word)C_a_i_cons(&a,2,lf[285],t46);
t48=(C_word)C_a_i_cons(&a,2,lf[291],t47);
t49=(C_word)C_a_i_cons(&a,2,lf[71],t48);
t50=(C_word)C_a_i_cons(&a,2,lf[290],t49);
t51=(C_word)C_a_i_cons(&a,2,lf[289],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11777,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=(C_word)C_a_i_cons(&a,2,t51,t53);
t55=(C_word)C_a_i_cons(&a,2,t45,t54);
/* optimizer.scm: 664  register-simplifications */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),t2,lf[11],t32,t55);}

/* a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_11777,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[292]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[293]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11799,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 695  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11797 in a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11799,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11822,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11824,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11854,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 712  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t8,C_SCHEME_FALSE);}

/* k11852 in k11797 in a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 704  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a11823 in k11797 in a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11824,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11846,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 709  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,((C_word*)t0)[2]);}

/* k11844 in a11823 in k11797 in a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 709  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[2]);}

/* k11848 in k11844 in a11823 in k11797 in a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11850,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 710  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t4,C_SCHEME_TRUE);}

/* k11840 in k11848 in k11844 in a11823 in k11797 in a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11842,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[18],C_SCHEME_END_OF_LIST,t2));}

/* k11820 in k11797 in a11776 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11822,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[11],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t4));}

/* a11947 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11948(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_11948,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[138]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11962,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 680  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k11960 in a11947 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11962,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[18],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t4));}

/* k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5678,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1 /* (set! reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5680,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6006,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 807  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[283]+1)))(4,*((C_word*)lf[283]+1),t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6006,2,t0,t1);}
t2=C_mutate((C_word*)lf[135]+1 /* (set! substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[136]+1 /* (set! rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6008,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[137]+1 /* (set! simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6028,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[178]+1 /* (set! transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7900,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[207]+1 /* (set! perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8995,tmp=(C_word)a,a+=2,tmp));
t7=C_set_block_item(lf[231] /* compiler-syntax-statistics */,0,C_SCHEME_END_OF_LIST);
t8=C_mutate((C_word*)lf[232]+1 /* (set! compiler-syntax-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10639,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[235]+1 /* (set! r-c-s ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10653,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10705,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11593,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11751,a[2]=t11,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1841 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t12,lf[278]);}

/* k11749 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11751,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[278],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 1824 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),((C_word*)t0)[3],lf[282],((C_word*)t0)[2],t3);}

/* a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11593,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11597,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1827 r */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[12]);}

/* k11595 in a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11600,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1828 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[11]);}

/* k11598 in k11595 in a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1829 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[281]);}

/* k11601 in k11598 in k11595 in a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11603,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1830 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[280]);}

/* k11604 in k11601 in k11598 in k11595 in a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1831 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[279]);}

/* k11607 in k11604 in k11601 in k11598 in k11595 in a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11612,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1832 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[278]);}

/* k11610 in k11607 in k11604 in k11601 in k11598 in k11595 in a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_memq(lf[132],C_retrieve(lf[277])))){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=t2;
f_11618(t4,(C_word)C_eqp(C_fix(3),t3));}
else{
t3=t2;
f_11618(t3,C_SCHEME_FALSE);}}

/* k11616 in k11610 in k11607 in k11604 in k11601 in k11598 in k11595 in a11592 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_11618(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[78],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11618,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(C_word)C_i_cadr(((C_word*)t0)[9]);
t9=(C_word)C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t9);
t11=(C_word)C_a_i_cons(&a,2,lf[275],t10);
t12=(C_word)C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=(C_word)C_a_i_cons(&a,2,t8,t12);
t14=(C_word)C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[275],t15);
t17=(C_word)C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[276],t18);
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,t13,t20);
t22=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t21);
t23=(C_word)C_a_i_cons(&a,2,t22,C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,t7,t23);
t25=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=(C_word)C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,t5,t26);
t28=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t27);
t29=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t28));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[9]);}}

/* k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10708,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11544,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1843 r-c-s */
((C_proc4)C_retrieve_symbol_proc(lf[235]))(4,*((C_word*)lf[235]+1),t2,lf[274],t3);}

/* a11543 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11544,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_memq(lf[8],C_retrieve(lf[246])):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11554,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1848 r */
t9=t3;
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,lf[273]);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t2);}}

/* k11552 in a11543 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1849 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[14]);}

/* k11559 in k11552 in a11543 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11561,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11577,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1849 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t3,*((C_word*)lf[272]+1),((C_word*)t0)[4],t4);}

/* k11575 in k11559 in k11552 in a11543 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11577,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11542,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1852 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t2,lf[238]);}

/* k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11542,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[238],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11538,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1853 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[239]);}

/* k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11538,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[239],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1854 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[240]);}

/* k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11534,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[240],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1855 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[241]);}

/* k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11530,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[241],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1856 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[242]);}

/* k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11526,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[242],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1857 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[243]);}

/* k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11522,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[243],t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1858 ##sys#primitive-alias */
((C_proc3)C_retrieve_symbol_proc(lf[271]))(3,*((C_word*)lf[271]+1),t3,lf[244]);}

/* k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11518,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[244],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10714,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11386,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1859 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),t10,lf[270],t11,t9);}

/* a11385 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11386,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11390,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1862 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t5,lf[261]);}

/* k11388 in a11385 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_i_memq(t3,lf[268]);
t5=(C_truep(t4)?lf[250]:lf[269]);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1863 compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[245]))(8,*((C_word*)lf[245]+1),t2,t5,t1,((C_word*)t0)[3],t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k11391 in k11388 in a11385 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11393,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1872 r */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[12]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k11401 in k11391 in k11388 in a11385 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11447,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1872 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[243]);}

/* k11445 in k11401 in k11391 in k11388 in a11385 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11447,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1874 r */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,lf[244]);}

/* k11425 in k11445 in k11401 in k11391 in k11388 in a11385 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11427,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t6));}

/* k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11359,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1877 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),t2,lf[267],t3,((C_word*)t0)[2]);}

/* a11358 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11359(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11359,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,C_fix(3)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11369,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cadr(t2);
t8=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1881 compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[245]))(8,*((C_word*)lf[245]+1),t6,lf[240],t7,t2,t8,t3,t4);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}}

/* k11367 in a11358 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10720,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11346,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1890 r-c-s */
((C_proc5)C_retrieve_symbol_proc(lf[235]))(5,*((C_word*)lf[235]+1),t2,lf[266],t3,((C_word*)t0)[2]);}

/* a11345 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11346(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11346,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11350,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 1893 compile-format-string */
((C_proc8)C_retrieve_symbol_proc(lf[245]))(8,*((C_word*)lf[245]+1),t5,lf[264],lf[265],t2,t6,t3,t4);}

/* k11348 in a11345 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10720,2,t0,t1);}
t2=C_mutate((C_word*)lf[245]+1 /* (set! compile-format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10722,tmp=(C_word)a,a+=2,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=8) C_bad_argc_2(c,8,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_10722,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10728,a[2]=t7,a[3]=t6,a[4]=t3,a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1903 call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[263]+1)))(3,*((C_word*)lf[263]+1),t1,t8);}

/* a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10728,3,t0,t1,t2);}
t3=(C_word)C_i_length(((C_word*)t0)[7]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[6],C_retrieve(lf[246])))){
t4=(C_word)C_i_car(((C_word*)t0)[7]);
t5=(C_word)C_i_stringp(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10750,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_10750(t7,t5);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[7]);
if(C_truep((C_word)C_i_listp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11317,a[2]=((C_word*)t0)[7],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11328,a[2]=((C_word*)t0)[7],a[3]=t8,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1909 r */
t10=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,lf[27]);}
else{
t8=t6;
f_10750(t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k11326 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11332,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1909 caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}

/* k11330 in k11326 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1909 c */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11315 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11317,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11324,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1910 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[262]+1)))(3,*((C_word*)lf[262]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10750(t2,C_SCHEME_FALSE);}}

/* k11322 in k11315 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10750(t2,(C_word)C_i_stringp(t1));}

/* k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10750,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
if(C_truep((C_word)C_i_stringp(t3))){
t4=t2;
f_10753(2,t4,(C_word)C_i_car(((C_word*)t0)[8]));}
else{
/* optimizer.scm: 1911 cadar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[262]+1)))(3,*((C_word*)lf[262]+1),t2,((C_word*)t0)[8]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10753,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10758,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(C_word)C_i_string_length(t1);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t10,a[6]=t7,a[7]=t5,a[8]=t4,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1925 r */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,lf[238]);}

/* k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1926 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[239]);}

/* k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_10790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1927 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[242]);}

/* k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_10793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm: 1928 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[261]);}

/* k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_10796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1929 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[240]);}

/* k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1930 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[12]);}

/* k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1931 r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[241]);}

/* k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10804,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10814,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10886,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10833,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_10896,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t5,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[5],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[6],a[18]=((C_word*)t0)[7],a[19]=((C_word*)t0)[14],tmp=(C_word)a,a+=20,tmp));
t9=((C_word*)t7)[1];
f_10896(t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10896(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_10896,NULL,3,t0,t1,t2);}
t3=((C_word*)((C_word*)t0)[19])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[18]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10906,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=t1,a[7]=((C_word*)t0)[16],a[8]=((C_word*)t0)[17],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[12])[1]))){
t5=t4;
f_10906(2,t5,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1953 fail */
t5=((C_word*)t0)[11];
f_10758(t5,t4,C_SCHEME_FALSE,lf[257],C_SCHEME_END_OF_LIST);}}
else{
t4=f_10804(((C_word*)t0)[10]);
t5=(C_word)C_eqp(t4,C_make_character(126));
if(C_truep(t5)){
t6=f_10804(((C_word*)t0)[10]);
t7=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_10957,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[19],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[16],a[13]=t1,a[14]=((C_word*)t0)[9],a[15]=t6,tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1961 endchunk */
t8=((C_word*)t0)[13];
f_10833(t8,t7,t2);}
else{
t6=(C_word)C_a_i_cons(&a,2,t4,t2);
/* optimizer.scm: 1984 loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10957,2,t0,t1);}
t2=(C_word)C_u_i_char_upcase(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10963,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
switch(t2){
case C_make_character(83):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10984,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1963 next */
t5=((C_word*)t0)[9];
f_10814(t5,t4);
case C_make_character(65):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11009,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1964 next */
t5=((C_word*)t0)[9];
f_10814(t5,t4);
case C_make_character(67):
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11034,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1965 next */
t5=((C_word*)t0)[9];
f_10814(t5,t4);
case C_make_character(66):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11071,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1966 next */
t5=((C_word*)t0)[9];
f_10814(t5,t4);
case C_make_character(79):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11108,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1967 next */
t5=((C_word*)t0)[9];
f_10814(t5,t4);
case C_make_character(88):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11145,a[2]=((C_word*)t0)[10],a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1968 next */
t5=((C_word*)t0)[9];
f_10814(t5,t4);
case C_make_character(33):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[258],t4);
/* optimizer.scm: 1969 push */
t6=t3;
f_10963(2,t6,f_10886(C_a_i(&a,3),((C_word*)t0)[10],t5));
case C_make_character(63):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11175,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1971 next */
t5=((C_word*)t0)[9];
f_10814(t5,t4);
case C_make_character(126):
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,C_make_character(126),t4);
t6=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[242]+1),t5);
/* optimizer.scm: 1974 push */
t7=t3;
f_10963(2,t7,f_10886(C_a_i(&a,3),((C_word*)t0)[10],t6));
default:
t4=(C_word)C_eqp(t2,C_make_character(37));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(78)));
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,C_make_character(10),t6);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],t7);
/* optimizer.scm: 1975 push */
t9=t3;
f_10963(2,t9,f_10886(C_a_i(&a,3),((C_word*)t0)[10],t8));}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(((C_word*)t0)[15]))){
t6=f_10804(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=t3;
f_10963(2,t8,f_11261(t7,t6));}
else{
/* optimizer.scm: 1982 fail */
t6=((C_word*)t0)[2];
f_10758(t6,t3,C_SCHEME_TRUE,lf[260],(C_word)C_a_i_list(&a,1,((C_word*)t0)[15]));}}}}

/* skip in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static C_word C_fcall f_11261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_u_i_char_whitespacep(t1))){
t2=f_10804(((C_word*)t0)[3]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k11173 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11178,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1972 next */
t3=((C_word*)t0)[2];
f_10814(t3,t2);}

/* k11176 in k11173 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11178,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[259],t5);
/* optimizer.scm: 1973 push */
t7=((C_word*)t0)[3];
f_10963(2,t7,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t6));}

/* k11143 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11145,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(16),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* optimizer.scm: 1968 push */
t8=((C_word*)t0)[3];
f_10963(2,t8,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k11106 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11108,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(8),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* optimizer.scm: 1967 push */
t8=((C_word*)t0)[3];
f_10963(2,t8,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k11069 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11071,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_fix(2),C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
/* optimizer.scm: 1966 push */
t8=((C_word*)t0)[3];
f_10963(2,t8,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t7));}

/* k11032 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11034,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* optimizer.scm: 1965 push */
t5=((C_word*)t0)[3];
f_10963(2,t5,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k11007 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_11009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11009,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* optimizer.scm: 1964 push */
t5=((C_word*)t0)[3];
f_10963(2,t5,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k10982 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10984,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
/* optimizer.scm: 1963 push */
t5=((C_word*)t0)[3];
f_10963(2,t5,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t4));}

/* k10961 in k10955 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1983 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10896(t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10904 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10909,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1954 endchunk */
t3=((C_word*)t0)[3];
f_10833(t3,t2,((C_word*)t0)[2]);}

/* k10907 in k10904 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10909,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10928,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1956 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t6,((C_word*)((C_word*)t0)[2])[1]);}

/* k10926 in k10907 in k10904 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[256]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k10922 in k10907 in k10904 in loop in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10924,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* endchunk in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10833,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10847,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=(C_word)C_eqp(C_fix(1),t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=t3;
f_10847(t9,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t8));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10876,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1947 reverse-list->string */
((C_proc3)C_retrieve_symbol_proc(lf[255]))(3,*((C_word*)lf[255]+1),t6,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10874 in endchunk in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10876,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
f_10847(t4,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k10845 in endchunk in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10847,NULL,2,t0,t1);}
/* optimizer.scm: 1944 push */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_10886(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static C_word C_fcall f_10886(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}

/* next in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10814,NULL,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* optimizer.scm: 1938 fail */
t2=((C_word*)t0)[2];
f_10758(t2,t1,C_SCHEME_TRUE,lf[254],C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in k10800 in k10797 in k10794 in k10791 in k10788 in k10785 in k10782 in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static C_word C_fcall f_10804(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=(C_word)C_i_string_ref(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* fail in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10758(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10758,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10762,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1914 get-line */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t5,((C_word*)t0)[2]);}

/* k10760 in fail in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10765,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
/* optimizer.scm: 1919 sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[250]))(4,*((C_word*)lf[250]+1),t3,lf[251],t1);}
else{
t4=t3;
f_10775(2,t4,lf[252]);}}

/* k10773 in k10760 in fail in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1915 compiler-warning */
((C_proc9)C_retrieve_symbol_proc(lf[247]))(9,*((C_word*)lf[247]+1),((C_word*)t0)[6],lf[248],lf[249],((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10763 in k10760 in fail in k10751 in k10748 in a10727 in ##compiler#compile-format-string in k10718 in k10715 in k10712 in k11516 in k11520 in k11524 in k11528 in k11532 in k11536 in k11540 in k10706 in k10703 in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* optimizer.scm: 1921 return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##compiler#r-c-s in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_10653r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_10653r(t0,t1,t2,t3,t4);}}

static void C_ccall f_10653r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10657,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_10657(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_10657(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k10655 in ##compiler#r-c-s in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1818 ##sys#er-transformer */
((C_proc3)C_retrieve_symbol_proc(lf[237]))(3,*((C_word*)lf[237]+1),t2,((C_word*)t0)[2]);}

/* k10681 in k10655 in ##compiler#r-c-s in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10683,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_symbolp(((C_word*)t0)[3]);
t5=(C_truep(t4)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]):((C_word*)t0)[3]);
/* for-each */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t3,t5);}

/* a10664 in k10681 in k10655 in ##compiler#r-c-s in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10665,3,t0,t1,t2);}
/* optimizer.scm: 1821 ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[3]))(5,*((C_word*)lf[3]+1),t1,t2,lf[236],((C_word*)t0)[2]);}

/* ##sys#compiler-syntax-hook in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10639,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10643,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1813 alist-ref */
((C_proc6)C_retrieve_symbol_proc(lf[234]))(6,*((C_word*)lf[234]+1),t4,t2,C_retrieve(lf[231]),*((C_word*)lf[36]+1),C_fix(0));}

/* k10641 in ##sys#compiler-syntax-hook in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10647,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fixnum_increase(t1);
/* optimizer.scm: 1815 alist-update! */
((C_proc5)C_retrieve_symbol_proc(lf[233]))(5,*((C_word*)lf[233]+1),t2,((C_word*)t0)[2],t3,C_retrieve(lf[231]));}

/* k10645 in k10641 in ##sys#compiler-syntax-hook in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[231]+1 /* (set! compiler-syntax-statistics ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8995,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8998,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9098,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9394,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9638,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9857,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10058,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10307,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10394,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10541,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1783 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t15,lf[21],lf[230]);}

/* k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1784 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_8998(t3,t2);}

/* k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10547,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1785 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[229]);}

/* k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1786 build-call-graph */
t3=((C_word*)t0)[2];
f_9098(t3,t2,((C_word*)t0)[3]);}

/* k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10553,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1787 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[228]);}

/* k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10556,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1788 eliminate */
t3=((C_word*)t0)[4];
f_9295(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10556,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10559,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10633,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1789 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[220],lf[227]);}

/* k10631 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1789 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[219]))(3,*((C_word*)lf[219]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10559(2,t2,C_SCHEME_UNDEFINED);}}

/* k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1790 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[226]);}

/* k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10565,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1791 collect-accessibles */
t3=((C_word*)t0)[2];
f_9394(t3,t2,((C_word*)t0)[3]);}

/* k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10627,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1792 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[220],lf[225]);}

/* k10625 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1792 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[219]))(3,*((C_word*)lf[219]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10568(2,t2,C_SCHEME_UNDEFINED);}}

/* k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1793 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[224]);}

/* k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10574,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10624,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1794 eliminate4 */
t4=((C_word*)t0)[3];
f_9638(t4,t3,((C_word*)t0)[2]);}

/* k10622 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10624,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9604,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9604(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k10622 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9604(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9604,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9608,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1588 filter */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t4,t5,t2);}

/* a9621 in loop in k10622 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9622,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1588 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t3,t4);}

/* a9627 in a9621 in loop in k10622 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9628(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9628,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k9606 in loop in k10622 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1592 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9604(t5,((C_word*)t0)[3],t1,t2);}}

/* k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10614,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10616,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[198]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a10615 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10616,2,t0,t1);}
/* optimizer.scm: 1795 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t1,((C_word*)t0)[2]);}

/* k10612 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1795 debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),((C_word*)t0)[2],lf[8],lf[223],t1);}

/* k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1796 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[222]);}

/* k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1797 compute-extra-variables */
t3=((C_word*)t0)[2];
f_9857(t3,t2,((C_word*)t0)[5]);}

/* k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10607,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1798 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[220],lf[221]);}

/* k10605 in k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1798 pretty-print */
((C_proc3)C_retrieve_symbol_proc(lf[219]))(3,*((C_word*)lf[219]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_10586(2,t2,C_SCHEME_UNDEFINED);}}

/* k10584 in k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1799 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[218]);}

/* k10587 in k10584 in k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1800 extend-call-sites! */
t3=((C_word*)t0)[2];
f_10307(t3,t2,((C_word*)t0)[4]);}

/* k10590 in k10587 in k10584 in k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1801 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[217]);}

/* k10593 in k10590 in k10587 in k10584 in k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1802 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_10394(t3,t2,((C_word*)t0)[4]);}

/* k10596 in k10593 in k10590 in k10587 in k10584 in k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1803 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[216]);}

/* k10599 in k10596 in k10593 in k10590 in k10587 in k10584 in k10581 in k10578 in k10575 in k10572 in k10569 in k10566 in k10563 in k10560 in k10557 in k10554 in k10551 in k10548 in k10545 in k10542 in k10539 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1804 reconstruct! */
t2=((C_word*)t0)[5];
f_10058(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10394,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10400,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10400(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10400(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10400,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10419,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
/* for-each */
t13=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t10,((C_word*)((C_word*)t0)[2])[1],t12);}
else{
t10=(C_word)C_eqp(t4,lf[17]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10512,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
/* for-each */
t14=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,((C_word*)((C_word*)t0)[2])[1],t13);}
else{
/* for-each */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* k10510 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10512,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1778 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t3,((C_word*)t0)[2],lf[69]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k10519 in k10510 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1779 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10522 in k10519 in k10510 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1780 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k10417 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10419,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10424,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_10424(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3286 in k10417 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10424(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10424,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1768 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10447,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10462,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1770 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10465,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_10465(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_10465(t12,t11);}}}

/* k10463 in doloop3286 in k10417 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_10424(t4,((C_word*)t0)[2],t2,t3);}

/* k10460 in doloop3286 in k10417 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1770 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10445 in doloop3286 in k10417 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10454,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10458,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1771 reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k10456 in k10445 in doloop3286 in k10417 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1771 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k10452 in k10445 in doloop3286 in k10417 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1771 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10307,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10313,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10313(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10313,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[16]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10335,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[10],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10365,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10369,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
/* map */
t21=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[49]),t20);}
else{
t17=t11;
f_10335(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_10335(2,t14,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t10=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}

/* k10367 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1750 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1,t2);}

/* k10363 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10365,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1748 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10333 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
/* for-each */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_10058(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10058,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10070,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10072,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
/* optimizer.scm: 1684 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t4,t5,t8,t2);}

/* a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10072(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10072,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10079,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1687 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t5,((C_word*)t0)[2],t4,lf[47]);}

/* k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1688 hide-variable */
((C_proc3)C_retrieve_symbol_proc(lf[215]))(3,*((C_word*)lf[215]+1),t2,((C_word*)t0)[5]);}

/* k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10082,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10091,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1689 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t3,t4);}

/* a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10091(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10091,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10098,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[83]),t6);}

/* k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10101,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1694 map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[133]+1)))(5,*((C_word*)lf[133]+1),t2,*((C_word*)lf[134]+1),((C_word*)t0)[5],t1);}

/* k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10182,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10197,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10197(3,t9,t2,t4);}

/* walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10197,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10216,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10223,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
/* optimizer.scm: 1723 rename */
t13=((C_word*)t0)[2];
f_10182(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[17]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10253,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10264,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 1725 rename */
t15=((C_word*)t0)[2];
f_10182(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1728 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t13,t14);}
else{
/* for-each */
t13=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}}}

/* a10282 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10283,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10298,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10302,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k10300 in a10282 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1731 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10296 in a10282 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1732 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10197(3,t4,((C_word*)t0)[2],t3);}

/* k10262 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10264,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1725 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10251 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k10238 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10240,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1723 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k10221 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1720 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10214 in walk in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10182,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k10102 in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1697 gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}

/* k10151 in k10102 in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10153,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10137,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10141,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1703 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10139 in k10151 in k10102 in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1703 build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k10135 in k10151 in k10102 in k10099 in k10096 in a10090 in k10080 in k10077 in a10071 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10137,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[37],lf[14],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[37],lf[17],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t7));}

/* k10068 in reconstruct! in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10070,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1681 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9857(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9857,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9922,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10044,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a10043 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10044,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9922,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9924,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9999,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10004,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10004,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10042,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1670 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t4,((C_word*)t0)[2],t3,lf[47]);}

/* k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10042,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9866,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9866(3,t8,t4,t1);}

/* walk in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9866,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[12]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9886,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1646 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9904,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1649 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t11,t12);}
else{
/* for-each */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* a9903 in walk in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9904(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9904,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9909,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1652 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k9907 in a9903 in walk in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1653 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9866(3,t4,((C_word*)t0)[2],t3);}

/* k9884 in walk in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k9862 in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9864,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10018,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10020,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10034,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1676 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),t5,t6,*((C_word*)lf[36]+1));}

/* k10032 in k9862 in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1672 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a10019 in k9862 in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10020,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k10016 in k9862 in k10040 in a10003 in k9997 in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_10018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10018,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9924,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9992,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1661 count */
((C_proc4)C_retrieve_symbol_proc(lf[214]))(4,*((C_word*)lf[214]+1),t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a9991 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9992,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k9988 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9990,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9944,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a9977 in k9988 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9978,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1664 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9924(3,t4,t1,t3);}

/* k9942 in k9988 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9944,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9954,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9962,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9966,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9968,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a9967 in k9942 in k9988 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9968,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k9964 in k9942 in k9988 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1666 concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),((C_word*)t0)[2],t1);}

/* k9960 in k9942 in k9988 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1666 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9952 in k9942 in k9988 in walk in k9920 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9638,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9642,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9644,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9644(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9644(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9644,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9663,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_9663(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t12)){
t13=t11;
f_9663(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_9663(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[211]);
t15=t11;
f_9663(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[159])));}}}}

/* k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9663(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9663,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[12]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9674,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9674(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[14]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1611 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[16]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9749,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9760,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1617 call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9830,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a9829 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9830,3,t0,t1,t2);}
/* optimizer.scm: 1632 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9644(t3,t1,t2,((C_word*)t0)[2]);}

/* a9759 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9760(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9760,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[10],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9776,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9776(3,t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a9759 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9776,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9796,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9806,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1626 lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t7,*((C_word*)lf[36]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k9804 in loop in a9759 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9806,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_9796(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9810,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1628 delete! */
((C_proc5)C_retrieve_symbol_proc(lf[212]))(5,*((C_word*)lf[212]+1),t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[36]+1));}}

/* k9808 in k9804 in loop in a9759 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1629 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k9794 in loop in a9759 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k9747 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9754,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9753 in k9747 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9754,3,t0,t1,t2);}
/* optimizer.scm: 1631 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9644(t3,t1,t2,((C_word*)t0)[2]);}

/* a9724 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9725(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9725,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9737,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1614 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t6,t2,((C_word*)t0)[2]);}

/* k9735 in a9724 in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1614 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9644(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9674(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9674,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9692,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1606 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9695,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1608 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9644(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9693 in loop in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1609 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9674(t4,((C_word*)t0)[2],t2,t3);}

/* k9690 in loop in k9661 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1606 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9644(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9640 in eliminate4 in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9394(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9394,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9398,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9400,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_9400(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9400(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9400,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_9419(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[27]);
if(C_truep(t12)){
t13=t11;
f_9419(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[69]);
if(C_truep(t13)){
t14=t11;
f_9419(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[211]);
t15=t11;
f_9419(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[159])));}}}}

/* k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9419,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[12]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9430,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_9430(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[14]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9478,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9512,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1563 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_9478(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_9478(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9521,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a9520 in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9521,3,t0,t1,t2);}
/* optimizer.scm: 1569 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9400(t3,t1,t2,((C_word*)t0)[2]);}

/* k9510 in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_9478(t3,t2);}

/* k9476 in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9478,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1564 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t2,t3);}

/* a9486 in k9476 in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9487(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9487,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9499,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1567 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t6,t2,((C_word*)t0)[2]);}

/* k9497 in a9486 in k9476 in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1567 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9400(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9430(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9430,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9448,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1554 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9451,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1556 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9400(t6,t4,t5,((C_word*)t0)[3]);}}

/* k9449 in loop in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1557 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9430(t4,((C_word*)t0)[2],t2,t3);}

/* k9446 in loop in k9417 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1554 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9400(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9396 in collect-accessibles in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9295,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9301,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1524 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t1,t4,t3);}

/* a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9301,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9335,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9345,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1534 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t6,t5);}

/* k9343 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9345,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9350,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9350(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k9343 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9350(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9350,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9357,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1537 lset-difference */
((C_proc6)C_retrieve_symbol_proc(lf[183]))(6,*((C_word*)lf[183]+1),t5,*((C_word*)lf[36]+1),t6,t3,((C_word*)t0)[2]);}

/* k9355 in count in k9343 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9384,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1538 delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[210]))(4,*((C_word*)lf[210]+1),t2,t3,*((C_word*)lf[36]+1));}

/* k9382 in k9355 in count in k9343 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9384,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1539 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9378 in k9382 in k9355 in count in k9343 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9380,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9370,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9372,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9371 in k9378 in k9382 in k9355 in count in k9343 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9372,3,t0,t1,t2);}
/* optimizer.scm: 1540 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9350(t3,t1,t2,((C_word*)t0)[2]);}

/* k9368 in k9378 in k9382 in k9355 in count in k9343 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1540 fold */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),((C_word*)t0)[3],*((C_word*)lf[209]+1),((C_word*)t0)[2],t1);}

/* k9333 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9335,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1527 any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),((C_word*)t0)[5],t3,t4);}}

/* a9312 in k9333 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9313,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9320,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1528 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t3,((C_word*)t0)[2],t2,lf[74]);}

/* k9318 in a9312 in k9333 in a9300 in eliminate in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9098(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9098,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9101,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9250,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9252,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a9251 in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9252,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9267,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9277,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1513 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t9,t6,t10);}

/* a9276 in a9251 in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9277(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9277,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
/* optimizer.scm: 1516 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9101(t7,t1,t6,t2);}

/* k9265 in a9251 in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9271,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1517 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k9269 in k9265 in a9251 in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9248 in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9101(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9101,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[17]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_9151(2,t16,t14);}
else{
/* optimizer.scm: 1489 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t15,((C_word*)t0)[2],t12,lf[101]);}}
else{
t12=(C_word)C_eqp(t5,lf[12]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9169,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_9169(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[14]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9223,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1501 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9240,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t9);}}}}

/* a9239 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9240,3,t0,t1,t2);}
/* optimizer.scm: 1504 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9101(t3,t1,t2,((C_word*)t0)[2]);}

/* a9222 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9223(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9223,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9235,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1503 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t6,t2,((C_word*)t0)[2]);}

/* k9233 in a9222 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1503 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9101(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9169(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9169,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9187,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1496 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9193,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1498 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_9101(t7,t5,t6,((C_word*)t0)[3]);}}

/* k9191 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1499 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_9169(t4,((C_word*)t0)[2],t2,t3);}

/* k9185 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1496 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9101(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9149 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9151,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9126(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_9126(t4,t3);}}

/* k9124 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9126,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9129,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_9129(t5,t4);}
else{
t3=t2;
f_9129(t3,C_SCHEME_UNDEFINED);}}

/* k9127 in k9124 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9129,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9134,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a9133 in k9127 in k9124 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9134,3,t0,t1,t2);}
/* optimizer.scm: 1492 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9101(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8998,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9002,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9004,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1460 ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t4,t5,((C_word*)t0)[2]);}

/* a9003 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9004,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[47],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[75],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[118],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9035,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[76],t3))){
t10=t9;
f_9035(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[14],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[101],t3))){
t13=t9;
f_9035(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_9035(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_9035(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k9033 in a9003 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_9035(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9035,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1471 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k9037 in k9033 in a9003 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9039,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9043,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1472 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k9041 in k9037 in k9033 in a9003 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k9000 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_9002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7900,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8484,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8065,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7903,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8990,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1439 debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t17,lf[21],lf[206]);}

/* k8988 in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8993,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1440 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7903(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k8991 in k8988 in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_7903(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7903,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[55]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7928,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8013,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1231 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t14,((C_word*)t0)[2],t2,lf[76]);}
else{
t14=t13;
f_7928(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_7928(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[17]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
/* optimizer.scm: 1241 walk */
t24=t1;
t25=t13;
t26=t14;
t27=C_SCHEME_FALSE;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[12]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8039,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
/* optimizer.scm: 1243 walk */
t24=t14;
t25=t15;
t26=t16;
t27=t3;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8059,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t15=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t8);}}}}

/* a8058 in walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8059(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8059,3,t0,t1,t2);}
/* optimizer.scm: 1245 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7903(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8037 in walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1244 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7903(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8011 in walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8013,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_7928(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1233 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[47]);}
else{
t2=((C_word*)t0)[9];
f_7928(2,t2,C_SCHEME_FALSE);}}}

/* k7957 in k8011 in walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7959,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1234 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[75]);}
else{
t2=((C_word*)t0)[4];
f_7928(2,t2,C_SCHEME_FALSE);}}

/* k7963 in k7957 in k8011 in walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7965,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1235 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[118]);}
else{
t2=((C_word*)t0)[4];
f_7928(2,t2,C_SCHEME_FALSE);}}

/* k7969 in k7963 in k7957 in k8011 in walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7971,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1238 scan */
t9=((C_word*)t0)[4];
f_8065(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_7928(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_7928(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_7928(2,t2,C_SCHEME_FALSE);}}

/* k7926 in walk in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1239 transform */
t2=((C_word*)t0)[11];
f_8484(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1240 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7903(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8065(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8065,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8068,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8475,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1324 rec */
t18=((C_word*)t12)[1];
f_8068(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k8473 in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8475,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8482,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1325 delete */
((C_proc5)C_retrieve_symbol_proc(lf[205]))(5,*((C_word*)lf[205]+1),t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[36]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8480 in k8473 in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1325 lset= */
((C_proc5)C_retrieve_symbol_proc(lf[204]))(5,*((C_word*)lf[204]+1),((C_word*)t0)[3],*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8068,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[10]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8117,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1256 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t14,((C_word*)t0)[9],t13,lf[200]);}
else{
t13=(C_word)C_eqp(t11,lf[55]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8135,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1264 decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[88]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8172,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1273 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[192]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8206,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
/* optimizer.scm: 1276 scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[201]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8222,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
/* optimizer.scm: 1281 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[202]))(3,*((C_word*)lf[202]+1),t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[203]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8263,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
/* optimizer.scm: 1289 estimate-foreign-result-size */
((C_proc3)C_retrieve_symbol_proc(lf[202]))(3,*((C_word*)lf[202]+1),t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[16]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[10],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8316,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8344,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[10],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_8344(t35,t34);}
else{
t31=t28;
f_8344(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_8316(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_8316(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[180]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8405,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1315 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[17]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
/* optimizer.scm: 1316 rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[12]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8438,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
/* optimizer.scm: 1318 rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8462,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1320 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),t1,t22,t9);}}}}}}}}}}}

/* a8461 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8462(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8462,3,t0,t1,t2);}
/* optimizer.scm: 1320 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8068(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8436 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8438,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8449,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1319 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8447 in k8436 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1319 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8068(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a8404 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8405,3,t0,t1,t2);}
/* optimizer.scm: 1315 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8068(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8342 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_8316(t3,C_SCHEME_TRUE);}

/* k8314 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8316,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8321,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1308 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8320 in k8314 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8321(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8321,3,t0,t1,t2);}
/* optimizer.scm: 1308 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8068(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8261 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8263,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8269,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8269(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8269(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8269(t7,C_SCHEME_TRUE);}}}

/* k8267 in k8261 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8269,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8274,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1295 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8273 in k8267 in k8261 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8274,3,t0,t1,t2);}
/* optimizer.scm: 1295 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8068(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8220 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8222,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8228,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8228(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_8228(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_8228(t7,C_SCHEME_TRUE);}}}

/* k8226 in k8220 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8228,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8233,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1287 every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8232 in k8226 in k8220 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8233,3,t0,t1,t2);}
/* optimizer.scm: 1287 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8068(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k8204 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8206,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8202,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1278 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8200 in k8204 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a8171 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8172,3,t0,t1,t2);}
/* optimizer.scm: 1273 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8068(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a8134 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8135,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8151,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1268 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t8,t2,((C_word*)t0)[2]);}

/* k8149 in a8134 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1268 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8068(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k8115 in rec in scan in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8484(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8484,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8488,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8978,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8980,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[198]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1330 debugging */
((C_proc6)C_retrieve_symbol_proc(lf[7]))(6,*((C_word*)lf[7]+1),t8,lf[8],lf[199],t3,t7);}}

/* a8979 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
/* optimizer.scm: 1329 unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t1,((C_word*)t0)[2]);}

/* k8976 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1329 debugging */
((C_proc7)C_retrieve_symbol_proc(lf[7]))(7,*((C_word*)lf[7]+1),((C_word*)t0)[4],lf[8],lf[196],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8488,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8498,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1335 get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[118]);}

/* k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8498,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_listp(((C_word*)t0)[11]))){
t5=(C_word)C_i_length(((C_word*)t0)[11]);
t6=(C_word)C_eqp(t5,C_fix(4));
if(C_truep(t6)){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
t8=t4;
f_8504(t8,(C_word)C_i_listp(t7));}
else{
t7=t4;
f_8504(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8504(t5,C_SCHEME_FALSE);}}

/* k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_8504(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8504,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1339 caaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[194]+1)))(3,*((C_word*)lf[194]+1),t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm: 1437 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),((C_word*)t0)[10],lf[195],((C_word*)t0)[13]);}}

/* k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_8513,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm: 1340 cdaddr */
((C_proc3)C_retrieve_proc(*((C_word*)lf[193]+1)))(3,*((C_word*)lf[193]+1),t2,((C_word*)t0)[14]);}

/* k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8513,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1344 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t4,((C_word*)t0)[5],lf[192]);}

/* k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8695,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_8695(3,t9,t2,t5);}

/* rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8695,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[16]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[10],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8739,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1358 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8870,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1383 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t20,t2,lf[190]);}
else{
/* optimizer.scm: 1386 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t1,lf[191]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8917,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1391 alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
/* for-each */
t13=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}
else{
/* for-each */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}}

/* k8915 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8917,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8920,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1392 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t3,t4,((C_word*)t0)[3]);}

/* k8918 in k8915 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1393 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8695(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8868 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1384 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8871 in k8868 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1385 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8739,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8748,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_8748(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1361 quit */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t5,lf[186],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8794,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_8794(2,t14,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1372 quit */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t10,lf[188],((C_word*)t0)[4]);}}
else{
/* optimizer.scm: 1381 bomb */
((C_proc4)C_retrieve_symbol_proc(lf[176]))(4,*((C_word*)lf[176]+1),((C_word*)t0)[8],lf[189],((C_word*)t0)[11]);}}}

/* k8792 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1375 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t2,((C_word*)t0)[3],lf[12]);}

/* k8795 in k8792 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8824,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
/* optimizer.scm: 1376 take */
((C_proc4)C_retrieve_symbol_proc(lf[187]))(4,*((C_word*)lf[187]+1),t3,t5,C_fix(1));}

/* k8822 in k8795 in k8792 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1376 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8798 in k8795 in k8792 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8803,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[185],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1377 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t6);}

/* k8801 in k8798 in k8795 in k8792 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1380 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8695(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8746 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1364 node-class-set! */
((C_proc4)C_retrieve_symbol_proc(lf[184]))(4,*((C_word*)lf[184]+1),t2,((C_word*)t0)[3],lf[185]);}

/* k8749 in k8746 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8754,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1365 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t2,((C_word*)t0)[3],t3);}

/* k8752 in k8749 in k8746 in k8737 in rec in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1366 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8525,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8618,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8675,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8677,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1414 lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[183]))(5,*((C_word*)lf[183]+1),t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a8676 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8677(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8677,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k8673 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8617 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8618,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8628,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_8628(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1404 quit */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t5,lf[182],((C_word*)t0)[2]);}}

/* k8626 in a8617 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8628,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[180],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t2,t7);
/* optimizer.scm: 1407 node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[37],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8537,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1419 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8535 in k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8540,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8576,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1421 fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a8575 in k8535 in k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8576,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[37],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t5,t13));}

/* k8538 in k8535 in k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1430 copy-node! */
((C_proc4)C_retrieve_symbol_proc(lf[179]))(4,*((C_word*)lf[179]+1),t2,t1,((C_word*)t0)[2]);}

/* k8541 in k8538 in k8535 in k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8548,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8547 in k8541 in k8538 in k8535 in k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8548,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8555,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8574,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1434 gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t5);}

/* k8572 in a8547 in k8541 in k8538 in k8535 in k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8574,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1434 node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8553 in a8547 in k8541 in k8538 in k8535 in k8523 in k8520 in k8517 in k8511 in k8508 in k8502 in k8496 in k8486 in transform in ##compiler#transform-direct-lambdas! in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8555,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t2,t3));}

/* ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6028,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6085,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);
case C_fix(2):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6193,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t13,t12,lf[46]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6291,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[138]))){
if(C_truep(C_retrieve(lf[142]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(2),t9);
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6329,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t12,t11,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6385,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[138]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(C_fix(1),t11);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6472,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t13,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
if(C_truep(C_retrieve(lf[138]))){
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t11,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6537,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t15,t14,lf[46]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6592,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6613,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_cadddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6757,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t12,t11,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_caddr(t7);
t10=(C_truep(t9)?t9:C_retrieve(lf[142]));
if(C_truep(t10)){
t11=t4;
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6844,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t12,t11,lf[46]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6903,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6973,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_cadr(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7032,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t13,t12,lf[46]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_eqp(C_fix(1),t9);
if(C_truep(t10)){
t11=C_retrieve(lf[142]);
t12=(C_truep(t11)?t11:(C_word)C_i_cadddr(t7));
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7109,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t13,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[138]))){
t12=(C_word)C_i_not(t9);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t10,t9));
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7196,a[2]=t10,a[3]=t11,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t15,t14,lf[46]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[138]))){
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_car(t7);
t11=(C_word)C_eqp(t9,t10);
if(C_truep(t11)){
t12=t4;
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7269,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t13,t12,lf[46]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[138]))){
if(C_truep((C_word)C_i_nullp(t8))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7331,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7360,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=(C_word)C_i_length(t8);
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[142]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[138]))){
t12=(C_word)C_i_car(t7);
t13=(C_word)C_eqp(t9,t12);
if(C_truep(t13)){
t14=t4;
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7502,a[2]=t8,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t15,t14,lf[46]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7569,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=(C_word)C_i_car(t7);
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[138]))){
t12=(C_word)C_eqp(t10,t9);
if(C_truep(t12)){
t13=t4;
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7717,a[2]=t11,a[3]=t8,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t13,lf[46]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[138]))){
t9=t4;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7774,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t10,t9,lf[46]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1206 bomb */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t1,lf[177]);}}

/* k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7774,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7789,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7796,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1192 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7808,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a7807 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7808,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7816,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7822,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_7822(t9,t4,t3,t5);}

/* loop in a7807 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_7822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7822,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7842,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 816  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6053,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_6053(t8,(C_word)C_eqp(lf[27],t7));}
else{
t7=t6;
f_6053(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7871,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1204 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k7869 in loop in a7807 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7871,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6051 in loop in a7807 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 817  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 818  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7840 in loop in a7807 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7846,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1202 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7822(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k7844 in k7840 in loop in a7807 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7846,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7814 in a7807 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1195 append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a7801 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7802,2,t0,t1);}
/* optimizer.scm: 1194 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7798 in k7794 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1191 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7787 in k7772 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7789,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k7715 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7736,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7749,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1173 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_7736(t9,(C_word)C_a_i_record(&a,4,lf[37],lf[88],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7747 in k7715 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7749,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_7736(t4,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t2,t3));}

/* k7734 in k7715 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_7736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7736,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[175],t2));}

/* k7567 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7569,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7575,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1133 fifth */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7573 in k7567 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7575,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[142]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7584,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7659,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1137 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t4,t5,((C_word*)t0)[2]);}

/* a7658 in k7573 in k7567 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7659,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[27],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7582 in k7573 in k7567 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7584,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1142 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[172],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7626,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1150 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t3,t4,t1);}}}

/* a7627 in k7582 in k7573 in k7567 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7628(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7628,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[88],t5,t6));}}

/* k7624 in k7582 in k7573 in k7567 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7626,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[173],t2));}

/* k7598 in k7582 in k7573 in k7567 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[171],t2));}

/* k7500 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7502,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7530,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7529 in k7500 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7530,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7542,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1121 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t4,t5);}

/* k7540 in a7529 in k7500 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7542,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1120 append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7519 in k7500 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7520,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1119 split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[2],t2);}

/* k7513 in k7500 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7515,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[170],t3));}

/* k7358 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7360,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[142]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7369,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7441,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1088 remove */
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a7440 in k7358 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7441,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[27],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k7367 in k7358 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7369,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7385,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1093 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[166],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[147]),lf[152]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7420,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1101 fold-inner */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a7421 in k7367 in k7358 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7422,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t4,t5));}

/* k7418 in k7367 in k7358 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7420,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[167],t2));}

/* k7383 in k7367 in k7358 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7385,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[165],t2));}

/* k7329 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7331,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1075 qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7339 in k7329 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7341,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[164],t2));}

/* k7267 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7269,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[142]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_7289(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_7289(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7287 in k7267 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_7289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7289,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[163],t6));}

/* k7194 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7196,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7226,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_7226(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_7226(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_7226(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7224 in k7194 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_7226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7226,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[37],lf[88],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[162],t5));}

/* k7107 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7109,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[147]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7121,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1026 varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[147]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[161],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7126 in k7107 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1026 cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7119 in k7107 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7121,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k7030 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_7032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7032,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[147]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[142]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[142]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[160],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6971 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6973,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_6988(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_6988(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6986 in k6971 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6988(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6988,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6991,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[37],lf[159],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 999  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6989 in k6986 in k6971 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6991,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k6901 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6903,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[158],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6939,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6946,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 989  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6944 in k6901 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 989  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6937 in k6901 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6939,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k6842 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6844,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6856(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_6856(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6854 in k6842 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6856,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6862,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 974  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6867 in k6854 in k6842 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 974  cons* */
((C_proc5)C_retrieve_symbol_proc(lf[157]))(5,*((C_word*)lf[157]+1),((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6860 in k6854 in k6842 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6862,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k6755 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6757,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6779,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 956  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6777 in k6755 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 959  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,t4);}

/* k6785 in k6777 in k6755 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6791,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 961  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t2,t4);}
else{
t4=t2;
f_6791(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k6789 in k6785 in k6777 in k6755 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6791,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t2));}

/* k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6613,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 927  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6635,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[142]))){
t4=(C_word)C_eqp(C_retrieve(lf[147]),lf[156]);
t5=t3;
f_6635(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_6635(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6635,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_6638(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_6638(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[147]),lf[155]);
t6=t2;
f_6638(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k6636 in k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6638,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6697,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6696 in k6636 in k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6697,3,t0,t1,t2);}
/* optimizer.scm: 931  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t1);}

/* k6639 in k6636 in k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6644,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[49]),t1);}

/* k6642 in k6639 in k6636 in k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6649,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[147]),lf[152]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6675,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 943  fold-boolean */
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t6,t7,t1);}

/* a6674 in k6642 in k6639 in k6636 in k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6675,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[2],t4));}

/* k6671 in k6642 in k6639 in k6636 in k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6673,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[153],t2);
/* optimizer.scm: 933  fold-right */
((C_proc6)C_retrieve_symbol_proc(lf[124]))(6,*((C_word*)lf[124]+1),((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6648 in k6642 in k6639 in k6636 in k6633 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6649,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t5,t6));}

/* k6627 in k6611 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6629,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[151],t2));}

/* k6590 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6535 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6537,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 913  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6559 in k6535 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 912  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6548 in k6535 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6550,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[150],t3));}

/* k6470 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6472,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[149],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6383 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6385,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[147])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 889  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6425 in k6383 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6427,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[37],lf[139],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[148],t4));}

/* k6327 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6329,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 871  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6340 in k6327 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 874  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t3,t4);}

/* k6348 in k6340 in k6327 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t3));}

/* k6289 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 862  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6299 in k6289 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6301,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[146],t2));}

/* k6191 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[142]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[10],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6250,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
/* optimizer.scm: 853  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t10,((C_word*)t0)[2],t12,lf[145]);}
else{
t10=t7;
f_6221(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_6221(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6248 in k6191 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6221(t2,(C_word)C_eqp(lf[144],t1));}

/* k6219 in k6191 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6221,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_6218(t4,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_6218(t5,(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t4));}}

/* k6216 in k6191 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6218,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[143],t2));}

/* k6083 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6085,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[10],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[10],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6148,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 832  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_6088(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_6088(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_6088(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_6088(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6146 in k6083 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6148,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6088(t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[141],t2));}

/* k6086 in k6083 in ##compiler#simplify-named-call in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_6088(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6088,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[138]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[139],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[140],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#rewrite in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6008r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6008r(t0,t1,t2,t3);}}

static void C_ccall f_6008r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6012,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 810  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t4,C_retrieve(lf[135]),t2);}

/* k6010 in ##compiler#rewrite in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 811  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,t2,t4);}

/* k6020 in k6010 in ##compiler#rewrite in k6004 in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 811  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),((C_word*)t0)[3],C_retrieve(lf[135]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5680,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5684,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 722  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[133]+1)))(5,*((C_word*)lf[133]+1),t7,*((C_word*)lf[134]+1),t2,t3);}

/* k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5731,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 733  for-each */
((C_proc5)C_retrieve_proc(*((C_word*)lf[132]+1)))(5,*((C_word*)lf[132]+1),t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5992 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5993,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5998,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6002,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 734  scan-used-variables */
((C_proc4)C_retrieve_symbol_proc(lf[131]))(4,*((C_word*)lf[131]+1),t5,t3,((C_word*)t0)[2]);}

/* k6000 in a5992 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_6002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 734  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5996 in a5992 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5731,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a5934 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5935,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5945,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 743  filter */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t3,t4,((C_word*)t0)[2]);}}

/* a5966 in a5934 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5967,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 744  find-path */
t5=((C_word*)t0)[2];
f_5686(t5,t4,((C_word*)t0)[3],t2);}}

/* k5978 in a5966 in a5934 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 744  find-path */
t2=((C_word*)t0)[5];
f_5686(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5943 in a5934 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5949,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5961,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 746  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t3);}

/* k5959 in k5943 in a5934 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5961,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 746  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k5947 in k5943 in a5934 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5949,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5953,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 747  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k5951 in k5947 in k5943 in a5934 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5734,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5737,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5876,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 756  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[130]))(4,*((C_word*)lf[130]+1),t4,t5,t6);}

/* a5918 in a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5919,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5925,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 757  filter */
((C_proc4)C_retrieve_symbol_proc(lf[129]))(4,*((C_word*)lf[129]+1),t1,t3,((C_word*)t0)[2]);}

/* a5924 in a5918 in a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5925,3,t0,t1,t2);}
/* optimizer.scm: 757  find-path */
t3=((C_word*)t0)[3];
f_5686(t3,t1,((C_word*)t0)[2],t2);}

/* k5881 in a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5887,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5891,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5893,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 762  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a5892 in k5881 in a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5893,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5906,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 763  lset<= */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,*((C_word*)lf[36]+1),t5,((C_word*)t0)[2]);}}

/* k5904 in a5892 in k5881 in a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k5889 in k5881 in a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 760  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5885 in k5881 in a5875 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5740,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 769  topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[126]))(4,*((C_word*)lf[126]+1),t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[36]+1));}

/* k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5740,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 774  fold */
((C_proc5)C_retrieve_symbol_proc(lf[125]))(5,*((C_word*)lf[125]+1),t4,t5,((C_word*)t0)[2],t1);}

/* a5759 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5760(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5760,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5773,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_5773(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_5773(t9,C_SCHEME_FALSE);}}

/* k5771 in a5759 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5773,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5796,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5816,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 788  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5815 in k5771 in a5759 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5816(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5816,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5848,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 791  gensym */
((C_proc2)C_retrieve_symbol_proc(lf[83]))(2,*((C_word*)lf[83]+1),t4);}

/* k5846 in a5815 in k5771 in a5759 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5848,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[37],lf[17],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t2,t8));}

/* k5812 in k5771 in a5759 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 783  fold-right */
((C_proc5)C_retrieve_symbol_proc(lf[124]))(5,*((C_word*)lf[124]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5795 in k5771 in a5759 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5796,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[37],lf[12],t4,t6));}

/* k5741 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5752,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 800  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[123],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 802  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k5750 in k5741 in k5738 in k5735 in k5732 in k5729 in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 801  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5686,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5692,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5692(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5692(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5692,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5716,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 730  any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t1,t8,t5);}}}

/* a5715 in find in find-path in k5682 in ##compiler#reorganize-recursive-bindings in k5676 in k5673 in k5670 in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5716(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5716,3,t0,t1,t2);}
/* optimizer.scm: 730  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5692(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5665(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_5665r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5665r(t0,t1,t2,t3);}}

static void C_ccall f_5665r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 501  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[121]))(5,*((C_word*)lf[121]+1),t1,C_retrieve(lf[23]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5424,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5427,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5431,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5438,a[2]=t9,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 453  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t10,lf[21],lf[119]);}

/* k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5453,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t3,lf[117],lf[46]);}

/* k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5660,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 492  test */
t4=((C_word*)t0)[3];
f_5431(t4,t3,lf[117],lf[118]);}
else{
t2=((C_word*)t0)[2];
f_5441(2,t2,C_SCHEME_UNDEFINED);}}

/* k5658 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5458(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5458,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5471,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5649,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 462  test */
t10=((C_word*)t0)[2];
f_5431(t10,t9,t7,lf[76]);}

/* k5647 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5471(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 462  test */
t2=((C_word*)t0)[3];
f_5431(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[47]);}}

/* k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5474,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 463  test */
t3=((C_word*)t0)[3];
f_5431(t3,t2,((C_word*)t0)[2],lf[75]);}

/* k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=t2;
f_5480(t8,(C_word)C_eqp(lf[55],t7));}
else{
t7=t2;
f_5480(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_5480(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5480(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5480(t3,C_SCHEME_FALSE);}}

/* k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5480,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_5495(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_5495(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5495(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5495,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5501,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 474  test */
t4=((C_word*)t0)[2];
f_5431(t4,t3,t2,lf[75]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5499 in k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_5507(t6,(C_word)C_eqp(lf[11],t5));}
else{
t5=t2;
f_5507(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5507(t3,C_SCHEME_FALSE);}}

/* k5505 in k5499 in k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5507(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5507,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[10],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_5516(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_5516(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5514 in k5505 in k5499 in k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5516,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 486  node-parameters-set! */
((C_proc4)C_retrieve_symbol_proc(lf[115]))(4,*((C_word*)lf[115]+1),t4,((C_word*)t0)[2],lf[116]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5521 in k5514 in k5505 in k5499 in k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 487  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],t3);}

/* k5524 in k5521 in k5514 in k5505 in k5499 in k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5544,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 490  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[114]+1)))(3,*((C_word*)lf[114]+1),t4,t5);}

/* k5542 in k5524 in k5521 in k5514 in k5505 in k5499 in k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 488  node-subexpressions-set! */
((C_proc4)C_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5527 in k5524 in k5521 in k5514 in k5505 in k5499 in k5493 in k5478 in k5472 in k5469 in a5457 in k5451 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 491  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_5427(((C_word*)t0)[2]));}

/* k5439 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 494  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[112],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5444(2,t4,C_SCHEME_UNDEFINED);}}

/* k5442 in k5439 in k5436 in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5431(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5431,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 451  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static C_word C_fcall f_5427(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[66],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3936,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3939,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3945,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3965,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3969,a[2]=t3,a[3]=t20,a[4]=t18,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4061,a[2]=t25,a[3]=t17,a[4]=t23,a[5]=t18,a[6]=t7,a[7]=t20,a[8]=t15,tmp=(C_word)a,a+=9,tmp));
t29=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4275,a[2]=t11,a[3]=t3,a[4]=t27,a[5]=t23,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t18,tmp=(C_word)a,a+=10,tmp));
t30=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5309,a[2]=t23,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5328,a[2]=t23,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 419  perform-pre-optimization! */
((C_proc4)C_retrieve_symbol_proc(lf[111]))(4,*((C_word*)lf[111]+1),t31,t2,t3);}

/* k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5328,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 420  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5334,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 422  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t2,lf[21],lf[110]);}}

/* k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5334,2,t0,t1);}
t2=C_set_block_item(lf[24] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5338,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 424  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4061(3,t4,t3,((C_word*)t0)[2]);}

/* k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5341,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 425  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[109],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5341(2,t3,C_SCHEME_UNDEFINED);}}

/* k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5377,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[24])))){
/* optimizer.scm: 426  debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t3,lf[8],lf[108]);}
else{
t4=t3;
f_5377(2,t4,C_SCHEME_FALSE);}}

/* k5375 in k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5377,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5382,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[24]));}
else{
t2=((C_word*)t0)[2];
f_5344(2,t2,C_SCHEME_UNDEFINED);}}

/* a5381 in k5375 in k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5382,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5386,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 429  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[107]+1)))(4,*((C_word*)lf[107]+1),t3,C_make_character(9),t4);}

/* k5384 in a5381 in k5375 in k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 431  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[105]+1)))(4,*((C_word*)lf[105]+1),((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 432  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[106]+1)))(2,*((C_word*)lf[106]+1),((C_word*)t0)[2]);}}

/* k5342 in k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 434  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[104],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5347(2,t4,C_SCHEME_UNDEFINED);}}

/* k5345 in k5342 in k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 435  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[103],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5350(2,t4,C_SCHEME_UNDEFINED);}}

/* k5348 in k5345 in k5342 in k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 436  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[102],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_5353(2,t4,C_SCHEME_UNDEFINED);}}

/* k5351 in k5348 in k5345 in k5342 in k5339 in k5336 in k5332 in k5326 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 437  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5309(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5309,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5313,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k5311 in walk-generic in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5319,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 415  every */
((C_proc5)C_retrieve_symbol_proc(lf[43]))(5,*((C_word*)lf[43]+1),t2,*((C_word*)lf[36]+1),((C_word*)t0)[2],t1);}

/* k5317 in k5311 in walk-generic in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5319,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[37],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4275(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4275,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_4300(t14,t1,t10);}
else{
t10=(C_word)C_eqp(t8,lf[12]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4375,a[2]=t11,a[3]=((C_word*)t0)[8],a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 238  test */
t13=((C_word*)t0)[8];
f_3939(t13,t12,t11,lf[51]);}
else{
t11=(C_word)C_eqp(t8,lf[55]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4432,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t6,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 248  test */
t15=((C_word*)t0)[8];
f_3939(t15,t13,t14,lf[64]);}
else{
t12=(C_word)C_eqp(t8,lf[16]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t4);
t14=(C_word)C_slot(t13,C_fix(1));
t15=(C_word)C_eqp(t14,lf[10]);
if(C_truep(t15)){
t16=(C_word)C_slot(t13,C_fix(2));
t17=(C_word)C_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4608,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=t17,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5175,a[2]=t17,a[3]=((C_word*)t0)[8],a[4]=t18,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 286  test */
t20=((C_word*)t0)[8];
f_3939(t20,t19,t17,lf[76]);}
else{
t16=(C_word)C_eqp(t14,lf[55]);
if(C_truep(t16)){
if(C_truep((C_word)C_i_car(t6))){
/* optimizer.scm: 393  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_5309(t17,t1,t2,t8,t6,t4);}
else{
t17=(C_word)C_i_cdr(t6);
t18=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5200,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t20=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
/* optimizer.scm: 395  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_5309(t17,t1,t2,t8,t6,t4);}}}
else{
t13=(C_word)C_eqp(t8,lf[17]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t6);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5225,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t14,a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 399  test */
t16=((C_word*)t0)[8];
f_3939(t16,t15,t14,lf[53]);}
else{
/* optimizer.scm: 411  walk-generic */
t14=((C_word*)((C_word*)t0)[4])[1];
f_5309(t14,t1,t2,t8,t6,t4);}}}}}}

/* k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_5228(2,t3,t1);}
else{
/* optimizer.scm: 399  test */
t3=((C_word*)t0)[2];
f_3939(t3,t2,((C_word*)t0)[7],lf[51]);}}

/* k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
if(C_truep(t1)){
t2=f_3965(((C_word*)t0)[9]);
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5240,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 402  test */
t4=((C_word*)t0)[2];
f_3939(t4,t3,((C_word*)t0)[7],lf[101]);}}

/* k5299 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5269(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5297,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 403  variable-visible? */
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t4,((C_word*)t0)[2]);}}

/* k5295 in k5299 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5269(t2,(C_word)C_i_not(t1));}

/* k5267 in k5299 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5269,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 404  test */
t3=((C_word*)t0)[3];
f_3939(t3,t2,((C_word*)t0)[2],lf[75]);}
else{
t2=((C_word*)t0)[6];
f_5240(t2,C_SCHEME_FALSE);}}

/* k5288 in k5267 in k5299 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5290,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5240(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 405  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}}

/* k5280 in k5288 in k5267 in k5299 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5240(t2,(C_word)C_i_not(t1));}

/* k5238 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5240(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5240,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3965(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 407  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t3,lf[8],lf[99],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5259,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 409  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4061(3,t4,t2,t3);}}

/* k5257 in k5238 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5259,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[17],((C_word*)t0)[2],t2));}

/* k5244 in k5238 in k5226 in k5223 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5246,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k5198 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k5173 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5175,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4608(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 287  test */
t3=((C_word*)t0)[3];
f_3939(t3,t2,((C_word*)t0)[2],lf[47]);}}

/* k5163 in k5173 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4608(2,t2,t1);}
else{
/* optimizer.scm: 288  test */
t2=((C_word*)t0)[3];
f_3939(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[98]);}}

/* k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4608,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t1,tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 290  test */
t4=((C_word*)t0)[4];
f_3939(t4,t3,((C_word*)t0)[10],lf[53]);}

/* k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4617,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t3,a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 293  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t4,((C_word*)t0)[11],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[68])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[10],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4784,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 301  test */
t10=((C_word*)t0)[4];
f_3939(t10,t9,t7,lf[76]);}
else{
t8=t3;
f_4659(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_4659(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4659(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4798,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t4=t2;
f_4798(t4,(C_word)C_eqp(lf[55],t3));}
else{
t3=t2;
f_4798(t3,C_SCHEME_FALSE);}}}}

/* k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4798,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 317  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[2],t3,t4);}
else{
/* optimizer.scm: 390  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_5309(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4809,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_4819,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
if(C_truep(C_retrieve(lf[91]))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[17],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 322  test */
t8=((C_word*)t0)[3];
f_3939(t8,t7,t5,lf[97]);}
else{
t7=t6;
f_4819(t7,C_SCHEME_FALSE);}}

/* k5119 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5121,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 323  test */
t3=((C_word*)t0)[2];
f_3939(t3,t2,((C_word*)t0)[3],lf[96]);}
else{
t2=((C_word*)t0)[5];
f_4819(t2,C_SCHEME_FALSE);}}

/* k5125 in k5119 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t2,((C_word*)t0)[2],lf[95]);}
else{
t2=((C_word*)t0)[4];
f_4819(t2,C_SCHEME_FALSE);}}

/* k5128 in k5125 in k5119 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(t1,lf[92]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4819(t3,C_SCHEME_TRUE);}
else{
t3=(C_word)C_eqp(t1,lf[93]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4819(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t5=C_retrieve(lf[94]);
t6=((C_word*)t0)[3];
f_4819(t6,(C_word)C_fixnum_lessp(t4,t5));}}}

/* k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4819(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4819,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4822,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4857,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[15],a[4]=t2,a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t3,((C_word*)t0)[15],lf[81]);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_4866,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 339  test */
t3=((C_word*)t0)[4];
f_3939(t3,t2,((C_word*)t0)[13],lf[64]);}}

/* k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4866,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 341  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_5309(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4880(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5025,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[16],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[19],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5108,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 365  test */
t4=((C_word*)t0)[6];
f_3939(t4,t3,((C_word*)t0)[2],lf[60]);}}

/* k5106 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_5025(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_5025(t2,C_SCHEME_FALSE);}}

/* k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_5025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5025,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 367  llist-length */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[3]);}
else{
/* optimizer.scm: 389  walk-generic */
t2=((C_word*)((C_word*)t0)[12])[1];
f_5309(t2,((C_word*)t0)[11],((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k5026 in k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5028,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[11]);
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 369  walk-generic */
t4=((C_word*)((C_word*)t0)[10])[1];
f_5309(t4,((C_word*)t0)[9],t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5040,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 371  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[7]))(6,*((C_word*)lf[7]+1),t4,lf[8],lf[89],((C_word*)t0)[2],t1);}}

/* k5038 in k5026 in k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5050 in k5038 in k5026 in k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5051,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5055,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5070,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5078,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 382  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t6,C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_i_length(t3);
t8=(C_word)C_fixnum_times(C_fix(3),t7);
t9=(C_word)C_a_i_list(&a,2,lf[87],t8);
t10=t6;
f_5078(2,t10,(C_word)C_a_i_record(&a,4,lf[37],lf[88],t9,t3));}}

/* k5076 in a5050 in k5038 in k5026 in k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5078,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 378  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5068 in a5050 in k5038 in k5026 in k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5070,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k5053 in a5050 in k5038 in k5026 in k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a5044 in k5038 in k5026 in k5023 in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5045,2,t0,t1);}
/* optimizer.scm: 372  split-at */
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4880(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4880,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_3965(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 348  append-reverse */
((C_proc4)C_retrieve_symbol_proc(lf[82]))(4,*((C_word*)lf[82]+1),t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 349  test */
t10=((C_word*)t0)[2];
f_3939(t10,t8,t9,lf[56]);}}

/* k4911 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4913,2,t0,t1);}
if(C_truep(t1)){
t2=f_3965(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 351  debugging */
((C_proc6)C_retrieve_symbol_proc(lf[7]))(6,*((C_word*)lf[7]+1),t3,lf[8],lf[85],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 361  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_4880(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k4917 in k4911 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 354  expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}

/* k4923 in k4917 in k4911 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 357  gensym */
((C_proc3)C_retrieve_symbol_proc(lf[83]))(3,*((C_word*)lf[83]+1),t2,lf[84]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 360  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4880(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k4960 in k4923 in k4917 in k4911 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 358  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4061(3,t5,t3,t4);}

/* k4936 in k4960 in k4923 in k4917 in k4911 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 359  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4880(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4940 in k4936 in k4960 in k4923 in k4917 in k4911 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t2));}

/* k4905 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4907,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k4894 in loop in k4864 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[16],((C_word*)t0)[2],t1));}

/* k4855 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_structurep(t1,lf[37]);
t3=(C_truep(t2)?lf[78]:lf[79]);
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* optimizer.scm: 329  debugging */
((C_proc7)C_retrieve_symbol_proc(lf[7]))(7,*((C_word*)lf[7]+1),((C_word*)t0)[4],lf[80],t3,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4820 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 335  check-signature */
((C_proc5)C_retrieve_symbol_proc(lf[67]))(5,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4823 in k4820 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 336  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[77],((C_word*)t0)[2]);}

/* k4826 in k4823 in k4820 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=f_3965(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 338  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[65]))(6,*((C_word*)lf[65]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_TRUE);}

/* k4836 in k4826 in k4823 in k4820 in k4817 in a4808 in k4796 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 338  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4061(3,t2,((C_word*)t0)[2],t1);}

/* k4782 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4680(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 301  test */
t2=((C_word*)t0)[3];
f_3939(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[47]);}}

/* k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_eqp(lf[55],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_caddr(t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4701,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t5);
/* optimizer.scm: 304  test */
t8=((C_word*)t0)[2];
f_3939(t8,t6,t7,lf[56]);}
else{
t6=((C_word*)t0)[7];
f_4659(t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[7];
f_4659(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_4659(t2,C_SCHEME_FALSE);}}

/* k4699 in k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4704,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4704(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 305  test */
t5=((C_word*)t0)[2];
f_3939(t5,t3,t4,lf[75]);}}

/* k4756 in k4699 in k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4704(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 306  test */
t4=((C_word*)t0)[2];
f_3939(t4,t2,t3,lf[74]);}}

/* k4748 in k4756 in k4699 in k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4704(t2,(C_word)C_i_not(t1));}

/* k4702 in k4699 in k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4704,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4729,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 307  any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_4659(t2,C_SCHEME_FALSE);}}

/* a4728 in k4702 in k4699 in k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4729,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
((C_proc4)C_retrieve_symbol_proc(lf[73]))(4,*((C_word*)lf[73]+1),t1,t2,((C_word*)t0)[2]);}

/* k4725 in k4702 in k4699 in k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4727,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4659(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4713,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 308  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[71],lf[72],((C_word*)t0)[2]);}}

/* k4711 in k4725 in k4702 in k4699 in k4678 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[37],lf[69],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4659(t4,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[70],t3));}

/* k4657 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4659(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 312  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_5309(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4624 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4629,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 294  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[66],((C_word*)t0)[2]);}

/* k4627 in k4624 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4629,2,t0,t1);}
t2=f_3965(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 296  inline-lambda-bindings */
((C_proc6)C_retrieve_symbol_proc(lf[65]))(6,*((C_word*)lf[65]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4637 in k4627 in k4624 in k4615 in k4606 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 296  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4061(3,t2,((C_word*)t0)[2],t1);}

/* k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4437,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 249  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 264  test */
t4=((C_word*)t0)[11];
f_3939(t4,t2,t3,lf[60]);}}

/* k4522 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4529,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 265  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[62]))(4,*((C_word*)lf[62]+1),((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 277  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5309(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a4528 in k4522 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4529(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4529,5,t0,t1,t2,t3,t4);}
t5=f_3965(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4536,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 269  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t6,lf[8],lf[63],t4);}

/* k4534 in a4528 in k4522 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 274  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4563 in k4534 in a4528 in k4522 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4549,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 276  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4061(3,t6,t4,t5);}

/* k4547 in k4563 in k4534 in a4528 in k4522 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4549,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[55],((C_word*)t0)[2],t2));}

/* a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4437,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4443,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4454 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4455,4,t0,t1,t2,t3);}
t4=f_3965(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 254  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t5,lf[8],lf[61],t2);}

/* k4460 in a4454 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4491,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 258  test */
t7=((C_word*)t0)[2];
f_3939(t7,t5,t6,lf[60]);}
else{
t6=t5;
f_4498(2,t6,C_SCHEME_FALSE);}}

/* k4496 in k4460 in a4454 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4498,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 259  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[59],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 261  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4499 in k4496 in k4460 in a4454 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 260  build-lambda-list */
((C_proc5)C_retrieve_symbol_proc(lf[58]))(5,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4489 in k4460 in a4454 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4491,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 263  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4061(3,t6,t4,t5);}

/* k4473 in k4489 in k4460 in a4454 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4475,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[55],((C_word*)t0)[2],t2));}

/* a4442 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 252  partition */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t1,t2,((C_word*)t0)[2]);}

/* a4448 in a4442 in a4436 in k4430 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4449,3,t0,t1,t2);}
/* optimizer.scm: 252  test */
t3=((C_word*)t0)[2];
f_3939(t3,t1,t2,lf[56]);}

/* k4373 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4378,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_4378(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 239  test */
t4=((C_word*)t0)[3];
f_3939(t4,t3,((C_word*)t0)[2],lf[54]);}}

/* k4399 in k4373 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4401,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4378(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 240  test */
t3=((C_word*)t0)[3];
f_3939(t3,t2,((C_word*)t0)[2],lf[53]);}}

/* k4408 in k4399 in k4373 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 240  test */
t3=((C_word*)t0)[3];
f_3939(t3,t2,((C_word*)t0)[2],lf[52]);}
else{
t2=((C_word*)t0)[4];
f_4378(t2,C_SCHEME_FALSE);}}

/* k4415 in k4408 in k4399 in k4373 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4378(t2,(C_word)C_i_not(t1));}

/* k4376 in k4373 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4378,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3965(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 243  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4061(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k4393 in k4376 in k4373 in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4395,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[37],lf[12],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4300,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 224  test */
t4=((C_word*)t0)[4];
f_3939(t4,t3,t2,lf[51]);}

/* k4302 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4304,2,t0,t1);}
if(C_truep(t1)){
/* replace328 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4300(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 225  test */
t3=((C_word*)t0)[5];
f_3939(t3,t2,((C_word*)t0)[4],lf[50]);}}

/* k4314 in k4302 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4316,2,t0,t1);}
if(C_truep(t1)){
t2=f_3965(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 227  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t3,lf[8],lf[48],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_4339(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_3965(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_4339(t8,t7);}}}

/* k4337 in k4314 in k4302 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 234  varnode */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4320 in k4314 in k4302 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4333,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 228  test */
t3=((C_word*)t0)[3];
f_3939(t3,t2,((C_word*)t0)[2],lf[47]);}

/* k4331 in k4320 in k4314 in k4302 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
/* optimizer.scm: 228  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4061,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[34])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[8])[1];
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4075,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 178  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4275(t5,t4,t2);}}

/* k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4075,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[11]);
if(C_truep(t5)){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_eqp(lf[27],t7);
if(C_truep(t8)){
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t10=C_mutate(((C_word *)((C_word*)t0)[7])+1,t9);
t11=f_3965(((C_word*)t0)[6]);
t12=(C_word)C_i_car(t2);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_i_car(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
/* optimizer.scm: 186  walk */
t16=((C_word*)((C_word*)t0)[5])[1];
f_4061(3,t16,t4,t15);}
else{
t9=t4;
f_4084(2,t9,t1);}}
else{
t6=(C_word)C_eqp(t3,lf[16]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[10],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4145,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=t12,tmp=(C_word)a,a+=9,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4246,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=t13,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[45]))(4,*((C_word*)lf[45]+1),t14,t12,lf[46]);}
else{
t10=t4;
f_4084(2,t10,t1);}}
else{
t7=t4;
f_4084(2,t7,t1);}}}

/* k4244 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 195  foldable? */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_4145(2,t2,C_SCHEME_FALSE);}}

/* k4250 in k4244 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 196  every */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_4145(2,t2,C_SCHEME_FALSE);}}

/* k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4227,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* map */
t5=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[7];
f_4084(2,t2,((C_word*)t0)[6]);}}

/* a4226 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4227(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4227,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_cons(&a,2,lf[27],t5));}

/* k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4225,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4156,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t3,t4);}

/* a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4156,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4162,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4179,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t1,t3,t4);}

/* a4178 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4211,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4210 in a4178 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4211r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4211r(t0,t1,t2);}}

static void C_ccall f_4211r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4217,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k277283 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4216 in a4210 in a4178 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4217,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4184 in a4178 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 204  eval */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,((C_word*)t0)[2]);}

/* k4187 in a4184 in a4178 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4192,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 205  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[40],((C_word*)t0)[2]);}

/* k4190 in k4187 in a4184 in a4178 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4192,2,t0,t1);}
t2=f_3965(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4209,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 210  qnode */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t4,((C_word*)t0)[2]);}

/* k4207 in k4190 in k4187 in a4184 in a4178 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[37],lf[16],lf[38],t2));}

/* a4161 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4162,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k277283 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4167 in a4161 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_4172(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_4172(t4,t3);}}

/* k4170 in a4167 in a4161 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4172,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 202  lset-adjoin */
((C_proc5)C_retrieve_symbol_proc(lf[35]))(5,*((C_word*)lf[35]+1),t2,*((C_word*)lf[36]+1),C_retrieve(lf[34]),((C_word*)t0)[2]);}

/* k4174 in k4170 in a4167 in a4161 in a4155 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[34]+1 /* (set! broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k4152 in k4223 in k4143 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4082 in k4073 in walk in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 176  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3969(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_3969(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3969,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
/* optimizer.scm: 157  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t3,C_retrieve(lf[23]),t5);}

/* k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3976,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3984,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 158  any */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t2,t3,t1);}
else{
t3=t2;
f_3976(2,t3,C_SCHEME_FALSE);}}

/* a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3984,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3994,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 160  match-node */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3992 in a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4043,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4042 in k3992 in a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4043,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k4039 in k3992 in a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3998 in k3992 in a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4006,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 163  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4004 in k3998 in k3992 in a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4006,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_4012(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4033,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 167  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[28]))(5,*((C_word*)lf[28]+1),t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k4031 in k4004 in k3998 in k3992 in a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4012(t3,t2);}

/* k4010 in k4004 in k3998 in k3992 in a3983 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_4012(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_3965(((C_word*)t0)[5]);
/* optimizer.scm: 169  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3969(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3974 in k3971 in simplify in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static C_word C_fcall f_3965(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* constant-node? in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3945,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[27],t3));}

/* test in ##compiler#perform-high-level-optimizations in k3931 in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_3939(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3939,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 151  get */
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3698(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3698,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3701,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3719,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 83   debugging */
((C_proc4)C_retrieve_symbol_proc(lf[7]))(4,*((C_word*)lf[7]+1),t8,lf[21],lf[22]);}

/* k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3722,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 84   call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,t3);}

/* a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3763(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3763,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3766,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3778,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 119  scan */
t9=((C_word*)t6)[1];
f_3778(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_3778(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3778,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3803,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_3803(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_3803(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[11]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_3830(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[18]);
t14=t12;
f_3830(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[19])));}}}

/* k3828 in scan in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_3830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 101  scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_3778(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[12]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 105  scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_3778(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[14]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[15]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[16]);
if(C_truep(t5)){
/* optimizer.scm: 110  return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[17]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))){
t9=t8;
f_3894(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 114  mark */
t9=((C_word*)t0)[3];
f_3701(3,t9,t8,t7);}}
else{
/* optimizer.scm: 117  scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3766(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k3892 in k3828 in scan in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 115  scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3778(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k3847 in k3828 in scan in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3860,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 106  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3858 in k3847 in k3828 in scan in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 106  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3778(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3831 in k3828 in scan in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 102  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k3801 in scan in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_3803(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3803,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_fcall f_3766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3766,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3772,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3771 in scan-each in a3762 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3772,3,t0,t1,t2);}
/* optimizer.scm: 88   scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3778(t3,t1,t2,((C_word*)t0)[2]);}

/* k3720 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3725,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 120  debugging */
((C_proc5)C_retrieve_symbol_proc(lf[7]))(5,*((C_word*)lf[7]+1),t2,lf[8],lf[9],((C_word*)((C_word*)t0)[2])[1]);}

/* k3723 in k3720 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3730,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a3729 in k3723 in k3720 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3730,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3735,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[5]);}

/* f_3735 in a3729 in k3723 in k3720 in k3717 in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3735r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3735r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3735r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3739,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3739(2,t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3739(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3737 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[3]))(5,*((C_word*)lf[3]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* mark in ##compiler#scan-toplevel-assignments in k3694 in k3691 in k3688 in k3685 in k3682 in k3679 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3701,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[3])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[668] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_3681:optimizer_scm",(void*)f_3681},
{"f_3684:optimizer_scm",(void*)f_3684},
{"f_3687:optimizer_scm",(void*)f_3687},
{"f_3690:optimizer_scm",(void*)f_3690},
{"f_3693:optimizer_scm",(void*)f_3693},
{"f_3696:optimizer_scm",(void*)f_3696},
{"f_3933:optimizer_scm",(void*)f_3933},
{"f_13060:optimizer_scm",(void*)f_13060},
{"f_13068:optimizer_scm",(void*)f_13068},
{"f_13073:optimizer_scm",(void*)f_13073},
{"f_13118:optimizer_scm",(void*)f_13118},
{"f_13122:optimizer_scm",(void*)f_13122},
{"f_13083:optimizer_scm",(void*)f_13083},
{"f_13107:optimizer_scm",(void*)f_13107},
{"f_13092:optimizer_scm",(void*)f_13092},
{"f_5672:optimizer_scm",(void*)f_5672},
{"f_12099:optimizer_scm",(void*)f_12099},
{"f_12133:optimizer_scm",(void*)f_12133},
{"f_12235:optimizer_scm",(void*)f_12235},
{"f_12245:optimizer_scm",(void*)f_12245},
{"f_12309:optimizer_scm",(void*)f_12309},
{"f_12338:optimizer_scm",(void*)f_12338},
{"f_12461:optimizer_scm",(void*)f_12461},
{"f_12354:optimizer_scm",(void*)f_12354},
{"f_12401:optimizer_scm",(void*)f_12401},
{"f_12391:optimizer_scm",(void*)f_12391},
{"f_12399:optimizer_scm",(void*)f_12399},
{"f_12531:optimizer_scm",(void*)f_12531},
{"f_12544:optimizer_scm",(void*)f_12544},
{"f_12579:optimizer_scm",(void*)f_12579},
{"f_12563:optimizer_scm",(void*)f_12563},
{"f_12567:optimizer_scm",(void*)f_12567},
{"f_12556:optimizer_scm",(void*)f_12556},
{"f_12745:optimizer_scm",(void*)f_12745},
{"f_12758:optimizer_scm",(void*)f_12758},
{"f_12764:optimizer_scm",(void*)f_12764},
{"f_12810:optimizer_scm",(void*)f_12810},
{"f_12802:optimizer_scm",(void*)f_12802},
{"f_12786:optimizer_scm",(void*)f_12786},
{"f_12790:optimizer_scm",(void*)f_12790},
{"f_12794:optimizer_scm",(void*)f_12794},
{"f_5675:optimizer_scm",(void*)f_5675},
{"f_11777:optimizer_scm",(void*)f_11777},
{"f_11799:optimizer_scm",(void*)f_11799},
{"f_11854:optimizer_scm",(void*)f_11854},
{"f_11824:optimizer_scm",(void*)f_11824},
{"f_11846:optimizer_scm",(void*)f_11846},
{"f_11850:optimizer_scm",(void*)f_11850},
{"f_11842:optimizer_scm",(void*)f_11842},
{"f_11822:optimizer_scm",(void*)f_11822},
{"f_11948:optimizer_scm",(void*)f_11948},
{"f_11962:optimizer_scm",(void*)f_11962},
{"f_5678:optimizer_scm",(void*)f_5678},
{"f_6006:optimizer_scm",(void*)f_6006},
{"f_11751:optimizer_scm",(void*)f_11751},
{"f_11593:optimizer_scm",(void*)f_11593},
{"f_11597:optimizer_scm",(void*)f_11597},
{"f_11600:optimizer_scm",(void*)f_11600},
{"f_11603:optimizer_scm",(void*)f_11603},
{"f_11606:optimizer_scm",(void*)f_11606},
{"f_11609:optimizer_scm",(void*)f_11609},
{"f_11612:optimizer_scm",(void*)f_11612},
{"f_11618:optimizer_scm",(void*)f_11618},
{"f_10705:optimizer_scm",(void*)f_10705},
{"f_11544:optimizer_scm",(void*)f_11544},
{"f_11554:optimizer_scm",(void*)f_11554},
{"f_11561:optimizer_scm",(void*)f_11561},
{"f_11577:optimizer_scm",(void*)f_11577},
{"f_10708:optimizer_scm",(void*)f_10708},
{"f_11542:optimizer_scm",(void*)f_11542},
{"f_11538:optimizer_scm",(void*)f_11538},
{"f_11534:optimizer_scm",(void*)f_11534},
{"f_11530:optimizer_scm",(void*)f_11530},
{"f_11526:optimizer_scm",(void*)f_11526},
{"f_11522:optimizer_scm",(void*)f_11522},
{"f_11518:optimizer_scm",(void*)f_11518},
{"f_11386:optimizer_scm",(void*)f_11386},
{"f_11390:optimizer_scm",(void*)f_11390},
{"f_11393:optimizer_scm",(void*)f_11393},
{"f_11403:optimizer_scm",(void*)f_11403},
{"f_11447:optimizer_scm",(void*)f_11447},
{"f_11427:optimizer_scm",(void*)f_11427},
{"f_10714:optimizer_scm",(void*)f_10714},
{"f_11359:optimizer_scm",(void*)f_11359},
{"f_11369:optimizer_scm",(void*)f_11369},
{"f_10717:optimizer_scm",(void*)f_10717},
{"f_11346:optimizer_scm",(void*)f_11346},
{"f_11350:optimizer_scm",(void*)f_11350},
{"f_10720:optimizer_scm",(void*)f_10720},
{"f_10722:optimizer_scm",(void*)f_10722},
{"f_10728:optimizer_scm",(void*)f_10728},
{"f_11328:optimizer_scm",(void*)f_11328},
{"f_11332:optimizer_scm",(void*)f_11332},
{"f_11317:optimizer_scm",(void*)f_11317},
{"f_11324:optimizer_scm",(void*)f_11324},
{"f_10750:optimizer_scm",(void*)f_10750},
{"f_10753:optimizer_scm",(void*)f_10753},
{"f_10784:optimizer_scm",(void*)f_10784},
{"f_10787:optimizer_scm",(void*)f_10787},
{"f_10790:optimizer_scm",(void*)f_10790},
{"f_10793:optimizer_scm",(void*)f_10793},
{"f_10796:optimizer_scm",(void*)f_10796},
{"f_10799:optimizer_scm",(void*)f_10799},
{"f_10802:optimizer_scm",(void*)f_10802},
{"f_10896:optimizer_scm",(void*)f_10896},
{"f_10957:optimizer_scm",(void*)f_10957},
{"f_11261:optimizer_scm",(void*)f_11261},
{"f_11175:optimizer_scm",(void*)f_11175},
{"f_11178:optimizer_scm",(void*)f_11178},
{"f_11145:optimizer_scm",(void*)f_11145},
{"f_11108:optimizer_scm",(void*)f_11108},
{"f_11071:optimizer_scm",(void*)f_11071},
{"f_11034:optimizer_scm",(void*)f_11034},
{"f_11009:optimizer_scm",(void*)f_11009},
{"f_10984:optimizer_scm",(void*)f_10984},
{"f_10963:optimizer_scm",(void*)f_10963},
{"f_10906:optimizer_scm",(void*)f_10906},
{"f_10909:optimizer_scm",(void*)f_10909},
{"f_10928:optimizer_scm",(void*)f_10928},
{"f_10924:optimizer_scm",(void*)f_10924},
{"f_10833:optimizer_scm",(void*)f_10833},
{"f_10876:optimizer_scm",(void*)f_10876},
{"f_10847:optimizer_scm",(void*)f_10847},
{"f_10886:optimizer_scm",(void*)f_10886},
{"f_10814:optimizer_scm",(void*)f_10814},
{"f_10804:optimizer_scm",(void*)f_10804},
{"f_10758:optimizer_scm",(void*)f_10758},
{"f_10762:optimizer_scm",(void*)f_10762},
{"f_10775:optimizer_scm",(void*)f_10775},
{"f_10765:optimizer_scm",(void*)f_10765},
{"f_10653:optimizer_scm",(void*)f_10653},
{"f_10657:optimizer_scm",(void*)f_10657},
{"f_10683:optimizer_scm",(void*)f_10683},
{"f_10665:optimizer_scm",(void*)f_10665},
{"f_10639:optimizer_scm",(void*)f_10639},
{"f_10643:optimizer_scm",(void*)f_10643},
{"f_10647:optimizer_scm",(void*)f_10647},
{"f_8995:optimizer_scm",(void*)f_8995},
{"f_10541:optimizer_scm",(void*)f_10541},
{"f_10544:optimizer_scm",(void*)f_10544},
{"f_10547:optimizer_scm",(void*)f_10547},
{"f_10550:optimizer_scm",(void*)f_10550},
{"f_10553:optimizer_scm",(void*)f_10553},
{"f_10556:optimizer_scm",(void*)f_10556},
{"f_10633:optimizer_scm",(void*)f_10633},
{"f_10559:optimizer_scm",(void*)f_10559},
{"f_10562:optimizer_scm",(void*)f_10562},
{"f_10565:optimizer_scm",(void*)f_10565},
{"f_10627:optimizer_scm",(void*)f_10627},
{"f_10568:optimizer_scm",(void*)f_10568},
{"f_10571:optimizer_scm",(void*)f_10571},
{"f_10624:optimizer_scm",(void*)f_10624},
{"f_9604:optimizer_scm",(void*)f_9604},
{"f_9622:optimizer_scm",(void*)f_9622},
{"f_9628:optimizer_scm",(void*)f_9628},
{"f_9608:optimizer_scm",(void*)f_9608},
{"f_10574:optimizer_scm",(void*)f_10574},
{"f_10616:optimizer_scm",(void*)f_10616},
{"f_10614:optimizer_scm",(void*)f_10614},
{"f_10577:optimizer_scm",(void*)f_10577},
{"f_10580:optimizer_scm",(void*)f_10580},
{"f_10583:optimizer_scm",(void*)f_10583},
{"f_10607:optimizer_scm",(void*)f_10607},
{"f_10586:optimizer_scm",(void*)f_10586},
{"f_10589:optimizer_scm",(void*)f_10589},
{"f_10592:optimizer_scm",(void*)f_10592},
{"f_10595:optimizer_scm",(void*)f_10595},
{"f_10598:optimizer_scm",(void*)f_10598},
{"f_10601:optimizer_scm",(void*)f_10601},
{"f_10394:optimizer_scm",(void*)f_10394},
{"f_10400:optimizer_scm",(void*)f_10400},
{"f_10512:optimizer_scm",(void*)f_10512},
{"f_10521:optimizer_scm",(void*)f_10521},
{"f_10524:optimizer_scm",(void*)f_10524},
{"f_10419:optimizer_scm",(void*)f_10419},
{"f_10424:optimizer_scm",(void*)f_10424},
{"f_10465:optimizer_scm",(void*)f_10465},
{"f_10462:optimizer_scm",(void*)f_10462},
{"f_10447:optimizer_scm",(void*)f_10447},
{"f_10458:optimizer_scm",(void*)f_10458},
{"f_10454:optimizer_scm",(void*)f_10454},
{"f_10307:optimizer_scm",(void*)f_10307},
{"f_10313:optimizer_scm",(void*)f_10313},
{"f_10369:optimizer_scm",(void*)f_10369},
{"f_10365:optimizer_scm",(void*)f_10365},
{"f_10335:optimizer_scm",(void*)f_10335},
{"f_10058:optimizer_scm",(void*)f_10058},
{"f_10072:optimizer_scm",(void*)f_10072},
{"f_10079:optimizer_scm",(void*)f_10079},
{"f_10082:optimizer_scm",(void*)f_10082},
{"f_10091:optimizer_scm",(void*)f_10091},
{"f_10098:optimizer_scm",(void*)f_10098},
{"f_10101:optimizer_scm",(void*)f_10101},
{"f_10197:optimizer_scm",(void*)f_10197},
{"f_10283:optimizer_scm",(void*)f_10283},
{"f_10302:optimizer_scm",(void*)f_10302},
{"f_10298:optimizer_scm",(void*)f_10298},
{"f_10264:optimizer_scm",(void*)f_10264},
{"f_10253:optimizer_scm",(void*)f_10253},
{"f_10240:optimizer_scm",(void*)f_10240},
{"f_10223:optimizer_scm",(void*)f_10223},
{"f_10216:optimizer_scm",(void*)f_10216},
{"f_10182:optimizer_scm",(void*)f_10182},
{"f_10104:optimizer_scm",(void*)f_10104},
{"f_10153:optimizer_scm",(void*)f_10153},
{"f_10141:optimizer_scm",(void*)f_10141},
{"f_10137:optimizer_scm",(void*)f_10137},
{"f_10070:optimizer_scm",(void*)f_10070},
{"f_9857:optimizer_scm",(void*)f_9857},
{"f_10044:optimizer_scm",(void*)f_10044},
{"f_9922:optimizer_scm",(void*)f_9922},
{"f_9999:optimizer_scm",(void*)f_9999},
{"f_10004:optimizer_scm",(void*)f_10004},
{"f_10042:optimizer_scm",(void*)f_10042},
{"f_9866:optimizer_scm",(void*)f_9866},
{"f_9904:optimizer_scm",(void*)f_9904},
{"f_9909:optimizer_scm",(void*)f_9909},
{"f_9886:optimizer_scm",(void*)f_9886},
{"f_9864:optimizer_scm",(void*)f_9864},
{"f_10034:optimizer_scm",(void*)f_10034},
{"f_10020:optimizer_scm",(void*)f_10020},
{"f_10018:optimizer_scm",(void*)f_10018},
{"f_9924:optimizer_scm",(void*)f_9924},
{"f_9992:optimizer_scm",(void*)f_9992},
{"f_9990:optimizer_scm",(void*)f_9990},
{"f_9978:optimizer_scm",(void*)f_9978},
{"f_9944:optimizer_scm",(void*)f_9944},
{"f_9968:optimizer_scm",(void*)f_9968},
{"f_9966:optimizer_scm",(void*)f_9966},
{"f_9962:optimizer_scm",(void*)f_9962},
{"f_9954:optimizer_scm",(void*)f_9954},
{"f_9638:optimizer_scm",(void*)f_9638},
{"f_9644:optimizer_scm",(void*)f_9644},
{"f_9663:optimizer_scm",(void*)f_9663},
{"f_9830:optimizer_scm",(void*)f_9830},
{"f_9760:optimizer_scm",(void*)f_9760},
{"f_9776:optimizer_scm",(void*)f_9776},
{"f_9806:optimizer_scm",(void*)f_9806},
{"f_9810:optimizer_scm",(void*)f_9810},
{"f_9796:optimizer_scm",(void*)f_9796},
{"f_9749:optimizer_scm",(void*)f_9749},
{"f_9754:optimizer_scm",(void*)f_9754},
{"f_9725:optimizer_scm",(void*)f_9725},
{"f_9737:optimizer_scm",(void*)f_9737},
{"f_9674:optimizer_scm",(void*)f_9674},
{"f_9695:optimizer_scm",(void*)f_9695},
{"f_9692:optimizer_scm",(void*)f_9692},
{"f_9642:optimizer_scm",(void*)f_9642},
{"f_9394:optimizer_scm",(void*)f_9394},
{"f_9400:optimizer_scm",(void*)f_9400},
{"f_9419:optimizer_scm",(void*)f_9419},
{"f_9521:optimizer_scm",(void*)f_9521},
{"f_9512:optimizer_scm",(void*)f_9512},
{"f_9478:optimizer_scm",(void*)f_9478},
{"f_9487:optimizer_scm",(void*)f_9487},
{"f_9499:optimizer_scm",(void*)f_9499},
{"f_9430:optimizer_scm",(void*)f_9430},
{"f_9451:optimizer_scm",(void*)f_9451},
{"f_9448:optimizer_scm",(void*)f_9448},
{"f_9398:optimizer_scm",(void*)f_9398},
{"f_9295:optimizer_scm",(void*)f_9295},
{"f_9301:optimizer_scm",(void*)f_9301},
{"f_9345:optimizer_scm",(void*)f_9345},
{"f_9350:optimizer_scm",(void*)f_9350},
{"f_9357:optimizer_scm",(void*)f_9357},
{"f_9384:optimizer_scm",(void*)f_9384},
{"f_9380:optimizer_scm",(void*)f_9380},
{"f_9372:optimizer_scm",(void*)f_9372},
{"f_9370:optimizer_scm",(void*)f_9370},
{"f_9335:optimizer_scm",(void*)f_9335},
{"f_9313:optimizer_scm",(void*)f_9313},
{"f_9320:optimizer_scm",(void*)f_9320},
{"f_9098:optimizer_scm",(void*)f_9098},
{"f_9252:optimizer_scm",(void*)f_9252},
{"f_9277:optimizer_scm",(void*)f_9277},
{"f_9267:optimizer_scm",(void*)f_9267},
{"f_9271:optimizer_scm",(void*)f_9271},
{"f_9250:optimizer_scm",(void*)f_9250},
{"f_9101:optimizer_scm",(void*)f_9101},
{"f_9240:optimizer_scm",(void*)f_9240},
{"f_9223:optimizer_scm",(void*)f_9223},
{"f_9235:optimizer_scm",(void*)f_9235},
{"f_9169:optimizer_scm",(void*)f_9169},
{"f_9193:optimizer_scm",(void*)f_9193},
{"f_9187:optimizer_scm",(void*)f_9187},
{"f_9151:optimizer_scm",(void*)f_9151},
{"f_9126:optimizer_scm",(void*)f_9126},
{"f_9129:optimizer_scm",(void*)f_9129},
{"f_9134:optimizer_scm",(void*)f_9134},
{"f_8998:optimizer_scm",(void*)f_8998},
{"f_9004:optimizer_scm",(void*)f_9004},
{"f_9035:optimizer_scm",(void*)f_9035},
{"f_9039:optimizer_scm",(void*)f_9039},
{"f_9043:optimizer_scm",(void*)f_9043},
{"f_9002:optimizer_scm",(void*)f_9002},
{"f_7900:optimizer_scm",(void*)f_7900},
{"f_8990:optimizer_scm",(void*)f_8990},
{"f_8993:optimizer_scm",(void*)f_8993},
{"f_7903:optimizer_scm",(void*)f_7903},
{"f_8059:optimizer_scm",(void*)f_8059},
{"f_8039:optimizer_scm",(void*)f_8039},
{"f_8013:optimizer_scm",(void*)f_8013},
{"f_7959:optimizer_scm",(void*)f_7959},
{"f_7965:optimizer_scm",(void*)f_7965},
{"f_7971:optimizer_scm",(void*)f_7971},
{"f_7928:optimizer_scm",(void*)f_7928},
{"f_8065:optimizer_scm",(void*)f_8065},
{"f_8475:optimizer_scm",(void*)f_8475},
{"f_8482:optimizer_scm",(void*)f_8482},
{"f_8068:optimizer_scm",(void*)f_8068},
{"f_8462:optimizer_scm",(void*)f_8462},
{"f_8438:optimizer_scm",(void*)f_8438},
{"f_8449:optimizer_scm",(void*)f_8449},
{"f_8405:optimizer_scm",(void*)f_8405},
{"f_8344:optimizer_scm",(void*)f_8344},
{"f_8316:optimizer_scm",(void*)f_8316},
{"f_8321:optimizer_scm",(void*)f_8321},
{"f_8263:optimizer_scm",(void*)f_8263},
{"f_8269:optimizer_scm",(void*)f_8269},
{"f_8274:optimizer_scm",(void*)f_8274},
{"f_8222:optimizer_scm",(void*)f_8222},
{"f_8228:optimizer_scm",(void*)f_8228},
{"f_8233:optimizer_scm",(void*)f_8233},
{"f_8206:optimizer_scm",(void*)f_8206},
{"f_8202:optimizer_scm",(void*)f_8202},
{"f_8172:optimizer_scm",(void*)f_8172},
{"f_8135:optimizer_scm",(void*)f_8135},
{"f_8151:optimizer_scm",(void*)f_8151},
{"f_8117:optimizer_scm",(void*)f_8117},
{"f_8484:optimizer_scm",(void*)f_8484},
{"f_8980:optimizer_scm",(void*)f_8980},
{"f_8978:optimizer_scm",(void*)f_8978},
{"f_8488:optimizer_scm",(void*)f_8488},
{"f_8498:optimizer_scm",(void*)f_8498},
{"f_8504:optimizer_scm",(void*)f_8504},
{"f_8510:optimizer_scm",(void*)f_8510},
{"f_8513:optimizer_scm",(void*)f_8513},
{"f_8519:optimizer_scm",(void*)f_8519},
{"f_8695:optimizer_scm",(void*)f_8695},
{"f_8917:optimizer_scm",(void*)f_8917},
{"f_8920:optimizer_scm",(void*)f_8920},
{"f_8870:optimizer_scm",(void*)f_8870},
{"f_8873:optimizer_scm",(void*)f_8873},
{"f_8739:optimizer_scm",(void*)f_8739},
{"f_8794:optimizer_scm",(void*)f_8794},
{"f_8797:optimizer_scm",(void*)f_8797},
{"f_8824:optimizer_scm",(void*)f_8824},
{"f_8800:optimizer_scm",(void*)f_8800},
{"f_8803:optimizer_scm",(void*)f_8803},
{"f_8748:optimizer_scm",(void*)f_8748},
{"f_8751:optimizer_scm",(void*)f_8751},
{"f_8754:optimizer_scm",(void*)f_8754},
{"f_8522:optimizer_scm",(void*)f_8522},
{"f_8677:optimizer_scm",(void*)f_8677},
{"f_8675:optimizer_scm",(void*)f_8675},
{"f_8618:optimizer_scm",(void*)f_8618},
{"f_8628:optimizer_scm",(void*)f_8628},
{"f_8525:optimizer_scm",(void*)f_8525},
{"f_8537:optimizer_scm",(void*)f_8537},
{"f_8576:optimizer_scm",(void*)f_8576},
{"f_8540:optimizer_scm",(void*)f_8540},
{"f_8543:optimizer_scm",(void*)f_8543},
{"f_8548:optimizer_scm",(void*)f_8548},
{"f_8574:optimizer_scm",(void*)f_8574},
{"f_8555:optimizer_scm",(void*)f_8555},
{"f_6028:optimizer_scm",(void*)f_6028},
{"f_7774:optimizer_scm",(void*)f_7774},
{"f_7796:optimizer_scm",(void*)f_7796},
{"f_7808:optimizer_scm",(void*)f_7808},
{"f_7822:optimizer_scm",(void*)f_7822},
{"f_7871:optimizer_scm",(void*)f_7871},
{"f_6053:optimizer_scm",(void*)f_6053},
{"f_7842:optimizer_scm",(void*)f_7842},
{"f_7846:optimizer_scm",(void*)f_7846},
{"f_7816:optimizer_scm",(void*)f_7816},
{"f_7802:optimizer_scm",(void*)f_7802},
{"f_7800:optimizer_scm",(void*)f_7800},
{"f_7789:optimizer_scm",(void*)f_7789},
{"f_7717:optimizer_scm",(void*)f_7717},
{"f_7749:optimizer_scm",(void*)f_7749},
{"f_7736:optimizer_scm",(void*)f_7736},
{"f_7569:optimizer_scm",(void*)f_7569},
{"f_7575:optimizer_scm",(void*)f_7575},
{"f_7659:optimizer_scm",(void*)f_7659},
{"f_7584:optimizer_scm",(void*)f_7584},
{"f_7628:optimizer_scm",(void*)f_7628},
{"f_7626:optimizer_scm",(void*)f_7626},
{"f_7600:optimizer_scm",(void*)f_7600},
{"f_7502:optimizer_scm",(void*)f_7502},
{"f_7530:optimizer_scm",(void*)f_7530},
{"f_7542:optimizer_scm",(void*)f_7542},
{"f_7520:optimizer_scm",(void*)f_7520},
{"f_7515:optimizer_scm",(void*)f_7515},
{"f_7360:optimizer_scm",(void*)f_7360},
{"f_7441:optimizer_scm",(void*)f_7441},
{"f_7369:optimizer_scm",(void*)f_7369},
{"f_7422:optimizer_scm",(void*)f_7422},
{"f_7420:optimizer_scm",(void*)f_7420},
{"f_7385:optimizer_scm",(void*)f_7385},
{"f_7331:optimizer_scm",(void*)f_7331},
{"f_7341:optimizer_scm",(void*)f_7341},
{"f_7269:optimizer_scm",(void*)f_7269},
{"f_7289:optimizer_scm",(void*)f_7289},
{"f_7196:optimizer_scm",(void*)f_7196},
{"f_7226:optimizer_scm",(void*)f_7226},
{"f_7109:optimizer_scm",(void*)f_7109},
{"f_7128:optimizer_scm",(void*)f_7128},
{"f_7121:optimizer_scm",(void*)f_7121},
{"f_7032:optimizer_scm",(void*)f_7032},
{"f_6973:optimizer_scm",(void*)f_6973},
{"f_6988:optimizer_scm",(void*)f_6988},
{"f_6991:optimizer_scm",(void*)f_6991},
{"f_6903:optimizer_scm",(void*)f_6903},
{"f_6946:optimizer_scm",(void*)f_6946},
{"f_6939:optimizer_scm",(void*)f_6939},
{"f_6844:optimizer_scm",(void*)f_6844},
{"f_6856:optimizer_scm",(void*)f_6856},
{"f_6869:optimizer_scm",(void*)f_6869},
{"f_6862:optimizer_scm",(void*)f_6862},
{"f_6757:optimizer_scm",(void*)f_6757},
{"f_6779:optimizer_scm",(void*)f_6779},
{"f_6787:optimizer_scm",(void*)f_6787},
{"f_6791:optimizer_scm",(void*)f_6791},
{"f_6613:optimizer_scm",(void*)f_6613},
{"f_6635:optimizer_scm",(void*)f_6635},
{"f_6638:optimizer_scm",(void*)f_6638},
{"f_6697:optimizer_scm",(void*)f_6697},
{"f_6641:optimizer_scm",(void*)f_6641},
{"f_6644:optimizer_scm",(void*)f_6644},
{"f_6675:optimizer_scm",(void*)f_6675},
{"f_6673:optimizer_scm",(void*)f_6673},
{"f_6649:optimizer_scm",(void*)f_6649},
{"f_6629:optimizer_scm",(void*)f_6629},
{"f_6592:optimizer_scm",(void*)f_6592},
{"f_6537:optimizer_scm",(void*)f_6537},
{"f_6561:optimizer_scm",(void*)f_6561},
{"f_6550:optimizer_scm",(void*)f_6550},
{"f_6472:optimizer_scm",(void*)f_6472},
{"f_6385:optimizer_scm",(void*)f_6385},
{"f_6427:optimizer_scm",(void*)f_6427},
{"f_6329:optimizer_scm",(void*)f_6329},
{"f_6342:optimizer_scm",(void*)f_6342},
{"f_6350:optimizer_scm",(void*)f_6350},
{"f_6291:optimizer_scm",(void*)f_6291},
{"f_6301:optimizer_scm",(void*)f_6301},
{"f_6193:optimizer_scm",(void*)f_6193},
{"f_6250:optimizer_scm",(void*)f_6250},
{"f_6221:optimizer_scm",(void*)f_6221},
{"f_6218:optimizer_scm",(void*)f_6218},
{"f_6085:optimizer_scm",(void*)f_6085},
{"f_6148:optimizer_scm",(void*)f_6148},
{"f_6088:optimizer_scm",(void*)f_6088},
{"f_6008:optimizer_scm",(void*)f_6008},
{"f_6012:optimizer_scm",(void*)f_6012},
{"f_6022:optimizer_scm",(void*)f_6022},
{"f_5680:optimizer_scm",(void*)f_5680},
{"f_5684:optimizer_scm",(void*)f_5684},
{"f_5993:optimizer_scm",(void*)f_5993},
{"f_6002:optimizer_scm",(void*)f_6002},
{"f_5998:optimizer_scm",(void*)f_5998},
{"f_5731:optimizer_scm",(void*)f_5731},
{"f_5935:optimizer_scm",(void*)f_5935},
{"f_5967:optimizer_scm",(void*)f_5967},
{"f_5980:optimizer_scm",(void*)f_5980},
{"f_5945:optimizer_scm",(void*)f_5945},
{"f_5961:optimizer_scm",(void*)f_5961},
{"f_5949:optimizer_scm",(void*)f_5949},
{"f_5953:optimizer_scm",(void*)f_5953},
{"f_5734:optimizer_scm",(void*)f_5734},
{"f_5876:optimizer_scm",(void*)f_5876},
{"f_5919:optimizer_scm",(void*)f_5919},
{"f_5925:optimizer_scm",(void*)f_5925},
{"f_5883:optimizer_scm",(void*)f_5883},
{"f_5893:optimizer_scm",(void*)f_5893},
{"f_5906:optimizer_scm",(void*)f_5906},
{"f_5891:optimizer_scm",(void*)f_5891},
{"f_5887:optimizer_scm",(void*)f_5887},
{"f_5737:optimizer_scm",(void*)f_5737},
{"f_5740:optimizer_scm",(void*)f_5740},
{"f_5760:optimizer_scm",(void*)f_5760},
{"f_5773:optimizer_scm",(void*)f_5773},
{"f_5816:optimizer_scm",(void*)f_5816},
{"f_5848:optimizer_scm",(void*)f_5848},
{"f_5814:optimizer_scm",(void*)f_5814},
{"f_5796:optimizer_scm",(void*)f_5796},
{"f_5743:optimizer_scm",(void*)f_5743},
{"f_5752:optimizer_scm",(void*)f_5752},
{"f_5686:optimizer_scm",(void*)f_5686},
{"f_5692:optimizer_scm",(void*)f_5692},
{"f_5716:optimizer_scm",(void*)f_5716},
{"f_5665:optimizer_scm",(void*)f_5665},
{"f_5424:optimizer_scm",(void*)f_5424},
{"f_5438:optimizer_scm",(void*)f_5438},
{"f_5453:optimizer_scm",(void*)f_5453},
{"f_5660:optimizer_scm",(void*)f_5660},
{"f_5458:optimizer_scm",(void*)f_5458},
{"f_5649:optimizer_scm",(void*)f_5649},
{"f_5471:optimizer_scm",(void*)f_5471},
{"f_5474:optimizer_scm",(void*)f_5474},
{"f_5480:optimizer_scm",(void*)f_5480},
{"f_5495:optimizer_scm",(void*)f_5495},
{"f_5501:optimizer_scm",(void*)f_5501},
{"f_5507:optimizer_scm",(void*)f_5507},
{"f_5516:optimizer_scm",(void*)f_5516},
{"f_5523:optimizer_scm",(void*)f_5523},
{"f_5526:optimizer_scm",(void*)f_5526},
{"f_5544:optimizer_scm",(void*)f_5544},
{"f_5529:optimizer_scm",(void*)f_5529},
{"f_5441:optimizer_scm",(void*)f_5441},
{"f_5444:optimizer_scm",(void*)f_5444},
{"f_5431:optimizer_scm",(void*)f_5431},
{"f_5427:optimizer_scm",(void*)f_5427},
{"f_3936:optimizer_scm",(void*)f_3936},
{"f_5328:optimizer_scm",(void*)f_5328},
{"f_5334:optimizer_scm",(void*)f_5334},
{"f_5338:optimizer_scm",(void*)f_5338},
{"f_5341:optimizer_scm",(void*)f_5341},
{"f_5377:optimizer_scm",(void*)f_5377},
{"f_5382:optimizer_scm",(void*)f_5382},
{"f_5386:optimizer_scm",(void*)f_5386},
{"f_5344:optimizer_scm",(void*)f_5344},
{"f_5347:optimizer_scm",(void*)f_5347},
{"f_5350:optimizer_scm",(void*)f_5350},
{"f_5353:optimizer_scm",(void*)f_5353},
{"f_5309:optimizer_scm",(void*)f_5309},
{"f_5313:optimizer_scm",(void*)f_5313},
{"f_5319:optimizer_scm",(void*)f_5319},
{"f_4275:optimizer_scm",(void*)f_4275},
{"f_5225:optimizer_scm",(void*)f_5225},
{"f_5228:optimizer_scm",(void*)f_5228},
{"f_5301:optimizer_scm",(void*)f_5301},
{"f_5297:optimizer_scm",(void*)f_5297},
{"f_5269:optimizer_scm",(void*)f_5269},
{"f_5290:optimizer_scm",(void*)f_5290},
{"f_5282:optimizer_scm",(void*)f_5282},
{"f_5240:optimizer_scm",(void*)f_5240},
{"f_5259:optimizer_scm",(void*)f_5259},
{"f_5246:optimizer_scm",(void*)f_5246},
{"f_5200:optimizer_scm",(void*)f_5200},
{"f_5175:optimizer_scm",(void*)f_5175},
{"f_5165:optimizer_scm",(void*)f_5165},
{"f_4608:optimizer_scm",(void*)f_4608},
{"f_4617:optimizer_scm",(void*)f_4617},
{"f_4798:optimizer_scm",(void*)f_4798},
{"f_4809:optimizer_scm",(void*)f_4809},
{"f_5121:optimizer_scm",(void*)f_5121},
{"f_5127:optimizer_scm",(void*)f_5127},
{"f_5130:optimizer_scm",(void*)f_5130},
{"f_4819:optimizer_scm",(void*)f_4819},
{"f_4866:optimizer_scm",(void*)f_4866},
{"f_5108:optimizer_scm",(void*)f_5108},
{"f_5025:optimizer_scm",(void*)f_5025},
{"f_5028:optimizer_scm",(void*)f_5028},
{"f_5040:optimizer_scm",(void*)f_5040},
{"f_5051:optimizer_scm",(void*)f_5051},
{"f_5078:optimizer_scm",(void*)f_5078},
{"f_5070:optimizer_scm",(void*)f_5070},
{"f_5055:optimizer_scm",(void*)f_5055},
{"f_5045:optimizer_scm",(void*)f_5045},
{"f_4880:optimizer_scm",(void*)f_4880},
{"f_4913:optimizer_scm",(void*)f_4913},
{"f_4919:optimizer_scm",(void*)f_4919},
{"f_4925:optimizer_scm",(void*)f_4925},
{"f_4962:optimizer_scm",(void*)f_4962},
{"f_4938:optimizer_scm",(void*)f_4938},
{"f_4942:optimizer_scm",(void*)f_4942},
{"f_4907:optimizer_scm",(void*)f_4907},
{"f_4896:optimizer_scm",(void*)f_4896},
{"f_4857:optimizer_scm",(void*)f_4857},
{"f_4822:optimizer_scm",(void*)f_4822},
{"f_4825:optimizer_scm",(void*)f_4825},
{"f_4828:optimizer_scm",(void*)f_4828},
{"f_4838:optimizer_scm",(void*)f_4838},
{"f_4784:optimizer_scm",(void*)f_4784},
{"f_4680:optimizer_scm",(void*)f_4680},
{"f_4701:optimizer_scm",(void*)f_4701},
{"f_4758:optimizer_scm",(void*)f_4758},
{"f_4750:optimizer_scm",(void*)f_4750},
{"f_4704:optimizer_scm",(void*)f_4704},
{"f_4729:optimizer_scm",(void*)f_4729},
{"f_4727:optimizer_scm",(void*)f_4727},
{"f_4713:optimizer_scm",(void*)f_4713},
{"f_4659:optimizer_scm",(void*)f_4659},
{"f_4626:optimizer_scm",(void*)f_4626},
{"f_4629:optimizer_scm",(void*)f_4629},
{"f_4639:optimizer_scm",(void*)f_4639},
{"f_4432:optimizer_scm",(void*)f_4432},
{"f_4524:optimizer_scm",(void*)f_4524},
{"f_4529:optimizer_scm",(void*)f_4529},
{"f_4536:optimizer_scm",(void*)f_4536},
{"f_4565:optimizer_scm",(void*)f_4565},
{"f_4549:optimizer_scm",(void*)f_4549},
{"f_4437:optimizer_scm",(void*)f_4437},
{"f_4455:optimizer_scm",(void*)f_4455},
{"f_4462:optimizer_scm",(void*)f_4462},
{"f_4498:optimizer_scm",(void*)f_4498},
{"f_4501:optimizer_scm",(void*)f_4501},
{"f_4491:optimizer_scm",(void*)f_4491},
{"f_4475:optimizer_scm",(void*)f_4475},
{"f_4443:optimizer_scm",(void*)f_4443},
{"f_4449:optimizer_scm",(void*)f_4449},
{"f_4375:optimizer_scm",(void*)f_4375},
{"f_4401:optimizer_scm",(void*)f_4401},
{"f_4410:optimizer_scm",(void*)f_4410},
{"f_4417:optimizer_scm",(void*)f_4417},
{"f_4378:optimizer_scm",(void*)f_4378},
{"f_4395:optimizer_scm",(void*)f_4395},
{"f_4300:optimizer_scm",(void*)f_4300},
{"f_4304:optimizer_scm",(void*)f_4304},
{"f_4316:optimizer_scm",(void*)f_4316},
{"f_4339:optimizer_scm",(void*)f_4339},
{"f_4322:optimizer_scm",(void*)f_4322},
{"f_4333:optimizer_scm",(void*)f_4333},
{"f_4061:optimizer_scm",(void*)f_4061},
{"f_4075:optimizer_scm",(void*)f_4075},
{"f_4246:optimizer_scm",(void*)f_4246},
{"f_4252:optimizer_scm",(void*)f_4252},
{"f_4145:optimizer_scm",(void*)f_4145},
{"f_4227:optimizer_scm",(void*)f_4227},
{"f_4225:optimizer_scm",(void*)f_4225},
{"f_4156:optimizer_scm",(void*)f_4156},
{"f_4179:optimizer_scm",(void*)f_4179},
{"f_4211:optimizer_scm",(void*)f_4211},
{"f_4217:optimizer_scm",(void*)f_4217},
{"f_4185:optimizer_scm",(void*)f_4185},
{"f_4189:optimizer_scm",(void*)f_4189},
{"f_4192:optimizer_scm",(void*)f_4192},
{"f_4209:optimizer_scm",(void*)f_4209},
{"f_4162:optimizer_scm",(void*)f_4162},
{"f_4168:optimizer_scm",(void*)f_4168},
{"f_4172:optimizer_scm",(void*)f_4172},
{"f_4176:optimizer_scm",(void*)f_4176},
{"f_4154:optimizer_scm",(void*)f_4154},
{"f_4084:optimizer_scm",(void*)f_4084},
{"f_3969:optimizer_scm",(void*)f_3969},
{"f_3973:optimizer_scm",(void*)f_3973},
{"f_3984:optimizer_scm",(void*)f_3984},
{"f_3994:optimizer_scm",(void*)f_3994},
{"f_4043:optimizer_scm",(void*)f_4043},
{"f_4041:optimizer_scm",(void*)f_4041},
{"f_4000:optimizer_scm",(void*)f_4000},
{"f_4006:optimizer_scm",(void*)f_4006},
{"f_4033:optimizer_scm",(void*)f_4033},
{"f_4012:optimizer_scm",(void*)f_4012},
{"f_3976:optimizer_scm",(void*)f_3976},
{"f_3965:optimizer_scm",(void*)f_3965},
{"f_3945:optimizer_scm",(void*)f_3945},
{"f_3939:optimizer_scm",(void*)f_3939},
{"f_3698:optimizer_scm",(void*)f_3698},
{"f_3719:optimizer_scm",(void*)f_3719},
{"f_3763:optimizer_scm",(void*)f_3763},
{"f_3778:optimizer_scm",(void*)f_3778},
{"f_3830:optimizer_scm",(void*)f_3830},
{"f_3894:optimizer_scm",(void*)f_3894},
{"f_3849:optimizer_scm",(void*)f_3849},
{"f_3860:optimizer_scm",(void*)f_3860},
{"f_3833:optimizer_scm",(void*)f_3833},
{"f_3803:optimizer_scm",(void*)f_3803},
{"f_3766:optimizer_scm",(void*)f_3766},
{"f_3772:optimizer_scm",(void*)f_3772},
{"f_3722:optimizer_scm",(void*)f_3722},
{"f_3725:optimizer_scm",(void*)f_3725},
{"f_3730:optimizer_scm",(void*)f_3730},
{"f_3735:optimizer_scm",(void*)f_3735},
{"f_3739:optimizer_scm",(void*)f_3739},
{"f_3701:optimizer_scm",(void*)f_3701},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
