/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:33
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: posixunix.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -output-file posixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
#else
static C_TLS struct {
  char *gr_name, gr_passwd;
  int gr_gid;
  char *gr_mem[ 1 ];
} C_group = { "", "", 0, { "" } };
#endif
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)
#define C_isdir             ((C_statbuf.st_mode & S_IFMT) == S_IFDIR)
#define C_ischr             ((C_statbuf.st_mode & S_IFMT) == S_IFCHR)
#define C_isblk             ((C_statbuf.st_mode & S_IFMT) == S_IFBLK)
#define C_isfifo            ((C_statbuf.st_mode & S_IFMT) == S_IFIFO)
#ifdef S_IFSOCK
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == S_IFSOCK)
#else
#define C_issock            ((C_statbuf.st_mode & S_IFMT) == 0140000)
#endif

#ifdef C_GNU_ENV
# define C_unsetenv(s)      (unsetenv((char *)C_data_pointer(s)), C_SCHEME_TRUE)
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
# define C_unsetenv(s)      C_fix(putenv((char *)C_data_pointer(s)))
static C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

static time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#define cpy_tmvec_to_tmstc08(ptm, v) \
    (memset((ptm), 0, sizeof(struct tm)), \
    (ptm)->tm_sec = C_unfix(C_block_item((v), 0)), \
    (ptm)->tm_min = C_unfix(C_block_item((v), 1)), \
    (ptm)->tm_hour = C_unfix(C_block_item((v), 2)), \
    (ptm)->tm_mday = C_unfix(C_block_item((v), 3)), \
    (ptm)->tm_mon = C_unfix(C_block_item((v), 4)), \
    (ptm)->tm_year = C_unfix(C_block_item((v), 5)), \
    (ptm)->tm_wday = C_unfix(C_block_item((v), 6)), \
    (ptm)->tm_yday = C_unfix(C_block_item((v), 7)), \
    (ptm)->tm_isdst = (C_block_item((v), 8) != C_SCHEME_FALSE))

#define cpy_tmvec_to_tmstc9(ptm, v) \
    (((struct tm *)ptm)->tm_gmtoff = C_unfix(C_block_item((v), 9)))

#define cpy_tmstc08_to_tmvec(v, ptm) \
    (C_set_block_item((v), 0, C_fix(((struct tm *)ptm)->tm_sec)), \
    C_set_block_item((v), 1, C_fix((ptm)->tm_min)), \
    C_set_block_item((v), 2, C_fix((ptm)->tm_hour)), \
    C_set_block_item((v), 3, C_fix((ptm)->tm_mday)), \
    C_set_block_item((v), 4, C_fix((ptm)->tm_mon)), \
    C_set_block_item((v), 5, C_fix((ptm)->tm_year)), \
    C_set_block_item((v), 6, C_fix((ptm)->tm_wday)), \
    C_set_block_item((v), 7, C_fix((ptm)->tm_yday)), \
    C_set_block_item((v), 8, ((ptm)->tm_isdst ? C_SCHEME_TRUE : C_SCHEME_FALSE)))

#define cpy_tmstc9_to_tmvec(v, ptm) \
    (C_set_block_item((v), 9, C_fix((ptm)->tm_gmtoff)))

#define C_tm_set_08(v)  cpy_tmvec_to_tmstc08( &C_tm, (v) )
#define C_tm_set_9(v)   cpy_tmvec_to_tmstc9( &C_tm, (v) )

#define C_tm_get_08(v)  cpy_tmstc08_to_tmvec( (v), &C_tm )
#define C_tm_get_9(v)   cpy_tmstc9_to_tmvec( (v), &C_tm )

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  return v;
}

#else

static struct tm *
C_tm_set( C_word v )
{
  C_tm_set_08( v );
  C_tm_set_9( v );
  return &C_tm;
}

static C_word
C_tm_get( C_word v )
{
  C_tm_get_08( v );
  C_tm_get_9( v );
  return v;
}

#endif

#define C_asctime(v)    (asctime(C_tm_set(v)))
#define C_mktime(v)     ((C_temporary_flonum = mktime(C_tm_set(v))) != -1)
#define C_timegm(v)     ((C_temporary_flonum = timegm(C_tm_set(v))) != -1)

#define TIME_STRING_MAXLENGTH 255
static char C_time_string [TIME_STRING_MAXLENGTH + 1];
#undef TIME_STRING_MAXLENGTH

#define C_strftime(v, f) \
        (strftime(C_time_string, sizeof(C_time_string), C_c_string(f), C_tm_set(v)) ? C_time_string : NULL)

#define C_strptime(s, f, v) \
        (strptime(C_c_string(s), C_c_string(f), &C_tm) ? C_tm_get(v) : C_SCHEME_FALSE)

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[467];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,41),40,112,111,115,105,120,45,101,114,114,111,114,32,116,121,112,101,51,48,32,108,111,99,51,49,32,109,115,103,51,50,32,46,32,97,114,103,115,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,31),40,35,35,115,121,115,35,102,105,108,101,45,110,111,110,98,108,111,99,107,105,110,103,33,32,97,51,57,52,50,41,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,102,105,108,101,45,115,101,108,101,99,116,45,111,110,101,32,97,52,53,52,56,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,39),40,102,105,108,101,45,99,111,110,116,114,111,108,32,102,100,49,51,55,32,99,109,100,49,51,56,32,46,32,116,109,112,49,51,54,49,51,57,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,111,112,101,110,32,102,105,108,101,110,97,109,101,49,53,57,32,102,108,97,103,115,49,54,48,32,46,32,109,111,100,101,49,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,18),40,102,105,108,101,45,99,108,111,115,101,32,102,100,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,37),40,102,105,108,101,45,114,101,97,100,32,102,100,49,56,50,32,115,105,122,101,49,56,51,32,46,32,98,117,102,102,101,114,49,56,52,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,38),40,102,105,108,101,45,119,114,105,116,101,32,102,100,50,48,49,32,98,117,102,102,101,114,50,48,50,32,46,32,115,105,122,101,50,48,51,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,109,107,115,116,101,109,112,32,116,101,109,112,108,97,116,101,50,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,9),40,102,100,95,122,101,114,111,41,0,0,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,16),40,102,100,95,115,101,116,32,97,50,52,51,50,52,56,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,17),40,102,100,95,116,101,115,116,32,97,50,53,48,50,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,97,51,56,54,53,32,102,100,51,51,51,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,97,51,56,57,48,32,102,100,51,50,52,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,97,51,57,51,48,32,102,100,50,57,56,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,13),40,97,51,57,53,54,32,102,100,50,55,57,41,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,115,101,108,101,99,116,32,102,100,115,114,50,53,56,32,102,100,115,119,50,53,57,32,46,32,116,105,109,101,111,117,116,50,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,35),40,35,35,115,121,115,35,115,116,97,116,32,102,105,108,101,51,54,51,32,108,105,110,107,51,54,52,32,108,111,99,51,54,53,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,26),40,102,105,108,101,45,115,116,97,116,32,102,51,56,50,32,46,32,108,105,110,107,51,56,51,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,16),40,102,105,108,101,45,115,105,122,101,32,102,51,57,54,41};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,29),40,102,105,108,101,45,109,111,100,105,102,105,99,97,116,105,111,110,45,116,105,109,101,32,102,52,48,49,41,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,97,99,99,101,115,115,45,116,105,109,101,32,102,52,48,54,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,99,104,97,110,103,101,45,116,105,109,101,32,102,52,49,49,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,17),40,102,105,108,101,45,111,119,110,101,114,32,102,52,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,23),40,102,105,108,101,45,112,101,114,109,105,115,115,105,111,110,115,32,102,52,50,49,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,24),40,114,101,103,117,108,97,114,45,102,105,108,101,63,32,102,110,97,109,101,52,50,54,41};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,115,121,109,98,111,108,105,99,45,108,105,110,107,63,32,102,110,97,109,101,52,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,24),40,115,116,97,116,45,114,101,103,117,108,97,114,63,32,102,110,97,109,101,52,52,52,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,26),40,115,116,97,116,45,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,52,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,28),40,99,104,97,114,97,99,116,101,114,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,54,50,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,24),40,98,108,111,99,107,45,100,101,118,105,99,101,63,32,102,110,97,109,101,52,55,50,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,17),40,102,95,52,49,51,55,32,102,110,97,109,101,52,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,18),40,115,111,99,107,101,116,63,32,102,110,97,109,101,52,57,51,41,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,47),40,115,101,116,45,102,105,108,101,45,112,111,115,105,116,105,111,110,33,32,112,111,114,116,53,48,50,32,112,111,115,53,48,51,32,46,32,119,104,101,110,99,101,53,48,52,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,12),40,97,52,50,51,52,32,120,53,55,50,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,53,53,52,32,46,32,116,109,112,53,53,51,53,53,53,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,26),40,99,104,97,110,103,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,48,52,41,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,26),40,100,101,108,101,116,101,45,100,105,114,101,99,116,111,114,121,32,110,97,109,101,54,49,48,41,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,54,51,53,32,115,112,101,99,54,52,53,32,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,52,54,41,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,115,104,111,119,45,100,111,116,102,105,108,101,115,63,54,51,56,32,37,115,112,101,99,54,51,51,54,57,49,41,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,115,112,101,99,54,51,55,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,23),40,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,54,50,53,54,50,54,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,21),40,100,105,114,101,99,116,111,114,121,63,32,102,110,97,109,101,55,48,54,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,31),40,99,117,114,114,101,110,116,45,100,105,114,101,99,116,111,114,121,32,46,32,116,109,112,55,50,49,55,50,50,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,105,115,112,101,114,115,101,32,103,55,54,55,55,54,56,55,54,57,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,6),40,115,101,112,63,41,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,52,54,51,52,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,19),40,97,52,54,50,56,32,101,120,118,97,114,55,56,49,55,57,55,41,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,52,54,53,50,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,52,54,54,52,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,20),40,97,52,54,53,56,32,46,32,97,114,103,115,55,57,48,56,49,53,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,52,54,52,54,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,15),40,97,52,54,50,50,32,107,55,56,57,55,57,53,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,5),40,99,119,100,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,108,56,53,48,32,114,56,53,49,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,24),40,99,97,110,111,110,105,99,97,108,45,112,97,116,104,32,112,97,116,104,56,49,57,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,6),40,109,111,100,101,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,14),40,98,97,100,109,111,100,101,32,109,56,54,51,41,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,33),40,99,104,101,99,107,32,108,111,99,56,54,53,32,99,109,100,56,54,54,32,105,110,112,56,54,55,32,114,56,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,31),40,111,112,101,110,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,56,55,51,32,46,32,109,56,55,52,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,32),40,111,112,101,110,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,56,56,54,32,46,32,109,56,56,55,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,26),40,99,108,111,115,101,45,105,110,112,117,116,45,112,105,112,101,32,112,111,114,116,56,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,7),40,97,53,49,49,54,41,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,20),40,97,53,49,50,50,32,46,32,114,101,115,117,108,116,115,57,50,54,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,47),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,112,105,112,101,32,99,109,100,57,49,57,32,112,114,111,99,57,50,48,32,46,32,109,111,100,101,57,50,49,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,7),40,97,53,49,52,48,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,20),40,97,53,49,52,54,32,46,32,114,101,115,117,108,116,115,57,51,54,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,48),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,112,105,112,101,32,99,109,100,57,50,57,32,112,114,111,99,57,51,48,32,46,32,109,111,100,101,57,51,49,41};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,53,49,54,53,32,46,32,114,101,115,117,108,116,115,57,52,54,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,48),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,105,112,101,32,99,109,100,57,51,57,32,116,104,117,110,107,57,52,48,32,46,32,109,111,100,101,57,52,49,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,20),40,97,53,49,56,53,32,46,32,114,101,115,117,108,116,115,57,53,56,41,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,47),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,105,112,101,32,99,109,100,57,53,49,32,116,104,117,110,107,57,53,50,32,46,32,109,111,100,101,57,53,51,41,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,13),40,99,114,101,97,116,101,45,112,105,112,101,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,104,97,110,100,108,101,114,32,115,105,103,49,48,50,57,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,38),40,115,101,116,45,115,105,103,110,97,108,45,104,97,110,100,108,101,114,33,32,115,105,103,49,48,51,50,32,112,114,111,99,49,48,51,51,41,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,43),40,35,35,115,121,115,35,105,110,116,101,114,114,117,112,116,45,104,111,111,107,32,114,101,97,115,111,110,49,48,51,57,32,115,116,97,116,101,49,48,52,48,41,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,13),40,97,53,51,48,48,32,115,49,48,53,48,41,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,27),40,115,101,116,45,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,115,49,48,52,56,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,32,115,105,103,115,49,48,54,51,32,109,97,115,107,49,48,54,52,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,13),40,115,105,103,110,97,108,45,109,97,115,107,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,109,97,115,107,101,100,63,32,115,105,103,49,48,55,50,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,22),40,115,105,103,110,97,108,45,109,97,115,107,33,32,115,105,103,49,48,55,55,41,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,24),40,115,105,103,110,97,108,45,117,110,109,97,115,107,33,32,115,105,103,49,48,56,53,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,20),40,115,121,115,116,101,109,45,105,110,102,111,114,109,97,116,105,111,110,41,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,41),40,117,115,101,114,45,105,110,102,111,114,109,97,116,105,111,110,32,117,115,101,114,49,49,53,55,32,46,32,116,109,112,49,49,53,54,49,49,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,99,117,114,114,101,110,116,45,117,115,101,114,45,110,97,109,101,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,29),40,99,117,114,114,101,110,116,45,101,102,102,101,99,116,105,118,101,45,117,115,101,114,45,110,97,109,101,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,50,48,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,43),40,103,114,111,117,112,45,105,110,102,111,114,109,97,116,105,111,110,32,103,114,111,117,112,49,50,48,48,32,46,32,116,109,112,49,49,57,57,49,50,48,49,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,16),40,95,101,110,115,117,114,101,45,103,114,111,117,112,115,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,50,53,54,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,12),40,103,101,116,45,103,114,111,117,112,115,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,26),40,100,111,108,111,111,112,49,50,54,57,32,108,115,116,49,50,55,53,32,105,49,50,55,54,41,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,103,114,111,117,112,115,33,32,108,115,116,48,49,50,54,53,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,35),40,105,110,105,116,105,97,108,105,122,101,45,103,114,111,117,112,115,32,117,115,101,114,49,51,48,50,32,105,100,49,51,48,51,41,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,34),40,99,104,97,110,103,101,45,102,105,108,101,45,109,111,100,101,32,102,110,97,109,101,49,51,55,52,32,109,49,51,55,53,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,42),40,99,104,97,110,103,101,45,102,105,108,101,45,111,119,110,101,114,32,102,110,49,51,56,50,32,117,105,100,49,51,56,51,32,103,105,100,49,51,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,102,105,108,101,110,97,109,101,49,51,57,55,32,97,99,99,49,51,57,56,32,108,111,99,49,51,57,57,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,32),40,102,105,108,101,45,114,101,97,100,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,55,41};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,119,114,105,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,35),40,102,105,108,101,45,101,120,101,99,117,116,101,45,97,99,99,101,115,115,63,32,102,105,108,101,110,97,109,101,49,52,49,49,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,16),40,99,114,101,97,116,101,45,115,101,115,115,105,111,110,41};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,38),40,99,114,101,97,116,101,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,111,108,100,49,52,52,52,32,110,101,119,49,52,52,53,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,115,121,109,98,111,108,105,99,45,108,105,110,107,32,102,110,97,109,101,49,52,53,54,41,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,27),40,102,105,108,101,45,108,105,110,107,32,111,108,100,49,52,56,48,32,110,101,119,49,52,56,49,41,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,20),40,109,111,100,101,32,105,110,112,49,52,57,55,32,109,49,52,57,56,41,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,36),40,99,104,101,99,107,32,108,111,99,49,53,49,54,32,102,100,49,53,49,55,32,105,110,112,49,53,49,56,32,114,49,53,49,57,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,33),40,111,112,101,110,45,105,110,112,117,116,45,102,105,108,101,42,32,102,100,49,53,50,52,32,46,32,109,49,53,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,34),40,111,112,101,110,45,111,117,116,112,117,116,45,102,105,108,101,42,32,102,100,49,53,50,56,32,46,32,109,49,53,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,23),40,112,111,114,116,45,62,102,105,108,101,110,111,32,112,111,114,116,49,53,51,54,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,36),40,100,117,112,108,105,99,97,116,101,45,102,105,108,101,110,111,32,111,108,100,49,53,53,50,32,46,32,110,101,119,49,53,53,51,41,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,8),40,114,101,97,100,121,63,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,7),40,102,101,116,99,104,41,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,7),40,97,54,51,52,53,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,7),40,97,54,51,53,56,41,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,7),40,97,54,51,55,48,41,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,7),40,97,54,51,57,49,41,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,110,49,54,55,56,32,109,49,54,55,57,32,115,116,97,114,116,49,54,56,48,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,41),40,97,54,52,48,48,32,112,111,114,116,49,54,55,49,32,110,49,54,55,50,32,100,101,115,116,49,54,55,51,32,115,116,97,114,116,49,54,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,24),40,98,117,109,112,101,114,32,99,117,114,49,55,49,52,32,112,116,114,49,55,49,53,41};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,7),40,97,54,53,54,50,41,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,42),40,97,54,53,54,56,32,100,101,115,116,49,55,53,52,49,55,53,53,49,55,53,57,32,99,111,110,116,63,49,55,53,54,49,55,53,55,49,55,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,49,55,49,49,41,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,26),40,97,54,52,55,54,32,112,111,114,116,49,55,48,54,32,108,105,109,105,116,49,55,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,49,53,56,56,32,110,111,110,98,108,111,99,107,105,110,103,63,49,54,48,48,32,98,117,102,105,49,54,48,49,32,111,110,45,99,108,111,115,101,49,54,48,50,32,109,111,114,101,63,49,54,48,51,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,69),40,100,101,102,45,109,111,114,101,63,49,53,57,51,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,52,49,55,55,52,32,37,98,117,102,105,49,53,56,53,49,55,55,53,32,37,111,110,45,99,108,111,115,101,49,53,56,54,49,55,55,54,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,53,57,50,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,52,49,55,56,48,32,37,98,117,102,105,49,53,56,53,49,55,56,49,41,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,53,57,49,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,53,56,52,49,55,56,53,41,0,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,53,57,48,41,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,62),40,35,35,115,121,115,35,99,117,115,116,111,109,45,105,110,112,117,116,45,112,111,114,116,32,108,111,99,49,53,55,52,32,110,97,109,49,53,55,53,32,102,100,49,53,55,54,32,46,32,116,109,112,49,53,55,51,49,53,55,55,41,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,22),40,112,111,107,101,32,115,116,114,49,56,52,55,32,108,101,110,49,56,52,56,41,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,15),40,97,54,55,53,57,32,115,116,114,49,56,57,53,41,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,7),40,97,54,55,54,53,41,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,7),40,97,54,55,56,54,41,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,16),40,102,95,54,55,57,53,32,115,116,114,49,56,54,50,41};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,32,114,101,109,49,56,55,51,32,115,116,97,114,116,49,56,55,52,32,108,101,110,49,56,55,53,41};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,16),40,102,95,54,56,49,48,32,115,116,114,49,56,54,57,41};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,49),40,98,111,100,121,49,56,50,55,32,110,111,110,98,108,111,99,107,105,110,103,63,49,56,51,56,32,98,117,102,105,49,56,51,57,32,111,110,45,99,108,111,115,101,49,56,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,54),40,100,101,102,45,111,110,45,99,108,111,115,101,49,56,51,49,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,52,49,57,49,50,32,37,98,117,102,105,49,56,50,53,49,57,49,51,41,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,98,117,102,105,49,56,51,48,32,37,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,52,49,57,49,55,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,110,111,110,98,108,111,99,107,105,110,103,63,49,56,50,57,41,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,63),40,35,35,115,121,115,35,99,117,115,116,111,109,45,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,49,56,49,52,32,110,97,109,49,56,49,53,32,102,100,49,56,49,54,32,46,32,116,109,112,49,56,49,51,49,56,49,55,41,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,33),40,102,105,108,101,45,116,114,117,110,99,97,116,101,32,102,110,97,109,101,49,57,51,52,32,111,102,102,49,57,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,32,112,111,114,116,49,57,53,52,32,97,114,103,115,49,57,53,53,32,108,111,99,49,57,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,30),40,101,114,114,32,109,115,103,49,57,55,56,32,108,111,99,107,49,57,55,57,32,108,111,99,49,57,56,48,41,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,31),40,102,105,108,101,45,108,111,99,107,32,112,111,114,116,49,57,56,50,32,46,32,97,114,103,115,49,57,56,51,41,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,40),40,102,105,108,101,45,108,111,99,107,47,98,108,111,99,107,105,110,103,32,112,111,114,116,49,57,56,55,32,46,32,97,114,103,115,49,57,56,56,41};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,36),40,102,105,108,101,45,116,101,115,116,45,108,111,99,107,32,112,111,114,116,49,57,57,50,32,46,32,97,114,103,115,49,57,57,51,41,0,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,22),40,102,105,108,101,45,117,110,108,111,99,107,32,108,111,99,107,50,48,49,55,41,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,34),40,99,114,101,97,116,101,45,102,105,102,111,32,102,110,97,109,101,50,48,50,52,32,46,32,109,111,100,101,50,48,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,102,105,102,111,63,32,102,105,108,101,110,97,109,101,50,48,51,52,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,24),40,115,101,116,101,110,118,32,118,97,114,50,48,52,48,32,118,97,108,50,48,52,49,41};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,18),40,117,110,115,101,116,101,110,118,32,118,97,114,50,48,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,12),40,115,99,97,110,32,106,50,48,55,49,41,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,50,48,54,53,41,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,27),40,103,101,116,45,101,110,118,105,114,111,110,109,101,110,116,45,118,97,114,105,97,98,108,101,115,41,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,72),40,109,97,112,45,102,105,108,101,45,116,111,45,109,101,109,111,114,121,32,97,100,100,114,50,49,49,57,32,108,101,110,50,49,50,48,32,112,114,111,116,50,49,50,49,32,102,108,97,103,50,49,50,50,32,102,100,50,49,50,51,32,46,32,111,102,102,50,49,50,52,41};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,43),40,117,110,109,97,112,45,102,105,108,101,45,102,114,111,109,45,109,101,109,111,114,121,32,109,109,97,112,50,49,53,50,32,46,32,108,101,110,50,49,53,51,41,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,37),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,45,112,111,105,110,116,101,114,32,109,109,97,112,50,49,54,50,41,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,27),40,109,101,109,111,114,121,45,109,97,112,112,101,100,45,102,105,108,101,63,32,120,50,49,54,55,41,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,34),40,99,104,101,99,107,45,116,105,109,101,45,118,101,99,116,111,114,32,108,111,99,50,49,55,49,32,116,109,50,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,30),40,115,101,99,111,110,100,115,45,62,108,111,99,97,108,45,116,105,109,101,32,115,101,99,115,50,49,55,57,41,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,28),40,115,101,99,111,110,100,115,45,62,117,116,99,45,116,105,109,101,32,115,101,99,115,50,49,56,52,41,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,26),40,115,101,99,111,110,100,115,45,62,115,116,114,105,110,103,32,115,101,99,115,50,49,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,35),40,116,105,109,101,45,62,115,116,114,105,110,103,32,116,109,50,50,50,56,32,46,32,116,109,112,50,50,50,55,50,50,50,57,41,0,0,0,0,0};
static C_char C_TLS li167[] C_aligned={C_lihdr(0,0,36),40,115,116,114,105,110,103,45,62,116,105,109,101,32,116,105,109,50,50,54,57,32,46,32,116,109,112,50,50,54,56,50,50,55,48,41,0,0,0,0};
static C_char C_TLS li168[] C_aligned={C_lihdr(0,0,28),40,108,111,99,97,108,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,56,54,41,0,0,0,0};
static C_char C_TLS li169[] C_aligned={C_lihdr(0,0,26),40,117,116,99,45,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,50,50,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li170[] C_aligned={C_lihdr(0,0,29),40,108,111,99,97,108,45,116,105,109,101,122,111,110,101,45,97,98,98,114,101,118,105,97,116,105,111,110,41,0,0,0};
static C_char C_TLS li171[] C_aligned={C_lihdr(0,0,18),40,95,101,120,105,116,32,46,32,99,111,100,101,50,51,48,56,41,0,0,0,0,0,0};
static C_char C_TLS li172[] C_aligned={C_lihdr(0,0,22),40,115,101,116,45,97,108,97,114,109,33,32,97,50,51,49,49,50,51,49,52,41,0,0};
static C_char C_TLS li173[] C_aligned={C_lihdr(0,0,50),40,115,101,116,45,98,117,102,102,101,114,105,110,103,45,109,111,100,101,33,32,112,111,114,116,50,51,50,49,32,109,111,100,101,50,51,50,50,32,46,32,115,105,122,101,50,51,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li174[] C_aligned={C_lihdr(0,0,25),40,116,101,114,109,105,110,97,108,45,112,111,114,116,63,32,112,111,114,116,50,51,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li175[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,116,101,114,109,105,110,97,108,45,99,104,101,99,107,32,99,97,108,108,101,114,50,51,53,48,32,112,111,114,116,50,51,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li176[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,110,97,109,101,32,112,111,114,116,50,51,54,56,41};
static C_char C_TLS li177[] C_aligned={C_lihdr(0,0,24),40,116,101,114,109,105,110,97,108,45,115,105,122,101,32,112,111,114,116,50,51,56,51,41};
static C_char C_TLS li178[] C_aligned={C_lihdr(0,0,15),40,103,101,116,45,104,111,115,116,45,110,97,109,101,41,0};
static C_char C_TLS li179[] C_aligned={C_lihdr(0,0,7),40,97,55,57,53,50,41,0};
static C_char C_TLS li180[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,102,110,115,50,52,54,52,41,0,0};
static C_char C_TLS li181[] C_aligned={C_lihdr(0,0,55),40,97,55,57,53,56,32,100,105,114,50,52,51,52,50,52,51,53,50,52,52,50,32,102,105,108,50,52,51,54,50,52,51,55,50,52,52,51,32,101,120,116,50,52,51,56,50,52,51,57,50,52,52,52,41,0};
static C_char C_TLS li182[] C_aligned={C_lihdr(0,0,21),40,99,111,110,99,45,108,111,111,112,32,112,97,116,104,115,50,52,50,57,41,0,0,0};
static C_char C_TLS li183[] C_aligned={C_lihdr(0,0,18),40,103,108,111,98,32,46,32,112,97,116,104,115,50,52,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li184[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,54,55,32,97,50,53,48,56,50,53,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li185[] C_aligned={C_lihdr(0,0,26),40,112,114,111,99,101,115,115,45,102,111,114,107,32,46,32,116,104,117,110,107,50,52,57,53,41,0,0,0,0,0,0};
static C_char C_TLS li186[] C_aligned={C_lihdr(0,0,28),40,115,101,116,97,114,103,32,97,50,53,50,49,50,53,50,55,32,97,50,53,50,48,50,53,50,56,41,0,0,0,0};
static C_char C_TLS li187[] C_aligned={C_lihdr(0,0,28),40,115,101,116,101,110,118,32,97,50,53,51,54,50,53,52,50,32,97,50,53,51,53,50,53,52,51,41,0,0,0,0};
static C_char C_TLS li188[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,50,53,57,51,32,105,50,54,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li189[] C_aligned={C_lihdr(0,0,25),40,100,111,108,111,111,112,50,53,56,50,32,97,108,50,53,56,56,32,105,50,53,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li190[] C_aligned={C_lihdr(0,0,34),40,98,111,100,121,50,53,54,55,32,97,114,103,108,105,115,116,50,53,55,55,32,101,110,118,108,105,115,116,50,53,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li191[] C_aligned={C_lihdr(0,0,34),40,100,101,102,45,101,110,118,108,105,115,116,50,53,55,48,32,37,97,114,103,108,105,115,116,50,53,54,53,50,54,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li192[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,97,114,103,108,105,115,116,50,53,54,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li193[] C_aligned={C_lihdr(0,0,44),40,112,114,111,99,101,115,115,45,101,120,101,99,117,116,101,32,102,105,108,101,110,97,109,101,50,53,53,55,32,46,32,116,109,112,50,53,53,54,50,53,53,56,41,0,0,0,0};
static C_char C_TLS li194[] C_aligned={C_lihdr(0,0,39),40,35,35,115,121,115,35,112,114,111,99,101,115,115,45,119,97,105,116,32,112,105,100,50,54,53,49,32,110,111,104,97,110,103,50,54,53,50,41,0};
static C_char C_TLS li195[] C_aligned={C_lihdr(0,0,7),40,97,56,51,52,57,41,0};
static C_char C_TLS li196[] C_aligned={C_lihdr(0,0,36),40,97,56,51,53,53,32,101,112,105,100,50,54,57,55,32,101,110,111,114,109,50,54,57,56,32,101,99,111,100,101,50,54,57,57,41,0,0,0,0};
static C_char C_TLS li197[] C_aligned={C_lihdr(0,0,25),40,112,114,111,99,101,115,115,45,119,97,105,116,32,46,32,97,114,103,115,50,54,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li198[] C_aligned={C_lihdr(0,0,20),40,99,117,114,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0};
static C_char C_TLS li199[] C_aligned={C_lihdr(0,0,19),40,112,97,114,101,110,116,45,112,114,111,99,101,115,115,45,105,100,41,0,0,0,0,0};
static C_char C_TLS li200[] C_aligned={C_lihdr(0,0,17),40,115,108,101,101,112,32,97,50,55,49,49,50,55,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li201[] C_aligned={C_lihdr(0,0,33),40,112,114,111,99,101,115,115,45,115,105,103,110,97,108,32,105,100,50,55,49,55,32,46,32,115,105,103,50,55,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li202[] C_aligned={C_lihdr(0,0,21),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,41,0,0,0};
static C_char C_TLS li203[] C_aligned={C_lihdr(0,0,42),40,35,35,115,121,115,35,115,104,101,108,108,45,99,111,109,109,97,110,100,45,97,114,103,117,109,101,110,116,115,32,99,109,100,108,105,110,50,55,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li204[] C_aligned={C_lihdr(0,0,30),40,112,114,111,99,101,115,115,45,114,117,110,32,102,50,55,52,53,32,46,32,97,114,103,115,50,55,52,54,41,0,0};
static C_char C_TLS li205[] C_aligned={C_lihdr(0,0,7),40,97,56,53,50,53,41,0};
static C_char C_TLS li206[] C_aligned={C_lihdr(0,0,29),40,97,56,53,51,49,32,95,50,55,57,53,32,102,108,103,50,55,57,54,32,99,111,100,50,55,57,55,41,0,0,0};
static C_char C_TLS li207[] C_aligned={C_lihdr(0,0,8),40,102,95,56,53,49,49,41};
static C_char C_TLS li208[] C_aligned={C_lihdr(0,0,68),40,109,97,107,101,45,111,110,45,99,108,111,115,101,32,108,111,99,50,55,56,48,32,112,105,100,50,55,56,49,32,99,108,115,118,101,99,50,55,56,50,32,105,100,120,50,55,56,51,32,105,100,120,97,50,55,56,52,32,105,100,120,98,50,55,56,53,41,0,0,0,0};
static C_char C_TLS li209[] C_aligned={C_lihdr(0,0,7),40,97,56,53,53,52,41,0};
static C_char C_TLS li210[] C_aligned={C_lihdr(0,0,19),40,97,56,53,54,48,32,105,50,56,49,48,32,111,50,56,49,49,41,0,0,0,0,0};
static C_char C_TLS li211[] C_aligned={C_lihdr(0,0,22),40,110,101,101,100,101,100,45,112,105,112,101,32,112,111,114,116,50,56,48,51,41,0,0};
static C_char C_TLS li212[] C_aligned={C_lihdr(0,0,34),40,99,111,110,110,101,99,116,45,112,97,114,101,110,116,32,112,105,112,101,50,56,49,52,32,112,111,114,116,50,56,49,53,41,0,0,0,0,0,0};
static C_char C_TLS li213[] C_aligned={C_lihdr(0,0,43),40,99,111,110,110,101,99,116,45,99,104,105,108,100,32,112,105,112,101,50,56,50,53,32,112,111,114,116,50,56,50,54,32,115,116,100,102,100,50,56,50,55,41,0,0,0,0,0};
static C_char C_TLS li214[] C_aligned={C_lihdr(0,0,14),40,115,119,97,112,112,101,100,45,101,110,100,115,41,0,0};
static C_char C_TLS li215[] C_aligned={C_lihdr(0,0,7),40,97,56,54,51,53,41,0};
static C_char C_TLS li216[] C_aligned={C_lihdr(0,0,67),40,115,112,97,119,110,32,99,109,100,50,56,52,54,32,97,114,103,115,50,56,52,55,32,101,110,118,50,56,52,56,32,115,116,100,111,117,116,102,50,56,52,57,32,115,116,100,105,110,102,50,56,53,48,32,115,116,100,101,114,114,102,50,56,53,49,41,0,0,0,0,0};
static C_char C_TLS li217[] C_aligned={C_lihdr(0,0,59),40,105,110,112,117,116,45,112,111,114,116,32,108,111,99,50,56,54,49,32,99,109,100,50,56,54,51,32,112,105,112,101,50,56,54,52,32,115,116,100,102,50,56,54,53,32,111,110,45,99,108,111,115,101,50,56,54,55,41,0,0,0,0,0};
static C_char C_TLS li218[] C_aligned={C_lihdr(0,0,60),40,111,117,116,112,117,116,45,112,111,114,116,32,108,111,99,50,56,55,52,32,99,109,100,50,56,55,54,32,112,105,112,101,50,56,55,55,32,115,116,100,102,50,56,55,56,32,111,110,45,99,108,111,115,101,50,56,56,48,41,0,0,0,0};
static C_char C_TLS li219[] C_aligned={C_lihdr(0,0,7),40,97,56,54,56,53,41,0};
static C_char C_TLS li220[] C_aligned={C_lihdr(0,0,50),40,97,56,54,57,49,32,105,110,112,105,112,101,50,56,57,57,32,111,117,116,112,105,112,101,50,57,48,48,32,101,114,114,112,105,112,101,50,57,48,49,32,112,105,100,50,57,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li221[] C_aligned={C_lihdr(0,0,83),40,35,35,115,121,115,35,112,114,111,99,101,115,115,32,108,111,99,50,56,56,56,32,99,109,100,50,56,56,57,32,97,114,103,115,50,56,57,48,32,101,110,118,50,56,57,49,32,115,116,100,111,117,116,102,50,56,57,50,32,115,116,100,105,110,102,50,56,57,51,32,115,116,100,101,114,114,102,50,56,57,52,41,0,0,0,0,0};
static C_char C_TLS li222[] C_aligned={C_lihdr(0,0,21),40,97,56,55,52,56,32,103,50,57,50,52,50,57,50,53,50,57,50,54,41,0,0,0};
static C_char C_TLS li223[] C_aligned={C_lihdr(0,0,19),40,99,104,107,115,116,114,108,115,116,32,108,115,116,50,57,49,55,41,0,0,0,0,0};
static C_char C_TLS li224[] C_aligned={C_lihdr(0,0,7),40,97,56,55,54,54,41,0};
static C_char C_TLS li225[] C_aligned={C_lihdr(0,0,38),40,97,56,55,55,50,32,105,110,50,57,51,54,32,111,117,116,50,57,51,55,32,112,105,100,50,57,51,56,32,101,114,114,50,57,51,57,41,0,0};
static C_char C_TLS li226[] C_aligned={C_lihdr(0,0,52),40,37,112,114,111,99,101,115,115,32,108,111,99,50,57,49,48,32,101,114,114,63,50,57,49,49,32,99,109,100,50,57,49,50,32,97,114,103,115,50,57,49,51,32,101,110,118,50,57,49,52,41,0,0,0,0};
static C_char C_TLS li227[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,50,57,54,49,32,97,114,103,115,50,57,55,49,32,101,110,118,50,57,55,50,41,0,0,0,0,0};
static C_char C_TLS li228[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,50,57,54,52,32,37,97,114,103,115,50,57,53,57,50,57,55,54,41,0,0,0,0,0};
static C_char C_TLS li229[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,50,57,54,51,41,0,0};
static C_char C_TLS li230[] C_aligned={C_lihdr(0,0,31),40,112,114,111,99,101,115,115,32,99,109,100,50,57,53,49,32,46,32,116,109,112,50,57,53,48,50,57,53,50,41,0};
static C_char C_TLS li231[] C_aligned={C_lihdr(0,0,27),40,98,111,100,121,51,48,48,53,32,97,114,103,115,51,48,49,53,32,101,110,118,51,48,49,54,41,0,0,0,0,0};
static C_char C_TLS li232[] C_aligned={C_lihdr(0,0,27),40,100,101,102,45,101,110,118,51,48,48,56,32,37,97,114,103,115,51,48,48,51,51,48,50,48,41,0,0,0,0,0};
static C_char C_TLS li233[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,97,114,103,115,51,48,48,55,41,0,0};
static C_char C_TLS li234[] C_aligned={C_lihdr(0,0,32),40,112,114,111,99,101,115,115,42,32,99,109,100,50,57,57,53,32,46,32,116,109,112,50,57,57,52,50,57,57,54,41};
static C_char C_TLS li235[] C_aligned={C_lihdr(0,0,14),40,102,95,57,48,54,50,32,120,51,48,57,48,41,0,0};
static C_char C_TLS li236[] C_aligned={C_lihdr(0,0,7),40,97,56,57,56,53,41,0};
static C_char C_TLS li237[] C_aligned={C_lihdr(0,0,7),40,97,56,57,57,48,41,0};
static C_char C_TLS li238[] C_aligned={C_lihdr(0,0,7),40,97,57,48,49,52,41,0};
static C_char C_TLS li239[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,32,102,115,51,48,57,54,32,114,51,48,57,55,41,0,0,0,0,0};
static C_char C_TLS li240[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,56,49,32,46,32,95,51,48,56,48,41};
static C_char C_TLS li241[] C_aligned={C_lihdr(0,0,16),40,102,95,57,48,55,51,32,46,32,95,51,48,55,56,41};
static C_char C_TLS li242[] C_aligned={C_lihdr(0,0,38),40,98,111,100,121,51,48,53,50,32,97,99,116,105,111,110,51,48,54,51,32,105,100,51,48,54,52,32,108,105,109,105,116,51,48,54,53,41,0,0};
static C_char C_TLS li243[] C_aligned={C_lihdr(0,0,43),40,100,101,102,45,108,105,109,105,116,51,48,53,54,32,37,97,99,116,105,111,110,51,48,52,57,51,49,51,55,32,37,105,100,51,48,53,48,51,49,51,56,41,0,0,0,0,0};
static C_char C_TLS li244[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,105,100,51,48,53,53,32,37,97,99,116,105,111,110,51,48,52,57,51,49,52,50,41,0,0,0,0};
static C_char C_TLS li245[] C_aligned={C_lihdr(0,0,19),40,97,57,49,48,49,32,120,51,49,52,55,32,121,51,49,52,56,41,0,0,0,0,0};
static C_char C_TLS li246[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,97,99,116,105,111,110,51,48,53,52,41};
static C_char C_TLS li247[] C_aligned={C_lihdr(0,0,51),40,102,105,110,100,45,102,105,108,101,115,32,100,105,114,51,48,52,48,32,112,114,101,100,51,48,52,49,32,46,32,97,99,116,105,111,110,45,105,100,45,108,105,109,105,116,51,48,52,50,41,0,0,0,0,0};
static C_char C_TLS li248[] C_aligned={C_lihdr(0,0,29),40,115,101,116,45,114,111,111,116,45,100,105,114,101,99,116,111,114,121,33,32,100,105,114,51,49,55,50,41,0,0,0};
static C_char C_TLS li249[] C_aligned={C_lihdr(0,0,15),40,97,57,50,48,48,32,112,105,100,49,52,50,54,41,0};
static C_char C_TLS li250[] C_aligned={C_lihdr(0,0,24),40,97,57,50,49,56,32,112,105,100,49,52,51,53,32,112,103,105,100,49,52,51,54,41};
static C_char C_TLS li251[] C_aligned={C_lihdr(0,0,7),40,97,57,50,51,57,41,0};
static C_char C_TLS li252[] C_aligned={C_lihdr(0,0,14),40,97,57,50,52,50,32,105,100,49,49,51,55,41,0,0};
static C_char C_TLS li253[] C_aligned={C_lihdr(0,0,7),40,97,57,50,53,55,41,0};
static C_char C_TLS li254[] C_aligned={C_lihdr(0,0,14),40,97,57,50,54,48,32,105,100,49,49,50,56,41,0,0};
static C_char C_TLS li255[] C_aligned={C_lihdr(0,0,7),40,97,57,50,55,53,41,0};
static C_char C_TLS li256[] C_aligned={C_lihdr(0,0,14),40,97,57,50,55,56,32,105,100,49,49,49,57,41,0,0};
static C_char C_TLS li257[] C_aligned={C_lihdr(0,0,7),40,97,57,50,57,51,41,0};
static C_char C_TLS li258[] C_aligned={C_lihdr(0,0,14),40,97,57,50,57,54,32,105,100,49,49,49,48,41,0,0};
static C_char C_TLS li259[] C_aligned={C_lihdr(0,0,13),40,97,57,51,49,49,32,110,49,48,57,50,41,0,0,0};
static C_char C_TLS li260[] C_aligned={C_lihdr(0,0,15),40,97,57,51,49,55,32,112,111,114,116,53,50,53,41,0};
static C_char C_TLS li261[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k9168 in set-root-directory! in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub3164(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3164(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from k8407 */
static C_word C_fcall stub2712(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2712(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub2707(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2707(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub2703(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2703(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub2547(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2547(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k8113 */
static C_word C_fcall stub2538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2538(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub2532(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2532(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k8094 */
static C_word C_fcall stub2523(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2523(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from k8070 */
static C_word C_fcall stub2509(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2509(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub2491(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2491(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2405(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2405(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k7882 */
static C_word C_fcall stub2376(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2376(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from k7859 */
static C_word C_fcall stub2361(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2361(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from k7748 */
static C_word C_fcall stub2312(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2312(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from k7726 */
static C_word C_fcall stub2303(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2303(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub2295(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub2295(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from strptime */
static C_word C_fcall stub2256(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub2256(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_word t2=(C_word )(C_a2);
C_r=((C_word)C_strptime(t0,t1,t2));
return C_r;}

/* from strftime */
static C_word C_fcall stub2214(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2214(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_word t1=(C_word )(C_a1);
C_r=C_mpointer(&C_a,(void*)C_strftime(t0,t1));
return C_r;}

/* from asctime */
static C_word C_fcall stub2206(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2206(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from k7533 */
static C_word C_fcall stub2190(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2190(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k7433 */
static C_word C_fcall stub2143(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub2143(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k7371 */
static C_word C_fcall stub2104(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub2104(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from k7270 */
static C_word C_fcall stub2055(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub2055(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k6021 in k6017 in file-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1468(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1468(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k5758 */
static C_word C_fcall stub1293(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub1293(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from k5627 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub1234(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1234(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from k5620 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1228(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1228(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from k5534 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1186(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1186(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a9239 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1134(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1134(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a9257 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1125(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1125(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a9275 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1116(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1116(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a9293 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall stub1107(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1107(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k3781 */
static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub252(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from k3771 */
static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub245(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from k3761 */
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from k3543 */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from k3492 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub46(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from k3485 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub40(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub40(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k3461 */
static C_word C_fcall stub23(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub23(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3434)
static void C_ccall f_3434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9318)
static void C_ccall f_9318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9334)
static void C_ccall f_9334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9322)
static void C_ccall f_9322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5241)
static void C_ccall f_5241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9312)
static void C_ccall f_9312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5376)
static void C_ccall f_5376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9297)
static void C_ccall f_9297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9307)
static void C_ccall f_9307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9294)
static void C_ccall f_9294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5418)
static void C_ccall f_5418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9279)
static void C_ccall f_9279(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9289)
static void C_ccall f_9289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9276)
static void C_ccall f_9276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5422)
static void C_ccall f_5422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9271)
static void C_ccall f_9271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9258)
static void C_ccall f_9258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5426)
static void C_ccall f_5426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9243)
static void C_ccall f_9243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9253)
static void C_ccall f_9253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9240)
static void C_ccall f_9240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9219)
static void C_ccall f_9219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9201)
static void C_ccall f_9201(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9214)
static void C_ccall f_9214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9208)
static void C_ccall f_9208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_ccall f_5948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5987)
static void C_ccall f_5987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9170)
static void C_ccall f_9170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_8919)
static void C_ccall f_8919r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9096)
static void C_fcall f_9096(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9102)
static void C_ccall f_9102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9091)
static void C_fcall f_9091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9086)
static void C_fcall f_9086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8921)
static void C_fcall f_8921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9073)
static void C_ccall f_9073(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_9081)
static void C_ccall f_9081(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8928)
static void C_fcall f_8928(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9061)
static void C_ccall f_9061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9055)
static void C_ccall f_9055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8938)
static void C_ccall f_8938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8940)
static void C_fcall f_8940(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8959)
static void C_ccall f_8959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9041)
static void C_ccall f_9041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9048)
static void C_ccall f_9048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9035)
static void C_ccall f_9035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9028)
static void C_ccall f_9028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9025)
static void C_ccall f_9025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9015)
static void C_ccall f_9015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8991)
static void C_ccall f_8991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8999)
static void C_ccall f_8999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9006)
static void C_ccall f_9006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9003)
static void C_ccall f_9003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8986)
static void C_ccall f_8986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8984)
static void C_ccall f_8984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_ccall f_9062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8859)
static void C_ccall f_8859(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8859)
static void C_ccall f_8859r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8871)
static void C_fcall f_8871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8866)
static void C_fcall f_8866(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8861)
static void C_fcall f_8861(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8799)
static void C_ccall f_8799(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8799)
static void C_ccall f_8799r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8811)
static void C_fcall f_8811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8806)
static void C_fcall f_8806(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8801)
static void C_fcall f_8801(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8738)
static void C_fcall f_8738(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8793)
static void C_ccall f_8793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8797)
static void C_ccall f_8797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8759)
static void C_ccall f_8759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8773)
static void C_ccall f_8773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8767)
static void C_ccall f_8767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8740)
static void C_fcall f_8740(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8749)
static void C_ccall f_8749(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8680)
static void C_ccall f_8680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8692)
static void C_ccall f_8692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8703)
static void C_ccall f_8703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8719)
static void C_ccall f_8719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8707)
static void C_ccall f_8707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8715)
static void C_ccall f_8715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8711)
static void C_ccall f_8711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8686)
static void C_ccall f_8686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8669)
static void C_fcall f_8669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8658)
static void C_fcall f_8658(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_8662)
static void C_ccall f_8662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8613)
static void C_fcall f_8613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8617)
static void C_ccall f_8617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8620)
static void C_ccall f_8620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8623)
static void C_ccall f_8623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8636)
static void C_ccall f_8636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8640)
static void C_ccall f_8640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_ccall f_8646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8634)
static void C_ccall f_8634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8597)
static C_word C_fcall f_8597(C_word *a,C_word t0);
C_noret_decl(f_8580)
static void C_fcall f_8580(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8593)
static void C_ccall f_8593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8505)
static void C_ccall f_8505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8566)
static void C_fcall f_8566(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8579)
static void C_ccall f_8579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8546)
static void C_fcall f_8546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8561)
static void C_ccall f_8561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8555)
static void C_ccall f_8555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_fcall f_8509(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_8511)
static void C_ccall f_8511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8532)
static void C_ccall f_8532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8526)
static void C_ccall f_8526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8453)
static void C_ccall f_8453(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8453)
static void C_ccall f_8453r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8460)
static void C_ccall f_8460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8483)
static void C_ccall f_8483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8447)
static void C_ccall f_8447(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8442)
static void C_ccall f_8442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8411)
static void C_ccall f_8411r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8404)
static void C_ccall f_8404(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8401)
static void C_ccall f_8401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8398)
static void C_ccall f_8398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8320)
static void C_ccall f_8320r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8356)
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_8121)
static void C_ccall f_8121r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_8255)
static void C_fcall f_8255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8250)
static void C_fcall f_8250(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8123)
static void C_fcall f_8123(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8141)
static void C_fcall f_8141(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8187)
static C_word C_fcall f_8187(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8154)
static void C_fcall f_8154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8179)
static void C_ccall f_8179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8102)
static C_word C_fcall f_8102(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8083)
static C_word C_fcall f_8083(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_8041)
static void C_ccall f_8041(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_8041)
static void C_ccall f_8041r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7938)
static void C_fcall f_7938(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7959)
static void C_ccall f_7959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8033)
static void C_ccall f_8033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7963)
static void C_ccall f_7963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7966)
static void C_ccall f_7966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7973)
static void C_ccall f_7973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_fcall f_7975(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7992)
static void C_ccall f_7992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8002)
static void C_ccall f_8002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8006)
static void C_ccall f_8006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_ccall f_7920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7924)
static void C_ccall f_7924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7927)
static void C_ccall f_7927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7913)
static void C_ccall f_7913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7862)
static void C_ccall f_7862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7866)
static void C_ccall f_7866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7830)
static void C_fcall f_7830(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7834)
static void C_ccall f_7834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7811)
static void C_ccall f_7811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7815)
static void C_ccall f_7815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7818)
static void C_ccall f_7818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_7752)
static void C_ccall f_7752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7745)
static void C_ccall f_7745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_7729)
static void C_ccall f_7729r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7702)
static void C_ccall f_7702(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7706)
static void C_ccall f_7706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7687)
static void C_ccall f_7687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7658)
static void C_ccall f_7658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7662)
static void C_ccall f_7662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7572)
static void C_ccall f_7572r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7576)
static void C_ccall f_7576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7579)
static void C_ccall f_7579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7598)
static void C_ccall f_7598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_ccall f_7536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7543)
static void C_ccall f_7543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7508)
static void C_ccall f_7508(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7489)
static void C_fcall f_7489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7483)
static void C_ccall f_7483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7474)
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_7377)
static void C_ccall f_7377r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_7381)
static void C_ccall f_7381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7387)
static void C_ccall f_7387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7406)
static void C_ccall f_7406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7393)
static void C_ccall f_7393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7273)
static void C_ccall f_7273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7279)
static void C_fcall f_7279(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7283)
static void C_ccall f_7283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7291)
static void C_fcall f_7291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7317)
static void C_ccall f_7317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7321)
static void C_ccall f_7321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7309)
static void C_ccall f_7309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7253)
static void C_ccall f_7253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7261)
static void C_ccall f_7261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7247)
static void C_ccall f_7247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7251)
static void C_ccall f_7251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7210)
static void C_ccall f_7210(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7234)
static void C_ccall f_7234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7217)
static void C_ccall f_7217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7174)
static void C_fcall f_7174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7191)
static void C_ccall f_7191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7139)
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7117)
static void C_ccall f_7117r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7121)
static void C_ccall f_7121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7102)
static void C_ccall f_7102r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7106)
static void C_ccall f_7106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_7087)
static void C_ccall f_7087r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6995)
static void C_fcall f_6995(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7017)
static void C_ccall f_7017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7023)
static void C_fcall f_7023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6984)
static void C_ccall f_6984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6893)
static void C_fcall f_6893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6888)
static void C_fcall f_6888(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6883)
static void C_fcall f_6883(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6699)
static void C_fcall f_6699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6810)
static void C_ccall f_6810(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6827)
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6837)
static void C_ccall f_6837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6795)
static void C_ccall f_6795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6751)
static void C_fcall f_6751(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6766)
static void C_ccall f_6766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6776)
static void C_ccall f_6776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6760)
static void C_ccall f_6760(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6755)
static void C_ccall f_6755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6758)
static void C_ccall f_6758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6705)
static void C_fcall f_6705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6740)
static void C_ccall f_6740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6721)
static void C_ccall f_6721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6215)
static void C_ccall f_6215r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_6619)
static void C_fcall f_6619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6614)
static void C_fcall f_6614(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6609)
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6604)
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6217)
static void C_fcall f_6217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6227)
static void C_ccall f_6227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6477)
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6483)
static void C_fcall f_6483(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6579)
static void C_ccall f_6579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6535)
static void C_ccall f_6535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6502)
static void C_ccall f_6502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_ccall f_6401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6409)
static void C_fcall f_6409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6411)
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6459)
static void C_ccall f_6459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_ccall f_6396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6371)
static void C_ccall f_6371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6381)
static void C_ccall f_6381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6344)
static void C_ccall f_6344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6259)
static void C_fcall f_6259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_fcall f_6271(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6308)
static void C_ccall f_6308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6317)
static void C_ccall f_6317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static C_word C_fcall f_6251(C_word t0);
C_noret_decl(f_6228)
static void C_fcall f_6228(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6195)
static void C_fcall f_6195(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6198)
static void C_ccall f_6198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_ccall f_6143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6147)
static void C_ccall f_6147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6165)
static void C_ccall f_6165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6129)
static void C_ccall f_6129r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6141)
static void C_ccall f_6141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_fcall f_6100(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6113)
static void C_ccall f_6113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_fcall f_6063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6071)
static void C_ccall f_6071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6019)
static void C_ccall f_6019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_ccall f_5996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5950)
static void C_ccall f_5950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5971)
static void C_ccall f_5971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5975)
static void C_ccall f_5975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_ccall f_5931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5941)
static void C_ccall f_5941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5925)
static void C_ccall f_5925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5889)
static void C_fcall f_5889(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5911)
static void C_ccall f_5911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5859)
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5832)
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_ccall f_5853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5768)
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5756)
static void C_ccall f_5756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5694)
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5698)
static void C_ccall f_5698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5703)
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5719)
static void C_ccall f_5719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5689)
static void C_ccall f_5689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_ccall f_5670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_fcall f_5646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static C_word C_fcall f_5624(C_word t0);
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_fcall f_5545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5555)
static void C_ccall f_5555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5582)
static void C_ccall f_5582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5525)
static void C_ccall f_5525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5499)
static void C_ccall f_5499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5511)
static void C_ccall f_5511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5478)
static void C_ccall f_5478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5439)
static void C_fcall f_5439(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5457)
static void C_ccall f_5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5378)
static void C_ccall f_5378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5393)
static void C_ccall f_5393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5401)
static void C_ccall f_5401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5345)
static void C_ccall f_5345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_fcall f_5313(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5283)
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5290)
static void C_ccall f_5290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5196)
static void C_ccall f_5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5176)
static void C_ccall f_5176r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5141)
static void C_ccall f_5141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5108)
static void C_ccall f_5108r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5123)
static void C_ccall f_5123r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5099)
static void C_ccall f_5099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5056)
static void C_ccall f_5056r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_ccall f_5070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_ccall f_5041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5034)
static void C_ccall f_5034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_fcall f_5005(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_fcall f_4999(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4987)
static C_word C_fcall f_4987(C_word t0);
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4797)
static void C_fcall f_4797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_fcall f_4816(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_fcall f_4860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4873)
static void C_ccall f_4873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4897)
static void C_ccall f_4897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_ccall f_4677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_fcall f_4686(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4693)
static void C_ccall f_4693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_fcall f_4754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4731)
static void C_ccall f_4731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4727)
static void C_ccall f_4727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4614)
static void C_fcall f_4614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4647)
static void C_ccall f_4647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4603)
static C_word C_fcall f_4603(C_word t0);
C_noret_decl(f_4598)
static void C_fcall f_4598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4550)
static void C_ccall f_4550r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_ccall f_4563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4534)
static void C_ccall f_4534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4475)
static void C_fcall f_4475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4372)
static void C_fcall f_4372(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_ccall f_4469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_fcall f_4403(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4413)
static void C_ccall f_4413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4416)
static void C_ccall f_4416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4425)
static void C_fcall f_4425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4368)
static void C_ccall f_4368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_ccall f_4340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_ccall f_4246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4171)
static void C_ccall f_4171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4177)
static void C_ccall f_4177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4155)
static void C_ccall f_4155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_ccall f_4127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4099)
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4073)
static void C_ccall f_4073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4017)
static void C_ccall f_4017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_fcall f_3976(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_fcall f_3809(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3889)
static void C_ccall f_3889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_fcall f_3848(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_fcall f_3852(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3774)
static C_word C_fcall f_3774(C_word t0,C_word t1);
C_noret_decl(f_3764)
static C_word C_fcall f_3764(C_word t0,C_word t1);
C_noret_decl(f_3758)
static C_word C_fcall f_3758(C_word t0);
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_ccall f_3746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3687)
static void C_ccall f_3687r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3645)
static void C_ccall f_3645r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_ccall f_3658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_ccall f_3609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static void C_ccall f_3612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3546)
static void C_ccall f_3546r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3482)
static void C_ccall f_3482(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9096)
static void C_fcall trf_9096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9096(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9096(t0,t1);}

C_noret_decl(trf_9091)
static void C_fcall trf_9091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9091(t0,t1,t2);}

C_noret_decl(trf_9086)
static void C_fcall trf_9086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9086(t0,t1,t2,t3);}

C_noret_decl(trf_8921)
static void C_fcall trf_8921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8921(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8921(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8928)
static void C_fcall trf_8928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8928(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8928(t0,t1);}

C_noret_decl(trf_8940)
static void C_fcall trf_8940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8940(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8940(t0,t1,t2,t3);}

C_noret_decl(trf_8871)
static void C_fcall trf_8871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8871(t0,t1);}

C_noret_decl(trf_8866)
static void C_fcall trf_8866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8866(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8866(t0,t1,t2);}

C_noret_decl(trf_8861)
static void C_fcall trf_8861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8861(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8861(t0,t1,t2,t3);}

C_noret_decl(trf_8811)
static void C_fcall trf_8811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8811(t0,t1);}

C_noret_decl(trf_8806)
static void C_fcall trf_8806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8806(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8806(t0,t1,t2);}

C_noret_decl(trf_8801)
static void C_fcall trf_8801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8801(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8801(t0,t1,t2,t3);}

C_noret_decl(trf_8738)
static void C_fcall trf_8738(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8738(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8738(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_8740)
static void C_fcall trf_8740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8740(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8740(t0,t1,t2);}

C_noret_decl(trf_8669)
static void C_fcall trf_8669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8669(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8669(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8658)
static void C_fcall trf_8658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8658(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8658(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8613)
static void C_fcall trf_8613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8613(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8613(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8580)
static void C_fcall trf_8580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8580(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8580(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8566)
static void C_fcall trf_8566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8566(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8566(t0,t1,t2,t3);}

C_noret_decl(trf_8546)
static void C_fcall trf_8546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8546(t0,t1,t2);}

C_noret_decl(trf_8509)
static void C_fcall trf_8509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8509(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_8509(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_8255)
static void C_fcall trf_8255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8255(t0,t1);}

C_noret_decl(trf_8250)
static void C_fcall trf_8250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8250(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8250(t0,t1,t2);}

C_noret_decl(trf_8123)
static void C_fcall trf_8123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8123(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8123(t0,t1,t2,t3);}

C_noret_decl(trf_8141)
static void C_fcall trf_8141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8141(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8141(t0,t1,t2,t3);}

C_noret_decl(trf_8154)
static void C_fcall trf_8154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8154(t0,t1);}

C_noret_decl(trf_7938)
static void C_fcall trf_7938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7938(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7938(t0,t1,t2);}

C_noret_decl(trf_7975)
static void C_fcall trf_7975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7975(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7975(t0,t1,t2);}

C_noret_decl(trf_7830)
static void C_fcall trf_7830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7830(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7830(t0,t1,t2);}

C_noret_decl(trf_7489)
static void C_fcall trf_7489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7489(t0,t1,t2);}

C_noret_decl(trf_7279)
static void C_fcall trf_7279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7279(t0,t1,t2);}

C_noret_decl(trf_7291)
static void C_fcall trf_7291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7291(t0,t1,t2);}

C_noret_decl(trf_7174)
static void C_fcall trf_7174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7174(t0,t1);}

C_noret_decl(trf_7069)
static void C_fcall trf_7069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7069(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7069(t0,t1,t2,t3);}

C_noret_decl(trf_6995)
static void C_fcall trf_6995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6995(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6995(t0,t1,t2,t3);}

C_noret_decl(trf_7023)
static void C_fcall trf_7023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7023(t0,t1);}

C_noret_decl(trf_6893)
static void C_fcall trf_6893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6893(t0,t1);}

C_noret_decl(trf_6888)
static void C_fcall trf_6888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6888(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6888(t0,t1,t2);}

C_noret_decl(trf_6883)
static void C_fcall trf_6883(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6883(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6883(t0,t1,t2,t3);}

C_noret_decl(trf_6699)
static void C_fcall trf_6699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6699(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6699(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6827)
static void C_fcall trf_6827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6827(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6827(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6751)
static void C_fcall trf_6751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6751(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6751(t0,t1);}

C_noret_decl(trf_6705)
static void C_fcall trf_6705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6705(t0,t1,t2,t3);}

C_noret_decl(trf_6619)
static void C_fcall trf_6619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6619(t0,t1);}

C_noret_decl(trf_6614)
static void C_fcall trf_6614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6614(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6614(t0,t1,t2);}

C_noret_decl(trf_6609)
static void C_fcall trf_6609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6609(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6609(t0,t1,t2,t3);}

C_noret_decl(trf_6604)
static void C_fcall trf_6604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6604(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6604(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6217)
static void C_fcall trf_6217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6217(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6217(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6483)
static void C_fcall trf_6483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6483(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6483(t0,t1,t2);}

C_noret_decl(trf_6409)
static void C_fcall trf_6409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6409(t0,t1);}

C_noret_decl(trf_6411)
static void C_fcall trf_6411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6411(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6411(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6259)
static void C_fcall trf_6259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6259(t0,t1);}

C_noret_decl(trf_6271)
static void C_fcall trf_6271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6271(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6271(t0,t1);}

C_noret_decl(trf_6228)
static void C_fcall trf_6228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6228(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6228(t0,t1);}

C_noret_decl(trf_6195)
static void C_fcall trf_6195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6195(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6195(t0,t1);}

C_noret_decl(trf_6100)
static void C_fcall trf_6100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6100(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6100(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6063)
static void C_fcall trf_6063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6063(t0,t1,t2);}

C_noret_decl(trf_5889)
static void C_fcall trf_5889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5889(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5889(t0,t1,t2,t3);}

C_noret_decl(trf_5703)
static void C_fcall trf_5703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5703(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5703(t0,t1,t2,t3);}

C_noret_decl(trf_5646)
static void C_fcall trf_5646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5646(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5646(t0,t1,t2);}

C_noret_decl(trf_5545)
static void C_fcall trf_5545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5545(t0,t1);}

C_noret_decl(trf_5568)
static void C_fcall trf_5568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5568(t0,t1,t2);}

C_noret_decl(trf_5439)
static void C_fcall trf_5439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5439(t0,t1);}

C_noret_decl(trf_5313)
static void C_fcall trf_5313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5313(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5313(t0,t1,t2,t3);}

C_noret_decl(trf_5005)
static void C_fcall trf_5005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5005(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5005(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4999)
static void C_fcall trf_4999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4999(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4999(t0,t1);}

C_noret_decl(trf_4797)
static void C_fcall trf_4797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4797(t0,t1);}

C_noret_decl(trf_4816)
static void C_fcall trf_4816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4816(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4816(t0,t1);}

C_noret_decl(trf_4860)
static void C_fcall trf_4860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4860(t0,t1);}

C_noret_decl(trf_4686)
static void C_fcall trf_4686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4686(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4686(t0,t1,t2,t3);}

C_noret_decl(trf_4754)
static void C_fcall trf_4754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4754(t0,t1);}

C_noret_decl(trf_4614)
static void C_fcall trf_4614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4614(t0,t1);}

C_noret_decl(trf_4598)
static void C_fcall trf_4598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4598(t0,t1);}

C_noret_decl(trf_4475)
static void C_fcall trf_4475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4475(t0,t1);}

C_noret_decl(trf_4470)
static void C_fcall trf_4470(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4470(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4470(t0,t1,t2);}

C_noret_decl(trf_4372)
static void C_fcall trf_4372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4372(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4372(t0,t1,t2,t3);}

C_noret_decl(trf_4403)
static void C_fcall trf_4403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4403(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4403(t0,t1);}

C_noret_decl(trf_4425)
static void C_fcall trf_4425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4425(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4425(t0,t1);}

C_noret_decl(trf_3976)
static void C_fcall trf_3976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3976(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3976(t0,t1,t2,t3);}

C_noret_decl(trf_3809)
static void C_fcall trf_3809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3809(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3809(t0,t1);}

C_noret_decl(trf_3848)
static void C_fcall trf_3848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3848(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3848(t0,t1);}

C_noret_decl(trf_3852)
static void C_fcall trf_3852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3852(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3852(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3360)){
C_save(t1);
C_rereclaim2(3360*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,467);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_h_intern(&lf[51],9,"file-open");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[53]=C_h_intern(&lf[53],17,"\003sysmake-c-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysexpand-home-path");
lf[55]=C_h_intern(&lf[55],10,"file-close");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[57]=C_h_intern(&lf[57],11,"make-string");
lf[58]=C_h_intern(&lf[58],9,"file-read");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[60]=C_h_intern(&lf[60],11,"\000type-error");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[62]=C_h_intern(&lf[62],10,"file-write");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[65]=C_h_intern(&lf[65],12,"file-mkstemp");
lf[66]=C_h_intern(&lf[66],13,"\003syssubstring");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[68]=C_h_intern(&lf[68],11,"file-select");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[70]=C_h_intern(&lf[70],12,"\003sysfor-each");
lf[71]=C_h_intern(&lf[71],8,"seek/set");
lf[72]=C_h_intern(&lf[72],8,"seek/end");
lf[73]=C_h_intern(&lf[73],8,"seek/cur");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[77]=C_h_intern(&lf[77],9,"file-stat");
lf[78]=C_h_intern(&lf[78],9,"file-size");
lf[79]=C_h_intern(&lf[79],22,"file-modification-time");
lf[80]=C_h_intern(&lf[80],16,"file-access-time");
lf[81]=C_h_intern(&lf[81],16,"file-change-time");
lf[82]=C_h_intern(&lf[82],10,"file-owner");
lf[83]=C_h_intern(&lf[83],16,"file-permissions");
lf[84]=C_h_intern(&lf[84],13,"regular-file\077");
lf[85]=C_h_intern(&lf[85],14,"symbolic-link\077");
lf[86]=C_h_intern(&lf[86],13,"stat-regular\077");
lf[87]=C_h_intern(&lf[87],15,"stat-directory\077");
lf[88]=C_h_intern(&lf[88],17,"character-device\077");
lf[89]=C_h_intern(&lf[89],17,"stat-char-device\077");
lf[90]=C_h_intern(&lf[90],13,"block-device\077");
lf[91]=C_h_intern(&lf[91],18,"stat-block-device\077");
lf[92]=C_h_intern(&lf[92],5,"fifo\077");
lf[93]=C_h_intern(&lf[93],10,"stat-fifo\077");
lf[94]=C_h_intern(&lf[94],13,"stat-symlink\077");
lf[95]=C_h_intern(&lf[95],7,"socket\077");
lf[96]=C_h_intern(&lf[96],12,"stat-socket\077");
lf[97]=C_h_intern(&lf[97],18,"set-file-position!");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[99]=C_h_intern(&lf[99],6,"stream");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[101]=C_h_intern(&lf[101],5,"port\077");
lf[102]=C_h_intern(&lf[102],13,"\000bounds-error");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[104]=C_h_intern(&lf[104],13,"file-position");
lf[105]=C_h_intern(&lf[105],16,"create-directory");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot stat file");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\026path segment is a file");
lf[110]=C_h_intern(&lf[110],12,"file-exists\077");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[112]=C_h_intern(&lf[112],12,"string-split");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[114]=C_h_intern(&lf[114],16,"change-directory");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[116]=C_h_intern(&lf[116],16,"delete-directory");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[118]=C_h_intern(&lf[118],10,"string-ref");
lf[119]=C_h_intern(&lf[119],6,"string");
lf[120]=C_h_intern(&lf[120],9,"directory");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[122]=C_h_intern(&lf[122],16,"\003sysmake-pointer");
lf[123]=C_h_intern(&lf[123],17,"current-directory");
lf[124]=C_h_intern(&lf[124],10,"directory\077");
lf[125]=C_h_intern(&lf[125],13,"\003sysfile-info");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[127]=C_h_intern(&lf[127],5,"null\077");
lf[128]=C_h_intern(&lf[128],6,"char=\077");
lf[129]=C_h_intern(&lf[129],8,"string=\077");
lf[130]=C_h_intern(&lf[130],16,"char-alphabetic\077");
lf[131]=C_h_intern(&lf[131],18,"string-intersperse");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[133]=C_h_intern(&lf[133],24,"get-environment-variable");
lf[134]=C_h_intern(&lf[134],17,"current-user-name");
lf[135]=C_h_intern(&lf[135],9,"condition");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[137]=C_h_intern(&lf[137],22,"with-exception-handler");
lf[138]=C_h_intern(&lf[138],30,"call-with-current-continuation");
lf[139]=C_h_intern(&lf[139],14,"canonical-path");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[143]=C_h_intern(&lf[143],7,"reverse");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\006/home/");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[154]=C_h_intern(&lf[154],5,"\000text");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[157]=C_h_intern(&lf[157],13,"\003sysmake-port");
lf[158]=C_h_intern(&lf[158],21,"\003sysstream-port-class");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[160]=C_h_intern(&lf[160],15,"open-input-pipe");
lf[161]=C_h_intern(&lf[161],7,"\000binary");
lf[162]=C_h_intern(&lf[162],16,"open-output-pipe");
lf[163]=C_h_intern(&lf[163],16,"close-input-pipe");
lf[164]=C_h_intern(&lf[164],23,"close-input/output-pipe");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[166]=C_h_intern(&lf[166],14,"\003syscheck-port");
lf[167]=C_h_intern(&lf[167],17,"close-output-pipe");
lf[168]=C_h_intern(&lf[168],20,"call-with-input-pipe");
lf[169]=C_h_intern(&lf[169],21,"call-with-output-pipe");
lf[170]=C_h_intern(&lf[170],20,"with-input-from-pipe");
lf[171]=C_h_intern(&lf[171],18,"\003sysstandard-input");
lf[172]=C_h_intern(&lf[172],19,"with-output-to-pipe");
lf[173]=C_h_intern(&lf[173],19,"\003sysstandard-output");
lf[174]=C_h_intern(&lf[174],11,"create-pipe");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[176]=C_h_intern(&lf[176],11,"signal/term");
lf[177]=C_h_intern(&lf[177],11,"signal/kill");
lf[178]=C_h_intern(&lf[178],10,"signal/int");
lf[179]=C_h_intern(&lf[179],10,"signal/hup");
lf[180]=C_h_intern(&lf[180],10,"signal/fpe");
lf[181]=C_h_intern(&lf[181],10,"signal/ill");
lf[182]=C_h_intern(&lf[182],11,"signal/segv");
lf[183]=C_h_intern(&lf[183],11,"signal/abrt");
lf[184]=C_h_intern(&lf[184],11,"signal/trap");
lf[185]=C_h_intern(&lf[185],11,"signal/quit");
lf[186]=C_h_intern(&lf[186],11,"signal/alrm");
lf[187]=C_h_intern(&lf[187],13,"signal/vtalrm");
lf[188]=C_h_intern(&lf[188],11,"signal/prof");
lf[189]=C_h_intern(&lf[189],9,"signal/io");
lf[190]=C_h_intern(&lf[190],10,"signal/urg");
lf[191]=C_h_intern(&lf[191],11,"signal/chld");
lf[192]=C_h_intern(&lf[192],11,"signal/cont");
lf[193]=C_h_intern(&lf[193],11,"signal/stop");
lf[194]=C_h_intern(&lf[194],11,"signal/tstp");
lf[195]=C_h_intern(&lf[195],11,"signal/pipe");
lf[196]=C_h_intern(&lf[196],11,"signal/xcpu");
lf[197]=C_h_intern(&lf[197],11,"signal/xfsz");
lf[198]=C_h_intern(&lf[198],11,"signal/usr1");
lf[199]=C_h_intern(&lf[199],11,"signal/usr2");
lf[200]=C_h_intern(&lf[200],12,"signal/winch");
lf[201]=C_h_intern(&lf[201],12,"signals-list");
lf[202]=C_h_intern(&lf[202],18,"\003sysinterrupt-hook");
lf[203]=C_h_intern(&lf[203],14,"signal-handler");
lf[204]=C_h_intern(&lf[204],19,"set-signal-handler!");
lf[205]=C_h_intern(&lf[205],16,"set-signal-mask!");
lf[206]=C_h_intern(&lf[206],14,"\000process-error");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[208]=C_h_intern(&lf[208],11,"signal-mask");
lf[209]=C_h_intern(&lf[209],14,"signal-masked\077");
lf[210]=C_h_intern(&lf[210],12,"signal-mask!");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[212]=C_h_intern(&lf[212],14,"signal-unmask!");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[214]=C_h_intern(&lf[214],18,"system-information");
lf[215]=C_h_intern(&lf[215],25,"\003syspeek-nonnull-c-string");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[217]=C_h_intern(&lf[217],15,"current-user-id");
lf[218]=C_h_intern(&lf[218],25,"current-effective-user-id");
lf[219]=C_h_intern(&lf[219],16,"current-group-id");
lf[220]=C_h_intern(&lf[220],26,"current-effective-group-id");
lf[221]=C_h_intern(&lf[221],16,"user-information");
lf[222]=C_h_intern(&lf[222],6,"vector");
lf[223]=C_h_intern(&lf[223],4,"list");
lf[224]=C_h_intern(&lf[224],27,"current-effective-user-name");
lf[225]=C_h_intern(&lf[225],17,"group-information");
lf[227]=C_h_intern(&lf[227],10,"get-groups");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[231]=C_h_intern(&lf[231],11,"set-groups!");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[234]=C_h_intern(&lf[234],17,"initialize-groups");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[236]=C_h_intern(&lf[236],10,"errno/perm");
lf[237]=C_h_intern(&lf[237],11,"errno/noent");
lf[238]=C_h_intern(&lf[238],10,"errno/srch");
lf[239]=C_h_intern(&lf[239],10,"errno/intr");
lf[240]=C_h_intern(&lf[240],8,"errno/io");
lf[241]=C_h_intern(&lf[241],12,"errno/noexec");
lf[242]=C_h_intern(&lf[242],10,"errno/badf");
lf[243]=C_h_intern(&lf[243],11,"errno/child");
lf[244]=C_h_intern(&lf[244],11,"errno/nomem");
lf[245]=C_h_intern(&lf[245],11,"errno/acces");
lf[246]=C_h_intern(&lf[246],11,"errno/fault");
lf[247]=C_h_intern(&lf[247],10,"errno/busy");
lf[248]=C_h_intern(&lf[248],12,"errno/notdir");
lf[249]=C_h_intern(&lf[249],11,"errno/isdir");
lf[250]=C_h_intern(&lf[250],11,"errno/inval");
lf[251]=C_h_intern(&lf[251],11,"errno/mfile");
lf[252]=C_h_intern(&lf[252],11,"errno/nospc");
lf[253]=C_h_intern(&lf[253],11,"errno/spipe");
lf[254]=C_h_intern(&lf[254],10,"errno/pipe");
lf[255]=C_h_intern(&lf[255],11,"errno/again");
lf[256]=C_h_intern(&lf[256],10,"errno/rofs");
lf[257]=C_h_intern(&lf[257],11,"errno/exist");
lf[258]=C_h_intern(&lf[258],16,"errno/wouldblock");
lf[259]=C_h_intern(&lf[259],10,"errno/2big");
lf[260]=C_h_intern(&lf[260],12,"errno/deadlk");
lf[261]=C_h_intern(&lf[261],9,"errno/dom");
lf[262]=C_h_intern(&lf[262],10,"errno/fbig");
lf[263]=C_h_intern(&lf[263],11,"errno/ilseq");
lf[264]=C_h_intern(&lf[264],11,"errno/mlink");
lf[265]=C_h_intern(&lf[265],17,"errno/nametoolong");
lf[266]=C_h_intern(&lf[266],11,"errno/nfile");
lf[267]=C_h_intern(&lf[267],11,"errno/nodev");
lf[268]=C_h_intern(&lf[268],11,"errno/nolck");
lf[269]=C_h_intern(&lf[269],11,"errno/nosys");
lf[270]=C_h_intern(&lf[270],14,"errno/notempty");
lf[271]=C_h_intern(&lf[271],11,"errno/notty");
lf[272]=C_h_intern(&lf[272],10,"errno/nxio");
lf[273]=C_h_intern(&lf[273],11,"errno/range");
lf[274]=C_h_intern(&lf[274],10,"errno/xdev");
lf[275]=C_h_intern(&lf[275],16,"change-file-mode");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[277]=C_h_intern(&lf[277],17,"change-file-owner");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[279]=C_h_intern(&lf[279],17,"file-read-access\077");
lf[280]=C_h_intern(&lf[280],18,"file-write-access\077");
lf[281]=C_h_intern(&lf[281],20,"file-execute-access\077");
lf[282]=C_h_intern(&lf[282],14,"create-session");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[284]=C_h_intern(&lf[284],16,"process-group-id");
lf[285]=C_h_intern(&lf[285],20,"create-symbolic-link");
lf[286]=C_h_intern(&lf[286],18,"create-symbol-link");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[288]=C_h_intern(&lf[288],9,"substring");
lf[289]=C_h_intern(&lf[289],18,"read-symbolic-link");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[291]=C_h_intern(&lf[291],9,"file-link");
lf[292]=C_h_intern(&lf[292],9,"hard-link");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[294]=C_h_intern(&lf[294],12,"fileno/stdin");
lf[295]=C_h_intern(&lf[295],13,"fileno/stdout");
lf[296]=C_h_intern(&lf[296],13,"fileno/stderr");
lf[297]=C_h_intern(&lf[297],7,"\000append");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[305]=C_h_intern(&lf[305],16,"open-input-file*");
lf[306]=C_h_intern(&lf[306],17,"open-output-file*");
lf[307]=C_h_intern(&lf[307],12,"port->fileno");
lf[308]=C_h_intern(&lf[308],6,"socket");
lf[309]=C_h_intern(&lf[309],20,"\003systcp-port->fileno");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[312]=C_h_intern(&lf[312],25,"\003syspeek-unsigned-integer");
lf[313]=C_h_intern(&lf[313],16,"duplicate-fileno");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[315]=C_h_intern(&lf[315],15,"make-input-port");
lf[316]=C_h_intern(&lf[316],14,"set-port-name!");
lf[317]=C_h_intern(&lf[317],21,"\003syscustom-input-port");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[319]=C_h_intern(&lf[319],17,"\003systhread-yield!");
lf[320]=C_h_intern(&lf[320],25,"\003systhread-block-for-i/o!");
lf[321]=C_h_intern(&lf[321],18,"\003syscurrent-thread");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[326]=C_h_intern(&lf[326],17,"\003sysstring-append");
lf[327]=C_h_intern(&lf[327],15,"\003sysmake-string");
lf[328]=C_h_intern(&lf[328],20,"\003sysscan-buffer-line");
lf[329]=C_h_intern(&lf[329],4,"noop");
lf[330]=C_h_intern(&lf[330],16,"make-output-port");
lf[331]=C_h_intern(&lf[331],22,"\003syscustom-output-port");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[334]=C_h_intern(&lf[334],13,"file-truncate");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[337]=C_h_intern(&lf[337],4,"lock");
lf[338]=C_h_intern(&lf[338],9,"file-lock");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[340]=C_h_intern(&lf[340],18,"file-lock/blocking");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[342]=C_h_intern(&lf[342],14,"file-test-lock");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[344]=C_h_intern(&lf[344],11,"file-unlock");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[346]=C_h_intern(&lf[346],11,"create-fifo");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[349]=C_h_intern(&lf[349],6,"setenv");
lf[350]=C_h_intern(&lf[350],8,"unsetenv");
lf[351]=C_h_intern(&lf[351],25,"get-environment-variables");
lf[352]=C_h_intern(&lf[352],19,"current-environment");
lf[353]=C_h_intern(&lf[353],9,"prot/read");
lf[354]=C_h_intern(&lf[354],10,"prot/write");
lf[355]=C_h_intern(&lf[355],9,"prot/exec");
lf[356]=C_h_intern(&lf[356],9,"prot/none");
lf[357]=C_h_intern(&lf[357],9,"map/fixed");
lf[358]=C_h_intern(&lf[358],10,"map/shared");
lf[359]=C_h_intern(&lf[359],11,"map/private");
lf[360]=C_h_intern(&lf[360],13,"map/anonymous");
lf[361]=C_h_intern(&lf[361],8,"map/file");
lf[362]=C_h_intern(&lf[362],18,"map-file-to-memory");
lf[363]=C_h_intern(&lf[363],4,"mmap");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[365]=C_h_intern(&lf[365],20,"\003syspointer->address");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[367]=C_h_intern(&lf[367],16,"\003sysnull-pointer");
lf[368]=C_h_intern(&lf[368],22,"unmap-file-from-memory");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[370]=C_h_intern(&lf[370],26,"memory-mapped-file-pointer");
lf[371]=C_h_intern(&lf[371],19,"memory-mapped-file\077");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[374]=C_h_intern(&lf[374],19,"seconds->local-time");
lf[375]=C_h_intern(&lf[375],18,"\003sysdecode-seconds");
lf[376]=C_h_intern(&lf[376],17,"seconds->utc-time");
lf[377]=C_h_intern(&lf[377],15,"seconds->string");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[379]=C_h_intern(&lf[379],12,"time->string");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000 time formatting overflows buffer");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[382]=C_h_intern(&lf[382],12,"string->time");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\027%a %b %e %H:%M:%S %Z %Y");
lf[384]=C_h_intern(&lf[384],19,"local-time->seconds");
lf[385]=C_h_intern(&lf[385],15,"\003syscons-flonum");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[387]=C_h_intern(&lf[387],17,"utc-time->seconds");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[389]=C_h_intern(&lf[389],27,"local-timezone-abbreviation");
lf[390]=C_h_intern(&lf[390],5,"_exit");
lf[391]=C_h_intern(&lf[391],10,"set-alarm!");
lf[392]=C_h_intern(&lf[392],19,"set-buffering-mode!");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[394]=C_h_intern(&lf[394],5,"\000full");
lf[395]=C_h_intern(&lf[395],5,"\000line");
lf[396]=C_h_intern(&lf[396],5,"\000none");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[398]=C_h_intern(&lf[398],14,"terminal-port\077");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[401]=C_h_intern(&lf[401],13,"terminal-name");
lf[402]=C_h_intern(&lf[402],13,"terminal-size");
lf[403]=C_h_intern(&lf[403],6,"\000error");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[405]=C_h_intern(&lf[405],17,"\003sysmake-locative");
lf[406]=C_h_intern(&lf[406],8,"location");
lf[407]=C_h_intern(&lf[407],13,"get-host-name");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[409]=C_h_intern(&lf[409],6,"regexp");
lf[410]=C_h_intern(&lf[410],12,"string-match");
lf[411]=C_h_intern(&lf[411],12,"glob->regexp");
lf[412]=C_h_intern(&lf[412],13,"make-pathname");
lf[413]=C_h_intern(&lf[413],18,"decompose-pathname");
lf[414]=C_h_intern(&lf[414],4,"glob");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[417]=C_h_intern(&lf[417],12,"process-fork");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[419]=C_h_intern(&lf[419],24,"pathname-strip-directory");
lf[420]=C_h_intern(&lf[420],15,"process-execute");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[422]=C_h_intern(&lf[422],16,"\003sysprocess-wait");
lf[423]=C_h_intern(&lf[423],12,"process-wait");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[425]=C_h_intern(&lf[425],18,"current-process-id");
lf[426]=C_h_intern(&lf[426],17,"parent-process-id");
lf[427]=C_h_intern(&lf[427],5,"sleep");
lf[428]=C_h_intern(&lf[428],14,"process-signal");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[430]=C_h_intern(&lf[430],17,"\003sysshell-command");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[433]=C_h_intern(&lf[433],27,"\003sysshell-command-arguments");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[435]=C_h_intern(&lf[435],11,"process-run");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[437]=C_h_intern(&lf[437],11,"\003sysprocess");
lf[438]=C_h_intern(&lf[438],7,"process");
lf[439]=C_h_intern(&lf[439],8,"process*");
lf[440]=C_h_intern(&lf[440],10,"find-files");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[444]=C_h_intern(&lf[444],16,"\003sysdynamic-wind");
lf[445]=C_h_intern(&lf[445],13,"pathname-file");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[447]=C_h_intern(&lf[447],7,"regexp\077");
lf[448]=C_h_intern(&lf[448],19,"set-root-directory!");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[451]=C_h_intern(&lf[451],21,"set-process-group-id!");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[453]=C_h_intern(&lf[453],18,"getter-with-setter");
lf[454]=C_h_intern(&lf[454],26,"effective-group-id!-setter");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[456]=C_h_intern(&lf[456],12,"set-user-id!");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[458]=C_h_intern(&lf[458],25,"effective-user-id!-setter");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[461]=C_h_intern(&lf[461],23,"\003sysuser-interrupt-hook");
lf[462]=C_h_intern(&lf[462],11,"make-vector");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[465]=C_h_intern(&lf[465],17,"register-feature!");
lf[466]=C_h_intern(&lf[466],5,"posix");
C_register_lf2(lf,467,create_ptable());
t2=C_mutate(&lf[0] /* (set! c150 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3434,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3432 */
static void C_ccall f_3434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3435 in k3432 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3438 in k3435 in k3432 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 501  register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[465]+1)))(3,*((C_word*)lf[465]+1),t2,lf[466]);}

/* k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word ab[110],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3] /* (set! posix-error ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3464,a[2]=t2,a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! posix-error ...) */,lf[3]);
t5=C_mutate((C_word*)lf[9]+1 /* (set! file-nonblocking! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3482,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! file-select-one ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! pipe/buf ...) */,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1 /* (set! fcntl/dupfd ...) */,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1 /* (set! fcntl/getfd ...) */,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1 /* (set! fcntl/setfd ...) */,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1 /* (set! fcntl/getfl ...) */,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1 /* (set! fcntl/setfl ...) */,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1 /* (set! open/rdonly ...) */,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1 /* (set! open/wronly ...) */,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1 /* (set! open/rdwr ...) */,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1 /* (set! open/read ...) */,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1 /* (set! open/write ...) */,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1 /* (set! open/creat ...) */,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1 /* (set! open/append ...) */,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1 /* (set! open/excl ...) */,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1 /* (set! open/noctty ...) */,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1 /* (set! open/nonblock ...) */,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1 /* (set! open/trunc ...) */,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1 /* (set! open/sync ...) */,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1 /* (set! open/fsync ...) */,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1 /* (set! open/binary ...) */,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1 /* (set! open/text ...) */,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1 /* (set! perm/irusr ...) */,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1 /* (set! perm/iwusr ...) */,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1 /* (set! perm/ixusr ...) */,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1 /* (set! perm/irgrp ...) */,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1 /* (set! perm/iwgrp ...) */,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1 /* (set! perm/ixgrp ...) */,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1 /* (set! perm/iroth ...) */,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1 /* (set! perm/iwoth ...) */,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1 /* (set! perm/ixoth ...) */,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1 /* (set! perm/irwxu ...) */,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1 /* (set! perm/irwxg ...) */,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1 /* (set! perm/irwxo ...) */,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1 /* (set! perm/isvtx ...) */,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1 /* (set! perm/isuid ...) */,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1 /* (set! perm/isgid ...) */,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1 /* (set! file-control ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3546,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[51]+1 /* (set! file-open ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3592,a[2]=t45,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp));
t47=C_mutate((C_word*)lf[55]+1 /* (set! file-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3630,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[57]+1);
t49=C_mutate((C_word*)lf[58]+1 /* (set! file-read ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3645,a[2]=t48,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[62]+1 /* (set! file-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3687,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[65]+1 /* (set! file-mkstemp ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3726,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3758,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
t53=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3764,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
t54=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3774,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t55=C_mutate((C_word*)lf[68]+1 /* (set! file-select ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3784,a[2]=t53,a[3]=t54,a[4]=t52,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t56=C_mutate((C_word*)lf[71]+1 /* (set! seek/set ...) */,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[72]+1 /* (set! seek/end ...) */,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[73]+1 /* (set! seek/cur ...) */,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[74] /* (set! stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3976,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[77]+1 /* (set! file-stat ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[78]+1 /* (set! file-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4045,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t62=C_mutate((C_word*)lf[79]+1 /* (set! file-modification-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4051,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t63=C_mutate((C_word*)lf[80]+1 /* (set! file-access-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4057,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t64=C_mutate((C_word*)lf[81]+1 /* (set! file-change-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4063,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[82]+1 /* (set! file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4069,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t66=C_mutate((C_word*)lf[83]+1 /* (set! file-permissions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4075,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t67=C_mutate((C_word*)lf[84]+1 /* (set! regular-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4081,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[85]+1 /* (set! symbolic-link? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4090,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[86]+1 /* (set! stat-regular? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4099,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[87]+1 /* (set! stat-directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[88]+1 /* (set! character-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t72=C_mutate((C_word*)lf[89]+1 /* (set! stat-char-device? ...) */,*((C_word*)lf[88]+1));
t73=C_mutate((C_word*)lf[90]+1 /* (set! block-device? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4127,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t74=C_mutate((C_word*)lf[91]+1 /* (set! stat-block-device? ...) */,*((C_word*)lf[90]+1));
t75=C_mutate((C_word*)lf[92]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4137,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[93]+1 /* (set! stat-fifo? ...) */,*((C_word*)lf[92]+1));
t77=C_mutate((C_word*)lf[94]+1 /* (set! stat-symlink? ...) */,*((C_word*)lf[85]+1));
t78=C_mutate((C_word*)lf[95]+1 /* (set! socket? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4148,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[96]+1 /* (set! stat-socket? ...) */,*((C_word*)lf[95]+1));
t80=C_mutate((C_word*)lf[97]+1 /* (set! set-file-position! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4158,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t81=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t82=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9318,a[2]=((C_word)li260),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 845  getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[453]+1)))(4,*((C_word*)lf[453]+1),t81,t82,*((C_word*)lf[97]+1));}

/* a9317 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9318,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9322,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9334,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 847  port? */
t5=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9332 in a9317 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[99]);
t4=((C_word*)t0)[2];
f_9322(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_9322(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 852  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[60],lf[104],lf[464],((C_word*)t0)[3]);}}}

/* k9320 in a9317 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9325,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 854  posix-error */
t3=lf[3];
f_3464(6,t3,t2,lf[48],lf[104],lf[463],((C_word*)t0)[2]);}
else{
t3=t2;
f_9325(2,t3,C_SCHEME_UNDEFINED);}}

/* k9323 in k9320 in a9317 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[171],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1 /* (set! file-position ...) */,t1);
t3=C_mutate((C_word*)lf[105]+1 /* (set! create-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4220,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[114]+1 /* (set! change-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4322,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[116]+1 /* (set! delete-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4346,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[118]+1);
t7=*((C_word*)lf[57]+1);
t8=*((C_word*)lf[119]+1);
t9=C_mutate((C_word*)lf[120]+1 /* (set! directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4370,a[2]=t7,a[3]=t6,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[124]+1 /* (set! directory? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4527,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[57]+1);
t12=C_mutate((C_word*)lf[123]+1 /* (set! current-directory ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4550,a[2]=t11,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp));
t13=*((C_word*)lf[127]+1);
t14=*((C_word*)lf[128]+1);
t15=*((C_word*)lf[129]+1);
t16=*((C_word*)lf[130]+1);
t17=*((C_word*)lf[118]+1);
t18=*((C_word*)lf[2]+1);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4598,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4603,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
t21=*((C_word*)lf[133]+1);
t22=*((C_word*)lf[134]+1);
t23=*((C_word*)lf[123]+1);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4614,a[2]=t23,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t25=C_mutate((C_word*)lf[139]+1 /* (set! canonical-path ...) */,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4670,a[2]=t16,a[3]=t14,a[4]=t21,a[5]=t22,a[6]=t24,a[7]=t15,a[8]=t13,a[9]=t17,a[10]=t19,a[11]=t18,a[12]=t20,a[13]=((C_word)li56),tmp=(C_word)a,a+=14,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4987,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5005,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
t29=C_mutate((C_word*)lf[160]+1 /* (set! open-input-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5020,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li60),tmp=(C_word)a,a+=6,tmp));
t30=C_mutate((C_word*)lf[162]+1 /* (set! open-output-pipe ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5056,a[2]=t27,a[3]=t28,a[4]=t26,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t31=C_mutate((C_word*)lf[163]+1 /* (set! close-input-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5092,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[167]+1 /* (set! close-output-pipe ...) */,*((C_word*)lf[163]+1));
t33=*((C_word*)lf[160]+1);
t34=*((C_word*)lf[162]+1);
t35=*((C_word*)lf[163]+1);
t36=*((C_word*)lf[167]+1);
t37=C_mutate((C_word*)lf[168]+1 /* (set! call-with-input-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5108,a[2]=t33,a[3]=t35,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp));
t38=C_mutate((C_word*)lf[169]+1 /* (set! call-with-output-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5132,a[2]=t34,a[3]=t36,a[4]=((C_word)li68),tmp=(C_word)a,a+=5,tmp));
t39=C_mutate((C_word*)lf[170]+1 /* (set! with-input-from-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t33,a[3]=t35,a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp));
t40=C_mutate((C_word*)lf[172]+1 /* (set! with-output-to-pipe ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5176,a[2]=t34,a[3]=t36,a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp));
t41=C_mutate((C_word*)lf[174]+1 /* (set! create-pipe ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5196,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[176]+1 /* (set! signal/term ...) */,C_fix((C_word)SIGTERM));
t43=C_mutate((C_word*)lf[177]+1 /* (set! signal/kill ...) */,C_fix((C_word)SIGKILL));
t44=C_mutate((C_word*)lf[178]+1 /* (set! signal/int ...) */,C_fix((C_word)SIGINT));
t45=C_mutate((C_word*)lf[179]+1 /* (set! signal/hup ...) */,C_fix((C_word)SIGHUP));
t46=C_mutate((C_word*)lf[180]+1 /* (set! signal/fpe ...) */,C_fix((C_word)SIGFPE));
t47=C_mutate((C_word*)lf[181]+1 /* (set! signal/ill ...) */,C_fix((C_word)SIGILL));
t48=C_mutate((C_word*)lf[182]+1 /* (set! signal/segv ...) */,C_fix((C_word)SIGSEGV));
t49=C_mutate((C_word*)lf[183]+1 /* (set! signal/abrt ...) */,C_fix((C_word)SIGABRT));
t50=C_mutate((C_word*)lf[184]+1 /* (set! signal/trap ...) */,C_fix((C_word)SIGTRAP));
t51=C_mutate((C_word*)lf[185]+1 /* (set! signal/quit ...) */,C_fix((C_word)SIGQUIT));
t52=C_mutate((C_word*)lf[186]+1 /* (set! signal/alrm ...) */,C_fix((C_word)SIGALRM));
t53=C_mutate((C_word*)lf[187]+1 /* (set! signal/vtalrm ...) */,C_fix((C_word)SIGVTALRM));
t54=C_mutate((C_word*)lf[188]+1 /* (set! signal/prof ...) */,C_fix((C_word)SIGPROF));
t55=C_mutate((C_word*)lf[189]+1 /* (set! signal/io ...) */,C_fix((C_word)SIGIO));
t56=C_mutate((C_word*)lf[190]+1 /* (set! signal/urg ...) */,C_fix((C_word)SIGURG));
t57=C_mutate((C_word*)lf[191]+1 /* (set! signal/chld ...) */,C_fix((C_word)SIGCHLD));
t58=C_mutate((C_word*)lf[192]+1 /* (set! signal/cont ...) */,C_fix((C_word)SIGCONT));
t59=C_mutate((C_word*)lf[193]+1 /* (set! signal/stop ...) */,C_fix((C_word)SIGSTOP));
t60=C_mutate((C_word*)lf[194]+1 /* (set! signal/tstp ...) */,C_fix((C_word)SIGTSTP));
t61=C_mutate((C_word*)lf[195]+1 /* (set! signal/pipe ...) */,C_fix((C_word)SIGPIPE));
t62=C_mutate((C_word*)lf[196]+1 /* (set! signal/xcpu ...) */,C_fix((C_word)SIGXCPU));
t63=C_mutate((C_word*)lf[197]+1 /* (set! signal/xfsz ...) */,C_fix((C_word)SIGXFSZ));
t64=C_mutate((C_word*)lf[198]+1 /* (set! signal/usr1 ...) */,C_fix((C_word)SIGUSR1));
t65=C_mutate((C_word*)lf[199]+1 /* (set! signal/usr2 ...) */,C_fix((C_word)SIGUSR2));
t66=C_mutate((C_word*)lf[200]+1 /* (set! signal/winch ...) */,C_fix((C_word)SIGWINCH));
t67=(C_word)C_a_i_list(&a,25,*((C_word*)lf[176]+1),*((C_word*)lf[177]+1),*((C_word*)lf[178]+1),*((C_word*)lf[179]+1),*((C_word*)lf[180]+1),*((C_word*)lf[181]+1),*((C_word*)lf[182]+1),*((C_word*)lf[183]+1),*((C_word*)lf[184]+1),*((C_word*)lf[185]+1),*((C_word*)lf[186]+1),*((C_word*)lf[187]+1),*((C_word*)lf[188]+1),*((C_word*)lf[189]+1),*((C_word*)lf[190]+1),*((C_word*)lf[191]+1),*((C_word*)lf[192]+1),*((C_word*)lf[193]+1),*((C_word*)lf[194]+1),*((C_word*)lf[195]+1),*((C_word*)lf[196]+1),*((C_word*)lf[197]+1),*((C_word*)lf[198]+1),*((C_word*)lf[199]+1),*((C_word*)lf[200]+1));
t68=C_mutate((C_word*)lf[201]+1 /* (set! signals-list ...) */,t67);
t69=*((C_word*)lf[202]+1);
t70=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5241,a[2]=((C_word*)t0)[2],a[3]=t69,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1175 make-vector */
t71=*((C_word*)lf[462]+1);
((C_proc4)(void*)(*((C_word*)t71+1)))(4,t71,t70,C_fix(256),C_SCHEME_FALSE);}

/* k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5241,2,t0,t1);}
t2=C_mutate((C_word*)lf[203]+1 /* (set! signal-handler ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5243,a[2]=t1,a[3]=((C_word)li74),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[204]+1 /* (set! set-signal-handler! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5252,a[2]=t1,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[202]+1 /* (set! interrupt-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li76),tmp=(C_word)a,a+=5,tmp));
t5=C_mutate((C_word*)lf[205]+1 /* (set! set-signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5283,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[208]+1 /* (set! signal-mask ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5307,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[209]+1 /* (set! signal-masked? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5339,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[210]+1 /* (set! signal-mask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5345,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[212]+1 /* (set! signal-unmask! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5360,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9312,a[2]=((C_word)li259),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1231 set-signal-handler! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[204]+1)))(4,*((C_word*)lf[204]+1),t10,*((C_word*)lf[178]+1),t11);}

/* a9311 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9312,3,t0,t1,t2);}
/* posixunix.scm: 1233 ##sys#user-interrupt-hook */
((C_proc2)C_retrieve_proc(*((C_word*)lf[461]+1)))(2,*((C_word*)lf[461]+1),t1);}

/* k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5376,2,t0,t1);}
t2=C_mutate((C_word*)lf[214]+1 /* (set! system-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5378,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9294,a[2]=((C_word)li257),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9297,a[2]=((C_word)li258),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1257 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[453]+1)))(4,*((C_word*)lf[453]+1),t3,t4,t5);}

/* a9296 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9297,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9307,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1261 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9305 in a9296 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1262 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[456],lf[460],((C_word*)t0)[2]);}

/* a9293 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9294,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1107(C_SCHEME_UNDEFINED));}

/* k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5418,2,t0,t1);}
t2=C_mutate((C_word*)lf[217]+1 /* (set! current-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9276,a[2]=((C_word)li255),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9279,a[2]=((C_word)li256),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1265 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[453]+1)))(4,*((C_word*)lf[453]+1),t3,t4,t5);}

/* a9278 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9279(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9279,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9289,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1269 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9287 in a9278 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1270 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[458],lf[459],((C_word*)t0)[2]);}

/* a9275 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9276,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1116(C_SCHEME_UNDEFINED));}

/* k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5422,2,t0,t1);}
t2=C_mutate((C_word*)lf[218]+1 /* (set! current-effective-user-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9258,a[2]=((C_word)li253),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9261,a[2]=((C_word)li254),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1274 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[453]+1)))(4,*((C_word*)lf[453]+1),t3,t4,t5);}

/* a9260 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9261,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9271,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1278 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9269 in a9260 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1279 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[456],lf[457],((C_word*)t0)[2]);}

/* a9257 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9258,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1125(C_SCHEME_UNDEFINED));}

/* k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5426,2,t0,t1);}
t2=C_mutate((C_word*)lf[219]+1 /* (set! current-group-id ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9240,a[2]=((C_word)li251),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9243,a[2]=((C_word)li252),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1282 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[453]+1)))(4,*((C_word*)lf[453]+1),t3,t4,t5);}

/* a9242 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9243,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9253,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1286 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9251 in a9242 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1287 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[454],lf[455],((C_word*)t0)[2]);}

/* a9239 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9240,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1134(C_SCHEME_UNDEFINED));}

/* k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=C_mutate((C_word*)lf[220]+1 /* (set! current-effective-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[221]+1 /* (set! user-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5432,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[134]+1 /* (set! current-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5499,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[224]+1 /* (set! current-effective-user-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5513,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[225]+1 /* (set! group-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5538,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[226] /* (set! _ensure-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5624,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[227]+1 /* (set! get-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5631,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[231]+1 /* (set! set-groups! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5694,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[234]+1 /* (set! initialize-groups ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5768,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[236]+1 /* (set! errno/perm ...) */,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[237]+1 /* (set! errno/noent ...) */,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[238]+1 /* (set! errno/srch ...) */,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[239]+1 /* (set! errno/intr ...) */,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[240]+1 /* (set! errno/io ...) */,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[241]+1 /* (set! errno/noexec ...) */,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[242]+1 /* (set! errno/badf ...) */,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[243]+1 /* (set! errno/child ...) */,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[244]+1 /* (set! errno/nomem ...) */,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[245]+1 /* (set! errno/acces ...) */,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[246]+1 /* (set! errno/fault ...) */,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[247]+1 /* (set! errno/busy ...) */,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[248]+1 /* (set! errno/notdir ...) */,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[249]+1 /* (set! errno/isdir ...) */,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[250]+1 /* (set! errno/inval ...) */,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[251]+1 /* (set! errno/mfile ...) */,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[252]+1 /* (set! errno/nospc ...) */,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[253]+1 /* (set! errno/spipe ...) */,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[254]+1 /* (set! errno/pipe ...) */,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[255]+1 /* (set! errno/again ...) */,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[256]+1 /* (set! errno/rofs ...) */,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[257]+1 /* (set! errno/exist ...) */,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[258]+1 /* (set! errno/wouldblock ...) */,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[259] /* errno/2big */,0,C_fix(0));
t35=C_set_block_item(lf[260] /* errno/deadlk */,0,C_fix(0));
t36=C_set_block_item(lf[261] /* errno/dom */,0,C_fix(0));
t37=C_set_block_item(lf[262] /* errno/fbig */,0,C_fix(0));
t38=C_set_block_item(lf[263] /* errno/ilseq */,0,C_fix(0));
t39=C_set_block_item(lf[264] /* errno/mlink */,0,C_fix(0));
t40=C_set_block_item(lf[265] /* errno/nametoolong */,0,C_fix(0));
t41=C_set_block_item(lf[266] /* errno/nfile */,0,C_fix(0));
t42=C_set_block_item(lf[267] /* errno/nodev */,0,C_fix(0));
t43=C_set_block_item(lf[268] /* errno/nolck */,0,C_fix(0));
t44=C_set_block_item(lf[269] /* errno/nosys */,0,C_fix(0));
t45=C_set_block_item(lf[270] /* errno/notempty */,0,C_fix(0));
t46=C_set_block_item(lf[271] /* errno/notty */,0,C_fix(0));
t47=C_set_block_item(lf[272] /* errno/nxio */,0,C_fix(0));
t48=C_set_block_item(lf[273] /* errno/range */,0,C_fix(0));
t49=C_set_block_item(lf[274] /* errno/xdev */,0,C_fix(0));
t50=C_mutate((C_word*)lf[275]+1 /* (set! change-file-mode ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5832,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[277]+1 /* (set! change-file-owner ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5859,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t52=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5889,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
t53=C_mutate((C_word*)lf[279]+1 /* (set! file-read-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5913,a[2]=t52,a[3]=((C_word)li99),tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[280]+1 /* (set! file-write-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5919,a[2]=t52,a[3]=((C_word)li100),tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[281]+1 /* (set! file-execute-access? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5925,a[2]=t52,a[3]=((C_word)li101),tmp=(C_word)a,a+=4,tmp));
t56=C_mutate((C_word*)lf[282]+1 /* (set! create-session ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5931,a[2]=((C_word)li102),tmp=(C_word)a,a+=3,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9201,a[2]=((C_word)li249),tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9219,a[2]=((C_word)li250),tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1502 getter-with-setter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[453]+1)))(4,*((C_word*)lf[453]+1),t57,t58,t59);}

/* a9218 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9219,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[451]);
t5=(C_word)C_i_check_exact_2(t3,lf[451]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9235,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1514 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k9233 in a9218 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1515 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[451],lf[452],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a9200 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9201(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9201,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[284]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9208,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9214,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1507 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_9208(2,t6,C_SCHEME_UNDEFINED);}}

/* k9212 in a9200 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1508 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[284],lf[450],((C_word*)t0)[2]);}

/* k9206 in a9200 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5948,2,t0,t1);}
t2=C_mutate((C_word*)lf[284]+1 /* (set! process-group-id ...) */,t1);
t3=C_mutate((C_word*)lf[285]+1 /* (set! create-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5950,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[288]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5987,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1535 make-string */
t7=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word ab[261],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5987,2,t0,t1);}
t2=C_mutate((C_word*)lf[289]+1 /* (set! read-symbolic-link ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5988,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li104),tmp=(C_word)a,a+=5,tmp));
t3=C_mutate((C_word*)lf[291]+1 /* (set! file-link ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[294]+1 /* (set! fileno/stdin ...) */,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[295]+1 /* (set! fileno/stdout ...) */,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[296]+1 /* (set! fileno/stderr ...) */,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6063,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6100,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp);
t9=C_mutate((C_word*)lf[305]+1 /* (set! open-input-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6115,a[2]=t7,a[3]=t8,a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[306]+1 /* (set! open-output-file* ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6129,a[2]=t7,a[3]=t8,a[4]=((C_word)li109),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[307]+1 /* (set! port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6143,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[313]+1 /* (set! duplicate-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6188,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[315]+1);
t14=*((C_word*)lf[316]+1);
t15=C_mutate((C_word*)lf[317]+1 /* (set! custom-input-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6215,a[2]=t13,a[3]=t14,a[4]=((C_word)li131),tmp=(C_word)a,a+=5,tmp));
t16=*((C_word*)lf[330]+1);
t17=*((C_word*)lf[316]+1);
t18=C_mutate((C_word*)lf[331]+1 /* (set! custom-output-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6697,a[2]=t16,a[3]=t17,a[4]=((C_word)li143),tmp=(C_word)a,a+=5,tmp));
t19=C_mutate((C_word*)lf[334]+1 /* (set! file-truncate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6956,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6995,a[2]=((C_word)li145),tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7069,a[2]=((C_word)li146),tmp=(C_word)a,a+=3,tmp);
t22=C_mutate((C_word*)lf[338]+1 /* (set! file-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7087,a[2]=t20,a[3]=t21,a[4]=((C_word)li147),tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[340]+1 /* (set! file-lock/blocking ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7102,a[2]=t20,a[3]=t21,a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[342]+1 /* (set! file-test-lock ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7117,a[2]=t20,a[3]=t21,a[4]=((C_word)li149),tmp=(C_word)a,a+=5,tmp));
t25=C_mutate((C_word*)lf[344]+1 /* (set! file-unlock ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7139,a[2]=((C_word)li150),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[346]+1 /* (set! create-fifo ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7167,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[92]+1 /* (set! fifo? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7210,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[349]+1 /* (set! setenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7236,a[2]=((C_word)li153),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[350]+1 /* (set! unsetenv ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7253,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[351]+1 /* (set! get-environment-variables ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7273,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[352]+1 /* (set! current-environment ...) */,*((C_word*)lf[351]+1));
t32=C_mutate((C_word*)lf[353]+1 /* (set! prot/read ...) */,C_fix((C_word)PROT_READ));
t33=C_mutate((C_word*)lf[354]+1 /* (set! prot/write ...) */,C_fix((C_word)PROT_WRITE));
t34=C_mutate((C_word*)lf[355]+1 /* (set! prot/exec ...) */,C_fix((C_word)PROT_EXEC));
t35=C_mutate((C_word*)lf[356]+1 /* (set! prot/none ...) */,C_fix((C_word)PROT_NONE));
t36=C_mutate((C_word*)lf[357]+1 /* (set! map/fixed ...) */,C_fix((C_word)MAP_FIXED));
t37=C_mutate((C_word*)lf[358]+1 /* (set! map/shared ...) */,C_fix((C_word)MAP_SHARED));
t38=C_mutate((C_word*)lf[359]+1 /* (set! map/private ...) */,C_fix((C_word)MAP_PRIVATE));
t39=C_mutate((C_word*)lf[360]+1 /* (set! map/anonymous ...) */,C_fix((C_word)MAP_ANON));
t40=C_mutate((C_word*)lf[361]+1 /* (set! map/file ...) */,C_fix((C_word)MAP_FILE));
t41=C_mutate((C_word*)lf[362]+1 /* (set! map-file-to-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7377,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[368]+1 /* (set! unmap-file-from-memory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7439,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[370]+1 /* (set! memory-mapped-file-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7474,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[371]+1 /* (set! memory-mapped-file? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7483,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[372] /* (set! check-time-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7489,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[374]+1 /* (set! seconds->local-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7508,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[376]+1 /* (set! seconds->utc-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7517,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[377]+1 /* (set! seconds->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7536,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[379]+1 /* (set! time->string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7572,a[2]=((C_word)li166),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[382]+1 /* (set! string->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7641,a[2]=((C_word)li167),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[384]+1 /* (set! local-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7687,a[2]=((C_word)li168),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[387]+1 /* (set! utc-time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7702,a[2]=((C_word)li169),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[389]+1 /* (set! local-timezone-abbreviation ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7717,a[2]=((C_word)li170),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[390]+1 /* (set! _exit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7729,a[2]=((C_word)li171),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[391]+1 /* (set! set-alarm! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7745,a[2]=((C_word)li172),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[392]+1 /* (set! set-buffering-mode! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7752,a[2]=((C_word)li173),tmp=(C_word)a,a+=3,tmp));
t57=C_mutate((C_word*)lf[398]+1 /* (set! terminal-port? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7811,a[2]=((C_word)li174),tmp=(C_word)a,a+=3,tmp));
t58=C_mutate(&lf[399] /* (set! terminal-check ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7830,a[2]=((C_word)li175),tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[401]+1 /* (set! terminal-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7862,a[2]=((C_word)li176),tmp=(C_word)a,a+=3,tmp));
t60=C_mutate((C_word*)lf[402]+1 /* (set! terminal-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7885,a[2]=((C_word)li177),tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[407]+1 /* (set! get-host-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7920,a[2]=((C_word)li178),tmp=(C_word)a,a+=3,tmp));
t62=*((C_word*)lf[409]+1);
t63=*((C_word*)lf[410]+1);
t64=*((C_word*)lf[411]+1);
t65=*((C_word*)lf[120]+1);
t66=*((C_word*)lf[412]+1);
t67=*((C_word*)lf[413]+1);
t68=C_mutate((C_word*)lf[414]+1 /* (set! glob ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7932,a[2]=t64,a[3]=t62,a[4]=t65,a[5]=t63,a[6]=t66,a[7]=t67,a[8]=((C_word)li183),tmp=(C_word)a,a+=9,tmp));
t69=C_mutate((C_word*)lf[417]+1 /* (set! process-fork ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8041,a[2]=((C_word)li185),tmp=(C_word)a,a+=3,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8083,a[2]=((C_word)li186),tmp=(C_word)a,a+=3,tmp);
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8102,a[2]=((C_word)li187),tmp=(C_word)a,a+=3,tmp);
t72=*((C_word*)lf[419]+1);
t73=C_mutate((C_word*)lf[420]+1 /* (set! process-execute ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8121,a[2]=t72,a[3]=t71,a[4]=t70,a[5]=((C_word)li193),tmp=(C_word)a,a+=6,tmp));
t74=C_mutate((C_word*)lf[422]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8303,a[2]=((C_word)li194),tmp=(C_word)a,a+=3,tmp));
t75=C_mutate((C_word*)lf[423]+1 /* (set! process-wait ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8320,a[2]=((C_word)li197),tmp=(C_word)a,a+=3,tmp));
t76=C_mutate((C_word*)lf[425]+1 /* (set! current-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8398,a[2]=((C_word)li198),tmp=(C_word)a,a+=3,tmp));
t77=C_mutate((C_word*)lf[426]+1 /* (set! parent-process-id ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8401,a[2]=((C_word)li199),tmp=(C_word)a,a+=3,tmp));
t78=C_mutate((C_word*)lf[427]+1 /* (set! sleep ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8404,a[2]=((C_word)li200),tmp=(C_word)a,a+=3,tmp));
t79=C_mutate((C_word*)lf[428]+1 /* (set! process-signal ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8411,a[2]=((C_word)li201),tmp=(C_word)a,a+=3,tmp));
t80=C_mutate((C_word*)lf[430]+1 /* (set! shell-command ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8438,a[2]=((C_word)li202),tmp=(C_word)a,a+=3,tmp));
t81=C_mutate((C_word*)lf[433]+1 /* (set! shell-command-arguments ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8447,a[2]=((C_word)li203),tmp=(C_word)a,a+=3,tmp));
t82=*((C_word*)lf[417]+1);
t83=*((C_word*)lf[420]+1);
t84=C_mutate((C_word*)lf[435]+1 /* (set! process-run ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8453,a[2]=t82,a[3]=t83,a[4]=((C_word)li204),tmp=(C_word)a,a+=5,tmp));
t85=*((C_word*)lf[174]+1);
t86=*((C_word*)lf[423]+1);
t87=*((C_word*)lf[417]+1);
t88=*((C_word*)lf[420]+1);
t89=*((C_word*)lf[313]+1);
t90=*((C_word*)lf[55]+1);
t91=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8509,a[2]=t86,a[3]=((C_word)li208),tmp=(C_word)a,a+=4,tmp);
t92=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8546,a[2]=t85,a[3]=((C_word)li211),tmp=(C_word)a,a+=4,tmp);
t93=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8566,a[2]=t90,a[3]=((C_word)li212),tmp=(C_word)a,a+=4,tmp);
t94=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8580,a[2]=t90,a[3]=((C_word)li213),tmp=(C_word)a,a+=4,tmp);
t95=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8597,a[2]=((C_word)li214),tmp=(C_word)a,a+=3,tmp);
t96=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8613,a[2]=t92,a[3]=t87,a[4]=t94,a[5]=t88,a[6]=t95,a[7]=((C_word)li216),tmp=(C_word)a,a+=8,tmp);
t97=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8658,a[2]=t93,a[3]=((C_word)li217),tmp=(C_word)a,a+=4,tmp);
t98=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8669,a[2]=t93,a[3]=((C_word)li218),tmp=(C_word)a,a+=4,tmp);
t99=C_mutate((C_word*)lf[437]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8680,a[2]=t98,a[3]=t91,a[4]=t97,a[5]=t96,a[6]=((C_word)li221),tmp=(C_word)a,a+=7,tmp));
t100=C_set_block_item(lf[438] /* process */,0,C_SCHEME_UNDEFINED);
t101=C_set_block_item(lf[439] /* process* */,0,C_SCHEME_UNDEFINED);
t102=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8738,a[2]=((C_word)li226),tmp=(C_word)a,a+=3,tmp);
t103=C_mutate((C_word*)lf[438]+1 /* (set! process ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8799,a[2]=t102,a[3]=((C_word)li230),tmp=(C_word)a,a+=4,tmp));
t104=C_mutate((C_word*)lf[439]+1 /* (set! process* ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8859,a[2]=t102,a[3]=((C_word)li234),tmp=(C_word)a,a+=4,tmp));
t105=*((C_word*)lf[414]+1);
t106=*((C_word*)lf[410]+1);
t107=*((C_word*)lf[412]+1);
t108=*((C_word*)lf[124]+1);
t109=C_mutate((C_word*)lf[440]+1 /* (set! find-files ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8919,a[2]=t108,a[3]=t107,a[4]=t105,a[5]=t106,a[6]=((C_word)li247),tmp=(C_word)a,a+=7,tmp));
t110=C_mutate((C_word*)lf[448]+1 /* (set! set-root-directory! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9178,a[2]=((C_word)li248),tmp=(C_word)a,a+=3,tmp));
t111=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t111+1)))(2,t111,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9178,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[448]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9170,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_foreign_string_argumentp(t4);
/* ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t6=t5;
f_9170(2,t6,C_SCHEME_FALSE);}}

/* k9168 in set-root-directory! in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub3164(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2396 posix-error */
t3=lf[3];
f_3464(6,t3,((C_word*)t0)[3],lf[48],lf[448],lf[449],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_8919r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_8919r(t0,t1,t2,t3,t4);}}

static void C_ccall f_8919r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,a[8]=((C_word)li242),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9086,a[2]=t5,a[3]=((C_word)li243),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9091,a[2]=t6,a[3]=((C_word)li244),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9096,a[2]=t7,a[3]=((C_word)li246),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action30543145 */
t9=t8;
f_9096(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id30553141 */
t11=t7;
f_9091(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit30563136 */
t13=t6;
f_9086(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body30523062 */
t15=t5;
f_8921(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-action3054 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_9096(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9096,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9102,a[2]=((C_word)li245),tmp=(C_word)a,a+=3,tmp);
/* def-id30553141 */
t3=((C_word*)t0)[2];
f_9091(t3,t1,t2);}

/* a9101 in def-action3054 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9102(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9102,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id3055 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_9091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9091,NULL,3,t0,t1,t2);}
/* def-limit30563136 */
t3=((C_word*)t0)[2];
f_9086(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit3056 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_9086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9086,NULL,4,t0,t1,t2,t3);}
/* body30523062 */
t4=((C_word*)t0)[2];
f_8921(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8921(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8921,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[440]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8928,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_8928(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9081,a[2]=t4,a[3]=t7,a[4]=((C_word)li240),tmp=(C_word)a,a+=5,tmp):t4));}
else{
t10=t8;
f_8928(t10,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9073,a[2]=((C_word)li241),tmp=(C_word)a,a+=3,tmp));}}

/* f_9073 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9073(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9073,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_9081 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9081(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9081,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8928(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8928,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_9061(2,t4,t2);}
else{
/* posixunix.scm: 2368 regexp? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[447]+1)))(3,*((C_word*)lf[447]+1),t3,((C_word*)t0)[11]);}}

/* k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9061,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9062,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word)li235),tmp=(C_word)a,a+=5,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9055,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2371 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[446]);}

/* k9053 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2371 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8938,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8940,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,a[10]=((C_word)li239),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_8940(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8940(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8940,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8959,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2377 directory? */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}}

/* k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8959,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9035,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2378 pathname-file */
t3=*((C_word*)lf[445]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9041,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2385 pproc */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k9039 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9041,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9048,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2385 action */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2386 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_8940(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k9046 in k9039 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2385 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8940(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9035,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[441]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[442]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2378 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_8940(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2379 lproc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8974,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8984,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8986,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,a[5]=((C_word)li236),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word)li237),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9015,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,a[5]=((C_word)li238),tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[444]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9025,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9028,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2384 pproc */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[6]);}}

/* k9026 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2384 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_9025(2,t2,((C_word*)t0)[2]);}}

/* k9023 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2384 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8940(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a9014 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9015,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a8990 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9013,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2382 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],lf[443]);}

/* k9011 in a8990 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2382 glob */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8997 in a8990 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9003,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9006,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2383 pproc */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}

/* k9004 in k8997 in a8990 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2383 action */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_9003(2,t2,((C_word*)t0)[2]);}}

/* k9001 in k8997 in a8990 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2382 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8940(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8985 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8986,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k8982 in k8972 in k9033 in k8957 in loop in k8936 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2380 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8940(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_9062 in k9059 in k8926 in body3052 in find-files in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_9062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9062,3,t0,t1,t2);}
/* posixunix.scm: 2369 string-match */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8859(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8859r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8859r(t0,t1,t2,t3);}}

static void C_ccall f_8859r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8861,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li231),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8866,a[2]=t4,a[3]=((C_word)li232),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8871,a[2]=t5,a[3]=((C_word)li233),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args30073023 */
t7=t6;
f_8871(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env30083019 */
t9=t5;
f_8866(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body30053014 */
t11=t4;
f_8861(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args3007 in process* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8871,NULL,2,t0,t1);}
/* def-env30083019 */
t2=((C_word*)t0)[2];
f_8866(t2,t1,C_SCHEME_FALSE);}

/* def-env3008 in process* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8866(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8866,NULL,3,t0,t1,t2);}
/* body30053014 */
t3=((C_word*)t0)[2];
f_8861(t3,t1,t2,C_SCHEME_FALSE);}

/* body3005 in process* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8861(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8861,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2346 %process */
f_8738(t1,lf[439],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8799(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_8799r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8799r(t0,t1,t2,t3);}}

static void C_ccall f_8799r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8801,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li227),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8806,a[2]=t4,a[3]=((C_word)li228),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8811,a[2]=t5,a[3]=((C_word)li229),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args29632979 */
t7=t6;
f_8811(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env29642975 */
t9=t5;
f_8806(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body29612970 */
t11=t4;
f_8801(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-args2963 in process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8811,NULL,2,t0,t1);}
/* def-env29642975 */
t2=((C_word*)t0)[2];
f_8806(t2,t1,C_SCHEME_FALSE);}

/* def-env2964 in process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8806(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8806,NULL,3,t0,t1,t2);}
/* body29612970 */
t3=((C_word*)t0)[2];
f_8801(t3,t1,t2,C_SCHEME_FALSE);}

/* body2961 in process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8801(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8801,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2343 %process */
f_8738(t1,lf[438],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8738(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8738,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8740,a[2]=t2,a[3]=((C_word)li223),tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8759,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2332 chkstrlst */
t12=t9;
f_8740(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8793,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2334 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[433]+1)))(3,*((C_word*)lf[433]+1),t12,((C_word*)t7)[1]);}}

/* k8791 in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8793,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2335 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[430]+1)))(2,*((C_word*)lf[430]+1),t3);}

/* k8795 in k8791 in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_8759(2,t3,t2);}

/* k8757 in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8762,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2336 chkstrlst */
t3=((C_word*)t0)[2];
f_8740(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_8762(2,t3,C_SCHEME_UNDEFINED);}}

/* k8760 in k8757 in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8767,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li224),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8773,a[2]=((C_word*)t0)[3],a[3]=((C_word)li225),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8772 in k8760 in k8757 in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8773(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8773,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2339 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2340 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8766 in k8760 in k8757 in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8767,2,t0,t1);}
/* posixunix.scm: 2337 ##sys#process */
t2=*((C_word*)lf[437]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8740(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8740,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8749,a[2]=((C_word*)t0)[2],a[3]=((C_word)li222),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a8748 in chkstrlst in %process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8749(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8749,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8680,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8686,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word)li219),tmp=(C_word)a,a+=10,tmp);
t10=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,a[10]=((C_word)li220),tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t9,t10);}

/* a8691 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8692(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8692,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8703,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8723,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2313 make-on-close */
t12=((C_word*)t0)[3];
f_8509(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k8721 in a8691 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2312 input-port */
t2=((C_word*)t0)[7];
f_8658(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8701 in a8691 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8707,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2315 make-on-close */
t4=((C_word*)t0)[6];
f_8509(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k8717 in k8701 in a8691 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2314 output-port */
t2=((C_word*)t0)[7];
f_8669(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8705 in k8701 in a8691 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8711,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8715,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2318 make-on-close */
t4=((C_word*)t0)[3];
f_8509(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k8713 in k8705 in k8701 in a8691 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2317 input-port */
t2=((C_word*)t0)[7];
f_8658(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8709 in k8705 in k8701 in a8691 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2311 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8685 in ##sys#process in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8686,2,t0,t1);}
/* posixunix.scm: 2306 spawn */
t2=((C_word*)t0)[8];
f_8613(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8669,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8673,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2302 connect-parent */
t8=((C_word*)t0)[2];
f_8566(t8,t7,t4,t5);}

/* k8671 in output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2303 ##sys#custom-output-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[331]+1)))(8,*((C_word*)lf[331]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8658(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8658,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8662,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2298 connect-parent */
t8=((C_word*)t0)[2];
f_8566(t8,t7,t4,t5);}

/* k8660 in input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2299 ##sys#custom-input-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[317]+1)))(8,*((C_word*)lf[317]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8613(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8613,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_8617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2285 needed-pipe */
t9=((C_word*)t0)[2];
f_8546(t9,t8,t6);}

/* k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2286 needed-pipe */
t3=((C_word*)t0)[2];
f_8546(t3,t2,((C_word*)t0)[5]);}

/* k8618 in k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2287 needed-pipe */
t3=((C_word*)t0)[2];
f_8546(t3,t2,((C_word*)t0)[6]);}

/* k8621 in k8618 in k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8623,2,t0,t1);}
t2=f_8597(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8634,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_8636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],a[14]=((C_word)li215),tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2290 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8635 in k8621 in k8618 in k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8640,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2292 connect-child */
t3=((C_word*)t0)[7];
f_8580(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[294]+1));}

/* k8638 in a8635 in k8621 in k8618 in k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8643,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_8597(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2293 connect-child */
t4=((C_word*)t0)[5];
f_8580(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[295]+1));}

/* k8641 in k8638 in a8635 in k8621 in k8618 in k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8646,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_8597(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2294 connect-child */
t4=((C_word*)t0)[3];
f_8580(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[296]+1));}

/* k8644 in k8641 in k8638 in a8635 in k8621 in k8618 in k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2295 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8632 in k8621 in k8618 in k8615 in spawn in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2288 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_8597(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(t1);
t3=(C_word)C_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8580(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8580,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8593,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2276 file-close */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k8591 in connect-child in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8593,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8505,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2250 duplicate-fileno */
t6=*((C_word*)lf[313]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k8503 in k8591 in connect-child in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2251 file-close */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8566(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8566,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8579,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2270 file-close */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k8577 in connect-parent in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8546,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8555,a[2]=((C_word*)t0)[2],a[3]=((C_word)li209),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8561,a[2]=((C_word)li210),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a8560 in needed-pipe in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8561,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a8554 in needed-pipe in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8555,2,t0,t1);}
/* posixunix.scm: 2265 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* make-on-close in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8509(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8509,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8511,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,a[9]=((C_word)li207),tmp=(C_word)a,a+=10,tmp));}

/* f_8511 in make-on-close in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8511,2,t0,t1);}
t2=(C_word)C_i_vector_set(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li205),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word)li206),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a8531 */
static void C_ccall f_8532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8532,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2260 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[206],((C_word*)t0)[3],lf[436],((C_word*)t0)[2],t4);}}

/* a8525 */
static void C_ccall f_8526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8526,2,t0,t1);}
/* posixunix.scm: 2258 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8453(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8453r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8453r(t0,t1,t2,t3);}}

static void C_ccall f_8453r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8460,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2214 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k8458 in process-run in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8460,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(0),t1);
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2216 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2218 ##sys#shell-command */
((C_proc2)C_retrieve_proc(*((C_word*)lf[430]+1)))(2,*((C_word*)lf[430]+1),t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8477 in k8458 in process-run in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8483,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2218 ##sys#shell-command-arguments */
((C_proc3)C_retrieve_proc(*((C_word*)lf[433]+1)))(3,*((C_word*)lf[433]+1),t2,((C_word*)t0)[2]);}

/* k8481 in k8477 in k8458 in process-run in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2218 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8447(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8447,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[434],t2));}

/* ##sys#shell-command in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8442,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2204 get-environment-variable */
t3=*((C_word*)lf[133]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[432]);}

/* k8440 in ##sys#shell-command in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[431]));}

/* process-signal in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8411(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_8411r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_8411r(t0,t1,t2,t3);}}

static void C_ccall f_8411r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[428]);
t7=(C_word)C_i_check_exact_2(t5,lf[428]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 2201 posix-error */
t10=lf[3];
f_3464(7,t10,t1,lf[206],lf[428],lf[429],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8404(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8404,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2712(C_SCHEME_UNDEFINED,t3));}

/* parent-process-id in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8401,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2707(C_SCHEME_UNDEFINED));}

/* current-process-id in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8398,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub2703(C_SCHEME_UNDEFINED));}

/* process-wait in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8320(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_8320r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8320r(t0,t1,t2);}}

static void C_ccall f_8320r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(9);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t2));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t6));
if(C_truep((C_word)C_i_nullp(t10))){
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[423]);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8350,a[2]=t8,a[3]=t11,a[4]=((C_word)li195),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8356,a[2]=t11,a[3]=((C_word)li196),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t13,t14);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}

/* a8355 in process-wait in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8356,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 2187 posix-error */
t6=lf[3];
f_3464(6,t6,t1,lf[206],lf[423],lf[424],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2188 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a8349 in process-wait in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8350,2,t0,t1);}
/* posixunix.scm: 2185 ##sys#process-wait */
((C_proc4)C_retrieve_proc(*((C_word*)lf[422]+1)))(4,*((C_word*)lf[422]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8303,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 2172 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8121(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_8121r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8121r(t0,t1,t2,t3);}}

static void C_ccall f_8121r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word)li190),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8250,a[2]=t4,a[3]=((C_word)li191),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8255,a[2]=t5,a[3]=((C_word)li192),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist25692637 */
t7=t6;
f_8255(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist25702633 */
t9=t5;
f_8250(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body25672576 */
t11=t4;
f_8123(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-arglist2569 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8255,NULL,2,t0,t1);}
/* def-envlist25702633 */
t2=((C_word*)t0)[2];
f_8250(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist2570 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8250(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8250,NULL,3,t0,t1,t2);}
/* body25672576 */
t3=((C_word*)t0)[2];
f_8123(t3,t1,t2,C_SCHEME_FALSE);}

/* body2567 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8123(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8123,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[420]);
t5=(C_word)C_i_check_list_2(t2,lf[420]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8133,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2140 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[5]);}

/* k8131 in body2567 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_8083(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8141,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li189),tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_8141(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* doloop2582 in k8131 in body2567 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8141(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8141,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_8083(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8154,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[420]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8187,a[2]=((C_word*)t0)[3],a[3]=((C_word)li188),tmp=(C_word)a,a+=4,tmp);
t8=t5;
f_8154(t8,f_8187(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_8154(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[420]);
t6=(C_word)C_block_size(t4);
t7=f_8083(t3,t4,t6);
t8=(C_word)C_i_cdr(t2);
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* doloop2593 in doloop2582 in k8131 in body2567 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_8187(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(f_8102(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[420]);
t5=(C_word)C_block_size(t3);
t6=f_8102(t2,t3,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k8152 in doloop2582 in k8131 in body2567 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_8154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8154,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8179,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2154 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8177 in k8152 in doloop2582 in k8131 in body2567 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2154 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8155 in k8152 in doloop2582 in k8131 in body2567 in process-execute in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub2532(C_SCHEME_UNDEFINED);
t5=(C_word)stub2547(C_SCHEME_UNDEFINED);
/* posixunix.scm: 2161 posix-error */
t6=lf[3];
f_3464(6,t6,((C_word*)t0)[3],lf[206],lf[420],lf[421],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_8102(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2538(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* setarg in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_8083(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_check;
t4=(C_word)C_i_foreign_fixnum_argumentp(t1);
t5=(C_truep(t2)?(C_word)C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_fixnum_argumentp(t3);
return((C_word)stub2523(C_SCHEME_UNDEFINED,t4,t5,t6));}

/* process-fork in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8041(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_8041r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_8041r(t0,t1,t2);}}

static void C_ccall f_8041r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub2491(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 2125 posix-error */
t5=lf[3];
f_3464(5,t5,t1,lf[206],lf[417],lf[418]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8063,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_vector_ref(t2,C_fix(0));
t9=t8;
((C_proc2)C_retrieve_proc(t9))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k8061 in process-fork in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8067,a[2]=((C_word)li184),tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_8067 in k8061 in process-fork in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8067,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2509(C_SCHEME_UNDEFINED,t3));}

/* glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_7932r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7932r(t0,t1,t2);}}

static void C_ccall f_7932r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=((C_word)li182),tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_7938(t6,t1,t2);}

/* conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7938(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7938,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7953,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li179),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word)li181),tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}}

/* a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7959,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8033,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[416]);
/* posixunix.scm: 2110 make-pathname */
t8=((C_word*)t0)[6];
((C_proc5)C_retrieve_proc(t8))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k8031 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2110 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7961 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7966,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 2111 regexp */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k7964 in k7961 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7973,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[415]);
/* posixunix.scm: 2112 directory */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k7971 in k7964 in k7961 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7973,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7975,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li180),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_7975(t5,((C_word*)t0)[2],t1);}

/* loop in k7971 in k7964 in k7961 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7975(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7975,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* posixunix.scm: 2113 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_7938(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7992,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(t2);
/* posixunix.scm: 2114 string-match */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k7990 in loop in k7971 in k7964 in k7961 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7992,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(t1);
/* posixunix.scm: 2115 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* posixunix.scm: 2116 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_7975(t3,((C_word*)t0)[6],t2);}}

/* k8000 in k7990 in loop in k7971 in k7964 in k7961 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8006,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* posixunix.scm: 2115 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7975(t4,t2,t3);}

/* k8004 in k8000 in k7990 in loop in k7971 in k7964 in k7961 in a7958 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_8006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8006,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a7952 in conc-loop in glob in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7953,2,t0,t1);}
/* posixunix.scm: 2109 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7924,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub2405(t3),C_fix(0));}

/* k7922 in get-host-name in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7927,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_7927(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2091 posix-error */
t3=lf[3];
f_3464(5,t3,t2,lf[403],lf[407],lf[408]);}}

/* k7925 in k7922 in get-host-name in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7885,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7889,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2072 ##sys#terminal-check */
f_7830(t3,lf[402],t2);}

/* k7887 in terminal-size in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7889,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7909,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[405]+1)))(6,*((C_word*)lf[405]+1),t4,t2,C_fix(0),C_SCHEME_FALSE,lf[406]);}

/* k7907 in k7887 in terminal-size in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7913,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[405]+1)))(6,*((C_word*)lf[405]+1),t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[406]);}

/* k7911 in k7907 in k7887 in terminal-size in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=(C_word)C_i_foreign_pointer_argumentp(t3);
t6=(C_word)C_i_foreign_pointer_argumentp(t1);
t7=(C_word)stub2376(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(C_word)C_eqp(C_fix(0),t7);
if(C_truep(t8)){
/* posixunix.scm: 2079 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 2080 posix-error */
t9=lf[3];
f_3464(6,t9,((C_word*)t0)[4],lf[403],lf[402],lf[404],((C_word*)t0)[6]);}}

/* terminal-name in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7862,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7866,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2064 ##sys#terminal-check */
f_7830(t3,lf[401],t2);}

/* k7864 in terminal-name in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7866,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=(C_word)stub2361(t4,t5);
/* ##sys#peek-nonnull-c-string */
t7=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* ##sys#terminal-check in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7830(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7830,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7834,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2056 ##sys#check-port */
t5=*((C_word*)lf[166]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k7832 in ##sys#terminal-check in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[99],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2059 ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[400],((C_word*)t0)[4]);}}

/* terminal-port? in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7811,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7815,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2051 ##sys#check-port */
t4=*((C_word*)lf[166]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[398]);}

/* k7813 in terminal-port? in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2052 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k7816 in k7813 in terminal-port? in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_7752r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_7752r(t0,t1,t2,t3,t4);}}

static void C_ccall f_7752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7756,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2036 ##sys#check-port */
t6=*((C_word*)lf[166]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[392]);}

/* k7754 in set-buffering-mode! in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[394]);
if(C_truep(t6)){
t7=t5;
f_7762(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[395]);
if(C_truep(t7)){
t8=t5;
f_7762(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[396]);
if(C_truep(t8)){
t9=t5;
f_7762(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 2042 ##sys#error */
t9=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[392],lf[397],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k7760 in k7754 in set-buffering-mode! in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[392]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[99],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 2048 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[392],lf[393],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7745,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub2312(C_SCHEME_UNDEFINED,t3));}

/* _exit in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7729(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_7729r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_7729r(t0,t1,t2);}}

static void C_ccall f_7729r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_i_vector_ref(t2,C_fix(0)):C_fix(0));
t5=(C_word)C_i_foreign_fixnum_argumentp(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub2303(C_SCHEME_UNDEFINED,t5));}

/* local-timezone-abbreviation in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub2295(t2),C_fix(0));}

/* utc-time->seconds in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7702(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7702,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7706,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2004 check-time-vector */
f_7489(t3,lf[387],t2);}

/* k7704 in utc-time->seconds in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 2006 ##sys#cons-flonum */
t2=*((C_word*)lf[385]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2007 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[387],lf[388],((C_word*)t0)[3]);}}

/* local-time->seconds in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7687,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7691,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1998 check-time-vector */
f_7489(t3,lf[384],t2);}

/* k7689 in local-time->seconds in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 2000 ##sys#cons-flonum */
t2=*((C_word*)lf[385]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2001 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[384],lf[386],((C_word*)t0)[3]);}}

/* string->time in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7641r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7641r(t0,t1,t2,t3);}}

static void C_ccall f_7641r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7645,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7645(2,t5,lf[383]);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7645(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7643 in string->time in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7645,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[382]);
t3=(C_word)C_i_check_string_2(t1,lf[382]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7658,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1995 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[3]);}

/* k7656 in k7643 in string->time in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7662,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1995 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7660 in k7656 in k7643 in string->time in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7662,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,10,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub2256(C_SCHEME_UNDEFINED,t4,t1,t2));}

/* time->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7572(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_7572r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7572r(t0,t1,t2,t3);}}

static void C_ccall f_7572r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7576,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_7576(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_7576(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k7574 in time->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1979 check-time-vector */
f_7489(t2,lf[379],((C_word*)t0)[2]);}

/* k7577 in k7574 in time->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7579,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(C_word)C_i_check_string_2(((C_word*)t0)[4],lf[379]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7588,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7598,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1983 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub2206(t4,t3),C_fix(0));}}

/* k7599 in k7577 in k7574 in time->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1987 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1988 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[379],lf[381],((C_word*)t0)[2]);}}

/* k7596 in k7577 in k7574 in time->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7598,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],(C_word)stub2214(t3,t2,t1),C_fix(0));}

/* k7586 in k7577 in k7574 in time->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* posixunix.scm: 1984 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[379],lf[380],((C_word*)t0)[2]);}}

/* seconds->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7536,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[377]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7543,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t7=(C_word)C_i_foreign_integer_argumentp(t5);
t8=(C_word)stub2190(t6,t7);
/* ##sys#peek-c-string */
t9=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,t8,C_fix(0));}

/* k7541 in seconds->string in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_block_size(t1);
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1972 ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,C_fix(0),t3);}
else{
/* posixunix.scm: 1973 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[377],lf[378],((C_word*)t0)[2]);}}

/* seconds->utc-time in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7517,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[376]);
/* posixunix.scm: 1964 ##sys#decode-seconds */
t4=*((C_word*)lf[375]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7508(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7508,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[374]);
/* posixunix.scm: 1960 ##sys#decode-seconds */
t4=*((C_word*)lf[375]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* check-time-vector in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7489(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7489,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_check_vector_2(t3,t2);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1956 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,lf[373],t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* memory-mapped-file? in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7483,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[363]));}

/* memory-mapped-file-pointer in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7474,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[363],lf[370]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7439r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7439r(t0,t1,t2,t3);}}

static void C_ccall f_7439r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
t4=(C_word)C_i_check_structure_2(t2,lf[363],lf[368]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t6);
t10=(C_word)stub2143(C_SCHEME_UNDEFINED,t8,t9);
t11=(C_word)C_eqp(C_fix(0),t10);
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1942 posix-error */
t12=lf[3];
f_3464(7,t12,t1,lf[48],lf[368],lf[369],t2,t6);}}

/* map-file-to-memory in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(c<7) C_bad_min_argc_2(c,7,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_7377r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_7377r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_7377r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7381,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_7381(2,t10,t2);}
else{
/* posixunix.scm: 1927 ##sys#null-pointer */
t10=*((C_word*)lf[367]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k7379 in map-file-to-memory in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7381,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7387,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_7387(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1930 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[60],lf[362],lf[366],t1);}}

/* k7385 in k7379 in map-file-to-memory in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7387,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)C_i_foreign_integer_argumentp(t3);
t10=(C_word)C_i_foreign_fixnum_argumentp(t4);
t11=(C_word)C_i_foreign_fixnum_argumentp(t5);
t12=(C_word)C_i_foreign_fixnum_argumentp(t6);
t13=(C_word)C_i_foreign_integer_argumentp(((C_word*)t0)[3]);
t14=(C_word)stub2104(t7,t8,t9,t10,t11,t12,t13);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7393,a[2]=((C_word*)t0)[7],a[3]=t14,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1932 ##sys#pointer->address */
t17=*((C_word*)lf[365]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,t14);}

/* k7404 in k7385 in k7379 in map-file-to-memory in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1933 posix-error */
t3=lf[3];
f_3464(11,t3,((C_word*)t0)[8],lf[48],lf[362],lf[364],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_7393(2,t3,C_SCHEME_UNDEFINED);}}

/* k7391 in k7385 in k7379 in map-file-to-memory in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7393,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[363],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* get-environment-variables in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7273,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7279,a[2]=t3,a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7279(t5,t1,C_fix(0));}

/* loop in get-environment-variables in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7279,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7283,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub2055(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k7281 in loop in get-environment-variables in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7283,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7291,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word)li155),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7291(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k7281 in loop in get-environment-variables in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7291,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7317,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1891 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1894 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k7315 in scan in k7281 in loop in get-environment-variables in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7321,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1892 ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k7319 in k7315 in scan in k7281 in loop in get-environment-variables in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7321,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7309,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1893 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7279(t5,t3,t4);}

/* k7307 in k7319 in k7315 in scan in k7281 in loop in get-environment-variables in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7309,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7253,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[350]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7261,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1880 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7259 in unsetenv in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_unsetenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7236,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[349]);
t5=(C_word)C_i_check_string_2(t3,lf[349]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7247,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1875 ##sys#make-c-string */
t7=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7245 in setenv in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7251,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1875 ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7249 in k7245 in setenv in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7210(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7210,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7217,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7234,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1863 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7232 in fifo? in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1863 ##sys#file-info */
t2=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7215 in fifo? in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1866 posix-error */
t2=lf[3];
f_3464(6,t2,((C_word*)t0)[3],lf[48],lf[92],lf[348],((C_word*)t0)[2]);}}

/* create-fifo in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7167r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7167r(t0,t1,t2,t3);}}

static void C_ccall f_7167r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[346]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7174,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_7174(t6,(C_word)C_i_vector_ref(t3,C_fix(0)));}
else{
t6=(C_word)C_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_7174(t7,(C_word)C_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k7172 in create-fifo in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7174(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7174,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[346]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7195,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1857 ##sys#expand-home-path */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k7193 in k7172 in create-fifo in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1857 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7189 in k7172 in create-fifo in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1858 posix-error */
t3=lf[3];
f_3464(7,t3,((C_word*)t0)[3],lf[48],lf[346],lf[347],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7139,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[337],lf[344]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1847 posix-error */
t9=lf[3];
f_3464(6,t9,t1,lf[48],lf[344],lf[345],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7117(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7117r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7117r(t0,t1,t2,t3);}}

static void C_ccall f_7117r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7121,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1838 setup */
f_6995(t4,t2,t3,lf[342]);}

/* k7119 in file-test-lock in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1840 err */
f_7069(((C_word*)t0)[3],lf[343],t1,lf[342]);}}

/* file-lock/blocking in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7102(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7102r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7102r(t0,t1,t2,t3);}}

static void C_ccall f_7102r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7106,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1832 setup */
f_6995(t4,t2,t3,lf[340]);}

/* k7104 in file-lock/blocking in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1834 err */
f_7069(((C_word*)t0)[2],lf[341],t1,lf[340]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7087(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_7087r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_7087r(t0,t1,t2,t3);}}

static void C_ccall f_7087r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7091,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1826 setup */
f_6995(t4,t2,t3,lf[338]);}

/* k7089 in file-lock in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1828 err */
f_7069(((C_word*)t0)[2],lf[339],t1,lf[338]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7069(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7069,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1823 posix-error */
t8=lf[3];
f_3464(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6995(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6995,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t3));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t8));
if(C_truep((C_word)C_i_nullp(t14))){
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7017,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1815 ##sys#check-port */
t16=*((C_word*)lf[166]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}
else{
/* ##sys#error */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}

/* k7015 in setup in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_7017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7017,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_7023(t6,t5);}
else{
t5=t3;
f_7023(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k7021 in k7015 in setup in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_7023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7023,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[337],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6956,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[334]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6973,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6980,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6984,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1798 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_6973(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1800 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[334],lf[336],t2);}}}

/* k6982 in file-truncate in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1798 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6978 in file-truncate in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_6973(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k6971 in file-truncate in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1802 posix-error */
t2=lf[3];
f_3464(7,t2,((C_word*)t0)[4],lf[48],lf[334],lf[335],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_6697r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6697r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6697r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(20);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,a[7]=((C_word)li139),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6883,a[2]=t6,a[3]=((C_word)li140),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6888,a[2]=t7,a[3]=((C_word)li141),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6893,a[2]=t8,a[3]=((C_word)li142),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?18291920 */
t10=t9;
f_6893(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi18301916 */
t12=t8;
f_6888(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close18311911 */
t14=t7;
f_6883(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* body18271837 */
t16=t6;
f_6699(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-nonblocking?1829 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6893,NULL,2,t0,t1);}
/* def-bufi18301916 */
t2=((C_word*)t0)[2];
f_6888(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1830 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6888(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6888,NULL,3,t0,t1,t2);}
/* def-on-close18311911 */
t3=((C_word*)t0)[2];
f_6883(t3,t1,t2,C_fix(0));}

/* def-on-close1831 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6883(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6883,NULL,4,t0,t1,t2,t3);}
/* body18271837 */
t4=((C_word*)t0)[2];
f_6699(t4,t1,t2,t3,*((C_word*)lf[329]+1));}

/* body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6699,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6703,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1740 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_6703(2,t6,C_SCHEME_UNDEFINED);}}

/* k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6705,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word)li132),tmp=(C_word)a,a+=7,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_6751(t11,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6795,a[2]=t3,a[3]=((C_word)li136),tmp=(C_word)a,a+=4,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6809,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1759 ##sys#make-string */
t12=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_6809(2,t12,((C_word*)t0)[6]);}}}

/* k6807 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6809,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_6751(t4,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word)li138),tmp=(C_word)a,a+=7,tmp));}

/* f_6810 in k6807 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6810(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6810,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6827,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],a[8]=((C_word)li137),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6827(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1775 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6705(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_6827(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6827,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6837,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1765 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_6705(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_difference(t4,t2);
/* posixunix.scm: 1770 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k6835 in loop */
static void C_ccall f_6837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1767 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6827(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_6795 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6795,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1758 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6705(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6749 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6751(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6751,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6755,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6760,a[2]=((C_word*)t0)[9],a[3]=((C_word)li133),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6766,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li134),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[9],a[3]=((C_word)li135),tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1778 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t5,t6,t7,t8);}

/* a6786 in k6749 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6787,2,t0,t1);}
/* posixunix.scm: 1788 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* a6765 in k6749 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6766,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6776,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1785 posix-error */
t3=lf[3];
f_3464(7,t3,t2,lf[48],((C_word*)t0)[3],lf[333],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6776(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6774 in a6765 in k6749 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1786 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6759 in k6749 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6760(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6760,3,t0,t1,t2);}
/* posixunix.scm: 1780 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,t2);}

/* k6753 in k6749 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6755,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6758,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1789 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6756 in k6753 in k6749 in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6705(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6705,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6721,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1748 ##sys#thread-yield! */
t8=*((C_word*)lf[319]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1750 posix-error */
t7=lf[3];
f_3464(7,t7,t1,((C_word*)t0)[3],lf[48],lf[332],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6740,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1752 ##sys#substring */
t7=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6738 in poke in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1752 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6705(t3,((C_word*)t0)[2],t1,t2);}

/* k6719 in poke in k6701 in body1827 in ##sys#custom-output-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1749 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_6705(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5r,(void*)f_6215r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6215r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6215r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,a[7]=((C_word)li126),tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6604,a[2]=t6,a[3]=((C_word)li127),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6609,a[2]=t7,a[3]=((C_word)li128),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6614,a[2]=t8,a[3]=((C_word)li129),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6619,a[2]=t9,a[3]=((C_word)li130),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?15901788 */
t11=t10;
f_6619(t11,t1);}
else{
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi15911784 */
t13=t9;
f_6614(t13,t1,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close15921779 */
t15=t8;
f_6609(t15,t1,t11,t13);}
else{
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_cdr(t14);
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?15931773 */
t17=t7;
f_6604(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_i_car(t16);
t18=(C_word)C_i_cdr(t16);
if(C_truep((C_word)C_i_nullp(t18))){
/* body15881599 */
t19=t6;
f_6217(t19,t1,t11,t13,t15,t17);}
else{
/* ##sys#error */
t19=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t1,lf[0],t18);}}}}}}

/* def-nonblocking?1590 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6619,NULL,2,t0,t1);}
/* def-bufi15911784 */
t2=((C_word*)t0)[2];
f_6614(t2,t1,C_SCHEME_FALSE);}

/* def-bufi1591 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6614(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6614,NULL,3,t0,t1,t2);}
/* def-on-close15921779 */
t3=((C_word*)t0)[2];
f_6609(t3,t1,t2,C_fix(1));}

/* def-on-close1592 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6609(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6609,NULL,4,t0,t1,t2,t3);}
/* def-more?15931773 */
t4=((C_word*)t0)[2];
f_6604(t4,t1,t2,t3,*((C_word*)lf[329]+1));}

/* def-more?1593 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6604,NULL,5,t0,t1,t2,t3,t4);}
/* body15881599 */
t5=((C_word*)t0)[2];
f_6217(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6217,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6221,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1614 ##sys#file-nonblocking! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[9]+1)))(3,*((C_word*)lf[9]+1),t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_6221(2,t7,C_SCHEME_UNDEFINED);}}

/* k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6221,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1616 ##sys#make-string */
t5=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_6227(2,t5,((C_word*)t0)[10]);}}

/* k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[73],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6227,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6228,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word)li112),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6251,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6259,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,a[10]=((C_word)li114),tmp=(C_word)a,a+=11,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6341,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6346,a[2]=t8,a[3]=t5,a[4]=t7,a[5]=((C_word)li115),tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6359,a[2]=t6,a[3]=t3,a[4]=t5,a[5]=((C_word)li116),tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6371,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=((C_word)li117),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6392,a[2]=t8,a[3]=t7,a[4]=((C_word)li118),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6401,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6477,a[2]=t1,a[3]=t8,a[4]=t3,a[5]=t5,a[6]=((C_word)li125),tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1664 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)C_retrieve_proc(t18))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6477(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6477,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6483,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li124),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_6483(t7,t1,C_SCHEME_FALSE);}

/* loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6483(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6483,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6485,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li121),tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6563,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word)li122),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6569,a[2]=((C_word*)t0)[2],a[3]=((C_word)li123),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6579,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1729 fetch */
t5=((C_word*)t0)[5];
f_6259(t5,t4);}}

/* k6577 in loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1731 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6483(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a6568 in loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6569,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* posixunix.scm: 1726 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6483(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a6562 in loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6563,2,t0,t1);}
/* posixunix.scm: 1724 ##sys#scan-buffer-line */
((C_proc6)C_retrieve_proc(*((C_word*)lf[328]+1)))(6,*((C_word*)lf[328]+1),t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* bumper in loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6485,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(C_fix(0),t4);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=t5;
f_6492(2,t8,(C_truep(t7)?t7:lf[325]));}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6535,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1706 ##sys#make-string */
t8=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}

/* k6533 in bumper in loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_substring_copy(((C_word*)t0)[8],t1,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(5));
t4=(C_word)C_fixnum_plus(t3,((C_word*)t0)[4]);
t5=(C_word)C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),t4);
if(C_truep(((C_word*)t0)[3])){
/* posixunix.scm: 1712 ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[326]+1)))(4,*((C_word*)lf[326]+1),((C_word*)t0)[2],((C_word*)t0)[3],t1);}
else{
t6=((C_word*)t0)[2];
f_6492(2,t6,t1);}}

/* k6490 in bumper in loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6492,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=(C_word)C_eqp(((C_word*)t0)[6],((C_word*)t0)[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6502,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1716 fetch */
t5=((C_word*)t0)[3];
f_6259(t5,t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t5=(C_word)C_fixnum_plus(t4,C_fix(1));
t6=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t5);
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_fix(0));
/* posixunix.scm: 1721 values */
C_values(4,0,((C_word*)t0)[4],t1,C_SCHEME_FALSE);}}

/* k6500 in k6490 in bumper in loop in a6476 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
/* posixunix.scm: 1717 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a6400 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6401(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6401,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6409,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t7=t6;
f_6409(t7,t3);}
else{
t7=(C_word)C_block_size(t4);
t8=t6;
f_6409(t8,(C_word)C_fixnum_difference(t7,t5));}}

/* k6407 in a6400 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6409,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word)li119),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_6411(t5,((C_word*)t0)[3],t1,C_fix(0),((C_word*)t0)[2]);}

/* loop in k6407 in a6400 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6411(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6411,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_fixnum_difference(t2,t8);
t14=(C_word)C_fixnum_plus(t3,t8);
t15=(C_word)C_fixnum_plus(t4,t8);
/* posixunix.scm: 1692 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6459,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1694 fetch */
t7=((C_word*)t0)[2];
f_6259(t7,t6);}}}

/* k6457 in loop in k6407 in a6400 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(0),((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1697 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6411(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a6391 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1682 fetch */
t3=((C_word*)t0)[2];
f_6259(t3,t2);}

/* k6394 in a6391 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1683 peek */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_6251(((C_word*)t0)[2]));}

/* a6370 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6371,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6381,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1679 posix-error */
t3=lf[3];
f_3464(7,t3,t2,lf[48],((C_word*)t0)[3],lf[324],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_6381(2,t3,C_SCHEME_UNDEFINED);}}}

/* k6379 in a6370 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1680 on-close */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6358 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1674 ready? */
t3=((C_word*)t0)[2];
f_6228(t3,t1);}}

/* a6345 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6350,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1666 fetch */
t3=((C_word*)t0)[2];
f_6259(t3,t2);}

/* k6348 in a6345 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_6251(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k6339 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6341,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6344,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1733 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k6342 in k6339 in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6259,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6271,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word)li113),tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_6271(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6271(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6271,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6287,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1641 ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[320]+1)))(5,*((C_word*)lf[320]+1),t5,*((C_word*)lf[321]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1644 posix-error */
t5=lf[3];
f_3464(7,t5,t1,lf[48],((C_word*)t0)[6],lf[322],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6308,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1648 more? */
t6=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k6306 in loop in fetch in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6308,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1650 ##sys#thread-yield! */
t3=*((C_word*)lf[319]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_6317(2,t8,t7);}
else{
/* posixunix.scm: 1656 posix-error */
t7=lf[3];
f_3464(7,t7,t4,lf[48],((C_word*)t0)[3],lf[323],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_6317(2,t6,C_SCHEME_UNDEFINED);}}}

/* k6315 in k6306 in loop in fetch in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6309 in k6306 in loop in fetch in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1651 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6271(t2,((C_word*)t0)[2]);}

/* k6285 in loop in fetch in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1642 ##sys#thread-yield! */
t3=*((C_word*)lf[319]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6288 in k6285 in loop in fetch in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1643 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6271(t2,((C_word*)t0)[2]);}

/* peek in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_6251(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6228(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6228,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1622 ##sys#file-select-one */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)t0)[3]);}

/* k6230 in ready? in k6225 in k6219 in body1588 in ##sys#custom-input-port in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
/* posixunix.scm: 1626 posix-error */
t4=lf[3];
f_3464(7,t4,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[318],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t1));}}

/* duplicate-fileno in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6188r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6188r(t0,t1,t2,t3);}}

static void C_ccall f_6188r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[313]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6195,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_6195(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_i_vector_ref(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[313]);
t8=t5;
f_6195(t8,(C_word)C_dup2(t2,t6));}}

/* k6193 in duplicate-fileno in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6195(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6195,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6198,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1607 posix-error */
t3=lf[3];
f_3464(6,t3,t2,lf[48],lf[313],lf[314],((C_word*)t0)[2]);}
else{
t3=t2;
f_6198(2,t3,C_SCHEME_UNDEFINED);}}

/* k6196 in k6193 in duplicate-fileno in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6143,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6147,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1589 ##sys#check-port */
t4=*((C_word*)lf[166]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[307]);}

/* k6145 in port->fileno in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6147,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[308],t2);
if(C_truep(t3)){
/* posixunix.scm: 1590 ##sys#tcp-port->fileno */
((C_proc3)C_retrieve_proc(*((C_word*)lf[309]+1)))(3,*((C_word*)lf[309]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1591 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[312]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k6180 in k6145 in port->fileno in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6182,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1596 posix-error */
t2=lf[3];
f_3464(6,t2,((C_word*)t0)[3],lf[60],lf[307],lf[310],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6165,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1594 posix-error */
t4=lf[3];
f_3464(6,t4,t3,lf[48],lf[307],lf[311],((C_word*)t0)[2]);}
else{
t4=t3;
f_6165(2,t4,C_SCHEME_UNDEFINED);}}}

/* k6163 in k6180 in k6145 in port->fileno in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6129(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6129r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6129r(t0,t1,t2,t3);}}

static void C_ccall f_6129r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[306]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6141,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1585 mode */
f_6063(t5,C_SCHEME_FALSE,t3);}

/* k6139 in open-output-file* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6141,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1585 check */
f_6100(((C_word*)t0)[2],lf[306],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6115r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6115r(t0,t1,t2,t3);}}

static void C_ccall f_6115r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[305]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6127,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1581 mode */
f_6063(t5,C_SCHEME_TRUE,t3);}

/* k6125 in open-input-file* in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6127,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1581 check */
f_6100(((C_word*)t0)[2],lf[305],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6100(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6100,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1574 posix-error */
t6=lf[3];
f_3464(6,t6,t1,lf[48],t2,lf[303],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6113,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1575 ##sys#make-port */
t7=*((C_word*)lf[157]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[158]+1),lf[304],lf[99]);}}

/* k6111 in check in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_6063(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6063,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6071,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(t5,lf[297]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1568 ##sys#error */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[298],t5);}
else{
t8=t4;
f_6071(2,t8,lf[299]);}}
else{
/* posixunix.scm: 1569 ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[300],t5);}}
else{
t5=t4;
f_6071(2,t5,(C_truep(t2)?lf[301]:lf[302]));}}

/* k6069 in mode in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1564 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6038,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[291]);
t5=(C_word)C_i_check_string_2(t3,lf[291]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6019,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_6019(2,t9,C_SCHEME_FALSE);}}

/* k6017 in file-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6023,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t3=t2;
f_6023(2,t3,C_SCHEME_FALSE);}}

/* k6021 in k6017 in file-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1468(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1549 posix-error */
t3=lf[3];
f_3464(7,t3,((C_word*)t0)[4],lf[48],lf[292],lf[293],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5988,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[289]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5996,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6012,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1538 ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k6010 in read-symbolic-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1538 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5994 in read-symbolic-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5996,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5999,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1540 posix-error */
t4=lf[3];
f_3464(6,t4,t3,lf[48],lf[289],lf[290],((C_word*)t0)[2]);}
else{
t4=t3;
f_5999(2,t4,C_SCHEME_UNDEFINED);}}

/* k5997 in k5994 in read-symbolic-link in k5985 in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1541 substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5950,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[285]);
t5=(C_word)C_i_check_string_2(t3,lf[285]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5971,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5983,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1526 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5981 in create-symbolic-link in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1526 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5969 in create-symbolic-link in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5979,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1527 ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5977 in k5969 in create-symbolic-link in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1527 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5973 in k5969 in create-symbolic-link in k5946 in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1529 posix-error */
t3=lf[3];
f_3464(7,t3,((C_word*)t0)[4],lf[48],lf[286],lf[287],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* create-session in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5935,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5941,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1497 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5935(2,t4,C_SCHEME_UNDEFINED);}}

/* k5939 in create-session in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1498 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[282],lf[283]);}

/* k5933 in create-session in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5925,3,t0,t1,t2);}
/* posixunix.scm: 1492 check */
f_5889(t1,t2,C_fix((C_word)X_OK),lf[281]);}

/* file-write-access? in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5919,3,t0,t1,t2);}
/* posixunix.scm: 1491 check */
f_5889(t1,t2,C_fix((C_word)W_OK),lf[280]);}

/* file-read-access? in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5913,3,t0,t1,t2);}
/* posixunix.scm: 1490 check */
f_5889(t1,t2,C_fix((C_word)R_OK),lf[279]);}

/* check in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5889(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5889,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5907,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5911,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1487 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5909 in check in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1487 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5905 in check in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5907,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5899,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_5899(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1488 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5897 in k5905 in check in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5859(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5859,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[277]);
t6=(C_word)C_i_check_exact_2(t3,lf[277]);
t7=(C_word)C_i_check_exact_2(t4,lf[277]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5883,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5887,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1477 ##sys#expand-home-path */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k5885 in change-file-owner in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1477 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5881 in change-file-owner in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1478 posix-error */
t3=lf[3];
f_3464(8,t3,((C_word*)t0)[3],lf[48],lf[277],lf[278],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5832,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[275]);
t5=(C_word)C_i_check_exact_2(t3,lf[275]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5853,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5857,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1469 ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k5855 in change-file-mode in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1469 ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5851 in change-file-mode in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1470 posix-error */
t3=lf[3];
f_3464(7,t3,((C_word*)t0)[3],lf[48],lf[275],lf[276],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5768(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5768,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[234]);
t5=(C_word)C_i_check_exact_2(t3,lf[234]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5756,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t9=(C_word)C_i_foreign_string_argumentp(t6);
/* ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t9=t8;
f_5756(2,t9,C_SCHEME_FALSE);}}

/* k5754 in initialize-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5756,2,t0,t1);}
t2=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=(C_word)stub1293(C_SCHEME_UNDEFINED,t1,t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1390 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k5782 in k5754 in initialize-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1391 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[234],lf[235],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5694(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5694,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5698,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_5624(t4);
if(C_truep(t5)){
t6=t3;
f_5698(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1373 ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[231],lf[233]);}}

/* k5696 in set-groups! in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5698,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5703,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li93),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5703(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop1269 in k5696 in set-groups! in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5703(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5703,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5719,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1378 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[231]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k5717 in doloop1269 in k5696 in set-groups! in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1379 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[231],lf[232],((C_word*)t0)[2]);}

/* get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5635,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5689,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1359 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_5635(2,t4,C_SCHEME_UNDEFINED);}}

/* k5687 in get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1360 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[227],lf[230]);}

/* k5633 in get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_5624(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_5638(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1362 ##sys#error */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[227],lf[229]);}}

/* k5636 in k5633 in get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t4=(C_word)stub1228(C_SCHEME_UNDEFINED,t3);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5670,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1364 ##sys#update-errno */
t6=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t2;
f_5641(2,t5,C_SCHEME_UNDEFINED);}}

/* k5668 in k5636 in k5633 in get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1365 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[227],lf[228]);}

/* k5639 in k5636 in k5633 in get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5641,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5646,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li91),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5646(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k5639 in k5636 in k5633 in get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5646(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5646,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5660,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1369 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k5658 in loop in k5639 in k5636 in k5633 in get-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5660,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_5624(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub1234(C_SCHEME_UNDEFINED,t2));}

/* group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5538r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5538r(t0,t1,t2,t3);}}

static void C_ccall f_5538r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5542,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5542(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5542(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5545,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5545(t3,(C_word)C_getgrgid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[225]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1333 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5594 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5545(t2,(C_word)C_getgrnam(t1));}

/* k5543 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5553 in k5543 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5559,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k5557 in k5553 in k5543 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5563,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5568,a[2]=t4,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5568(t6,t2,C_fix(0));}

/* loop in k5557 in k5553 in k5543 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5568,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5572,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)stub1186(t5,t6);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t3,t7,C_fix(0));}

/* k5570 in loop in k5557 in k5553 in k5543 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5582,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1342 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5568(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k5580 in k5570 in loop in k5557 in k5553 in k5543 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5582,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5561 in k5557 in k5553 in k5543 in k5540 in group-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[222]+1):*((C_word*)lf[223]+1));
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5521,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5525,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1318 current-effective-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[218]+1)))(2,*((C_word*)lf[218]+1),t3);}

/* k5523 in current-effective-user-name in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1318 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[221]+1)))(3,*((C_word*)lf[221]+1),((C_word*)t0)[2],t1);}

/* k5519 in current-effective-user-name in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5507,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5511,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1315 current-user-id */
((C_proc2)C_retrieve_proc(*((C_word*)lf[217]+1)))(2,*((C_word*)lf[217]+1),t3);}

/* k5509 in current-user-name in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1315 user-information */
((C_proc3)C_retrieve_proc(*((C_word*)lf[221]+1)))(3,*((C_word*)lf[221]+1),((C_word*)t0)[2],t1);}

/* k5505 in current-user-name in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_list_ref(t1,C_fix(0)));}

/* user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5432r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5432r(t0,t1,t2,t3);}}

static void C_ccall f_5432r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5436,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_5436(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_5436(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5439,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[2]))){
t3=t2;
f_5439(t3,(C_word)C_getpwuid(((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_check_string_2(((C_word*)t0)[2],lf[221]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5478,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1303 ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5476 in k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5439(t2,(C_word)C_getpwnam(t1));}

/* k5437 in k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5439,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5447 in k5437 in k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5453,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k5451 in k5447 in k5437 in k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5457,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k5455 in k5451 in k5447 in k5437 in k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5461,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k5459 in k5455 in k5451 in k5447 in k5437 in k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5465,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k5463 in k5459 in k5455 in k5451 in k5447 in k5437 in k5434 in user-information in k5428 in k5424 in k5420 in k5416 in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[222]+1):*((C_word*)lf[223]+1));
t3=t2;
((C_proc9)C_retrieve_proc(t3))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5378,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5382,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5411,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1248 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_5382(2,t3,C_SCHEME_UNDEFINED);}}

/* k5409 in system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1249 ##sys#error */
t2=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[214],lf[216]);}

/* k5380 in system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k5387 in k5380 in system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5393,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k5391 in k5387 in k5380 in system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5397,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k5395 in k5391 in k5387 in k5380 in system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5401,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k5399 in k5395 in k5391 in k5387 in k5380 in system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5405,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[215]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k5403 in k5399 in k5395 in k5391 in k5387 in k5380 in system-information in k5374 in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5405,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5360,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[212]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1227 posix-error */
t5=lf[3];
f_3464(5,t5,t1,lf[206],lf[212],lf[213]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5345,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[210]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1221 posix-error */
t5=lf[3];
f_3464(5,t5,t1,lf[206],lf[210],lf[211]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5339,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[209]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5307,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5313,a[2]=t3,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5313(t5,t1,*((C_word*)lf[201]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5313(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5313,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1211 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5283,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[205]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5290,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5301,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a5300 in set-signal-mask! in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5301,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[205]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k5288 in set-signal-mask! in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1204 posix-error */
t2=lf[3];
f_3464(5,t2,((C_word*)t0)[2],lf[206],lf[205],lf[207]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5265,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5275,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1190 h */
t6=t4;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
/* posixunix.scm: 1192 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k5273 in ##sys#interrupt-hook in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1191 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5252,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[204]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_vector_set(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k5239 in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5243,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[203]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5200,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 1107 posix-error */
t3=lf[3];
f_3464(5,t3,t2,lf[48],lf[174],lf[175]);}
else{
t3=t2;
f_5200(2,t3,C_SCHEME_UNDEFINED);}}

/* k5198 in create-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1108 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5176r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5176r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5176r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[173]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5180,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5178 in with-output-to-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=C_mutate((C_word*)lf[173]+1 /* (set! standard-output ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5186,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li71),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1095 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5185 in k5178 in with-output-to-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5186r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5186r(t0,t1,t2);}}

static void C_ccall f_5186r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5190,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1097 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5188 in a5185 in k5178 in with-output-to-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[173]+1 /* (set! standard-output ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_5156r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5156r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5156r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[171]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5160,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k5158 in with-input-from-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
t2=C_mutate((C_word*)lf[171]+1 /* (set! standard-input ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5166,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1085 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a5165 in k5158 in with-input-from-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_5166r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5166r(t0,t1,t2);}}

static void C_ccall f_5166r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5170,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1087 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5168 in a5165 in k5158 in with-input-from-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[171]+1 /* (set! standard-input ...) */,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5132r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5132r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5132r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5136,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5134 in call-with-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5141,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li66),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5147,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1075 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5146 in k5134 in call-with-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5147r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5147r(t0,t1,t2);}}

static void C_ccall f_5147r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5151,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1078 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5149 in a5146 in k5134 in call-with-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5140 in k5134 in call-with-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5141,2,t0,t1);}
/* posixunix.scm: 1076 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5108(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_5108r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5108r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5108r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5112,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k5110 in call-with-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5117,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5123,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1067 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5122 in k5110 in call-with-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5123(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5123r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5123r(t0,t1,t2);}}

static void C_ccall f_5123r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5127,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1070 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k5125 in a5122 in k5110 in call-with-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5116 in k5110 in call-with-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5117,2,t0,t1);}
/* posixunix.scm: 1068 proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5092,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5096,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1054 ##sys#check-port */
t4=*((C_word*)lf[166]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[163]);}

/* k5094 in close-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5096,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5099,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 1056 posix-error */
t5=lf[3];
f_3464(6,t5,t3,lf[48],lf[164],lf[165],((C_word*)t0)[3]);}
else{
t5=t3;
f_5099(2,t5,C_SCHEME_UNDEFINED);}}

/* k5097 in k5094 in close-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5056(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5056r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5056r(t0,t1,t2,t3);}}

static void C_ccall f_5056r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[162]);
t5=f_4987(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5070,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[154]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5077,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1049 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[161]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5087,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1050 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1051 badmode */
f_4999(t6,t5);}}}

/* k5085 in open-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5070(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k5075 in open-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5077,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5070(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k5068 in open-output-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1045 check */
f_5005(((C_word*)t0)[3],lf[162],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_5020r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5020r(t0,t1,t2,t3);}}

static void C_ccall f_5020r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_string_2(t2,lf[160]);
t5=f_4987(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5034,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[154]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5041,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1038 ##sys#make-c-string */
t9=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[161]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5051,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1039 ##sys#make-c-string */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 1040 badmode */
f_4999(t6,t5);}}}

/* k5049 in open-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5034(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k5039 in open-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5041,2,t0,t1);}
t2=((C_word*)t0)[2];
f_5034(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k5032 in open-input-pipe in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1034 check */
f_5005(((C_word*)t0)[3],lf[160],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_5005(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5005,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1026 posix-error */
t6=lf[3];
f_3464(6,t6,t1,lf[48],t2,lf[156],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5018,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1027 ##sys#make-port */
t7=*((C_word*)lf[157]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[158]+1),lf[159],lf[99]);}}

/* k5016 in check in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4999(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4999,NULL,2,t1,t2);}
/* posixunix.scm: 1023 ##sys#error */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[155],t2);}

/* mode in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_4987(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[154]));}

/* canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4670,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[139]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4677,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_block_size(t2);
t6=(C_word)C_eqp(C_fix(0),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 971  cwd */
t8=((C_word*)t0)[6];
f_4614(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=t4,tmp=(C_word)a,a+=12,tmp);
t8=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4977,a[2]=((C_word*)t0)[12],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 973  sref */
t10=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t2,C_fix(0));}
else{
t9=t7;
f_4797(t9,C_SCHEME_FALSE);}}}

/* k4975 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 973  sep? */
t2=((C_word*)t0)[3];
f_4797(t2,f_4603(t1));}

/* k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4797,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
f_4677(2,t2,((C_word*)t0)[10]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[10]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 976  cwd */
t5=((C_word*)t0)[8];
f_4614(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4963,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 977  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[10],C_fix(0));}}}

/* k4961 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 977  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(126),t1);}

/* k4950 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 978  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4816(t2,C_SCHEME_FALSE);}}

/* k4957 in k4950 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 978  sep? */
t2=((C_word*)t0)[3];
f_4816(t2,f_4603(t1));}

/* k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4816(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4816,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 980  get-environment-variable */
t3=((C_word*)t0)[7];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[151]);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[9]);
t3=(C_word)C_eqp(C_fix(2),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 985  cwd */
t5=((C_word*)t0)[6];
f_4614(t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4945,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 986  sref */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[9],C_fix(0));}}}

/* k4943 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 986  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4922 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4941,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[6];
f_4860(t2,C_SCHEME_FALSE);}}

/* k4939 in k4922 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 987  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4928 in k4922 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4930,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 988  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[5];
f_4860(t2,C_SCHEME_FALSE);}}

/* k4935 in k4928 in k4922 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  sep? */
t2=((C_word*)t0)[3];
f_4860(t2,f_4603(t1));}

/* k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4860,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[9]);
/* posixunix.scm: 989  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4873,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 990  sref */
t5=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[9],C_fix(0));}}

/* k4919 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 990  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(47),t1);}

/* k4898 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4917,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 991  sref */
t4=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],C_fix(1));}
else{
t2=((C_word*)t0)[5];
f_4873(2,t2,C_SCHEME_FALSE);}}

/* k4915 in k4898 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 991  alpha? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4904 in k4898 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4906,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4913,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 992  sref */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(2));}
else{
t2=((C_word*)t0)[4];
f_4873(2,t2,C_SCHEME_FALSE);}}

/* k4911 in k4904 in k4898 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 992  char=? */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(58),t1);}

/* k4871 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4873,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
/* posixunix.scm: 993  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[6],((C_word*)t0)[7],C_fix(3),t2);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 994  sref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],C_fix(0));}}

/* k4895 in k4871 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4897,2,t0,t1);}
t2=f_4603(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
f_4677(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4893,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 997  cwd */
t4=((C_word*)t0)[2];
f_4614(t4,t3);}}

/* k4891 in k4895 in k4871 in k4858 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 997  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[153],((C_word*)t0)[2]);}

/* k4852 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 985  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[152],((C_word*)t0)[2]);}

/* k4821 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4826(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 981  user */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k4839 in k4821 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 981  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[150],t1);}

/* k4824 in k4821 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4830,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 982  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(1),t3);}

/* k4828 in k4824 in k4821 in k4814 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 979  sappend */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4808 in k4795 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 976  sappend */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[149],((C_word*)t0)[2]);}

/* k4789 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 971  sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[148]);}

/* k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4677,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=t1;
/* string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t2,t3,lf[147]);}

/* k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li55),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_4686(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4686(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4686,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 1000 null? */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4693,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1001 null? */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[8]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4754,a[2]=t2,a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[4]);
/* posixunix.scm: 1012 string=? */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,lf[146],t5);}}

/* k4755 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4754(t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* posixunix.scm: 1014 string=? */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[145],t3);}}

/* k4764 in k4755 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4754(t2,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=((C_word*)t0)[4];
f_4754(t3,(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[3]));}}

/* k4752 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1010 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4686(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4697 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[140]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[3]);
t4=(C_word)C_a_i_minus(&a,2,t3,C_fix(1));
/* posixunix.scm: 1003 sref */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[3],t4);}}

/* k4733 in k4697 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=f_4603(t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4716,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_a_i_cons(&a,2,lf[142],((C_word*)t0)[2]);
/* posixunix.scm: 1006 reverse */
t6=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4727,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4731,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1009 reverse */
t5=*((C_word*)lf[143]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4729 in k4733 in k4697 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1009 isperse */
f_4598(((C_word*)t0)[2],t1);}

/* k4725 in k4733 in k4697 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1007 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[144],t1);}

/* k4714 in k4733 in k4697 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1006 isperse */
f_4598(((C_word*)t0)[2],t1);}

/* k4710 in k4733 in k4697 in k4691 in loop in k4682 in k4675 in canonical-path in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1004 sappend */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[141],t1);}

/* cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4614,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4621,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4623,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
t4=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* a4622 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4623,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4629,a[2]=t2,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4647,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[137]+1)))(4,*((C_word*)lf[137]+1),t1,t3,t4);}

/* a4646 in a4622 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[3],a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[2],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4658 in a4646 in a4622 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4659r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4659r(t0,t1,t2);}}

static void C_ccall f_4659r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4665,a[2]=t2,a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp);
/* k789795 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4664 in a4658 in a4646 in a4622 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4652 in a4646 in a4622 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
/* posixunix.scm: 966  cw */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a4628 in a4622 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4629,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4635,a[2]=t2,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
/* k789795 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4634 in a4628 in a4622 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[135]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[136]);}

/* k4619 in cwd in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* sep? in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_4603(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_eqp(C_make_character(47),t1);
return((C_truep(t2)?t2:(C_word)C_eqp(C_make_character(92),t1)));}

/* isperse in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4598(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4598,NULL,2,t1,t2);}
/* string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[131]+1)))(4,*((C_word*)lf[131]+1),t1,t2,lf[132]);}

/* current-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4550(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4550r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4550r(t0,t1,t2);}}

static void C_ccall f_4550r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4554,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_4554(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_4554(2,t5,(C_word)C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4552 in current-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 945  change-directory */
t2=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 946  make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}}

/* k4561 in k4552 in current-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 949  ##sys#substring */
t3=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 950  posix-error */
t3=lf[3];
f_3464(5,t3,((C_word*)t0)[2],lf[48],lf[123],lf[126]);}}

/* directory? in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4527,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[124]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4534,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 938  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4546 in directory? in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 938  ##sys#file-info */
t2=*((C_word*)lf[125]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4532 in directory? in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr2r,(void*)f_4370r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4370r(t0,t1,t2);}}

static void C_ccall f_4370r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(13);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4470,a[2]=t3,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=t4,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec637694 */
t6=t5;
f_4475(t6,t1);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?638690 */
t8=t4;
f_4470(t8,t1,t6);}
else{
t8=(C_word)C_i_car(t7);
t9=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t9))){
/* body635644 */
t10=t3;
f_4372(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-spec637 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4475,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4483,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 911  current-directory */
t3=*((C_word*)lf[123]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4481 in def-spec637 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?638690 */
t2=((C_word*)t0)[3];
f_4470(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?638 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4470(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4470,NULL,3,t0,t1,t2);}
/* body635644 */
t3=((C_word*)t0)[2];
f_4372(t3,t1,t2,C_SCHEME_FALSE);}

/* body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4372(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4372,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[120]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 913  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,C_fix(256));}

/* k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 914  ##sys#make-pointer */
t3=*((C_word*)lf[122]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4385,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 915  ##sys#make-pointer */
t3=*((C_word*)lf[122]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4469,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 916  ##sys#expand-home-path */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k4467 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 916  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4387 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4389,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 918  posix-error */
t3=lf[3];
f_3464(6,t3,((C_word*)t0)[7],lf[48],lf[120],lf[121],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word)li38),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_4403(t6,((C_word*)t0)[7]);}}

/* loop in k4387 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4403(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4403,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 926  ##sys#substring */
t5=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k4411 in loop in k4387 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 927  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,C_fix(0));}

/* k4414 in k4411 in loop in k4387 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 928  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_4419(2,t3,C_SCHEME_FALSE);}}

/* k4417 in k4414 in k4411 in loop in k4387 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4425,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(C_make_character(46),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_4425(t5,t4);}
else{
t5=(C_word)C_eqp(C_make_character(46),t1);
t6=(C_truep(t5)?(C_word)C_eqp(C_fix(2),((C_word*)t0)[3]):C_SCHEME_FALSE);
t7=t2;
f_4425(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_4425(t4,C_SCHEME_FALSE);}}

/* k4423 in k4417 in k4414 in k4411 in loop in k4387 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_4425(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4425,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 933  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4403(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 934  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4403(t3,t2);}}

/* k4433 in k4423 in k4417 in k4414 in k4411 in loop in k4387 in k4383 in k4380 in k4377 in body635 in directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4346,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[116]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4364,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4368,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 904  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4366 in delete-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 904  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4362 in delete-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 905  posix-error */
t3=lf[3];
f_3464(6,t3,((C_word*)t0)[3],lf[48],lf[116],lf[117],((C_word*)t0)[2]);}}

/* change-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4322,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[114]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4340,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4344,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 898  ##sys#expand-home-path */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4342 in change-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 898  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4338 in change-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 899  posix-error */
t3=lf[3];
f_3464(6,t3,((C_word*)t0)[3],lf[48],lf[114],lf[115],((C_word*)t0)[2]);}}

/* create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4220r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4220r(t0,t1,t2,t3);}}

static void C_ccall f_4220r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4224,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4224(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4224(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
t2=(C_word)C_i_check_string_2(((C_word*)t0)[3],lf[105]);
if(C_truep(t1)){
t3=((C_word*)t0)[3];
t4=lf[106];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4235,a[2]=t5,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4287,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 886  string-split */
((C_proc4)C_retrieve_proc(*((C_word*)lf[112]+1)))(4,*((C_word*)lf[112]+1),t7,t3,lf[113]);}
else{
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4301,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 862  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}}

/* k4299 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 863  posix-error */
t3=lf[3];
f_3464(6,t3,((C_word*)t0)[3],lf[48],lf[105],lf[107],((C_word*)t0)[2]);}}

/* k4285 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4234 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4235,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4240,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 884  string-append */
t4=*((C_word*)lf[2]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)((C_word*)t0)[2])[1],lf[111],t2);}

/* k4238 in a4234 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4246,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4263,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 867  file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[110]+1)))(3,*((C_word*)lf[110]+1),t5,t3);}

/* k4261 in k4238 in a4234 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4263,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 868  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4246(2,t2,C_SCHEME_FALSE);}}

/* k4281 in k4261 in k4238 in a4234 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_stat(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 869  posix-error */
t3=lf[3];
f_3464(6,t3,((C_word*)t0)[3],lf[48],lf[105],lf[108],((C_word*)t0)[2]);}
else{
t3=C_mk_bool(C_isdir);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
f_4246(2,t4,t3);}
else{
/* posixunix.scm: 872  posix-error */
t4=lf[3];
f_3464(6,t4,((C_word*)t0)[3],lf[48],lf[105],lf[109],((C_word*)t0)[2]);}}}

/* k4244 in k4238 in a4234 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4246,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 862  ##sys#make-c-string */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k4258 in k4244 in k4238 in a4234 in k4222 in create-directory in k4216 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 863  posix-error */
t3=lf[3];
f_3464(6,t3,((C_word*)t0)[3],lf[48],lf[105],lf[107],((C_word*)t0)[2]);}}

/* set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4158r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4158r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4158r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[97]);
t8=(C_word)C_i_check_exact_2(t6,lf[97]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4171,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 836  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[102],lf[97],lf[103],t3,t2);}
else{
t10=t9;
f_4171(2,t10,C_SCHEME_UNDEFINED);}}

/* k4169 in set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 837  port? */
t4=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k4181 in k4169 in set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[99]);
t4=((C_word*)t0)[4];
f_4177(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_4177(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 841  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[60],lf[97],lf[100],((C_word*)t0)[5]);}}}

/* k4175 in k4169 in set-file-position! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 842  posix-error */
t2=lf[3];
f_3464(7,t2,((C_word*)t0)[4],lf[48],lf[97],lf[98],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* socket? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4148,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[95]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4155,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 826  ##sys#stat */
f_3976(t4,t2,C_SCHEME_FALSE,lf[95]);}

/* k4153 in socket? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_issock));}

/* f_4137 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4137,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[93]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4144,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 818  ##sys#stat */
f_3976(t4,t2,C_SCHEME_FALSE,lf[93]);}

/* k4142 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isfifo));}

/* block-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4127,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[90]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4134,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 811  ##sys#stat */
f_3976(t4,t2,C_SCHEME_FALSE,lf[90]);}

/* k4132 in block-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isblk));}

/* character-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4117,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[88]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 804  ##sys#stat */
f_3976(t4,t2,C_SCHEME_FALSE,lf[88]);}

/* k4122 in character-device? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_ischr));}

/* stat-directory? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4108,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[87]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4115,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 799  ##sys#stat */
f_3976(t4,t2,C_SCHEME_FALSE,lf[87]);}

/* k4113 in stat-directory? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isdir));}

/* stat-regular? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4099(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4099,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[86]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4106,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 794  ##sys#stat */
f_3976(t4,t2,C_SCHEME_FALSE,lf[86]);}

/* k4104 in stat-regular? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* symbolic-link? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4090,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4097,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 789  ##sys#stat */
f_3976(t4,t2,C_SCHEME_TRUE,lf[85]);}

/* k4095 in symbolic-link? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4081,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4088,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 784  ##sys#stat */
f_3976(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k4086 in regular-file? in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4075,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4079,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 780  ##sys#stat */
f_3976(t3,t2,C_SCHEME_FALSE,lf[83]);}

/* k4077 in file-permissions in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4069,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4073,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#stat */
f_3976(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k4071 in file-owner in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4063,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4067,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 778  ##sys#stat */
f_3976(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k4065 in file-change-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4057,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 777  ##sys#stat */
f_3976(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k4059 in file-access-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4061,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4051,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 776  ##sys#stat */
f_3976(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k4053 in file-modification-time in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4045,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4049,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 775  ##sys#stat */
f_3976(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k4047 in file-size in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4013r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4013r(t0,t1,t2,t3);}}

static void C_ccall f_4013r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4017,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4024,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_4024(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_4024(2,t7,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k4022 in file-stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 768  ##sys#stat */
f_3976(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[77]);}

/* k4015 in file-stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4017,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3976(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3976,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3980,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_3980(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4001,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4008,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 759  ##sys#expand-home-path */
t8=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 763  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[60],lf[76],t2);}}}

/* k4006 in ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 759  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3999 in ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3980(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k3978 in ##sys#stat in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 765  posix-error */
t2=lf[3];
f_3464(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[75],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3784r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3784r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3784r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_i_vector_ref(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_3758(C_fix(0));
t10=f_3758(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_3800(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 688  fd_set */
t14=t12;
f_3800(2,t14,f_3764(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[68]);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t15=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a3956 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3957,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 695  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3764(C_fix(0),t2));}

/* k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_3806(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 700  fd_set */
t5=t3;
f_3806(2,t5,f_3764(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[68]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a3930 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3931,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[68]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 707  fd_set */
t5=t1;
((C_proc2)C_retrieve_proc(t5))(2,t5,f_3764(C_fix(1),t2));}

/* k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3809,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[68]);
t4=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_3809(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_3809(t4,(C_word)C_C_select(t3));}}

/* k3807 in k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3809(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3809,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 714  posix-error */
t2=lf[3];
f_3464(7,t2,((C_word*)t0)[5],lf[48],lf[68],lf[69],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 715  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 720  fd_test */
t4=t3;
f_3848(t4,f_3774(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3889,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3891,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t8=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_3848(t4,C_SCHEME_FALSE);}}}}

/* a3890 in k3807 in k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3891,3,t0,t1,t2);}
t3=f_3774(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3887 in k3807 in k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3848(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3846 in k3807 in k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3848(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3848,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3852,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 726  fd_test */
t3=t2;
f_3852(t3,f_3774(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3864,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3866,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* for-each */
t7=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_3852(t3,C_SCHEME_FALSE);}}

/* a3865 in k3846 in k3807 in k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3866,3,t0,t1,t2);}
t3=f_3774(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k3862 in k3846 in k3807 in k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3852(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3850 in k3846 in k3807 in k3804 in k3798 in file-select in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_fcall f_3852(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 717  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_3774(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub252(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_set in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_3764(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=(C_word)C_i_foreign_fixnum_argumentp(t1);
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
return((C_word)stub245(C_SCHEME_UNDEFINED,t3,t4));}

/* fd_zero in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static C_word C_fcall f_3758(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_i_foreign_fixnum_argumentp(t1);
return((C_word)stub239(C_SCHEME_UNDEFINED,t2));}

/* file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3726,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[65]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3733,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 666  ##sys#make-c-string */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3731 in file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3739,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 670  posix-error */
t6=lf[3];
f_3464(6,t6,t4,lf[48],lf[65],lf[67],((C_word*)t0)[2]);}
else{
t6=t4;
f_3739(2,t6,C_SCHEME_UNDEFINED);}}

/* k3737 in k3731 in file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3746,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 671  ##sys#substring */
t4=*((C_word*)lf[66]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k3744 in k3737 in k3731 in file-mkstemp in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 671  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3687(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3687r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3687r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3687r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[62]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3694,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_3694(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 655  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[60],lf[62],lf[64],t3);}}

/* k3692 in file-write in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3694,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[62]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3703,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 660  posix-error */
t8=lf[3];
f_3464(7,t8,t6,lf[48],lf[62],lf[63],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_3703(2,t8,C_SCHEME_UNDEFINED);}}

/* k3701 in k3692 in file-write in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3645r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3645r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3645r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[58]);
t6=(C_word)C_i_check_exact_2(t3,lf[58]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3655,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_3655(2,t8,(C_word)C_i_vector_ref(t4,C_fix(0)));}
else{
/* posixunix.scm: 643  make-string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}

/* k3653 in file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_3658(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 645  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[60],lf[58],lf[61],t1);}}

/* k3656 in k3653 in file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3658,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3661,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 648  posix-error */
t5=lf[3];
f_3464(7,t5,t3,lf[48],lf[58],lf[59],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_3661(2,t5,C_SCHEME_UNDEFINED);}}

/* k3659 in k3656 in k3653 in file-read in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3661,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3630,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[55]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 636  posix-error */
t4=lf[3];
f_3464(6,t4,t1,lf[48],lf[55],lf[56],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3592r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3592r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3592r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[51]);
t8=(C_word)C_i_check_exact_2(t3,lf[51]);
t9=(C_word)C_i_check_exact_2(t6,lf[51]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3609,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3622,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 627  ##sys#expand-home-path */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k3620 in file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 627  ##sys#make-c-string */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3607 in file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3612,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 629  posix-error */
t5=lf[3];
f_3464(8,t5,t3,lf[48],lf[51],lf[52],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_3612(2,t5,C_SCHEME_UNDEFINED);}}

/* k3610 in k3607 in file-open in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_3546r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3546r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3546r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3550,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_3550(2,t6,C_fix(0));}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_3550(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3548 in file-control in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[47]);
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[3],lf[47]);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=(C_word)C_i_foreign_fixnum_argumentp(t4);
t7=(C_word)C_i_foreign_fixnum_argumentp(t5);
t8=(C_word)C_i_foreign_integer_argumentp(t1);
t9=(C_word)stub124(C_SCHEME_UNDEFINED,t6,t7,t8);
t10=(C_word)C_eqp(t9,C_fix(-1));
if(C_truep(t10)){
/* posixunix.scm: 617  posix-error */
t11=lf[3];
f_3464(7,t11,((C_word*)t0)[2],lf[48],lf[47],lf[49],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t9);}}

/* ##sys#file-select-one in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3489,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub46(C_SCHEME_UNDEFINED,t3));}

/* ##sys#file-nonblocking! in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3482(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3482,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub40(C_SCHEME_UNDEFINED,t3));}

/* posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_3464r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3464r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3464r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3468,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 507  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3466 in posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3479,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_word)C_i_foreign_fixnum_argumentp(t1);
t6=(C_word)stub23(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,C_fix(0));}

/* k3477 in k3466 in posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 508  string-append */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k3473 in k3466 in posix-error in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in k3432 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[614] = {
{"toplevel:posixunix_scm",(void*)C_posix_toplevel},
{"f_3434:posixunix_scm",(void*)f_3434},
{"f_3437:posixunix_scm",(void*)f_3437},
{"f_3440:posixunix_scm",(void*)f_3440},
{"f_3443:posixunix_scm",(void*)f_3443},
{"f_3446:posixunix_scm",(void*)f_3446},
{"f_3449:posixunix_scm",(void*)f_3449},
{"f_3452:posixunix_scm",(void*)f_3452},
{"f_9318:posixunix_scm",(void*)f_9318},
{"f_9334:posixunix_scm",(void*)f_9334},
{"f_9322:posixunix_scm",(void*)f_9322},
{"f_9325:posixunix_scm",(void*)f_9325},
{"f_4218:posixunix_scm",(void*)f_4218},
{"f_5241:posixunix_scm",(void*)f_5241},
{"f_9312:posixunix_scm",(void*)f_9312},
{"f_5376:posixunix_scm",(void*)f_5376},
{"f_9297:posixunix_scm",(void*)f_9297},
{"f_9307:posixunix_scm",(void*)f_9307},
{"f_9294:posixunix_scm",(void*)f_9294},
{"f_5418:posixunix_scm",(void*)f_5418},
{"f_9279:posixunix_scm",(void*)f_9279},
{"f_9289:posixunix_scm",(void*)f_9289},
{"f_9276:posixunix_scm",(void*)f_9276},
{"f_5422:posixunix_scm",(void*)f_5422},
{"f_9261:posixunix_scm",(void*)f_9261},
{"f_9271:posixunix_scm",(void*)f_9271},
{"f_9258:posixunix_scm",(void*)f_9258},
{"f_5426:posixunix_scm",(void*)f_5426},
{"f_9243:posixunix_scm",(void*)f_9243},
{"f_9253:posixunix_scm",(void*)f_9253},
{"f_9240:posixunix_scm",(void*)f_9240},
{"f_5430:posixunix_scm",(void*)f_5430},
{"f_9219:posixunix_scm",(void*)f_9219},
{"f_9235:posixunix_scm",(void*)f_9235},
{"f_9201:posixunix_scm",(void*)f_9201},
{"f_9214:posixunix_scm",(void*)f_9214},
{"f_9208:posixunix_scm",(void*)f_9208},
{"f_5948:posixunix_scm",(void*)f_5948},
{"f_5987:posixunix_scm",(void*)f_5987},
{"f_9178:posixunix_scm",(void*)f_9178},
{"f_9170:posixunix_scm",(void*)f_9170},
{"f_8919:posixunix_scm",(void*)f_8919},
{"f_9096:posixunix_scm",(void*)f_9096},
{"f_9102:posixunix_scm",(void*)f_9102},
{"f_9091:posixunix_scm",(void*)f_9091},
{"f_9086:posixunix_scm",(void*)f_9086},
{"f_8921:posixunix_scm",(void*)f_8921},
{"f_9073:posixunix_scm",(void*)f_9073},
{"f_9081:posixunix_scm",(void*)f_9081},
{"f_8928:posixunix_scm",(void*)f_8928},
{"f_9061:posixunix_scm",(void*)f_9061},
{"f_9055:posixunix_scm",(void*)f_9055},
{"f_8938:posixunix_scm",(void*)f_8938},
{"f_8940:posixunix_scm",(void*)f_8940},
{"f_8959:posixunix_scm",(void*)f_8959},
{"f_9041:posixunix_scm",(void*)f_9041},
{"f_9048:posixunix_scm",(void*)f_9048},
{"f_9035:posixunix_scm",(void*)f_9035},
{"f_8974:posixunix_scm",(void*)f_8974},
{"f_9028:posixunix_scm",(void*)f_9028},
{"f_9025:posixunix_scm",(void*)f_9025},
{"f_9015:posixunix_scm",(void*)f_9015},
{"f_8991:posixunix_scm",(void*)f_8991},
{"f_9013:posixunix_scm",(void*)f_9013},
{"f_8999:posixunix_scm",(void*)f_8999},
{"f_9006:posixunix_scm",(void*)f_9006},
{"f_9003:posixunix_scm",(void*)f_9003},
{"f_8986:posixunix_scm",(void*)f_8986},
{"f_8984:posixunix_scm",(void*)f_8984},
{"f_9062:posixunix_scm",(void*)f_9062},
{"f_8859:posixunix_scm",(void*)f_8859},
{"f_8871:posixunix_scm",(void*)f_8871},
{"f_8866:posixunix_scm",(void*)f_8866},
{"f_8861:posixunix_scm",(void*)f_8861},
{"f_8799:posixunix_scm",(void*)f_8799},
{"f_8811:posixunix_scm",(void*)f_8811},
{"f_8806:posixunix_scm",(void*)f_8806},
{"f_8801:posixunix_scm",(void*)f_8801},
{"f_8738:posixunix_scm",(void*)f_8738},
{"f_8793:posixunix_scm",(void*)f_8793},
{"f_8797:posixunix_scm",(void*)f_8797},
{"f_8759:posixunix_scm",(void*)f_8759},
{"f_8762:posixunix_scm",(void*)f_8762},
{"f_8773:posixunix_scm",(void*)f_8773},
{"f_8767:posixunix_scm",(void*)f_8767},
{"f_8740:posixunix_scm",(void*)f_8740},
{"f_8749:posixunix_scm",(void*)f_8749},
{"f_8680:posixunix_scm",(void*)f_8680},
{"f_8692:posixunix_scm",(void*)f_8692},
{"f_8723:posixunix_scm",(void*)f_8723},
{"f_8703:posixunix_scm",(void*)f_8703},
{"f_8719:posixunix_scm",(void*)f_8719},
{"f_8707:posixunix_scm",(void*)f_8707},
{"f_8715:posixunix_scm",(void*)f_8715},
{"f_8711:posixunix_scm",(void*)f_8711},
{"f_8686:posixunix_scm",(void*)f_8686},
{"f_8669:posixunix_scm",(void*)f_8669},
{"f_8673:posixunix_scm",(void*)f_8673},
{"f_8658:posixunix_scm",(void*)f_8658},
{"f_8662:posixunix_scm",(void*)f_8662},
{"f_8613:posixunix_scm",(void*)f_8613},
{"f_8617:posixunix_scm",(void*)f_8617},
{"f_8620:posixunix_scm",(void*)f_8620},
{"f_8623:posixunix_scm",(void*)f_8623},
{"f_8636:posixunix_scm",(void*)f_8636},
{"f_8640:posixunix_scm",(void*)f_8640},
{"f_8643:posixunix_scm",(void*)f_8643},
{"f_8646:posixunix_scm",(void*)f_8646},
{"f_8634:posixunix_scm",(void*)f_8634},
{"f_8597:posixunix_scm",(void*)f_8597},
{"f_8580:posixunix_scm",(void*)f_8580},
{"f_8593:posixunix_scm",(void*)f_8593},
{"f_8505:posixunix_scm",(void*)f_8505},
{"f_8566:posixunix_scm",(void*)f_8566},
{"f_8579:posixunix_scm",(void*)f_8579},
{"f_8546:posixunix_scm",(void*)f_8546},
{"f_8561:posixunix_scm",(void*)f_8561},
{"f_8555:posixunix_scm",(void*)f_8555},
{"f_8509:posixunix_scm",(void*)f_8509},
{"f_8511:posixunix_scm",(void*)f_8511},
{"f_8532:posixunix_scm",(void*)f_8532},
{"f_8526:posixunix_scm",(void*)f_8526},
{"f_8453:posixunix_scm",(void*)f_8453},
{"f_8460:posixunix_scm",(void*)f_8460},
{"f_8479:posixunix_scm",(void*)f_8479},
{"f_8483:posixunix_scm",(void*)f_8483},
{"f_8447:posixunix_scm",(void*)f_8447},
{"f_8438:posixunix_scm",(void*)f_8438},
{"f_8442:posixunix_scm",(void*)f_8442},
{"f_8411:posixunix_scm",(void*)f_8411},
{"f_8404:posixunix_scm",(void*)f_8404},
{"f_8401:posixunix_scm",(void*)f_8401},
{"f_8398:posixunix_scm",(void*)f_8398},
{"f_8320:posixunix_scm",(void*)f_8320},
{"f_8356:posixunix_scm",(void*)f_8356},
{"f_8350:posixunix_scm",(void*)f_8350},
{"f_8303:posixunix_scm",(void*)f_8303},
{"f_8121:posixunix_scm",(void*)f_8121},
{"f_8255:posixunix_scm",(void*)f_8255},
{"f_8250:posixunix_scm",(void*)f_8250},
{"f_8123:posixunix_scm",(void*)f_8123},
{"f_8133:posixunix_scm",(void*)f_8133},
{"f_8141:posixunix_scm",(void*)f_8141},
{"f_8187:posixunix_scm",(void*)f_8187},
{"f_8154:posixunix_scm",(void*)f_8154},
{"f_8179:posixunix_scm",(void*)f_8179},
{"f_8157:posixunix_scm",(void*)f_8157},
{"f_8102:posixunix_scm",(void*)f_8102},
{"f_8083:posixunix_scm",(void*)f_8083},
{"f_8041:posixunix_scm",(void*)f_8041},
{"f_8063:posixunix_scm",(void*)f_8063},
{"f_8067:posixunix_scm",(void*)f_8067},
{"f_7932:posixunix_scm",(void*)f_7932},
{"f_7938:posixunix_scm",(void*)f_7938},
{"f_7959:posixunix_scm",(void*)f_7959},
{"f_8033:posixunix_scm",(void*)f_8033},
{"f_7963:posixunix_scm",(void*)f_7963},
{"f_7966:posixunix_scm",(void*)f_7966},
{"f_7973:posixunix_scm",(void*)f_7973},
{"f_7975:posixunix_scm",(void*)f_7975},
{"f_7992:posixunix_scm",(void*)f_7992},
{"f_8002:posixunix_scm",(void*)f_8002},
{"f_8006:posixunix_scm",(void*)f_8006},
{"f_7953:posixunix_scm",(void*)f_7953},
{"f_7920:posixunix_scm",(void*)f_7920},
{"f_7924:posixunix_scm",(void*)f_7924},
{"f_7927:posixunix_scm",(void*)f_7927},
{"f_7885:posixunix_scm",(void*)f_7885},
{"f_7889:posixunix_scm",(void*)f_7889},
{"f_7909:posixunix_scm",(void*)f_7909},
{"f_7913:posixunix_scm",(void*)f_7913},
{"f_7862:posixunix_scm",(void*)f_7862},
{"f_7866:posixunix_scm",(void*)f_7866},
{"f_7830:posixunix_scm",(void*)f_7830},
{"f_7834:posixunix_scm",(void*)f_7834},
{"f_7811:posixunix_scm",(void*)f_7811},
{"f_7815:posixunix_scm",(void*)f_7815},
{"f_7818:posixunix_scm",(void*)f_7818},
{"f_7752:posixunix_scm",(void*)f_7752},
{"f_7756:posixunix_scm",(void*)f_7756},
{"f_7762:posixunix_scm",(void*)f_7762},
{"f_7745:posixunix_scm",(void*)f_7745},
{"f_7729:posixunix_scm",(void*)f_7729},
{"f_7717:posixunix_scm",(void*)f_7717},
{"f_7702:posixunix_scm",(void*)f_7702},
{"f_7706:posixunix_scm",(void*)f_7706},
{"f_7687:posixunix_scm",(void*)f_7687},
{"f_7691:posixunix_scm",(void*)f_7691},
{"f_7641:posixunix_scm",(void*)f_7641},
{"f_7645:posixunix_scm",(void*)f_7645},
{"f_7658:posixunix_scm",(void*)f_7658},
{"f_7662:posixunix_scm",(void*)f_7662},
{"f_7572:posixunix_scm",(void*)f_7572},
{"f_7576:posixunix_scm",(void*)f_7576},
{"f_7579:posixunix_scm",(void*)f_7579},
{"f_7601:posixunix_scm",(void*)f_7601},
{"f_7598:posixunix_scm",(void*)f_7598},
{"f_7588:posixunix_scm",(void*)f_7588},
{"f_7536:posixunix_scm",(void*)f_7536},
{"f_7543:posixunix_scm",(void*)f_7543},
{"f_7517:posixunix_scm",(void*)f_7517},
{"f_7508:posixunix_scm",(void*)f_7508},
{"f_7489:posixunix_scm",(void*)f_7489},
{"f_7483:posixunix_scm",(void*)f_7483},
{"f_7474:posixunix_scm",(void*)f_7474},
{"f_7439:posixunix_scm",(void*)f_7439},
{"f_7377:posixunix_scm",(void*)f_7377},
{"f_7381:posixunix_scm",(void*)f_7381},
{"f_7387:posixunix_scm",(void*)f_7387},
{"f_7406:posixunix_scm",(void*)f_7406},
{"f_7393:posixunix_scm",(void*)f_7393},
{"f_7273:posixunix_scm",(void*)f_7273},
{"f_7279:posixunix_scm",(void*)f_7279},
{"f_7283:posixunix_scm",(void*)f_7283},
{"f_7291:posixunix_scm",(void*)f_7291},
{"f_7317:posixunix_scm",(void*)f_7317},
{"f_7321:posixunix_scm",(void*)f_7321},
{"f_7309:posixunix_scm",(void*)f_7309},
{"f_7253:posixunix_scm",(void*)f_7253},
{"f_7261:posixunix_scm",(void*)f_7261},
{"f_7236:posixunix_scm",(void*)f_7236},
{"f_7247:posixunix_scm",(void*)f_7247},
{"f_7251:posixunix_scm",(void*)f_7251},
{"f_7210:posixunix_scm",(void*)f_7210},
{"f_7234:posixunix_scm",(void*)f_7234},
{"f_7217:posixunix_scm",(void*)f_7217},
{"f_7167:posixunix_scm",(void*)f_7167},
{"f_7174:posixunix_scm",(void*)f_7174},
{"f_7195:posixunix_scm",(void*)f_7195},
{"f_7191:posixunix_scm",(void*)f_7191},
{"f_7139:posixunix_scm",(void*)f_7139},
{"f_7117:posixunix_scm",(void*)f_7117},
{"f_7121:posixunix_scm",(void*)f_7121},
{"f_7102:posixunix_scm",(void*)f_7102},
{"f_7106:posixunix_scm",(void*)f_7106},
{"f_7087:posixunix_scm",(void*)f_7087},
{"f_7091:posixunix_scm",(void*)f_7091},
{"f_7069:posixunix_scm",(void*)f_7069},
{"f_6995:posixunix_scm",(void*)f_6995},
{"f_7017:posixunix_scm",(void*)f_7017},
{"f_7023:posixunix_scm",(void*)f_7023},
{"f_6956:posixunix_scm",(void*)f_6956},
{"f_6984:posixunix_scm",(void*)f_6984},
{"f_6980:posixunix_scm",(void*)f_6980},
{"f_6973:posixunix_scm",(void*)f_6973},
{"f_6697:posixunix_scm",(void*)f_6697},
{"f_6893:posixunix_scm",(void*)f_6893},
{"f_6888:posixunix_scm",(void*)f_6888},
{"f_6883:posixunix_scm",(void*)f_6883},
{"f_6699:posixunix_scm",(void*)f_6699},
{"f_6703:posixunix_scm",(void*)f_6703},
{"f_6809:posixunix_scm",(void*)f_6809},
{"f_6810:posixunix_scm",(void*)f_6810},
{"f_6827:posixunix_scm",(void*)f_6827},
{"f_6837:posixunix_scm",(void*)f_6837},
{"f_6795:posixunix_scm",(void*)f_6795},
{"f_6751:posixunix_scm",(void*)f_6751},
{"f_6787:posixunix_scm",(void*)f_6787},
{"f_6766:posixunix_scm",(void*)f_6766},
{"f_6776:posixunix_scm",(void*)f_6776},
{"f_6760:posixunix_scm",(void*)f_6760},
{"f_6755:posixunix_scm",(void*)f_6755},
{"f_6758:posixunix_scm",(void*)f_6758},
{"f_6705:posixunix_scm",(void*)f_6705},
{"f_6740:posixunix_scm",(void*)f_6740},
{"f_6721:posixunix_scm",(void*)f_6721},
{"f_6215:posixunix_scm",(void*)f_6215},
{"f_6619:posixunix_scm",(void*)f_6619},
{"f_6614:posixunix_scm",(void*)f_6614},
{"f_6609:posixunix_scm",(void*)f_6609},
{"f_6604:posixunix_scm",(void*)f_6604},
{"f_6217:posixunix_scm",(void*)f_6217},
{"f_6221:posixunix_scm",(void*)f_6221},
{"f_6227:posixunix_scm",(void*)f_6227},
{"f_6477:posixunix_scm",(void*)f_6477},
{"f_6483:posixunix_scm",(void*)f_6483},
{"f_6579:posixunix_scm",(void*)f_6579},
{"f_6569:posixunix_scm",(void*)f_6569},
{"f_6563:posixunix_scm",(void*)f_6563},
{"f_6485:posixunix_scm",(void*)f_6485},
{"f_6535:posixunix_scm",(void*)f_6535},
{"f_6492:posixunix_scm",(void*)f_6492},
{"f_6502:posixunix_scm",(void*)f_6502},
{"f_6401:posixunix_scm",(void*)f_6401},
{"f_6409:posixunix_scm",(void*)f_6409},
{"f_6411:posixunix_scm",(void*)f_6411},
{"f_6459:posixunix_scm",(void*)f_6459},
{"f_6392:posixunix_scm",(void*)f_6392},
{"f_6396:posixunix_scm",(void*)f_6396},
{"f_6371:posixunix_scm",(void*)f_6371},
{"f_6381:posixunix_scm",(void*)f_6381},
{"f_6359:posixunix_scm",(void*)f_6359},
{"f_6346:posixunix_scm",(void*)f_6346},
{"f_6350:posixunix_scm",(void*)f_6350},
{"f_6341:posixunix_scm",(void*)f_6341},
{"f_6344:posixunix_scm",(void*)f_6344},
{"f_6259:posixunix_scm",(void*)f_6259},
{"f_6271:posixunix_scm",(void*)f_6271},
{"f_6308:posixunix_scm",(void*)f_6308},
{"f_6317:posixunix_scm",(void*)f_6317},
{"f_6311:posixunix_scm",(void*)f_6311},
{"f_6287:posixunix_scm",(void*)f_6287},
{"f_6290:posixunix_scm",(void*)f_6290},
{"f_6251:posixunix_scm",(void*)f_6251},
{"f_6228:posixunix_scm",(void*)f_6228},
{"f_6232:posixunix_scm",(void*)f_6232},
{"f_6188:posixunix_scm",(void*)f_6188},
{"f_6195:posixunix_scm",(void*)f_6195},
{"f_6198:posixunix_scm",(void*)f_6198},
{"f_6143:posixunix_scm",(void*)f_6143},
{"f_6147:posixunix_scm",(void*)f_6147},
{"f_6182:posixunix_scm",(void*)f_6182},
{"f_6165:posixunix_scm",(void*)f_6165},
{"f_6129:posixunix_scm",(void*)f_6129},
{"f_6141:posixunix_scm",(void*)f_6141},
{"f_6115:posixunix_scm",(void*)f_6115},
{"f_6127:posixunix_scm",(void*)f_6127},
{"f_6100:posixunix_scm",(void*)f_6100},
{"f_6113:posixunix_scm",(void*)f_6113},
{"f_6063:posixunix_scm",(void*)f_6063},
{"f_6071:posixunix_scm",(void*)f_6071},
{"f_6038:posixunix_scm",(void*)f_6038},
{"f_6019:posixunix_scm",(void*)f_6019},
{"f_6023:posixunix_scm",(void*)f_6023},
{"f_5988:posixunix_scm",(void*)f_5988},
{"f_6012:posixunix_scm",(void*)f_6012},
{"f_5996:posixunix_scm",(void*)f_5996},
{"f_5999:posixunix_scm",(void*)f_5999},
{"f_5950:posixunix_scm",(void*)f_5950},
{"f_5983:posixunix_scm",(void*)f_5983},
{"f_5971:posixunix_scm",(void*)f_5971},
{"f_5979:posixunix_scm",(void*)f_5979},
{"f_5975:posixunix_scm",(void*)f_5975},
{"f_5931:posixunix_scm",(void*)f_5931},
{"f_5941:posixunix_scm",(void*)f_5941},
{"f_5935:posixunix_scm",(void*)f_5935},
{"f_5925:posixunix_scm",(void*)f_5925},
{"f_5919:posixunix_scm",(void*)f_5919},
{"f_5913:posixunix_scm",(void*)f_5913},
{"f_5889:posixunix_scm",(void*)f_5889},
{"f_5911:posixunix_scm",(void*)f_5911},
{"f_5907:posixunix_scm",(void*)f_5907},
{"f_5899:posixunix_scm",(void*)f_5899},
{"f_5859:posixunix_scm",(void*)f_5859},
{"f_5887:posixunix_scm",(void*)f_5887},
{"f_5883:posixunix_scm",(void*)f_5883},
{"f_5832:posixunix_scm",(void*)f_5832},
{"f_5857:posixunix_scm",(void*)f_5857},
{"f_5853:posixunix_scm",(void*)f_5853},
{"f_5768:posixunix_scm",(void*)f_5768},
{"f_5756:posixunix_scm",(void*)f_5756},
{"f_5784:posixunix_scm",(void*)f_5784},
{"f_5694:posixunix_scm",(void*)f_5694},
{"f_5698:posixunix_scm",(void*)f_5698},
{"f_5703:posixunix_scm",(void*)f_5703},
{"f_5719:posixunix_scm",(void*)f_5719},
{"f_5631:posixunix_scm",(void*)f_5631},
{"f_5689:posixunix_scm",(void*)f_5689},
{"f_5635:posixunix_scm",(void*)f_5635},
{"f_5638:posixunix_scm",(void*)f_5638},
{"f_5670:posixunix_scm",(void*)f_5670},
{"f_5641:posixunix_scm",(void*)f_5641},
{"f_5646:posixunix_scm",(void*)f_5646},
{"f_5660:posixunix_scm",(void*)f_5660},
{"f_5624:posixunix_scm",(void*)f_5624},
{"f_5538:posixunix_scm",(void*)f_5538},
{"f_5542:posixunix_scm",(void*)f_5542},
{"f_5596:posixunix_scm",(void*)f_5596},
{"f_5545:posixunix_scm",(void*)f_5545},
{"f_5555:posixunix_scm",(void*)f_5555},
{"f_5559:posixunix_scm",(void*)f_5559},
{"f_5568:posixunix_scm",(void*)f_5568},
{"f_5572:posixunix_scm",(void*)f_5572},
{"f_5582:posixunix_scm",(void*)f_5582},
{"f_5563:posixunix_scm",(void*)f_5563},
{"f_5513:posixunix_scm",(void*)f_5513},
{"f_5525:posixunix_scm",(void*)f_5525},
{"f_5521:posixunix_scm",(void*)f_5521},
{"f_5499:posixunix_scm",(void*)f_5499},
{"f_5511:posixunix_scm",(void*)f_5511},
{"f_5507:posixunix_scm",(void*)f_5507},
{"f_5432:posixunix_scm",(void*)f_5432},
{"f_5436:posixunix_scm",(void*)f_5436},
{"f_5478:posixunix_scm",(void*)f_5478},
{"f_5439:posixunix_scm",(void*)f_5439},
{"f_5449:posixunix_scm",(void*)f_5449},
{"f_5453:posixunix_scm",(void*)f_5453},
{"f_5457:posixunix_scm",(void*)f_5457},
{"f_5461:posixunix_scm",(void*)f_5461},
{"f_5465:posixunix_scm",(void*)f_5465},
{"f_5378:posixunix_scm",(void*)f_5378},
{"f_5411:posixunix_scm",(void*)f_5411},
{"f_5382:posixunix_scm",(void*)f_5382},
{"f_5389:posixunix_scm",(void*)f_5389},
{"f_5393:posixunix_scm",(void*)f_5393},
{"f_5397:posixunix_scm",(void*)f_5397},
{"f_5401:posixunix_scm",(void*)f_5401},
{"f_5405:posixunix_scm",(void*)f_5405},
{"f_5360:posixunix_scm",(void*)f_5360},
{"f_5345:posixunix_scm",(void*)f_5345},
{"f_5339:posixunix_scm",(void*)f_5339},
{"f_5307:posixunix_scm",(void*)f_5307},
{"f_5313:posixunix_scm",(void*)f_5313},
{"f_5283:posixunix_scm",(void*)f_5283},
{"f_5301:posixunix_scm",(void*)f_5301},
{"f_5290:posixunix_scm",(void*)f_5290},
{"f_5265:posixunix_scm",(void*)f_5265},
{"f_5275:posixunix_scm",(void*)f_5275},
{"f_5252:posixunix_scm",(void*)f_5252},
{"f_5243:posixunix_scm",(void*)f_5243},
{"f_5196:posixunix_scm",(void*)f_5196},
{"f_5200:posixunix_scm",(void*)f_5200},
{"f_5176:posixunix_scm",(void*)f_5176},
{"f_5180:posixunix_scm",(void*)f_5180},
{"f_5186:posixunix_scm",(void*)f_5186},
{"f_5190:posixunix_scm",(void*)f_5190},
{"f_5156:posixunix_scm",(void*)f_5156},
{"f_5160:posixunix_scm",(void*)f_5160},
{"f_5166:posixunix_scm",(void*)f_5166},
{"f_5170:posixunix_scm",(void*)f_5170},
{"f_5132:posixunix_scm",(void*)f_5132},
{"f_5136:posixunix_scm",(void*)f_5136},
{"f_5147:posixunix_scm",(void*)f_5147},
{"f_5151:posixunix_scm",(void*)f_5151},
{"f_5141:posixunix_scm",(void*)f_5141},
{"f_5108:posixunix_scm",(void*)f_5108},
{"f_5112:posixunix_scm",(void*)f_5112},
{"f_5123:posixunix_scm",(void*)f_5123},
{"f_5127:posixunix_scm",(void*)f_5127},
{"f_5117:posixunix_scm",(void*)f_5117},
{"f_5092:posixunix_scm",(void*)f_5092},
{"f_5096:posixunix_scm",(void*)f_5096},
{"f_5099:posixunix_scm",(void*)f_5099},
{"f_5056:posixunix_scm",(void*)f_5056},
{"f_5087:posixunix_scm",(void*)f_5087},
{"f_5077:posixunix_scm",(void*)f_5077},
{"f_5070:posixunix_scm",(void*)f_5070},
{"f_5020:posixunix_scm",(void*)f_5020},
{"f_5051:posixunix_scm",(void*)f_5051},
{"f_5041:posixunix_scm",(void*)f_5041},
{"f_5034:posixunix_scm",(void*)f_5034},
{"f_5005:posixunix_scm",(void*)f_5005},
{"f_5018:posixunix_scm",(void*)f_5018},
{"f_4999:posixunix_scm",(void*)f_4999},
{"f_4987:posixunix_scm",(void*)f_4987},
{"f_4670:posixunix_scm",(void*)f_4670},
{"f_4977:posixunix_scm",(void*)f_4977},
{"f_4797:posixunix_scm",(void*)f_4797},
{"f_4963:posixunix_scm",(void*)f_4963},
{"f_4952:posixunix_scm",(void*)f_4952},
{"f_4959:posixunix_scm",(void*)f_4959},
{"f_4816:posixunix_scm",(void*)f_4816},
{"f_4945:posixunix_scm",(void*)f_4945},
{"f_4924:posixunix_scm",(void*)f_4924},
{"f_4941:posixunix_scm",(void*)f_4941},
{"f_4930:posixunix_scm",(void*)f_4930},
{"f_4937:posixunix_scm",(void*)f_4937},
{"f_4860:posixunix_scm",(void*)f_4860},
{"f_4921:posixunix_scm",(void*)f_4921},
{"f_4900:posixunix_scm",(void*)f_4900},
{"f_4917:posixunix_scm",(void*)f_4917},
{"f_4906:posixunix_scm",(void*)f_4906},
{"f_4913:posixunix_scm",(void*)f_4913},
{"f_4873:posixunix_scm",(void*)f_4873},
{"f_4897:posixunix_scm",(void*)f_4897},
{"f_4893:posixunix_scm",(void*)f_4893},
{"f_4854:posixunix_scm",(void*)f_4854},
{"f_4823:posixunix_scm",(void*)f_4823},
{"f_4841:posixunix_scm",(void*)f_4841},
{"f_4826:posixunix_scm",(void*)f_4826},
{"f_4830:posixunix_scm",(void*)f_4830},
{"f_4810:posixunix_scm",(void*)f_4810},
{"f_4791:posixunix_scm",(void*)f_4791},
{"f_4677:posixunix_scm",(void*)f_4677},
{"f_4684:posixunix_scm",(void*)f_4684},
{"f_4686:posixunix_scm",(void*)f_4686},
{"f_4693:posixunix_scm",(void*)f_4693},
{"f_4757:posixunix_scm",(void*)f_4757},
{"f_4766:posixunix_scm",(void*)f_4766},
{"f_4754:posixunix_scm",(void*)f_4754},
{"f_4699:posixunix_scm",(void*)f_4699},
{"f_4735:posixunix_scm",(void*)f_4735},
{"f_4731:posixunix_scm",(void*)f_4731},
{"f_4727:posixunix_scm",(void*)f_4727},
{"f_4716:posixunix_scm",(void*)f_4716},
{"f_4712:posixunix_scm",(void*)f_4712},
{"f_4614:posixunix_scm",(void*)f_4614},
{"f_4623:posixunix_scm",(void*)f_4623},
{"f_4647:posixunix_scm",(void*)f_4647},
{"f_4659:posixunix_scm",(void*)f_4659},
{"f_4665:posixunix_scm",(void*)f_4665},
{"f_4653:posixunix_scm",(void*)f_4653},
{"f_4629:posixunix_scm",(void*)f_4629},
{"f_4635:posixunix_scm",(void*)f_4635},
{"f_4621:posixunix_scm",(void*)f_4621},
{"f_4603:posixunix_scm",(void*)f_4603},
{"f_4598:posixunix_scm",(void*)f_4598},
{"f_4550:posixunix_scm",(void*)f_4550},
{"f_4554:posixunix_scm",(void*)f_4554},
{"f_4563:posixunix_scm",(void*)f_4563},
{"f_4527:posixunix_scm",(void*)f_4527},
{"f_4548:posixunix_scm",(void*)f_4548},
{"f_4534:posixunix_scm",(void*)f_4534},
{"f_4370:posixunix_scm",(void*)f_4370},
{"f_4475:posixunix_scm",(void*)f_4475},
{"f_4483:posixunix_scm",(void*)f_4483},
{"f_4470:posixunix_scm",(void*)f_4470},
{"f_4372:posixunix_scm",(void*)f_4372},
{"f_4379:posixunix_scm",(void*)f_4379},
{"f_4382:posixunix_scm",(void*)f_4382},
{"f_4385:posixunix_scm",(void*)f_4385},
{"f_4469:posixunix_scm",(void*)f_4469},
{"f_4389:posixunix_scm",(void*)f_4389},
{"f_4403:posixunix_scm",(void*)f_4403},
{"f_4413:posixunix_scm",(void*)f_4413},
{"f_4416:posixunix_scm",(void*)f_4416},
{"f_4419:posixunix_scm",(void*)f_4419},
{"f_4425:posixunix_scm",(void*)f_4425},
{"f_4435:posixunix_scm",(void*)f_4435},
{"f_4346:posixunix_scm",(void*)f_4346},
{"f_4368:posixunix_scm",(void*)f_4368},
{"f_4364:posixunix_scm",(void*)f_4364},
{"f_4322:posixunix_scm",(void*)f_4322},
{"f_4344:posixunix_scm",(void*)f_4344},
{"f_4340:posixunix_scm",(void*)f_4340},
{"f_4220:posixunix_scm",(void*)f_4220},
{"f_4224:posixunix_scm",(void*)f_4224},
{"f_4301:posixunix_scm",(void*)f_4301},
{"f_4287:posixunix_scm",(void*)f_4287},
{"f_4235:posixunix_scm",(void*)f_4235},
{"f_4240:posixunix_scm",(void*)f_4240},
{"f_4263:posixunix_scm",(void*)f_4263},
{"f_4283:posixunix_scm",(void*)f_4283},
{"f_4246:posixunix_scm",(void*)f_4246},
{"f_4260:posixunix_scm",(void*)f_4260},
{"f_4158:posixunix_scm",(void*)f_4158},
{"f_4171:posixunix_scm",(void*)f_4171},
{"f_4183:posixunix_scm",(void*)f_4183},
{"f_4177:posixunix_scm",(void*)f_4177},
{"f_4148:posixunix_scm",(void*)f_4148},
{"f_4155:posixunix_scm",(void*)f_4155},
{"f_4137:posixunix_scm",(void*)f_4137},
{"f_4144:posixunix_scm",(void*)f_4144},
{"f_4127:posixunix_scm",(void*)f_4127},
{"f_4134:posixunix_scm",(void*)f_4134},
{"f_4117:posixunix_scm",(void*)f_4117},
{"f_4124:posixunix_scm",(void*)f_4124},
{"f_4108:posixunix_scm",(void*)f_4108},
{"f_4115:posixunix_scm",(void*)f_4115},
{"f_4099:posixunix_scm",(void*)f_4099},
{"f_4106:posixunix_scm",(void*)f_4106},
{"f_4090:posixunix_scm",(void*)f_4090},
{"f_4097:posixunix_scm",(void*)f_4097},
{"f_4081:posixunix_scm",(void*)f_4081},
{"f_4088:posixunix_scm",(void*)f_4088},
{"f_4075:posixunix_scm",(void*)f_4075},
{"f_4079:posixunix_scm",(void*)f_4079},
{"f_4069:posixunix_scm",(void*)f_4069},
{"f_4073:posixunix_scm",(void*)f_4073},
{"f_4063:posixunix_scm",(void*)f_4063},
{"f_4067:posixunix_scm",(void*)f_4067},
{"f_4057:posixunix_scm",(void*)f_4057},
{"f_4061:posixunix_scm",(void*)f_4061},
{"f_4051:posixunix_scm",(void*)f_4051},
{"f_4055:posixunix_scm",(void*)f_4055},
{"f_4045:posixunix_scm",(void*)f_4045},
{"f_4049:posixunix_scm",(void*)f_4049},
{"f_4013:posixunix_scm",(void*)f_4013},
{"f_4024:posixunix_scm",(void*)f_4024},
{"f_4017:posixunix_scm",(void*)f_4017},
{"f_3976:posixunix_scm",(void*)f_3976},
{"f_4008:posixunix_scm",(void*)f_4008},
{"f_4001:posixunix_scm",(void*)f_4001},
{"f_3980:posixunix_scm",(void*)f_3980},
{"f_3784:posixunix_scm",(void*)f_3784},
{"f_3957:posixunix_scm",(void*)f_3957},
{"f_3800:posixunix_scm",(void*)f_3800},
{"f_3931:posixunix_scm",(void*)f_3931},
{"f_3806:posixunix_scm",(void*)f_3806},
{"f_3809:posixunix_scm",(void*)f_3809},
{"f_3891:posixunix_scm",(void*)f_3891},
{"f_3889:posixunix_scm",(void*)f_3889},
{"f_3848:posixunix_scm",(void*)f_3848},
{"f_3866:posixunix_scm",(void*)f_3866},
{"f_3864:posixunix_scm",(void*)f_3864},
{"f_3852:posixunix_scm",(void*)f_3852},
{"f_3774:posixunix_scm",(void*)f_3774},
{"f_3764:posixunix_scm",(void*)f_3764},
{"f_3758:posixunix_scm",(void*)f_3758},
{"f_3726:posixunix_scm",(void*)f_3726},
{"f_3733:posixunix_scm",(void*)f_3733},
{"f_3739:posixunix_scm",(void*)f_3739},
{"f_3746:posixunix_scm",(void*)f_3746},
{"f_3687:posixunix_scm",(void*)f_3687},
{"f_3694:posixunix_scm",(void*)f_3694},
{"f_3703:posixunix_scm",(void*)f_3703},
{"f_3645:posixunix_scm",(void*)f_3645},
{"f_3655:posixunix_scm",(void*)f_3655},
{"f_3658:posixunix_scm",(void*)f_3658},
{"f_3661:posixunix_scm",(void*)f_3661},
{"f_3630:posixunix_scm",(void*)f_3630},
{"f_3592:posixunix_scm",(void*)f_3592},
{"f_3622:posixunix_scm",(void*)f_3622},
{"f_3609:posixunix_scm",(void*)f_3609},
{"f_3612:posixunix_scm",(void*)f_3612},
{"f_3546:posixunix_scm",(void*)f_3546},
{"f_3550:posixunix_scm",(void*)f_3550},
{"f_3489:posixunix_scm",(void*)f_3489},
{"f_3482:posixunix_scm",(void*)f_3482},
{"f_3464:posixunix_scm",(void*)f_3464},
{"f_3468:posixunix_scm",(void*)f_3468},
{"f_3479:posixunix_scm",(void*)f_3479},
{"f_3475:posixunix_scm",(void*)f_3475},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
