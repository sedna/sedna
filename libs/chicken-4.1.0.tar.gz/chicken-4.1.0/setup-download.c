/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:40
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: setup-download.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -feature chicken-compile-shared -dynamic -emit-import-library setup-download -ignore-repository -output-file setup-download.c
   used units: library eval data_structures ports extras srfi_69 extras regex posix utils srfi_1 data_structures tcp srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[178];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,56,57,32,97,114,103,115,49,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,50,48,55,32,118,101,114,115,105,111,110,50,48,56,32,118,115,50,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,63),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,119,104,101,110,45,110,111,45,115,117,99,104,45,118,101,114,115,105,111,110,45,119,97,114,110,105,110,103,32,101,103,103,50,49,54,32,118,101,114,115,105,111,110,50,49,55,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,98,111,100,121,50,53,49,32,118,101,114,115,105,111,110,50,54,49,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,50,53,52,32,37,118,101,114,115,105,111,110,50,52,57,50,56,51,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,50,53,51,41};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,50,52,48,32,100,105,114,50,52,49,32,46,32,116,109,112,50,51,57,50,52,50,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,50,50,57,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,7),40,97,49,50,56,55,41,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,13),40,97,49,50,56,49,32,101,120,51,51,48,41,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,50,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,7),40,97,49,51,49,52,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,97,49,51,48,56,32,46,32,97,114,103,115,51,50,52,51,51,54,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,7),40,97,49,50,57,54,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,97,49,50,55,53,32,107,51,50,51,51,50,56,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,97,49,50,53,48,32,114,101,116,117,114,110,51,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,37),40,97,49,50,51,53,32,108,111,99,51,48,53,51,48,54,51,49,49,32,118,101,114,115,105,111,110,51,48,55,51,48,56,51,49,50,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,49,50,50,51,32,101,103,103,51,48,50,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,50,57,56,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,51,52,54,32,112,97,114,103,51,52,55,32,112,110,97,109,51,52,56,32,116,109,112,51,52,53,51,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,49,52,54,57,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,97,49,52,57,55,32,102,105,108,101,100,105,114,52,55,51,52,55,52,52,56,48,32,118,101,114,52,55,53,52,55,54,52,56,49,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,12),40,97,49,53,52,48,32,102,52,54,51,41,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,52,51,52,32,118,101,114,115,105,111,110,52,52,54,32,100,101,115,116,105,110,97,116,105,111,110,52,52,55,32,117,115,101,114,110,97,109,101,52,52,56,32,112,97,115,115,119,111,114,100,52,52,57,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,67),40,100,101,102,45,112,97,115,115,119,111,114,100,52,51,57,32,37,118,101,114,115,105,111,110,52,51,48,53,48,50,32,37,100,101,115,116,105,110,97,116,105,111,110,52,51,49,53,48,51,32,37,117,115,101,114,110,97,109,101,52,51,50,53,48,52,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,51),40,100,101,102,45,117,115,101,114,110,97,109,101,52,51,56,32,37,118,101,114,115,105,111,110,52,51,48,53,48,56,32,37,100,101,115,116,105,110,97,116,105,111,110,52,51,49,53,48,57,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,52,51,55,32,37,118,101,114,115,105,111,110,52,51,48,53,49,51,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,52,51,54,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,52,50,49,32,114,101,112,111,52,50,50,32,46,32,116,109,112,52,50,48,52,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,49,55,49,53,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,49,57,50,55,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,50,48,55,52,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,55,51,55,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,55,57,49,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,56,55,49,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,56,55,52,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,49,56,55,55,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,7),40,97,49,56,56,48,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,32),40,97,49,57,51,51,32,105,110,54,57,50,54,57,51,54,57,55,32,111,117,116,54,57,52,54,57,53,54,57,56,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,49),40,97,49,55,50,49,32,104,111,115,116,53,56,56,53,56,57,53,57,54,32,112,111,114,116,53,57,48,53,57,49,53,57,55,32,108,111,99,110,53,57,50,53,57,51,53,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,44),40,98,111,100,121,53,54,52,32,118,101,114,115,105,111,110,53,55,53,32,100,101,115,116,105,110,97,116,105,111,110,53,55,54,32,116,101,115,116,115,53,55,55,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,116,101,115,116,115,53,54,56,32,37,118,101,114,115,105,111,110,53,54,49,54,49,57,32,37,100,101,115,116,105,110,97,116,105,111,110,53,54,50,54,50,48,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,53,54,55,32,37,118,101,114,115,105,111,110,53,54,49,54,50,52,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,53,54,54,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,53,53,50,32,117,114,108,53,53,51,32,46,32,116,109,112,53,53,49,53,53,52,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,50,50,48,55,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,7),40,97,50,50,49,50,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,50,50,53,49,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,48,55,32,116,114,97,110,115,112,111,114,116,56,48,56,32,108,111,99,97,116,105,111,110,56,48,57,32,46,32,116,109,112,56,48,54,56,49,48,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,50,50,55,49,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,18),40,97,49,48,56,56,32,103,50,50,57,50,51,48,50,51,49,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,12),40,97,49,51,55,49,32,115,51,57,54,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,51,55,56,32,117,115,101,114,110,97,109,101,51,56,56,32,112,97,115,115,119,111,114,100,51,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,112,97,115,115,119,111,114,100,51,56,49,32,37,117,115,101,114,110,97,109,101,51,55,54,52,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,117,115,101,114,110,97,109,101,51,56,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,50,50,55,54,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,50,51,48,48,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,56,53,57,32,108,111,99,97,116,105,111,110,56,54,48,32,46,32,116,109,112,56,53,56,56,54,49,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_957)
static void C_ccall f_957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_981)
static void C_ccall f_981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2277)
static void C_ccall f_2277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_fcall f_1396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1391)
static void C_fcall f_1391(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1350)
static void C_fcall f_1350(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1354)
static void C_ccall f_1354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1384)
static void C_ccall f_1384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1097)
static void C_ccall f_1097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_ccall f_2213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1773)
static void C_fcall f_1773(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_fcall f_1768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1763)
static void C_fcall f_1763(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1707)
static void C_fcall f_1707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1726)
static void C_ccall f_1726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1729)
static void C_ccall f_1729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_fcall f_2137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_fcall f_2111(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_fcall f_2124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_fcall f_2152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_ccall f_2171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_fcall f_1965(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_fcall f_1983(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2031)
static void C_ccall f_2031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_ccall f_1716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_ccall f_1659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1577)
static void C_fcall f_1577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_fcall f_1572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1567)
static void C_fcall f_1567(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1562)
static void C_fcall f_1562(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1446)
static void C_fcall f_1446(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1450)
static void C_ccall f_1450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1456)
static void C_ccall f_1456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1539)
static void C_ccall f_1539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_fcall f_1321(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1215)
static void C_ccall f_1215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1240)
static void C_ccall f_1240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1167)
static void C_fcall f_1167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1162)
static void C_fcall f_1162(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1101)
static void C_fcall f_1101(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1108)
static void C_ccall f_1108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1154)
static void C_ccall f_1154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_fcall f_1070(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1043)
static void C_fcall f_1043(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_fcall f_1028(C_word t0) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_fcall f_1006(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1396)
static void C_fcall trf_1396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1396(t0,t1);}

C_noret_decl(trf_1391)
static void C_fcall trf_1391(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1391(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1391(t0,t1,t2);}

C_noret_decl(trf_1350)
static void C_fcall trf_1350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1350(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1350(t0,t1,t2,t3);}

C_noret_decl(trf_1773)
static void C_fcall trf_1773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1773(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1773(t0,t1);}

C_noret_decl(trf_1768)
static void C_fcall trf_1768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1768(t0,t1,t2);}

C_noret_decl(trf_1763)
static void C_fcall trf_1763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1763(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1763(t0,t1,t2,t3);}

C_noret_decl(trf_1707)
static void C_fcall trf_1707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1707(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1707(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2137)
static void C_fcall trf_2137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2137(t0,t1);}

C_noret_decl(trf_2111)
static void C_fcall trf_2111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2111(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2111(t0,t1);}

C_noret_decl(trf_2124)
static void C_fcall trf_2124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2124(t0,t1);}

C_noret_decl(trf_2152)
static void C_fcall trf_2152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2152(t0,t1,t2);}

C_noret_decl(trf_1965)
static void C_fcall trf_1965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1965(t0,t1);}

C_noret_decl(trf_1973)
static void C_fcall trf_1973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1973(t0,t1,t2);}

C_noret_decl(trf_1983)
static void C_fcall trf_1983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1983(t0,t1);}

C_noret_decl(trf_1577)
static void C_fcall trf_1577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1577(t0,t1);}

C_noret_decl(trf_1572)
static void C_fcall trf_1572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1572(t0,t1,t2);}

C_noret_decl(trf_1567)
static void C_fcall trf_1567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1567(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1567(t0,t1,t2,t3);}

C_noret_decl(trf_1562)
static void C_fcall trf_1562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1562(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1562(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1446)
static void C_fcall trf_1446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1446(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1446(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1321)
static void C_fcall trf_1321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1321(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1321(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1167)
static void C_fcall trf_1167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1167(t0,t1);}

C_noret_decl(trf_1162)
static void C_fcall trf_1162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1162(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1162(t0,t1,t2);}

C_noret_decl(trf_1101)
static void C_fcall trf_1101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1101(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1101(t0,t1,t2);}

C_noret_decl(trf_1070)
static void C_fcall trf_1070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1070(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1070(t0,t1,t2);}

C_noret_decl(trf_1043)
static void C_fcall trf_1043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1043(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1043(t0,t1,t2,t3);}

C_noret_decl(trf_1028)
static void C_fcall trf_1028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1028(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1028(t0);}

C_noret_decl(trf_1006)
static void C_fcall trf_1006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1006(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1006(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(830)){
C_save(t1);
C_rereclaim2(830*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,178);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[5]=C_h_intern(&lf[5],12,"flush-output");
lf[6]=C_h_intern(&lf[6],7,"fprintf");
lf[7]=C_h_intern(&lf[7],18,"current-error-port");
lf[8]=C_h_intern(&lf[8],19,"current-output-port");
lf[9]=C_h_intern(&lf[9],34,"setup-download#temporary-directory");
lf[11]=C_h_intern(&lf[11],36,"setup-api#create-temporary-directory");
lf[13]=C_h_intern(&lf[13],5,"error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[15]=C_h_intern(&lf[15],4,"sort");
lf[16]=C_h_intern(&lf[16],20,"setup-api#version>=\077");
lf[18]=C_h_intern(&lf[18],7,"warning");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[20]=C_h_intern(&lf[20],31,"setup-download#locate-egg/local");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[24]=C_h_intern(&lf[24],10,"directory\077");
lf[25]=C_h_intern(&lf[25],12,"file-exists\077");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[27]=C_h_intern(&lf[27],9,"directory");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[29]=C_h_intern(&lf[29],9,"\003syserror");
lf[30]=C_h_intern(&lf[30],37,"setup-download#gather-egg-information");
lf[31]=C_h_intern(&lf[31],7,"version");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[33]=C_h_intern(&lf[33],20,"with-input-from-file");
lf[34]=C_h_intern(&lf[34],4,"read");
lf[35]=C_h_intern(&lf[35],22,"with-exception-handler");
lf[36]=C_h_intern(&lf[36],30,"call-with-current-continuation");
lf[37]=C_h_intern(&lf[37],14,"string->symbol");
lf[38]=C_h_intern(&lf[38],7,"call/cc");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[40]=C_h_intern(&lf[40],10,"filter-map");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[44]=C_h_intern(&lf[44],4,"conc");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[46]=C_h_intern(&lf[46],2,"qs");
lf[47]=C_h_intern(&lf[47],15,"\003sysget-keyword");
lf[48]=C_h_intern(&lf[48],11,"\000recursive\077");
lf[49]=C_h_intern(&lf[49],29,"setup-download#locate-egg/svn");
lf[50]=C_h_intern(&lf[50],13,"string-append");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_h_intern(&lf[58],6,"system");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[63]=C_h_intern(&lf[63],13,"string-search");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[65]=C_h_intern(&lf[65],20,"with-input-from-pipe");
lf[66]=C_h_intern(&lf[66],10,"read-lines");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_h_intern(&lf[74],30,"setup-download#locate-egg/http");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[77]=C_h_intern(&lf[77],12,"string-match");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000#(http://)\077([^/:]+)(:([^:/]+))\077(/.+)");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[80]=C_h_intern(&lf[80],11,"tcp-connect");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[82]=C_h_intern(&lf[82],7,"reverse");
lf[83]=C_h_intern(&lf[83],17,"close-output-port");
lf[84]=C_h_intern(&lf[84],16,"close-input-port");
lf[85]=C_h_intern(&lf[85],16,"create-directory");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[87]=C_h_intern(&lf[87],7,"display");
lf[88]=C_h_intern(&lf[88],19,"with-output-to-file");
lf[89]=C_h_intern(&lf[89],20,"\003sysread-string/port");
lf[90]=C_h_intern(&lf[90],9,"read-line");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[92]=C_h_intern(&lf[92],14,"string-suffix\077");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[96]=C_h_intern(&lf[96],17,"open-input-string");
lf[97]=C_h_intern(&lf[97],26,"string-concatenate-reverse");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\024reading chunks ...~%");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s*chunked.*");
lf[101]=C_h_intern(&lf[101],12,"string-null\077");
lf[102]=C_h_intern(&lf[102],6,"signal");
lf[103]=C_h_intern(&lf[103],24,"make-composite-condition");
lf[104]=C_h_intern(&lf[104],23,"make-property-condition");
lf[105]=C_h_intern(&lf[105],10,"http-fetch");
lf[106]=C_h_intern(&lf[106],3,"exn");
lf[107]=C_h_intern(&lf[107],7,"message");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[109]=C_h_intern(&lf[109],9,"arguments");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\003200");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.*");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[114]=C_h_intern(&lf[114],5,"\000port");
lf[115]=C_h_intern(&lf[115],7,"\000accept");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\003*/*");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[131]=C_h_intern(&lf[131],15,"\000content-length");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[134]=C_h_intern(&lf[134],11,"\000connection");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000$connecting to host ~s, port ~a ...~%");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[142]=C_h_intern(&lf[142],33,"setup-download#retrieve-extension");
lf[143]=C_h_intern(&lf[143],5,"local");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000)destination for transport `local\047 ignored");
lf[145]=C_h_intern(&lf[145],3,"svn");
lf[146]=C_h_intern(&lf[146],4,"http");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000/cannot retrieve extension unsupported transport");
lf[148]=C_h_intern(&lf[148],16,"\003sysdynamic-wind");
lf[149]=C_h_intern(&lf[149],6,"\000tests");
lf[150]=C_h_intern(&lf[150],9,"\000password");
lf[151]=C_h_intern(&lf[151],9,"\000username");
lf[152]=C_h_intern(&lf[152],12,"\000destination");
lf[153]=C_h_intern(&lf[153],6,"\000quiet");
lf[154]=C_h_intern(&lf[154],8,"\000version");
lf[155]=C_h_intern(&lf[155],30,"setup-download#list-extensions");
lf[156]=C_h_intern(&lf[156],18,"string-concatenate");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[158]=C_h_intern(&lf[158],7,"\003sysmap");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[160]=C_h_intern(&lf[160],12,"string-chomp");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[170]=C_h_intern(&lf[170],14,"make-parameter");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[172]=C_h_intern(&lf[172],15,"chicken-version");
lf[173]=C_h_intern(&lf[173],17,"tcp-write-timeout");
lf[174]=C_h_intern(&lf[174],16,"tcp-read-timeout");
lf[175]=C_h_intern(&lf[175],19,"tcp-connect-timeout");
lf[176]=C_h_intern(&lf[176],11,"\003sysrequire");
lf[177]=C_h_intern(&lf[177],9,"setup-api");
C_register_lf2(lf,178,create_ptable());
t2=C_mutate(&lf[0] /* (set! c296 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k943 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k946 in k943 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k949 in k946 in k943 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k952 in k949 in k946 in k943 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_957,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_960,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_966,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_981,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_987,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[176]))(3,*((C_word*)lf[176]+1),t2,lf[177]);}

/* k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 45   tcp-connect-timeout */
((C_proc3)C_retrieve_symbol_proc(lf[175]))(3,*((C_word*)lf[175]+1),t2,C_fix(10000));}

/* k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 46   tcp-read-timeout */
((C_proc3)C_retrieve_symbol_proc(lf[174]))(3,*((C_word*)lf[174]+1),t2,C_fix(20000));}

/* k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 47   tcp-write-timeout */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,C_fix(20000));}

/* k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=lf[2] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2308,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 51   chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[172]))(2,*((C_word*)lf[172]+1),t4);}

/* k2306 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 51   conc */
((C_proc4)C_retrieve_symbol_proc(lf[44]))(4,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[171],t1);}

/* k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=C_mutate(&lf[4] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 58   make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t4,C_SCHEME_FALSE);}

/* k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=C_mutate((C_word*)lf[9]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate(&lf[10] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[12] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1043,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[17] /* (set! setup-download#when-no-such-version-warning ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[20]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[30]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1215,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[41] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[49]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1444,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[74]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1705,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[142]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2184,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[155]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}

/* setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2257r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2257r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2257r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2261,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t5,lf[153],t4);}

/* k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[151],((C_word*)t0)[2]);}

/* k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[150],((C_word*)t0)[2]);}

/* k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2272,a[2]=t3,a[3]=t5,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2277,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li57),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2301,a[2]=t5,a[3]=t3,a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[148]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a2300 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2277,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=(C_word)C_eqp(t2,lf[143]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[4];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1087,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1089,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1097,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 79   directory */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t8,t5);}
else{
t4=(C_word)C_eqp(t2,lf[145]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1350,a[2]=t6,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1391,a[2]=t8,a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1396,a[2]=t9,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t7))){
/* def-username380404 */
t11=t10;
f_1396(t11,t5);}
else{
t11=(C_word)C_i_car(t7);
t12=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-password381400 */
t13=t9;
f_1391(t13,t5,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body378387 */
t15=t8;
f_1350(t15,t5,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t5,lf[0],t14);}}}}
else{
/* setup-download.scm: 294  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t1,lf[169],((C_word*)t0)[5]);}}}

/* def-username380 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1396,NULL,2,t0,t1);}
/* def-password381400 */
t2=((C_word*)t0)[2];
f_1391(t2,t1,C_SCHEME_FALSE);}

/* def-password381 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1391(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1391,NULL,3,t0,t1,t2);}
/* body378387 */
t3=((C_word*)t0)[2];
f_1350(t3,t1,t2,C_SCHEME_FALSE);}

/* body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1350(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1350,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1354,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
/* setup-download.scm: 120  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t4,lf[166],t2,lf[167]);}
else{
t5=t4;
f_1354(2,t5,lf[168]);}}

/* k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-download.scm: 121  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[163],((C_word*)t0)[2],lf[164]);}
else{
t3=t2;
f_1357(2,t3,lf[165]);}}

/* k1355 in k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1360,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 122  make-svn-ls-cmd */
f_1321(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1358 in k1355 in k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1363,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 123  d */
f_1006(t2,lf[162],(C_word)C_a_i_list(&a,1,t1));}

/* k1361 in k1358 in k1355 in k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1372,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1384,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 126  with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t4,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1382 in k1361 in k1358 in k1355 in k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1371 in k1361 in k1358 in k1355 in k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1372,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1380,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 125  string-chomp */
((C_proc4)C_retrieve_symbol_proc(lf[160]))(4,*((C_word*)lf[160]+1),t3,t2,lf[161]);}

/* k1378 in a1371 in k1361 in k1358 in k1355 in k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 125  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),((C_word*)t0)[2],t1,lf[159]);}

/* k1368 in k1361 in k1358 in k1355 in k1352 in body378 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 124  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[156]))(3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* k1095 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[158]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1088 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1089,3,t0,t1,t2);}
/* string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t1,t2,lf[157]);}

/* k1085 in a2276 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 79   string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[156]))(3,*((C_word*)lf[156]+1),((C_word*)t0)[2],t1);}

/* a2271 in k2265 in k2262 in k2259 in setup-download#list-extensions in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_2184r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2184r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2184r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2188,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[154],t5);}

/* k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[153],((C_word*)t0)[2]);}

/* k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[152],((C_word*)t0)[2]);}

/* k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[151],((C_word*)t0)[2]);}

/* k2195 in k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[150],((C_word*)t0)[2]);}

/* k2198 in k2195 in k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[149],((C_word*)t0)[2]);}

/* k2201 in k2198 in k2195 in k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=((C_word*)t0)[10];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=t3,a[3]=t5,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2213,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word)li48),tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2252,a[2]=t5,a[3]=t3,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[148]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a2251 in k2201 in k2198 in k2195 in k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2212 in k2201 in k2198 in k2195 in k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=((C_word*)t0)[9];
t3=(C_word)C_eqp(t2,lf[143]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
/* setup-download.scm: 277  warning */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t4,lf[144]);}
else{
t5=t4;
f_2223(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_eqp(t2,lf[145]);
if(C_truep(t4)){
/* setup-download.scm: 280  locate-egg/svn */
((C_proc8)C_retrieve_symbol_proc(lf[49]))(8,*((C_word*)lf[49]+1),t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t5=(C_word)C_eqp(t2,lf[146]);
if(C_truep(t5)){
/* setup-download.scm: 282  locate-egg/http */
((C_proc7)C_retrieve_symbol_proc(lf[74]))(7,*((C_word*)lf[74]+1),t1,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
/* setup-download.scm: 284  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t1,lf[147],((C_word*)t0)[9]);}}}}

/* k2221 in a2212 in k2201 in k2198 in k2195 in k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 278  locate-egg/local */
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2207 in k2201 in k2198 in k2195 in k2192 in k2189 in k2186 in setup-download#retrieve-extension in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_1705r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1705r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1705r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1707,a[2]=t2,a[3]=t3,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1763,a[2]=t5,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1768,a[2]=t6,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1773,a[2]=t7,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-version566627 */
t9=t8;
f_1773(t9,t1);}
else{
t9=(C_word)C_i_car(t4);
t10=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t10))){
/* def-destination567623 */
t11=t7;
f_1768(t11,t1,t9);}
else{
t11=(C_word)C_i_car(t10);
t12=(C_word)C_i_cdr(t10);
if(C_truep((C_word)C_i_nullp(t12))){
/* def-tests568618 */
t13=t6;
f_1763(t13,t1,t9,t11);}
else{
t13=(C_word)C_i_car(t12);
t14=(C_word)C_i_cdr(t12);
if(C_truep((C_word)C_i_nullp(t14))){
/* body564574 */
t15=t5;
f_1707(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-version566 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1773(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1773,NULL,2,t0,t1);}
/* def-destination567623 */
t2=((C_word*)t0)[2];
f_1768(t2,t1,C_SCHEME_FALSE);}

/* def-destination567 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1768,NULL,3,t0,t1,t2);}
/* def-tests568618 */
t3=((C_word*)t0)[2];
f_1763(t3,t1,t2,C_SCHEME_FALSE);}

/* def-tests568 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1763(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1763,NULL,4,t0,t1,t2,t3);}
/* body564574 */
t4=((C_word*)t0)[2];
f_1707(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1707(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1707,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1711,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t6=t5;
f_1711(2,t6,t3);}
else{
/* setup-download.scm: 165  get-temporary-directory */
f_1028(t5);}}

/* k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[6],a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word)li41),tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1722,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1726,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
/* setup-download.scm: 170  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t6,lf[140],((C_word*)t0)[5]);}
else{
t7=t6;
f_1752(2,t7,lf[141]);}}

/* k1750 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?lf[137]:lf[138]);
/* setup-download.scm: 167  string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[50]+1)))(7,*((C_word*)lf[50]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[139],((C_word*)t0)[2],t1,t2);}

/* k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1729,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 172  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1745,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 173  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,t1);}

/* k1743 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1732(2,t2,C_SCHEME_UNDEFINED);}
else{
/* setup-download.scm: 173  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1735,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[5];
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1923,a[2]=t2,a[3]=t5,a[4]=t6,a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 213  d */
f_1006(t7,lf[136],(C_word)C_a_i_list(&a,2,t3,t4));}

/* k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word)li40),tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1934,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t5,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 215  d */
f_1006(t6,lf[135],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}

/* k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[31],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1941,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,4,lf[114],((C_word*)t0)[4],lf[115],lf[116]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1858,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t5,lf[114],t4,t6);}

/* a1880 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(80));}

/* k1856 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1878,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[134],((C_word*)t0)[2],t3);}

/* a1877 in k1856 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[133]);}

/* k1859 in k1856 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1875,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[115],((C_word*)t0)[2],t3);}

/* a1874 in k1859 in k1856 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[132]);}

/* k1862 in k1859 in k1856 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_symbol_proc(lf[47]))(5,*((C_word*)lf[47]+1),t2,lf[131],((C_word*)t0)[2],t3);}

/* a1871 in k1862 in k1859 in k1856 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* k1865 in k1862 in k1859 in k1856 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 193  conc */
((C_proc24)C_retrieve_symbol_proc(lf[44]))(24,*((C_word*)lf[44]+1),((C_word*)t0)[7],lf[117],((C_word*)t0)[6],lf[118],lf[119],lf[120],((C_word*)t0)[5],lf[121],lf[122],C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*"),lf[123],lf[124],((C_word*)t0)[4],lf[125],lf[126],((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],lf[127],lf[128],t1,lf[129],lf[130]);}

/* k2142 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 216  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[87]+1)))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1941,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 219  flush-output */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),t2,((C_word*)t0)[5]);}

/* k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 220  d */
f_1006(t2,lf[113],C_SCHEME_END_OF_LIST);}

/* k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1950,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 222  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}

/* k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1953,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
if(C_truep((C_word)C_i_stringp(t3))){
/* setup-download.scm: 204  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t2,lf[112],t3);}
else{
t4=t2;
f_1953(2,t4,C_SCHEME_FALSE);}}

/* k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1956,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 224  d */
f_1006(t2,lf[111],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t4);
t6=t3;
f_2137(t6,(C_word)C_i_string_equal_p(lf[110],t5));}
else{
t5=t3;
f_2137(t5,C_SCHEME_FALSE);}}

/* k2135 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_2137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2137,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1959(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1848,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 181  make-property-condition */
((C_proc7)C_retrieve_symbol_proc(lf[104]))(7,*((C_word*)lf[104]+1),t4,lf[106],lf[107],lf[108],lf[109],t2);}}

/* k1846 in k2135 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1852,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 185  make-property-condition */
((C_proc3)C_retrieve_symbol_proc(lf[104]))(3,*((C_word*)lf[104]+1),t2,lf[105]);}

/* k1850 in k1846 in k2135 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 180  make-composite-condition */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1842 in k2135 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 179  signal */
((C_proc3)C_retrieve_symbol_proc(lf[102]))(3,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1);}

/* k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word)li35),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2111(t6,t2);}

/* loop in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_2111(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2111,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 229  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2113 in loop in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 230  string-null? */
((C_proc3)C_retrieve_symbol_proc(lf[101]))(3,*((C_word*)lf[101]+1),t2,t1);}

/* k2119 in k2113 in loop in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2133,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
/* setup-download.scm: 210  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t3,lf[100],t4);}}

/* k2131 in k2119 in k2113 in loop in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_2124(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_2124(t2,C_SCHEME_UNDEFINED);}}

/* k2122 in k2119 in k2113 in loop in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_2124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2124,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 232  d */
f_1006(t2,lf[99],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k2125 in k2122 in k2119 in k2113 in loop in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 233  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2111(t2,((C_word*)t0)[2]);}

/* k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2099,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 235  d */
f_1006(t3,lf[98],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_1965(t3,C_SCHEME_UNDEFINED);}}

/* k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2152,a[2]=t3,a[3]=t5,a[4]=((C_word)li34),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2152(t7,t2,C_SCHEME_END_OF_LIST);}

/* get-chunks in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_2152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2152,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 265  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t4,((C_word*)t0)[2]);}

/* k2180 in get-chunks in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 265  string->number */
C_string_to_number(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k2154 in get-chunks in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* setup-download.scm: 267  string-concatenate-reverse */
((C_proc3)C_retrieve_symbol_proc(lf[97]))(3,*((C_word*)lf[97]+1),((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* read-string/port */
t3=C_retrieve(lf[89]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}}

/* k2166 in k2154 in get-chunks in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2171,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 269  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2]);}

/* k2169 in k2166 in k2154 in get-chunks in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2171,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* setup-download.scm: 270  get-chunks */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2152(t3,((C_word*)t0)[2],t2);}

/* k2100 in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2105,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 237  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2103 in k2100 in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 238  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[96]))(3,*((C_word*)lf[96]+1),t2,((C_word*)t0)[2]);}

/* k2107 in k2103 in k2100 in k2097 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1965(t3,t2);}

/* k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1965,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 239  d */
f_1006(t2,lf[95],C_SCHEME_END_OF_LIST);}

/* k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li33),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1973(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1973,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 241  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=t2;
f_1983(t4,(C_word)C_eqp(lf[13],t3));}
else{
t3=t2;
f_1983(t3,C_SCHEME_FALSE);}}

/* k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1983,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1990,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* setup-download.scm: 243  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,lf[81],t3);}
else{
t2=(C_word)C_eofp(((C_word*)t0)[8]);
t3=(C_truep(t2)?t2:(C_word)C_i_not(((C_word*)t0)[8]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 245  close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[8]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2031,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 250  string-suffix? */
((C_proc4)C_retrieve_symbol_proc(lf[92]))(4,*((C_word*)lf[92]+1),t4,lf[93],((C_word*)t0)[8]);}
else{
/* setup-download.scm: 249  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[7],lf[94],((C_word*)t0)[8]);}}}}

/* k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2031,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 251  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 256  d */
f_1006(t2,lf[91],(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k2048 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* setup-download.scm: 257  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2051 in k2048 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 258  read-line */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2054 in k2051 in k2048 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* read-string/port */
t3=C_retrieve(lf[89]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2057 in k2054 in k2051 in k2048 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 260  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2071 in k2057 in k2054 in k2051 in k2048 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[3],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 260  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),((C_word*)t0)[2],t1,t2);}

/* a2074 in k2071 in k2057 in k2054 in k2051 in k2048 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
/* display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[87]+1)))(3,*((C_word*)lf[87]+1),t1,((C_word*)t0)[2]);}

/* k2060 in k2057 in k2054 in k2051 in k2048 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* setup-download.scm: 261  get-files */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1973(t3,((C_word*)t0)[2],t2);}

/* k2032 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 252  d */
f_1006(t2,lf[86],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k2035 in k2032 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2047,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 253  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2045 in k2035 in k2032 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 253  create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),((C_word*)t0)[2],t1);}

/* k2038 in k2035 in k2032 in k2029 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 254  get-files */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1973(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2008 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 246  close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[83]+1)))(3,*((C_word*)lf[83]+1),t2,((C_word*)t0)[2]);}

/* k2011 in k2008 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 247  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[82]+1)))(3,*((C_word*)lf[82]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1988 in k1981 in k1975 in get-files in k1966 in k1963 in k1960 in k1957 in k1954 in k1951 in k1948 in k1945 in k1942 in k1939 in k1936 in a1933 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[13]+1),t1,t2);}

/* a1927 in k1921 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
/* setup-download.scm: 214  tcp-connect */
((C_proc4)C_retrieve_symbol_proc(lf[80]))(4,*((C_word*)lf[80]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1733 in k1730 in k1727 in k1724 in a1721 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_truep(t2)?t2:lf[79]);
/* setup-download.scm: 176  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a1715 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1716,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 155  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),t3,lf[78],t2);}

/* k1657 in a1715 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1659,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(t1):((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1670,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?(C_word)C_i_cadddr(t1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1683,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_list_ref(t1,C_fix(4));
/* setup-download.scm: 159  string->number */
C_string_to_number(3,0,t5,t6);}
else{
t5=t3;
f_1670(2,t5,C_fix(80));}}

/* k1681 in k1657 in a1715 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1670(2,t2,t1);}
else{
t2=(C_word)C_i_list_ref(((C_word*)t0)[2],C_fix(4));
/* setup-download.scm: 160  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],lf[76],t2);}}

/* k1668 in k1657 in a1715 in k1709 in body564 in setup-download#locate-egg/http in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_list_ref(((C_word*)t0)[4],C_fix(5)):lf[75]);
/* setup-download.scm: 156  values */
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_1444r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1444r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1444r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1446,a[2]=t3,a[3]=t2,a[4]=((C_word)li24),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1562,a[2]=t5,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1567,a[2]=t6,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1572,a[2]=t7,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1577,a[2]=t8,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-version436516 */
t10=t9;
f_1577(t10,t1);}
else{
t10=(C_word)C_i_car(t4);
t11=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-destination437512 */
t12=t8;
f_1572(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* def-username438507 */
t14=t7;
f_1567(t14,t1,t10,t12);}
else{
t14=(C_word)C_i_car(t13);
t15=(C_word)C_i_cdr(t13);
if(C_truep((C_word)C_i_nullp(t15))){
/* def-password439501 */
t16=t6;
f_1562(t16,t1,t10,t12,t14);}
else{
t16=(C_word)C_i_car(t15);
t17=(C_word)C_i_cdr(t15);
if(C_truep((C_word)C_i_nullp(t17))){
/* body434445 */
t18=t5;
f_1446(t18,t1,t10,t12,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t1,lf[0],t17);}}}}}}

/* def-version436 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1577,NULL,2,t0,t1);}
/* def-destination437512 */
t2=((C_word*)t0)[2];
f_1572(t2,t1,C_SCHEME_FALSE);}

/* def-destination437 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1572,NULL,3,t0,t1,t2);}
/* def-username438507 */
t3=((C_word*)t0)[2];
f_1567(t3,t1,t2,C_SCHEME_FALSE);}

/* def-username438 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1567(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1567,NULL,4,t0,t1,t2,t3);}
/* def-password439501 */
t4=((C_word*)t0)[2];
f_1562(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-password439 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1562(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1562,NULL,5,t0,t1,t2,t3,t4);}
/* body434445 */
t5=((C_word*)t0)[2];
f_1446(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1446(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1446,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1450,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
/* setup-download.scm: 129  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t6,lf[71],t4,lf[72]);}
else{
t7=t6;
f_1450(2,t7,lf[73]);}}

/* k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* setup-download.scm: 130  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t2,lf[68],((C_word*)t0)[2],lf[69]);}
else{
t3=t2;
f_1453(2,t3,lf[70]);}}

/* k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1456,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1555,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 131  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[4],((C_word*)t0)[7]);}

/* k1553 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
/* setup-download.scm: 131  make-svn-ls-cmd */
f_1321(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,(C_word)C_a_i_list(&a,2,lf[48],C_SCHEME_TRUE));}

/* k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1459,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* setup-download.scm: 132  d */
f_1006(t2,lf[67],(C_word)C_a_i_list(&a,1,t1));}

/* k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* setup-download.scm: 133  with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t2,((C_word*)t0)[2],C_retrieve(lf[66]));}

/* k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 136  filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),t3,t4,t1);}

/* a1540 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1541,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1545,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 137  string-search */
((C_proc4)C_retrieve_symbol_proc(lf[63]))(4,*((C_word*)lf[63]+1),t3,lf[64],t2);}

/* k1543 in a1540 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_cadr(t1):C_SCHEME_FALSE));}

/* k1537 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 134  existing-version */
f_1043(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t1,a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li22),tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1498,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1502,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_1532(2,t7,t5);}
else{
/* setup-download.scm: 147  get-temporary-directory */
f_1028(t6);}}

/* k1530 in a1497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 147  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1500 in a1497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1528,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 148  conc */
((C_proc7)C_retrieve_symbol_proc(lf[44]))(7,*((C_word*)lf[44]+1),t3,((C_word*)t0)[4],C_make_character(47),((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[2]);}

/* k1526 in k1500 in a1497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))?lf[60]:lf[61]);
/* setup-download.scm: 116  conc */
((C_proc15)C_retrieve_symbol_proc(lf[44]))(15,*((C_word*)lf[44]+1),((C_word*)t0)[2],lf[62],t2,C_make_character(32),t3,C_make_character(32),C_make_character(34),t1,C_make_character(34),C_make_character(32),C_make_character(34),t4,C_make_character(34),t5);}

/* k1503 in k1500 in a1497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1508,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 149  d */
f_1006(t2,lf[59],(C_word)C_a_i_list(&a,1,t1));}

/* k1506 in k1503 in k1500 in a1497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 150  system */
((C_proc3)C_retrieve_symbol_proc(lf[58]))(3,*((C_word*)lf[58]+1),t2,((C_word*)t0)[2]);}

/* k1522 in k1506 in k1503 in k1500 in a1497 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
/* setup-download.scm: 151  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* setup-download.scm: 152  values */
C_values(4,0,((C_word*)t0)[4],C_SCHEME_FALSE,lf[57]);}}

/* a1469 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1470,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 141  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,lf[51],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1484,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 143  when-no-such-version-warning */
f_1070(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1482 in a1469 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_member(lf[52],((C_word*)t0)[3]))){
/* setup-download.scm: 145  values */
C_values(4,0,((C_word*)t0)[2],lf[53],lf[54]);}
else{
/* setup-download.scm: 146  values */
C_values(4,0,((C_word*)t0)[2],lf[55],lf[56]);}}

/* k1479 in a1469 in k1463 in k1460 in k1457 in k1454 in k1451 in k1448 in body434 in setup-download#locate-egg/svn in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 141  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#make-svn-ls-cmd in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1321(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1321,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1325,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#get-keyword */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t6,lf[48],t5);}

/* k1323 in setup-download#make-svn-ls-cmd in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(C_truep(t1)?lf[42]:lf[43]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1336,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 113  qs */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),t3,((C_word*)t0)[2]);}

/* k1334 in k1323 in setup-download#make-svn-ls-cmd in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 113  conc */
((C_proc8)C_retrieve_symbol_proc(lf[44]))(8,*((C_word*)lf[44]+1),((C_word*)t0)[5],lf[45],((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1215,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1219,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 95   directory */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t3,t2);}

/* k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[3],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 96   filter-map */
((C_proc4)C_retrieve_symbol_proc(lf[40]))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2,t1);}

/* a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1224,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1230,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1236,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1236,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1240,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 99   make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t4,t2,((C_word*)t0)[2],lf[39]);}

/* k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 100  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,t1);}

/* k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 101  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1251,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* setup-download.scm: 103  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[37]+1)))(3,*((C_word*)lf[37]+1),t3,((C_word*)t0)[3]);}

/* k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1259,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[31],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1271,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t4,t5);}

/* a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1276,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1282,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1297,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t1,t3,t4);}

/* a1296 in a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1308 in a1296 in a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1309r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1309r(t0,t1,t2);}}

static void C_ccall f_1309r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1315,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
/* k323328 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1314 in a1308 in a1296 in a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1302 in a1296 in a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
/* setup-download.scm: 109  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[33]))(4,*((C_word*)lf[33]+1),t1,((C_word*)t0)[2],*((C_word*)lf[34]+1));}

/* a1281 in a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1282,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* k323328 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1287 in a1281 in a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1292,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 107  warning */
((C_proc4)C_retrieve_symbol_proc(lf[18]))(4,*((C_word*)lf[18]+1),t2,lf[32],((C_word*)t0)[2]);}

/* k1290 in a1287 in a1281 in a1275 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 108  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1272 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1269 in k1257 in a1250 in k1244 in k1238 in a1235 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* a1229 in a1223 in k1217 in setup-download#gather-egg-information in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
/* setup-download.scm: 98   locate-egg/local */
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1099r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1099r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1099r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1101,a[2]=t3,a[3]=t2,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1162,a[2]=t5,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1167,a[2]=t6,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-version253286 */
t8=t7;
f_1167(t8,t1);}
else{
t8=(C_word)C_i_car(t4);
t9=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t9))){
/* def-destination254282 */
t10=t6;
f_1162(t10,t1,t8);}
else{
t10=(C_word)C_i_car(t9);
t11=(C_word)C_i_cdr(t9);
if(C_truep((C_word)C_i_nullp(t11))){
/* body251260 */
t12=t5;
f_1101(t12,t1,t8);}
else{
/* ##sys#error */
t12=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-version253 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1167,NULL,2,t0,t1);}
/* def-destination254282 */
t2=((C_word*)t0)[2];
f_1162(t2,t1,C_SCHEME_FALSE);}

/* def-destination254 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1162(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1162,NULL,3,t0,t1,t2);}
/* body251260 */
t3=((C_word*)t0)[2];
f_1101(t3,t1,t2);}

/* body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1101(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1101,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1105,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 82   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 83   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,t1,lf[28]);}

/* k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1148,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 84   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,t1);}

/* k1146 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1148,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 84   directory? */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1111(2,t2,C_SCHEME_FALSE);}}

/* k1152 in k1146 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1154,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 85   directory */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1111(2,t2,C_SCHEME_FALSE);}}

/* k1159 in k1152 in k1146 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 85   existing-version */
f_1043(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1109 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1121,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 87   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[5],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-download.scm: 88   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[26]);}}

/* k1122 in k1109 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* setup-download.scm: 89   when-no-such-version-warning */
f_1070(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1125 in k1122 in k1109 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 90   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,((C_word*)t0)[3]);}

/* k1140 in k1125 in k1122 in k1109 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-download.scm: 90   directory? */
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1133(2,t2,C_SCHEME_FALSE);}}

/* k1131 in k1125 in k1122 in k1109 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-download.scm: 91   values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],lf[22]);}
else{
/* setup-download.scm: 92   values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],lf[23]);}}

/* k1119 in k1109 in k1106 in k1103 in body251 in setup-download#locate-egg/local in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 87   values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#when-no-such-version-warning in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1070(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1070,NULL,3,t1,t2,t3);}
if(C_truep(t3)){
/* setup-download.scm: 76   warning */
((C_proc5)C_retrieve_symbol_proc(lf[18]))(5,*((C_word*)lf[18]+1),t1,lf[19],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setup-download#existing-version in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1043(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1043,NULL,4,t1,t2,t3,t4);}
if(C_truep(t3)){
if(C_truep((C_word)C_i_member(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* setup-download.scm: 70   error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t1,lf[14],t2,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 71   sort */
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),t5,t4,C_retrieve(lf[16]));}}

/* k1057 in setup-download#existing-version in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_pairp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_i_car(t1):C_SCHEME_FALSE));}

/* setup-download#get-temporary-directory in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1028(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1028,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 61   temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[9]))(2,*((C_word*)lf[9]+1),t2);}

/* k1030 in setup-download#get-temporary-directory in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* setup-download.scm: 62   setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t2);}}

/* k1036 in k1030 in setup-download#get-temporary-directory in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1041,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* setup-download.scm: 63   temporary-directory */
((C_proc3)C_retrieve_symbol_proc(lf[9]))(3,*((C_word*)lf[9]+1),t2,t1);}

/* k1039 in k1036 in k1030 in setup-download#get-temporary-directory in k1024 in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-download#d in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_fcall f_1006(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1006,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1010,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))){
/* setup-download.scm: 54   current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t4);}
else{
/* setup-download.scm: 54   current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[8]+1)))(2,*((C_word*)lf[8]+1),t4);}}

/* k1008 in setup-download#d in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1013,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,C_retrieve(lf[6]),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1011 in k1008 in setup-download#d in k1002 in k997 in k994 in k991 in k988 in k985 in k982 in k979 in k976 in k973 in k970 in k967 in k964 in k961 in k958 in k955 in k952 in k949 in k946 in k943 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download.scm: 56   flush-output */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[206] = {
{"toplevel:setup_download_scm",(void*)C_toplevel},
{"f_945:setup_download_scm",(void*)f_945},
{"f_948:setup_download_scm",(void*)f_948},
{"f_951:setup_download_scm",(void*)f_951},
{"f_954:setup_download_scm",(void*)f_954},
{"f_957:setup_download_scm",(void*)f_957},
{"f_960:setup_download_scm",(void*)f_960},
{"f_963:setup_download_scm",(void*)f_963},
{"f_966:setup_download_scm",(void*)f_966},
{"f_969:setup_download_scm",(void*)f_969},
{"f_972:setup_download_scm",(void*)f_972},
{"f_975:setup_download_scm",(void*)f_975},
{"f_978:setup_download_scm",(void*)f_978},
{"f_981:setup_download_scm",(void*)f_981},
{"f_984:setup_download_scm",(void*)f_984},
{"f_987:setup_download_scm",(void*)f_987},
{"f_990:setup_download_scm",(void*)f_990},
{"f_993:setup_download_scm",(void*)f_993},
{"f_996:setup_download_scm",(void*)f_996},
{"f_999:setup_download_scm",(void*)f_999},
{"f_2308:setup_download_scm",(void*)f_2308},
{"f_1004:setup_download_scm",(void*)f_1004},
{"f_1026:setup_download_scm",(void*)f_1026},
{"f_2257:setup_download_scm",(void*)f_2257},
{"f_2261:setup_download_scm",(void*)f_2261},
{"f_2264:setup_download_scm",(void*)f_2264},
{"f_2267:setup_download_scm",(void*)f_2267},
{"f_2301:setup_download_scm",(void*)f_2301},
{"f_2277:setup_download_scm",(void*)f_2277},
{"f_1396:setup_download_scm",(void*)f_1396},
{"f_1391:setup_download_scm",(void*)f_1391},
{"f_1350:setup_download_scm",(void*)f_1350},
{"f_1354:setup_download_scm",(void*)f_1354},
{"f_1357:setup_download_scm",(void*)f_1357},
{"f_1360:setup_download_scm",(void*)f_1360},
{"f_1363:setup_download_scm",(void*)f_1363},
{"f_1384:setup_download_scm",(void*)f_1384},
{"f_1372:setup_download_scm",(void*)f_1372},
{"f_1380:setup_download_scm",(void*)f_1380},
{"f_1370:setup_download_scm",(void*)f_1370},
{"f_1097:setup_download_scm",(void*)f_1097},
{"f_1089:setup_download_scm",(void*)f_1089},
{"f_1087:setup_download_scm",(void*)f_1087},
{"f_2272:setup_download_scm",(void*)f_2272},
{"f_2184:setup_download_scm",(void*)f_2184},
{"f_2188:setup_download_scm",(void*)f_2188},
{"f_2191:setup_download_scm",(void*)f_2191},
{"f_2194:setup_download_scm",(void*)f_2194},
{"f_2197:setup_download_scm",(void*)f_2197},
{"f_2200:setup_download_scm",(void*)f_2200},
{"f_2203:setup_download_scm",(void*)f_2203},
{"f_2252:setup_download_scm",(void*)f_2252},
{"f_2213:setup_download_scm",(void*)f_2213},
{"f_2223:setup_download_scm",(void*)f_2223},
{"f_2208:setup_download_scm",(void*)f_2208},
{"f_1705:setup_download_scm",(void*)f_1705},
{"f_1773:setup_download_scm",(void*)f_1773},
{"f_1768:setup_download_scm",(void*)f_1768},
{"f_1763:setup_download_scm",(void*)f_1763},
{"f_1707:setup_download_scm",(void*)f_1707},
{"f_1711:setup_download_scm",(void*)f_1711},
{"f_1722:setup_download_scm",(void*)f_1722},
{"f_1752:setup_download_scm",(void*)f_1752},
{"f_1726:setup_download_scm",(void*)f_1726},
{"f_1729:setup_download_scm",(void*)f_1729},
{"f_1745:setup_download_scm",(void*)f_1745},
{"f_1732:setup_download_scm",(void*)f_1732},
{"f_1923:setup_download_scm",(void*)f_1923},
{"f_1934:setup_download_scm",(void*)f_1934},
{"f_1938:setup_download_scm",(void*)f_1938},
{"f_1881:setup_download_scm",(void*)f_1881},
{"f_1858:setup_download_scm",(void*)f_1858},
{"f_1878:setup_download_scm",(void*)f_1878},
{"f_1861:setup_download_scm",(void*)f_1861},
{"f_1875:setup_download_scm",(void*)f_1875},
{"f_1864:setup_download_scm",(void*)f_1864},
{"f_1872:setup_download_scm",(void*)f_1872},
{"f_1867:setup_download_scm",(void*)f_1867},
{"f_2144:setup_download_scm",(void*)f_2144},
{"f_1941:setup_download_scm",(void*)f_1941},
{"f_1944:setup_download_scm",(void*)f_1944},
{"f_1947:setup_download_scm",(void*)f_1947},
{"f_1950:setup_download_scm",(void*)f_1950},
{"f_1953:setup_download_scm",(void*)f_1953},
{"f_1956:setup_download_scm",(void*)f_1956},
{"f_2137:setup_download_scm",(void*)f_2137},
{"f_1848:setup_download_scm",(void*)f_1848},
{"f_1852:setup_download_scm",(void*)f_1852},
{"f_1844:setup_download_scm",(void*)f_1844},
{"f_1959:setup_download_scm",(void*)f_1959},
{"f_2111:setup_download_scm",(void*)f_2111},
{"f_2115:setup_download_scm",(void*)f_2115},
{"f_2121:setup_download_scm",(void*)f_2121},
{"f_2133:setup_download_scm",(void*)f_2133},
{"f_2124:setup_download_scm",(void*)f_2124},
{"f_2127:setup_download_scm",(void*)f_2127},
{"f_1962:setup_download_scm",(void*)f_1962},
{"f_2099:setup_download_scm",(void*)f_2099},
{"f_2152:setup_download_scm",(void*)f_2152},
{"f_2182:setup_download_scm",(void*)f_2182},
{"f_2156:setup_download_scm",(void*)f_2156},
{"f_2168:setup_download_scm",(void*)f_2168},
{"f_2171:setup_download_scm",(void*)f_2171},
{"f_2102:setup_download_scm",(void*)f_2102},
{"f_2105:setup_download_scm",(void*)f_2105},
{"f_2109:setup_download_scm",(void*)f_2109},
{"f_1965:setup_download_scm",(void*)f_1965},
{"f_1968:setup_download_scm",(void*)f_1968},
{"f_1973:setup_download_scm",(void*)f_1973},
{"f_1977:setup_download_scm",(void*)f_1977},
{"f_1983:setup_download_scm",(void*)f_1983},
{"f_2031:setup_download_scm",(void*)f_2031},
{"f_2050:setup_download_scm",(void*)f_2050},
{"f_2053:setup_download_scm",(void*)f_2053},
{"f_2056:setup_download_scm",(void*)f_2056},
{"f_2059:setup_download_scm",(void*)f_2059},
{"f_2073:setup_download_scm",(void*)f_2073},
{"f_2075:setup_download_scm",(void*)f_2075},
{"f_2062:setup_download_scm",(void*)f_2062},
{"f_2034:setup_download_scm",(void*)f_2034},
{"f_2037:setup_download_scm",(void*)f_2037},
{"f_2047:setup_download_scm",(void*)f_2047},
{"f_2040:setup_download_scm",(void*)f_2040},
{"f_2010:setup_download_scm",(void*)f_2010},
{"f_2013:setup_download_scm",(void*)f_2013},
{"f_1990:setup_download_scm",(void*)f_1990},
{"f_1928:setup_download_scm",(void*)f_1928},
{"f_1735:setup_download_scm",(void*)f_1735},
{"f_1716:setup_download_scm",(void*)f_1716},
{"f_1659:setup_download_scm",(void*)f_1659},
{"f_1683:setup_download_scm",(void*)f_1683},
{"f_1670:setup_download_scm",(void*)f_1670},
{"f_1444:setup_download_scm",(void*)f_1444},
{"f_1577:setup_download_scm",(void*)f_1577},
{"f_1572:setup_download_scm",(void*)f_1572},
{"f_1567:setup_download_scm",(void*)f_1567},
{"f_1562:setup_download_scm",(void*)f_1562},
{"f_1446:setup_download_scm",(void*)f_1446},
{"f_1450:setup_download_scm",(void*)f_1450},
{"f_1453:setup_download_scm",(void*)f_1453},
{"f_1555:setup_download_scm",(void*)f_1555},
{"f_1456:setup_download_scm",(void*)f_1456},
{"f_1459:setup_download_scm",(void*)f_1459},
{"f_1462:setup_download_scm",(void*)f_1462},
{"f_1541:setup_download_scm",(void*)f_1541},
{"f_1545:setup_download_scm",(void*)f_1545},
{"f_1539:setup_download_scm",(void*)f_1539},
{"f_1465:setup_download_scm",(void*)f_1465},
{"f_1498:setup_download_scm",(void*)f_1498},
{"f_1532:setup_download_scm",(void*)f_1532},
{"f_1502:setup_download_scm",(void*)f_1502},
{"f_1528:setup_download_scm",(void*)f_1528},
{"f_1505:setup_download_scm",(void*)f_1505},
{"f_1508:setup_download_scm",(void*)f_1508},
{"f_1524:setup_download_scm",(void*)f_1524},
{"f_1470:setup_download_scm",(void*)f_1470},
{"f_1484:setup_download_scm",(void*)f_1484},
{"f_1481:setup_download_scm",(void*)f_1481},
{"f_1321:setup_download_scm",(void*)f_1321},
{"f_1325:setup_download_scm",(void*)f_1325},
{"f_1336:setup_download_scm",(void*)f_1336},
{"f_1215:setup_download_scm",(void*)f_1215},
{"f_1219:setup_download_scm",(void*)f_1219},
{"f_1224:setup_download_scm",(void*)f_1224},
{"f_1236:setup_download_scm",(void*)f_1236},
{"f_1240:setup_download_scm",(void*)f_1240},
{"f_1246:setup_download_scm",(void*)f_1246},
{"f_1251:setup_download_scm",(void*)f_1251},
{"f_1259:setup_download_scm",(void*)f_1259},
{"f_1276:setup_download_scm",(void*)f_1276},
{"f_1297:setup_download_scm",(void*)f_1297},
{"f_1309:setup_download_scm",(void*)f_1309},
{"f_1315:setup_download_scm",(void*)f_1315},
{"f_1303:setup_download_scm",(void*)f_1303},
{"f_1282:setup_download_scm",(void*)f_1282},
{"f_1288:setup_download_scm",(void*)f_1288},
{"f_1292:setup_download_scm",(void*)f_1292},
{"f_1274:setup_download_scm",(void*)f_1274},
{"f_1271:setup_download_scm",(void*)f_1271},
{"f_1230:setup_download_scm",(void*)f_1230},
{"f_1099:setup_download_scm",(void*)f_1099},
{"f_1167:setup_download_scm",(void*)f_1167},
{"f_1162:setup_download_scm",(void*)f_1162},
{"f_1101:setup_download_scm",(void*)f_1101},
{"f_1105:setup_download_scm",(void*)f_1105},
{"f_1108:setup_download_scm",(void*)f_1108},
{"f_1148:setup_download_scm",(void*)f_1148},
{"f_1154:setup_download_scm",(void*)f_1154},
{"f_1161:setup_download_scm",(void*)f_1161},
{"f_1111:setup_download_scm",(void*)f_1111},
{"f_1124:setup_download_scm",(void*)f_1124},
{"f_1127:setup_download_scm",(void*)f_1127},
{"f_1142:setup_download_scm",(void*)f_1142},
{"f_1133:setup_download_scm",(void*)f_1133},
{"f_1121:setup_download_scm",(void*)f_1121},
{"f_1070:setup_download_scm",(void*)f_1070},
{"f_1043:setup_download_scm",(void*)f_1043},
{"f_1059:setup_download_scm",(void*)f_1059},
{"f_1028:setup_download_scm",(void*)f_1028},
{"f_1032:setup_download_scm",(void*)f_1032},
{"f_1038:setup_download_scm",(void*)f_1038},
{"f_1041:setup_download_scm",(void*)f_1041},
{"f_1006:setup_download_scm",(void*)f_1006},
{"f_1010:setup_download_scm",(void*)f_1010},
{"f_1013:setup_download_scm",(void*)f_1013},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
