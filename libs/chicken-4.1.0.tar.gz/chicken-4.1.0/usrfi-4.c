/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:35
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: srfi-4.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file usrfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_u8peek(b, i)         C_fix(((unsigned char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s8peek(b, i)         C_fix(((char *)C_data_pointer(b))[ C_unfix(i) ])
#define C_u16peek(b, i)        C_fix(((unsigned short *)C_data_pointer(b))[ C_unfix(i) ])
#define C_s16peek(b, i)        C_fix(((short *)C_data_pointer(b))[ C_unfix(i) ])
#ifdef C_SIXTY_FOUR
# define C_a_u32peek(ptr, d, b, i) C_fix(((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_fix(((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#else
# define C_a_u32peek(ptr, d, b, i) C_unsigned_int_to_num(ptr, ((C_u32 *)C_data_pointer(b))[ C_unfix(i) ])
# define C_a_s32peek(ptr, d, b, i) C_int_to_num(ptr, ((C_s32 *)C_data_pointer(b))[ C_unfix(i) ])
#endif
#define C_f32peek(b, i)        (C_temporary_flonum = ((float *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_f64peek(b, i)        (C_temporary_flonum = ((double *)C_data_pointer(b))[ C_unfix(i) ], C_SCHEME_UNDEFINED)
#define C_u8poke(b, i, x)      ((((unsigned char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s8poke(b, i, x)      ((((char *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u16poke(b, i, x)     ((((unsigned short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_s16poke(b, i, x)     ((((short *)C_data_pointer(b))[ C_unfix(i) ] = C_unfix(x)), C_SCHEME_UNDEFINED)
#define C_u32poke(b, i, x)     ((((C_u32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_unsigned_int(x)), C_SCHEME_UNDEFINED)
#define C_s32poke(b, i, x)     ((((C_s32 *)C_data_pointer(b))[ C_unfix(i) ] = C_num_to_int(x)), C_SCHEME_UNDEFINED)
#define C_f32poke(b, i, x)     ((((float *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_f64poke(b, i, x)     ((((double *)C_data_pointer(b))[ C_unfix(i) ] = C_flonum_magnitude(x)), C_SCHEME_UNDEFINED)
#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[174];
static double C_possibly_force_alignment;


/* from ext-free in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub272(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub272(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

/* from ext-alloc */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub265(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub265(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_ccall f_1688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4030)
static void C_ccall f_4030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4006)
static void C_ccall f_4006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3085)
static void C_ccall f_3085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3089)
static void C_ccall f_3089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3231)
static void C_ccall f_3231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3267)
static void C_ccall f_3267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3956)
static void C_fcall f_3956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3889)
static void C_fcall f_3889(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_fcall f_3925(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3929)
static void C_ccall f_3929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3938)
static void C_ccall f_3938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_fcall f_3878(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3832)
static void C_fcall f_3832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_fcall f_3827(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3782)
static void C_fcall f_3782(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3798)
static void C_fcall f_3798(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3667)
static void C_ccall f_3667r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3720)
static void C_fcall f_3720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_fcall f_3715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3706)
static void C_fcall f_3706(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3669)
static void C_fcall f_3669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3684)
static void C_fcall f_3684(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3576)
static void C_fcall f_3576(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_fcall f_3197(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_fcall f_3168(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3150)
static void C_fcall f_3150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3152)
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_fcall f_3139(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3141)
static void C_ccall f_3141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3121)
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3115)
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3109)
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3024)
static void C_fcall f_3024(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3035)
static void C_fcall f_3035(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3006)
static void C_ccall f_3006r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2906)
static void C_fcall f_2906(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2846)
static void C_fcall f_2846(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2836)
static void C_fcall f_2836(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2784)
static void C_fcall f_2784(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2806)
static void C_fcall f_2806(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2722)
static void C_fcall f_2722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_fcall f_2717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2712)
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2660)
static void C_fcall f_2660(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_fcall f_2682(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_fcall f_2687(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2598)
static void C_fcall f_2598(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_fcall f_2593(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2588)
static void C_fcall f_2588(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2543)
static void C_fcall f_2543(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static C_word C_fcall f_2567(C_word t0,C_word t1);
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2481)
static void C_fcall f_2481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_fcall f_2476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2471)
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2426)
static void C_fcall f_2426(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static C_word C_fcall f_2450(C_word t0,C_word t1);
C_noret_decl(f_2307)
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2307)
static void C_ccall f_2307r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2364)
static void C_fcall f_2364(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_fcall f_2359(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2354)
static void C_fcall f_2354(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2309)
static void C_fcall f_2309(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2190)
static void C_ccall f_2190r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2247)
static void C_fcall f_2247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_fcall f_2242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2237)
static void C_fcall f_2237(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2192)
static void C_fcall f_2192(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_fcall f_2216(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2130)
static void C_fcall f_2130(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_fcall f_2125(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2120)
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2075)
static void C_fcall f_2075(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_fcall f_2099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1956)
static void C_ccall f_1956r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2013)
static void C_fcall f_2013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_fcall f_2008(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2003)
static void C_fcall f_2003(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1958)
static void C_fcall f_1958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_fcall f_1982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1938)
static void C_fcall f_1938(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1913)
static void C_fcall f_1913(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_fcall f_1822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1834)
static void C_ccall f_1834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_fcall f_1733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1702)
static void C_fcall f_1702(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1659)
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1650)
static C_word C_fcall f_1650(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1647)
static C_word C_fcall f_1647(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1623)
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;

C_noret_decl(trf_3956)
static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3956(t0,t1);}

C_noret_decl(trf_3951)
static void C_fcall trf_3951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3951(t0,t1,t2);}

C_noret_decl(trf_3889)
static void C_fcall trf_3889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3889(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3889(t0,t1,t2,t3);}

C_noret_decl(trf_3925)
static void C_fcall trf_3925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3925(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3925(t0,t1);}

C_noret_decl(trf_3878)
static void C_fcall trf_3878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3878(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3878(t0,t1,t2);}

C_noret_decl(trf_3832)
static void C_fcall trf_3832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3832(t0,t1);}

C_noret_decl(trf_3827)
static void C_fcall trf_3827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3827(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3827(t0,t1,t2);}

C_noret_decl(trf_3782)
static void C_fcall trf_3782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3782(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3782(t0,t1,t2,t3);}

C_noret_decl(trf_3798)
static void C_fcall trf_3798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3798(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3798(t0,t1);}

C_noret_decl(trf_3720)
static void C_fcall trf_3720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3720(t0,t1);}

C_noret_decl(trf_3715)
static void C_fcall trf_3715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3715(t0,t1,t2);}

C_noret_decl(trf_3706)
static void C_fcall trf_3706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3706(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3706(t0,t1,t2,t3);}

C_noret_decl(trf_3669)
static void C_fcall trf_3669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3669(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3669(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3684)
static void C_fcall trf_3684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3684(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3684(t0,t1,t2);}

C_noret_decl(trf_3576)
static void C_fcall trf_3576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3576(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3576(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3197)
static void C_fcall trf_3197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3197(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3197(t0,t1,t2,t3);}

C_noret_decl(trf_3168)
static void C_fcall trf_3168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3168(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3168(t0,t1,t2,t3);}

C_noret_decl(trf_3150)
static void C_fcall trf_3150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3150(t0,t1,t2);}

C_noret_decl(trf_3139)
static void C_fcall trf_3139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3139(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3139(t0,t1,t2);}

C_noret_decl(trf_3024)
static void C_fcall trf_3024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3024(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3024(t0,t1,t2);}

C_noret_decl(trf_3035)
static void C_fcall trf_3035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3035(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3035(t0,t1,t2);}

C_noret_decl(trf_2906)
static void C_fcall trf_2906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2906(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2906(t0,t1,t2,t3);}

C_noret_decl(trf_2923)
static void C_fcall trf_2923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2923(t0,t1,t2,t3);}

C_noret_decl(trf_2846)
static void C_fcall trf_2846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2846(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2846(t0,t1);}

C_noret_decl(trf_2841)
static void C_fcall trf_2841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2841(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2841(t0,t1,t2);}

C_noret_decl(trf_2836)
static void C_fcall trf_2836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2836(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2836(t0,t1,t2,t3);}

C_noret_decl(trf_2784)
static void C_fcall trf_2784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2784(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2784(t0,t1,t2,t3);}

C_noret_decl(trf_2806)
static void C_fcall trf_2806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2806(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2806(t0,t1);}

C_noret_decl(trf_2811)
static void C_fcall trf_2811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2811(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2811(t0,t1,t2);}

C_noret_decl(trf_2722)
static void C_fcall trf_2722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2722(t0,t1);}

C_noret_decl(trf_2717)
static void C_fcall trf_2717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2717(t0,t1,t2);}

C_noret_decl(trf_2712)
static void C_fcall trf_2712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2712(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2712(t0,t1,t2,t3);}

C_noret_decl(trf_2660)
static void C_fcall trf_2660(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2660(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2660(t0,t1,t2,t3);}

C_noret_decl(trf_2682)
static void C_fcall trf_2682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2682(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2682(t0,t1);}

C_noret_decl(trf_2687)
static void C_fcall trf_2687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2687(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2687(t0,t1,t2);}

C_noret_decl(trf_2598)
static void C_fcall trf_2598(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2598(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2598(t0,t1);}

C_noret_decl(trf_2593)
static void C_fcall trf_2593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2593(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2593(t0,t1,t2);}

C_noret_decl(trf_2588)
static void C_fcall trf_2588(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2588(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2588(t0,t1,t2,t3);}

C_noret_decl(trf_2543)
static void C_fcall trf_2543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2543(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2543(t0,t1,t2,t3);}

C_noret_decl(trf_2481)
static void C_fcall trf_2481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2481(t0,t1);}

C_noret_decl(trf_2476)
static void C_fcall trf_2476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2476(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2476(t0,t1,t2);}

C_noret_decl(trf_2471)
static void C_fcall trf_2471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2471(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2471(t0,t1,t2,t3);}

C_noret_decl(trf_2426)
static void C_fcall trf_2426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2426(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2426(t0,t1,t2,t3);}

C_noret_decl(trf_2364)
static void C_fcall trf_2364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2364(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2364(t0,t1);}

C_noret_decl(trf_2359)
static void C_fcall trf_2359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2359(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2359(t0,t1,t2);}

C_noret_decl(trf_2354)
static void C_fcall trf_2354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2354(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2354(t0,t1,t2,t3);}

C_noret_decl(trf_2309)
static void C_fcall trf_2309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2309(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2309(t0,t1,t2,t3);}

C_noret_decl(trf_2333)
static void C_fcall trf_2333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2333(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2333(t0,t1,t2);}

C_noret_decl(trf_2247)
static void C_fcall trf_2247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2247(t0,t1);}

C_noret_decl(trf_2242)
static void C_fcall trf_2242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2242(t0,t1,t2);}

C_noret_decl(trf_2237)
static void C_fcall trf_2237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2237(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2237(t0,t1,t2,t3);}

C_noret_decl(trf_2192)
static void C_fcall trf_2192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2192(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2192(t0,t1,t2,t3);}

C_noret_decl(trf_2216)
static void C_fcall trf_2216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2216(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2216(t0,t1,t2);}

C_noret_decl(trf_2130)
static void C_fcall trf_2130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2130(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2130(t0,t1);}

C_noret_decl(trf_2125)
static void C_fcall trf_2125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2125(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2125(t0,t1,t2);}

C_noret_decl(trf_2120)
static void C_fcall trf_2120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2120(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2120(t0,t1,t2,t3);}

C_noret_decl(trf_2075)
static void C_fcall trf_2075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2075(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2075(t0,t1,t2,t3);}

C_noret_decl(trf_2099)
static void C_fcall trf_2099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2099(t0,t1,t2);}

C_noret_decl(trf_2013)
static void C_fcall trf_2013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2013(t0,t1);}

C_noret_decl(trf_2008)
static void C_fcall trf_2008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2008(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2008(t0,t1,t2);}

C_noret_decl(trf_2003)
static void C_fcall trf_2003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2003(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2003(t0,t1,t2,t3);}

C_noret_decl(trf_1958)
static void C_fcall trf_1958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1958(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1958(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1982)
static void C_fcall trf_1982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1982(t0,t1,t2);}

C_noret_decl(trf_1938)
static void C_fcall trf_1938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1938(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1938(t0,t1);}

C_noret_decl(trf_1913)
static void C_fcall trf_1913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1913(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1913(t0,t1,t2,t3);}

C_noret_decl(trf_1822)
static void C_fcall trf_1822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1822(t0,t1,t2,t3);}

C_noret_decl(trf_1733)
static void C_fcall trf_1733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1733(t0,t1,t2,t3);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1716(t0,t1,t2,t3);}

C_noret_decl(trf_1702)
static void C_fcall trf_1702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1702(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1702(t0,t1,t2,t3);}

C_noret_decl(trf_1659)
static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1659(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(42);
if(!C_demand(42)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1554)){
C_save(t1);
C_rereclaim2(1554*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(42);
C_initialize_lf(lf,174);
lf[0]=C_h_intern(&lf[0],24,"\003syscheck-exact-interval");
lf[1]=C_h_intern(&lf[1],9,"\003syserror");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[3]=C_h_intern(&lf[3],26,"\003syscheck-inexact-interval");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[12]=C_h_intern(&lf[12],15,"\003syscons-flonum");
lf[22]=C_h_intern(&lf[22],15,"u8vector-length");
lf[23]=C_h_intern(&lf[23],15,"s8vector-length");
lf[24]=C_h_intern(&lf[24],16,"u16vector-length");
lf[25]=C_h_intern(&lf[25],16,"s16vector-length");
lf[26]=C_h_intern(&lf[26],16,"u32vector-length");
lf[27]=C_h_intern(&lf[27],16,"s32vector-length");
lf[28]=C_h_intern(&lf[28],16,"f32vector-length");
lf[29]=C_h_intern(&lf[29],16,"f64vector-length");
lf[30]=C_h_intern(&lf[30],15,"\003syscheck-range");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[32]=C_h_intern(&lf[32],13,"u8vector-set!");
lf[33]=C_h_intern(&lf[33],13,"s8vector-set!");
lf[34]=C_h_intern(&lf[34],14,"u16vector-set!");
lf[35]=C_h_intern(&lf[35],14,"s16vector-set!");
lf[36]=C_h_intern(&lf[36],14,"u32vector-set!");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[39]=C_h_intern(&lf[39],14,"s32vector-set!");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[41]=C_h_intern(&lf[41],14,"f32vector-set!");
lf[42]=C_h_intern(&lf[42],14,"f64vector-set!");
lf[43]=C_h_intern(&lf[43],12,"u8vector-ref");
lf[44]=C_h_intern(&lf[44],12,"s8vector-ref");
lf[45]=C_h_intern(&lf[45],13,"u16vector-ref");
lf[46]=C_h_intern(&lf[46],13,"s16vector-ref");
lf[47]=C_h_intern(&lf[47],13,"u32vector-ref");
lf[48]=C_h_intern(&lf[48],13,"s32vector-ref");
lf[49]=C_h_intern(&lf[49],13,"f32vector-ref");
lf[50]=C_h_intern(&lf[50],13,"f64vector-ref");
lf[51]=C_h_intern(&lf[51],14,"set-finalizer!");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[53]=C_h_intern(&lf[53],19,"\003sysallocate-vector");
lf[54]=C_h_intern(&lf[54],21,"release-number-vector");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[57]=C_h_intern(&lf[57],13,"make-u8vector");
lf[58]=C_h_intern(&lf[58],8,"u8vector");
lf[59]=C_h_intern(&lf[59],13,"make-s8vector");
lf[60]=C_h_intern(&lf[60],8,"s8vector");
lf[61]=C_h_intern(&lf[61],4,"fin\077");
lf[62]=C_h_intern(&lf[62],14,"make-u16vector");
lf[63]=C_h_intern(&lf[63],9,"u16vector");
lf[64]=C_h_intern(&lf[64],14,"make-s16vector");
lf[65]=C_h_intern(&lf[65],9,"s16vector");
lf[66]=C_h_intern(&lf[66],14,"make-u32vector");
lf[67]=C_h_intern(&lf[67],9,"u32vector");
lf[68]=C_h_intern(&lf[68],14,"make-s32vector");
lf[69]=C_h_intern(&lf[69],9,"s32vector");
lf[70]=C_h_intern(&lf[70],14,"make-f32vector");
lf[71]=C_h_intern(&lf[71],9,"f32vector");
lf[72]=C_h_intern(&lf[72],14,"make-f64vector");
lf[73]=C_h_intern(&lf[73],9,"f64vector");
lf[74]=C_h_intern(&lf[74],27,"\003syserror-not-a-proper-list");
lf[75]=C_h_intern(&lf[75],14,"list->u8vector");
lf[76]=C_h_intern(&lf[76],14,"list->s8vector");
lf[77]=C_h_intern(&lf[77],15,"list->u16vector");
lf[78]=C_h_intern(&lf[78],15,"list->s16vector");
lf[79]=C_h_intern(&lf[79],15,"list->u32vector");
lf[80]=C_h_intern(&lf[80],15,"list->s32vector");
lf[81]=C_h_intern(&lf[81],15,"list->f32vector");
lf[82]=C_h_intern(&lf[82],15,"list->f64vector");
lf[83]=C_h_intern(&lf[83],14,"u8vector->list");
lf[84]=C_h_intern(&lf[84],14,"s8vector->list");
lf[85]=C_h_intern(&lf[85],15,"u16vector->list");
lf[86]=C_h_intern(&lf[86],15,"s16vector->list");
lf[87]=C_h_intern(&lf[87],15,"u32vector->list");
lf[88]=C_h_intern(&lf[88],15,"s32vector->list");
lf[89]=C_h_intern(&lf[89],15,"f32vector->list");
lf[90]=C_h_intern(&lf[90],15,"f64vector->list");
lf[91]=C_h_intern(&lf[91],9,"u8vector\077");
lf[92]=C_h_intern(&lf[92],9,"s8vector\077");
lf[93]=C_h_intern(&lf[93],10,"u16vector\077");
lf[94]=C_h_intern(&lf[94],10,"s16vector\077");
lf[95]=C_h_intern(&lf[95],10,"u32vector\077");
lf[96]=C_h_intern(&lf[96],10,"s32vector\077");
lf[97]=C_h_intern(&lf[97],10,"f32vector\077");
lf[98]=C_h_intern(&lf[98],10,"f64vector\077");
lf[99]=C_h_intern(&lf[99],13,"\003sysmake-blob");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[102]=C_h_intern(&lf[102],21,"u8vector->blob/shared");
lf[103]=C_h_intern(&lf[103],21,"s8vector->blob/shared");
lf[104]=C_h_intern(&lf[104],22,"u16vector->blob/shared");
lf[105]=C_h_intern(&lf[105],22,"s16vector->blob/shared");
lf[106]=C_h_intern(&lf[106],22,"u32vector->blob/shared");
lf[107]=C_h_intern(&lf[107],22,"s32vector->blob/shared");
lf[108]=C_h_intern(&lf[108],22,"f32vector->blob/shared");
lf[109]=C_h_intern(&lf[109],22,"f64vector->blob/shared");
lf[110]=C_h_intern(&lf[110],14,"u8vector->blob");
lf[111]=C_h_intern(&lf[111],14,"s8vector->blob");
lf[112]=C_h_intern(&lf[112],15,"u16vector->blob");
lf[113]=C_h_intern(&lf[113],15,"s16vector->blob");
lf[114]=C_h_intern(&lf[114],15,"u32vector->blob");
lf[115]=C_h_intern(&lf[115],15,"s32vector->blob");
lf[116]=C_h_intern(&lf[116],15,"f32vector->blob");
lf[117]=C_h_intern(&lf[117],15,"f64vector->blob");
lf[118]=C_h_intern(&lf[118],21,"blob->u8vector/shared");
lf[119]=C_h_intern(&lf[119],21,"blob->s8vector/shared");
lf[120]=C_h_intern(&lf[120],22,"blob->u16vector/shared");
lf[121]=C_h_intern(&lf[121],22,"blob->s16vector/shared");
lf[122]=C_h_intern(&lf[122],22,"blob->u32vector/shared");
lf[123]=C_h_intern(&lf[123],22,"blob->s32vector/shared");
lf[124]=C_h_intern(&lf[124],22,"blob->f32vector/shared");
lf[125]=C_h_intern(&lf[125],22,"blob->f64vector/shared");
lf[126]=C_h_intern(&lf[126],14,"blob->u8vector");
lf[127]=C_h_intern(&lf[127],14,"blob->s8vector");
lf[128]=C_h_intern(&lf[128],15,"blob->u16vector");
lf[129]=C_h_intern(&lf[129],15,"blob->s16vector");
lf[130]=C_h_intern(&lf[130],15,"blob->u32vector");
lf[131]=C_h_intern(&lf[131],15,"blob->s32vector");
lf[132]=C_h_intern(&lf[132],15,"blob->f32vector");
lf[133]=C_h_intern(&lf[133],15,"blob->f64vector");
lf[134]=C_h_intern(&lf[134],18,"\003sysuser-read-hook");
lf[135]=C_h_intern(&lf[135],4,"read");
lf[136]=C_h_intern(&lf[136],2,"u8");
lf[137]=C_h_intern(&lf[137],2,"s8");
lf[138]=C_h_intern(&lf[138],3,"u16");
lf[139]=C_h_intern(&lf[139],3,"s16");
lf[140]=C_h_intern(&lf[140],3,"u32");
lf[141]=C_h_intern(&lf[141],3,"s32");
lf[142]=C_h_intern(&lf[142],3,"f32");
lf[143]=C_h_intern(&lf[143],3,"f64");
lf[144]=C_h_intern(&lf[144],1,"f");
lf[145]=C_h_intern(&lf[145],1,"F");
lf[146]=C_h_intern(&lf[146],14,"\003sysread-error");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[148]=C_h_intern(&lf[148],19,"\003sysuser-print-hook");
lf[149]=C_h_intern(&lf[149],9,"\003sysprint");
lf[151]=C_h_intern(&lf[151],11,"subu8vector");
lf[152]=C_h_intern(&lf[152],12,"subu16vector");
lf[153]=C_h_intern(&lf[153],12,"subu32vector");
lf[154]=C_h_intern(&lf[154],11,"subs8vector");
lf[155]=C_h_intern(&lf[155],12,"subs16vector");
lf[156]=C_h_intern(&lf[156],12,"subs32vector");
lf[157]=C_h_intern(&lf[157],12,"subf32vector");
lf[158]=C_h_intern(&lf[158],12,"subf64vector");
lf[159]=C_h_intern(&lf[159],14,"write-u8vector");
lf[160]=C_h_intern(&lf[160],16,"\003syswrite-char-0");
lf[161]=C_h_intern(&lf[161],14,"\003syscheck-port");
lf[162]=C_h_intern(&lf[162],19,"\003sysstandard-output");
lf[163]=C_h_intern(&lf[163],14,"read-u8vector!");
lf[164]=C_h_intern(&lf[164],16,"\003sysread-string!");
lf[165]=C_h_intern(&lf[165],18,"\003sysstandard-input");
lf[166]=C_h_intern(&lf[166],18,"open-output-string");
lf[167]=C_h_intern(&lf[167],17,"get-output-string");
lf[168]=C_h_intern(&lf[168],13,"read-u8vector");
lf[169]=C_h_intern(&lf[169],19,"\003syswrite-char/port");
lf[170]=C_h_intern(&lf[170],15,"\003sysread-char-0");
lf[171]=C_h_intern(&lf[171],17,"register-feature!");
lf[172]=C_h_intern(&lf[172],6,"srfi-4");
lf[173]=C_h_intern(&lf[173],18,"getter-with-setter");
C_register_lf2(lf,174,create_ptable());
t2=C_mutate((C_word*)lf[0]+1 /* (set! check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1569,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! check-inexact-interval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1584,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[5] /* (set! u8vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1605,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[6] /* (set! s8vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1608,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[7] /* (set! u16vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1611,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[8] /* (set! s16vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1614,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[9] /* (set! u32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1617,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[10] /* (set! s32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1620,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[11] /* (set! f32vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1623,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[13] /* (set! f64vector-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1629,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[14] /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1635,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[15] /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1638,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[16] /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1641,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[17] /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1644,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[18] /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1647,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[19] /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1650,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[20] /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1653,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[21] /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1656,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1659,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t20,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 140  len */
f_1659(t21,lf[58],C_SCHEME_FALSE,lf[22]);}

/* k1670 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! u8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 141  len */
f_1659(t3,lf[60],C_SCHEME_FALSE,lf[23]);}

/* k1674 in k1670 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! s8vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 142  len */
f_1659(t3,lf[63],C_fix(1),lf[24]);}

/* k1678 in k1674 in k1670 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1680,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! u16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 143  len */
f_1659(t3,lf[65],C_fix(1),lf[25]);}

/* k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! s16vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 144  len */
f_1659(t3,lf[67],C_fix(2),lf[26]);}

/* k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1688,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! u32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 145  len */
f_1659(t3,lf[69],C_fix(2),lf[27]);}

/* k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! s32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 146  len */
f_1659(t3,lf[71],C_fix(2),lf[28]);}

/* k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1696,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! f32vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 147  len */
f_1659(t3,lf[73],C_fix(3),lf[29]);}

/* k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! f64vector-length ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1702,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1716,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1733,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1822,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1848,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 203  setu */
f_1733(t7,*((C_word*)lf[22]+1),lf[14],lf[32]);}

/* k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! u8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 204  set */
f_1716(t3,*((C_word*)lf[23]+1),lf[15],lf[33]);}

/* k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=C_mutate((C_word*)lf[33]+1 /* (set! s8vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 205  setu */
f_1733(t3,*((C_word*)lf[24]+1),lf[16],lf[34]);}

/* k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1 /* (set! u16vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 206  set */
f_1716(t3,*((C_word*)lf[25]+1),lf[17],lf[35]);}

/* k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! s16vector-set! ...) */,t1);
t3=*((C_word*)lf[26]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_mutate((C_word*)lf[36]+1 /* (set! u32vector-set! ...) */,t4);
t6=*((C_word*)lf[27]+1);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1761,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_mutate((C_word*)lf[39]+1 /* (set! s32vector-set! ...) */,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 209  setf */
f_1822(t9,*((C_word*)lf[28]+1),lf[20],lf[41]);}

/* k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1 /* (set! f32vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1876,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 210  setf */
f_1822(t3,*((C_word*)lf[29]+1),lf[21],lf[42]);}

/* k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! f64vector-set! ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 213  get */
f_1702(t4,*((C_word*)lf[22]+1),lf[5],lf[43]);}

/* k4032 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 213  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[32]+1));}

/* k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4030,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 216  get */
f_1702(t4,*((C_word*)lf[23]+1),lf[6],lf[44]);}

/* k4028 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 216  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[33]+1));}

/* k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=C_mutate((C_word*)lf[44]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4026,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 219  get */
f_1702(t4,*((C_word*)lf[24]+1),lf[7],lf[45]);}

/* k4024 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 219  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[34]+1));}

/* k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4022,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 222  get */
f_1702(t4,*((C_word*)lf[25]+1),lf[8],lf[46]);}

/* k4020 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 222  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[35]+1));}

/* k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=C_mutate((C_word*)lf[46]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4018,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 226  get */
f_1702(t4,*((C_word*)lf[26]+1),lf[9],lf[47]);}

/* k4016 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 225  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=C_mutate((C_word*)lf[47]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4014,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 230  get */
f_1702(t4,*((C_word*)lf[27]+1),lf[10],lf[48]);}

/* k4012 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 229  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[39]+1));}

/* k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4010,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 234  get */
f_1702(t4,*((C_word*)lf[28]+1),lf[11],lf[49]);}

/* k4008 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 233  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[41]+1));}

/* k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1904,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4006,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 238  get */
f_1702(t4,*((C_word*)lf[29]+1),lf[13],lf[50]);}

/* k4004 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 237  getter-with-setter */
t2=*((C_word*)lf[173]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[42]+1));}

/* k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=C_mutate((C_word*)lf[50]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1911,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[51]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1913,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[54]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1931,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[57]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1956,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[59]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2073,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[62]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2190,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[64]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2307,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[66]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2424,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[68]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2541,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t13=C_mutate((C_word*)lf[70]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2658,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[72]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2782,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2906,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2946,a[2]=t15,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 397  init */
f_2906(t16,*((C_word*)lf[57]+1),*((C_word*)lf[32]+1),lf[75]);}

/* k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2946,2,t0,t1);}
t2=C_mutate((C_word*)lf[75]+1 /* (set! list->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 398  init */
f_2906(t3,*((C_word*)lf[59]+1),*((C_word*)lf[33]+1),lf[76]);}

/* k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=C_mutate((C_word*)lf[76]+1 /* (set! list->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 399  init */
f_2906(t3,*((C_word*)lf[62]+1),*((C_word*)lf[34]+1),lf[77]);}

/* k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=C_mutate((C_word*)lf[77]+1 /* (set! list->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 400  init */
f_2906(t3,*((C_word*)lf[64]+1),*((C_word*)lf[35]+1),lf[78]);}

/* k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2958,2,t0,t1);}
t2=C_mutate((C_word*)lf[78]+1 /* (set! list->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 401  init */
f_2906(t3,*((C_word*)lf[66]+1),*((C_word*)lf[36]+1),lf[79]);}

/* k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! list->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 402  init */
f_2906(t3,*((C_word*)lf[68]+1),*((C_word*)lf[39]+1),lf[80]);}

/* k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=C_mutate((C_word*)lf[80]+1 /* (set! list->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 403  init */
f_2906(t3,*((C_word*)lf[70]+1),*((C_word*)lf[41]+1),lf[81]);}

/* k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2970,2,t0,t1);}
t2=C_mutate((C_word*)lf[81]+1 /* (set! list->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 404  init */
f_2906(t3,*((C_word*)lf[72]+1),*((C_word*)lf[42]+1),lf[82]);}

/* k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=C_mutate((C_word*)lf[82]+1 /* (set! list->f64vector ...) */,t1);
t3=*((C_word*)lf[75]+1);
t4=C_mutate((C_word*)lf[58]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[76]+1);
t6=C_mutate((C_word*)lf[60]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[77]+1);
t8=C_mutate((C_word*)lf[63]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[78]+1);
t10=C_mutate((C_word*)lf[65]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[79]+1);
t12=C_mutate((C_word*)lf[67]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=*((C_word*)lf[80]+1);
t14=C_mutate((C_word*)lf[69]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3006,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=*((C_word*)lf[81]+1);
t16=C_mutate((C_word*)lf[71]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3012,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[82]+1);
t18=C_mutate((C_word*)lf[73]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3018,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3024,tmp=(C_word)a,a+=2,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3061,a[2]=t19,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 455  init */
f_3024(t20,*((C_word*)lf[22]+1),lf[5]);}

/* k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3061,2,t0,t1);}
t2=C_mutate((C_word*)lf[83]+1 /* (set! u8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 456  init */
f_3024(t3,*((C_word*)lf[23]+1),lf[6]);}

/* k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=C_mutate((C_word*)lf[84]+1 /* (set! s8vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 457  init */
f_3024(t3,*((C_word*)lf[24]+1),lf[7]);}

/* k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
t2=C_mutate((C_word*)lf[85]+1 /* (set! u16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 458  init */
f_3024(t3,*((C_word*)lf[25]+1),lf[8]);}

/* k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
t2=C_mutate((C_word*)lf[86]+1 /* (set! s16vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 459  init */
f_3024(t3,*((C_word*)lf[26]+1),lf[9]);}

/* k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
t2=C_mutate((C_word*)lf[87]+1 /* (set! u32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 460  init */
f_3024(t3,*((C_word*)lf[27]+1),lf[10]);}

/* k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=C_mutate((C_word*)lf[88]+1 /* (set! s32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 461  init */
f_3024(t3,*((C_word*)lf[28]+1),lf[11]);}

/* k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3085,2,t0,t1);}
t2=C_mutate((C_word*)lf[89]+1 /* (set! f32vector->list ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3089,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 462  init */
f_3024(t3,*((C_word*)lf[29]+1),lf[13]);}

/* k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3089,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! f64vector->list ...) */,t1);
t3=C_mutate((C_word*)lf[91]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3091,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[92]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3097,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[93]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3103,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[94]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3109,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[95]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3115,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[96]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3121,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[97]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3127,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[98]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3133,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3139,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3150,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3168,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3197,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3231,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t14,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 514  pack */
f_3139(t15,lf[58],lf[102]);}

/* k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3231,2,t0,t1);}
t2=C_mutate((C_word*)lf[102]+1 /* (set! u8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 515  pack */
f_3139(t3,lf[60],lf[103]);}

/* k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=C_mutate((C_word*)lf[103]+1 /* (set! s8vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 516  pack */
f_3139(t3,lf[63],lf[104]);}

/* k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1 /* (set! u16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 517  pack */
f_3139(t3,lf[65],lf[105]);}

/* k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1 /* (set! s16vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 518  pack */
f_3139(t3,lf[67],lf[106]);}

/* k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3247,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1 /* (set! u32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 519  pack */
f_3139(t3,lf[69],lf[107]);}

/* k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1 /* (set! s32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 520  pack */
f_3139(t3,lf[71],lf[108]);}

/* k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1 /* (set! f32vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 521  pack */
f_3139(t3,lf[73],lf[109]);}

/* k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3259,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1 /* (set! f64vector->blob/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 523  pack-copy */
f_3150(t3,lf[58],lf[110]);}

/* k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 524  pack-copy */
f_3150(t3,lf[60],lf[111]);}

/* k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3267,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 525  pack-copy */
f_3150(t3,lf[63],lf[112]);}

/* k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 526  pack-copy */
f_3150(t3,lf[65],lf[113]);}

/* k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3275,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 527  pack-copy */
f_3150(t3,lf[67],lf[114]);}

/* k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3279,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 528  pack-copy */
f_3150(t3,lf[69],lf[115]);}

/* k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 529  pack-copy */
f_3150(t3,lf[71],lf[116]);}

/* k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 530  pack-copy */
f_3150(t3,lf[73],lf[117]);}

/* k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 532  unpack */
f_3168(t3,lf[58],C_SCHEME_TRUE,lf[118]);}

/* k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 533  unpack */
f_3168(t3,lf[60],C_SCHEME_TRUE,lf[119]);}

/* k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3299,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 534  unpack */
f_3168(t3,lf[63],C_fix(2),lf[120]);}

/* k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3303,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 535  unpack */
f_3168(t3,lf[65],C_fix(2),lf[121]);}

/* k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 536  unpack */
f_3168(t3,lf[67],C_fix(4),lf[122]);}

/* k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3311,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 537  unpack */
f_3168(t3,lf[69],C_fix(4),lf[123]);}

/* k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=C_mutate((C_word*)lf[123]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 538  unpack */
f_3168(t3,lf[71],C_fix(4),lf[124]);}

/* k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3319,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 539  unpack */
f_3168(t3,lf[73],C_fix(8),lf[125]);}

/* k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3323,2,t0,t1);}
t2=C_mutate((C_word*)lf[125]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 541  unpack-copy */
f_3197(t3,lf[58],C_SCHEME_TRUE,lf[126]);}

/* k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 542  unpack-copy */
f_3197(t3,lf[60],C_SCHEME_TRUE,lf[127]);}

/* k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=C_mutate((C_word*)lf[127]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 543  unpack-copy */
f_3197(t3,lf[63],C_fix(2),lf[128]);}

/* k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3339,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 544  unpack-copy */
f_3197(t3,lf[65],C_fix(2),lf[129]);}

/* k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=C_mutate((C_word*)lf[129]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 545  unpack-copy */
f_3197(t3,lf[67],C_fix(4),lf[130]);}

/* k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3343,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 546  unpack-copy */
f_3197(t3,lf[69],C_fix(4),lf[131]);}

/* k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=C_mutate((C_word*)lf[131]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 547  unpack-copy */
f_3197(t3,lf[71],C_fix(4),lf[132]);}

/* k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=C_mutate((C_word*)lf[132]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3355,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 548  unpack-copy */
f_3197(t3,lf[73],C_fix(8),lf[133]);}

/* k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[88],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=C_mutate((C_word*)lf[133]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[134]+1);
t4=*((C_word*)lf[135]+1);
t5=(C_word)C_a_i_list(&a,16,lf[136],*((C_word*)lf[75]+1),lf[137],*((C_word*)lf[76]+1),lf[138],*((C_word*)lf[77]+1),lf[139],*((C_word*)lf[78]+1),lf[140],*((C_word*)lf[79]+1),lf[141],*((C_word*)lf[80]+1),lf[142],*((C_word*)lf[81]+1),lf[143],*((C_word*)lf[82]+1));
t6=C_mutate((C_word*)lf[134]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3360,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[148]+1);
t8=C_mutate((C_word*)lf[148]+1 /* (set! user-print-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[150] /* (set! subvector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3576,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[151]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3619,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[152]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3625,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[153]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3631,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[154]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3637,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[155]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3643,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[156]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3649,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[157]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3655,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[158]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3661,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[159]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3667,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[163]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3780,tmp=(C_word)a,a+=2,tmp));
t20=*((C_word*)lf[166]+1);
t21=*((C_word*)lf[167]+1);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3878,tmp=(C_word)a,a+=2,tmp);
t23=C_mutate((C_word*)lf[168]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3887,a[2]=t20,a[3]=t21,a[4]=t22,tmp=(C_word)a,a+=5,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 670  register-feature! */
t25=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,lf[172]);}

/* k4000 in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr2r,(void*)f_3887r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3887r(t0,t1,t2);}}

static void C_ccall f_3887r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3951,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3956,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-n14481496 */
t6=t5;
f_3956(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-p14491492 */
t8=t4;
f_3951(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body14461455 */
t10=t3;
f_3889(t10,t1,t6,t8);}}}

/* def-n1448 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,2,t0,t1);}
/* def-p14491492 */
t2=((C_word*)t0)[2];
f_3951(t2,t1,C_SCHEME_FALSE);}

/* def-p1449 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3951,NULL,3,t0,t1,t2);}
/* body14461455 */
t3=((C_word*)t0)[2];
f_3889(t3,t1,t2,*((C_word*)lf[165]+1));}

/* body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3889(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3889,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 650  ##sys#check-port */
t5=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,lf[168]);}

/* k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],lf[168]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 652  ##sys#allocate-vector */
t4=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[7],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 659  open-output-string */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3918 in k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3920,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3925(t5,((C_word*)t0)[2]);}

/* loop in k3918 in k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3925(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3925,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 661  ##sys#read-char-0 */
t3=*((C_word*)lf[170]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3927 in loop in k3918 in k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3929,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3938,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 663  get-output-string */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 667  ##sys#write-char/port */
t3=*((C_word*)lf[169]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}

/* k3945 in k3927 in loop in k3918 in k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 668  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3925(t2,((C_word*)t0)[2]);}

/* k3936 in k3927 in loop in k3918 in k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(t1);
/* srfi-4.scm: 665  wrap */
f_3878(((C_word*)t0)[2],t1,t2);}

/* k3900 in k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 653  ##sys#read-string! */
t3=*((C_word*)lf[164]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k3903 in k3900 in k3891 in body1446 in read-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3905,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[58],((C_word*)t0)[5]));}
else{
/* srfi-4.scm: 657  wrap */
f_3878(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3878(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3878,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3886,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 645  ##sys#allocate-vector */
t5=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3884 in wrap in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,lf[58],t1));}

/* read-u8vector! in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr4r,(void*)f_3780r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3780r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3780r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3782,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3827,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3832,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-port13821409 */
t9=t8;
f_3832(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-start13831405 */
t11=t7;
f_3827(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
/* body13801389 */
t13=t6;
f_3782(t13,t1,t9,t11);}}}

/* def-port1382 in read-u8vector! in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3832,NULL,2,t0,t1);}
/* def-start13831405 */
t2=((C_word*)t0)[2];
f_3827(t2,t1,*((C_word*)lf[165]+1));}

/* def-start1383 in read-u8vector! in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3827(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3827,NULL,3,t0,t1,t2);}
/* body13801389 */
t3=((C_word*)t0)[2];
f_3782(t3,t1,t2,C_fix(0));}

/* body1380 in read-u8vector! in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3782(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3782,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3786,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 629  ##sys#check-port */
t5=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[163]);}

/* k3784 in body1380 in read-u8vector! in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[6],lf[163]);
t3=(C_word)C_i_check_structure_2(((C_word*)t0)[5],lf[58],lf[163]);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3798,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t6=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[3])[1],lf[163]);
t7=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1]);
t8=(C_word)C_block_size(t4);
if(C_truep((C_word)C_fixnum_greaterp(t7,t8))){
t9=(C_word)C_block_size(t4);
t10=(C_word)C_u_fixnum_difference(t9,((C_word*)t0)[6]);
t11=C_mutate(((C_word *)((C_word*)t0)[3])+1,t10);
t12=t5;
f_3798(t12,t11);}
else{
t9=t5;
f_3798(t9,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_3798(t6,C_SCHEME_UNDEFINED);}}

/* k3796 in k3784 in body1380 in read-u8vector! in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3798(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 637  ##sys#read-string! */
t2=*((C_word*)lf[164]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3667(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3667r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3667r(t0,t1,t2,t3);}}

static void C_ccall f_3667r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3669,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3706,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3715,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3720,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-port13091348 */
t8=t7;
f_3720(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-from13101344 */
t10=t6;
f_3715(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-to13111339 */
t12=t5;
f_3706(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body13071317 */
t14=t4;
f_3669(t14,t1,t8,t10,t12);}}}}

/* def-port1309 in write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3720,NULL,2,t0,t1);}
/* def-from13101344 */
t2=((C_word*)t0)[2];
f_3715(t2,t1,*((C_word*)lf[162]+1));}

/* def-from1310 in write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3715,NULL,3,t0,t1,t2);}
/* def-to13111339 */
t3=((C_word*)t0)[2];
f_3706(t3,t1,t2,C_fix(0));}

/* def-to1311 in write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3706(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3706,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_8vector_length(((C_word*)t0)[3]);
/* body13071317 */
t5=((C_word*)t0)[2];
f_3669(t5,t1,t2,t3,t4);}

/* body1307 in write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3669(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3669,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_structure_2(((C_word*)t0)[2],lf[58],lf[159]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3676,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 622  ##sys#check-port */
t7=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,lf[159]);}

/* k3674 in body1307 in write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3676,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3684(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop1323 in k3674 in body1307 in write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3684(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3684,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3694,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_make_character((C_word)C_unfix((C_word)C_u8peek(((C_word*)t0)[3],t2)));
/* srfi-4.scm: 626  ##sys#write-char-0 */
t5=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* k3692 in doloop1323 in k3674 in body1307 in write-u8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3684(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3661,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 618  subvector */
f_3576(t1,t2,lf[73],C_fix(8),t3,t4,lf[158]);}

/* subf32vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3655,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 617  subvector */
f_3576(t1,t2,lf[71],C_fix(4),t3,t4,lf[157]);}

/* subs32vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3649,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 616  subvector */
f_3576(t1,t2,lf[69],C_fix(4),t3,t4,lf[156]);}

/* subs16vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3643,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 615  subvector */
f_3576(t1,t2,lf[65],C_fix(2),t3,t4,lf[155]);}

/* subs8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3637,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 614  subvector */
f_3576(t1,t2,lf[60],C_fix(1),t3,t4,lf[154]);}

/* subu32vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3631,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 613  subvector */
f_3576(t1,t2,lf[67],C_fix(4),t3,t4,lf[153]);}

/* subu16vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3625,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 612  subvector */
f_3576(t1,t2,lf[63],C_fix(2),t3,t4,lf[152]);}

/* subu8vector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3619,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm: 611  subvector */
f_3576(t1,t2,lf[58],C_fix(1),t3,t4,lf[151]);}

/* subvector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3576(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3576,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(C_word)C_i_check_structure_2(t2,t3,t7);
t9=(C_word)C_slot(t2,C_fix(1));
t10=(C_word)C_block_size(t9);
t11=(C_word)C_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3589,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=(C_word)C_u_fixnum_plus(t11,C_fix(1));
/* srfi-4.scm: 602  ##sys#check-range */
t14=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t12,t5,C_fix(0),t13,t7);}

/* k3587 in subvector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 603  ##sys#check-range */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[9],C_fix(0),t3,((C_word*)t0)[2]);}

/* k3590 in k3587 in subvector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 605  ##sys#allocate-vector */
t5=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3596 in k3590 in k3587 in subvector in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(C_word)C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=(C_word)C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=(C_word)C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[102],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3416,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[83]+1),C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,lf[136],t5);
t7=(C_word)C_a_i_cons(&a,2,lf[58],t6);
t8=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[84]+1),C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,lf[137],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[60],t9);
t11=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[85]+1),C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,lf[138],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[63],t12);
t14=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[86]+1),C_SCHEME_END_OF_LIST);
t15=(C_word)C_a_i_cons(&a,2,lf[139],t14);
t16=(C_word)C_a_i_cons(&a,2,lf[65],t15);
t17=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[87]+1),C_SCHEME_END_OF_LIST);
t18=(C_word)C_a_i_cons(&a,2,lf[140],t17);
t19=(C_word)C_a_i_cons(&a,2,lf[67],t18);
t20=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[88]+1),C_SCHEME_END_OF_LIST);
t21=(C_word)C_a_i_cons(&a,2,lf[141],t20);
t22=(C_word)C_a_i_cons(&a,2,lf[69],t21);
t23=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[89]+1),C_SCHEME_END_OF_LIST);
t24=(C_word)C_a_i_cons(&a,2,lf[142],t23);
t25=(C_word)C_a_i_cons(&a,2,lf[71],t24);
t26=(C_word)C_a_i_cons(&a,2,*((C_word*)lf[90]+1),C_SCHEME_END_OF_LIST);
t27=(C_word)C_a_i_cons(&a,2,lf[143],t26);
t28=(C_word)C_a_i_cons(&a,2,lf[73],t27);
t29=(C_word)C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=(C_word)C_a_i_cons(&a,2,t25,t29);
t31=(C_word)C_a_i_cons(&a,2,t22,t30);
t32=(C_word)C_a_i_cons(&a,2,t19,t31);
t33=(C_word)C_a_i_cons(&a,2,t16,t32);
t34=(C_word)C_a_i_cons(&a,2,t13,t33);
t35=(C_word)C_a_i_cons(&a,2,t10,t34);
t36=(C_word)C_a_i_cons(&a,2,t7,t35);
t37=(C_word)C_u_i_assq((C_word)C_slot(t2,C_fix(0)),t36);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3426,a[2]=t2,a[3]=t37,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 589  ##sys#print */
t39=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t39+1)))(5,t39,t38,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm: 592  old-hook */
t38=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t38+1)))(5,t38,t1,t2,t3,t4);}}

/* k3424 in ##sys#user-print-hook in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
/* srfi-4.scm: 590  ##sys#print */
t4=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[4]);}

/* k3427 in k3424 in ##sys#user-print-hook in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,((C_word*)t0)[2]);}

/* k3434 in k3427 in k3424 in ##sys#user-print-hook in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 591  ##sys#print */
t2=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3360,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep((C_word)C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3370,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 566  read */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* srfi-4.scm: 571  old-hook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k3368 in ##sys#user-read-hook in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(C_word)C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=(C_word)C_eqp(t3,lf[144]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,lf[145]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_u_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 569  read */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 570  ##sys#read-error */
t7=*((C_word*)lf[146]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[5],((C_word*)t0)[2],lf[147],t3);}}}

/* k3393 in k3368 in ##sys#user-read-hook in k3353 in k3349 in k3345 in k3341 in k3337 in k3333 in k3329 in k3325 in k3321 in k3317 in k3313 in k3309 in k3305 in k3301 in k3297 in k3293 in k3289 in k3285 in k3281 in k3277 in k3273 in k3269 in k3265 in k3261 in k3257 in k3253 in k3249 in k3245 in k3241 in k3237 in k3233 in k3229 in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t1);}

/* unpack-copy in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3197(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3197,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3199,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_3199 in unpack-copy in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3199,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 506  ##sys#make-blob */
t6=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k3207 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,2,((C_word*)t0)[4],(C_word)C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm: 512  ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[101],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3168(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3168,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3170,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_3170 in unpack in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3170,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_block_size(t2);
t5=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:(C_word)C_eqp(C_fix(0),(C_word)C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm: 500  ##sys#error */
t7=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[100],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3150(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3150,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3152 in pack-copy in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3152(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3152,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3162,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_block_size(t4);
/* srfi-4.scm: 490  ##sys#make-blob */
t7=*((C_word*)lf[99]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k3160 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_copy_block(((C_word*)t0)[2],t1));}

/* pack in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3139(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3139,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3141,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3141 in pack in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3141,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* f64vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3133,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[73]));}

/* f32vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3127,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[71]));}

/* s32vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3121,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[69]));}

/* u32vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3115,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[67]));}

/* s16vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3109,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[65]));}

/* u16vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3103,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[63]));}

/* s8vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3097,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[60]));}

/* u8vector? in k3087 in k3083 in k3079 in k3075 in k3071 in k3067 in k3063 in k3059 in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3091,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[58]));}

/* init in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_3024(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3024,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3026,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp));}

/* f_3026 in init in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3026,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3030,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 448  length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3028 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3035,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3035(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3028 */
static void C_fcall f_3035(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3035,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 452  ref */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],t2);}}

/* k3047 in loop in k3028 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3053,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-4.scm: 453  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3035(t4,t2,t3);}

/* k3051 in k3047 in loop in k3028 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* f64vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3018r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3018r(t0,t1,t2);}}

static void C_ccall f_3018r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 439  list->f64vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f32vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3012r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3012r(t0,t1,t2);}}

static void C_ccall f_3012r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 435  list->f32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s32vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3006(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3006r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3006r(t0,t1,t2);}}

static void C_ccall f_3006r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 431  list->s32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u32vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3000r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3000r(t0,t1,t2);}}

static void C_ccall f_3000r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 427  list->u32vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s16vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2994r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2994r(t0,t1,t2);}}

static void C_ccall f_2994r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 423  list->s16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u16vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2988r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2988r(t0,t1,t2);}}

static void C_ccall f_2988r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 419  list->u16vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s8vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2982r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2982r(t0,t1,t2);}}

static void C_ccall f_2982r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 415  list->s8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u8vector in k2972 in k2968 in k2964 in k2960 in k2956 in k2952 in k2948 in k2944 in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2976r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2976r(t0,t1,t2);}}

static void C_ccall f_2976r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm: 411  list->u8vector */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* init in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2906(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2906,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2908,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_2908 in init in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2908,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[4]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2918,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 389  make */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k2916 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2923(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop938 in k2916 */
static void C_fcall f_2923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2923,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2930,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep((C_word)C_blockp(t2))?(C_word)C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* srfi-4.scm: 394  set */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[5],t3,(C_word)C_slot(t2,C_fix(0)));}
else{
/* srfi-4.scm: 395  ##sys#error-not-a-proper-list */
t6=*((C_word*)lf[74]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}}

/* k2928 in doloop938 in k2916 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2923(t2,((C_word*)t0)[4],(C_word)C_slot(((C_word*)t0)[3],C_fix(1)),(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2782r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2782r(t0,t1,t2,t3);}}

static void C_ccall f_2782r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2836,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2841,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init856903 */
t8=t7;
f_2846(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?857899 */
t10=t6;
f_2841(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin858894 */
t12=t5;
f_2836(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body854864 */
t14=t4;
f_2784(t14,t1,t8,t10);}}}}

/* def-init856 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2846(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2846,NULL,2,t0,t1);}
/* def-ext?857899 */
t2=((C_word*)t0)[2];
f_2841(t2,t1,C_SCHEME_FALSE);}

/* def-ext?857 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2841,NULL,3,t0,t1,t2);}
/* def-fin858894 */
t3=((C_word*)t0)[2];
f_2836(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin858 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2836(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2836,NULL,4,t0,t1,t2,t3);}
/* body854864 */
t4=((C_word*)t0)[2];
f_2784(t4,t1,t2,t3);}

/* body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2784(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2784,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[72]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 368  alloc */
f_1913(t6,lf[72],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(3)),t3);}

/* k2833 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 369  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2794(2,t5,C_SCHEME_UNDEFINED);}}

/* k2792 in k2833 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[72]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2806,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2806(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 375  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2823 in k2792 in k2833 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2806(t3,t2);}

/* k2804 in k2792 in k2833 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2806(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2806,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2811(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop877 in k2804 in k2792 in k2833 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2811,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2818,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 378  ##sys#f64vector-set! */
t4=lf[21];
f_1656(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k2816 in doloop877 in k2804 in k2792 in k2833 in body854 in make-f64vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2811(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2658r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2658r(t0,t1,t2,t3);}}

static void C_ccall f_2658r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2717,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init777824 */
t8=t7;
f_2722(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?778820 */
t10=t6;
f_2717(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin779815 */
t12=t5;
f_2712(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body775785 */
t14=t4;
f_2660(t14,t1,t8,t10);}}}}

/* def-init777 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2722,NULL,2,t0,t1);}
/* def-ext?778820 */
t2=((C_word*)t0)[2];
f_2717(t2,t1,C_SCHEME_FALSE);}

/* def-ext?778 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2717,NULL,3,t0,t1,t2);}
/* def-fin779815 */
t3=((C_word*)t0)[2];
f_2712(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin779 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2712(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2712,NULL,4,t0,t1,t2,t3);}
/* body775785 */
t4=((C_word*)t0)[2];
f_2660(t4,t1,t2,t3);}

/* body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2660(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2660,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[70]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 353  alloc */
f_1913(t6,lf[70],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2709 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[71],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 354  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2670(2,t5,C_SCHEME_UNDEFINED);}}

/* k2668 in k2709 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[70]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2682(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm: 360  exact->inexact */
C_exact_to_inexact(3,0,t5,((C_word*)((C_word*)t0)[5])[1]);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2699 in k2668 in k2709 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2682(t3,t2);}

/* k2680 in k2668 in k2709 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2682(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2682,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2687(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop798 in k2680 in k2668 in k2709 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2687(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2687,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2694,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 363  ##sys#f32vector-set! */
t4=lf[20];
f_1653(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)((C_word*)t0)[2])[1]);}}

/* k2692 in doloop798 in k2680 in k2668 in k2709 in body775 in make-f32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2687(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2541r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2541r(t0,t1,t2,t3);}}

static void C_ccall f_2541r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2588,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2593,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2598,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init701745 */
t8=t7;
f_2598(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?702741 */
t10=t6;
f_2593(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin703736 */
t12=t5;
f_2588(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body699709 */
t14=t4;
f_2543(t14,t1,t8,t10);}}}}

/* def-init701 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2598(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2598,NULL,2,t0,t1);}
/* def-ext?702741 */
t2=((C_word*)t0)[2];
f_2593(t2,t1,C_SCHEME_FALSE);}

/* def-ext?702 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2593(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2593,NULL,3,t0,t1,t2);}
/* def-fin703736 */
t3=((C_word*)t0)[2];
f_2588(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin703 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2588(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2588,NULL,4,t0,t1,t2,t3);}
/* body699709 */
t4=((C_word*)t0)[2];
f_2543(t4,t1,t2,t3);}

/* body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2543(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2543,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 340  alloc */
f_1913(t5,lf[68],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2585 in body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[69],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 341  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2553(2,t5,C_SCHEME_UNDEFINED);}}

/* k2551 in k2585 in body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[68]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2567(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop720 in k2551 in k2585 in body699 in make-s32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static C_word C_fcall f_2567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_1650(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2424r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2424r(t0,t1,t2,t3);}}

static void C_ccall f_2424r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2471,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2476,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2481,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init625669 */
t8=t7;
f_2481(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?626665 */
t10=t6;
f_2476(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin627660 */
t12=t5;
f_2471(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body623633 */
t14=t4;
f_2426(t14,t1,t8,t10);}}}}

/* def-init625 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2481,NULL,2,t0,t1);}
/* def-ext?626665 */
t2=((C_word*)t0)[2];
f_2476(t2,t1,C_SCHEME_FALSE);}

/* def-ext?626 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2476,NULL,3,t0,t1,t2);}
/* def-fin627660 */
t3=((C_word*)t0)[2];
f_2471(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin627 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2471,NULL,4,t0,t1,t2,t3);}
/* body623633 */
t4=((C_word*)t0)[2];
f_2426(t4,t1,t2,t3);}

/* body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2426(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2426,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 327  alloc */
f_1913(t5,lf[66],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(2)),t3);}

/* k2468 in body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[67],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 328  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2436(2,t5,C_SCHEME_UNDEFINED);}}

/* k2434 in k2468 in body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[66]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2450(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop644 in k2434 in k2468 in body623 in make-u32vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static C_word C_fcall f_2450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=f_1647(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2307(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2307r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2307r(t0,t1,t2,t3);}}

static void C_ccall f_2307r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init549593 */
t8=t7;
f_2364(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?550589 */
t10=t6;
f_2359(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin551584 */
t12=t5;
f_2354(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body547557 */
t14=t4;
f_2309(t14,t1,t8,t10);}}}}

/* def-init549 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2364(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2364,NULL,2,t0,t1);}
/* def-ext?550589 */
t2=((C_word*)t0)[2];
f_2359(t2,t1,C_SCHEME_FALSE);}

/* def-ext?550 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2359(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2359,NULL,3,t0,t1,t2);}
/* def-fin551584 */
t3=((C_word*)t0)[2];
f_2354(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin551 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2354(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2354,NULL,4,t0,t1,t2,t3);}
/* body547557 */
t4=((C_word*)t0)[2];
f_2309(t4,t1,t2,t3);}

/* body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2309(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2309,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[64]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 314  alloc */
f_1913(t5,lf[64],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k2351 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[65],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 315  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2319(2,t5,C_SCHEME_UNDEFINED);}}

/* k2317 in k2351 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2319,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 319  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[64]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2326 in k2317 in k2351 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2333(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop568 in k2326 in k2317 in k2351 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2333,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 322  ##sys#s16vector-set! */
t4=lf[17];
f_1644(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k2338 in doloop568 in k2326 in k2317 in k2351 in body547 in make-s16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2333(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2190(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2190r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2190r(t0,t1,t2,t3);}}

static void C_ccall f_2190r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2242,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2247,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init473517 */
t8=t7;
f_2247(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?474513 */
t10=t6;
f_2242(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin475508 */
t12=t5;
f_2237(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body471481 */
t14=t4;
f_2192(t14,t1,t8,t10);}}}}

/* def-init473 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2247,NULL,2,t0,t1);}
/* def-ext?474513 */
t2=((C_word*)t0)[2];
f_2242(t2,t1,C_SCHEME_FALSE);}

/* def-ext?474 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2242,NULL,3,t0,t1,t2);}
/* def-fin475508 */
t3=((C_word*)t0)[2];
f_2237(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin475 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2237(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2237,NULL,4,t0,t1,t2,t3);}
/* body471481 */
t4=((C_word*)t0)[2];
f_2192(t4,t1,t2,t3);}

/* body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2192(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2192,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[62]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 301  alloc */
f_1913(t5,lf[62],(C_word)C_fixnum_shift_left(((C_word*)t0)[5],C_fix(1)),t3);}

/* k2234 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[63],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 302  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2202(2,t5,C_SCHEME_UNDEFINED);}}

/* k2200 in k2234 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2202,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 306  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[62]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2209 in k2200 in k2234 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2216(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop492 in k2209 in k2200 in k2234 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2216(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2216,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2223,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 309  ##sys#u16vector-set! */
t4=lf[16];
f_1641(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k2221 in doloop492 in k2209 in k2200 in k2234 in body471 in make-u16vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2216(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_2073r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2073r(t0,t1,t2,t3);}}

static void C_ccall f_2073r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2125,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init397441 */
t8=t7;
f_2130(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?398437 */
t10=t6;
f_2125(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin399432 */
t12=t5;
f_2120(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body395405 */
t14=t4;
f_2075(t14,t1,t8,t10);}}}}

/* def-init397 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2130(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2130,NULL,2,t0,t1);}
/* def-ext?398437 */
t2=((C_word*)t0)[2];
f_2125(t2,t1,C_SCHEME_FALSE);}

/* def-ext?398 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2125(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2125,NULL,3,t0,t1,t2);}
/* def-fin399432 */
t3=((C_word*)t0)[2];
f_2120(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin399 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2120(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2120,NULL,4,t0,t1,t2,t3);}
/* body395405 */
t4=((C_word*)t0)[2];
f_2075(t4,t1,t2,t3);}

/* body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2075(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2075,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[59]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 288  alloc */
f_1913(t5,lf[59],((C_word*)t0)[5],t3);}

/* k2117 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[60],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[4])?*((C_word*)lf[61]+1):C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 289  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2085(2,t5,C_SCHEME_UNDEFINED);}}

/* k2083 in k2117 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 293  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[59]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2092 in k2083 in k2117 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2099(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop416 in k2092 in k2083 in k2117 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2099(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2099,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2106,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 296  ##sys#s8vector-set! */
t4=lf[15];
f_1638(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k2104 in doloop416 in k2092 in k2083 in k2117 in body395 in make-s8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_2099(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1956(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_1956r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1956r(t0,t1,t2,t3);}}

static void C_ccall f_1956r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2003,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2008,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-init320364 */
t8=t7;
f_2013(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-ext?321360 */
t10=t6;
f_2008(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-fin?322355 */
t12=t5;
f_2003(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body318328 */
t14=t4;
f_1958(t14,t1,t8,t10,t12);}}}}

/* def-init320 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2013,NULL,2,t0,t1);}
/* def-ext?321360 */
t2=((C_word*)t0)[2];
f_2008(t2,t1,C_SCHEME_FALSE);}

/* def-ext?321 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2008(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2008,NULL,3,t0,t1,t2);}
/* def-fin?322355 */
t3=((C_word*)t0)[2];
f_2003(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?322 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_2003(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2003,NULL,4,t0,t1,t2,t3);}
/* body318328 */
t4=((C_word*)t0)[2];
f_1958(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1958(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1958,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_exact_2(((C_word*)t0)[5],lf[57]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* srfi-4.scm: 275  alloc */
f_1913(t6,lf[57],((C_word*)t0)[5],t3);}

/* k2000 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,2,lf[58],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t4)){
/* srfi-4.scm: 276  set-finalizer! */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1968(2,t5,C_SCHEME_UNDEFINED);}}

/* k1966 in k2000 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 280  ##sys#check-exact-interval */
t4=*((C_word*)lf[0]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[57]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1975 in k1966 in k2000 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1982(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop339 in k1975 in k1966 in k2000 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1982,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1989,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm: 283  ##sys#u8vector-set! */
t4=lf[14];
f_1635(5,t4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[2]);}}

/* k1987 in doloop339 in k1975 in k1966 in k2000 in body318 in make-u8vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1982(t2,((C_word*)t0)[3],(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* release-number-vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1931,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1938,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1938(t5,(C_word)C_u_i_memq(t4,lf[56]));}
else{
t4=t3;
f_1938(t4,C_SCHEME_FALSE);}}

/* k1936 in release-number-vector in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1938(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-4.scm: 269  ext-free */
t2=((C_word*)t0)[4];
f_1911(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 270  ##sys#error */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[54],lf[55],((C_word*)t0)[2]);}}

/* alloc in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1913(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1913,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=(C_word)stub265(C_SCHEME_UNDEFINED,t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* srfi-4.scm: 260  ##sys#error */
t7=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[52],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm: 261  ##sys#allocate-vector */
t6=*((C_word*)lf[53]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1927 in alloc in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_string_to_bytevector(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* ext-free in k1906 in k1902 in k1898 in k1894 in k1890 in k1886 in k1882 in k1878 in k1874 in k1870 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1911,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub272(C_SCHEME_UNDEFINED,t2));}

/* f_1761 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1761,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1765,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 178  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1763 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1768,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fits_in_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1768(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 180  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[39],lf[40],((C_word*)t0)[2]);}}

/* k1766 in k1763 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 181  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[39]);}

/* k1769 in k1766 in k1763 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 182  upd */
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_1650(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f_1788 in k1858 in k1854 in k1850 in k1846 in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1788,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 186  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1790 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1795,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_negativep(((C_word*)t0)[2]))){
/* srfi-4.scm: 188  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[36],lf[37],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_fits_in_unsigned_int_p(((C_word*)t0)[2]))){
t3=t2;
f_1795(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm: 190  ##sys#error */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[36],lf[38],((C_word*)t0)[2]);}}}

/* k1793 in k1790 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 191  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],C_fix(0),((C_word*)t0)[2],lf[36]);}

/* k1796 in k1793 in k1790 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 192  upd */
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_1647(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* setf in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1822(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1822,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1824,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1824 in setf in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1824,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1828,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 196  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1826 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1834,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 198  ##sys#check-range */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1832 in k1826 */
static void C_ccall f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_blockp(((C_word*)t0)[2]))){
t3=t2;
f_1841(2,t3,((C_word*)t0)[2]);}
else{
/* srfi-4.scm: 201  exact->inexact */
C_exact_to_inexact(3,0,t2,((C_word*)t0)[2]);}}

/* k1839 in k1832 in k1826 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 199  upd */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setu in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1733(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1733,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1735,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1735 in setu in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1735,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1739,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 169  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1737 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[7],C_fix(0)))){
/* srfi-4.scm: 172  ##sys#error */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],lf[31],((C_word*)t0)[7]);}
else{
t4=t3;
f_1745(2,t4,C_SCHEME_UNDEFINED);}}

/* k1743 in k1737 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 173  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1746 in k1743 in k1737 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 174  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1716(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1718,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp));}

/* f_1718 in set in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1718,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1722,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm: 162  length */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1720 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1722,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1728,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 164  ##sys#check-range */
t4=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],C_fix(0),t1,((C_word*)t0)[6]);}

/* k1726 in k1720 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 165  upd */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* get in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_fcall f_1702(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1702,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1704,a[2]=t2,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp));}

/* f_1704 in get in k1698 in k1694 in k1690 in k1686 in k1682 in k1678 in k1674 in k1670 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1704,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1708,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm: 156  length */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1706 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm: 157  ##sys#check-range */
t3=*((C_word*)lf[30]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),t1,((C_word*)t0)[2]);}

/* k1709 in k1706 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm: 158  acc */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* len */
static void C_fcall f_1659(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1659,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1661,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp));}

/* f_1661 in len */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1661,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=(C_word)C_block_size((C_word)C_slot(t2,C_fix(1)));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_shift_right(t4,((C_word*)t0)[2]):t4));}

/* ##sys#f64vector-set! */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1656,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f64poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f32vector-set! */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1653,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_f32poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s32vector-set! */
static C_word C_fcall f_1650(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)C_s32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#u32vector-set! */
static C_word C_fcall f_1647(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)C_u32poke((C_word)C_slot(t1,C_fix(1)),t2,t3));}

/* ##sys#s16vector-set! */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1644,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u16vector-set! */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1641,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u16poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#s8vector-set! */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1638,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_s8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#u8vector-set! */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1635,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_u8poke((C_word)C_slot(t2,C_fix(1)),t3,t4));}

/* ##sys#f64vector-ref */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1629,4,t0,t1,t2,t3);}
t4=(C_word)C_f64peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 116  ##sys#cons-flonum */
t5=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#f32vector-ref */
static void C_ccall f_1623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1623,4,t0,t1,t2,t3);}
t4=(C_word)C_f32peek((C_word)C_slot(t2,C_fix(1)),t3);
/* srfi-4.scm: 112  ##sys#cons-flonum */
t5=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}

/* ##sys#s32vector-ref */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1620,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_s32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u32vector-ref */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1617,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_u32peek(&a,2,(C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s16vector-ref */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1614,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u16vector-ref */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1611,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u16peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#s8vector-ref */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1608,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_s8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#u8vector-ref */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1605,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_u8peek((C_word)C_slot(t2,C_fix(1)),t3));}

/* ##sys#check-inexact-interval */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1584,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_number_2(t2,t5);
t7=(C_word)C_i_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_i_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 98   ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[4],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* ##sys#check-exact-interval */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1569,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
t7=(C_word)C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm: 92   ##sys#error */
t9=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[2],t2,t3,t4);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[294] = {
{"toplevel:srfi_4_scm",(void*)C_srfi_4_toplevel},
{"f_1672:srfi_4_scm",(void*)f_1672},
{"f_1676:srfi_4_scm",(void*)f_1676},
{"f_1680:srfi_4_scm",(void*)f_1680},
{"f_1684:srfi_4_scm",(void*)f_1684},
{"f_1688:srfi_4_scm",(void*)f_1688},
{"f_1692:srfi_4_scm",(void*)f_1692},
{"f_1696:srfi_4_scm",(void*)f_1696},
{"f_1700:srfi_4_scm",(void*)f_1700},
{"f_1848:srfi_4_scm",(void*)f_1848},
{"f_1852:srfi_4_scm",(void*)f_1852},
{"f_1856:srfi_4_scm",(void*)f_1856},
{"f_1860:srfi_4_scm",(void*)f_1860},
{"f_1872:srfi_4_scm",(void*)f_1872},
{"f_1876:srfi_4_scm",(void*)f_1876},
{"f_4034:srfi_4_scm",(void*)f_4034},
{"f_1880:srfi_4_scm",(void*)f_1880},
{"f_4030:srfi_4_scm",(void*)f_4030},
{"f_1884:srfi_4_scm",(void*)f_1884},
{"f_4026:srfi_4_scm",(void*)f_4026},
{"f_1888:srfi_4_scm",(void*)f_1888},
{"f_4022:srfi_4_scm",(void*)f_4022},
{"f_1892:srfi_4_scm",(void*)f_1892},
{"f_4018:srfi_4_scm",(void*)f_4018},
{"f_1896:srfi_4_scm",(void*)f_1896},
{"f_4014:srfi_4_scm",(void*)f_4014},
{"f_1900:srfi_4_scm",(void*)f_1900},
{"f_4010:srfi_4_scm",(void*)f_4010},
{"f_1904:srfi_4_scm",(void*)f_1904},
{"f_4006:srfi_4_scm",(void*)f_4006},
{"f_1908:srfi_4_scm",(void*)f_1908},
{"f_2946:srfi_4_scm",(void*)f_2946},
{"f_2950:srfi_4_scm",(void*)f_2950},
{"f_2954:srfi_4_scm",(void*)f_2954},
{"f_2958:srfi_4_scm",(void*)f_2958},
{"f_2962:srfi_4_scm",(void*)f_2962},
{"f_2966:srfi_4_scm",(void*)f_2966},
{"f_2970:srfi_4_scm",(void*)f_2970},
{"f_2974:srfi_4_scm",(void*)f_2974},
{"f_3061:srfi_4_scm",(void*)f_3061},
{"f_3065:srfi_4_scm",(void*)f_3065},
{"f_3069:srfi_4_scm",(void*)f_3069},
{"f_3073:srfi_4_scm",(void*)f_3073},
{"f_3077:srfi_4_scm",(void*)f_3077},
{"f_3081:srfi_4_scm",(void*)f_3081},
{"f_3085:srfi_4_scm",(void*)f_3085},
{"f_3089:srfi_4_scm",(void*)f_3089},
{"f_3231:srfi_4_scm",(void*)f_3231},
{"f_3235:srfi_4_scm",(void*)f_3235},
{"f_3239:srfi_4_scm",(void*)f_3239},
{"f_3243:srfi_4_scm",(void*)f_3243},
{"f_3247:srfi_4_scm",(void*)f_3247},
{"f_3251:srfi_4_scm",(void*)f_3251},
{"f_3255:srfi_4_scm",(void*)f_3255},
{"f_3259:srfi_4_scm",(void*)f_3259},
{"f_3263:srfi_4_scm",(void*)f_3263},
{"f_3267:srfi_4_scm",(void*)f_3267},
{"f_3271:srfi_4_scm",(void*)f_3271},
{"f_3275:srfi_4_scm",(void*)f_3275},
{"f_3279:srfi_4_scm",(void*)f_3279},
{"f_3283:srfi_4_scm",(void*)f_3283},
{"f_3287:srfi_4_scm",(void*)f_3287},
{"f_3291:srfi_4_scm",(void*)f_3291},
{"f_3295:srfi_4_scm",(void*)f_3295},
{"f_3299:srfi_4_scm",(void*)f_3299},
{"f_3303:srfi_4_scm",(void*)f_3303},
{"f_3307:srfi_4_scm",(void*)f_3307},
{"f_3311:srfi_4_scm",(void*)f_3311},
{"f_3315:srfi_4_scm",(void*)f_3315},
{"f_3319:srfi_4_scm",(void*)f_3319},
{"f_3323:srfi_4_scm",(void*)f_3323},
{"f_3327:srfi_4_scm",(void*)f_3327},
{"f_3331:srfi_4_scm",(void*)f_3331},
{"f_3335:srfi_4_scm",(void*)f_3335},
{"f_3339:srfi_4_scm",(void*)f_3339},
{"f_3343:srfi_4_scm",(void*)f_3343},
{"f_3347:srfi_4_scm",(void*)f_3347},
{"f_3351:srfi_4_scm",(void*)f_3351},
{"f_3355:srfi_4_scm",(void*)f_3355},
{"f_4002:srfi_4_scm",(void*)f_4002},
{"f_3887:srfi_4_scm",(void*)f_3887},
{"f_3956:srfi_4_scm",(void*)f_3956},
{"f_3951:srfi_4_scm",(void*)f_3951},
{"f_3889:srfi_4_scm",(void*)f_3889},
{"f_3893:srfi_4_scm",(void*)f_3893},
{"f_3920:srfi_4_scm",(void*)f_3920},
{"f_3925:srfi_4_scm",(void*)f_3925},
{"f_3929:srfi_4_scm",(void*)f_3929},
{"f_3947:srfi_4_scm",(void*)f_3947},
{"f_3938:srfi_4_scm",(void*)f_3938},
{"f_3902:srfi_4_scm",(void*)f_3902},
{"f_3905:srfi_4_scm",(void*)f_3905},
{"f_3878:srfi_4_scm",(void*)f_3878},
{"f_3886:srfi_4_scm",(void*)f_3886},
{"f_3780:srfi_4_scm",(void*)f_3780},
{"f_3832:srfi_4_scm",(void*)f_3832},
{"f_3827:srfi_4_scm",(void*)f_3827},
{"f_3782:srfi_4_scm",(void*)f_3782},
{"f_3786:srfi_4_scm",(void*)f_3786},
{"f_3798:srfi_4_scm",(void*)f_3798},
{"f_3667:srfi_4_scm",(void*)f_3667},
{"f_3720:srfi_4_scm",(void*)f_3720},
{"f_3715:srfi_4_scm",(void*)f_3715},
{"f_3706:srfi_4_scm",(void*)f_3706},
{"f_3669:srfi_4_scm",(void*)f_3669},
{"f_3676:srfi_4_scm",(void*)f_3676},
{"f_3684:srfi_4_scm",(void*)f_3684},
{"f_3694:srfi_4_scm",(void*)f_3694},
{"f_3661:srfi_4_scm",(void*)f_3661},
{"f_3655:srfi_4_scm",(void*)f_3655},
{"f_3649:srfi_4_scm",(void*)f_3649},
{"f_3643:srfi_4_scm",(void*)f_3643},
{"f_3637:srfi_4_scm",(void*)f_3637},
{"f_3631:srfi_4_scm",(void*)f_3631},
{"f_3625:srfi_4_scm",(void*)f_3625},
{"f_3619:srfi_4_scm",(void*)f_3619},
{"f_3576:srfi_4_scm",(void*)f_3576},
{"f_3589:srfi_4_scm",(void*)f_3589},
{"f_3592:srfi_4_scm",(void*)f_3592},
{"f_3598:srfi_4_scm",(void*)f_3598},
{"f_3416:srfi_4_scm",(void*)f_3416},
{"f_3426:srfi_4_scm",(void*)f_3426},
{"f_3429:srfi_4_scm",(void*)f_3429},
{"f_3436:srfi_4_scm",(void*)f_3436},
{"f_3360:srfi_4_scm",(void*)f_3360},
{"f_3370:srfi_4_scm",(void*)f_3370},
{"f_3395:srfi_4_scm",(void*)f_3395},
{"f_3197:srfi_4_scm",(void*)f_3197},
{"f_3199:srfi_4_scm",(void*)f_3199},
{"f_3209:srfi_4_scm",(void*)f_3209},
{"f_3168:srfi_4_scm",(void*)f_3168},
{"f_3170:srfi_4_scm",(void*)f_3170},
{"f_3150:srfi_4_scm",(void*)f_3150},
{"f_3152:srfi_4_scm",(void*)f_3152},
{"f_3162:srfi_4_scm",(void*)f_3162},
{"f_3139:srfi_4_scm",(void*)f_3139},
{"f_3141:srfi_4_scm",(void*)f_3141},
{"f_3133:srfi_4_scm",(void*)f_3133},
{"f_3127:srfi_4_scm",(void*)f_3127},
{"f_3121:srfi_4_scm",(void*)f_3121},
{"f_3115:srfi_4_scm",(void*)f_3115},
{"f_3109:srfi_4_scm",(void*)f_3109},
{"f_3103:srfi_4_scm",(void*)f_3103},
{"f_3097:srfi_4_scm",(void*)f_3097},
{"f_3091:srfi_4_scm",(void*)f_3091},
{"f_3024:srfi_4_scm",(void*)f_3024},
{"f_3026:srfi_4_scm",(void*)f_3026},
{"f_3030:srfi_4_scm",(void*)f_3030},
{"f_3035:srfi_4_scm",(void*)f_3035},
{"f_3049:srfi_4_scm",(void*)f_3049},
{"f_3053:srfi_4_scm",(void*)f_3053},
{"f_3018:srfi_4_scm",(void*)f_3018},
{"f_3012:srfi_4_scm",(void*)f_3012},
{"f_3006:srfi_4_scm",(void*)f_3006},
{"f_3000:srfi_4_scm",(void*)f_3000},
{"f_2994:srfi_4_scm",(void*)f_2994},
{"f_2988:srfi_4_scm",(void*)f_2988},
{"f_2982:srfi_4_scm",(void*)f_2982},
{"f_2976:srfi_4_scm",(void*)f_2976},
{"f_2906:srfi_4_scm",(void*)f_2906},
{"f_2908:srfi_4_scm",(void*)f_2908},
{"f_2918:srfi_4_scm",(void*)f_2918},
{"f_2923:srfi_4_scm",(void*)f_2923},
{"f_2930:srfi_4_scm",(void*)f_2930},
{"f_2782:srfi_4_scm",(void*)f_2782},
{"f_2846:srfi_4_scm",(void*)f_2846},
{"f_2841:srfi_4_scm",(void*)f_2841},
{"f_2836:srfi_4_scm",(void*)f_2836},
{"f_2784:srfi_4_scm",(void*)f_2784},
{"f_2835:srfi_4_scm",(void*)f_2835},
{"f_2794:srfi_4_scm",(void*)f_2794},
{"f_2825:srfi_4_scm",(void*)f_2825},
{"f_2806:srfi_4_scm",(void*)f_2806},
{"f_2811:srfi_4_scm",(void*)f_2811},
{"f_2818:srfi_4_scm",(void*)f_2818},
{"f_2658:srfi_4_scm",(void*)f_2658},
{"f_2722:srfi_4_scm",(void*)f_2722},
{"f_2717:srfi_4_scm",(void*)f_2717},
{"f_2712:srfi_4_scm",(void*)f_2712},
{"f_2660:srfi_4_scm",(void*)f_2660},
{"f_2711:srfi_4_scm",(void*)f_2711},
{"f_2670:srfi_4_scm",(void*)f_2670},
{"f_2701:srfi_4_scm",(void*)f_2701},
{"f_2682:srfi_4_scm",(void*)f_2682},
{"f_2687:srfi_4_scm",(void*)f_2687},
{"f_2694:srfi_4_scm",(void*)f_2694},
{"f_2541:srfi_4_scm",(void*)f_2541},
{"f_2598:srfi_4_scm",(void*)f_2598},
{"f_2593:srfi_4_scm",(void*)f_2593},
{"f_2588:srfi_4_scm",(void*)f_2588},
{"f_2543:srfi_4_scm",(void*)f_2543},
{"f_2587:srfi_4_scm",(void*)f_2587},
{"f_2553:srfi_4_scm",(void*)f_2553},
{"f_2567:srfi_4_scm",(void*)f_2567},
{"f_2424:srfi_4_scm",(void*)f_2424},
{"f_2481:srfi_4_scm",(void*)f_2481},
{"f_2476:srfi_4_scm",(void*)f_2476},
{"f_2471:srfi_4_scm",(void*)f_2471},
{"f_2426:srfi_4_scm",(void*)f_2426},
{"f_2470:srfi_4_scm",(void*)f_2470},
{"f_2436:srfi_4_scm",(void*)f_2436},
{"f_2450:srfi_4_scm",(void*)f_2450},
{"f_2307:srfi_4_scm",(void*)f_2307},
{"f_2364:srfi_4_scm",(void*)f_2364},
{"f_2359:srfi_4_scm",(void*)f_2359},
{"f_2354:srfi_4_scm",(void*)f_2354},
{"f_2309:srfi_4_scm",(void*)f_2309},
{"f_2353:srfi_4_scm",(void*)f_2353},
{"f_2319:srfi_4_scm",(void*)f_2319},
{"f_2328:srfi_4_scm",(void*)f_2328},
{"f_2333:srfi_4_scm",(void*)f_2333},
{"f_2340:srfi_4_scm",(void*)f_2340},
{"f_2190:srfi_4_scm",(void*)f_2190},
{"f_2247:srfi_4_scm",(void*)f_2247},
{"f_2242:srfi_4_scm",(void*)f_2242},
{"f_2237:srfi_4_scm",(void*)f_2237},
{"f_2192:srfi_4_scm",(void*)f_2192},
{"f_2236:srfi_4_scm",(void*)f_2236},
{"f_2202:srfi_4_scm",(void*)f_2202},
{"f_2211:srfi_4_scm",(void*)f_2211},
{"f_2216:srfi_4_scm",(void*)f_2216},
{"f_2223:srfi_4_scm",(void*)f_2223},
{"f_2073:srfi_4_scm",(void*)f_2073},
{"f_2130:srfi_4_scm",(void*)f_2130},
{"f_2125:srfi_4_scm",(void*)f_2125},
{"f_2120:srfi_4_scm",(void*)f_2120},
{"f_2075:srfi_4_scm",(void*)f_2075},
{"f_2119:srfi_4_scm",(void*)f_2119},
{"f_2085:srfi_4_scm",(void*)f_2085},
{"f_2094:srfi_4_scm",(void*)f_2094},
{"f_2099:srfi_4_scm",(void*)f_2099},
{"f_2106:srfi_4_scm",(void*)f_2106},
{"f_1956:srfi_4_scm",(void*)f_1956},
{"f_2013:srfi_4_scm",(void*)f_2013},
{"f_2008:srfi_4_scm",(void*)f_2008},
{"f_2003:srfi_4_scm",(void*)f_2003},
{"f_1958:srfi_4_scm",(void*)f_1958},
{"f_2002:srfi_4_scm",(void*)f_2002},
{"f_1968:srfi_4_scm",(void*)f_1968},
{"f_1977:srfi_4_scm",(void*)f_1977},
{"f_1982:srfi_4_scm",(void*)f_1982},
{"f_1989:srfi_4_scm",(void*)f_1989},
{"f_1931:srfi_4_scm",(void*)f_1931},
{"f_1938:srfi_4_scm",(void*)f_1938},
{"f_1913:srfi_4_scm",(void*)f_1913},
{"f_1929:srfi_4_scm",(void*)f_1929},
{"f_1911:srfi_4_scm",(void*)f_1911},
{"f_1761:srfi_4_scm",(void*)f_1761},
{"f_1765:srfi_4_scm",(void*)f_1765},
{"f_1768:srfi_4_scm",(void*)f_1768},
{"f_1771:srfi_4_scm",(void*)f_1771},
{"f_1788:srfi_4_scm",(void*)f_1788},
{"f_1792:srfi_4_scm",(void*)f_1792},
{"f_1795:srfi_4_scm",(void*)f_1795},
{"f_1798:srfi_4_scm",(void*)f_1798},
{"f_1822:srfi_4_scm",(void*)f_1822},
{"f_1824:srfi_4_scm",(void*)f_1824},
{"f_1828:srfi_4_scm",(void*)f_1828},
{"f_1834:srfi_4_scm",(void*)f_1834},
{"f_1841:srfi_4_scm",(void*)f_1841},
{"f_1733:srfi_4_scm",(void*)f_1733},
{"f_1735:srfi_4_scm",(void*)f_1735},
{"f_1739:srfi_4_scm",(void*)f_1739},
{"f_1745:srfi_4_scm",(void*)f_1745},
{"f_1748:srfi_4_scm",(void*)f_1748},
{"f_1716:srfi_4_scm",(void*)f_1716},
{"f_1718:srfi_4_scm",(void*)f_1718},
{"f_1722:srfi_4_scm",(void*)f_1722},
{"f_1728:srfi_4_scm",(void*)f_1728},
{"f_1702:srfi_4_scm",(void*)f_1702},
{"f_1704:srfi_4_scm",(void*)f_1704},
{"f_1708:srfi_4_scm",(void*)f_1708},
{"f_1711:srfi_4_scm",(void*)f_1711},
{"f_1659:srfi_4_scm",(void*)f_1659},
{"f_1661:srfi_4_scm",(void*)f_1661},
{"f_1656:srfi_4_scm",(void*)f_1656},
{"f_1653:srfi_4_scm",(void*)f_1653},
{"f_1650:srfi_4_scm",(void*)f_1650},
{"f_1647:srfi_4_scm",(void*)f_1647},
{"f_1644:srfi_4_scm",(void*)f_1644},
{"f_1641:srfi_4_scm",(void*)f_1641},
{"f_1638:srfi_4_scm",(void*)f_1638},
{"f_1635:srfi_4_scm",(void*)f_1635},
{"f_1629:srfi_4_scm",(void*)f_1629},
{"f_1623:srfi_4_scm",(void*)f_1623},
{"f_1620:srfi_4_scm",(void*)f_1620},
{"f_1617:srfi_4_scm",(void*)f_1617},
{"f_1614:srfi_4_scm",(void*)f_1614},
{"f_1611:srfi_4_scm",(void*)f_1611},
{"f_1608:srfi_4_scm",(void*)f_1608},
{"f_1605:srfi_4_scm",(void*)f_1605},
{"f_1584:srfi_4_scm",(void*)f_1584},
{"f_1569:srfi_4_scm",(void*)f_1569},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
