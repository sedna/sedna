/* Generated from scrutinizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:38
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: scrutinizer.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -extend private-namespace.scm -output-file scrutinizer.c
   unit: scrutinizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[162];
static double C_possibly_force_alignment;


C_noret_decl(C_scrutinizer_toplevel)
C_externexport void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4724)
static void C_ccall f_4724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4736)
static void C_fcall f_4736(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4730)
static void C_ccall f_4730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4153)
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4611)
static void C_ccall f_4611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4639)
static void C_ccall f_4639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4614)
static void C_ccall f_4614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4585)
static void C_ccall f_4585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4526)
static void C_ccall f_4526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_fcall f_4551(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4558)
static void C_ccall f_4558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4532)
static void C_ccall f_4532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_fcall f_4538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_ccall f_4441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4501)
static void C_ccall f_4501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4494)
static void C_ccall f_4494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4486)
static void C_ccall f_4486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4484)
static void C_ccall f_4484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_ccall f_4477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4359)
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4407)
static void C_ccall f_4407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_ccall f_4380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4395)
static void C_ccall f_4395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4377)
static void C_ccall f_4377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4233)
static void C_ccall f_4233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4236)
static void C_ccall f_4236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4239)
static void C_ccall f_4239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_fcall f_4248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4318)
static void C_ccall f_4318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_fcall f_4275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4256)
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4182)
static void C_fcall f_4182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3578)
static void C_fcall f_3578(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3808)
static void C_ccall f_3808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_fcall f_3775(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_ccall f_3782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_fcall f_3682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3713)
static void C_ccall f_3713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3728)
static void C_ccall f_3728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4092)
static void C_fcall f_4092(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_fcall f_4055(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_fcall f_3581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3589)
static void C_ccall f_3589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_fcall f_3596(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3599)
static void C_ccall f_3599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_fcall f_3860(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3992)
static void C_fcall f_3992(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3895)
static void C_fcall f_3895(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3956)
static void C_fcall f_3956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_fcall f_3925(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3877)
static void C_ccall f_3877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_fcall f_3364(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3406)
static void C_ccall f_3406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_fcall f_2969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3003)
static void C_ccall f_3003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_fcall f_2759(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2824)
static void C_fcall f_2824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_fcall f_2765(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2783)
static void C_ccall f_2783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2790)
static void C_ccall f_2790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2797)
static void C_fcall f_2797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2771)
static void C_ccall f_2771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2777)
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2487)
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2574)
static void C_fcall f_2574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2593)
static void C_fcall f_2593(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_fcall f_2630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2478)
static void C_fcall f_2478(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_fcall f_2412(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_fcall f_2210(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_fcall f_2306(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_fcall f_2245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_fcall f_1750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2041)
static void C_ccall f_2041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_fcall f_2047(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_fcall f_1947(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1935)
static void C_ccall f_1935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1802)
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1840)
static void C_ccall f_1840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_fcall f_2148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2171)
static void C_fcall f_2171(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static C_word C_fcall f_2188(C_word t0);
C_noret_decl(f_3024)
static void C_fcall f_3024(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3131)
static void C_fcall f_3131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_fcall f_3147(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1713)
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1691)
static void C_fcall f_1691(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_fcall f_1616(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_fcall f_1550(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_fcall f_3558(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3568)
static void C_ccall f_3568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_fcall f_3504(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3513)
static void C_fcall f_3513(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3552)
static void C_ccall f_3552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3548)
static void C_ccall f_3548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3540)
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1518)
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1525)
static void C_fcall f_1525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1462)
static void C_fcall f_1462(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_fcall f_1469(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_fcall f_1437(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_fcall f_3412(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3422)
static void C_fcall f_3422(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3464)
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_fcall f_3425(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;

C_noret_decl(trf_4736)
static void C_fcall trf_4736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4736(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4736(t0,t1);}

C_noret_decl(trf_4153)
static void C_fcall trf_4153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4153(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4153(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4551)
static void C_fcall trf_4551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4551(t0,t1);}

C_noret_decl(trf_4538)
static void C_fcall trf_4538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4538(t0,t1);}

C_noret_decl(trf_4359)
static void C_fcall trf_4359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4359(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4359(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4248)
static void C_fcall trf_4248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4248(t0,t1);}

C_noret_decl(trf_4275)
static void C_fcall trf_4275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4275(t0,t1);}

C_noret_decl(trf_4182)
static void C_fcall trf_4182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4182(t0,t1);}

C_noret_decl(trf_3578)
static void C_fcall trf_3578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3578(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3578(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3775)
static void C_fcall trf_3775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3775(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3775(t0,t1);}

C_noret_decl(trf_3682)
static void C_fcall trf_3682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3682(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3682(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4092)
static void C_fcall trf_4092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4092(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4092(t0,t1);}

C_noret_decl(trf_4055)
static void C_fcall trf_4055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4055(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4055(t0,t1,t2);}

C_noret_decl(trf_3581)
static void C_fcall trf_3581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3581(t0,t1);}

C_noret_decl(trf_3596)
static void C_fcall trf_3596(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3596(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3596(t0,t1);}

C_noret_decl(trf_3860)
static void C_fcall trf_3860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3860(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3860(t0,t1,t2,t3);}

C_noret_decl(trf_3992)
static void C_fcall trf_3992(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3992(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3992(t0,t1);}

C_noret_decl(trf_3895)
static void C_fcall trf_3895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3895(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3895(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3956)
static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3956(t0,t1);}

C_noret_decl(trf_3925)
static void C_fcall trf_3925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3925(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3925(t0,t1);}

C_noret_decl(trf_3364)
static void C_fcall trf_3364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3364(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3364(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2969)
static void C_fcall trf_2969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2969(t0,t1,t2,t3);}

C_noret_decl(trf_2759)
static void C_fcall trf_2759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2759(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2759(t0,t1,t2,t3);}

C_noret_decl(trf_2824)
static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2824(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2765)
static void C_fcall trf_2765(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2765(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2765(t0,t1,t2,t3);}

C_noret_decl(trf_2797)
static void C_fcall trf_2797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2797(t0,t1);}

C_noret_decl(trf_2487)
static void C_fcall trf_2487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2487(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2487(t0,t1,t2,t3);}

C_noret_decl(trf_2574)
static void C_fcall trf_2574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2574(t0,t1);}

C_noret_decl(trf_2593)
static void C_fcall trf_2593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2593(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2593(t0,t1);}

C_noret_decl(trf_2630)
static void C_fcall trf_2630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2630(t0,t1);}

C_noret_decl(trf_2478)
static void C_fcall trf_2478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2478(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2478(t0,t1,t2,t3);}

C_noret_decl(trf_2412)
static void C_fcall trf_2412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2412(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2412(t0,t1,t2,t3);}

C_noret_decl(trf_2210)
static void C_fcall trf_2210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2210(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2210(t0,t1,t2,t3);}

C_noret_decl(trf_2306)
static void C_fcall trf_2306(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2306(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2306(t0,t1);}

C_noret_decl(trf_2245)
static void C_fcall trf_2245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2245(t0,t1);}

C_noret_decl(trf_1750)
static void C_fcall trf_1750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1750(t0,t1,t2);}

C_noret_decl(trf_2047)
static void C_fcall trf_2047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2047(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2047(t0,t1);}

C_noret_decl(trf_1947)
static void C_fcall trf_1947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1947(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1947(t0,t1,t2,t3);}

C_noret_decl(trf_2148)
static void C_fcall trf_2148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2148(t0,t1);}

C_noret_decl(trf_2171)
static void C_fcall trf_2171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2171(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2171(t0,t1);}

C_noret_decl(trf_3024)
static void C_fcall trf_3024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3024(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3024(t0,t1,t2,t3);}

C_noret_decl(trf_3131)
static void C_fcall trf_3131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3131(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3131(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3147)
static void C_fcall trf_3147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3147(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3147(t0,t1);}

C_noret_decl(trf_3152)
static void C_fcall trf_3152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3152(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3152(t0,t1,t2,t3);}

C_noret_decl(trf_1713)
static void C_fcall trf_1713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1713(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1713(t0,t1,t2);}

C_noret_decl(trf_1691)
static void C_fcall trf_1691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1691(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1691(t0,t1,t2);}

C_noret_decl(trf_1616)
static void C_fcall trf_1616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1616(t0,t1);}

C_noret_decl(trf_1550)
static void C_fcall trf_1550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1550(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1550(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3558)
static void C_fcall trf_3558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3558(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3558(t0,t1,t2);}

C_noret_decl(trf_3504)
static void C_fcall trf_3504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3504(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3504(t0,t1);}

C_noret_decl(trf_3513)
static void C_fcall trf_3513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3513(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3513(t0,t1,t2,t3);}

C_noret_decl(trf_1525)
static void C_fcall trf_1525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1525(t0,t1);}

C_noret_decl(trf_1462)
static void C_fcall trf_1462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1462(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1462(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1469)
static void C_fcall trf_1469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1469(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1469(t0,t1);}

C_noret_decl(trf_1437)
static void C_fcall trf_1437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1437(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1437(t0,t1,t2,t3);}

C_noret_decl(trf_3412)
static void C_fcall trf_3412(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3412(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3412(t0,t1,t2,t3);}

C_noret_decl(trf_3422)
static void C_fcall trf_3422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3422(t0,t1,t2);}

C_noret_decl(trf_3464)
static void C_fcall trf_3464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3464(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3464(t0,t1,t2);}

C_noret_decl(trf_3425)
static void C_fcall trf_3425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3425(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3425(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scrutinizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1443)){
C_save(t1);
C_rereclaim2(1443*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,162);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],6,"printf");
lf[2]=C_decode_literal(C_heaptop,"\376B\000\000\014[debug] ~\077~%");
lf[3]=C_h_intern(&lf[3],19,"\010compilerscrutinize");
lf[4]=C_h_intern(&lf[4],7,"sprintf");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\016procedure `~a\047");
lf[6]=C_h_intern(&lf[6],18,"\010compilerreal-name");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\021unknown procedure");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\017at toplevel:\012  ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\022in toplevel ~a:\012  ");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\021in local ~a,\012  ~a");
lf[11]=C_h_intern(&lf[11],25,"\010compilercompiler-warning");
lf[12]=C_h_intern(&lf[12],8,"scrutiny");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[14]=C_h_intern(&lf[14],10,"deprecated");
lf[15]=C_h_intern(&lf[15],1,"*");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000*use of deprecated toplevel identifier `~a\047");
lf[17]=C_h_intern(&lf[17],7,"\003sysget");
lf[18]=C_h_intern(&lf[18],9,"\004coretype");
lf[19]=C_h_intern(&lf[19],9,"undefined");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\0004access to variable `~a\047 which has an undefined value");
lf[21]=C_h_intern(&lf[21],18,"\004coredeclared-type");
lf[22]=C_h_intern(&lf[22],12,"\010compilerget");
lf[23]=C_h_intern(&lf[23],8,"assigned");
lf[24]=C_h_intern(&lf[24],5,"every");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\011undefined\376\003\000\000\002\376\001\000\000\010noreturn\376\377\016");
lf[26]=C_h_intern(&lf[26],2,"or");
lf[27]=C_h_intern(&lf[27],3,"...");
lf[28]=C_h_intern(&lf[28],7,"\003sysmap");
lf[29]=C_h_intern(&lf[29],4,"take");
lf[30]=C_h_intern(&lf[30],3,"min");
lf[31]=C_h_intern(&lf[31],30,"\010compilerbuild-expression-tree");
lf[32]=C_h_intern(&lf[32],12,"string-chomp");
lf[33]=C_h_intern(&lf[33],2,"pp");
lf[34]=C_h_intern(&lf[34],21,"with-output-to-string");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000mexpected value of type boolean in conditional but were given a value of typ"
"e `~a\047 which is always true:~%~%~a");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010anything");
lf[37]=C_h_intern(&lf[37],4,"char");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\011character");
lf[39]=C_h_intern(&lf[39],14,"symbol->string");
lf[40]=C_h_intern(&lf[40],9,"procedure");
lf[41]=C_h_intern(&lf[41],8,"->string");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000 a procedure with ~a returning ~a");
lf[43]=C_h_intern(&lf[43],18,"string-intersperse");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\004 OR ");
lf[45]=C_h_intern(&lf[45],6,"struct");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\026a structure of type ~a");
lf[47]=C_h_intern(&lf[47],13,"\010compilerbomb");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[50]=C_h_intern(&lf[50],3,"len");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\016zero arguments");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\032~a argument~a of type~a ~a");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\033an unknown number of values");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\013zero values");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\027~a value~a of type~a ~a");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[59]=C_h_intern(&lf[59],4,"list");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004pair\376\377\016");
lf[61]=C_h_intern(&lf[61],6,"number");
lf[62]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[63]=C_h_intern(&lf[63],10,"#!optional");
lf[64]=C_h_intern(&lf[64],6,"#!rest");
lf[65]=C_h_intern(&lf[65],6,"values");
lf[66]=C_h_intern(&lf[66],19,"\003sysundefined-value");
lf[67]=C_h_intern(&lf[67],6,"append");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[69]=C_h_intern(&lf[69],6,"reduce");
lf[70]=C_h_intern(&lf[70],3,"any");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[72]=C_h_intern(&lf[72],10,"\003sysappend");
lf[73]=C_h_intern(&lf[73],7,"reverse");
lf[74]=C_h_intern(&lf[74],10,"append-map");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[76]=C_h_intern(&lf[76],7,"call/cc");
lf[77]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[79]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[81]=C_h_intern(&lf[81],8,"noreturn");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[84]=C_h_intern(&lf[84],4,"pair");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004pair\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[86]=C_h_intern(&lf[86],4,"null");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[88]=C_h_intern(&lf[88],5,"break");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[90]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\0008expected ~a a single result, but were given zero results");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\0007expected ~a a single result, but were given ~a result~a");
lf[93]=C_h_intern(&lf[93],4,"cons");
lf[94]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[95]=C_h_intern(&lf[95],9,"make-list");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\024not a procedure type");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\033in procedure call to `~s\047~a");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\012 (line ~a)");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[100]=C_h_intern(&lf[100],26,"\010compilersource-info->line");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[102]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\030not a procedure type: ~a");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000Oexpected argument #~a of type `~a\047 ~a, but where given an argument of type "
"`~a\047");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0008expected ~a ~a argument~a, but where given ~a argument~a");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000Eexpected ~a a value of type `~a\047, but were given a value of type `~a\047");
lf[107]=C_h_intern(&lf[107],5,"quote");
lf[108]=C_h_intern(&lf[108],6,"string");
lf[109]=C_h_intern(&lf[109],6,"symbol");
lf[110]=C_h_intern(&lf[110],6,"fixnum");
lf[111]=C_h_intern(&lf[111],5,"float");
lf[112]=C_h_intern(&lf[112],7,"boolean");
lf[113]=C_h_intern(&lf[113],3,"eof");
lf[114]=C_h_intern(&lf[114],6,"vector");
lf[115]=C_h_intern(&lf[115],22,"\003sysgeneric-structure\077");
lf[116]=C_h_intern(&lf[116],14,"\004coreundefined");
lf[117]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[118]=C_h_intern(&lf[118],9,"\004coreproc");
lf[119]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[120]=C_h_intern(&lf[120],15,"\004coreglobal-ref");
lf[121]=C_h_intern(&lf[121],13,"\004corevariable");
lf[122]=C_h_intern(&lf[122],2,"if");
lf[123]=C_h_intern(&lf[123],3,"map");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000Ibranches in conditional expression differ in the number of results:~%~%~a");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\016in conditional");
lf[126]=C_h_intern(&lf[126],3,"let");
lf[127]=C_h_intern(&lf[127],10,"alist-cons");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\030in `let\047 binding of `~a\047");
lf[129]=C_h_intern(&lf[129],11,"\004corelambda");
lf[130]=C_h_intern(&lf[130],6,"lambda");
lf[131]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[132]=C_h_intern(&lf[132],7,"butlast");
lf[133]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[134]=C_h_intern(&lf[134],30,"\010compilerdecompose-lambda-list");
lf[135]=C_h_intern(&lf[135],4,"set!");
lf[136]=C_h_intern(&lf[136],9,"\004coreset!");
lf[137]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\134assignment of value of type `~a\047 to toplevel variable `~a\047 does not match d"
"eclared type `~a\047");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\025in assignment to `~a\047");
lf[140]=C_h_intern(&lf[140],14,"\004coreprimitive");
lf[141]=C_h_intern(&lf[141],15,"\004coreinline_ref");
lf[142]=C_h_intern(&lf[142],9,"\004corecall");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\034in ~a of procedure call `~s\047");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\021operator position");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\014argument #~a");
lf[146]=C_h_intern(&lf[146],4,"iota");
lf[147]=C_h_intern(&lf[147],11,"\004coreswitch");
lf[148]=C_h_intern(&lf[148],9,"\004corecond");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\031unexpected node class: ~a");
lf[150]=C_h_intern(&lf[150],12,"\003sysfor-each");
lf[151]=C_h_intern(&lf[151],27,"\010compilerload-type-database");
lf[152]=C_h_intern(&lf[152],8,"\003sysput!");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000Ytype-definition `~a\047 for toplevel binding `~a\047 conflicts with previously lo"
"aded type `~a\047");
lf[154]=C_h_intern(&lf[154],9,"read-file");
lf[155]=C_h_intern(&lf[155],21,"\010compilerverbose-mode");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\036loading type database ~a ...~%");
lf[157]=C_h_intern(&lf[157],12,"file-exists\077");
lf[158]=C_h_intern(&lf[158],13,"make-pathname");
lf[159]=C_h_intern(&lf[159],15,"repository-path");
lf[160]=C_h_intern(&lf[160],9,"\003syserror");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
C_register_lf2(lf,162,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1303,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1301 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1304 in k1301 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1307 in k1304 in k1301 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1320,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! scrutinize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1332,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[151]+1 /* (set! load-type-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4699,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4699r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4699r(t0,t1,t2,t3);}}

static void C_ccall f_4699r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4703,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 651  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[159]))(2,*((C_word*)lf[159]+1),t4);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4703(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[161],t3);}}}

/* k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4757,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 652  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t3,t1,((C_word*)t0)[2]);}

/* k4755 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 652  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[157]))(3,*((C_word*)lf[157]+1),((C_word*)t0)[2],t1);}

/* k4704 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[155]))){
/* scrutinizer.scm: 654  printf */
((C_proc4)C_retrieve_symbol_proc(lf[1]))(4,*((C_word*)lf[1]+1),t2,lf[156],t1);}
else{
t3=t2;
f_4712(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4710 in k4704 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4717,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4750,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 666  read-file */
((C_proc3)C_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t3,((C_word*)t0)[2]);}

/* k4748 in k4710 in k4704 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4716 in k4710 in k4704 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4717,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4724,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 658  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t4,t3,lf[18]);}

/* k4722 in a4716 in k4710 in k4704 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4724,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4730,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4736,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_equalp(t1,t2);
t6=t4;
f_4736(t6,(C_word)C_i_not(t5));}
else{
t5=t4;
f_4736(t5,C_SCHEME_FALSE);}}

/* k4734 in k4722 in a4716 in k4710 in k4704 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4736(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 661  compiler-warning */
((C_proc7)C_retrieve_symbol_proc(lf[11]))(7,*((C_word*)lf[11]+1),((C_word*)t0)[5],lf[12],lf[153],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4730(2,t2,C_SCHEME_UNDEFINED);}}

/* k4728 in k4722 in a4716 in k4710 in k4704 in k4701 in ##compiler#load-type-database in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 665  ##sys#put! */
((C_proc5)C_retrieve_symbol_proc(lf[152]))(5,*((C_word*)lf[152]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[18],((C_word*)t0)[2]);}

/* ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[150],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1332,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3422,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1462,a[2]=t8,a[3]=t3,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1518,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3504,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3558,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1550,a[2]=t11,a[3]=t14,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1570,a[2]=t17,a[3]=t19,a[4]=t21,tmp=(C_word)a,a+=5,tmp));
t23=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1691,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t24=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=t17,tmp=(C_word)a,a+=3,tmp));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3818,a[2]=t26,tmp=(C_word)a,a+=3,tmp));
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3024,a[2]=t29,tmp=(C_word)a,a+=3,tmp));
t31=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2188,tmp=(C_word)a,a+=2,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2148,tmp=(C_word)a,a+=2,tmp);
t33=C_SCHEME_UNDEFINED;
t34=(*a=C_VECTOR_TYPE|1,a[1]=t33,tmp=(C_word)a,a+=2,tmp);
t35=C_SCHEME_UNDEFINED;
t36=(*a=C_VECTOR_TYPE|1,a[1]=t35,tmp=(C_word)a,a+=2,tmp);
t37=C_SCHEME_UNDEFINED;
t38=(*a=C_VECTOR_TYPE|1,a[1]=t37,tmp=(C_word)a,a+=2,tmp);
t39=C_SCHEME_UNDEFINED;
t40=(*a=C_VECTOR_TYPE|1,a[1]=t39,tmp=(C_word)a,a+=2,tmp);
t41=C_set_block_item(t34,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=t36,tmp=(C_word)a,a+=3,tmp));
t42=C_set_block_item(t36,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1750,a[2]=t26,a[3]=t29,a[4]=t32,a[5]=t38,a[6]=t40,a[7]=t34,tmp=(C_word)a,a+=8,tmp));
t43=C_set_block_item(t38,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2210,a[2]=t38,a[3]=t34,a[4]=t31,tmp=(C_word)a,a+=5,tmp));
t44=C_set_block_item(t40,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2412,a[2]=t34,a[3]=t40,tmp=(C_word)a,a+=4,tmp));
t45=C_SCHEME_UNDEFINED;
t46=(*a=C_VECTOR_TYPE|1,a[1]=t45,tmp=(C_word)a,a+=2,tmp);
t47=C_SCHEME_UNDEFINED;
t48=(*a=C_VECTOR_TYPE|1,a[1]=t47,tmp=(C_word)a,a+=2,tmp);
t49=C_SCHEME_UNDEFINED;
t50=(*a=C_VECTOR_TYPE|1,a[1]=t49,tmp=(C_word)a,a+=2,tmp);
t51=C_SCHEME_UNDEFINED;
t52=(*a=C_VECTOR_TYPE|1,a[1]=t51,tmp=(C_word)a,a+=2,tmp);
t53=C_set_block_item(t46,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2478,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t54=C_set_block_item(t48,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2487,a[2]=t32,a[3]=t50,a[4]=t52,a[5]=t46,tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t50,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2759,a[2]=t31,a[3]=t46,tmp=(C_word)a,a+=4,tmp));
t56=C_set_block_item(t52,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2969,a[2]=t46,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t58=*((C_word*)lf[93]+1);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3860,a[2]=t31,tmp=(C_word)a,a+=3,tmp);
t60=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3578,a[2]=t26,a[3]=t46,a[4]=t7,a[5]=t59,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
t61=C_SCHEME_UNDEFINED;
t62=(*a=C_VECTOR_TYPE|1,a[1]=t61,tmp=(C_word)a,a+=2,tmp);
t63=C_set_block_item(t62,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=t62,tmp=(C_word)a,a+=3,tmp));
t64=C_SCHEME_UNDEFINED;
t65=(*a=C_VECTOR_TYPE|1,a[1]=t64,tmp=(C_word)a,a+=2,tmp);
t66=C_set_block_item(t65,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4153,a[2]=t13,a[3]=t60,a[4]=t46,a[5]=t58,a[6]=t57,a[7]=t15,a[8]=t65,a[9]=t62,a[10]=t14,a[11]=t7,a[12]=t34,a[13]=t9,a[14]=t8,tmp=(C_word)a,a+=15,tmp));
t67=(C_word)C_slot(t2,C_fix(3));
t68=(C_word)C_i_car(t67);
/* scrutinizer.scm: 649  walk */
t69=((C_word*)t65)[1];
f_4153(t69,t1,t68,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4153,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(2));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=C_retrieve(lf[66]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4169,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_eqp(t11,lf[107]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4182,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t16=(C_word)C_i_car(t9);
if(C_truep((C_word)C_i_stringp(t16))){
t17=t15;
f_4182(t17,lf[108]);}
else{
if(C_truep((C_word)C_i_symbolp(t16))){
t17=t15;
f_4182(t17,lf[109]);}
else{
if(C_truep((C_word)C_fixnump(t16))){
t17=t15;
f_4182(t17,lf[110]);}
else{
if(C_truep((C_word)C_i_flonump(t16))){
t17=t15;
f_4182(t17,lf[111]);}
else{
if(C_truep((C_word)C_i_numberp(t16))){
t17=t15;
f_4182(t17,lf[61]);}
else{
if(C_truep((C_word)C_booleanp(t16))){
t17=t15;
f_4182(t17,lf[112]);}
else{
if(C_truep((C_word)C_i_listp(t16))){
t17=t15;
f_4182(t17,lf[59]);}
else{
if(C_truep((C_word)C_i_pairp(t16))){
t17=t15;
f_4182(t17,lf[84]);}
else{
if(C_truep((C_word)C_eofp(t16))){
t17=t15;
f_4182(t17,lf[113]);}
else{
if(C_truep((C_word)C_i_vectorp(t16))){
t17=t15;
f_4182(t17,lf[114]);}
else{
t17=(C_word)C_immp(t16);
t18=(C_truep(t17)?C_SCHEME_FALSE:(C_truep(*((C_word*)lf[115]+1))?t16:C_SCHEME_FALSE));
if(C_truep(t18)){
t19=(C_word)C_slot(t16,C_fix(0));
t20=(C_word)C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=t15;
f_4182(t21,(C_word)C_a_i_cons(&a,2,lf[45],t20));}
else{
if(C_truep((C_word)C_i_nullp(t16))){
t19=t15;
f_4182(t19,lf[86]);}
else{
t19=(C_word)C_charp(t16);
t20=t15;
f_4182(t20,(C_truep(t19)?lf[37]:lf[15]));}}}}}}}}}}}}}
else{
t15=(C_word)C_eqp(t11,lf[116]);
if(C_truep(t15)){
t16=t13;
f_4169(2,t16,lf[117]);}
else{
t16=(C_word)C_eqp(t11,lf[118]);
if(C_truep(t16)){
t17=t13;
f_4169(2,t17,lf[119]);}
else{
t17=(C_word)C_eqp(t11,lf[120]);
if(C_truep(t17)){
t18=(C_word)C_i_car(t9);
/* scrutinizer.scm: 563  global-result */
t19=((C_word*)t0)[14];
f_1437(t19,t13,t18,t4);}
else{
t18=(C_word)C_eqp(t11,lf[121]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
/* scrutinizer.scm: 564  variable-result */
t20=((C_word*)t0)[13];
f_1462(t20,t13,t19,t3,t4);}
else{
t19=(C_word)C_eqp(t11,lf[122]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4233,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[10],a[10]=t4,a[11]=((C_word*)t0)[11],a[12]=t13,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4344,a[2]=t4,a[3]=t20,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_car(t7);
/* scrutinizer.scm: 565  walk */
t53=t21;
t54=t22;
t55=t3;
t56=t4;
t57=t5;
t1=t53;
t2=t54;
t3=t55;
t4=t56;
t5=t57;
goto loop;}
else{
t20=(C_word)C_eqp(t11,lf[126]);
if(C_truep(t20)){
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[6],a[3]=t22,a[4]=t3,a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t24=((C_word*)t22)[1];
f_4359(t24,t13,t9,t7,C_SCHEME_END_OF_LIST);}
else{
t21=(C_word)C_eqp(t11,lf[129]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(t11,lf[130]));
if(C_truep(t22)){
t23=(C_word)C_i_car(t9);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4441,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 591  decompose-lambda-list */
((C_proc4)C_retrieve_symbol_proc(lf[134]))(4,*((C_word*)lf[134]+1),t13,t23,t24);}
else{
t23=(C_word)C_eqp(t11,lf[135]);
t24=(C_truep(t23)?t23:(C_word)C_eqp(t11,lf[136]));
if(C_truep(t24)){
t25=(C_word)C_i_car(t9);
t26=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[11],a[8]=t13,a[9]=t3,a[10]=t25,tmp=(C_word)a,a+=11,tmp);
/* scrutinizer.scm: 611  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t26,t25,lf[18]);}
else{
t25=(C_word)C_eqp(t11,lf[140]);
t26=(C_truep(t25)?t25:(C_word)C_eqp(t11,lf[141]));
if(C_truep(t26)){
t27=t13;
f_4169(2,t27,lf[15]);}
else{
t27=(C_word)C_eqp(t11,lf[142]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4611,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=t9,a[6]=t4,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 630  fragment */
f_3504(t28,t2);}
else{
t28=(C_word)C_eqp(t11,lf[147]);
t29=(C_truep(t28)?t28:(C_word)C_eqp(t11,lf[148]));
if(C_truep(t29)){
/* scrutinizer.scm: 643  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t13,lf[149],t11);}
else{
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4668,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t31=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4670,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t32=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t30,t31,t7);}}}}}}}}}}}}}

/* a4669 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4670,3,t0,t1,t2);}
/* scrutinizer.scm: 645  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4153(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4666 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4169(2,t2,lf[15]);}

/* k4609 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4614,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4623,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4649,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(((C_word*)t0)[9]);
/* scrutinizer.scm: 640  iota */
((C_proc3)C_retrieve_symbol_proc(lf[146]))(3,*((C_word*)lf[146]+1),t4,t5);}

/* k4647 in k4609 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 631  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[123]+1)))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4622 in k4609 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4623,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4631,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t6)){
t7=t5;
f_4639(2,t7,lf[144]);}
else{
/* scrutinizer.scm: 637  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t5,lf[145],t3);}}

/* k4637 in a4622 in k4609 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 633  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[143],t1,((C_word*)t0)[2]);}

/* k4629 in a4622 in k4609 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 639  walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4153(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k4633 in k4629 in a4622 in k4609 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 632  single */
t2=((C_word*)t0)[5];
f_3364(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4612 in k4609 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 641  call-result */
t3=((C_word*)t0)[5];
f_3578(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4526,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4585,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 613  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t3,lf[139],((C_word*)t0)[10]);}

/* k4583 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 614  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4153(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k4587 in k4583 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 612  single */
t2=((C_word*)t0)[5];
f_3364(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4524 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4526,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4532,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(t2)){
t5=t4;
f_4551(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[3],lf[14]);
if(C_truep(t5)){
t6=t4;
f_4551(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4577,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 619  match */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2478(t7,t6,((C_word*)t0)[3],t1);}}}
else{
t5=t4;
f_4551(t5,C_SCHEME_FALSE);}}

/* k4575 in k4524 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4551(t2,(C_word)C_i_not(t1));}

/* k4549 in k4524 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4558,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 622  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),t2,lf[138],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
f_4532(2,t2,C_SCHEME_UNDEFINED);}}

/* k4556 in k4549 in k4524 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 620  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4530 in k4524 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=t2;
f_4538(t4,(C_word)C_eqp(lf[19],t3));}
else{
t3=t2;
f_4538(t3,C_SCHEME_FALSE);}}

/* k4536 in k4530 in k4524 in k4521 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
f_4169(2,t3,lf[137]);}

/* a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4441(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4441,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4448,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4501,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 595  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t7,t3,lf[15]);}

/* k4499 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[3])?lf[133]:C_SCHEME_END_OF_LIST);
/* scrutinizer.scm: 595  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[2],t1,t2);}

/* k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4484,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4486,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4494,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
/* scrutinizer.scm: 597  butlast */
((C_proc3)C_retrieve_symbol_proc(lf[132]))(3,*((C_word*)lf[132]+1),t5,((C_word*)t0)[2]);}
else{
t6=t5;
f_4494(2,t6,((C_word*)t0)[2]);}}

/* k4492 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4485 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4486,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t2,lf[15]));}

/* k4482 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 596  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4449 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* scrutinizer.scm: 600  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2],lf[59],t1);}
else{
t5=t4;
f_4473(2,t5,t1);}}

/* k4471 in k4449 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4477,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 601  add-loc */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4475 in k4471 in k4449 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 599  walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4153(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k4452 in k4449 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* scrutinizer.scm: 604  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),t2,lf[131],((C_word*)t0)[2],t3,t1);}

/* k4459 in k4452 in k4449 in k4446 in a4440 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* loop in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4359(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4359,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4377,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 585  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t6,t4,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4380,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4419,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_car(t2);
/* scrutinizer.scm: 587  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[6]))(3,*((C_word*)lf[6]+1),t7,t8);}}

/* k4417 in loop in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 587  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[128],t1);}

/* k4401 in loop in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4407,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
/* scrutinizer.scm: 588  walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4153(t5,t2,t3,((C_word*)t0)[2],((C_word*)t0)[6],t4);}

/* k4405 in k4401 in loop in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 586  single */
t2=((C_word*)t0)[5];
f_3364(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4378 in loop in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4380,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4395,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm: 589  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[127]))(5,*((C_word*)lf[127]+1),t4,t5,t1,((C_word*)t0)[2]);}

/* k4393 in k4378 in loop in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 589  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4359(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4375 in loop in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 585  walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4153(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4342 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 565  single */
t2=((C_word*)t0)[4];
f_3364(t2,((C_word*)t0)[3],lf[125],t1,((C_word*)t0)[2]);}

/* k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* scrutinizer.scm: 566  always-true */
t3=((C_word*)t0)[2];
f_1550(t3,t2,t1,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 567  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4153(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t1,a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* scrutinizer.scm: 568  walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4153(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[9],((C_word*)t0)[2]);}

/* k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[15]);
if(C_truep(t3)){
t4=t2;
f_4248(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[15],t1);
t5=t2;
f_4248(t5,(C_word)C_i_not(t4));}}

/* k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4248,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 571  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t4,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[8]);}
else{
t2=((C_word*)t0)[9];
f_4169(2,t2,lf[15]);}}

/* k4316 in k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4275(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 572  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4312 in k4316 in k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4275(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(C_word)C_i_length(((C_word*)t0)[2]);
t4=(C_word)C_eqp(t2,t3);
t5=((C_word*)t0)[4];
f_4275(t5,(C_word)C_i_not(t4));}}

/* k4273 in k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4275,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4286,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 578  pp-fragment */
t4=((C_word*)t0)[3];
f_3558(t4,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_4251(2,t2,C_SCHEME_UNDEFINED);}}

/* k4284 in k4273 in k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 576  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[124],t1);}

/* k4280 in k4273 in k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 574  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4249 in k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4256,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 579  map */
((C_proc5)C_retrieve_proc(*((C_word*)lf[123]+1)))(5,*((C_word*)lf[123]+1),((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4255 in k4249 in k4246 in k4240 in k4237 in k4234 in k4231 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4256,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,t2,t4);
t6=(C_word)C_a_i_cons(&a,2,lf[26],t5);
/* scrutinizer.scm: 579  simplify */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1741(3,t7,t1,t6);}

/* k4180 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4182,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4169(2,t2,(C_word)C_a_i_list(&a,1,t1));}

/* k4167 in walk in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* noreturn-type? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4121,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[81],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[26],t4);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 552  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t1,((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3578(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3578,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3581,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_retrieve(lf[66]);
t8=(C_word)C_i_car(t2);
t9=(C_word)C_i_cdr(t2);
t10=(C_word)C_i_length(t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3808,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* scrutinizer.scm: 472  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t11,t10,lf[15]);}

/* k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3808,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[15],C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,lf[40],t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[9],a[4]=t4,a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 473  procedure-type? */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3818(3,t8,t7,((C_word*)t0)[9]);}

/* k3798 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3800,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_3775(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3796,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 474  match */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2478(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3794 in k3798 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3775(t2,(C_word)C_i_not(t1));}

/* k3773 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3775(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3775,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 479  pname */
t4=((C_word*)t0)[2];
f_3581(t4,t3);}
else{
t2=((C_word*)t0)[6];
f_3637(2,t2,C_SCHEME_UNDEFINED);}}

/* k3784 in k3773 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 477  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[106],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3780 in k3773 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 475  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3642,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3656,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[66]);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3663,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t6=(C_word)C_i_length(t2);
t7=(C_word)C_eqp(t6,((C_word*)t0)[2]);
if(C_truep(t7)){
t8=t5;
f_3663(2,t8,C_SCHEME_UNDEFINED);}
else{
t8=(C_word)C_i_length(t2);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3760,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 490  pname */
t11=((C_word*)t0)[4];
f_3581(t11,t10);}}

/* k3758 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(1));
t3=(C_truep(t2)?lf[51]:lf[52]);
t4=(C_word)C_eqp(((C_word*)t0)[3],C_fix(1));
t5=(C_truep(t4)?lf[51]:lf[52]);
/* scrutinizer.scm: 488  sprintf */
((C_proc8)C_retrieve_symbol_proc(lf[4]))(8,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[105],t1,((C_word*)t0)[4],t3,((C_word*)t0)[3],t5);}

/* k3754 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 486  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3666,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[9]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3682(t7,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* doloop913 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3682(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3682,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?t5:(C_word)C_i_nullp(t3));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3695,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3713,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_i_car(t2);
/* scrutinizer.scm: 496  match */
t11=((C_word*)((C_word*)t0)[2])[1];
f_2478(t11,t8,t9,t10);}}

/* k3711 in doloop913 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3713,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
f_3695(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3720,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3728,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 501  pname */
t5=((C_word*)t0)[2];
f_3581(t5,t4);}}

/* k3726 in k3711 in doloop913 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm: 499  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[104],((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}

/* k3718 in k3711 in doloop913 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 497  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3693 in doloop913 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_3682(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k3664 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3669,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
if(C_truep(t4)){
t5=t2;
f_3669(2,t5,t3);}
else{
t5=(C_word)C_i_memq(((C_word*)t0)[2],lf[102]);
t6=(C_truep(t5)?t5:(C_word)C_i_not_pair_p(((C_word*)t0)[2]));
if(C_truep(t6)){
t7=t2;
f_3669(2,t7,lf[15]);}
else{
t7=(C_word)C_i_car(((C_word*)t0)[2]);
t8=(C_word)C_eqp(lf[40],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 539  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t2,t9);}
else{
/* scrutinizer.scm: 547  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t2,lf[103],((C_word*)t0)[2]);}}}}

/* a4044 in k3664 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4045,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(C_word)C_i_stringp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4092,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4092(t6,t4);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
t7=t5;
f_4092(t7,(C_word)C_i_symbolp(t6));}}

/* k4090 in a4044 in k3664 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4092(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4092,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4055,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4055(t6,((C_word*)t0)[2],t2);}

/* loop in k4090 in a4044 in k3664 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_4055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4055,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_eqp(lf[15],t2);
if(C_truep(t3)){
/* scrutinizer.scm: 545  return */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,lf[15]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4082,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 546  loop */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4080 in loop in k4090 in a4044 in k3664 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3667 in k3664 in k3661 in a3655 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3641 in k3635 in k3806 in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3642,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_length(t2);
/* scrutinizer.scm: 482  procedure-argument-types */
t4=((C_word*)t0)[3];
f_3860(t4,t1,((C_word*)t0)[2],t3);}

/* pname in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3581,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3589,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 462  fragment */
f_3504(t2,((C_word*)t0)[2]);}

/* k3587 in pname in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3593,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3596,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
t5=t3;
f_3596(t5,(C_word)C_i_pairp(t4));}
else{
t4=t3;
f_3596(t4,C_SCHEME_FALSE);}}

/* k3594 in k3587 in pname in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3596(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3596,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3599,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* scrutinizer.scm: 464  source-info->line */
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t2,t3);}
else{
t2=((C_word*)t0)[3];
f_3593(2,t2,lf[101]);}}

/* k3597 in k3594 in k3587 in pname in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_numberp(t1))){
/* scrutinizer.scm: 466  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[98],t1);}
else{
t2=((C_word*)t0)[2];
f_3593(2,t2,lf[99]);}}

/* k3591 in k3587 in pname in call-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 460  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[97],((C_word*)t0)[2],t1);}

/* procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3860(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3860,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_memq(t2,lf[94]);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3877,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 514  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t6,t3,lf[15]);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[40],t6);
if(C_truep(t7)){
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3886,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_i_cadr(t2);
t12=(C_word)C_i_stringp(t11);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3992,a[2]=t3,a[3]=t10,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_3992(t14,t12);}
else{
t14=(C_word)C_i_cadr(t2);
t15=t13;
f_3992(t15,(C_word)C_i_symbolp(t14));}}
else{
/* scrutinizer.scm: 532  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[96],t2);}}}

/* k3990 in procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3992,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3895,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3895(t6,((C_word*)t0)[3],t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* loop in k3990 in procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3895(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3895,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(lf[63],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 525  loop */
t16=t1;
t17=t7;
t18=t3;
t19=C_SCHEME_TRUE;
t1=t16;
t2=t17;
t3=t18;
t4=t19;
goto loop;}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[64],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3925,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cadr(t2);
t12=t9;
f_3925(t12,(C_word)C_eqp(lf[65],t11));}
else{
t11=t9;
f_3925(t11,C_SCHEME_FALSE);}}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3956,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t10=t3;
t11=t9;
f_3956(t11,(C_word)C_fixnum_less_or_equal_p(t10,C_fix(0)));}
else{
t10=t9;
f_3956(t10,C_SCHEME_FALSE);}}}}}

/* k3954 in loop in k3990 in procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3967,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* scrutinizer.scm: 530  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_3895(t6,t3,t4,t5,((C_word*)t0)[2]);}}

/* k3965 in k3954 in loop in k3990 in procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3923 in loop in k3990 in procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3925(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2188(t3);
/* scrutinizer.scm: 528  make-list */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k3884 in procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 531  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3875 in procedure-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 514  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* single in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3364(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3364,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(lf[15],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[15]);}
else{
t6=(C_word)C_i_length(t3);
t7=(C_word)C_eqp(C_fix(1),t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t3));}
else{
t8=(C_word)C_eqp(t6,C_fix(0));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3396,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 418  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t10,lf[91],t2);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3399,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3406,a[2]=t4,a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_eqp(t6,C_fix(1));
t12=(C_truep(t11)?lf[51]:lf[52]);
/* scrutinizer.scm: 423  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[4]))(6,*((C_word*)lf[4]+1),t10,lf[92],t2,t6,t12);}}}}

/* k3404 in single in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 421  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3397 in single in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_car(((C_word*)t0)[2]));}

/* k3394 in single in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 416  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3390 in single in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[19]);}

/* match-results in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2969,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not_pair_p(t3));}
else{
t4=(C_word)C_eqp(lf[15],t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(lf[15],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3003,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 364  match */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2478(t9,t6,t7,t8);}}}}}

/* k3001 in match-results in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 365  match-results */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2969(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2759(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2759,NULL,4,t0,t1,t2,t3);}
t4=C_retrieve(lf[66]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2824(t9,t1,t2,t3,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* loop in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2824,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_retrieve(lf[66]);
if(C_truep((C_word)C_i_nullp(t2))){
t7=t5;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_nullp(t3);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_i_car(t3);
t10=t1;
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_i_memq(t9,lf[89]));}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t7=t4;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_i_car(t2);
t9=t1;
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t8,lf[90]));}}
else{
t7=(C_word)C_i_car(t2);
t8=(C_word)C_eqp(lf[63],t7);
if(C_truep(t8)){
t9=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 350  loop */
t32=t1;
t33=t9;
t34=t3;
t35=C_SCHEME_TRUE;
t36=t5;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t9=(C_word)C_i_car(t3);
t10=(C_word)C_eqp(lf[63],t9);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 352  loop */
t32=t1;
t33=t2;
t34=t11;
t35=t4;
t36=C_SCHEME_TRUE;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t11=(C_word)C_i_car(t2);
t12=(C_word)C_eqp(lf[64],t11);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t2);
t14=f_2188(t13);
/* scrutinizer.scm: 354  match-rest */
t15=((C_word*)t0)[3];
f_2765(t15,t1,t14,t3);}
else{
t13=(C_word)C_i_car(t3);
t14=(C_word)C_eqp(lf[64],t13);
if(C_truep(t14)){
t15=(C_word)C_i_cdr(t3);
t16=f_2188(t15);
/* scrutinizer.scm: 356  match-rest */
t17=((C_word*)t0)[3];
f_2765(t17,t1,t16,t2);}
else{
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2932,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=(C_word)C_i_car(t2);
t17=(C_word)C_i_car(t3);
/* scrutinizer.scm: 357  match */
t18=((C_word*)((C_word*)t0)[2])[1];
f_2478(t18,t15,t16,t17);}}}}}}}

/* k2930 in loop in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 357  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2824(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-rest in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2765(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2765,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2771,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2783,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2782 in match-rest in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2783(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2783,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 336  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t4,t5,t2);}

/* a2808 in a2782 in match-rest in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2809,3,t0,t1,t2);}
/* match108 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2478(t3,t1,((C_word*)t0)[2],t2);}

/* k2788 in a2782 in match-rest in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2790,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2797,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 337  rest-type */
t4=t2;
f_2797(t4,f_2188(t3));}
else{
t3=t2;
f_2797(t3,lf[15]);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2795 in k2788 in a2782 in match-rest in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 337  match */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2478(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2770 in match-rest in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2777,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 335  break */
((C_proc4)C_retrieve_symbol_proc(lf[88]))(4,*((C_word*)lf[88]+1),t1,t2,((C_word*)t0)[2]);}

/* a2776 in a2770 in match-rest in match-args in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2777,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[64],t2));}

/* match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2487,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_eqp(t2,lf[15]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_eqp(t3,lf[15]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(C_word)C_eqp(t3,lf[81]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[61]);
t10=(C_truep(t9)?(C_word)C_i_memq(t3,lf[82]):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t11=(C_word)C_eqp(t3,lf[61]);
t12=(C_truep(t11)?(C_word)C_i_memq(t2,lf[83]):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t13=(C_word)C_eqp(lf[40],t2);
if(C_truep(t13)){
if(C_truep((C_word)C_i_pairp(t3))){
t14=(C_word)C_i_car(t3);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_eqp(lf[40],t14));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(lf[40],t3);
if(C_truep(t14)){
if(C_truep((C_word)C_i_pairp(t2))){
t15=(C_word)C_i_car(t2);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_eqp(lf[40],t15));}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t16=(C_word)C_i_car(t2);
t17=t15;
f_2574(t17,(C_word)C_eqp(lf[26],t16));}
else{
t16=t15;
f_2574(t16,C_SCHEME_FALSE);}}}}}}}}}}}

/* k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2574,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 316  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t3=(C_word)C_i_car(((C_word*)t0)[7]);
t4=t2;
f_2593(t4,(C_word)C_eqp(lf[26],t3));}
else{
t3=t2;
f_2593(t3,C_SCHEME_FALSE);}}}

/* k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2593(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2593,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2598,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 317  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),((C_word*)t0)[5],t2,t3);}
else{
t2=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_memq(((C_word*)t0)[6],lf[85]));}
else{
t3=((C_word*)t0)[7];
if(C_truep((C_truep((C_word)C_eqp(t3,lf[86]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,lf[59]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_memq(((C_word*)t0)[6],lf[87]));}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[6]))){
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_i_car(((C_word*)t0)[6]);
t7=t4;
f_2630(t7,(C_word)C_eqp(t5,t6));}
else{
t5=t4;
f_2630(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2630(t5,C_SCHEME_FALSE);}}}}}

/* k2628 in k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2630,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_eqp(t2,lf[40]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 323  named? */
f_2148(t4,((C_word*)t0)[7]);}
else{
t4=(C_word)C_eqp(t2,lf[45]);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?(C_word)C_i_equalp(((C_word*)t0)[7],((C_word*)t0)[6]):C_SCHEME_FALSE));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2688 in k2628 in k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 324  named? */
f_2148(t3,((C_word*)t0)[6]);}

/* k2679 in k2688 in k2628 in k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm: 325  named? */
f_2148(t3,((C_word*)t0)[7]);}

/* k2670 in k2679 in k2688 in k2628 in k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[9]):(C_word)C_i_cddr(((C_word*)t0)[9]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 326  named? */
f_2148(t3,((C_word*)t0)[8]);}

/* k2661 in k2670 in k2679 in k2688 in k2628 in k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2663,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2657,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 327  match-args */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2759(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2655 in k2661 in k2670 in k2679 in k2688 in k2628 in k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm: 328  match-results */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2969(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a2597 in k2591 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2598,3,t0,t1,t2);}
/* match108 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2478(t3,t1,((C_word*)t0)[2],t2);}

/* a2578 in k2572 in match1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2579,3,t0,t1,t2);}
/* match108 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2478(t3,t1,t2,((C_word*)t0)[2]);}

/* match in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2478(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2478,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2482,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 303  match1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2487(t5,t4,t2,t3);}

/* k2480 in match in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* merge-result-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2412(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2412,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(C_word)C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:(C_word)C_i_not_pair_p(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[15]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(C_word)C_a_i_cons(&a,2,t7,t9);
t11=(C_word)C_a_i_cons(&a,2,lf[26],t10);
/* scrutinizer.scm: 300  simplify */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1741(3,t12,t6,t11);}}}}

/* k2439 in merge-result-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2445,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 301  merge-result-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2412(t5,t2,t3,t4);}

/* k2443 in k2439 in merge-result-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2210(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2210,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t3);
t5=(C_word)C_i_memq(t4,lf[77]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t3:lf[78]));}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[64],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t7=(C_word)C_i_car(t3);
t8=t6;
f_2245(t8,(C_word)C_eqp(lf[64],t7));}
else{
t7=t6;
f_2245(t7,C_SCHEME_FALSE);}}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[63],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t9=(C_word)C_i_car(t3);
t10=t8;
f_2306(t10,(C_word)C_eqp(lf[63],t9));}
else{
t9=t8;
f_2306(t9,C_SCHEME_FALSE);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_i_car(t2);
t10=(C_word)C_i_car(t3);
t11=(C_word)C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(C_word)C_a_i_cons(&a,2,t9,t11);
t13=(C_word)C_a_i_cons(&a,2,lf[26],t12);
/* scrutinizer.scm: 294  simplify */
t14=((C_word*)((C_word*)t0)[3])[1];
f_1741(3,t14,t8,t13);}}}}

/* k2368 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2374,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 295  merge-argument-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2210(t5,t2,t3,t4);}

/* k2372 in k2368 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2304 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2306(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2306,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
t4=(C_word)C_i_cadr(((C_word*)t0)[4]);
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_cons(&a,2,t3,t5);
t7=(C_word)C_a_i_cons(&a,2,lf[26],t6);
/* scrutinizer.scm: 291  simplify */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1741(3,t8,t2,t7);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[80]);}}

/* k2315 in k2304 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[4]);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 292  merge-argument-types */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2210(t6,t3,t4,t5);}

/* k2323 in k2315 in k2304 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2319 in k2315 in k2304 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[63],t2));}

/* k2243 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2245,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=f_2188(t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
t6=f_2188(t5);
t7=(C_word)C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(C_word)C_a_i_cons(&a,2,t4,t7);
t9=(C_word)C_a_i_cons(&a,2,lf[26],t8);
/* scrutinizer.scm: 284  simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1741(3,t10,t2,t9);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[79]);}}

/* k2254 in k2243 in merge-argument-types in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[64],t2));}

/* simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1750,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 210  call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[76]+1)))(3,*((C_word*)lf[76]+1),t1,t3);}

/* a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1756,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[8]))){
t3=(C_word)C_i_car(((C_word*)t0)[8]);
t4=(C_word)C_eqp(t3,lf[26]);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[8]);
t6=(C_word)C_eqp(C_fix(2),t5);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* scrutinizer.scm: 215  simplify */
t8=((C_word*)((C_word*)t0)[7])[1];
f_1741(3,t8,t1,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[8]);
/* scrutinizer.scm: 216  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t7,((C_word*)((C_word*)t0)[2])[1],t8);}}
else{
t5=(C_word)C_eqp(t3,lf[40]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2143,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 257  named? */
f_2148(t6,((C_word*)t0)[8]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[8]);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[8]);}}

/* k2141 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[4]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[4]):(C_word)C_i_cddr(((C_word*)t0)[4]));
t4=(C_truep(t2)?(C_word)C_a_i_list(&a,1,t2):C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[4]):(C_word)C_i_cadr(((C_word*)t0)[4]));
/* map */
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,((C_word*)((C_word*)t0)[2])[1],t6);}

/* k2119 in k2141 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2111,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(lf[15],((C_word*)t0)[3]);
if(C_truep(t4)){
t5=t3;
f_2111(2,t5,lf[15]);}
else{
/* map */
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k2109 in k2119 in k2141 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 259  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),((C_word*)t0)[4],lf[75],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1791,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1797,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1894,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 217  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,t3,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 235  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[74]))(4,*((C_word*)lf[74]+1),t2,t3,t4);}}

/* a2036 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2037,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2041,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 237  simplify */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1741(3,t4,t3,t2);}

/* k2039 in a2036 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_i_car(t1);
t4=t2;
f_2047(t4,(C_word)C_eqp(lf[26],t3));}
else{
t3=t2;
f_2047(t3,C_SCHEME_FALSE);}}

/* k2045 in k2039 in a2036 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2047(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2047,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[3]));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],lf[19]);
if(C_truep(t2)){
/* scrutinizer.scm: 241  return */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[4],lf[19]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}}}

/* k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_1947(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1947(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1947,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* scrutinizer.scm: 245  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[73]+1)))(3,*((C_word*)lf[73]+1),t1,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[15],t4);
if(C_truep(t5)){
/* scrutinizer.scm: 246  return */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,lf[15]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 247  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t6,t7,t8);}}}

/* a2018 in loop in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2019,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?112 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3024(t4,t1,t3,t2);}

/* k1970 in loop in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1972,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 248  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1947(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 249  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,t3,((C_word*)t0)[3]);}}

/* a2008 in k1970 in loop in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2009,3,t0,t1,t2);}
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* type<=?112 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3024(t4,t1,t3,t2);}

/* k1983 in k1970 in loop in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm: 250  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1947(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* scrutinizer.scm: 251  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1947(t5,((C_word*)t0)[3],t2,t4);}}

/* k1906 in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t1,t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=C_retrieve(lf[66]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1935,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1937,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm: 255  any */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t5,t6,t1);}}

/* a1936 in k1906 in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1937,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,lf[15]));}

/* k1933 in k1906 in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?lf[71]:((C_word*)t0)[3]);
/* ##sys#append */
t3=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* k1926 in k1906 in k1903 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[26],t1);
/* scrutinizer.scm: 255  simplify */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1741(3,t3,((C_word*)t0)[2],t2);}

/* a1893 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1894,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(lf[40],t2));}

/* k1795 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1797,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[40]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* scrutinizer.scm: 219  reduce */
((C_proc5)C_retrieve_symbol_proc(lf[69]))(5,*((C_word*)lf[69]+1),((C_word*)t0)[6],t2,C_SCHEME_FALSE,t3);}}

/* a1801 in k1795 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1802,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 221  named? */
f_2148(t4,t2);}

/* k1883 in a1801 in k1795 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[7]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[7]):(C_word)C_i_cadr(((C_word*)t0)[7]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[7]):(C_word)C_i_cddr(((C_word*)t0)[7]));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1867,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm: 224  named? */
f_2148(t5,((C_word*)t0)[6]);}

/* k1865 in k1883 in a1801 in k1795 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1867,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadr(((C_word*)t0)[8]):C_SCHEME_FALSE);
t3=(C_truep(t2)?(C_word)C_i_caddr(((C_word*)t0)[8]):(C_word)C_i_cadr(((C_word*)t0)[8]));
t4=(C_truep(t2)?(C_word)C_i_cdddr(((C_word*)t0)[8]):(C_word)C_i_cddr(((C_word*)t0)[8]));
t5=(C_truep(((C_word*)t0)[7])?(C_truep(t2)?(C_word)C_eqp(((C_word*)t0)[7],t2):C_SCHEME_FALSE):C_SCHEME_FALSE);
t6=(C_truep(t5)?(C_word)C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1840,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm: 230  merge-argument-types */
t8=((C_word*)((C_word*)t0)[3])[1];
f_2210(t8,t7,((C_word*)t0)[2],t3);}

/* k1838 in k1865 in k1883 in a1801 in k1795 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1840,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1836,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 231  merge-result-types */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2412(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1834 in k1838 in k1865 in k1883 in a1801 in k1795 in k1789 in a1755 in simplify1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 227  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[67]+1)))(6,*((C_word*)lf[67]+1),((C_word*)t0)[4],lf[68],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* simplify in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1741,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1745,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 206  simplify1 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1750(t4,t3,t2);}

/* k1743 in simplify in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[66]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* named? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2148(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2148,NULL,2,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_car(t2);
t4=(C_word)C_eqp(lf[40],t3);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(t2);
t6=(C_word)C_i_nullp(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2171,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_2171(t8,t6);}
else{
t8=(C_word)C_i_cadr(t2);
t9=t7;
f_2171(t9,(C_word)C_i_pairp(t8));}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2169 in named? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_2171(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* rest-type in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static C_word C_fcall f_2188(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(lf[15]);}
else{
t2=(C_word)C_i_car(t1);
t3=(C_word)C_eqp(lf[65],t2);
return((C_truep(t3)?lf[15]:(C_word)C_i_car(t1)));}}

/* type<=? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3024(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3024,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_memq(t3,lf[58]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t3;
t7=(C_word)C_eqp(t6,lf[59]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_memq(t2,lf[60]));}
else{
t8=(C_word)C_eqp(t6,lf[40]);
if(C_truep(t8)){
if(C_truep((C_word)C_i_pairp(t2))){
t9=(C_word)C_i_car(t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_eqp(lf[40],t9));}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_eqp(t6,lf[61]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_memq(t2,lf[62]));}
else{
if(C_truep((C_word)C_i_pairp(t2))){
if(C_truep((C_word)C_i_pairp(t3))){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[26]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3100,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 377  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,t12,t13);}
else{
t12=(C_word)C_eqp(t10,lf[40]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t2);
t14=(C_word)C_i_pairp(t13);
t15=(C_truep(t14)?(C_word)C_i_cadr(t2):(C_word)C_i_caddr(t2));
t16=(C_word)C_i_cadr(t3);
t17=(C_word)C_i_pairp(t16);
t18=(C_truep(t17)?(C_word)C_i_cadr(t3):(C_word)C_i_caddr(t3));
t19=(C_word)C_i_cadr(t2);
t20=(C_word)C_i_pairp(t19);
t21=(C_truep(t20)?(C_word)C_i_cddr(t2):(C_word)C_i_cdddr(t2));
t22=(C_word)C_i_cadr(t3);
t23=(C_word)C_i_pairp(t22);
t24=(C_truep(t23)?(C_word)C_i_cddr(t3):(C_word)C_i_cdddr(t3));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3131,a[2]=t26,a[3]=t24,a[4]=t21,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t28=((C_word*)t26)[1];
f_3131(t28,t1,t15,t18,C_fix(0),C_fix(0));}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}}}}}

/* loop1 in type<=? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3131(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3131,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(C_word)C_i_nullp(t3);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_3147(t8,t6);}
else{
t8=t5;
t9=t7;
f_3147(t9,(C_word)C_fixnum_greaterp(t8,C_fix(0)));}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[63]);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 398  loop1 */
t25=t1;
t26=t8;
t27=t3;
t28=C_fix(1);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t8=(C_word)C_i_car(t3);
t9=(C_word)C_eqp(t8,lf[63]);
if(C_truep(t9)){
t10=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 400  loop1 */
t25=t1;
t26=t2;
t27=t10;
t28=t4;
t29=C_fix(1);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t10=(C_word)C_i_car(t2);
t11=(C_word)C_eqp(t10,lf[64]);
if(C_truep(t11)){
t12=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 402  loop1 */
t25=t1;
t26=t12;
t27=t3;
t28=C_fix(2);
t29=t5;
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t12=(C_word)C_i_car(t3);
t13=(C_word)C_eqp(t12,lf[64]);
if(C_truep(t13)){
t14=(C_word)C_i_cdr(t3);
/* scrutinizer.scm: 404  loop1 */
t25=t1;
t26=t2;
t27=t14;
t28=t4;
t29=C_fix(2);
t1=t25;
t2=t26;
t3=t27;
t4=t28;
t5=t29;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3266,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t15=(C_word)C_i_car(t2);
t16=(C_word)C_i_car(t3);
/* scrutinizer.scm: 405  type<=? */
t17=((C_word*)((C_word*)t0)[5])[1];
f_3024(t17,t14,t15,t16);}}}}}}}

/* k3264 in loop1 in type<=? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm: 406  loop1 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3131(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3145 in loop1 in type<=? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3147(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3147,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3152,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3152(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k3145 in loop1 in type<=? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3152,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(lf[15],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_nullp(t2));}
else{
t5=(C_word)C_eqp(lf[15],t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3180,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t2);
t8=(C_word)C_i_car(t3);
/* scrutinizer.scm: 393  type<=? */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3024(t9,t6,t7,t8);}}}}

/* k3178 in loop2 in k3145 in loop1 in type<=? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 394  loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3152(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3099 in type<=? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3100,3,t0,t1,t2);}
/* type<=?112 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3024(t3,t1,t2,((C_word*)t0)[2]);}

/* procedure-type? in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3818,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[40],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_eqp(lf[40],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(lf[26],t6);
if(C_truep(t7)){
t8=(C_word)C_i_cdr(t2);
/* scrutinizer.scm: 510  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t1,((C_word*)((C_word*)t0)[2])[1],t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* result-string in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1713(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1713,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[15],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[55]);}
else{
t4=(C_word)C_i_length(t2);
t5=C_retrieve(lf[50]);
t6=(C_word)C_eqp(t5,C_fix(1));
t7=(C_truep(t6)?lf[51]:lf[52]);
t8=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[56]);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1739,a[2]=t7,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t10=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)((C_word*)t0)[2])[1],t2);}}}

/* k1737 in result-string in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 201  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[57],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t1);}

/* argument-string in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1691(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1691,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_length(t2);
t4=C_retrieve(lf[50]);
t5=(C_word)C_eqp(t4,C_fix(1));
t6=(C_truep(t5)?lf[51]:lf[52]);
t7=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[53]);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1711,a[2]=t6,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* map */
t9=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)((C_word*)t0)[2])[1],t2);}}

/* k1709 in argument-string in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 190  sprintf */
((C_proc7)C_retrieve_symbol_proc(lf[4]))(7,*((C_word*)lf[4]+1),((C_word*)t0)[4],lf[54],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t1);}

/* typename in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1570,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_eqp(t3,lf[15]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[36]);}
else{
t5=(C_word)C_eqp(t3,lf[37]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[38]);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* scrutinizer.scm: 168  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t1,t2);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_i_car(t2);
t7=(C_word)C_eqp(t6,lf[40]);
if(C_truep(t7)){
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_i_stringp(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t9)){
t11=t10;
f_1616(t11,t9);}
else{
t11=(C_word)C_i_cadr(t2);
t12=t10;
f_1616(t12,(C_word)C_i_symbolp(t11));}}
else{
t8=(C_word)C_eqp(t6,lf[26]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_cdr(t2);
/* map */
t11=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,((C_word*)((C_word*)t0)[2])[1],t10);}
else{
t9=(C_word)C_eqp(t6,lf[45]);
if(C_truep(t9)){
t10=(C_word)C_i_cadr(t2);
/* scrutinizer.scm: 182  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t1,lf[46],t10);}
else{
/* scrutinizer.scm: 183  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[48],t2);}}}}
else{
/* scrutinizer.scm: 184  bomb */
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),t1,lf[49],t2);}}}}}

/* k1664 in typename in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 178  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[43]))(4,*((C_word*)lf[43]+1),((C_word*)t0)[2],t1,lf[44]);}

/* k1614 in typename in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1616,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 173  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm: 175  argument-string */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1691(t4,t2,t3);}}

/* k1628 in k1614 in typename in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1634,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm: 176  result-string */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1713(t4,t2,t3);}

/* k1632 in k1628 in k1614 in typename in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 174  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[42],((C_word*)t0)[2],t1);}

/* always-true in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1550(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1550,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1554,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm: 154  always-true1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1518(3,t6,t5,t2);}

/* k1552 in always-true in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1557,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 161  pp-fragment */
t5=((C_word*)t0)[3];
f_3558(t5,t4,((C_word*)t0)[2]);}
else{
t3=t2;
f_1557(2,t3,C_SCHEME_UNDEFINED);}}

/* k1566 in k1552 in always-true in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 158  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[35],((C_word*)t0)[2],t1);}

/* k1562 in k1552 in always-true in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 156  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1555 in k1552 in always-true in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pp-fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3558(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3558,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3566,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3568,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 455  with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[34]))(3,*((C_word*)lf[34]+1),t3,t4);}

/* a3567 in pp-fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 457  fragment */
f_3504(t2,((C_word*)t0)[2]);}

/* k3574 in a3567 in pp-fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 457  pp */
((C_proc3)C_retrieve_symbol_proc(lf[33]))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k3564 in pp-fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 454  string-chomp */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),((C_word*)t0)[2],t1);}

/* fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3504(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3504,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3508,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 446  build-expression-tree */
((C_proc3)C_retrieve_symbol_proc(lf[31]))(3,*((C_word*)lf[31]+1),t3,t2);}

/* k3506 in fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3513,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3513(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* walk in k3506 in fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3513(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3513,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(3)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[27]);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t5=(C_word)C_fixnum_increase(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3540,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3548,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3552,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_i_length(t2);
/* scrutinizer.scm: 451  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),t8,C_fix(5),t9);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}}}

/* k3550 in walk in k3506 in fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 451  take */
((C_proc4)C_retrieve_symbol_proc(lf[29]))(4,*((C_word*)lf[29]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3546 in walk in k3506 in fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3536 in walk in k3506 in fragment in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3540,3,t0,t1,t2);}
/* g850851857 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3513(t3,t1,t2,((C_word*)t0)[2]);}

/* always-true1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1518(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1518,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1525,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=t3;
f_1525(t5,(C_word)C_eqp(lf[26],t4));}
else{
t4=t3;
f_1525(t4,C_SCHEME_FALSE);}}

/* k1523 in always-true1 in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm: 150  every */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],lf[25]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:C_SCHEME_TRUE));}}

/* variable-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1462(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1462,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1509,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 135  get */
((C_proc5)C_retrieve_symbol_proc(lf[22]))(5,*((C_word*)lf[22]+1),t6,((C_word*)t0)[3],t2,lf[23]);}

/* k1507 in variable-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1509,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 136  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t2,((C_word*)t0)[2],lf[21]);}
else{
t2=((C_word*)t0)[3];
f_1469(t2,C_SCHEME_FALSE);}}

/* k1514 in k1507 in variable-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1469(t2,(C_word)C_i_not(t1));}

/* k1467 in variable-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1469(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1469,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_eqp(lf[19],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1488,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1492,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 144  real-name */
((C_proc4)C_retrieve_symbol_proc(lf[6]))(4,*((C_word*)lf[6]+1),t7,((C_word*)t0)[7],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cdr(t2);
t6=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,1,t5));}}
else{
/* scrutinizer.scm: 147  global-result */
t3=((C_word*)t0)[2];
f_1437(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4]);}}}

/* k1490 in k1467 in variable-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 143  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[20],t1);}

/* k1486 in k1467 in variable-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 141  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1482 in k1467 in variable-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* global-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_1437(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1437,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1441,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm: 121  ##sys#get */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),t4,t2,lf[18]);}

/* k1439 in global-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1441,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,lf[14]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm: 130  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),t4,lf[16],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,1,t1));}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}}

/* k1455 in k1439 in global-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 128  report */
t2=((C_word*)t0)[4];
f_3412(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1451 in k1439 in global-result in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[15]);}

/* report in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3412(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3412,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3420,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm: 430  location-name */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3422(t5,t4,t2);}

/* k3418 in report in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 427  compiler-warning */
((C_proc6)C_retrieve_symbol_proc(lf[11]))(6,*((C_word*)lf[11]+1),((C_word*)t0)[3],lf[12],lf[13],t1,((C_word*)t0)[2]);}

/* location-name in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3422,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3425,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[8]);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3455,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t2);
/* scrutinizer.scm: 438  lname */
f_3425(t5,t6);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3464,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3464(t8,t1,t2);}}}

/* rec in location-name in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3464(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3464,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t3))){
/* scrutinizer.scm: 442  location-name */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3422(t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* scrutinizer.scm: 443  lname */
f_3425(t4,t5);}}

/* k3479 in rec in location-name in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3485,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm: 443  rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3464(t4,t2,t3);}

/* k3483 in k3479 in rec in location-name in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 443  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[3],lf[10],((C_word*)t0)[2],t1);}

/* k3453 in location-name in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 438  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[9],t1);}

/* lname in location-name in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_fcall f_3425(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3425,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm: 434  real-name */
((C_proc3)C_retrieve_symbol_proc(lf[6]))(3,*((C_word*)lf[6]+1),t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[7]);}}

/* k3434 in lname in location-name in ##compiler#scrutinize in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm: 434  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[2],lf[5],t1);}

/* d in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1320r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1320r(t0,t1,t2,t3);}}

static void C_ccall f_1320r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
if(C_truep((C_word)C_fudge(C_fix(13)))){
/* scrutinizer.scm: 74   printf */
((C_proc5)C_retrieve_symbol_proc(lf[1]))(5,*((C_word*)lf[1]+1),t1,lf[2],t2,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[237] = {
{"toplevel:scrutinizer_scm",(void*)C_scrutinizer_toplevel},
{"f_1303:scrutinizer_scm",(void*)f_1303},
{"f_1306:scrutinizer_scm",(void*)f_1306},
{"f_1309:scrutinizer_scm",(void*)f_1309},
{"f_1312:scrutinizer_scm",(void*)f_1312},
{"f_1315:scrutinizer_scm",(void*)f_1315},
{"f_1318:scrutinizer_scm",(void*)f_1318},
{"f_4699:scrutinizer_scm",(void*)f_4699},
{"f_4703:scrutinizer_scm",(void*)f_4703},
{"f_4757:scrutinizer_scm",(void*)f_4757},
{"f_4706:scrutinizer_scm",(void*)f_4706},
{"f_4712:scrutinizer_scm",(void*)f_4712},
{"f_4750:scrutinizer_scm",(void*)f_4750},
{"f_4717:scrutinizer_scm",(void*)f_4717},
{"f_4724:scrutinizer_scm",(void*)f_4724},
{"f_4736:scrutinizer_scm",(void*)f_4736},
{"f_4730:scrutinizer_scm",(void*)f_4730},
{"f_1332:scrutinizer_scm",(void*)f_1332},
{"f_4153:scrutinizer_scm",(void*)f_4153},
{"f_4670:scrutinizer_scm",(void*)f_4670},
{"f_4668:scrutinizer_scm",(void*)f_4668},
{"f_4611:scrutinizer_scm",(void*)f_4611},
{"f_4649:scrutinizer_scm",(void*)f_4649},
{"f_4623:scrutinizer_scm",(void*)f_4623},
{"f_4639:scrutinizer_scm",(void*)f_4639},
{"f_4631:scrutinizer_scm",(void*)f_4631},
{"f_4635:scrutinizer_scm",(void*)f_4635},
{"f_4614:scrutinizer_scm",(void*)f_4614},
{"f_4523:scrutinizer_scm",(void*)f_4523},
{"f_4585:scrutinizer_scm",(void*)f_4585},
{"f_4589:scrutinizer_scm",(void*)f_4589},
{"f_4526:scrutinizer_scm",(void*)f_4526},
{"f_4577:scrutinizer_scm",(void*)f_4577},
{"f_4551:scrutinizer_scm",(void*)f_4551},
{"f_4558:scrutinizer_scm",(void*)f_4558},
{"f_4532:scrutinizer_scm",(void*)f_4532},
{"f_4538:scrutinizer_scm",(void*)f_4538},
{"f_4441:scrutinizer_scm",(void*)f_4441},
{"f_4501:scrutinizer_scm",(void*)f_4501},
{"f_4448:scrutinizer_scm",(void*)f_4448},
{"f_4494:scrutinizer_scm",(void*)f_4494},
{"f_4486:scrutinizer_scm",(void*)f_4486},
{"f_4484:scrutinizer_scm",(void*)f_4484},
{"f_4451:scrutinizer_scm",(void*)f_4451},
{"f_4473:scrutinizer_scm",(void*)f_4473},
{"f_4477:scrutinizer_scm",(void*)f_4477},
{"f_4454:scrutinizer_scm",(void*)f_4454},
{"f_4461:scrutinizer_scm",(void*)f_4461},
{"f_4359:scrutinizer_scm",(void*)f_4359},
{"f_4419:scrutinizer_scm",(void*)f_4419},
{"f_4403:scrutinizer_scm",(void*)f_4403},
{"f_4407:scrutinizer_scm",(void*)f_4407},
{"f_4380:scrutinizer_scm",(void*)f_4380},
{"f_4395:scrutinizer_scm",(void*)f_4395},
{"f_4377:scrutinizer_scm",(void*)f_4377},
{"f_4344:scrutinizer_scm",(void*)f_4344},
{"f_4233:scrutinizer_scm",(void*)f_4233},
{"f_4236:scrutinizer_scm",(void*)f_4236},
{"f_4239:scrutinizer_scm",(void*)f_4239},
{"f_4242:scrutinizer_scm",(void*)f_4242},
{"f_4248:scrutinizer_scm",(void*)f_4248},
{"f_4318:scrutinizer_scm",(void*)f_4318},
{"f_4314:scrutinizer_scm",(void*)f_4314},
{"f_4275:scrutinizer_scm",(void*)f_4275},
{"f_4286:scrutinizer_scm",(void*)f_4286},
{"f_4282:scrutinizer_scm",(void*)f_4282},
{"f_4251:scrutinizer_scm",(void*)f_4251},
{"f_4256:scrutinizer_scm",(void*)f_4256},
{"f_4182:scrutinizer_scm",(void*)f_4182},
{"f_4169:scrutinizer_scm",(void*)f_4169},
{"f_4121:scrutinizer_scm",(void*)f_4121},
{"f_3578:scrutinizer_scm",(void*)f_3578},
{"f_3808:scrutinizer_scm",(void*)f_3808},
{"f_3800:scrutinizer_scm",(void*)f_3800},
{"f_3796:scrutinizer_scm",(void*)f_3796},
{"f_3775:scrutinizer_scm",(void*)f_3775},
{"f_3786:scrutinizer_scm",(void*)f_3786},
{"f_3782:scrutinizer_scm",(void*)f_3782},
{"f_3637:scrutinizer_scm",(void*)f_3637},
{"f_3656:scrutinizer_scm",(void*)f_3656},
{"f_3760:scrutinizer_scm",(void*)f_3760},
{"f_3756:scrutinizer_scm",(void*)f_3756},
{"f_3663:scrutinizer_scm",(void*)f_3663},
{"f_3682:scrutinizer_scm",(void*)f_3682},
{"f_3713:scrutinizer_scm",(void*)f_3713},
{"f_3728:scrutinizer_scm",(void*)f_3728},
{"f_3720:scrutinizer_scm",(void*)f_3720},
{"f_3695:scrutinizer_scm",(void*)f_3695},
{"f_3666:scrutinizer_scm",(void*)f_3666},
{"f_4045:scrutinizer_scm",(void*)f_4045},
{"f_4092:scrutinizer_scm",(void*)f_4092},
{"f_4055:scrutinizer_scm",(void*)f_4055},
{"f_4082:scrutinizer_scm",(void*)f_4082},
{"f_3669:scrutinizer_scm",(void*)f_3669},
{"f_3642:scrutinizer_scm",(void*)f_3642},
{"f_3581:scrutinizer_scm",(void*)f_3581},
{"f_3589:scrutinizer_scm",(void*)f_3589},
{"f_3596:scrutinizer_scm",(void*)f_3596},
{"f_3599:scrutinizer_scm",(void*)f_3599},
{"f_3593:scrutinizer_scm",(void*)f_3593},
{"f_3860:scrutinizer_scm",(void*)f_3860},
{"f_3992:scrutinizer_scm",(void*)f_3992},
{"f_3895:scrutinizer_scm",(void*)f_3895},
{"f_3956:scrutinizer_scm",(void*)f_3956},
{"f_3967:scrutinizer_scm",(void*)f_3967},
{"f_3925:scrutinizer_scm",(void*)f_3925},
{"f_3886:scrutinizer_scm",(void*)f_3886},
{"f_3877:scrutinizer_scm",(void*)f_3877},
{"f_3364:scrutinizer_scm",(void*)f_3364},
{"f_3406:scrutinizer_scm",(void*)f_3406},
{"f_3399:scrutinizer_scm",(void*)f_3399},
{"f_3396:scrutinizer_scm",(void*)f_3396},
{"f_3392:scrutinizer_scm",(void*)f_3392},
{"f_2969:scrutinizer_scm",(void*)f_2969},
{"f_3003:scrutinizer_scm",(void*)f_3003},
{"f_2759:scrutinizer_scm",(void*)f_2759},
{"f_2824:scrutinizer_scm",(void*)f_2824},
{"f_2932:scrutinizer_scm",(void*)f_2932},
{"f_2765:scrutinizer_scm",(void*)f_2765},
{"f_2783:scrutinizer_scm",(void*)f_2783},
{"f_2809:scrutinizer_scm",(void*)f_2809},
{"f_2790:scrutinizer_scm",(void*)f_2790},
{"f_2797:scrutinizer_scm",(void*)f_2797},
{"f_2771:scrutinizer_scm",(void*)f_2771},
{"f_2777:scrutinizer_scm",(void*)f_2777},
{"f_2487:scrutinizer_scm",(void*)f_2487},
{"f_2574:scrutinizer_scm",(void*)f_2574},
{"f_2593:scrutinizer_scm",(void*)f_2593},
{"f_2630:scrutinizer_scm",(void*)f_2630},
{"f_2690:scrutinizer_scm",(void*)f_2690},
{"f_2681:scrutinizer_scm",(void*)f_2681},
{"f_2672:scrutinizer_scm",(void*)f_2672},
{"f_2663:scrutinizer_scm",(void*)f_2663},
{"f_2657:scrutinizer_scm",(void*)f_2657},
{"f_2598:scrutinizer_scm",(void*)f_2598},
{"f_2579:scrutinizer_scm",(void*)f_2579},
{"f_2478:scrutinizer_scm",(void*)f_2478},
{"f_2482:scrutinizer_scm",(void*)f_2482},
{"f_2412:scrutinizer_scm",(void*)f_2412},
{"f_2441:scrutinizer_scm",(void*)f_2441},
{"f_2445:scrutinizer_scm",(void*)f_2445},
{"f_2210:scrutinizer_scm",(void*)f_2210},
{"f_2370:scrutinizer_scm",(void*)f_2370},
{"f_2374:scrutinizer_scm",(void*)f_2374},
{"f_2306:scrutinizer_scm",(void*)f_2306},
{"f_2317:scrutinizer_scm",(void*)f_2317},
{"f_2325:scrutinizer_scm",(void*)f_2325},
{"f_2321:scrutinizer_scm",(void*)f_2321},
{"f_2245:scrutinizer_scm",(void*)f_2245},
{"f_2256:scrutinizer_scm",(void*)f_2256},
{"f_1750:scrutinizer_scm",(void*)f_1750},
{"f_1756:scrutinizer_scm",(void*)f_1756},
{"f_2143:scrutinizer_scm",(void*)f_2143},
{"f_2121:scrutinizer_scm",(void*)f_2121},
{"f_2111:scrutinizer_scm",(void*)f_2111},
{"f_1791:scrutinizer_scm",(void*)f_1791},
{"f_2037:scrutinizer_scm",(void*)f_2037},
{"f_2041:scrutinizer_scm",(void*)f_2041},
{"f_2047:scrutinizer_scm",(void*)f_2047},
{"f_1905:scrutinizer_scm",(void*)f_1905},
{"f_1947:scrutinizer_scm",(void*)f_1947},
{"f_2019:scrutinizer_scm",(void*)f_2019},
{"f_1972:scrutinizer_scm",(void*)f_1972},
{"f_2009:scrutinizer_scm",(void*)f_2009},
{"f_1985:scrutinizer_scm",(void*)f_1985},
{"f_1908:scrutinizer_scm",(void*)f_1908},
{"f_1937:scrutinizer_scm",(void*)f_1937},
{"f_1935:scrutinizer_scm",(void*)f_1935},
{"f_1928:scrutinizer_scm",(void*)f_1928},
{"f_1894:scrutinizer_scm",(void*)f_1894},
{"f_1797:scrutinizer_scm",(void*)f_1797},
{"f_1802:scrutinizer_scm",(void*)f_1802},
{"f_1885:scrutinizer_scm",(void*)f_1885},
{"f_1867:scrutinizer_scm",(void*)f_1867},
{"f_1840:scrutinizer_scm",(void*)f_1840},
{"f_1836:scrutinizer_scm",(void*)f_1836},
{"f_1741:scrutinizer_scm",(void*)f_1741},
{"f_1745:scrutinizer_scm",(void*)f_1745},
{"f_2148:scrutinizer_scm",(void*)f_2148},
{"f_2171:scrutinizer_scm",(void*)f_2171},
{"f_2188:scrutinizer_scm",(void*)f_2188},
{"f_3024:scrutinizer_scm",(void*)f_3024},
{"f_3131:scrutinizer_scm",(void*)f_3131},
{"f_3266:scrutinizer_scm",(void*)f_3266},
{"f_3147:scrutinizer_scm",(void*)f_3147},
{"f_3152:scrutinizer_scm",(void*)f_3152},
{"f_3180:scrutinizer_scm",(void*)f_3180},
{"f_3100:scrutinizer_scm",(void*)f_3100},
{"f_3818:scrutinizer_scm",(void*)f_3818},
{"f_1713:scrutinizer_scm",(void*)f_1713},
{"f_1739:scrutinizer_scm",(void*)f_1739},
{"f_1691:scrutinizer_scm",(void*)f_1691},
{"f_1711:scrutinizer_scm",(void*)f_1711},
{"f_1570:scrutinizer_scm",(void*)f_1570},
{"f_1666:scrutinizer_scm",(void*)f_1666},
{"f_1616:scrutinizer_scm",(void*)f_1616},
{"f_1630:scrutinizer_scm",(void*)f_1630},
{"f_1634:scrutinizer_scm",(void*)f_1634},
{"f_1550:scrutinizer_scm",(void*)f_1550},
{"f_1554:scrutinizer_scm",(void*)f_1554},
{"f_1568:scrutinizer_scm",(void*)f_1568},
{"f_1564:scrutinizer_scm",(void*)f_1564},
{"f_1557:scrutinizer_scm",(void*)f_1557},
{"f_3558:scrutinizer_scm",(void*)f_3558},
{"f_3568:scrutinizer_scm",(void*)f_3568},
{"f_3576:scrutinizer_scm",(void*)f_3576},
{"f_3566:scrutinizer_scm",(void*)f_3566},
{"f_3504:scrutinizer_scm",(void*)f_3504},
{"f_3508:scrutinizer_scm",(void*)f_3508},
{"f_3513:scrutinizer_scm",(void*)f_3513},
{"f_3552:scrutinizer_scm",(void*)f_3552},
{"f_3548:scrutinizer_scm",(void*)f_3548},
{"f_3540:scrutinizer_scm",(void*)f_3540},
{"f_1518:scrutinizer_scm",(void*)f_1518},
{"f_1525:scrutinizer_scm",(void*)f_1525},
{"f_1462:scrutinizer_scm",(void*)f_1462},
{"f_1509:scrutinizer_scm",(void*)f_1509},
{"f_1516:scrutinizer_scm",(void*)f_1516},
{"f_1469:scrutinizer_scm",(void*)f_1469},
{"f_1492:scrutinizer_scm",(void*)f_1492},
{"f_1488:scrutinizer_scm",(void*)f_1488},
{"f_1484:scrutinizer_scm",(void*)f_1484},
{"f_1437:scrutinizer_scm",(void*)f_1437},
{"f_1441:scrutinizer_scm",(void*)f_1441},
{"f_1457:scrutinizer_scm",(void*)f_1457},
{"f_1453:scrutinizer_scm",(void*)f_1453},
{"f_3412:scrutinizer_scm",(void*)f_3412},
{"f_3420:scrutinizer_scm",(void*)f_3420},
{"f_3422:scrutinizer_scm",(void*)f_3422},
{"f_3464:scrutinizer_scm",(void*)f_3464},
{"f_3481:scrutinizer_scm",(void*)f_3481},
{"f_3485:scrutinizer_scm",(void*)f_3485},
{"f_3455:scrutinizer_scm",(void*)f_3455},
{"f_3425:scrutinizer_scm",(void*)f_3425},
{"f_3436:scrutinizer_scm",(void*)f_3436},
{"f_1320:scrutinizer_scm",(void*)f_1320},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
