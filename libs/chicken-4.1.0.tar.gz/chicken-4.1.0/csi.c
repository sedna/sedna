/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:39
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: csi.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -output-file csi.c -extend ./private-namespace.scm
   used units: library eval data_structures ports extras srfi_69 chicken_syntax srfi_69 ports
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[387];
static double C_possibly_force_alignment;


/* from k1796 */
static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_ccall f_1619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1640)
static void C_ccall f_1640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5632)
static void C_ccall f_5632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4822)
static void C_ccall f_4822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3130)
static void C_ccall f_3130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3149)
static void C_ccall f_3149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3073)
static void C_ccall f_3073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_ccall f_5605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_fcall f_5565(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4838)
static void C_fcall f_4838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_ccall f_5509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_fcall f_4844(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5496)
static void C_ccall f_5496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_fcall f_5005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5008)
static void C_ccall f_5008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_ccall f_5479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5014)
static void C_ccall f_5014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5017)
static void C_fcall f_5017(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5447)
static void C_ccall f_5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5023)
static void C_ccall f_5023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_ccall f_5429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5026)
static void C_ccall f_5026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_ccall f_5425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5029)
static void C_ccall f_5029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5417)
static void C_ccall f_5417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5413)
static void C_ccall f_5413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5405)
static void C_ccall f_5405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5324)
static void C_ccall f_5324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5306)
static void C_ccall f_5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5309)
static void C_ccall f_5309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_ccall f_5312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5053)
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5266)
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5245)
static void C_fcall f_5245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_ccall f_5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5193)
static void C_ccall f_5193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5131)
static void C_ccall f_5131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5078)
static void C_ccall f_5078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5066)
static void C_ccall f_5066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4935)
static void C_fcall f_4935(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4939)
static void C_ccall f_4939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4951)
static void C_fcall f_4951(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4968)
static void C_ccall f_4968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4855)
static void C_fcall f_4855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4861)
static void C_fcall f_4861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4677)
static void C_fcall f_4677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_fcall f_4683(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4705)
static void C_fcall f_4705(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4755)
static void C_ccall f_4755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4721)
static void C_ccall f_4721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4794)
static C_word C_fcall f_4794(C_word t0);
C_noret_decl(f_4620)
static void C_fcall f_4620(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4626)
static void C_fcall f_4626(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4638)
static void C_fcall f_4638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4561)
static void C_ccall f_4561r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4570)
static void C_fcall f_4570(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4559)
static void C_ccall f_4559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4469)
static void C_fcall f_4469(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4552)
static void C_ccall f_4552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4488)
static void C_ccall f_4488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_fcall f_4506(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4516)
static void C_ccall f_4516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_fcall f_4418(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_fcall f_4355(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4359)
static void C_ccall f_4359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4375)
static void C_ccall f_4375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4304)
static void C_fcall f_4304(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_fcall f_4299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4193)
static void C_fcall f_4193(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4261)
static void C_fcall f_4261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4225)
static void C_ccall f_4225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4196)
static void C_fcall f_4196(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4186)
static void C_ccall f_4186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4161)
static void C_ccall f_4161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3495)
static void C_ccall f_3495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_ccall f_3594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3830)
static void C_ccall f_3830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_fcall f_4018(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4053)
static void C_ccall f_4053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4045)
static void C_ccall f_4045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_fcall f_3857(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_fcall f_3762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3776)
static void C_ccall f_3776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_ccall f_3624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3698)
static void C_fcall f_3698(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3642)
static void C_ccall f_3642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_fcall f_3647(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3663)
static void C_ccall f_3663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_fcall f_3381(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_ccall f_3426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3184)
static void C_ccall f_3184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3343)
static void C_ccall f_3343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3323)
static void C_ccall f_3323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3247)
static void C_ccall f_3247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3255)
static void C_ccall f_3255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_ccall f_3259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_ccall f_3210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3219)
static void C_ccall f_3219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_fcall f_3189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3050)
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3044)
static void C_ccall f_3044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2726)
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2730)
static void C_ccall f_2730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2734)
static void C_ccall f_2734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_fcall f_2698(C_word t0) C_noret;
C_noret_decl(f_2702)
static void C_ccall f_2702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2707)
static void C_fcall f_2707(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2663)
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2689)
static void C_ccall f_2689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2110)
static void C_fcall f_2110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_ccall f_2399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2992)
static void C_ccall f_2992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_fcall f_2953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2978)
static void C_ccall f_2978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2382)
static void C_ccall f_2382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2889)
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2320)
static void C_ccall f_2320r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2280)
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2247)
static void C_ccall f_2247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2208)
static void C_ccall f_2208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_ccall f_2211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2147)
static void C_ccall f_2147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2052)
static void C_ccall f_2052r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_fcall f_1967(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_fcall f_1911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1830)
static C_word C_fcall f_1830(C_word t0,C_word t1);
C_noret_decl(f_1803)
static void C_fcall f_1803(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1757)
static void C_ccall f_1757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_fcall f_1766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1685)
static void C_ccall f_1685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3132)
static void C_fcall trf_3132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3132(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3132(t0,t1,t2,t3);}

C_noret_decl(trf_5565)
static void C_fcall trf_5565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5565(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5565(t0,t1);}

C_noret_decl(trf_4838)
static void C_fcall trf_4838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4838(t0,t1);}

C_noret_decl(trf_4844)
static void C_fcall trf_4844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4844(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4844(t0,t1);}

C_noret_decl(trf_5005)
static void C_fcall trf_5005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5005(t0,t1);}

C_noret_decl(trf_5017)
static void C_fcall trf_5017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5017(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5017(t0,t1);}

C_noret_decl(trf_5053)
static void C_fcall trf_5053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5053(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5053(t0,t1,t2);}

C_noret_decl(trf_5245)
static void C_fcall trf_5245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5245(t0,t1);}

C_noret_decl(trf_4935)
static void C_fcall trf_4935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4935(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4935(t0,t1,t2);}

C_noret_decl(trf_4951)
static void C_fcall trf_4951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4951(t0,t1,t2);}

C_noret_decl(trf_4855)
static void C_fcall trf_4855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4855(t0,t1,t2);}

C_noret_decl(trf_4861)
static void C_fcall trf_4861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4861(t0,t1,t2);}

C_noret_decl(trf_4677)
static void C_fcall trf_4677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4677(t0,t1);}

C_noret_decl(trf_4683)
static void C_fcall trf_4683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4683(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4683(t0,t1,t2);}

C_noret_decl(trf_4705)
static void C_fcall trf_4705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4705(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4705(t0,t1);}

C_noret_decl(trf_4620)
static void C_fcall trf_4620(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4620(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4620(t0,t1,t2);}

C_noret_decl(trf_4626)
static void C_fcall trf_4626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4626(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4626(t0,t1,t2);}

C_noret_decl(trf_4638)
static void C_fcall trf_4638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4638(t0,t1,t2);}

C_noret_decl(trf_4570)
static void C_fcall trf_4570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4570(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4570(t0,t1,t2);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4384(t0,t1,t2);}

C_noret_decl(trf_4469)
static void C_fcall trf_4469(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4469(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4469(t0,t1,t2,t3);}

C_noret_decl(trf_4506)
static void C_fcall trf_4506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4506(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4506(t0,t1,t2);}

C_noret_decl(trf_4418)
static void C_fcall trf_4418(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4418(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4418(t0,t1,t2,t3);}

C_noret_decl(trf_4355)
static void C_fcall trf_4355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4355(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4355(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4304)
static void C_fcall trf_4304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4304(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4304(t0,t1);}

C_noret_decl(trf_4299)
static void C_fcall trf_4299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4299(t0,t1,t2);}

C_noret_decl(trf_4193)
static void C_fcall trf_4193(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4193(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4193(t0,t1,t2,t3);}

C_noret_decl(trf_4261)
static void C_fcall trf_4261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4261(t0,t1);}

C_noret_decl(trf_4196)
static void C_fcall trf_4196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4196(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4196(t0,t1,t2);}

C_noret_decl(trf_4018)
static void C_fcall trf_4018(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4018(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4018(t0,t1,t2);}

C_noret_decl(trf_3857)
static void C_fcall trf_3857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3857(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3857(t0,t1);}

C_noret_decl(trf_3762)
static void C_fcall trf_3762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3762(t0,t1);}

C_noret_decl(trf_3698)
static void C_fcall trf_3698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3698(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3698(t0,t1);}

C_noret_decl(trf_3647)
static void C_fcall trf_3647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3647(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3647(t0,t1,t2);}

C_noret_decl(trf_3381)
static void C_fcall trf_3381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3381(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3381(t0,t1,t2);}

C_noret_decl(trf_3413)
static void C_fcall trf_3413(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3413(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3413(t0,t1,t2,t3);}

C_noret_decl(trf_3189)
static void C_fcall trf_3189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3189(t0,t1);}

C_noret_decl(trf_2698)
static void C_fcall trf_2698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2698(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2698(t0);}

C_noret_decl(trf_2707)
static void C_fcall trf_2707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2707(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2707(t0,t1,t2);}

C_noret_decl(trf_2663)
static void C_fcall trf_2663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2663(t0,t1,t2);}

C_noret_decl(trf_2110)
static void C_fcall trf_2110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2110(t0,t1);}

C_noret_decl(trf_2953)
static void C_fcall trf_2953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2953(t0,t1);}

C_noret_decl(trf_1967)
static void C_fcall trf_1967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1967(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1967(t0,t1);}

C_noret_decl(trf_1911)
static void C_fcall trf_1911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1911(t0,t1,t2);}

C_noret_decl(trf_1803)
static void C_fcall trf_1803(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1803(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1803(t0,t1);}

C_noret_decl(trf_1766)
static void C_fcall trf_1766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1766(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2663)){
C_save(t1);
C_rereclaim2(2663*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,387);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[4]=C_h_intern(&lf[4],27,"\003sysrepl-print-length-limit");
lf[5]=C_h_intern(&lf[5],4,"\000csi");
lf[6]=C_h_intern(&lf[6],12,"\003sysfeatures");
lf[7]=C_h_intern(&lf[7],15,"\003csiprint-usage");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\003\376    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -k  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012    -R  -require-ex"
"tension NAME   require extension and import before\012                             "
"      executing code\012    -I  -include-path PATHNAME    add PATHNAME to include p"
"ath\012    --                            ignore all following options\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[12]=C_h_intern(&lf[12],19,"\003sysprint-to-string");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\002\344usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012    -v  -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012    -q  -quiet               "
"     do not print banner\012");
lf[14]=C_h_intern(&lf[14],16,"\003csiprint-banner");
lf[15]=C_h_intern(&lf[15],5,"print");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2009 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[18]=C_h_intern(&lf[18],15,"chicken-version");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[20]=C_h_intern(&lf[20],7,"newline");
lf[21]=C_h_intern(&lf[21],9,"read-char");
lf[22]=C_h_intern(&lf[22],4,"read");
lf[23]=C_h_intern(&lf[23],18,"\003sysuser-read-hook");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],17,"\003csihistory-count");
lf[26]=C_h_intern(&lf[26],15,"\003csihistory-ref");
lf[27]=C_h_intern(&lf[27],21,"\003syssharp-number-hook");
lf[28]=C_h_intern(&lf[28],9,"substring");
lf[29]=C_h_intern(&lf[29],18,"\003csichop-separator");
lf[30]=C_h_intern(&lf[30],4,"sub1");
lf[31]=C_h_intern(&lf[31],1,"@");
lf[32]=C_h_intern(&lf[32],12,"file-exists\077");
lf[33]=C_h_intern(&lf[33],13,"string-append");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[35]=C_h_intern(&lf[35],22,"\003csilookup-script-file");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[37]=C_h_intern(&lf[37],25,"\003syspeek-nonnull-c-string");
lf[38]=C_h_intern(&lf[38],12,"string-split");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[41]=C_h_intern(&lf[41],24,"get-environment-variable");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[43]=C_h_intern(&lf[43],16,"\003csihistory-list");
lf[44]=C_h_intern(&lf[44],13,"vector-resize");
lf[45]=C_h_intern(&lf[45],15,"\003csihistory-add");
lf[46]=C_h_intern(&lf[46],19,"\003sysundefined-value");
lf[47]=C_h_intern(&lf[47],9,"\003syserror");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[49]=C_h_intern(&lf[49],14,"\003csitty-input\077");
lf[50]=C_h_intern(&lf[50],13,"\003systty-port\077");
lf[51]=C_h_intern(&lf[51],18,"\003sysstandard-input");
lf[52]=C_h_intern(&lf[52],18,"\003sysbreak-on-error");
lf[53]=C_h_intern(&lf[53],20,"\003sysread-prompt-hook");
lf[55]=C_h_intern(&lf[55],16,"toplevel-command");
lf[56]=C_h_intern(&lf[56],19,"\003syshash-table-set!");
lf[57]=C_h_intern(&lf[57],4,"eval");
lf[58]=C_h_intern(&lf[58],12,"load-noisily");
lf[59]=C_h_intern(&lf[59],10,"singlestep");
lf[60]=C_h_intern(&lf[60],9,"read-line");
lf[61]=C_h_intern(&lf[61],6,"length");
lf[62]=C_h_intern(&lf[62],5,"write");
lf[63]=C_h_intern(&lf[63],6,"printf");
lf[64]=C_h_intern(&lf[64],6,"expand");
lf[65]=C_h_intern(&lf[65],12,"pretty-print");
lf[66]=C_h_intern(&lf[66],8,"integer\077");
lf[67]=C_h_intern(&lf[67],6,"values");
lf[68]=C_h_intern(&lf[68],18,"\003sysrepl-eval-hook");
lf[69]=C_h_intern(&lf[69],22,"\003csitrace-indent-level");
lf[70]=C_h_intern(&lf[70],4,"exit");
lf[71]=C_h_intern(&lf[71],1,"x");
lf[72]=C_h_intern(&lf[72],16,"\003sysstrip-syntax");
lf[73]=C_h_intern(&lf[73],1,"p");
lf[74]=C_h_intern(&lf[74],1,"d");
lf[75]=C_h_intern(&lf[75],12,"\003csidescribe");
lf[76]=C_h_intern(&lf[76],2,"du");
lf[77]=C_h_intern(&lf[77],8,"\003csidump");
lf[78]=C_h_intern(&lf[78],3,"dur");
lf[79]=C_h_intern(&lf[79],1,"r");
lf[80]=C_h_intern(&lf[80],10,"\003csireport");
lf[81]=C_h_intern(&lf[81],1,"q");
lf[82]=C_h_intern(&lf[82],1,"l");
lf[83]=C_h_intern(&lf[83],12,"\003sysfor-each");
lf[84]=C_h_intern(&lf[84],4,"load");
lf[85]=C_h_intern(&lf[85],2,"ln");
lf[86]=C_h_intern(&lf[86],6,"print*");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[88]=C_h_intern(&lf[88],8,"\000printer");
lf[89]=C_h_intern(&lf[89],1,"t");
lf[90]=C_h_intern(&lf[90],17,"\003sysdisplay-times");
lf[91]=C_h_intern(&lf[91],14,"\003sysstop-timer");
lf[92]=C_h_intern(&lf[92],15,"\003sysstart-timer");
lf[93]=C_h_intern(&lf[93],2,"tr");
lf[95]=C_h_intern(&lf[95],8,"\003syswarn");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\030procedure already traced");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000 procedure already has breakpoint");
lf[99]=C_h_intern(&lf[99],25,"\003csitraced-procedure-exit");
lf[100]=C_h_intern(&lf[100],26,"\003csitraced-procedure-entry");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot trace non-procedure");
lf[102]=C_h_intern(&lf[102],7,"\003sysmap");
lf[104]=C_h_intern(&lf[104],3,"utr");
lf[105]=C_h_intern(&lf[105],7,"\003csidel");
lf[106]=C_h_intern(&lf[106],3,"eq\077");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\024procedure not traced");
lf[108]=C_h_intern(&lf[108],2,"br");
lf[109]=C_h_intern(&lf[109],1,"a");
lf[110]=C_h_intern(&lf[110],15,"\003sysbreak-entry");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000&cannot set breakpoint on non-procedure");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\024un-tracing procedure");
lf[113]=C_h_intern(&lf[113],3,"ubr");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\033procedure has no breakpoint");
lf[115]=C_h_intern(&lf[115],3,"uba");
lf[116]=C_h_intern(&lf[116],14,"do-unbreak-all");
lf[117]=C_h_intern(&lf[117],8,"breakall");
lf[118]=C_h_intern(&lf[118],19,"\003sysbreak-in-thread");
lf[119]=C_h_intern(&lf[119],9,"breakonly");
lf[120]=C_h_intern(&lf[120],4,"info");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\021Breakpoints: ~s~%");
lf[122]=C_h_intern(&lf[122],3,"car");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\014Traced: ~s~%");
lf[124]=C_h_intern(&lf[124],1,"c");
lf[125]=C_h_intern(&lf[125],19,"\003syslast-breakpoint");
lf[126]=C_h_intern(&lf[126],16,"\003sysbreak-resume");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\026no breakpoint pending\012");
lf[128]=C_h_intern(&lf[128],3,"exn");
lf[129]=C_h_intern(&lf[129],18,"\003syslast-exception");
lf[130]=C_h_intern(&lf[130],4,"step");
lf[131]=C_h_intern(&lf[131],6,"lambda");
lf[132]=C_h_intern(&lf[132],1,"s");
lf[133]=C_h_intern(&lf[133],6,"system");
lf[134]=C_h_intern(&lf[134],1,"\077");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[136]=C_h_intern(&lf[136],23,"\003syshash-table-for-each");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\004OToplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,s TEXT ...   "
"    Execute shell-command\012 ,tr NAME ...      Trace procedures\012 ,utr NAME ...    "
" Untrace procedures\012 ,br NAME ...      Set breakpoints\012 ,ubr NAME ...     Remove"
" breakpoints\012 ,uba              Remove all breakpoints\012 ,breakall         Break "
"in all threads (default)\012 ,breakonly THREAD Break only in specified thread\012 ,c  "
"              Continue from breakpoint\012 ,info             List traced procedures"
" and breakpoints\012 ,step EXPR        Execute EXPR in single-stepping mode\012 ,exn  "
"            Describe last exception\012 ,t EXP            Evaluate form and print e"
"lapsed time\012 ,x EXP            Pretty print expanded expression EXP\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[139]=C_h_intern(&lf[139],18,"\003syshash-table-ref");
lf[140]=C_h_intern(&lf[140],7,"unquote");
lf[141]=C_h_intern(&lf[141],23,"\003syscurrent-environment");
lf[142]=C_h_intern(&lf[142],14,"string->symbol");
lf[144]=C_h_intern(&lf[144],19,"\003syswrite-char/port");
lf[145]=C_h_intern(&lf[145],19,"\003sysstandard-output");
lf[146]=C_h_intern(&lf[146],12,"flush-output");
lf[147]=C_h_intern(&lf[147],16,"\003syswrite-char-0");
lf[148]=C_h_intern(&lf[148],4,"add1");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[150]=C_h_intern(&lf[150],4,"chop");
lf[151]=C_h_intern(&lf[151],4,"sort");
lf[152]=C_h_intern(&lf[152],19,"with-output-to-port");
lf[153]=C_h_intern(&lf[153],19,"current-output-port");
lf[154]=C_h_intern(&lf[154],8,"truncate");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\002\001~%~\012                   Machine type:    \011~A ~A~%~\012                   Softwa"
"re type:   \011~A~%~\012                   Software version:\011~A~%~\012                   "
"Build platform:  \011~A~%~\012                   Include path:    \011~A~%~\012             "
"      Symbol-table load:\011~S~%  ~\012                     Avg bucket length:\011~S~%  ~"
"\012                     Total symbol count:\011~S~%~\012                   Memory:\011heap "
"size is ~S bytes~A with ~S bytes currently in use~%~  \012                     nurs"
"ery size is ~S bytes, stack grows ~A~%");
lf[164]=C_h_intern(&lf[164],21,"\003sysinclude-pathnames");
lf[165]=C_h_intern(&lf[165],14,"build-platform");
lf[166]=C_h_intern(&lf[166],16,"software-version");
lf[167]=C_h_intern(&lf[167],13,"software-type");
lf[168]=C_h_intern(&lf[168],12,"machine-type");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[170]=C_h_intern(&lf[170],11,"make-string");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[172]=C_h_intern(&lf[172],8,"string<\077");
lf[173]=C_h_intern(&lf[173],15,"keyword->string");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[175]=C_h_intern(&lf[175],17,"memory-statistics");
lf[176]=C_h_intern(&lf[176],21,"\003syssymbol-table-info");
lf[177]=C_h_intern(&lf[177],2,"gc");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[181]=C_h_intern(&lf[181],7,"sprintf");
lf[182]=C_h_intern(&lf[182],7,"fprintf");
lf[183]=C_h_intern(&lf[183],8,"list-ref");
lf[184]=C_h_intern(&lf[184],10,"string-ref");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[199]=C_h_intern(&lf[199],28,"\003sysarbitrary-unbound-symbol");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[203]=C_h_intern(&lf[203],8,"\003syssize");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[205]=C_h_intern(&lf[205],8,"\003sysslot");
lf[206]=C_h_intern(&lf[206],27,"\003syswith-print-length-limit");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\027~asymbol with name ~S~%");
lf[212]=C_h_intern(&lf[212],18,"\003syssymbol->string");
lf[213]=C_h_intern(&lf[213],20,"\003sysinterned-symbol\077");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\010keyword ");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[216]=C_h_intern(&lf[216],32,"\003syssymbol-has-toplevel-binding\077");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\035pair with car ~S and cdr ~S~%");
lf[219]=C_h_intern(&lf[219],15,"describe-object");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[221]=C_h_intern(&lf[221],25,"\003syspeek-unsigned-integer");
lf[222]=C_h_intern(&lf[222],9,"\000tinyclos");
lf[223]=C_h_intern(&lf[223],19,"\010tinyclosentity-tag");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[239]=C_h_intern(&lf[239],11,"\003csihexdump");
lf[240]=C_h_intern(&lf[240],8,"\003sysbyte");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[243]=C_h_intern(&lf[243],23,"\003syslambda-info->string");
lf[244]=C_h_intern(&lf[244],10,"hash-table");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[246]=C_h_intern(&lf[246],15,"hash-table-walk");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[251]=C_h_intern(&lf[251],9,"condition");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[253]=C_h_intern(&lf[253],4,"cdar");
lf[254]=C_h_intern(&lf[254],4,"caar");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[257]=C_h_intern(&lf[257],6,"unveil");
lf[258]=C_h_intern(&lf[258],6,"append");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[261]=C_h_intern(&lf[261],15,"meroon-instance");
lf[262]=C_h_intern(&lf[262],9,"provided\077");
lf[263]=C_h_intern(&lf[263],6,"meroon");
lf[264]=C_h_intern(&lf[264],15,"\003sysbytevector\077");
lf[265]=C_h_intern(&lf[265],13,"\003syslocative\077");
lf[266]=C_h_intern(&lf[266],9,"instance\077");
lf[267]=C_h_intern(&lf[267],5,"port\077");
lf[268]=C_h_intern(&lf[268],11,"\003sysnumber\077");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[270]=C_h_intern(&lf[270],17,"\003sysblock-address");
lf[271]=C_h_intern(&lf[271],14,"set-describer!");
lf[272]=C_h_intern(&lf[272],16,"\003syscheck-symbol");
lf[273]=C_h_intern(&lf[273],6,"symbol");
lf[274]=C_h_intern(&lf[274],3,"min");
lf[275]=C_h_intern(&lf[275],4,"dump");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[277]=C_h_intern(&lf[277],13,"\003syspeek-byte");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[279]=C_h_intern(&lf[279],10,"write-char");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[281]=C_h_intern(&lf[281],5,"fxmod");
lf[282]=C_h_intern(&lf[282],11,"\003csideldups");
lf[283]=C_h_intern(&lf[283],6,"equal\077");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[292]=C_h_intern(&lf[292],16,"\003sysstring->list");
lf[293]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-case-insensitive\376\003\000\000\002\376B\000"
"\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000"
"\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\022-require-extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376"
"\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release"
"\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-print\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[294]=C_h_intern(&lf[294],7,"\003csirun");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[296]=C_h_intern(&lf[296],8,"\003syslist");
lf[297]=C_h_intern(&lf[297],17,"open-input-string");
lf[298]=C_h_intern(&lf[298],4,"repl");
lf[299]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[308]=C_h_intern(&lf[308],22,"\004corerequire-extension");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[313]=C_h_intern(&lf[313],8,"for-each");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[317]=C_h_intern(&lf[317],4,"main");
lf[318]=C_h_intern(&lf[318],22,"command-line-arguments");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[320]=C_h_intern(&lf[320],18,"\003sysstandard-error");
lf[321]=C_h_intern(&lf[321],8,"\003sysload");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[325]=C_h_intern(&lf[325],17,"\003sysstring-append");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[327]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[328]=C_h_intern(&lf[328],13,"symbol-escape");
lf[329]=C_h_intern(&lf[329],20,"parentheses-synonyms");
lf[330]=C_h_intern(&lf[330],13,"keyword-style");
lf[331]=C_h_intern(&lf[331],5,"\000none");
lf[332]=C_h_intern(&lf[332],14,"case-sensitive");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[334]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000*Disabled support for parentheses synonyms\012");
lf[338]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[340]=C_h_intern(&lf[340],7,"\000prefix");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[343]=C_h_intern(&lf[343],7,"\000suffix");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[345]=C_h_intern(&lf[345],8,"string=\077");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[348]=C_h_intern(&lf[348],17,"register-feature!");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[351]=C_h_intern(&lf[351],16,"case-insensitive");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[353]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[354]=C_h_intern(&lf[354],12,"load-verbose");
lf[355]=C_h_intern(&lf[355],20,"\003syswarnings-enabled");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[357]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[359]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[360]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[361]=C_h_intern(&lf[361],20,"\003syseval-debug-level");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[365]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[366]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[367]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[368]=C_h_intern(&lf[368],20,"\003syswindows-platform");
lf[369]=C_h_intern(&lf[369],6,"script");
lf[370]=C_h_intern(&lf[370],12,"program-name");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[374]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-k\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[376]=C_h_intern(&lf[376],17,"get-output-string");
lf[377]=C_h_intern(&lf[377],18,"open-output-string");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[379]=C_h_intern(&lf[379],7,"reverse");
lf[380]=C_h_intern(&lf[380],22,"with-exception-handler");
lf[381]=C_h_intern(&lf[381],30,"call-with-current-continuation");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[383]=C_h_intern(&lf[383],25,"\003sysimplicit-exit-handler");
lf[384]=C_h_intern(&lf[384],11,"make-vector");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[386]=C_h_intern(&lf[386],11,"repl-prompt");
C_register_lf2(lf,387,create_ptable());
t2=C_mutate(&lf[0] /* (set! c270 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1614 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1617 in k1614 */
static void C_ccall f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1620 in k1617 in k1614 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1640,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1640,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant46 ...) */,lf[3]);
t3=C_set_block_item(lf[4] /* repl-print-length-limit */,0,C_fix(2048));
t4=(C_word)C_a_i_cons(&a,2,lf[5],C_retrieve(lf[6]));
t5=C_mutate((C_word*)lf[6]+1 /* (set! features ...) */,t4);
t6=C_mutate((C_word*)lf[7]+1 /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1650,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[14]+1 /* (set! print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1678,tmp=(C_word)a,a+=2,tmp));
t8=*((C_word*)lf[21]+1);
t9=*((C_word*)lf[22]+1);
t10=C_retrieve(lf[23]);
t11=C_mutate((C_word*)lf[23]+1 /* (set! user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1694,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1727,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[28]+1);
t14=C_mutate((C_word*)lf[29]+1 /* (set! chop-separator ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1753,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t15=C_set_block_item(lf[31] /* @ */,0,C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1784,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 178  make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[170]+1)))(3,*((C_word*)lf[170]+1),t16,C_fix(256));}

/* k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1803,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[35]+1 /* (set! lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1851,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(C_word)C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t5);
t7=C_set_block_item(lf[25] /* history-count */,0,C_fix(1));
t8=C_retrieve(lf[44]);
t9=C_mutate((C_word*)lf[45]+1 /* (set! history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1957,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[26]+1 /* (set! history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1996,tmp=(C_word)a,a+=2,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t12=C_retrieve(lf[181]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5640,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 230  repl-prompt */
((C_proc3)C_retrieve_symbol_proc(lf[386]))(3,*((C_word*)lf[386]+1),t11,t13);}

/* a5639 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
/* csi.scm: 233  sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[385],C_retrieve(lf[25]));}

/* k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=C_mutate((C_word*)lf[49]+1 /* (set! tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2023,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[52] /* break-on-error */,0,C_SCHEME_FALSE);
t4=C_retrieve(lf[53]);
t5=C_mutate((C_word*)lf[53]+1 /* (set! read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2036,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2050,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 245  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[384]+1)))(4,*((C_word*)lf[384]+1),t6,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! command-table ...) */,t1);
t3=C_mutate((C_word*)lf[55]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2052,tmp=(C_word)a,a+=2,tmp));
t4=C_retrieve(lf[57]);
t5=C_retrieve(lf[58]);
t6=*((C_word*)lf[22]+1);
t7=C_retrieve(lf[59]);
t8=C_retrieve(lf[60]);
t9=*((C_word*)lf[61]+1);
t10=*((C_word*)lf[8]+1);
t11=*((C_word*)lf[62]+1);
t12=C_retrieve(lf[38]);
t13=C_retrieve(lf[63]);
t14=C_retrieve(lf[64]);
t15=C_retrieve(lf[65]);
t16=*((C_word*)lf[66]+1);
t17=*((C_word*)lf[67]+1);
t18=C_mutate((C_word*)lf[68]+1 /* (set! repl-eval-hook ...) */,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2093,a[2]=t7,a[3]=t10,a[4]=t13,a[5]=t17,a[6]=t5,a[7]=t8,a[8]=t12,a[9]=t4,a[10]=t6,a[11]=t14,a[12]=t15,tmp=(C_word)a,a+=13,tmp));
t19=C_mutate(&lf[103] /* (set! resolve-var ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2643,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[105]+1 /* (set! del ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2657,tmp=(C_word)a,a+=2,tmp));
t21=C_set_block_item(lf[69] /* trace-indent-level */,0,C_fix(0));
t22=lf[94] /* traced-procedures */ =C_SCHEME_END_OF_LIST;;
t23=lf[97] /* broken-procedures */ =C_SCHEME_END_OF_LIST;;
t24=C_mutate(&lf[143] /* (set! trace-indent ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2698,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[100]+1 /* (set! traced-procedure-entry ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2726,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[99]+1 /* (set! traced-procedure-exit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2749,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[116]+1 /* (set! do-unbreak-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3040,tmp=(C_word)a,a+=2,tmp));
t28=C_retrieve(lf[63]);
t29=C_retrieve(lf[150]);
t30=C_retrieve(lf[151]);
t31=C_retrieve(lf[152]);
t32=*((C_word*)lf[153]+1);
t33=C_mutate((C_word*)lf[80]+1 /* (set! report ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3167,a[2]=t32,a[3]=t31,a[4]=t30,a[5]=t29,a[6]=t28,tmp=(C_word)a,a+=7,tmp));
t34=C_mutate(&lf[178] /* (set! bytevector-data ...) */,lf[179]);
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 607  make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[384]+1)))(4,*((C_word*)lf[384]+1),t35,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3361,2,t0,t1);}
t2=C_mutate(&lf[180] /* (set! describer-table ...) */,t1);
t3=C_retrieve(lf[181]);
t4=C_retrieve(lf[63]);
t5=C_retrieve(lf[182]);
t6=*((C_word*)lf[61]+1);
t7=*((C_word*)lf[183]+1);
t8=*((C_word*)lf[184]+1);
t9=C_mutate((C_word*)lf[75]+1 /* (set! describe ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3363,a[2]=t3,a[3]=t7,a[4]=t6,a[5]=t8,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=C_mutate((C_word*)lf[271]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4182,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[77]+1 /* (set! dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4191,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[8]+1);
t13=*((C_word*)lf[33]+1);
t14=*((C_word*)lf[170]+1);
t15=*((C_word*)lf[279]+1);
t16=C_mutate((C_word*)lf[239]+1 /* (set! hexdump ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4352,a[2]=t12,a[3]=t15,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t17=C_mutate((C_word*)lf[282]+1 /* (set! deldups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4561,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[284] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4620,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[285] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4677,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[294]+1 /* (set! run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4822,tmp=(C_word)a,a+=2,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 1013 run */
((C_proc2)C_retrieve_symbol_proc(lf[294]))(2,*((C_word*)lf[294]+1),t21);}

/* k5630 in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5635,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5638,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[383]))(2,*((C_word*)lf[383]+1),t3);}

/* k5636 in k5630 in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5633 in k5630 in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4826,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5626,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 875  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[382]);}

/* k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5626,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[375]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3068,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 525  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t3,t2);}

/* k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3073,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3098,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[381]+1)))(3,*((C_word*)lf[381]+1),t4,t5);}

/* a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3098,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3104,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3116,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[380]))(4,*((C_word*)lf[380]+1),t1,t3,t4);}

/* a3115 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3122,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3154 in a3115 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3155r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3155r(t0,t1,t2);}}

static void C_ccall f_3155r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3161,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k617622 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3160 in a3154 in a3115 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3161,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3121 in a3115 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3130,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 533  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k3128 in a3121 in a3115 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3130,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3132(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop628 in k3128 in a3121 in a3115 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3132(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3132,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 535  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[379]+1)))(3,*((C_word*)lf[379]+1),t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3149,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 533  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t4,((C_word*)t0)[2]);}}

/* k3147 in doloop628 in k3128 in a3121 in a3115 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3149,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3132(t3,((C_word*)t0)[2],t1,t2);}

/* a3103 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3104,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3110,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* k617622 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3109 in a3103 in a3097 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3110,2,t0,t1);}
/* csi.scm: 532  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[378],((C_word*)t0)[2]);}

/* k3094 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3091 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3072 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3073,3,t0,t1,t2);}
if(C_truep((C_word)C_i_stringp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3083,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 529  open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[377]))(2,*((C_word*)lf[377]+1),t3);}}

/* k3081 in a3072 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3086,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 530  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2],t1);}

/* k3084 in k3081 in a3072 in k3066 in k5624 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 531  get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[376]))(3,*((C_word*)lf[376]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4829,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 876  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t3);}

/* k5620 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 876  canonicalize-args */
f_4677(((C_word*)t0)[2],t1);}

/* k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4829,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4832,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 878  member* */
f_4620(t4,lf[374],((C_word*)t3)[1]);}

/* k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4835,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 879  member* */
f_4620(t2,lf[373],((C_word*)((C_word*)t0)[4])[1]);}

/* k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5515,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t1);
t5=(C_word)C_i_pairp(t4);
t6=(C_word)C_i_not(t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5565,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t6)){
t8=t7;
f_5565(t8,t6);}
else{
t8=(C_word)C_i_cadr(t1);
t9=(C_word)C_i_string_length(t8);
t10=(C_word)C_i_zerop(t9);
if(C_truep(t10)){
t11=t7;
f_5565(t11,t10);}
else{
t11=(C_word)C_i_cadr(t1);
t12=(C_word)C_i_string_ref(t11,C_fix(0));
t13=t7;
f_5565(t13,(C_word)C_eqp(C_make_character(45),t12));}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5605,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5618,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 893  canonicalize-args */
f_4677(t4,((C_word*)t0)[2]);}}

/* k5616 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 893  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k5603 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(C_word)C_i_member(lf[372],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_4838(t4,(C_truep(t3)?(C_word)C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5563 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_5565(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 884  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[371]);}
else{
t2=((C_word*)t0)[2];
f_5515(2,t2,C_SCHEME_UNDEFINED);}}

/* k5513 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 885  program-name */
((C_proc3)C_retrieve_symbol_proc(lf[370]))(3,*((C_word*)lf[370]+1),t2,t3);}

/* k5516 in k5513 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* csi.scm: 886  command-line-arguments */
((C_proc3)C_retrieve_symbol_proc(lf[318]))(3,*((C_word*)lf[318]+1),t2,t3);}

/* k5519 in k5516 in k5513 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 887  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[348]))(3,*((C_word*)lf[348]+1),t2,lf[369]);}

/* k5522 in k5519 in k5516 in k5513 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[368]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 890  lookup-script-file */
((C_proc3)C_retrieve_symbol_proc(lf[35]))(3,*((C_word*)lf[35]+1),t4,t5);}
else{
t4=((C_word*)t0)[2];
f_4838(t4,C_SCHEME_UNDEFINED);}}

/* k5531 in k5522 in k5519 in k5516 in k5513 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_4838(t3,(C_word)C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_4838(t2,C_SCHEME_FALSE);}}

/* k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4838,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 896  member* */
f_4620(t2,lf[367],((C_word*)((C_word*)t0)[4])[1]);}

/* k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_4844(t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5509,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 897  member* */
f_4620(t3,lf[366],((C_word*)((C_word*)t0)[4])[1]);}}

/* k5507 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4844(t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4844(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4844,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 898  member* */
f_4620(t2,lf[365],((C_word*)((C_word*)t0)[4])[1]);}

/* k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4847,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[7]:(C_truep(t1)?t1:((C_word*)t0)[6]));
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4853,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5496,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5500,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 900  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t5,lf[364]);}

/* k5498 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[362]);
/* csi.scm: 900  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),((C_word*)t0)[2],t2,lf[363]);}

/* k5494 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4935,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5005,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=C_set_block_item(lf[361] /* eval-debug-level */,0,C_fix(0));
t6=t4;
f_5005(t6,t5);}
else{
t5=t4;
f_5005(t5,C_SCHEME_UNDEFINED);}}

/* k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_5005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5005,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5485,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 923  member* */
f_4620(t3,lf[360],((C_word*)((C_word*)t0)[6])[1]);}

/* k5483 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5485,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5488,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 924  print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5008(2,t2,C_SCHEME_UNDEFINED);}}

/* k5486 in k5483 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 925  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5011,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 926  member* */
f_4620(t3,lf[359],((C_word*)((C_word*)t0)[6])[1]);}

/* k5474 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5476,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5479,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 927  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5011(2,t2,C_SCHEME_UNDEFINED);}}

/* k5477 in k5474 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 928  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_member(lf[358],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5473,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 930  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t4);}
else{
t3=t2;
f_5014(2,t3,C_SCHEME_UNDEFINED);}}

/* k5471 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 930  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),((C_word*)t0)[2],t1);}

/* k5464 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 931  exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],C_fix(0));}

/* k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5453,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 932  member* */
f_4620(t3,lf[357],((C_word*)((C_word*)t0)[6])[1]);}

/* k5451 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5453,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5456,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5456(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 933  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[356]);}}
else{
t2=((C_word*)t0)[3];
f_5017(t2,C_SCHEME_UNDEFINED);}}

/* k5454 in k5451 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[355] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_5017(t3,t2);}

/* k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_5017(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5017,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_5020(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5447,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 936  load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[354]))(3,*((C_word*)lf[354]+1),t3,C_SCHEME_TRUE);}}

/* k5445 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 937  print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5432,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 938  member* */
f_4620(t3,lf[353],((C_word*)((C_word*)t0)[6])[1]);}

/* k5430 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5435,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5435(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 939  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[352]);}}
else{
t2=((C_word*)t0)[3];
f_5023(2,t2,C_SCHEME_UNDEFINED);}}

/* k5433 in k5430 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 940  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[348]))(3,*((C_word*)lf[348]+1),t2,lf[351]);}

/* k5436 in k5433 in k5430 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 941  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5429,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 942  collect-options */
t4=((C_word*)t0)[2];
f_4855(t4,t3,lf[350]);}

/* k5427 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[348]),t1);}

/* k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5425,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 943  collect-options */
t4=((C_word*)t0)[2];
f_4855(t4,t3,lf[349]);}

/* k5423 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[348]),t1);}

/* k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5421,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 946  collect-options */
t6=((C_word*)t0)[2];
f_4855(t6,t5,lf[347]);}

/* k5419 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k5407 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5413,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5417,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 947  collect-options */
t4=((C_word*)t0)[2];
f_4855(t4,t3,lf[346]);}

/* k5415 in k5407 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[29]),t1);}

/* k5411 in k5407 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 946  append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[258]+1)))(6,*((C_word*)lf[258]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[164]),((C_word*)t0)[2]);}

/* k5403 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 945  deldups */
((C_proc4)C_retrieve_symbol_proc(lf[282]))(4,*((C_word*)lf[282]+1),((C_word*)t0)[2],t1,*((C_word*)lf[345]+1));}

/* k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5033,2,t0,t1);}
t2=C_mutate((C_word*)lf[164]+1 /* (set! include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5036,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[339],t5))){
/* csi.scm: 955  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t3,lf[340]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[341],t6))){
/* csi.scm: 957  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t3,lf[331]);}
else{
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_string_equal_p(lf[342],t7))){
/* csi.scm: 959  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t3,lf[343]);}
else{
t8=t3;
f_5036(2,t8,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm: 953  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[344]);}}
else{
t4=t3;
f_5036(2,t4,C_SCHEME_UNDEFINED);}}

/* k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 960  member* */
f_4620(t3,lf[338],((C_word*)((C_word*)t0)[3])[1]);}

/* k5334 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5336,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5339(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 961  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[337]);}}
else{
t2=((C_word*)t0)[3];
f_5039(2,t2,C_SCHEME_UNDEFINED);}}

/* k5337 in k5334 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 962  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5324,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 963  member* */
f_4620(t3,lf[336],((C_word*)((C_word*)t0)[3])[1]);}

/* k5322 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5324,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5327(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 964  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[335]);}}
else{
t2=((C_word*)t0)[3];
f_5042(2,t2,C_SCHEME_UNDEFINED);}}

/* k5325 in k5322 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 965  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5303,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 966  member* */
f_4620(t3,lf[334],((C_word*)((C_word*)t0)[3])[1]);}

/* k5301 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5303,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5306,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5306(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 967  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[333]);}}
else{
t2=((C_word*)t0)[3];
f_5045(2,t2,C_SCHEME_UNDEFINED);}}

/* k5304 in k5301 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 968  case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t2,C_SCHEME_FALSE);}

/* k5307 in k5304 in k5301 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 969  keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[330]))(3,*((C_word*)lf[330]+1),t2,lf[331]);}

/* k5310 in k5307 in k5304 in k5301 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 970  parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t2,C_SCHEME_FALSE);}

/* k5313 in k5310 in k5307 in k5304 in k5301 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 971  symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[328]))(3,*((C_word*)lf[328]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5294,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 972  member* */
f_4620(t3,lf[327],((C_word*)((C_word*)t0)[2])[1]);}

/* k5292 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5294,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_5048(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 910  ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[325]))(4,*((C_word*)lf[325]+1),t3,lf[326],lf[2]);}}

/* k4900 in k5292 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 911  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4906 in k4900 in k5292 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 912  load */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4914,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 913  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[324]);}}

/* k4928 in k4906 in k4900 in k5292 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:lf[323]);
/* csi.scm: 913  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],t2);}

/* k4912 in k4906 in k4900 in k5292 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 914  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t2,t1,lf[322],lf[2]);}

/* k4915 in k4912 in k4906 in k4900 in k5292 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4923,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 915  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k4921 in k4915 in k4912 in k4906 in k4900 in k5292 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 916  load */
((C_proc3)C_retrieve_symbol_proc(lf[84]))(3,*((C_word*)lf[84]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5048(2,t2,C_SCHEME_UNDEFINED);}}

/* k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5053,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5053(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_5053(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5053,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5066,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 976  repl */
((C_proc2)C_retrieve_symbol_proc(lf[298]))(2,*((C_word*)lf[298]+1),t4);}}
else{
t4=(C_word)C_i_car(((C_word*)t3)[1]);
t5=(C_word)C_i_member(t4,lf[299]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5078,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_5078(2,t7,t5);}
else{
if(C_truep((C_truep((C_word)C_i_equalp(t4,lf[300]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[301]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[302]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[303]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[304]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t4,lf[305]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t7=(C_word)C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=t6;
f_5078(2,t9,t8);}
else{
t7=(C_word)C_i_string_equal_p(lf[306],t4);
t8=(C_truep(t7)?t7:(C_word)C_i_string_equal_p(lf[307],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5107,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5131,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 984  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[142]+1)))(3,*((C_word*)lf[142]+1),t10,t11);}
else{
t9=(C_word)C_i_string_equal_p(lf[309],t4);
t10=(C_truep(t9)?t9:(C_word)C_i_string_equal_p(lf[310],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_cadr(((C_word*)t3)[1]);
/* csi.scm: 987  evalstring */
f_4935(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=(C_word)C_i_string_equal_p(lf[311],t4);
t12=(C_truep(t11)?t11:(C_word)C_i_string_equal_p(lf[312],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5167,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5177,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 990  evalstring */
f_4935(t13,t14,(C_word)C_a_i_list(&a,1,t15));}
else{
t13=(C_word)C_i_string_equal_p(lf[314],t4);
t14=(C_truep(t13)?t13:(C_word)C_i_string_equal_p(lf[315],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5193,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t16=(C_word)C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5203,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 993  evalstring */
f_4935(t15,t16,(C_word)C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[2])?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5213,a[2]=t6,a[3]=t15,tmp=(C_word)a,a+=4,tmp);
t17=(C_word)C_i_equalp(lf[319],t15);
t18=(C_truep(t17)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5266,tmp=(C_word)a,a+=2,tmp):C_SCHEME_FALSE);
/* csi.scm: 997  ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[321]))(5,*((C_word*)lf[321]+1),t16,t4,t18,C_SCHEME_FALSE);}}}}}}}}

/* f_5266 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5266(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5266,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5270,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 1001 pretty-print */
((C_proc4)C_retrieve_symbol_proc(lf[65]))(4,*((C_word*)lf[65]+1),t3,t2,*((C_word*)lf[320]+1));}

/* k5268 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 1002 newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,*((C_word*)lf[320]+1));}

/* k5271 in k5268 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 1003 eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5211 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5213,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[316],((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5224,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5234,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 1006 call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_5078(2,t2,C_SCHEME_UNDEFINED);}}

/* a5233 in k5211 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5234(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5234r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5234r(t0,t1,t2);}}

static void C_ccall f_5234r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5245,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_5245(t5,(C_word)C_fixnump(t4));}
else{
t4=t3;
f_5245(t4,C_SCHEME_FALSE);}}

/* k5243 in a5233 in k5211 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_5245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_fix(0));
/* csi.scm: 1008 exit */
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),((C_word*)t0)[2],t2);}

/* a5223 in k5211 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5232,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 1006 command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[318]))(2,*((C_word*)lf[318]+1),t2);}

/* k5230 in a5223 in k5211 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main */
((C_proc3)C_retrieve_symbol_proc(lf[317]))(3,*((C_word*)lf[317]+1),((C_word*)t0)[2],t1);}

/* a5202 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5203r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5203r(t0,t1,t2);}}

static void C_ccall f_5203r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[313]+1),C_retrieve(lf[65]),t2);}

/* k5191 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5078(2,t4,t3);}

/* a5176 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5177r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5177r(t0,t1,t2);}}

static void C_ccall f_5177r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[313]+1),*((C_word*)lf[15]+1),t2);}

/* k5165 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5078(2,t4,t3);}

/* k5145 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5078(2,t4,t3);}

/* k5129 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5131,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[308],t4);
/* csi.scm: 984  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[2],t5);}

/* k5105 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5078(2,t4,t3);}

/* k5076 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5053(t3,((C_word*)t0)[2],t2);}

/* k5064 in doloop1420 in k5046 in k5043 in k5040 in k5037 in k5034 in k5031 in k5027 in k5024 in k5021 in k5018 in k5015 in k5012 in k5009 in k5006 in k5003 in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_5066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 977  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[145]+1));}

/* evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4935(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4935,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4939,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4939(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4982,tmp=(C_word)a,a+=2,tmp));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4939(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_4982 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4942,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 918  open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[297]))(3,*((C_word*)lf[297]+1),t2,((C_word*)t0)[2]);}

/* k4940 in k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 919  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,t1);}

/* k4947 in k4940 in k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4951(t5,((C_word*)t0)[2],t1);}

/* doloop1346 in k4947 in k4940 in k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4951,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4972,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4974,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[296]+1));}}

/* a4973 in doloop1346 in k4947 in k4940 in k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
/* csi.scm: 921  eval */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),t1,((C_word*)t0)[2]);}

/* k4970 in doloop1346 in k4947 in k4940 in k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 921  rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4959 in doloop1346 in k4947 in k4940 in k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4968,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 919  read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t2,((C_word*)t0)[2]);}

/* k4966 in k4959 in doloop1346 in k4947 in k4940 in k4937 in evalstring in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4951(t2,((C_word*)t0)[2],t1);}

/* collect-options in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4855,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4861(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4861,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t4))){
/* csi.scm: 906  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[295],((C_word*)t0)[3]);}
else{
t5=(C_word)C_i_cadr(t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4888,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cddr(t3);
/* csi.scm: 907  loop */
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* k4886 in loop in collect-options in k4851 in k4845 in k4842 in k4839 in k4836 in k4833 in k4830 in k4827 in k4824 in ##csi#run in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4888,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4677(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4677,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4683,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4683(t6,t1,t2);}

/* loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4683,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[286]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[287]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[288]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[289]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[290]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4705,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_block_size(t3);
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(2)))){
t6=(C_word)C_eqp(C_make_character(45),(C_word)C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=(C_word)C_i_member(t3,lf[293]);
t8=t4;
f_4705(t8,(C_word)C_i_not(t7));}
else{
t7=t4;
f_4705(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4705(t6,C_SCHEME_FALSE);}}}}

/* k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4705(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4705,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(C_make_character(58),(C_word)C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 852  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4683(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4721,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4755,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 853  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[28]+1)))(4,*((C_word*)lf[28]+1),t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 857  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4683(t4,t2,t3);}}

/* k4760 in k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4762,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4753 in k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[292]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4719 in k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4721,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4794,tmp=(C_word)a,a+=2,tmp);
t4=f_4794(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4734,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4744,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm: 856  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[291],((C_word*)t0)[2]);}}

/* a4743 in k4719 in k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4744,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k4732 in k4719 in k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4734,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4738,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* csi.scm: 855  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4683(t4,t2,t3);}

/* k4736 in k4732 in k4719 in k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 855  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4719 in k4703 in loop in canonicalize-args in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static C_word C_fcall f_4794(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_i_car(t1);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=(C_word)C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4620(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4620,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4626,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4626(t7,t1,t3);}

/* loop in member* in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4626(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4626,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4638,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4638(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4638,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 828  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4626(t4,t1,t3);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(C_word)C_i_cdr(t2);
/* csi.scm: 830  find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4561(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4561r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4561r(t0,t1,t2,t3);}}

static void C_ccall f_4561r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4565,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4565(2,t5,*((C_word*)lf[283]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_4565(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4563 in ##csi#deldups in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4570,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4570(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4563 in ##csi#deldups in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4570(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4570,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4586,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4599,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 821  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t6,t3,t4,((C_word*)t0)[2]);}}

/* k4597 in recur in k4563 in ##csi#deldups in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 821  recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4570(t2,((C_word*)t0)[2],t1);}

/* k4584 in recur in k4563 in ##csi#deldups in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4586,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4352,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4355,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4384,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4384(t10,t1,C_fix(0));}

/* doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4384,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4559,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 789  justify */
t5=((C_word*)t0)[2];
f_4355(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4557 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 789  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm: 790  write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[8]);}

/* k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4469,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4469(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4469(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4469,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 795  fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[281]+1)))(4,*((C_word*)lf[281]+1),t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 800  write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4528 in doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4552,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 801  ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4550 in k4528 in doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 801  justify */
t2=((C_word*)t0)[3];
f_4355(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4546 in k4528 in doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 801  display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4531 in k4528 in doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4469(t4,((C_word*)t0)[2],t2,t3);}

/* k4486 in doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4488,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(C_word)C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4506(t7,((C_word*)t0)[4],t3);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* doloop986 in k4486 in doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4506(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4506,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4516,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 799  display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[280],((C_word*)t0)[2]);}}

/* k4514 in doloop986 in k4486 in doloop966 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4506(t3,((C_word*)t0)[2],t2);}

/* k4398 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 802  write-char */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[6]);}

/* k4401 in k4398 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4418(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* doloop1003 in k4401 in k4398 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4418(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4418,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:(C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 806  ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4429 in doloop1003 in k4401 in k4398 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?(C_word)C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_make_character((C_word)C_unfix(t1));
/* csi.scm: 808  write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm: 809  write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4432 in k4429 in doloop1003 in k4401 in k4398 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4418(t4,((C_word*)t0)[2],t2,t3);}

/* k4404 in k4401 in k4398 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 810  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in doloop944 in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4384(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4355(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4355,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4359,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 781  number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k4357 in justify in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4375,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm: 784  make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k4373 in k4357 in justify in ##csi#hexdump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 784  string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4191r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4191r(t0,t1,t2,t3);}}

static void C_ccall f_4191r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4193,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4299,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4304,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-len891924 */
t7=t6;
f_4304(t7,t1);}
else{
t7=(C_word)C_i_car(t3);
t8=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t8))){
/* def-out892920 */
t9=t5;
f_4299(t9,t1,t7);}
else{
t9=(C_word)C_i_car(t8);
t10=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t10))){
/* body889898 */
t11=t4;
f_4193(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len891 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4304(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4304,NULL,2,t0,t1);}
/* def-out892920 */
t2=((C_word*)t0)[2];
f_4299(t2,t1,C_SCHEME_FALSE);}

/* def-out892 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4299,NULL,3,t0,t1,t2);}
/* body889898 */
t3=((C_word*)t0)[2];
f_4193(t3,t1,t2,*((C_word*)lf[145]+1));}

/* body889 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4193(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4193,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4196,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_immp(((C_word*)t0)[2]))){
/* csi.scm: 763  ##sys#error */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[275],lf[276],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4218,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 764  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[264]+1)))(3,*((C_word*)lf[264]+1),t5,((C_word*)t0)[2]);}}

/* k4216 in body889 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 764  bestlen */
t4=((C_word*)t0)[2];
f_4196(t4,t2,t3);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* csi.scm: 765  bestlen */
t4=((C_word*)t0)[2];
f_4196(t4,t2,t3);}
else{
t2=(C_word)C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_anypointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm: 767  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[277]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_4261(t6,(C_word)C_i_assq(t5,C_retrieve2(lf[178],"bytevector-data")));}
else{
t5=t4;
f_4261(t5,C_SCHEME_FALSE);}}}}}

/* k4259 in k4216 in body889 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4261,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4271,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 770  bestlen */
t5=((C_word*)t0)[2];
f_4196(t5,t3,t4);}
else{
/* csi.scm: 771  ##sys#error */
t2=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[275],lf[278],((C_word*)t0)[5]);}}

/* k4269 in k4259 in k4216 in body889 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 770  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k4240 in k4216 in body889 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 765  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k4223 in k4216 in body889 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 764  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* bestlen in body889 in ##csi#dump in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4196(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4196,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 762  min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[274]+1)))(4,*((C_word*)lf[274]+1),t1,((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* set-describer! in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4182,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4186,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 751  ##sys#check-symbol */
((C_proc5)C_retrieve_proc(*((C_word*)lf[272]+1)))(5,*((C_word*)lf[272]+1),t4,t2,lf[273],lf[271]);}

/* k4184 in set-describer! in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 752  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[4],C_retrieve2(lf[180],"describer-table"),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3363r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3363r(t0,t1,t2,t3);}}

static void C_ccall f_3363r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_3367(2,t5,*((C_word*)lf[145]+1));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_3367(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3369,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_permanentp(((C_word*)t0)[7]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4161,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 638  ##sys#block-address */
((C_proc3)C_retrieve_symbol_proc(lf[270]))(3,*((C_word*)lf[270]+1),t4,((C_word*)t0)[7]);}
else{
t4=t3;
f_3495(2,t4,C_SCHEME_UNDEFINED);}}

/* k4159 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 638  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[269],t1);}

/* k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3498,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_charp(((C_word*)t0)[9]))){
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[9]));
/* csi.scm: 641  fprintf */
t4=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[7],lf[191],((C_word*)t0)[9],t3,t3,t3);}
else{
switch(((C_word*)t0)[9]){
case C_SCHEME_TRUE:
/* csi.scm: 642  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[192]);
case C_SCHEME_FALSE:
/* csi.scm: 643  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[193]);
default:
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[9]))){
/* csi.scm: 644  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[194]);}
else{
if(C_truep((C_word)C_eofp(((C_word*)t0)[9]))){
/* csi.scm: 645  fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[195]);}
else{
t3=C_retrieve(lf[46]);
t4=(C_word)C_eqp(t3,((C_word*)t0)[9]);
if(C_truep(t4)){
/* csi.scm: 646  fprintf */
t5=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[7],lf[196]);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[9]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3564,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 648  fprintf */
t6=((C_word*)t0)[8];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[7],lf[198],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9],((C_word*)t0)[9]);}
else{
t5=(C_word)C_slot(lf[199],C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[9],t5);
if(C_truep(t6)){
/* csi.scm: 653  fprintf */
t7=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[7],lf[200]);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 654  ##sys#number? */
((C_proc3)C_retrieve_symbol_proc(lf[268]))(3,*((C_word*)lf[268]+1),t7,((C_word*)t0)[9]);}}}}}}}}

/* k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3594,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 654  fprintf */
t2=((C_word*)t0)[10];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],lf[201],((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[7]))){
/* csi.scm: 655  descseq */
t2=((C_word*)t0)[6];
f_3369(6,t2,((C_word*)t0)[9],lf[202],*((C_word*)lf[203]+1),((C_word*)t0)[5],C_fix(0));}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[7]))){
/* csi.scm: 656  descseq */
t2=((C_word*)t0)[6];
f_3369(6,t2,((C_word*)t0)[9],lf[204],*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(0));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 658  ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_symbol_proc(lf[216]))(3,*((C_word*)lf[216]+1),t3,((C_word*)t0)[7]);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[7]))){
/* csi.scm: 675  descseq */
t2=((C_word*)t0)[6];
f_3369(6,t2,((C_word*)t0)[9],lf[217],((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[7]))){
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cdr(((C_word*)t0)[7]);
/* csi.scm: 676  fprintf */
t4=((C_word*)t0)[10];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[9],((C_word*)t0)[8],lf[218],t2,t3);}
else{
if(C_truep((C_word)C_i_closurep(((C_word*)t0)[7]))){
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(3)))){
if(C_truep((C_word)C_i_memq(lf[222],C_retrieve(lf[6])))){
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=(C_word)C_slot(((C_word*)t0)[7],t4);
t6=t3;
f_3762(t6,(C_word)C_eqp(C_retrieve(lf[223]),t5));}
else{
t4=t3;
f_3762(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3762(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3802,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 686  port? */
((C_proc3)C_retrieve_symbol_proc(lf[267]))(3,*((C_word*)lf[267]+1),t2,((C_word*)t0)[7]);}}}}}}}}

/* k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3802,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_truep(t2)?lf[224]:lf[225]);
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(7));
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3821,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 692  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t6,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_memq(lf[222],C_retrieve(lf[6])))){
/* csi.scm: 693  instance? */
((C_proc3)C_retrieve_symbol_proc(lf[266]))(3,*((C_word*)lf[266]+1),t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3830(2,t3,C_SCHEME_FALSE);}}}

/* k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3830,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 694  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[219]))(4,*((C_word*)lf[219]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 695  ##sys#locative? */
((C_proc3)C_retrieve_symbol_proc(lf[265]))(3,*((C_word*)lf[265]+1),t2,((C_word*)t0)[5]);}}

/* k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 697  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep((C_word)C_anypointerp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 710  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 711  ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[264]+1)))(3,*((C_word*)lf[264]+1),t2,((C_word*)t0)[6]);}}}

/* k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 713  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],lf[241],t2);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3952,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 716  ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[243]))(3,*((C_word*)lf[243]+1),t2,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[244]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[248]:lf[249]);
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
/* csi.scm: 719  fprintf */
t7=((C_word*)t0)[3];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[4],lf[250],t2,t5,t6);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[251]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4000,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* csi.scm: 726  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[256],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[6],lf[261]))){
/* csi.scm: 736  provided? */
((C_proc3)C_retrieve_symbol_proc(lf[262]))(3,*((C_word*)lf[262]+1),t2,lf[263]);}
else{
t3=t2;
f_4067(2,t3,C_SCHEME_FALSE);}}}}}}

/* k4065 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 737  unveil */
((C_proc4)C_retrieve_symbol_proc(lf[257]))(4,*((C_word*)lf[257]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[5]))){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 740  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t3,C_retrieve2(lf[180],"describer-table"),t2);}
else{
/* csi.scm: 747  fprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],lf[260]);}}}

/* k4080 in k4065 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],t1);}
else{
t2=(C_word)C_i_assq(((C_word*)t0)[4],C_retrieve2(lf[178],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(t2);
/* map */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve(lf[57]),t5);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4121,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm: 745  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[259],t4);}}}

/* k4119 in k4080 in k4065 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 746  descseq */
t2=((C_word*)t0)[3];
f_3369(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(1));}

/* k4108 in k4080 in k4065 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,C_fix(0));
/* csi.scm: 743  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[258]+1)))(4,*((C_word*)lf[258]+1),((C_word*)t0)[2],t1,t2);}

/* k4104 in k4080 in k4065 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4089 in k4080 in k4065 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4089,3,t0,t1,t2);}
/* g859860861 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3998 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a4004 in k3998 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4005,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4009,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 729  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[255],t2);}

/* k4007 in a4004 in k3998 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4018(t6,((C_word*)t0)[2],t2);}

/* loop in k4007 in a4004 in k3998 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_4018(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4018,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4028,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 732  caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[254]+1)))(3,*((C_word*)lf[254]+1),t4,t2);}}

/* k4051 in loop in k4007 in a4004 in k3998 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 733  cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[253]+1)))(3,*((C_word*)lf[253]+1),t3,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[3];
f_4028(2,t3,C_SCHEME_UNDEFINED);}}

/* k4043 in k4051 in loop in k4007 in a4004 in k3998 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* csi.scm: 733  fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[252],t1,t2);}

/* k4026 in loop in k4007 in a4004 in k3998 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* csi.scm: 734  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4018(t3,((C_word*)t0)[2],t2);}

/* k3962 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
/* csi.scm: 721  fprintf */
t4=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[247],t3);}

/* k3965 in k3962 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 722  hash-table-walk */
((C_proc4)C_retrieve_symbol_proc(lf[246]))(4,*((C_word*)lf[246]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3971 in k3965 in k3962 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3972,4,t0,t1,t2,t3);}
/* csi.scm: 724  fprintf */
t4=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t4))(6,t4,t1,((C_word*)t0)[2],lf[245],t2,t3);}

/* k3950 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 716  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[242],t1);}

/* k3937 in k3931 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 714  hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[239]))(6,*((C_word*)lf[239]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[240]+1),((C_word*)t0)[2]);}

/* k3925 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 710  fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[238],t1);}

/* k3844 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3857,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_3857(t5,lf[228]);
case C_fix(1):
t5=t4;
f_3857(t5,lf[229]);
case C_fix(2):
t5=t4;
f_3857(t5,lf[230]);
case C_fix(3):
t5=t4;
f_3857(t5,lf[231]);
case C_fix(4):
t5=t4;
f_3857(t5,lf[232]);
case C_fix(5):
t5=t4;
f_3857(t5,lf[233]);
case C_fix(6):
t5=t4;
f_3857(t5,lf[234]);
case C_fix(7):
t5=t4;
f_3857(t5,lf[235]);
case C_fix(8):
t5=t4;
f_3857(t5,lf[236]);
default:
t5=(C_word)C_eqp(t3,C_fix(9));
t6=t4;
f_3857(t6,(C_truep(t5)?lf[237]:C_SCHEME_UNDEFINED));}}

/* k3855 in k3844 in k3837 in k3828 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3857(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 696  fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[227],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3819 in k3800 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 687  fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[226],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3760 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3762,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm: 682  describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[219]))(4,*((C_word*)lf[219]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3776,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 684  ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[221]))(4,*((C_word*)lf[221]+1),t3,((C_word*)t0)[5],C_fix(0));}}

/* k3774 in k3760 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 684  sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[220],t1);}

/* k3770 in k3760 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 683  descseq */
t2=((C_word*)t0)[3];
f_3369(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[203]+1),*((C_word*)lf[205]+1),C_fix(1));}

/* k3716 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3624(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm: 658  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[215],((C_word*)t0)[2]);}}

/* k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3698,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_subbyte(t4,C_fix(0));
t6=t3;
f_3698(t6,(C_word)C_eqp(C_fix(0),t5));}
else{
t4=t3;
f_3698(t4,C_SCHEME_FALSE);}}

/* k3696 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3698(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 660  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),((C_word*)t0)[3],lf[214],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3627(2,t2,C_SCHEME_UNDEFINED);}}

/* k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3695,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 662  ##sys#interned-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),t3,((C_word*)t0)[5]);}

/* k3693 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(C_truep(t1)?lf[209]:lf[210]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3692,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 663  ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t3,((C_word*)t0)[2]);}

/* k3690 in k3693 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 661  fprintf */
t2=((C_word*)t0)[5];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[211],((C_word*)t0)[2],t1);}

/* k3628 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3630,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[4];
f_3498(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3642,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 666  display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[8]+1)))(4,*((C_word*)lf[8]+1),t3,lf[208],((C_word*)t0)[3]);}}

/* k3640 in k3628 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3642,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3647(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop781 in k3640 in k3628 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3647(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3647,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3657,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* csi.scm: 669  fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[3],lf[207],t4);}}

/* k3655 in doloop781 in k3640 in k3628 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 670  ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),t2,C_fix(1000),t3);}

/* a3671 in k3655 in doloop781 in k3640 in k3628 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* csi.scm: 673  write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[62]+1)))(4,*((C_word*)lf[62]+1),t1,t2,((C_word*)t0)[2]);}

/* k3658 in k3655 in doloop781 in k3640 in k3628 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3663,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 674  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}

/* k3661 in k3658 in k3655 in doloop781 in k3640 in k3628 in k3625 in k3622 in k3592 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3647(t3,((C_word*)t0)[2],t2);}

/* k3562 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=(C_word)C_make_character((C_word)C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)t0)[5],C_fix(65536)))){
/* csi.scm: 650  fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[197],t2);}
else{
t4=t3;
f_3570(2,t4,C_SCHEME_UNDEFINED);}}

/* k3568 in k3562 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 651  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[145]+1));}

/* k3496 in k3493 in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3369,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3492,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 618  plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3492,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm: 619  fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[190],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_3376(2,t4,C_SCHEME_UNDEFINED);}}

/* k3374 in k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_3381(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k3374 in k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3381(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3381,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm: 623  fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[185],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3404,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm: 625  pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k3402 in loop1 in k3374 in k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(C_word)C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_3413(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k3402 in loop1 in k3374 in k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3413(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3413,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 628  fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[189],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3477,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm: 635  pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k3475 in loop2 in k3402 in loop1 in k3374 in k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=(C_word)C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm: 635  loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3413(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm: 636  loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3413(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k3421 in loop2 in k3402 in loop1 in k3374 in k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=(C_word)C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(2));
t5=(C_truep(t4)?lf[186]:lf[187]);
/* csi.scm: 630  fprintf */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,((C_word*)t0)[2],lf[188],t3,t5);}
else{
/* csi.scm: 633  newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[2]);}}

/* k3424 in k3421 in loop2 in k3402 in loop1 in k3374 in k3490 in descseq in k3365 in ##csi#describe in k3359 in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm: 634  loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3381(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3167r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3167r(t0,t1,t2);}}

static void C_ccall f_3167r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3175,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=t3;
f_3175(2,t4,(C_word)C_i_vector_ref(t2,C_fix(0)));}
else{
/* csi.scm: 547  current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 547  with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 549  gc */
((C_proc2)C_retrieve_symbol_proc(lf[177]))(2,*((C_word*)lf[177]+1),t2);}

/* k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 550  ##sys#symbol-table-info */
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t2);}

/* k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 551  memory-statistics */
((C_proc2)C_retrieve_symbol_proc(lf[175]))(2,*((C_word*)lf[175]+1),t2);}

/* k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3189,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 553  printf */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[174]);}

/* k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3306,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3339,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3343,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3347,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t7=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[173]),C_retrieve(lf[6]));}

/* k3345 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 561  sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[172]+1));}

/* k3341 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 561  chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k3337 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3305 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3306,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3310,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 556  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t3,lf[171]);}

/* k3308 in a3305 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a3314 in k3308 in a3305 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3315,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3323,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* csi.scm: 559  make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[170]+1)))(4,*((C_word*)lf[170]+1),t3,t6,C_make_character(32));}

/* k3321 in a3314 in k3308 in a3305 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 559  printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[169],((C_word*)t0)[2],t1);}

/* k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm: 573  machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[168]))(2,*((C_word*)lf[168]+1),t3);}

/* k3233 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[157]:lf[158]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* csi.scm: 575  software-type */
((C_proc2)C_retrieve_symbol_proc(lf[167]))(2,*((C_word*)lf[167]+1),t4);}

/* k3241 in k3233 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3247,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* csi.scm: 576  software-version */
((C_proc2)C_retrieve_symbol_proc(lf[166]))(2,*((C_word*)lf[166]+1),t2);}

/* k3245 in k3241 in k3233 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* csi.scm: 577  build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[165]))(2,*((C_word*)lf[165]+1),t2);}

/* k3249 in k3245 in k3241 in k3233 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3255,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
/* csi.scm: 579  shorten */
f_3189(t2,t3);}

/* k3253 in k3249 in k3245 in k3241 in k3233 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3259,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(1));
/* csi.scm: 580  shorten */
f_3189(t2,t3);}

/* k3257 in k3253 in k3249 in k3245 in k3241 in k3233 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=(C_word)C_i_vector_ref(((C_word*)t0)[11],C_fix(2));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(0));
t4=(C_word)C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[159]:lf[160]);
t6=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_vector_ref(((C_word*)t0)[10],C_fix(2));
t8=(C_word)C_fudge(C_fix(18));
t9=(C_word)C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[161]:lf[162]);
/* csi.scm: 562  printf */
t11=((C_word*)t0)[9];
((C_proc17)C_retrieve_proc(t11))(17,t11,((C_word*)t0)[8],lf[163],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_retrieve(lf[164]),((C_word*)t0)[2],t1,t2,t3,t5,t6,t7,t10);}

/* k3208 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 587  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k3211 in k3208 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(14)))){
/* csi.scm: 588  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[156]);}
else{
t3=t2;
f_3216(2,t3,C_SCHEME_UNDEFINED);}}

/* k3214 in k3211 in k3208 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fudge(C_fix(15)))){
/* csi.scm: 589  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[155]);}
else{
t3=t2;
f_3219(2,t3,C_SCHEME_UNDEFINED);}}

/* k3217 in k3214 in k3211 in k3208 in k3205 in k3202 in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_3189(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3189,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3197,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm: 552  truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[154]+1)))(3,*((C_word*)lf[154]+1),t3,t4);}

/* k3195 in shorten in k3185 in k3182 in k3179 in a3176 in k3173 in ##csi#report in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_divide(&a,2,t1,C_fix(100)));}

/* do-unbreak-all in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3044,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3050,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[97],"broken-procedures"));}

/* a3049 in do-unbreak-all in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3050,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t3,C_fix(0),t4));}

/* k3042 in do-unbreak-all in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[97] /* broken-procedures */ =C_SCHEME_END_OF_LIST;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[46]));}

/* ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2749,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2754,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 429  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t4,C_retrieve(lf[69]));}

/* k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2754,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! trace-indent-level ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 430  trace-indent */
f_2698(t3);}

/* k2755 in k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 431  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t2,((C_word*)t0)[2]);}

/* k2758 in k2755 in k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 432  display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[149]);}

/* k2761 in k2758 in k2755 in k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2774,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2773 in k2761 in k2758 in k2755 in k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2774,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2778,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 435  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t3,t2);}

/* k2776 in a2773 in k2761 in k2758 in k2755 in k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),*((C_word*)lf[145]+1));}

/* k2764 in k2761 in k2758 in k2755 in k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 438  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k2767 in k2764 in k2761 in k2758 in k2755 in k2752 in ##csi#traced-procedure-exit in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 439  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[146]+1)))(2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* ##csi#traced-procedure-entry in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2726,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2730,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 421  trace-indent */
f_2698(t4);}

/* k2728 in ##csi#traced-procedure-entry in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 422  add1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t2,C_retrieve(lf[69]));}

/* k2732 in k2728 in ##csi#traced-procedure-entry in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2734,2,t0,t1);}
t2=C_mutate((C_word*)lf[69]+1 /* (set! trace-indent-level ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2737,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
/* csi.scm: 423  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[62]+1)))(3,*((C_word*)lf[62]+1),t3,t4);}

/* k2735 in k2732 in k2728 in ##csi#traced-procedure-entry in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 424  ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[147]))(4,*((C_word*)lf[147]+1),t2,C_make_character(10),*((C_word*)lf[145]+1));}

/* k2738 in k2735 in k2732 in k2728 in ##csi#traced-procedure-entry in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 425  flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[146]+1)))(2,*((C_word*)lf[146]+1),((C_word*)t0)[2]);}

/* ##csi#trace-indent in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_2698(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2698,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2702,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),*((C_word*)lf[145]+1));}

/* k2700 in ##csi#trace-indent in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2707,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2707(t5,((C_word*)t0)[2],C_retrieve(lf[69]));}

/* doloop464 in k2700 in ##csi#trace-indent in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_2707(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2707,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_less_or_equalp(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2717,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=C_retrieve(lf[144]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(32),*((C_word*)lf[145]+1));}}

/* k2715 in doloop464 in k2700 in ##csi#trace-indent in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 415  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k2722 in k2715 in doloop464 in k2700 in ##csi#trace-indent in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_2707(t2,((C_word*)t0)[2],t1);}

/* ##csi#del in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2657,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2663,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2663(t8,t1,t3);}

/* loop in ##csi#del in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_2663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2663,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 404  tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2677 in loop in ##csi#del in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2679,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* csi.scm: 406  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2663(t4,t2,t3);}}

/* k2687 in k2677 in loop in ##csi#del in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2689,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* resolve-var in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2643,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 394  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[142]+1)))(3,*((C_word*)lf[142]+1),t3,t2);}

/* k2649 in resolve-var in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2655,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 394  ##sys#current-environment */
((C_proc2)C_retrieve_symbol_proc(lf[141]))(2,*((C_word*)lf[141]+1),t2);}

/* k2653 in k2649 in resolve-var in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 394  ##sys#strip-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2093,3,t0,t1,t2);}
t3=C_set_block_item(lf[69] /* trace-indent-level */,0,C_fix(0));
if(C_truep((C_word)C_eofp(t2))){
/* csi.scm: 269  exit */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t1);}
else{
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=t2,tmp=(C_word)a,a+=15,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=t4;
f_2110(t6,(C_word)C_eqp(lf[140],t5));}
else{
t5=t4;
f_2110(t5,C_SCHEME_FALSE);}}}

/* k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_2110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2110,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2116,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=t2,a[15]=((C_word*)t0)[13],tmp=(C_word)a,a+=16,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
/* csi.scm: 273  ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t3,C_retrieve2(lf[54],"command-table"),t2);}
else{
t4=t3;
f_2116(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2624,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[13],t2,t3);}}

/* a2623 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2624r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2624r(t0,t1,t2);}}

static void C_ccall f_2624r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2628,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 390  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2626 in a2623 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2617 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2618,2,t0,t1);}
/* csi.scm: 389  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2116,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(t1);
t4=t3;
((C_proc2)C_retrieve_proc(t4))(2,t4,t2);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[14],lf[71]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 280  read */
t4=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[14],lf[73]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 284  read */
t5=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[14],lf[74]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2178,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 289  read */
t6=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[14],lf[76]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 293  read */
t7=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[14],lf[78]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 297  read */
t8=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[14],lf[79]);
if(C_truep(t7)){
/* csi.scm: 302  report */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),((C_word*)t0)[15]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[14],lf[81]);
if(C_truep(t8)){
/* csi.scm: 303  exit */
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),((C_word*)t0)[15]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[14],lf[82]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=t10,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 305  read-line */
t12=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[14],lf[85]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t11,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 309  read-line */
t13=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[14],lf[89]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2300,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 313  read */
t13=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[14],lf[93]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2361,a[2]=t14,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 317  read-line */
t16=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[14],lf[104]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2374,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2378,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2382,a[2]=t15,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 318  read-line */
t17=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t17))(2,t17,t16);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[14],lf[108]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2399,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2403,a[2]=t16,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 319  read-line */
t18=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t18))(2,t18,t17);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[14],lf[113]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2420,a[2]=t16,tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2424,a[2]=t17,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 320  read-line */
t19=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t19))(2,t19,t18);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[14],lf[115]);
if(C_truep(t16)){
/* csi.scm: 321  do-unbreak-all */
((C_proc2)C_retrieve_symbol_proc(lf[116]))(2,*((C_word*)lf[116]+1),((C_word*)t0)[15]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[14],lf[117]);
if(C_truep(t17)){
t18=C_set_block_item(lf[118] /* break-in-thread */,0,C_SCHEME_FALSE);
t19=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[14],lf[119]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2454,a[2]=t19,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 325  read */
t21=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[14],lf[120]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[94],"traced-procedures")))){
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2486,a[2]=t20,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,*((C_word*)lf[122]+1),C_retrieve2(lf[94],"traced-procedures"));}
else{
t21=t20;
f_2463(2,t21,C_SCHEME_UNDEFINED);}}
else{
t20=(C_word)C_eqp(((C_word*)t0)[14],lf[124]);
if(C_truep(t20)){
if(C_truep(C_retrieve(lf[125]))){
t21=C_retrieve(lf[125]);
t22=C_set_block_item(lf[125] /* last-breakpoint */,0,C_SCHEME_FALSE);
/* csi.scm: 335  ##sys#break-resume */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),((C_word*)t0)[15],t21);}
else{
/* csi.scm: 336  display */
t21=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t21))(3,t21,((C_word*)t0)[15],lf[127]);}}
else{
t21=(C_word)C_eqp(((C_word*)t0)[14],lf[128]);
if(C_truep(t21)){
if(C_truep(C_retrieve(lf[129]))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
t23=(C_word)C_a_i_list(&a,1,C_retrieve(lf[129]));
/* csi.scm: 339  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t22,t23);}
else{
t22=((C_word*)t0)[15];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_UNDEFINED);}}
else{
t22=(C_word)C_eqp(((C_word*)t0)[14],lf[130]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 342  read */
t24=((C_word*)t0)[11];
((C_proc2)C_retrieve_proc(t24))(2,t24,t23);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[14],lf[132]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 346  read-line */
t25=((C_word*)t0)[8];
((C_proc2)C_retrieve_proc(t25))(2,t25,t24);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[14],lf[134]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2580,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 351  display */
t26=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t26))(3,t26,t25,lf[137]);}
else{
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2604,a[2]=((C_word*)t0)[15],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 386  printf */
t26=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t26))(4,t26,t25,lf[138],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2602 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2578 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2588,tmp=(C_word)a,a+=2,tmp);
/* csi.scm: 377  ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[136]))(4,*((C_word*)lf[136]+1),t2,t3,C_retrieve2(lf[54],"command-table"));}

/* a2587 in k2578 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2588,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm: 381  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,C_make_character(32),t4);}
else{
/* csi.scm: 382  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[15]+1)))(4,*((C_word*)lf[15]+1),t1,lf[135],t2);}}

/* k2581 in k2578 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2559 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 347  system */
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),t2,t1);}

/* k2562 in k2559 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2567,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,1,t1);
/* csi.scm: 348  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t2,t3);}

/* k2565 in k2562 in k2559 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2528 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 343  read-line */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2531 in k2528 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t4=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=(C_word)C_a_i_cons(&a,2,lf[131],t4);
/* csi.scm: 344  eval */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t2,t5);}

/* k2538 in k2531 in k2528 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 344  singlestep */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2512 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 340  describe */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],C_retrieve(lf[129]));}

/* k2484 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 328  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[123],t1);}

/* k2461 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2463,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(C_retrieve2(lf[97],"broken-procedures")))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[122]+1),C_retrieve2(lf[97],"broken-procedures"));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2474 in k2461 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 330  printf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[121],t1);}

/* k2452 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 325  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2448 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[118]+1 /* (set! break-in-thread ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2422 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 320  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2418 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2414 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3011,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a3010 in k2414 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3011,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 506  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k3013 in a3010 in k2414 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3015,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[97],"broken-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 511  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t5,t2,C_retrieve2(lf[97],"broken-procedures"),*((C_word*)lf[106]+1));}
else{
/* csi.scm: 508  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[114],t1);}}

/* k3032 in k3013 in a3010 in k2414 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[97] /* (set! broken-procedures ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2401 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 319  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2397 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2930,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[97],"broken-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2943,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2942 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2943,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 485  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2945 in a2942 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures"));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2992,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 488  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t4,lf[112],t1);}
else{
t4=t3;
f_2953(t4,C_SCHEME_UNDEFINED);}}

/* k2990 in k2945 in a2942 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2992,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 490  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t4,((C_word*)t0)[4],C_retrieve2(lf[94],"traced-procedures"),*((C_word*)lf[106]+1));}

/* k2997 in k2990 in k2945 in a2942 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t1);
t3=((C_word*)t0)[2];
f_2953(t3,t2);}

/* k2951 in k2945 in a2942 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_2953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2953,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[97],"broken-procedures"));
t5=C_mutate(&lf[97] /* (set! broken-procedures ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(0),t6));}
else{
/* csi.scm: 492  ##sys#error */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[111],((C_word*)t0)[3]);}}

/* a2973 in k2951 in k2945 in a2942 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2974r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2974r(t0,t1,t2);}}

static void C_ccall f_2974r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2978,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 498  ##sys#break-entry */
((C_proc4)C_retrieve_symbol_proc(lf[110]))(4,*((C_word*)lf[110]+1),t3,((C_word*)t0)[2],t2);}

/* k2976 in a2973 in k2951 in k2945 in a2942 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2929 in k2393 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2930,3,t0,t1,t2);}
t3=(C_word)C_i_car(C_retrieve(lf[109]));
/* csi.scm: 482  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t1,t3);}

/* k2380 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 318  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2376 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2372 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2374,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2889,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2888 in k2372 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2889,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 471  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2891 in a2888 in k2372 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures"));
if(C_truep(t2)){
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_setslot(t1,C_fix(0),t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 476  del */
((C_proc5)C_retrieve_symbol_proc(lf[105]))(5,*((C_word*)lf[105]+1),t5,t2,C_retrieve2(lf[94],"traced-procedures"),*((C_word*)lf[106]+1));}
else{
/* csi.scm: 473  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[107],t1);}}

/* k2910 in k2891 in a2888 in k2372 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2359 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 317  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2355 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[103],"resolve-var"),t1);}

/* k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2353,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t1))){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2795,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[94],"traced-procedures"));}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2808,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}}

/* a2807 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2808,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2812,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 447  expand */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),t3,t2);}

/* k2810 in a2807 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[94],"traced-procedures")))){
/* csi.scm: 449  ##sys#warn */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[96],t1);}
else{
if(C_truep((C_word)C_i_assq(t1,C_retrieve2(lf[97],"broken-procedures")))){
/* csi.scm: 451  ##sys#warn */
((C_proc3)C_retrieve_symbol_proc(lf[95]))(3,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[98]);}
else{
t2=(C_word)C_slot(t1,C_fix(0));
if(C_truep((C_word)C_i_closurep(t2))){
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,C_retrieve2(lf[94],"traced-procedures"));
t5=C_mutate(&lf[94] /* (set! traced-procedures ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2851,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t1,C_fix(0),t6));}
else{
/* csi.scm: 454  ##sys#error */
t3=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[101],t1);}}}}

/* a2850 in k2810 in a2807 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2851r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2851r(t0,t1,t2);}}

static void C_ccall f_2851r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2855,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 460  traced-procedure-entry */
((C_proc4)C_retrieve_symbol_proc(lf[100]))(4,*((C_word*)lf[100]+1),t3,((C_word*)t0)[2],t2);}

/* k2853 in a2850 in k2810 in a2807 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 461  call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2865 in k2853 in a2850 in k2810 in a2807 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2866r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2866r(t0,t1,t2);}}

static void C_ccall f_2866r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 463  traced-procedure-exit */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t3,((C_word*)t0)[2],t2);}

/* k2868 in a2865 in k2853 in a2850 in k2810 in a2807 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2859 in k2853 in a2850 in k2810 in a2807 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2794 in k2351 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2795,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
/* csi.scm: 444  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t1,t3);}

/* k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2332 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2333r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2333r(t0,t1,t2);}}

static void C_ccall f_2333r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2337,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 315  history-add */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,t2);}

/* k2335 in a2332 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2304 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2309,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[92]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2307 in a2304 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2320,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2319 in k2307 in a2304 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2320(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2320r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2320r(t0,t1,t2);}}

static void C_ccall f_2320r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2331,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[91]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2329 in a2319 in k2307 in a2304 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[90]))(3,*((C_word*)lf[90]+1),((C_word*)t0)[2],t1);}

/* k2322 in a2319 in k2307 in a2304 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2313 in k2307 in a2304 in k2298 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
/* csi.scm: 314  eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2289 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 309  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2264 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2273 in k2264 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2274,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* load-noisily278 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[88],t3);}

/* a2279 in a2273 in k2264 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2280(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2280,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 310  pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2282 in a2279 in a2273 in k2264 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 310  print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[86]+1)))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],lf[87]);}

/* k2267 in k2264 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2255 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 305  string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2245 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[84]),t1);}

/* k2248 in k2245 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2206 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2211,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 298  read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2209 in k2206 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2214,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 299  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2212 in k2209 in k2206 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2217,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 300  eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2215 in k2212 in k2209 in k2206 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 301  dump */
((C_proc4)C_retrieve_symbol_proc(lf[77]))(4,*((C_word*)lf[77]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2191 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 294  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2194 in k2191 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 295  dump */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),((C_word*)t0)[2],t1);}

/* k2176 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2178,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 290  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2179 in k2176 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 291  describe */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],t1);}

/* k2158 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 285  eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2161 in k2158 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 286  pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k2164 in k2161 in k2158 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2135 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2147,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2151,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 281  expand */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k2149 in k2135 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 281  ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1);}

/* k2145 in k2135 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 281  pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2138 in k2135 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* k2120 in k2114 in k2108 in ##sys#repl-eval-hook in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[46]));}

/* toplevel-command in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2052(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2052r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2052r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2052r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2056(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2056(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2054 in toplevel-command in k2048 in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
t2=(C_word)C_i_check_symbol_2(((C_word*)t0)[4],lf[55]);
t3=(C_truep(t1)?(C_word)C_i_check_string_2(t1,lf[55]):C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* csi.scm: 250  ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[56]))(5,*((C_word*)lf[56]+1),((C_word*)t0)[2],C_retrieve2(lf[54],"command-table"),((C_word*)t0)[4],t4);}

/* ##sys#read-prompt-hook in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2043,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 243  tty-input? */
((C_proc2)C_retrieve_symbol_proc(lf[49]))(2,*((C_word*)lf[49]+1),t2);}

/* k2041 in ##sys#read-prompt-hook in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 243  old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##csi#tty-input? in k2019 in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(C_word)C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm: 236  ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t1,*((C_word*)lf[51]+1));}}

/* ##csi#history-ref in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1996,3,t0,t1,t2);}
t3=(C_word)C_i_inexact_to_exact(t2);
t4=(C_word)C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?(C_word)C_fixnum_less_or_equal_p(t3,C_retrieve(lf[25])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_vector_ref(C_retrieve(lf[43]),t3));}
else{
/* csi.scm: 228  ##sys#error */
t6=*((C_word*)lf[47]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[48],t2);}}

/* ##csi#history-add in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1957,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[46]):(C_word)C_slot(t2,C_fix(0)));
t5=(C_word)C_block_size(C_retrieve(lf[43]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(C_retrieve(lf[25]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_times(C_fix(2),t5);
/* csi.scm: 219  vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[43]),t8);}
else{
t7=t6;
f_1967(t7,C_SCHEME_UNDEFINED);}}

/* k1979 in ##csi#history-add in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[43]+1 /* (set! history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1967(t3,t2);}

/* k1965 in ##csi#history-add in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_1967(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_vector_set(C_retrieve(lf[43]),C_retrieve(lf[25]),((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(C_retrieve(lf[25]),C_fix(1));
t4=C_mutate((C_word*)lf[25]+1 /* (set! history-count ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1851,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 192  get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,lf[42]);}

/* k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(0)))){
t3=(C_word)C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=(C_word)C_eqp(t3,C_make_character(92));
t5=(C_truep(t4)?t4:(C_word)C_eqp(t3,C_make_character(47)));
if(C_truep(t5)){
/* csi.scm: 194  addext */
f_1803(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t6=((C_word*)t0)[5];
t7=(C_word)C_block_size(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1830,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=f_1830(t8,C_fix(0));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1879,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=((C_word*)t0)[2];
t12=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t13=(C_truep(t11)?(C_word)C_i_foreign_block_argumentp(t11):C_SCHEME_FALSE);
t14=(C_word)C_i_foreign_fixnum_argumentp(C_fix(256));
t15=(C_word)stub123(t12,t13,t14);
/* ##sys#peek-nonnull-c-string */
t16=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t10,t15,C_fix(0));}
else{
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm: 198  addext */
f_1803(t10,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1894 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 200  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,lf[40],((C_word*)t0)[2]);}}

/* k1900 in k1894 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 201  string-split */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t2,((C_word*)t0)[2],lf[39]);}

/* k1907 in k1900 in k1894 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1909,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1911(t5,((C_word*)t0)[2],t1);}

/* loop in k1907 in k1900 in k1894 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_1911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1911,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* csi.scm: 203  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1936 in loop in k1907 in k1900 in k1894 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 203  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1919 in loop in k1907 in k1900 in k1894 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm: 204  addext */
f_1803(t2,t1);}

/* k1922 in k1919 in loop in k1907 in k1900 in k1894 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm: 205  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1911(t3,((C_word*)t0)[4],t2);}}

/* k1877 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1879,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 197  chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1891 in k1877 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,lf[36],((C_word*)t0)[2]);}

/* k1887 in k1877 in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 197  addext */
f_1803(((C_word*)t0)[2],t1);}

/* loop in k1853 in ##csi#lookup-script-file in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static C_word C_fcall f_1830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],t1);
t3=(C_word)C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:(C_word)C_eqp(t2,C_make_character(47)));
if(C_truep(t4)){
return(t1);}
else{
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* addext in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_1803(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1803,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1810,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 181  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t3,t2);}

/* k1808 in addext in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1810,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 183  string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,((C_word*)t0)[2],lf[34]);}}

/* k1811 in k1808 in addext in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1819,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm: 184  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[32]))(3,*((C_word*)lf[32]+1),t2,t1);}

/* k1817 in k1811 in k1808 in addext in k1782 in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1753,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1757,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_block_size(t2);
/* csi.scm: 166  sub1 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t3,t4);}

/* k1755 in ##csi#chop-separator in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1757,2,t0,t1);}
t2=(C_word)C_i_string_ref(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1766,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(0)))){
t4=(C_word)C_eqp(t2,C_make_character(92));
t5=t3;
f_1766(t5,(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(47))));}
else{
t4=t3;
f_1766(t4,C_SCHEME_FALSE);}}

/* k1764 in k1755 in ##csi#chop-separator in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_fcall f_1766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm: 169  substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* ##sys#sharp-number-hook in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1727,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 155  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* k1737 in ##sys#sharp-number-hook in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##sys#user-read-hook in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1694,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:(C_word)C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1715,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_fixnum_difference(C_retrieve(lf[25]),C_fix(1));
/* csi.scm: 150  history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t7);}
else{
/* csi.scm: 151  old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1713 in ##sys#user-read-hook in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,lf[24],t2));}

/* ##csi#print-banner in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1682,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 120  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[20]+1)))(2,*((C_word*)lf[20]+1),t2);}

/* k1680 in ##csi#print-banner in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1685,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 138  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,lf[19]);}

/* k1683 in k1680 in ##csi#print-banner in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 139  chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,C_SCHEME_TRUE);}

/* k1690 in k1683 in k1680 in ##csi#print-banner in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 139  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[15]+1)))(5,*((C_word*)lf[15]+1),((C_word*)t0)[2],lf[16],t1,lf[17]);}

/* ##csi#print-usage in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm: 73   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,lf[13]);}

/* k1652 in ##csi#print-usage in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_a_i_cons(&a,2,lf[10],C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[2],t4);
t6=(C_word)C_a_i_cons(&a,2,lf[11],t5);
/* csi.scm: 93   ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t3,t6);}

/* k1662 in k1652 in ##csi#print-usage in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 93   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k1655 in k1652 in ##csi#print-usage in k1638 in k1635 in k1632 in k1629 in k1626 in k1623 in k1620 in k1617 in k1614 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm: 98   display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[438] = {
{"toplevel:csi_scm",(void*)C_toplevel},
{"f_1616:csi_scm",(void*)f_1616},
{"f_1619:csi_scm",(void*)f_1619},
{"f_1622:csi_scm",(void*)f_1622},
{"f_1625:csi_scm",(void*)f_1625},
{"f_1628:csi_scm",(void*)f_1628},
{"f_1631:csi_scm",(void*)f_1631},
{"f_1634:csi_scm",(void*)f_1634},
{"f_1637:csi_scm",(void*)f_1637},
{"f_1640:csi_scm",(void*)f_1640},
{"f_1784:csi_scm",(void*)f_1784},
{"f_5640:csi_scm",(void*)f_5640},
{"f_2021:csi_scm",(void*)f_2021},
{"f_2050:csi_scm",(void*)f_2050},
{"f_3361:csi_scm",(void*)f_3361},
{"f_5632:csi_scm",(void*)f_5632},
{"f_5638:csi_scm",(void*)f_5638},
{"f_5635:csi_scm",(void*)f_5635},
{"f_4822:csi_scm",(void*)f_4822},
{"f_5626:csi_scm",(void*)f_5626},
{"f_3068:csi_scm",(void*)f_3068},
{"f_3098:csi_scm",(void*)f_3098},
{"f_3116:csi_scm",(void*)f_3116},
{"f_3155:csi_scm",(void*)f_3155},
{"f_3161:csi_scm",(void*)f_3161},
{"f_3122:csi_scm",(void*)f_3122},
{"f_3130:csi_scm",(void*)f_3130},
{"f_3132:csi_scm",(void*)f_3132},
{"f_3149:csi_scm",(void*)f_3149},
{"f_3104:csi_scm",(void*)f_3104},
{"f_3110:csi_scm",(void*)f_3110},
{"f_3096:csi_scm",(void*)f_3096},
{"f_3093:csi_scm",(void*)f_3093},
{"f_3073:csi_scm",(void*)f_3073},
{"f_3083:csi_scm",(void*)f_3083},
{"f_3086:csi_scm",(void*)f_3086},
{"f_4826:csi_scm",(void*)f_4826},
{"f_5622:csi_scm",(void*)f_5622},
{"f_4829:csi_scm",(void*)f_4829},
{"f_4832:csi_scm",(void*)f_4832},
{"f_4835:csi_scm",(void*)f_4835},
{"f_5618:csi_scm",(void*)f_5618},
{"f_5605:csi_scm",(void*)f_5605},
{"f_5565:csi_scm",(void*)f_5565},
{"f_5515:csi_scm",(void*)f_5515},
{"f_5518:csi_scm",(void*)f_5518},
{"f_5521:csi_scm",(void*)f_5521},
{"f_5524:csi_scm",(void*)f_5524},
{"f_5533:csi_scm",(void*)f_5533},
{"f_4838:csi_scm",(void*)f_4838},
{"f_4841:csi_scm",(void*)f_4841},
{"f_5509:csi_scm",(void*)f_5509},
{"f_4844:csi_scm",(void*)f_4844},
{"f_4847:csi_scm",(void*)f_4847},
{"f_5500:csi_scm",(void*)f_5500},
{"f_5496:csi_scm",(void*)f_5496},
{"f_4853:csi_scm",(void*)f_4853},
{"f_5005:csi_scm",(void*)f_5005},
{"f_5485:csi_scm",(void*)f_5485},
{"f_5488:csi_scm",(void*)f_5488},
{"f_5008:csi_scm",(void*)f_5008},
{"f_5476:csi_scm",(void*)f_5476},
{"f_5479:csi_scm",(void*)f_5479},
{"f_5011:csi_scm",(void*)f_5011},
{"f_5473:csi_scm",(void*)f_5473},
{"f_5466:csi_scm",(void*)f_5466},
{"f_5014:csi_scm",(void*)f_5014},
{"f_5453:csi_scm",(void*)f_5453},
{"f_5456:csi_scm",(void*)f_5456},
{"f_5017:csi_scm",(void*)f_5017},
{"f_5447:csi_scm",(void*)f_5447},
{"f_5020:csi_scm",(void*)f_5020},
{"f_5432:csi_scm",(void*)f_5432},
{"f_5435:csi_scm",(void*)f_5435},
{"f_5438:csi_scm",(void*)f_5438},
{"f_5023:csi_scm",(void*)f_5023},
{"f_5429:csi_scm",(void*)f_5429},
{"f_5026:csi_scm",(void*)f_5026},
{"f_5425:csi_scm",(void*)f_5425},
{"f_5029:csi_scm",(void*)f_5029},
{"f_5421:csi_scm",(void*)f_5421},
{"f_5409:csi_scm",(void*)f_5409},
{"f_5417:csi_scm",(void*)f_5417},
{"f_5413:csi_scm",(void*)f_5413},
{"f_5405:csi_scm",(void*)f_5405},
{"f_5033:csi_scm",(void*)f_5033},
{"f_5036:csi_scm",(void*)f_5036},
{"f_5336:csi_scm",(void*)f_5336},
{"f_5339:csi_scm",(void*)f_5339},
{"f_5039:csi_scm",(void*)f_5039},
{"f_5324:csi_scm",(void*)f_5324},
{"f_5327:csi_scm",(void*)f_5327},
{"f_5042:csi_scm",(void*)f_5042},
{"f_5303:csi_scm",(void*)f_5303},
{"f_5306:csi_scm",(void*)f_5306},
{"f_5309:csi_scm",(void*)f_5309},
{"f_5312:csi_scm",(void*)f_5312},
{"f_5315:csi_scm",(void*)f_5315},
{"f_5045:csi_scm",(void*)f_5045},
{"f_5294:csi_scm",(void*)f_5294},
{"f_4902:csi_scm",(void*)f_4902},
{"f_4908:csi_scm",(void*)f_4908},
{"f_4930:csi_scm",(void*)f_4930},
{"f_4914:csi_scm",(void*)f_4914},
{"f_4917:csi_scm",(void*)f_4917},
{"f_4923:csi_scm",(void*)f_4923},
{"f_5048:csi_scm",(void*)f_5048},
{"f_5053:csi_scm",(void*)f_5053},
{"f_5266:csi_scm",(void*)f_5266},
{"f_5270:csi_scm",(void*)f_5270},
{"f_5273:csi_scm",(void*)f_5273},
{"f_5213:csi_scm",(void*)f_5213},
{"f_5234:csi_scm",(void*)f_5234},
{"f_5245:csi_scm",(void*)f_5245},
{"f_5224:csi_scm",(void*)f_5224},
{"f_5232:csi_scm",(void*)f_5232},
{"f_5203:csi_scm",(void*)f_5203},
{"f_5193:csi_scm",(void*)f_5193},
{"f_5177:csi_scm",(void*)f_5177},
{"f_5167:csi_scm",(void*)f_5167},
{"f_5147:csi_scm",(void*)f_5147},
{"f_5131:csi_scm",(void*)f_5131},
{"f_5107:csi_scm",(void*)f_5107},
{"f_5078:csi_scm",(void*)f_5078},
{"f_5066:csi_scm",(void*)f_5066},
{"f_4935:csi_scm",(void*)f_4935},
{"f_4982:csi_scm",(void*)f_4982},
{"f_4939:csi_scm",(void*)f_4939},
{"f_4942:csi_scm",(void*)f_4942},
{"f_4949:csi_scm",(void*)f_4949},
{"f_4951:csi_scm",(void*)f_4951},
{"f_4974:csi_scm",(void*)f_4974},
{"f_4972:csi_scm",(void*)f_4972},
{"f_4961:csi_scm",(void*)f_4961},
{"f_4968:csi_scm",(void*)f_4968},
{"f_4855:csi_scm",(void*)f_4855},
{"f_4861:csi_scm",(void*)f_4861},
{"f_4888:csi_scm",(void*)f_4888},
{"f_4677:csi_scm",(void*)f_4677},
{"f_4683:csi_scm",(void*)f_4683},
{"f_4705:csi_scm",(void*)f_4705},
{"f_4762:csi_scm",(void*)f_4762},
{"f_4755:csi_scm",(void*)f_4755},
{"f_4721:csi_scm",(void*)f_4721},
{"f_4744:csi_scm",(void*)f_4744},
{"f_4734:csi_scm",(void*)f_4734},
{"f_4738:csi_scm",(void*)f_4738},
{"f_4794:csi_scm",(void*)f_4794},
{"f_4620:csi_scm",(void*)f_4620},
{"f_4626:csi_scm",(void*)f_4626},
{"f_4638:csi_scm",(void*)f_4638},
{"f_4561:csi_scm",(void*)f_4561},
{"f_4565:csi_scm",(void*)f_4565},
{"f_4570:csi_scm",(void*)f_4570},
{"f_4599:csi_scm",(void*)f_4599},
{"f_4586:csi_scm",(void*)f_4586},
{"f_4352:csi_scm",(void*)f_4352},
{"f_4384:csi_scm",(void*)f_4384},
{"f_4559:csi_scm",(void*)f_4559},
{"f_4394:csi_scm",(void*)f_4394},
{"f_4397:csi_scm",(void*)f_4397},
{"f_4469:csi_scm",(void*)f_4469},
{"f_4530:csi_scm",(void*)f_4530},
{"f_4552:csi_scm",(void*)f_4552},
{"f_4548:csi_scm",(void*)f_4548},
{"f_4533:csi_scm",(void*)f_4533},
{"f_4488:csi_scm",(void*)f_4488},
{"f_4506:csi_scm",(void*)f_4506},
{"f_4516:csi_scm",(void*)f_4516},
{"f_4400:csi_scm",(void*)f_4400},
{"f_4403:csi_scm",(void*)f_4403},
{"f_4418:csi_scm",(void*)f_4418},
{"f_4431:csi_scm",(void*)f_4431},
{"f_4434:csi_scm",(void*)f_4434},
{"f_4406:csi_scm",(void*)f_4406},
{"f_4409:csi_scm",(void*)f_4409},
{"f_4355:csi_scm",(void*)f_4355},
{"f_4359:csi_scm",(void*)f_4359},
{"f_4375:csi_scm",(void*)f_4375},
{"f_4191:csi_scm",(void*)f_4191},
{"f_4304:csi_scm",(void*)f_4304},
{"f_4299:csi_scm",(void*)f_4299},
{"f_4193:csi_scm",(void*)f_4193},
{"f_4218:csi_scm",(void*)f_4218},
{"f_4261:csi_scm",(void*)f_4261},
{"f_4271:csi_scm",(void*)f_4271},
{"f_4242:csi_scm",(void*)f_4242},
{"f_4225:csi_scm",(void*)f_4225},
{"f_4196:csi_scm",(void*)f_4196},
{"f_4182:csi_scm",(void*)f_4182},
{"f_4186:csi_scm",(void*)f_4186},
{"f_3363:csi_scm",(void*)f_3363},
{"f_3367:csi_scm",(void*)f_3367},
{"f_4161:csi_scm",(void*)f_4161},
{"f_3495:csi_scm",(void*)f_3495},
{"f_3594:csi_scm",(void*)f_3594},
{"f_3802:csi_scm",(void*)f_3802},
{"f_3830:csi_scm",(void*)f_3830},
{"f_3839:csi_scm",(void*)f_3839},
{"f_3933:csi_scm",(void*)f_3933},
{"f_4067:csi_scm",(void*)f_4067},
{"f_4082:csi_scm",(void*)f_4082},
{"f_4121:csi_scm",(void*)f_4121},
{"f_4110:csi_scm",(void*)f_4110},
{"f_4106:csi_scm",(void*)f_4106},
{"f_4089:csi_scm",(void*)f_4089},
{"f_4000:csi_scm",(void*)f_4000},
{"f_4005:csi_scm",(void*)f_4005},
{"f_4009:csi_scm",(void*)f_4009},
{"f_4018:csi_scm",(void*)f_4018},
{"f_4053:csi_scm",(void*)f_4053},
{"f_4045:csi_scm",(void*)f_4045},
{"f_4028:csi_scm",(void*)f_4028},
{"f_3964:csi_scm",(void*)f_3964},
{"f_3967:csi_scm",(void*)f_3967},
{"f_3972:csi_scm",(void*)f_3972},
{"f_3952:csi_scm",(void*)f_3952},
{"f_3939:csi_scm",(void*)f_3939},
{"f_3927:csi_scm",(void*)f_3927},
{"f_3846:csi_scm",(void*)f_3846},
{"f_3857:csi_scm",(void*)f_3857},
{"f_3821:csi_scm",(void*)f_3821},
{"f_3762:csi_scm",(void*)f_3762},
{"f_3776:csi_scm",(void*)f_3776},
{"f_3772:csi_scm",(void*)f_3772},
{"f_3718:csi_scm",(void*)f_3718},
{"f_3624:csi_scm",(void*)f_3624},
{"f_3698:csi_scm",(void*)f_3698},
{"f_3627:csi_scm",(void*)f_3627},
{"f_3695:csi_scm",(void*)f_3695},
{"f_3692:csi_scm",(void*)f_3692},
{"f_3630:csi_scm",(void*)f_3630},
{"f_3642:csi_scm",(void*)f_3642},
{"f_3647:csi_scm",(void*)f_3647},
{"f_3657:csi_scm",(void*)f_3657},
{"f_3672:csi_scm",(void*)f_3672},
{"f_3660:csi_scm",(void*)f_3660},
{"f_3663:csi_scm",(void*)f_3663},
{"f_3564:csi_scm",(void*)f_3564},
{"f_3570:csi_scm",(void*)f_3570},
{"f_3498:csi_scm",(void*)f_3498},
{"f_3369:csi_scm",(void*)f_3369},
{"f_3492:csi_scm",(void*)f_3492},
{"f_3376:csi_scm",(void*)f_3376},
{"f_3381:csi_scm",(void*)f_3381},
{"f_3404:csi_scm",(void*)f_3404},
{"f_3413:csi_scm",(void*)f_3413},
{"f_3477:csi_scm",(void*)f_3477},
{"f_3423:csi_scm",(void*)f_3423},
{"f_3426:csi_scm",(void*)f_3426},
{"f_3167:csi_scm",(void*)f_3167},
{"f_3175:csi_scm",(void*)f_3175},
{"f_3177:csi_scm",(void*)f_3177},
{"f_3181:csi_scm",(void*)f_3181},
{"f_3184:csi_scm",(void*)f_3184},
{"f_3187:csi_scm",(void*)f_3187},
{"f_3204:csi_scm",(void*)f_3204},
{"f_3347:csi_scm",(void*)f_3347},
{"f_3343:csi_scm",(void*)f_3343},
{"f_3339:csi_scm",(void*)f_3339},
{"f_3306:csi_scm",(void*)f_3306},
{"f_3310:csi_scm",(void*)f_3310},
{"f_3315:csi_scm",(void*)f_3315},
{"f_3323:csi_scm",(void*)f_3323},
{"f_3207:csi_scm",(void*)f_3207},
{"f_3235:csi_scm",(void*)f_3235},
{"f_3243:csi_scm",(void*)f_3243},
{"f_3247:csi_scm",(void*)f_3247},
{"f_3251:csi_scm",(void*)f_3251},
{"f_3255:csi_scm",(void*)f_3255},
{"f_3259:csi_scm",(void*)f_3259},
{"f_3210:csi_scm",(void*)f_3210},
{"f_3213:csi_scm",(void*)f_3213},
{"f_3216:csi_scm",(void*)f_3216},
{"f_3219:csi_scm",(void*)f_3219},
{"f_3189:csi_scm",(void*)f_3189},
{"f_3197:csi_scm",(void*)f_3197},
{"f_3040:csi_scm",(void*)f_3040},
{"f_3050:csi_scm",(void*)f_3050},
{"f_3044:csi_scm",(void*)f_3044},
{"f_2749:csi_scm",(void*)f_2749},
{"f_2754:csi_scm",(void*)f_2754},
{"f_2757:csi_scm",(void*)f_2757},
{"f_2760:csi_scm",(void*)f_2760},
{"f_2763:csi_scm",(void*)f_2763},
{"f_2774:csi_scm",(void*)f_2774},
{"f_2778:csi_scm",(void*)f_2778},
{"f_2766:csi_scm",(void*)f_2766},
{"f_2769:csi_scm",(void*)f_2769},
{"f_2726:csi_scm",(void*)f_2726},
{"f_2730:csi_scm",(void*)f_2730},
{"f_2734:csi_scm",(void*)f_2734},
{"f_2737:csi_scm",(void*)f_2737},
{"f_2740:csi_scm",(void*)f_2740},
{"f_2698:csi_scm",(void*)f_2698},
{"f_2702:csi_scm",(void*)f_2702},
{"f_2707:csi_scm",(void*)f_2707},
{"f_2717:csi_scm",(void*)f_2717},
{"f_2724:csi_scm",(void*)f_2724},
{"f_2657:csi_scm",(void*)f_2657},
{"f_2663:csi_scm",(void*)f_2663},
{"f_2679:csi_scm",(void*)f_2679},
{"f_2689:csi_scm",(void*)f_2689},
{"f_2643:csi_scm",(void*)f_2643},
{"f_2651:csi_scm",(void*)f_2651},
{"f_2655:csi_scm",(void*)f_2655},
{"f_2093:csi_scm",(void*)f_2093},
{"f_2110:csi_scm",(void*)f_2110},
{"f_2624:csi_scm",(void*)f_2624},
{"f_2628:csi_scm",(void*)f_2628},
{"f_2618:csi_scm",(void*)f_2618},
{"f_2116:csi_scm",(void*)f_2116},
{"f_2604:csi_scm",(void*)f_2604},
{"f_2580:csi_scm",(void*)f_2580},
{"f_2588:csi_scm",(void*)f_2588},
{"f_2583:csi_scm",(void*)f_2583},
{"f_2561:csi_scm",(void*)f_2561},
{"f_2564:csi_scm",(void*)f_2564},
{"f_2567:csi_scm",(void*)f_2567},
{"f_2530:csi_scm",(void*)f_2530},
{"f_2533:csi_scm",(void*)f_2533},
{"f_2540:csi_scm",(void*)f_2540},
{"f_2514:csi_scm",(void*)f_2514},
{"f_2486:csi_scm",(void*)f_2486},
{"f_2463:csi_scm",(void*)f_2463},
{"f_2476:csi_scm",(void*)f_2476},
{"f_2454:csi_scm",(void*)f_2454},
{"f_2450:csi_scm",(void*)f_2450},
{"f_2424:csi_scm",(void*)f_2424},
{"f_2420:csi_scm",(void*)f_2420},
{"f_2416:csi_scm",(void*)f_2416},
{"f_3011:csi_scm",(void*)f_3011},
{"f_3015:csi_scm",(void*)f_3015},
{"f_3034:csi_scm",(void*)f_3034},
{"f_2403:csi_scm",(void*)f_2403},
{"f_2399:csi_scm",(void*)f_2399},
{"f_2395:csi_scm",(void*)f_2395},
{"f_2943:csi_scm",(void*)f_2943},
{"f_2947:csi_scm",(void*)f_2947},
{"f_2992:csi_scm",(void*)f_2992},
{"f_2999:csi_scm",(void*)f_2999},
{"f_2953:csi_scm",(void*)f_2953},
{"f_2974:csi_scm",(void*)f_2974},
{"f_2978:csi_scm",(void*)f_2978},
{"f_2930:csi_scm",(void*)f_2930},
{"f_2382:csi_scm",(void*)f_2382},
{"f_2378:csi_scm",(void*)f_2378},
{"f_2374:csi_scm",(void*)f_2374},
{"f_2889:csi_scm",(void*)f_2889},
{"f_2893:csi_scm",(void*)f_2893},
{"f_2912:csi_scm",(void*)f_2912},
{"f_2361:csi_scm",(void*)f_2361},
{"f_2357:csi_scm",(void*)f_2357},
{"f_2353:csi_scm",(void*)f_2353},
{"f_2808:csi_scm",(void*)f_2808},
{"f_2812:csi_scm",(void*)f_2812},
{"f_2851:csi_scm",(void*)f_2851},
{"f_2855:csi_scm",(void*)f_2855},
{"f_2866:csi_scm",(void*)f_2866},
{"f_2870:csi_scm",(void*)f_2870},
{"f_2860:csi_scm",(void*)f_2860},
{"f_2795:csi_scm",(void*)f_2795},
{"f_2300:csi_scm",(void*)f_2300},
{"f_2333:csi_scm",(void*)f_2333},
{"f_2337:csi_scm",(void*)f_2337},
{"f_2305:csi_scm",(void*)f_2305},
{"f_2309:csi_scm",(void*)f_2309},
{"f_2320:csi_scm",(void*)f_2320},
{"f_2331:csi_scm",(void*)f_2331},
{"f_2324:csi_scm",(void*)f_2324},
{"f_2314:csi_scm",(void*)f_2314},
{"f_2291:csi_scm",(void*)f_2291},
{"f_2266:csi_scm",(void*)f_2266},
{"f_2274:csi_scm",(void*)f_2274},
{"f_2280:csi_scm",(void*)f_2280},
{"f_2284:csi_scm",(void*)f_2284},
{"f_2269:csi_scm",(void*)f_2269},
{"f_2257:csi_scm",(void*)f_2257},
{"f_2247:csi_scm",(void*)f_2247},
{"f_2250:csi_scm",(void*)f_2250},
{"f_2208:csi_scm",(void*)f_2208},
{"f_2211:csi_scm",(void*)f_2211},
{"f_2214:csi_scm",(void*)f_2214},
{"f_2217:csi_scm",(void*)f_2217},
{"f_2193:csi_scm",(void*)f_2193},
{"f_2196:csi_scm",(void*)f_2196},
{"f_2178:csi_scm",(void*)f_2178},
{"f_2181:csi_scm",(void*)f_2181},
{"f_2160:csi_scm",(void*)f_2160},
{"f_2163:csi_scm",(void*)f_2163},
{"f_2166:csi_scm",(void*)f_2166},
{"f_2137:csi_scm",(void*)f_2137},
{"f_2151:csi_scm",(void*)f_2151},
{"f_2147:csi_scm",(void*)f_2147},
{"f_2140:csi_scm",(void*)f_2140},
{"f_2122:csi_scm",(void*)f_2122},
{"f_2052:csi_scm",(void*)f_2052},
{"f_2056:csi_scm",(void*)f_2056},
{"f_2036:csi_scm",(void*)f_2036},
{"f_2043:csi_scm",(void*)f_2043},
{"f_2023:csi_scm",(void*)f_2023},
{"f_1996:csi_scm",(void*)f_1996},
{"f_1957:csi_scm",(void*)f_1957},
{"f_1981:csi_scm",(void*)f_1981},
{"f_1967:csi_scm",(void*)f_1967},
{"f_1851:csi_scm",(void*)f_1851},
{"f_1855:csi_scm",(void*)f_1855},
{"f_1896:csi_scm",(void*)f_1896},
{"f_1902:csi_scm",(void*)f_1902},
{"f_1909:csi_scm",(void*)f_1909},
{"f_1911:csi_scm",(void*)f_1911},
{"f_1938:csi_scm",(void*)f_1938},
{"f_1921:csi_scm",(void*)f_1921},
{"f_1924:csi_scm",(void*)f_1924},
{"f_1879:csi_scm",(void*)f_1879},
{"f_1893:csi_scm",(void*)f_1893},
{"f_1889:csi_scm",(void*)f_1889},
{"f_1830:csi_scm",(void*)f_1830},
{"f_1803:csi_scm",(void*)f_1803},
{"f_1810:csi_scm",(void*)f_1810},
{"f_1813:csi_scm",(void*)f_1813},
{"f_1819:csi_scm",(void*)f_1819},
{"f_1753:csi_scm",(void*)f_1753},
{"f_1757:csi_scm",(void*)f_1757},
{"f_1766:csi_scm",(void*)f_1766},
{"f_1727:csi_scm",(void*)f_1727},
{"f_1739:csi_scm",(void*)f_1739},
{"f_1694:csi_scm",(void*)f_1694},
{"f_1715:csi_scm",(void*)f_1715},
{"f_1678:csi_scm",(void*)f_1678},
{"f_1682:csi_scm",(void*)f_1682},
{"f_1685:csi_scm",(void*)f_1685},
{"f_1692:csi_scm",(void*)f_1692},
{"f_1650:csi_scm",(void*)f_1650},
{"f_1654:csi_scm",(void*)f_1654},
{"f_1664:csi_scm",(void*)f_1664},
{"f_1657:csi_scm",(void*)f_1657},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
