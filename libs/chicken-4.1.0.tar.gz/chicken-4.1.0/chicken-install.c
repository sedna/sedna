/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:40
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: chicken-install.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -no-lambda-info -inline -local -ignore-repository -output-file chicken-install.c
   used units: library eval data_structures ports extras srfi_69 srfi_1 posix data_structures utils regex ports extras srfi_13 files chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[243];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_996)
static void C_ccall f_996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1005)
static void C_ccall f_1005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1011)
static void C_ccall f_1011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1023)
static void C_ccall f_1023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_ccall f_1032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_ccall f_1038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3058)
static void C_ccall f_3058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3064)
static void C_ccall f_3064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1094)
static void C_ccall f_1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_fcall f_2367(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_fcall f_2372(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2462)
static void C_fcall f_2462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_fcall f_2815(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2917)
static void C_ccall f_2917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2904)
static void C_ccall f_2904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2837)
static void C_ccall f_2837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2758)
static void C_ccall f_2758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_ccall f_1185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2614)
static void C_ccall f_2614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2577)
static void C_ccall f_2577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2581)
static void C_ccall f_2581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2432)
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2391)
static void C_ccall f_2391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1950)
static void C_ccall f_1950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2032)
static void C_ccall f_2032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2035)
static void C_ccall f_2035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2001)
static void C_ccall f_2001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2096)
static void C_ccall f_2096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2306)
static void C_ccall f_2306r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2250)
static void C_ccall f_2250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2184)
static void C_ccall f_2184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2219)
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2133)
static void C_ccall f_2133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3019)
static void C_ccall f_3019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3025)
static void C_ccall f_3025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_fcall f_2353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_fcall f_2331(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_fcall f_2071(C_word t0) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_fcall f_1704(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1886)
static void C_ccall f_1886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_fcall f_1579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_fcall f_1581(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1559)
static void C_ccall f_1559r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_fcall f_1493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_fcall f_1505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1817)
static void C_ccall f_1817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_ccall f_1810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_ccall f_1750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_fcall f_1451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_fcall f_1247(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1303)
static void C_fcall f_1303(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1290)
static void C_ccall f_1290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_fcall f_1287(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_fcall f_1191(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1201)
static void C_fcall f_1201(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2367)
static void C_fcall trf_2367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2367(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2367(t0,t1);}

C_noret_decl(trf_2372)
static void C_fcall trf_2372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2372(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2372(t0,t1,t2,t3);}

C_noret_decl(trf_2462)
static void C_fcall trf_2462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2462(t0,t1);}

C_noret_decl(trf_2815)
static void C_fcall trf_2815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2815(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2815(t0,t1);}

C_noret_decl(trf_2353)
static void C_fcall trf_2353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2353(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2353(t0,t1);}

C_noret_decl(trf_2331)
static void C_fcall trf_2331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2331(t0,t1);}

C_noret_decl(trf_2071)
static void C_fcall trf_2071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2071(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_2071(t0);}

C_noret_decl(trf_1704)
static void C_fcall trf_1704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1704(t0,t1);}

C_noret_decl(trf_1579)
static void C_fcall trf_1579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1579(t0,t1);}

C_noret_decl(trf_1581)
static void C_fcall trf_1581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1581(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1581(t0,t1,t2);}

C_noret_decl(trf_1493)
static void C_fcall trf_1493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1493(t0,t1);}

C_noret_decl(trf_1505)
static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1505(t0,t1);}

C_noret_decl(trf_1451)
static void C_fcall trf_1451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1451(t0,t1);}

C_noret_decl(trf_1247)
static void C_fcall trf_1247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1247(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1247(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1303)
static void C_fcall trf_1303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1303(t0,t1);}

C_noret_decl(trf_1287)
static void C_fcall trf_1287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1287(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1287(t0,t1);}

C_noret_decl(trf_1191)
static void C_fcall trf_1191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1191(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1191(t0,t1);}

C_noret_decl(trf_1201)
static void C_fcall trf_1201(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1201(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1201(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1111)){
C_save(t1);
C_rereclaim2(1111*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,243);
lf[13]=C_h_intern(&lf[13],4,"http");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[18]=C_h_intern(&lf[18],7,"chicken");
lf[19]=C_h_intern(&lf[19],15,"chicken-version");
lf[20]=C_h_intern(&lf[20],7,"version");
lf[21]=C_h_intern(&lf[21],8,"->string");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[23]=C_h_intern(&lf[23],21,"extension-information");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[25]=C_h_intern(&lf[25],24,"\003syscore-library-modules");
lf[30]=C_h_intern(&lf[30],7,"reverse");
lf[31]=C_h_intern(&lf[31],10,"alist-cons");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[33]=C_h_intern(&lf[33],5,"error");
lf[34]=C_h_intern(&lf[34],13,"string-append");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[37]=C_h_intern(&lf[37],20,"setup-api#version>=\077");
lf[38]=C_h_intern(&lf[38],7,"warning");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[40]=C_h_intern(&lf[40],7,"depends");
lf[41]=C_h_intern(&lf[41],5,"needs");
lf[42]=C_h_intern(&lf[42],6,"append");
lf[43]=C_h_intern(&lf[43],12,"test-depends");
lf[44]=C_h_intern(&lf[44],26,"setup-api#remove-extension");
lf[45]=C_h_intern(&lf[45],5,"print");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[48]=C_h_intern(&lf[48],12,"\003sysfor-each");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[50]=C_h_intern(&lf[50],18,"string-intersperse");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[52]=C_h_intern(&lf[52],6,"unzip1");
lf[53]=C_h_intern(&lf[53],20,"setup-api#yes-or-no\077");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[55]=C_h_intern(&lf[55],18,"string-concatenate");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[60]=C_h_intern(&lf[60],4,"conc");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[65]=C_h_intern(&lf[65],7,"\003sysmap");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[70]=C_h_intern(&lf[70],20,"with-input-from-file");
lf[71]=C_h_intern(&lf[71],4,"read");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[75]=C_h_intern(&lf[75],12,"file-exists\077");
lf[76]=C_h_intern(&lf[76],13,"make-pathname");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[78]=C_h_intern(&lf[78],6,"delete");
lf[79]=C_h_intern(&lf[79],3,"eq\077");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[81]=C_h_intern(&lf[81],8,"location");
lf[82]=C_h_intern(&lf[82],9,"transport");
lf[83]=C_h_intern(&lf[83],9,"condition");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[88]=C_h_intern(&lf[88],5,"abort");
lf[89]=C_h_intern(&lf[89],3,"exn");
lf[90]=C_h_intern(&lf[90],10,"http-fetch");
lf[91]=C_h_intern(&lf[91],3,"net");
lf[92]=C_h_intern(&lf[92],33,"setup-download#retrieve-extension");
lf[93]=C_h_intern(&lf[93],8,"\000version");
lf[94]=C_h_intern(&lf[94],12,"\000destination");
lf[95]=C_h_intern(&lf[95],6,"\000tests");
lf[96]=C_h_intern(&lf[96],9,"\000username");
lf[97]=C_h_intern(&lf[97],9,"\000password");
lf[98]=C_h_intern(&lf[98],17,"current-directory");
lf[99]=C_h_intern(&lf[99],22,"with-exception-handler");
lf[100]=C_h_intern(&lf[100],30,"call-with-current-continuation");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[108]=C_h_intern(&lf[108],26,"setup-api#remove-directory");
lf[109]=C_h_intern(&lf[109],34,"setup-download#temporary-directory");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[112]=C_h_intern(&lf[112],6,"system");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[116]=C_h_intern(&lf[116],4,"exit");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\004\257usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012  -v   -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -l   -lo"
"cation LOCATION       install from given location instead of default\012  -t   -tra"
"nsport TRANSPORT     use given transport instead of default\012  -s   -sudo        "
"            use sudo(1) for installing or removing files\012  -r   -retrieve       "
"         only retrieve egg into current directory, don\047t install\012  -n   -no-inst"
"all              do not install, just build (implies `-keep\047)\012  -p   -prefix PRE"
"FIX           change installation prefix to PREFIX\012       -host-extension       "
"   when cross-compiling, compile extension for host\012       -test                "
"    run included test-cases, if available\012       -username USER           set us"
"ername for transports that require this\012       -password PASS           set pass"
"word for transports that require this\012  -i   -init DIRECTORY          initialize"
" empty alternative repository\012  -u   -update-db               update export data"
"base");
lf[118]=C_h_intern(&lf[118],25,"\003sysimplicit-exit-handler");
lf[119]=C_h_intern(&lf[119],19,"print-error-message");
lf[120]=C_h_intern(&lf[120],18,"current-error-port");
lf[121]=C_h_intern(&lf[121],19,"setup-api#copy-file");
lf[122]=C_h_intern(&lf[122],15,"repository-path");
lf[123]=C_h_intern(&lf[123],7,"newline");
lf[124]=C_h_intern(&lf[124],5,"write");
lf[125]=C_h_intern(&lf[125],19,"with-output-to-file");
lf[126]=C_h_intern(&lf[126],8,"string<\077");
lf[127]=C_h_intern(&lf[127],14,"symbol->string");
lf[128]=C_h_intern(&lf[128],4,"sort");
lf[129]=C_h_intern(&lf[129],18,"\003sysmodule-exports");
lf[130]=C_h_intern(&lf[130],5,"value");
lf[131]=C_h_intern(&lf[131],6,"syntax");
lf[132]=C_h_intern(&lf[132],6,"print*");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[134]=C_h_intern(&lf[134],15,"\003sysmodule-name");
lf[135]=C_h_intern(&lf[135],10,"append-map");
lf[136]=C_h_intern(&lf[136],16,"\003sysmodule-table");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[138]=C_h_intern(&lf[138],20,"\003syswarnings-enabled");
lf[139]=C_h_intern(&lf[139],7,"sprintf");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\032Failed to import from `~a\047");
lf[141]=C_h_intern(&lf[141],6,"import");
lf[142]=C_h_intern(&lf[142],4,"eval");
lf[143]=C_h_intern(&lf[143],14,"string->symbol");
lf[144]=C_h_intern(&lf[144],12,"string-match");
lf[145]=C_h_intern(&lf[145],16,"\003sysdynamic-wind");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[147]=C_h_intern(&lf[147],6,"regexp");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\034.*/([^/]+)\134.import\134.(scm|so)");
lf[149]=C_h_intern(&lf[149],36,"setup-api#create-temporary-directory");
lf[150]=C_h_intern(&lf[150],4,"glob");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\012*.import.*");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\020~a -s run.scm ~a");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[156]=C_h_intern(&lf[156],10,"directory\077");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000> -bnq -e \042(require-library setup-api)\042 -e \042(import setup-api)\042");
lf[169]=C_h_intern(&lf[169],19,"setup-api#shellpath");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\042 -e \042(installation-prefix \134\042~a\134\042)\042");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[173]=C_h_intern(&lf[173],22,"setup-api#sudo-install");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\0003 -e \042(extension-name-and-version \047(\134\042~a\134\042 \134\042~a\134\042))\042");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[182]=C_h_intern(&lf[182],13,"pathname-file");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\007*.setup");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\017regex.import.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import"
".so\376\003\000\000\002\376B\000\000\021foreign.import.so\376\003\000\000\002\376B\000\000\020scheme.import.so\376\003\000\000\002\376B\000\000\021srfi-18.import"
".so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003"
"\000\000\002\376B\000\000\010types.db\376\377\016");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\017-host-extension");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[217]=C_h_intern(&lf[217],17,"lset-intersection");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\377\016");
lf[219]=C_h_intern(&lf[219],16,"\003sysstring->list");
lf[220]=C_h_intern(&lf[220],9,"substring");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[223]=C_h_intern(&lf[223],18,"absolute-pathname\077");
lf[224]=C_h_intern(&lf[224],18,"pathname-directory");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[226]=C_h_intern(&lf[226],18,"pathname-extension");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[229]=C_h_intern(&lf[229],9,"read-file");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[231]=C_h_intern(&lf[231],12,"chicken-home");
lf[232]=C_h_intern(&lf[232],22,"command-line-arguments");
lf[233]=C_h_intern(&lf[233],17,"register-feature!");
lf[234]=C_h_intern(&lf[234],15,"chicken-install");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[236]=C_h_intern(&lf[236],17,"\003syspeek-c-string");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[238]=C_h_intern(&lf[238],24,"get-environment-variable");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[240]=C_h_intern(&lf[240],11,"\003sysrequire");
lf[241]=C_h_intern(&lf[241],9,"setup-api");
lf[242]=C_h_intern(&lf[242],14,"setup-download");
C_register_lf2(lf,243,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k988 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k991 in k988 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k994 in k991 in k988 */
static void C_ccall f_996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k997 in k994 in k991 in k988 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1005,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1011,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1023,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[240]))(3,*((C_word*)lf[240]+1),t2,lf[242]);}

/* k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1041,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[240]))(3,*((C_word*)lf[240]+1),t2,lf[241]);}

/* k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 67   get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[238]))(3,*((C_word*)lf[238]+1),t2,lf[239]);}

/* k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* chicken-install.scm: 68   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),t2,t1,lf[237]);}
else{
t3=t2;
f_1049(2,t3,C_SCHEME_FALSE);}}

/* k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1052(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[236]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1052,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*program-path* ...) */,t1);
t3=lf[1] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[2] /* main#*force* */ =C_SCHEME_FALSE;;
t5=lf[3] /* main#*prefix* */ =C_SCHEME_FALSE;;
t6=lf[4] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t7=lf[5] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t9=lf[7] /* main#*no-install* */ =C_SCHEME_FALSE;;
t10=lf[8] /* main#*username* */ =C_SCHEME_FALSE;;
t11=lf[9] /* main#*password* */ =C_SCHEME_FALSE;;
t12=lf[10] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t13=lf[11] /* main#*default-location* */ =C_SCHEME_FALSE;;
t14=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,lf[13]);
t15=C_mutate(&lf[14] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t16=C_mutate(&lf[15] /* (set! main#constant219 ...) */,lf[16]);
t17=C_mutate(&lf[17] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1191,tmp=(C_word)a,a+=2,tmp));
t18=lf[26] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t19=lf[27] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3091,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 175  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),t21,C_retrieve2(lf[0],"main#*program-path*"),lf[235]);}

/* k3089 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 175  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),((C_word*)t0)[2],t1);}

/* k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! main#*csi* ...) */,t1);
t3=C_mutate(&lf[29] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1704,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[107] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2071,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[110] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2331,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[115] /* (set! main#usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2353,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 498  register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[233]))(3,*((C_word*)lf[233]+1),t7,lf[234]);}

/* k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3030,tmp=(C_word)a,a+=2,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t3,t4);}

/* a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3030,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3036,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t1,t3,t4);}

/* a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3064,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3076 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3077r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3077r(t0,t1,t2);}}

static void C_ccall f_3077r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3083,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k908913 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3082 in a3076 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3068,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3075,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 505  command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[232]))(2,*((C_word*)lf[232]+1),t3);}

/* k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2367,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1094,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 89   chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[231]))(2,*((C_word*)lf[231]+1),t4);}

/* k1092 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 89   make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1,lf[230]);}

/* k1071 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1090,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 90   file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),t2,t1);}

/* k1088 in k1071 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 93   read-file */
((C_proc3)C_retrieve_symbol_proc(lf[229]))(3,*((C_word*)lf[229]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2367(t2,C_SCHEME_END_OF_LIST);}}

/* k1081 in k1088 in k1071 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
f_2367(t3,(C_word)C_i_pairp(C_retrieve2(lf[10],"main#*default-sources*")));}

/* k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_2367(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2367,NULL,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2372,a[2]=t5,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2372(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_2372(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2372,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2090,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 315  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[122]))(2,*((C_word*)lf[122]+1),t7);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2388,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2416,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 395  glob */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),t5,lf[184]);}
else{
t5=t4;
f_2388(2,t5,C_SCHEME_UNDEFINED);}}}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_string_equal_p(t4,lf[185]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_2462(t7,t5);}
else{
t7=(C_word)C_i_string_equal_p(t4,lf[227]);
t8=t6;
f_2462(t8,(C_truep(t7)?t7:(C_word)C_i_string_equal_p(t4,lf[228])));}}}

/* k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_2462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2462,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 417  usage */
f_2353(((C_word*)t0)[7],C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[186]))){
t2=lf[2] /* main#*force* */ =C_SCHEME_TRUE;;
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 420  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2372(t4,((C_word*)t0)[7],t3,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[187]);
t3=(C_truep(t2)?t2:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[188]));
if(C_truep(t3)){
t4=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 423  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2372(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[189]);
t5=(C_truep(t4)?t4:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[190]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 425  setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t6,C_SCHEME_TRUE);}
else{
t6=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[191]);
t7=(C_truep(t6)?t6:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[192]));
if(C_truep(t7)){
t8=lf[6] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 429  loop */
t10=((C_word*)((C_word*)t0)[4])[1];
f_2372(t10,((C_word*)t0)[7],t9,((C_word*)t0)[3]);}
else{
t8=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[193]);
t9=(C_truep(t8)?t8:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[194]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t11))){
t12=t10;
f_2544(2,t12,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 431  usage */
f_2353(t10,C_fix(1));}}
else{
t10=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[195]);
t11=(C_truep(t10)?t10:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[196]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2577,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t13=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t13))){
t14=t12;
f_2577(2,t14,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 435  usage */
f_2353(t12,C_fix(1));}}
else{
t12=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[197]);
t13=(C_truep(t12)?t12:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[198]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2614,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=t14;
f_2614(2,t16,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 439  usage */
f_2353(t14,C_fix(1));}}
else{
t14=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[199]);
t15=(C_truep(t14)?t14:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[200]));
if(C_truep(t15)){
t16=lf[1] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[7] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 445  loop */
t19=((C_word*)((C_word*)t0)[4])[1];
f_2372(t19,((C_word*)t0)[7],t18,((C_word*)t0)[3]);}
else{
t16=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[201]);
t17=(C_truep(t16)?t16:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[202]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 447  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),t19);}
else{
t18=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[203]);
t19=(C_truep(t18)?t18:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[204]));
if(C_truep(t19)){
t20=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t21=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 451  loop */
t22=((C_word*)((C_word*)t0)[4])[1];
f_2372(t22,((C_word*)t0)[7],t21,((C_word*)t0)[3]);}
else{
t20=(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[205]);
t21=(C_truep(t20)?t20:(C_word)C_i_string_equal_p(((C_word*)t0)[6],lf[206]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2701(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 453  usage */
f_2353(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[213],((C_word*)t0)[6]))){
t22=lf[5] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 458  loop */
t24=((C_word*)((C_word*)t0)[4])[1];
f_2372(t24,((C_word*)t0)[7],t23,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[214],((C_word*)t0)[6]))){
t22=lf[4] /* main#*host-extension* */ =C_SCHEME_TRUE;;
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 461  loop */
t24=((C_word*)((C_word*)t0)[4])[1];
f_2372(t24,((C_word*)t0)[7],t23,((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[215],((C_word*)t0)[6]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2758,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2758(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 463  usage */
f_2353(t22,C_fix(1));}}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[216],((C_word*)t0)[6]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t23=(C_word)C_i_cdr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t23))){
t24=t22;
f_2788(2,t24,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 467  usage */
f_2353(t22,C_fix(1));}}
else{
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2815,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_positivep(t23))){
t24=(C_word)C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t25=t22;
f_2815(t25,(C_word)C_eqp(C_make_character(45),t24));}
else{
t24=t22;
f_2815(t24,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}

/* k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_2815(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2815,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_length(((C_word*)t0)[6]);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2862,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 473  substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[220]+1)))(4,*((C_word*)lf[220]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
/* chicken-install.scm: 477  usage */
f_2353(((C_word*)t0)[4],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 478  pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[226]))(3,*((C_word*)lf[226]+1),t2,((C_word*)t0)[6]);}}

/* k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
if(C_truep((C_word)C_i_equalp(lf[221],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 479  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 493  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[144]))(4,*((C_word*)lf[144]+1),t2,lf[225],((C_word*)t0)[2]);}}

/* k2921 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2937,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(t1);
t5=(C_word)C_i_caddr(t1);
/* chicken-install.scm: 495  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t3,t4,t5,((C_word*)t0)[3]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* chicken-install.scm: 496  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2372(t4,((C_word*)t0)[4],t2,t3);}}

/* k2935 in k2921 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 495  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2372(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2876 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2901,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 484  pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[224]))(3,*((C_word*)lf[224]+1),t3,((C_word*)t0)[2]);}

/* k2899 in k2876 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2910,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 486  absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[223]))(3,*((C_word*)lf[223]+1),t3,t1);}
else{
/* chicken-install.scm: 489  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[98]))(2,*((C_word*)lf[98]+1),t2);}}

/* k2908 in k2899 in k2876 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2904(2,t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 488  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[98]))(2,*((C_word*)lf[98]+1),t2);}}

/* k2915 in k2908 in k2899 in k2876 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 488  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2902 in k2899 in k2876 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2904,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,lf[222]);
/* chicken-install.scm: 481  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k2880 in k2876 in k2958 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* chicken-install.scm: 492  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2372(t5,((C_word*)t0)[2],t3,t4);}

/* k2860 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[219]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2822 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2858,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 474  lset-intersection */
((C_proc5)C_retrieve_symbol_proc(lf[217]))(5,*((C_word*)lf[217]+1),t2,*((C_word*)lf[79]+1),lf[218],t1);}

/* k2856 in k2822 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2847,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
/* chicken-install.scm: 476  usage */
f_2353(((C_word*)t0)[5],C_fix(1));}}

/* a2846 in k2856 in k2822 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2847,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_string(&a,2,C_make_character(45),t2));}

/* k2839 in k2856 in k2822 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* chicken-install.scm: 475  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t1,t2);}

/* k2835 in k2856 in k2822 in k2813 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 475  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2372(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2786 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[9] /* (set! main#*password* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 469  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2372(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2756 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[8] /* (set! main#*username* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 465  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2372(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1158,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 111  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[122]))(2,*((C_word*)lf[122]+1),t4);}

/* k1156 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1158,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))?lf[207]:lf[208]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1164,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 115  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[45]+1)))(5,*((C_word*)lf[45]+1),t3,lf[211],((C_word*)t0)[3],lf[212]);}

/* k1162 in k1156 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[210]);}

/* a1168 in k1162 in k1156 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1169,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1177,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1189,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 118  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),t5,((C_word*)t0)[2],t2);}

/* k1187 in a1168 in k1162 in k1156 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),((C_word*)t0)[2],t1);}

/* k1179 in a1168 in k1162 in k1156 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1185,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 118  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),t2,((C_word*)t0)[2]);}

/* k1183 in k1179 in a1168 in k1162 in k1156 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  sprintf */
((C_proc6)C_retrieve_symbol_proc(lf[139]))(6,*((C_word*)lf[139]+1),((C_word*)t0)[4],lf[209],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1175 in a1168 in k1162 in k1156 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 118  $system */
f_2331(((C_word*)t0)[2],t1);}

/* k2702 in k2699 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 455  exit */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],C_fix(0));}

/* k2670 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 447  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),((C_word*)t0)[2],t1);}

/* k2663 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 448  exit */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],C_fix(0));}

/* k2612 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[3] /* (set! main#*prefix* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 441  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2372(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2575 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* chicken-install.scm: 436  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[143]+1)))(3,*((C_word*)lf[143]+1),t2,t3);}

/* k2579 in k2575 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-transport* ...) */,t1);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 437  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2372(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k2542 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[11] /* (set! main#*default-location* ...) */,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
/* chicken-install.scm: 433  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2372(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2506 in k2460 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-install.scm: 426  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2372(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2414 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2432,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 404  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t2,lf[183]);}}

/* k2445 in k2414 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 405  exit */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],C_fix(1));}

/* a2431 in k2414 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2432,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2440,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 400  pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t3,t2);}

/* k2438 in a2431 in k2414 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[180],lf[181]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_cons(&a,2,t1,t2));}

/* k2428 in k2414 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 398  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k2424 in k2414 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_2388(2,t3,t2);}

/* k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2391(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2401,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[12],"main#*default-transport*"))){
t4=t3;
f_2401(2,t4,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 408  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t3,lf[179]);}}}

/* k2399 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[11],"main#*default-location*"))){
t2=((C_word*)t0)[2];
f_2391(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 410  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],lf[178]);}}

/* k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 411  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1978,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 289  retrieve */
f_1704(t3,t1);}

/* k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1986,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}}

/* a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1986,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1990,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_caddr(t2);
/* chicken-install.scm: 293  print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[45]+1)))(7,*((C_word*)lf[45]+1),t3,lf[176],t4,C_make_character(58),t5,lf[177]);}

/* k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* chicken-install.scm: 294  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t2,lf[175],t3);}

/* k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1993,2,t0,t1);}
t2=C_retrieve(lf[98]);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=t3;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#dynamic-wind */
t8=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[2],t6,t7,t6);}

/* a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1922,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t3);
t6=(C_word)C_i_caddr(t3);
/* chicken-install.scm: 280  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t4,lf[174],t5,t6);}

/* k1920 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 281  setup-api#sudo-install */
((C_proc2)C_retrieve_symbol_proc(lf[173]))(2,*((C_word*)lf[173]+1),t2);}

/* k1962 in k1920 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(C_truep(t1)?lf[160]:lf[161]);
t3=(C_truep(C_retrieve2(lf[1],"main#*keep*"))?lf[162]:lf[163]);
t4=(C_truep(C_retrieve2(lf[7],"main#*no-install*"))?lf[164]:lf[165]);
t5=(C_truep(C_retrieve2(lf[4],"main#*host-extension*"))?lf[166]:lf[167]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_retrieve2(lf[3],"main#*prefix*"))){
/* chicken-install.scm: 285  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t6,lf[171],C_retrieve2(lf[3],"main#*prefix*"));}
else{
t7=t6;
f_1942(2,t7,lf[172]);}}

/* k1940 in k1962 in k1920 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1946,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1950,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 286  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t3,t4,t5,lf[170]);}

/* k1948 in k1940 in k1962 in k1920 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 286  setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[169]))(3,*((C_word*)lf[169]+1),((C_word*)t0)[2],t1);}

/* k1944 in k1940 in k1962 in k1920 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 277  conc */
((C_proc12)C_retrieve_symbol_proc(lf[60]))(12,*((C_word*)lf[60]+1),((C_word*)t0)[8],C_retrieve2(lf[28],"main#*csi*"),lf[168],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(32),t1);}

/* k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2017,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 297  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t2,lf[159],t1);}

/* k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 298  $system */
f_2331(t2,((C_word*)t0)[2]);}

/* k2018 in k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 300  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),t3,lf[158]);}
else{
t3=t2;
f_2026(2,t3,C_SCHEME_FALSE);}}

/* k2046 in k2018 in k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 301  directory? */
((C_proc3)C_retrieve_symbol_proc(lf[156]))(3,*((C_word*)lf[156]+1),t2,lf[157]);}
else{
t2=((C_word*)t0)[2];
f_2026(2,t2,C_SCHEME_FALSE);}}

/* k2052 in k2046 in k2018 in k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 302  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),((C_word*)t0)[2],lf[155]);}
else{
t2=((C_word*)t0)[2];
f_2026(2,t2,C_SCHEME_FALSE);}}

/* k2024 in k2018 in k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 303  current-directory */
((C_proc3)C_retrieve_symbol_proc(lf[98]))(3,*((C_word*)lf[98]+1),t2,lf[154]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2027 in k2024 in k2018 in k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2029,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 304  sprintf */
((C_proc5)C_retrieve_symbol_proc(lf[139]))(5,*((C_word*)lf[139]+1),t2,lf[153],C_retrieve2(lf[28],"main#*csi*"),t3);}

/* k2030 in k2027 in k2024 in k2018 in k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2035,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 305  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t2,lf[152],t1);}

/* k2033 in k2030 in k2027 in k2024 in k2018 in k2015 in k2012 in a2009 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 306  $system */
f_2331(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* swap566 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2001,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g569570573 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1999 in swap566 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g569570573 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2002 in k1999 in swap566 in k1991 in k1988 in a1985 in k1976 in k2396 in k2389 in k2386 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2327 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 315  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1,lf[151]);}

/* k2323 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 315  glob */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),((C_word*)t0)[2],t1);}

/* k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2093,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 316  setup-api#create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[149]))(2,*((C_word*)lf[149]+1),t2);}

/* k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2096,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 317  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),t2,t1,C_retrieve2(lf[15],"main#constant219"));}

/* k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 318  regexp */
((C_proc3)C_retrieve_symbol_proc(lf[147]))(3,*((C_word*)lf[147]+1),t2,lf[148]);}

/* k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2102,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 319  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t2,lf[146]);}

/* k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[145]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a2317 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[138]));
t3=C_mutate((C_word*)lf[138]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2240,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 323  string-match */
((C_proc4)C_retrieve_symbol_proc(lf[144]))(4,*((C_word*)lf[144]+1),t3,((C_word*)t0)[2],t2);}

/* k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2252,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t2,t3);}

/* a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2278,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t1,t3,t4);}

/* a2277 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2305 in a2277 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2306(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2306r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2306r(t0,t1,t2);}}

static void C_ccall f_2306r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2312,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k639645 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2311 in a2305 in a2277 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2283 in a2277 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2300,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 328  string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[143]+1)))(3,*((C_word*)lf[143]+1),t2,t3);}

/* k2298 in a2283 in a2277 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2300,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_cons(&a,2,lf[141],t2);
/* chicken-install.scm: 328  eval */
((C_proc3)C_retrieve_symbol_proc(lf[142]))(3,*((C_word*)lf[142]+1),((C_word*)t0)[2],t3);}

/* a2257 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2258,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k639645 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2263 in a2257 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 326  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[120]))(2,*((C_word*)lf[120]+1),t2);}

/* k2270 in a2263 in a2257 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2276,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 327  sprintf */
((C_proc4)C_retrieve_symbol_proc(lf[139]))(4,*((C_word*)lf[139]+1),t2,lf[140],((C_word*)t0)[2]);}

/* k2274 in k2270 in a2263 in a2257 in a2251 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 325  print-error-message */
((C_proc5)C_retrieve_symbol_proc(lf[119]))(5,*((C_word*)lf[119]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2248 in k2242 in a2239 in a2233 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a2228 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2229,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[138]));
t3=C_mutate((C_word*)lf[138]+1 /* (set! warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 330  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t2,lf[137]);}

/* k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2174,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 333  append-map */
((C_proc4)C_retrieve_symbol_proc(lf[135]))(4,*((C_word*)lf[135]+1),t3,t4,C_retrieve(lf[136]));}

/* a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2174,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2181,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 336  ##sys#module-name */
((C_proc3)C_retrieve_symbol_proc(lf[134]))(3,*((C_word*)lf[134]+1),t4,t3);}

/* k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2184,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 337  print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[132]+1)))(4,*((C_word*)lf[132]+1),t2,lf[133],t1);}

/* k2182 in k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2194 in k2182 in k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2195,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2203,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}

/* a2218 in a2194 in k2182 in k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2219,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[131],((C_word*)t0)[2]));}

/* k2201 in a2194 in k2182 in k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2207,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2208 in k2201 in a2194 in k2182 in k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2209,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,t3,lf[130],((C_word*)t0)[2]));}

/* k2205 in k2201 in a2194 in k2182 in k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 339  append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2188 in k2182 in k2179 in a2173 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
/* chicken-install.scm: 338  ##sys#module-exports */
((C_proc3)C_retrieve_symbol_proc(lf[129]))(3,*((C_word*)lf[129]+1),t1,((C_word*)t0)[2]);}

/* k2148 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2152,tmp=(C_word)a,a+=2,tmp);
/* chicken-install.scm: 332  sort */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),((C_word*)t0)[2],t1,t2);}

/* a2151 in k2148 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2152(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2152,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2160,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 344  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,t5);}

/* k2158 in a2151 in k2148 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2164,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 344  symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t2,t3);}

/* k2162 in k2158 in a2151 in k2148 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 344  string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[126]+1)))(4,*((C_word*)lf[126]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2114,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 345  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[123]+1)))(2,*((C_word*)lf[123]+1),t2);}

/* k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 346  with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[125]))(4,*((C_word*)lf[125]+1),t2,((C_word*)t0)[3],t3);}

/* a2132 in k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2139,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2138 in a2132 in k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2139,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2143,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 348  write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t3,t2);}

/* k2141 in a2138 in a2132 in k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 348  newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[123]+1)))(2,*((C_word*)lf[123]+1),((C_word*)t0)[2]);}

/* k2115 in k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2131,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 349  repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[122]))(2,*((C_word*)lf[122]+1),t4);}

/* k2129 in k2115 in k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 349  make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[76]))(4,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[15],"main#constant219"));}

/* k2125 in k2115 in k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 349  setup-api#copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[121]))(4,*((C_word*)lf[121]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2118 in k2115 in k2112 in k2109 in k2106 in k2103 in k2100 in k2097 in k2094 in k2091 in k2088 in loop in k2365 in k3073 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 350  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3066 in a3063 in a3057 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 506  cleanup */
f_2071(((C_word*)t0)[2]);}

/* a3035 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3036,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k908913 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3041 in a3035 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 502  current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[120]))(2,*((C_word*)lf[120]+1),t3);}

/* k3054 in a3041 in a3035 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 502  print-error-message */
((C_proc4)C_retrieve_symbol_proc(lf[119]))(4,*((C_word*)lf[119]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3044 in a3041 in a3035 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 503  cleanup */
f_2071(t2);}

/* k3047 in k3044 in a3041 in a3035 in a3029 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 504  exit */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),((C_word*)t0)[2],C_fix(1));}

/* k3026 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3017 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3025,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[118]))(2,*((C_word*)lf[118]+1),t3);}

/* k3023 in k3017 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3020 in k3017 in k3014 in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#usage in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_2353(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2353,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2357,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 361  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t3,lf[117]);}

/* k2355 in main#usage in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 382  exit */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#$system in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_2331(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2331,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2335,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2348,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[14],"main#*windows-shell*"))){
/* chicken-install.scm: 355  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[34]+1)))(5,*((C_word*)lf[34]+1),t4,lf[113],t2,lf[114]);}
else{
t5=t4;
f_2348(2,t5,t2);}}

/* k2346 in main#$system in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 353  system */
((C_proc3)C_retrieve_symbol_proc(lf[112]))(3,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1);}

/* k2333 in main#$system in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 358  error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),((C_word*)t0)[3],lf[111],t1,((C_word*)t0)[2]);}}

/* main#cleanup in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_2071(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2071,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[1],"main#*keep*"))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 311  setup-download#temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[109]))(2,*((C_word*)lf[109]+1),t2);}}

/* k2076 in main#cleanup in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-install.scm: 312  setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1704(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1704,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1708,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 228  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t3,lf[106]);}

/* k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1850,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1850,3,t0,t1,t2);}
t3=(C_word)C_i_assoc(t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1865,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 234  delete */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t4,t3,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"),*((C_word*)lf[79]+1));}
else{
t4=(C_word)C_i_pairp(t2);
t5=(C_truep(t4)?(C_word)C_i_car(t2):t2);
t6=(C_word)C_i_pairp(t2);
t7=(C_truep(t6)?(C_word)C_i_cdr(t2):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1876,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1882,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t8,t9);}}

/* a1881 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1882,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1886,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=t4;
f_1886(2,t5,C_SCHEME_UNDEFINED);}
else{
/* chicken-install.scm: 239  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t4,lf[105]);}}

/* k1884 in a1881 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1889,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-install.scm: 240  print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[45]+1)))(6,*((C_word*)lf[45]+1),t2,lf[103],((C_word*)t0)[2],lf[104],((C_word*)t0)[4]);}

/* k1887 in k1884 in a1881 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1889,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* chicken-install.scm: 241  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),t2,((C_word*)t0)[2],t3,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}

/* k1891 in k1887 in k1884 in a1881 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1579,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(C_retrieve2(lf[11],"main#*default-location*"))?C_retrieve2(lf[12],"main#*default-transport*"):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[11],"main#*default-location*"),C_SCHEME_END_OF_LIST);
t5=(C_word)C_a_i_cons(&a,2,lf[81],t4);
t6=(C_word)C_a_i_cons(&a,2,C_retrieve2(lf[12],"main#*default-transport*"),C_SCHEME_END_OF_LIST);
t7=(C_word)C_a_i_cons(&a,2,lf[82],t6);
t8=(C_word)C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=(C_word)C_a_i_cons(&a,2,t5,t8);
t10=t2;
f_1579(t10,(C_word)C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_1579(t4,C_retrieve2(lf[10],"main#*default-sources*"));}}

/* k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1579,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1581,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1581(t5,((C_word*)t0)[2],t1);}

/* trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1581(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1581,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* chicken-install.scm: 198  values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[80]);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_assq(lf[81],t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1645,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_1645(2,t6,t4);}
else{
/* chicken-install.scm: 201  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t5,lf[102],t3);}}}

/* k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1645,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(C_word)C_i_assq(lf[82],((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_1635(2,t5,t3);}
else{
/* chicken-install.scm: 203  error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t4,lf[101],((C_word*)t0)[7]);}}

/* k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(C_word)C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a1610 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1611,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* chicken-install.scm: 206  values */
C_values(4,0,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1137,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 103  delete */
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t4,((C_word*)t0)[2],C_retrieve2(lf[10],"main#*default-sources*"),*((C_word*)lf[79]+1));}}

/* k1135 in a1610 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[10] /* (set! main#*default-sources* ...) */,t1);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 209  trying-sources */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1581(t4,((C_word*)t0)[2],t3);}

/* a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1469,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t2,t3);}

/* a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1471,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1477,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1540,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[99]))(4,*((C_word*)lf[99]+1),t1,t3,t4);}

/* a1539 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1558 in a1539 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1559(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1559r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1559r(t0,t1,t2);}}

static void C_ccall f_1559r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k366372 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1564 in a1558 in a1539 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1565,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1545 in a1539 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
/* chicken-install.scm: 182  current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[98]))(2,*((C_word*)lf[98]+1),t2);}
else{
t3=t2;
f_1554(2,t3,C_SCHEME_FALSE);}}

/* k1552 in a1545 in a1539 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 179  setup-download#retrieve-extension */
((C_proc15)C_retrieve_symbol_proc(lf[92]))(15,*((C_word*)lf[92]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95],C_retrieve2(lf[5],"main#*run-tests*"),lf[96],C_retrieve2(lf[8],"main#*username*"),lf[97],C_retrieve2(lf[9],"main#*password*"));}

/* a1476 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1477,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k366372 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1482 in a1476 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[2],lf[83]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1493,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=(C_word)C_i_memv(lf[89],t3);
t6=t4;
f_1493(t6,(C_truep(t5)?(C_word)C_i_memv(lf[91],t3):C_SCHEME_FALSE));}
else{
t5=t4;
f_1493(t5,C_SCHEME_FALSE);}}

/* k1491 in a1482 in a1476 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1493(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1493,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 187  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t2,lf[85]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_memv(lf[89],((C_word*)t0)[2]);
t4=t2;
f_1505(t4,(C_truep(t3)?(C_word)C_i_memv(lf[90],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1505(t3,C_SCHEME_FALSE);}}}

/* k1503 in k1491 in a1482 in a1476 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1505,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 190  print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),t2,lf[87]);}
else{
t2=((C_word*)t0)[2];
/* chicken-install.scm: 193  abort */
((C_proc3)C_retrieve_symbol_proc(lf[88]))(3,*((C_word*)lf[88]+1),((C_word*)t0)[3],t2);}}

/* k1506 in k1503 in k1491 in a1482 in a1476 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 191  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[86]);}

/* k1494 in k1491 in a1482 in a1476 in a1470 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 188  values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[84]);}

/* k1467 in a1604 in k1633 in k1643 in trying-sources in k1577 in a1875 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1863 in a1849 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1865,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_mutate(&lf[26] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
if(C_truep(C_retrieve2(lf[6],"main#*retrieve-only*"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1719,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve2(lf[26],"main#*eggs+dirs+vers*"));}}

/* a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1719,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_member(t3,C_retrieve2(lf[27],"main#*checked*")))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_cons(&a,2,t4,C_retrieve2(lf[27],"main#*checked*"));
t6=C_mutate(&lf[27] /* (set! main#*checked* ...) */,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1733,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cadr(t2);
t9=(C_word)C_i_car(t2);
/* chicken-install.scm: 248  make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),t7,t8,t9,lf[77]);}}

/* k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1739,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 249  file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),t2,t1);}

/* k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 250  with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[70]))(4,*((C_word*)lf[70]+1),t2,((C_word*)t0)[2],*((C_word*)lf[71]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* chicken-install.scm: 271  string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[34]+1)))(6,*((C_word*)lf[34]+1),t2,lf[72],t3,lf[73],lf[74]);}}

/* k1826 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 270  warning */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1);}

/* k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1745,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* chicken-install.scm: 251  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[45]+1)))(5,*((C_word*)lf[45]+1),t2,lf[68],t3,lf[69]);}

/* k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1756,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1810,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1817,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 254  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[50]))(4,*((C_word*)lf[50]+1),t6,t2,lf[67]);}
else{
t5=t4;
f_1760(2,t5,C_SCHEME_UNDEFINED);}}

/* k1815 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 254  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),((C_word*)t0)[2],lf[66],t1);}

/* k1808 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 255  retrieve */
f_1704(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[2],"main#*force*");
if(C_truep(t3)){
t4=t2;
f_1766(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1804,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1658,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_car(t5);
t9=(C_word)C_a_i_list(&a,3,lf[56],t8,lf[57]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1666,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1668,tmp=(C_word)a,a+=2,tmp);
/* map */
t12=*((C_word*)lf[65]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,t6);}}
else{
t3=t2;
f_1766(2,t3,C_SCHEME_FALSE);}}

/* a1667 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1668,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1694,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t2);
/* chicken-install.scm: 221  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t4,t5);}

/* k1692 in a1667 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_assq(lf[20],t1);
t3=(C_truep(t2)?(C_word)C_i_cadr(t2):lf[59]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* chicken-install.scm: 219  conc */
((C_proc10)C_retrieve_symbol_proc(lf[60]))(10,*((C_word*)lf[60]+1),((C_word*)t0)[3],lf[61],((C_word*)t0)[2],lf[62],t3,lf[63],t4,lf[64],C_make_character(10));}

/* k1664 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 213  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[58]);}

/* k1656 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 212  string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),((C_word*)t0)[2],t1);}

/* k1802 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 258  setup-api#yes-or-no? */
((C_proc4)C_retrieve_symbol_proc(lf[53]))(4,*((C_word*)lf[53]+1),((C_word*)t0)[2],t1,lf[54]);}

/* k1764 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 261  unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1767 in k1764 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1791,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 262  string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[50]))(4,*((C_word*)lf[50]+1),t3,t1,lf[51]);}

/* k1789 in k1767 in k1764 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 262  print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),((C_word*)t0)[2],lf[49],t1);}

/* k1770 in k1767 in k1764 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1780,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1779 in k1770 in k1767 in k1764 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1780,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1784,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 265  print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[45]+1)))(5,*((C_word*)lf[45]+1),t3,lf[46],t2,lf[47]);}

/* k1782 in a1779 in k1770 in k1767 in k1764 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 266  setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[44]))(3,*((C_word*)lf[44]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1773 in k1770 in k1767 in k1764 in k1758 in a1755 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 268  retrieve */
f_1704(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1750,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1242,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_assq(lf[40],t2);
t5=(C_truep(t4)?(C_word)C_i_cdr(t4):C_SCHEME_FALSE);
t6=(C_truep(t5)?t5:C_SCHEME_END_OF_LIST);
t7=(C_word)C_i_assq(lf[41],t2);
t8=(C_truep(t7)?(C_word)C_i_cdr(t7):C_SCHEME_FALSE);
t9=(C_truep(t8)?t8:C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1451,a[2]=t9,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[5],"main#*run-tests*"))){
t11=(C_word)C_i_assq(lf[43],t2);
t12=(C_truep(t11)?(C_word)C_i_cdr(t11):C_SCHEME_FALSE);
t13=t10;
f_1451(t13,(C_truep(t12)?t12:C_SCHEME_END_OF_LIST));}
else{
t11=t10;
f_1451(t11,C_SCHEME_END_OF_LIST);}}

/* k1449 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 135  append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[42]+1)))(5,*((C_word*)lf[42]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1247,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1247(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1247(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1247,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1261,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 141  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_symbolp(t5);
t8=(C_truep(t7)?t7:(C_word)C_i_stringp(t5));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1287,a[2]=t4,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1290,a[2]=t5,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* chicken-install.scm: 146  ext-version */
f_1191(t10,t5);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1303,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_listp(t5))){
t10=(C_word)C_i_length(t5);
if(C_truep((C_word)C_i_nequalp(C_fix(2),t10))){
t11=(C_word)C_i_car(t5);
t12=(C_word)C_i_stringp(t11);
if(C_truep(t12)){
t13=t9;
f_1303(t13,t12);}
else{
t13=(C_word)C_i_car(t5);
t14=t9;
f_1303(t14,(C_word)C_i_symbolp(t13));}}
else{
t11=t9;
f_1303(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1303(t10,C_SCHEME_FALSE);}}}}

/* k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1303,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 152  ext-version */
f_1191(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1403,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-install.scm: 168  warning */
((C_proc4)C_retrieve_symbol_proc(lf[38]))(4,*((C_word*)lf[38]+1),t2,lf[39],((C_word*)t0)[2]);}}

/* k1401 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 171  loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1247(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1388,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1392,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 155  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 154  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}}

/* k1321 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken-install.scm: 154  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1247(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1390 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 155  setup-api#version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[37]))(4,*((C_word*)lf[37]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1386 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1388,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 166  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_1247(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1377,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 156  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}}

/* k1375 in k1386 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
if(C_truep((C_word)C_i_string_equal_p(lf[32],t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 158  string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[34]+1)))(5,*((C_word*)lf[34]+1),t2,lf[35],t3,lf[36]);}
else{
t2=((C_word*)t0)[3];
f_1336(2,t2,C_SCHEME_UNDEFINED);}}

/* k1367 in k1375 in k1386 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 157  error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k1334 in k1386 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
/* chicken-install.scm: 164  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t3,t4);}

/* k1345 in k1334 in k1386 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1351,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* chicken-install.scm: 164  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,t3);}

/* k1349 in k1345 in k1334 in k1386 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 163  alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[31]))(5,*((C_word*)lf[31]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1341 in k1334 in k1386 in k1304 in k1301 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 162  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1247(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1288 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1290,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1287(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 148  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t2,((C_word*)t0)[2]);}}

/* k1295 in k1288 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1287(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1285 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1287(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 145  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1247(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1259 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1265,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-install.scm: 141  reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),t2,((C_word*)t0)[2]);}

/* k1263 in k1259 in loop in k1240 in a1749 in k1743 in k1740 in k1737 in k1731 in a1718 in k1709 in k1706 in main#retrieve in k1458 in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-install.scm: 141  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#ext-version in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1191(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1191,NULL,2,t1,t2);}
t3=(C_word)C_eqp(t2,lf[18]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1201,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1201(t5,t3);}
else{
t5=(C_word)C_i_equalp(t2,lf[24]);
if(C_truep(t5)){
t6=t4;
f_1201(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 124  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t6,t2);}}}

/* k1234 in main#ext-version in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1201(t2,(C_word)C_i_member(t1,C_retrieve(lf[25])));}

/* k1199 in main#ext-version in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_fcall f_1201(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1201,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-install.scm: 125  chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[19]))(2,*((C_word*)lf[19]+1),((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-install.scm: 126  extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[23]))(3,*((C_word*)lf[23]+1),t2,((C_word*)t0)[2]);}}

/* k1205 in k1199 in main#ext-version in k1050 in k1047 in k1044 in k1039 in k1036 in k1033 in k1030 in k1027 in k1024 in k1021 in k1018 in k1015 in k1012 in k1009 in k1006 in k1003 in k1000 in k997 in k994 in k991 in k988 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[20],t1);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(t2);
/* chicken-install.scm: 130  ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),((C_word*)t0)[2],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[22]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[246] = {
{"toplevel:chicken_install_scm",(void*)C_toplevel},
{"f_990:chicken_install_scm",(void*)f_990},
{"f_993:chicken_install_scm",(void*)f_993},
{"f_996:chicken_install_scm",(void*)f_996},
{"f_999:chicken_install_scm",(void*)f_999},
{"f_1002:chicken_install_scm",(void*)f_1002},
{"f_1005:chicken_install_scm",(void*)f_1005},
{"f_1008:chicken_install_scm",(void*)f_1008},
{"f_1011:chicken_install_scm",(void*)f_1011},
{"f_1014:chicken_install_scm",(void*)f_1014},
{"f_1017:chicken_install_scm",(void*)f_1017},
{"f_1020:chicken_install_scm",(void*)f_1020},
{"f_1023:chicken_install_scm",(void*)f_1023},
{"f_1026:chicken_install_scm",(void*)f_1026},
{"f_1029:chicken_install_scm",(void*)f_1029},
{"f_1032:chicken_install_scm",(void*)f_1032},
{"f_1035:chicken_install_scm",(void*)f_1035},
{"f_1038:chicken_install_scm",(void*)f_1038},
{"f_1041:chicken_install_scm",(void*)f_1041},
{"f_1046:chicken_install_scm",(void*)f_1046},
{"f_1049:chicken_install_scm",(void*)f_1049},
{"f_1052:chicken_install_scm",(void*)f_1052},
{"f_3091:chicken_install_scm",(void*)f_3091},
{"f_1460:chicken_install_scm",(void*)f_1460},
{"f_3016:chicken_install_scm",(void*)f_3016},
{"f_3030:chicken_install_scm",(void*)f_3030},
{"f_3058:chicken_install_scm",(void*)f_3058},
{"f_3077:chicken_install_scm",(void*)f_3077},
{"f_3083:chicken_install_scm",(void*)f_3083},
{"f_3064:chicken_install_scm",(void*)f_3064},
{"f_3075:chicken_install_scm",(void*)f_3075},
{"f_1094:chicken_install_scm",(void*)f_1094},
{"f_1073:chicken_install_scm",(void*)f_1073},
{"f_1090:chicken_install_scm",(void*)f_1090},
{"f_1083:chicken_install_scm",(void*)f_1083},
{"f_2367:chicken_install_scm",(void*)f_2367},
{"f_2372:chicken_install_scm",(void*)f_2372},
{"f_2462:chicken_install_scm",(void*)f_2462},
{"f_2815:chicken_install_scm",(void*)f_2815},
{"f_2960:chicken_install_scm",(void*)f_2960},
{"f_2923:chicken_install_scm",(void*)f_2923},
{"f_2937:chicken_install_scm",(void*)f_2937},
{"f_2878:chicken_install_scm",(void*)f_2878},
{"f_2901:chicken_install_scm",(void*)f_2901},
{"f_2910:chicken_install_scm",(void*)f_2910},
{"f_2917:chicken_install_scm",(void*)f_2917},
{"f_2904:chicken_install_scm",(void*)f_2904},
{"f_2882:chicken_install_scm",(void*)f_2882},
{"f_2862:chicken_install_scm",(void*)f_2862},
{"f_2824:chicken_install_scm",(void*)f_2824},
{"f_2858:chicken_install_scm",(void*)f_2858},
{"f_2847:chicken_install_scm",(void*)f_2847},
{"f_2841:chicken_install_scm",(void*)f_2841},
{"f_2837:chicken_install_scm",(void*)f_2837},
{"f_2788:chicken_install_scm",(void*)f_2788},
{"f_2758:chicken_install_scm",(void*)f_2758},
{"f_2701:chicken_install_scm",(void*)f_2701},
{"f_1158:chicken_install_scm",(void*)f_1158},
{"f_1164:chicken_install_scm",(void*)f_1164},
{"f_1169:chicken_install_scm",(void*)f_1169},
{"f_1189:chicken_install_scm",(void*)f_1189},
{"f_1181:chicken_install_scm",(void*)f_1181},
{"f_1185:chicken_install_scm",(void*)f_1185},
{"f_1177:chicken_install_scm",(void*)f_1177},
{"f_2704:chicken_install_scm",(void*)f_2704},
{"f_2672:chicken_install_scm",(void*)f_2672},
{"f_2665:chicken_install_scm",(void*)f_2665},
{"f_2614:chicken_install_scm",(void*)f_2614},
{"f_2577:chicken_install_scm",(void*)f_2577},
{"f_2581:chicken_install_scm",(void*)f_2581},
{"f_2544:chicken_install_scm",(void*)f_2544},
{"f_2508:chicken_install_scm",(void*)f_2508},
{"f_2416:chicken_install_scm",(void*)f_2416},
{"f_2447:chicken_install_scm",(void*)f_2447},
{"f_2432:chicken_install_scm",(void*)f_2432},
{"f_2440:chicken_install_scm",(void*)f_2440},
{"f_2430:chicken_install_scm",(void*)f_2430},
{"f_2426:chicken_install_scm",(void*)f_2426},
{"f_2388:chicken_install_scm",(void*)f_2388},
{"f_2401:chicken_install_scm",(void*)f_2401},
{"f_2391:chicken_install_scm",(void*)f_2391},
{"f_2398:chicken_install_scm",(void*)f_2398},
{"f_1978:chicken_install_scm",(void*)f_1978},
{"f_1986:chicken_install_scm",(void*)f_1986},
{"f_1990:chicken_install_scm",(void*)f_1990},
{"f_1993:chicken_install_scm",(void*)f_1993},
{"f_2010:chicken_install_scm",(void*)f_2010},
{"f_1922:chicken_install_scm",(void*)f_1922},
{"f_1964:chicken_install_scm",(void*)f_1964},
{"f_1942:chicken_install_scm",(void*)f_1942},
{"f_1950:chicken_install_scm",(void*)f_1950},
{"f_1946:chicken_install_scm",(void*)f_1946},
{"f_2014:chicken_install_scm",(void*)f_2014},
{"f_2017:chicken_install_scm",(void*)f_2017},
{"f_2020:chicken_install_scm",(void*)f_2020},
{"f_2048:chicken_install_scm",(void*)f_2048},
{"f_2054:chicken_install_scm",(void*)f_2054},
{"f_2026:chicken_install_scm",(void*)f_2026},
{"f_2029:chicken_install_scm",(void*)f_2029},
{"f_2032:chicken_install_scm",(void*)f_2032},
{"f_2035:chicken_install_scm",(void*)f_2035},
{"f_1997:chicken_install_scm",(void*)f_1997},
{"f_2001:chicken_install_scm",(void*)f_2001},
{"f_2004:chicken_install_scm",(void*)f_2004},
{"f_2329:chicken_install_scm",(void*)f_2329},
{"f_2325:chicken_install_scm",(void*)f_2325},
{"f_2090:chicken_install_scm",(void*)f_2090},
{"f_2093:chicken_install_scm",(void*)f_2093},
{"f_2096:chicken_install_scm",(void*)f_2096},
{"f_2099:chicken_install_scm",(void*)f_2099},
{"f_2102:chicken_install_scm",(void*)f_2102},
{"f_2318:chicken_install_scm",(void*)f_2318},
{"f_2234:chicken_install_scm",(void*)f_2234},
{"f_2240:chicken_install_scm",(void*)f_2240},
{"f_2244:chicken_install_scm",(void*)f_2244},
{"f_2252:chicken_install_scm",(void*)f_2252},
{"f_2278:chicken_install_scm",(void*)f_2278},
{"f_2306:chicken_install_scm",(void*)f_2306},
{"f_2312:chicken_install_scm",(void*)f_2312},
{"f_2284:chicken_install_scm",(void*)f_2284},
{"f_2300:chicken_install_scm",(void*)f_2300},
{"f_2258:chicken_install_scm",(void*)f_2258},
{"f_2264:chicken_install_scm",(void*)f_2264},
{"f_2272:chicken_install_scm",(void*)f_2272},
{"f_2276:chicken_install_scm",(void*)f_2276},
{"f_2250:chicken_install_scm",(void*)f_2250},
{"f_2229:chicken_install_scm",(void*)f_2229},
{"f_2105:chicken_install_scm",(void*)f_2105},
{"f_2108:chicken_install_scm",(void*)f_2108},
{"f_2174:chicken_install_scm",(void*)f_2174},
{"f_2181:chicken_install_scm",(void*)f_2181},
{"f_2184:chicken_install_scm",(void*)f_2184},
{"f_2195:chicken_install_scm",(void*)f_2195},
{"f_2219:chicken_install_scm",(void*)f_2219},
{"f_2203:chicken_install_scm",(void*)f_2203},
{"f_2209:chicken_install_scm",(void*)f_2209},
{"f_2207:chicken_install_scm",(void*)f_2207},
{"f_2189:chicken_install_scm",(void*)f_2189},
{"f_2150:chicken_install_scm",(void*)f_2150},
{"f_2152:chicken_install_scm",(void*)f_2152},
{"f_2160:chicken_install_scm",(void*)f_2160},
{"f_2164:chicken_install_scm",(void*)f_2164},
{"f_2111:chicken_install_scm",(void*)f_2111},
{"f_2114:chicken_install_scm",(void*)f_2114},
{"f_2133:chicken_install_scm",(void*)f_2133},
{"f_2139:chicken_install_scm",(void*)f_2139},
{"f_2143:chicken_install_scm",(void*)f_2143},
{"f_2117:chicken_install_scm",(void*)f_2117},
{"f_2131:chicken_install_scm",(void*)f_2131},
{"f_2127:chicken_install_scm",(void*)f_2127},
{"f_2120:chicken_install_scm",(void*)f_2120},
{"f_3068:chicken_install_scm",(void*)f_3068},
{"f_3036:chicken_install_scm",(void*)f_3036},
{"f_3042:chicken_install_scm",(void*)f_3042},
{"f_3056:chicken_install_scm",(void*)f_3056},
{"f_3046:chicken_install_scm",(void*)f_3046},
{"f_3049:chicken_install_scm",(void*)f_3049},
{"f_3028:chicken_install_scm",(void*)f_3028},
{"f_3019:chicken_install_scm",(void*)f_3019},
{"f_3025:chicken_install_scm",(void*)f_3025},
{"f_3022:chicken_install_scm",(void*)f_3022},
{"f_2353:chicken_install_scm",(void*)f_2353},
{"f_2357:chicken_install_scm",(void*)f_2357},
{"f_2331:chicken_install_scm",(void*)f_2331},
{"f_2348:chicken_install_scm",(void*)f_2348},
{"f_2335:chicken_install_scm",(void*)f_2335},
{"f_2071:chicken_install_scm",(void*)f_2071},
{"f_2078:chicken_install_scm",(void*)f_2078},
{"f_1704:chicken_install_scm",(void*)f_1704},
{"f_1708:chicken_install_scm",(void*)f_1708},
{"f_1850:chicken_install_scm",(void*)f_1850},
{"f_1882:chicken_install_scm",(void*)f_1882},
{"f_1886:chicken_install_scm",(void*)f_1886},
{"f_1889:chicken_install_scm",(void*)f_1889},
{"f_1893:chicken_install_scm",(void*)f_1893},
{"f_1876:chicken_install_scm",(void*)f_1876},
{"f_1579:chicken_install_scm",(void*)f_1579},
{"f_1581:chicken_install_scm",(void*)f_1581},
{"f_1645:chicken_install_scm",(void*)f_1645},
{"f_1635:chicken_install_scm",(void*)f_1635},
{"f_1611:chicken_install_scm",(void*)f_1611},
{"f_1137:chicken_install_scm",(void*)f_1137},
{"f_1605:chicken_install_scm",(void*)f_1605},
{"f_1471:chicken_install_scm",(void*)f_1471},
{"f_1540:chicken_install_scm",(void*)f_1540},
{"f_1559:chicken_install_scm",(void*)f_1559},
{"f_1565:chicken_install_scm",(void*)f_1565},
{"f_1546:chicken_install_scm",(void*)f_1546},
{"f_1554:chicken_install_scm",(void*)f_1554},
{"f_1477:chicken_install_scm",(void*)f_1477},
{"f_1483:chicken_install_scm",(void*)f_1483},
{"f_1493:chicken_install_scm",(void*)f_1493},
{"f_1505:chicken_install_scm",(void*)f_1505},
{"f_1508:chicken_install_scm",(void*)f_1508},
{"f_1496:chicken_install_scm",(void*)f_1496},
{"f_1469:chicken_install_scm",(void*)f_1469},
{"f_1865:chicken_install_scm",(void*)f_1865},
{"f_1711:chicken_install_scm",(void*)f_1711},
{"f_1719:chicken_install_scm",(void*)f_1719},
{"f_1733:chicken_install_scm",(void*)f_1733},
{"f_1739:chicken_install_scm",(void*)f_1739},
{"f_1828:chicken_install_scm",(void*)f_1828},
{"f_1742:chicken_install_scm",(void*)f_1742},
{"f_1745:chicken_install_scm",(void*)f_1745},
{"f_1756:chicken_install_scm",(void*)f_1756},
{"f_1817:chicken_install_scm",(void*)f_1817},
{"f_1810:chicken_install_scm",(void*)f_1810},
{"f_1760:chicken_install_scm",(void*)f_1760},
{"f_1668:chicken_install_scm",(void*)f_1668},
{"f_1694:chicken_install_scm",(void*)f_1694},
{"f_1666:chicken_install_scm",(void*)f_1666},
{"f_1658:chicken_install_scm",(void*)f_1658},
{"f_1804:chicken_install_scm",(void*)f_1804},
{"f_1766:chicken_install_scm",(void*)f_1766},
{"f_1769:chicken_install_scm",(void*)f_1769},
{"f_1791:chicken_install_scm",(void*)f_1791},
{"f_1772:chicken_install_scm",(void*)f_1772},
{"f_1780:chicken_install_scm",(void*)f_1780},
{"f_1784:chicken_install_scm",(void*)f_1784},
{"f_1775:chicken_install_scm",(void*)f_1775},
{"f_1750:chicken_install_scm",(void*)f_1750},
{"f_1451:chicken_install_scm",(void*)f_1451},
{"f_1242:chicken_install_scm",(void*)f_1242},
{"f_1247:chicken_install_scm",(void*)f_1247},
{"f_1303:chicken_install_scm",(void*)f_1303},
{"f_1403:chicken_install_scm",(void*)f_1403},
{"f_1306:chicken_install_scm",(void*)f_1306},
{"f_1323:chicken_install_scm",(void*)f_1323},
{"f_1392:chicken_install_scm",(void*)f_1392},
{"f_1388:chicken_install_scm",(void*)f_1388},
{"f_1377:chicken_install_scm",(void*)f_1377},
{"f_1369:chicken_install_scm",(void*)f_1369},
{"f_1336:chicken_install_scm",(void*)f_1336},
{"f_1347:chicken_install_scm",(void*)f_1347},
{"f_1351:chicken_install_scm",(void*)f_1351},
{"f_1343:chicken_install_scm",(void*)f_1343},
{"f_1290:chicken_install_scm",(void*)f_1290},
{"f_1297:chicken_install_scm",(void*)f_1297},
{"f_1287:chicken_install_scm",(void*)f_1287},
{"f_1261:chicken_install_scm",(void*)f_1261},
{"f_1265:chicken_install_scm",(void*)f_1265},
{"f_1191:chicken_install_scm",(void*)f_1191},
{"f_1236:chicken_install_scm",(void*)f_1236},
{"f_1201:chicken_install_scm",(void*)f_1201},
{"f_1207:chicken_install_scm",(void*)f_1207},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
