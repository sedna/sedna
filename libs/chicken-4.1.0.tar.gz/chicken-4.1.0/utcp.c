/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2009-08-01 00:35
   Version 4.0.7 - SVN rev. 15292
   linux-unix-gnu-x86 [ manyargs ptables applyhook ]
   compiled 2009-08-01 on x (Linux)
   command line: tcp.scm -no-trace -optimize-level 2 -include-path . -include-path ./ -explicit-use -unsafe -no-lambda-info -output-file utcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[95];
static double C_possibly_force_alignment;


/* from general-strerror */
static C_word C_fcall stub724(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub724(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from get-socket-error */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub718(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub718(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from f_1250 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub289(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub289(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k1164 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub254(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k1061 in ##net#gethostaddr in k1027 in k943 in k940 in k937 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub204(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from ##net#select-write */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub196(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub196(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from ##net#select in k1027 in k943 in k940 in k937 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub190(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub190(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k1038 in k1034 in k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub177(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub168(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub168(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from ##net#getpeername */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#getpeerport */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub155(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub155(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockport in k943 in k940 in k937 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub149(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub149(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockname */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub141(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub141(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#make-nonblocking in k943 in k940 in k937 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub135(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub135(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k1000 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k993 */
static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub107(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from ##net#shutdown in k943 in k940 in k937 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k983 */
static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub85(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from ##net#close in k943 in k940 in k937 */
static C_word C_fcall stub76(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub76(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k967 */
static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from ##net#listen */
static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub53(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k953 */
static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub41(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from ##net#socket in k943 in k940 in k937 */
static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub31(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2608)
static void C_ccall f_2608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2575)
static void C_ccall f_2575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2527)
static void C_ccall f_2527(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2534)
static void C_ccall f_2534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2562)
static void C_ccall f_2562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2514)
static void C_ccall f_2514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2503)
static void C_ccall f_2503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2461)
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2222)
static void C_ccall f_2222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_fcall f_1098(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1121)
static void C_ccall f_1121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1040)
static void C_ccall f_1040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1148)
static void C_ccall f_1148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1144)
static void C_ccall f_1144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_ccall f_2260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_fcall f_2329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2336)
static void C_ccall f_2336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2295)
static void C_ccall f_2295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2275)
static void C_ccall f_2275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_fcall f_2239(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_fcall f_2099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2144)
static void C_ccall f_2144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1450)
static void C_fcall f_1450(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_fcall f_1466(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1959)
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1890)
static void C_fcall f_1890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_fcall f_1855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1828)
static void C_ccall f_1828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1819)
static void C_ccall f_1819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1784)
static void C_ccall f_1784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1716)
static void C_fcall f_1716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_ccall f_1719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_fcall f_1686(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1696)
static void C_ccall f_1696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_fcall f_1547(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1557)
static void C_fcall f_1557(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1622)
static void C_ccall f_1622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_fcall f_1473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_fcall f_1479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_fcall f_1419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1394)
static void C_ccall f_1394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1324)
static void C_fcall f_1324(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_fcall f_1319(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1276)
static void C_fcall f_1276(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1175)
static void C_ccall f_1175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1250)
static void C_ccall f_1250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1184)
static void C_ccall f_1184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1205)
static void C_ccall f_1205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_fcall f_1068(C_word t0) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1054)
static void C_fcall f_1054(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static C_word C_fcall f_1048(C_word t0);
C_noret_decl(f_1013)
static C_word C_fcall f_1013(C_word t0);
C_noret_decl(f_1004)
static C_word C_fcall f_1004(C_word t0);
C_noret_decl(f_987)
static C_word C_fcall f_987(C_word t0,C_word t1);
C_noret_decl(f_977)
static C_word C_fcall f_977(C_word t0);
C_noret_decl(f_947)
static C_word C_fcall f_947(C_word t0,C_word t1,C_word t2);

C_noret_decl(trf_1098)
static void C_fcall trf_1098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1098(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1098(t0,t1,t2);}

C_noret_decl(trf_2329)
static void C_fcall trf_2329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2329(t0,t1);}

C_noret_decl(trf_2239)
static void C_fcall trf_2239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2239(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2239(t0,t1);}

C_noret_decl(trf_2099)
static void C_fcall trf_2099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2099(t0,t1);}

C_noret_decl(trf_1450)
static void C_fcall trf_1450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1450(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1450(t0,t1,t2);}

C_noret_decl(trf_1466)
static void C_fcall trf_1466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1466(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1466(t0,t1);}

C_noret_decl(trf_1959)
static void C_fcall trf_1959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1959(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1959(t0,t1,t2,t3);}

C_noret_decl(trf_1890)
static void C_fcall trf_1890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1890(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1890(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1855)
static void C_fcall trf_1855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1855(t0,t1);}

C_noret_decl(trf_1716)
static void C_fcall trf_1716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1716(t0,t1);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1677(t0,t1);}

C_noret_decl(trf_1686)
static void C_fcall trf_1686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1686(t0,t1);}

C_noret_decl(trf_1547)
static void C_fcall trf_1547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1547(t0,t1,t2);}

C_noret_decl(trf_1557)
static void C_fcall trf_1557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1557(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1557(t0,t1,t2,t3);}

C_noret_decl(trf_1473)
static void C_fcall trf_1473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1473(t0,t1);}

C_noret_decl(trf_1479)
static void C_fcall trf_1479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1479(t0,t1);}

C_noret_decl(trf_1419)
static void C_fcall trf_1419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1419(t0,t1);}

C_noret_decl(trf_1324)
static void C_fcall trf_1324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1324(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1324(t0,t1);}

C_noret_decl(trf_1319)
static void C_fcall trf_1319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1319(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1319(t0,t1,t2);}

C_noret_decl(trf_1276)
static void C_fcall trf_1276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1276(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1276(t0,t1,t2,t3);}

C_noret_decl(trf_1068)
static void C_fcall trf_1068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1068(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1068(t0);}

C_noret_decl(trf_1054)
static void C_fcall trf_1054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1054(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1054(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(440)){
C_save(t1);
C_rereclaim2(440*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,95);
lf[7]=C_h_intern(&lf[7],17,"\003sysmake-c-string");
lf[9]=C_h_intern(&lf[9],18,"\003syscurrent-thread");
lf[10]=C_h_intern(&lf[10],12,"\003sysschedule");
lf[11]=C_h_intern(&lf[11],10,"tcp-listen");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000network-error");
lf[14]=C_h_intern(&lf[14],17,"\003sysstring-append");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot bind to socket - ");
lf[16]=C_h_intern(&lf[16],17,"\003syspeek-c-string");
lf[17]=C_h_intern(&lf[17],16,"\003sysupdate-errno");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[19]=C_h_intern(&lf[19],11,"make-string");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[21]=C_h_intern(&lf[21],9,"\003syserror");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot create socket");
lf[23]=C_h_intern(&lf[23],13,"\000domain-error");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[25]=C_h_intern(&lf[25],12,"tcp-listener");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot listen on socket - ");
lf[27]=C_h_intern(&lf[27],13,"tcp-listener\077");
lf[28]=C_h_intern(&lf[28],9,"tcp-close");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot close TCP socket - ");
lf[30]=C_h_intern(&lf[30],15,"tcp-buffer-size");
lf[31]=C_h_intern(&lf[31],16,"tcp-read-timeout");
lf[32]=C_h_intern(&lf[32],17,"tcp-write-timeout");
lf[33]=C_h_intern(&lf[33],19,"tcp-connect-timeout");
lf[34]=C_h_intern(&lf[34],18,"tcp-accept-timeout");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[37]=C_h_intern(&lf[37],25,"\003systhread-block-for-i/o!");
lf[38]=C_h_intern(&lf[38],29,"\003systhread-block-for-timeout!");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot read from socket - ");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot write to socket - ");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[44]=C_h_intern(&lf[44],6,"socket");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot close socket output port - ");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[49]=C_h_intern(&lf[49],16,"make-output-port");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000 cannot check socket for input - ");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000!cannot close socket input port - ");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[53]=C_h_intern(&lf[53],15,"\003sysmake-string");
lf[54]=C_h_intern(&lf[54],20,"\003sysscan-buffer-line");
lf[55]=C_h_intern(&lf[55],15,"make-input-port");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot create TCP ports - ");
lf[58]=C_h_intern(&lf[58],10,"tcp-accept");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[61]=C_h_intern(&lf[61],17,"tcp-accept-ready\077");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000 cannot check socket for input - ");
lf[63]=C_h_intern(&lf[63],11,"tcp-connect");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot connect to socket - ");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create socket - ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[68]=C_h_intern(&lf[68],4,"\000all");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot find host address");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create socket - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000#cannot compute port from service - ");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[75]=C_h_intern(&lf[75],13,"\003syssubstring");
lf[76]=C_h_intern(&lf[76],20,"\003systcp-port->fileno");
lf[77]=C_h_intern(&lf[77],5,"error");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000)argument does not appear to be a TCP port");
lf[79]=C_h_intern(&lf[79],13,"\003sysport-data");
lf[80]=C_h_intern(&lf[80],13,"tcp-addresses");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000 cannot compute remote address - ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot compute local address - ");
lf[83]=C_h_intern(&lf[83],14,"\003syscheck-port");
lf[84]=C_h_intern(&lf[84],16,"tcp-port-numbers");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot compute remote port - ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot compute local port - ");
lf[87]=C_h_intern(&lf[87],17,"tcp-listener-port");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\036cannot obtain listener port - ");
lf[89]=C_h_intern(&lf[89],16,"tcp-abandon-port");
lf[90]=C_h_intern(&lf[90],19,"tcp-listener-fileno");
lf[91]=C_h_intern(&lf[91],14,"make-parameter");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot initialize Winsock");
lf[93]=C_h_intern(&lf[93],17,"register-feature!");
lf[94]=C_h_intern(&lf[94],3,"tcp");
C_register_lf2(lf,95,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_939,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k937 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k940 in k937 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 91   register-feature! */
t3=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[94]);}

/* k943 in k940 in k937 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! socket ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_947,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[1] /* (set! close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_977,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[2] /* (set! shutdown ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_987,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3] /* (set! make-nonblocking ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1004,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[4] /* (set! getsockport ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1013,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub168(C_SCHEME_UNDEFINED))){
t8=t7;
f_1029(2,t8,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 176  ##sys#signal-hook */
t8=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[13],lf[92]);}}

/* k1027 in k943 in k940 in k937 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1029,2,t0,t1);}
t2=C_mutate(&lf[5] /* (set! select ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1048,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[6] /* (set! gethostaddr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1054,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[8] /* (set! yield ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1068,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[11]+1 /* (set! tcp-listen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1274,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[27]+1 /* (set! tcp-listener? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1369,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[28]+1 /* (set! tcp-close ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1378,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 310  make-parameter */
t9=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,C_SCHEME_FALSE);}

/* k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! tcp-buffer-size ...) */,t1);
t3=C_set_block_item(lf[31] /* tcp-read-timeout */,0,C_SCHEME_UNDEFINED);
t4=C_set_block_item(lf[32] /* tcp-write-timeout */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[33] /* tcp-connect-timeout */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[34] /* tcp-accept-timeout */,0,C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1419,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1436,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2647,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 321  check */
f_1419(t9,lf[31]);}

/* k2645 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 321  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! tcp-read-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 322  check */
f_1419(t4,lf[32]);}

/* k2641 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 322  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=C_mutate((C_word*)lf[32]+1 /* (set! tcp-write-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 323  check */
f_1419(t4,lf[33]);}

/* k2637 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 323  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1444,2,t0,t1);}
t2=C_mutate((C_word*)lf[33]+1 /* (set! tcp-connect-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 324  check */
f_1419(t4,lf[34]);}

/* k2633 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 324  make-parameter */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1 /* (set! tcp-accept-timeout ...) */,t1);
t3=*((C_word*)lf[30]+1);
t4=*((C_word*)lf[19]+1);
t5=C_mutate(&lf[35] /* (set! io-ports ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1450,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t6=C_mutate((C_word*)lf[58]+1 /* (set! tcp-accept ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2084,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[61]+1 /* (set! tcp-accept-ready? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2170,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[63]+1 /* (set! tcp-connect ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2215,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[76]+1 /* (set! tcp-port->fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2461,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[80]+1 /* (set! tcp-addresses ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2479,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[84]+1 /* (set! tcp-port-numbers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2527,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[87]+1 /* (set! tcp-listener-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2575,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[89]+1 /* (set! tcp-abandon-port ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2604,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[90]+1 /* (set! tcp-listener-fileno ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2624,tmp=(C_word)a,a+=2,tmp));
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2624,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[25],lf[90]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2604,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2608,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 641  ##sys#check-port */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[89]);}

/* k2606 in tcp-abandon-port in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 643  ##sys#port-data */
t3=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2613 in k2606 in tcp-abandon-port in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2575,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[25],lf[87]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_1013(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2588,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2598,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2602,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t8=t6;
f_2588(2,t8,C_SCHEME_UNDEFINED);}}

/* k2600 in tcp-listener-port in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 636  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[88],t1);}

/* k2596 in tcp-listener-port in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 635  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[87],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2586 in tcp-listener-port in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2527(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2527,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2531,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 622  ##sys#check-port */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[84]);}

/* k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 623  ##sys#tcp-port->fileno */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2532 in k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2534,2,t0,t1);}
t2=f_1013(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2544(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2571 in k2532 in k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 626  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2567 in k2532 in k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 626  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[84],t1,((C_word*)t0)[2]);}

/* k2542 in k2532 in k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2544,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)stub155(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2551,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2551(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2562,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2560 in k2542 in k2532 in k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k2556 in k2542 in k2532 in k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 628  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[84],t1,((C_word*)t0)[2]);}

/* k2549 in k2542 in k2532 in k2529 in tcp-port-numbers in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 624  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2479,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2483,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 613  ##sys#check-port */
t4=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[80]);}

/* k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 614  ##sys#tcp-port->fileno */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2493,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub141(t4,t3),C_fix(0));}

/* k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2496(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2523 in k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 617  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2519 in k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 617  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[80],t1,((C_word*)t0)[2]);}

/* k2494 in k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub161(t4,t3),C_fix(0));}

/* k2498 in k2494 in k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2503,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2503(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2514,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2512 in k2498 in k2494 in k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 619  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k2508 in k2498 in k2494 in k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 619  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[80],t1,((C_word*)t0)[2]);}

/* k2501 in k2498 in k2494 in k2491 in k2484 in k2481 in tcp-addresses in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 615  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2461,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2465,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 607  ##sys#port-data */
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2463 in ##sys#tcp-port->fileno in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_vectorp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}
else{
/* tcp.scm: 610  error */
t2=*((C_word*)lf[77]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[76],lf[78],((C_word*)t0)[2]);}}

/* tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2215r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2215r(t0,t1,t2,t3);}}

static void C_ccall f_2215r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2222,a[2]=t1,a[3]=t8,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 556  tcp-connect-timeout */
t10=*((C_word*)lf[33]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2222,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2228,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2228(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t4,t5,t6);}}

/* a2443 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2444,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1098,a[2]=t5,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1098(t7,t1,C_fix(0));}

/* loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1098(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1098,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
/* tcp.scm: 232  values */
C_values(4,0,t1,((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1121,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_fixnum_increase(t2);
/* substring */
t7=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,((C_word*)t0)[3],t6,((C_word*)t0)[4]);}
else{
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 245  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1125,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* substring */
t3=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1125,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1036,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t4=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_1036(2,t4,C_SCHEME_FALSE);}}

/* k1034 in k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-c-string */
t3=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[74]);}

/* k1038 in k1034 in k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1040,2,t0,t1);}
t2=(C_word)stub177(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1131,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1137,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 240  ##sys#update-errno */
t6=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1131(2,t5,C_SCHEME_UNDEFINED);}}

/* k1135 in k1038 in k1034 in k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1148,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1146 in k1135 in k1038 in k1034 in k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 242  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[73],t1);}

/* k1142 in k1135 in k1038 in k1034 in k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 241  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[63],t1,((C_word*)t0)[2]);}

/* k1129 in k1038 in k1034 in k1123 in k1119 in loop in a2437 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 235  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2428 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_2228(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 560  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[63],lf[72],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2228,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 562  make-string */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=f_947(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 571  ##sys#update-errno */
t7=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_2260(2,t6,C_SCHEME_UNDEFINED);}}

/* k2414 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2427,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2425 in k2414 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k2421 in k2414 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 572  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[63],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 573  ##net#gethostaddr */
f_1054(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2405 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2263(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 574  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[63],lf[70],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=f_1004(((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t2;
f_2266(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 576  ##sys#update-errno */
t5=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2391 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2402 in k2391 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 577  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k2398 in k2391 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 577  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[63],t1);}

/* k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=(C_word)stub107(C_SCHEME_UNDEFINED,((C_word*)t0)[6],t5,t4);
t7=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t7)){
t8=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t10,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2329(t12,t2);}
else{
/* tcp.scm: 596  fail */
t9=((C_word*)t0)[2];
f_2239(t9,t2);}}
else{
t8=t2;
f_2269(2,t8,C_SCHEME_UNDEFINED);}}

/* loop in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_2329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2329,NULL,2,t0,t1);}
t2=(C_word)stub196(C_SCHEME_UNDEFINED,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
/* tcp.scm: 582  fail */
t5=((C_word*)t0)[2];
f_2239(t5,t3);}
else{
t5=t3;
f_2336(2,t5,C_SCHEME_UNDEFINED);}}

/* k2334 in loop in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2336,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_u_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 585  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,*((C_word*)lf[9]+1),t5);}
else{
t4=t3;
f_2345(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2343 in k2334 in loop in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 588  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[68]);}

/* k2346 in k2343 in k2334 in loop in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 589  yield */
f_1068(t2);}

/* k2349 in k2346 in k2343 in k2334 in loop in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 591  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[63],lf[67],((C_word*)t0)[2]);}
else{
t3=t2;
f_2354(2,t3,C_SCHEME_UNDEFINED);}}

/* k2352 in k2349 in k2346 in k2343 in k2334 in loop in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 595  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2329(t2,((C_word*)t0)[2]);}

/* k2267 in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=(C_word)stub718(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
t5=f_977(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2295,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=f_977(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t9=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,(C_word)stub724(t8,t2),C_fix(0));}
else{
t5=t3;
f_2275(2,t5,C_SCHEME_UNDEFINED);}}}

/* k2313 in k2267 in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 603  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[66],t1);}

/* k2309 in k2267 in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 603  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[63],t1);}

/* k2293 in k2267 in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 600  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[65],t1);}

/* k2289 in k2267 in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 600  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[63],t1);}

/* k2273 in k2267 in k2264 in k2261 in k2258 in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 604  ##net#io-ports */
t2=lf[35];
f_1450(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_2239(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2239,NULL,2,t0,t1);}
t2=f_977(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 566  ##sys#update-errno */
t4=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2244 in fail in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2255 in k2244 in fail in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 568  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[64],t1);}

/* k2251 in k2244 in fail in k2232 in k2226 in k2220 in tcp-connect in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 567  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[63],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2170,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[25],lf[61]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_1048(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2180,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2189,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 538  ##sys#update-errno */
t9=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_2180(2,t8,C_SCHEME_UNDEFINED);}}

/* k2187 in tcp-accept-ready? in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2198 in k2187 in tcp-accept-ready? in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 540  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k2194 in k2187 in tcp-accept-ready? in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 539  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[61],t1,((C_word*)t0)[2]);}

/* k2178 in tcp-accept-ready? in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2084,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[25]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2094,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 510  tcp-accept-timeout */
t6=*((C_word*)lf[34]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2099,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2099(t5,((C_word*)t0)[2]);}

/* loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_2099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2099,NULL,2,t0,t1);}
t2=f_1048(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)stub62(C_SCHEME_UNDEFINED,((C_word*)t0)[5],C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2112,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 515  ##sys#update-errno */
t8=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t5;
f_2112(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_u_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 522  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,*((C_word*)lf[9]+1),t6);}
else{
t5=t4;
f_2135(2,t5,C_SCHEME_UNDEFINED);}}}

/* k2133 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 525  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k2136 in k2133 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 526  yield */
f_1068(t2);}

/* k2139 in k2136 in k2133 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2144,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 528  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[58],lf[60],((C_word*)t0)[2]);}
else{
t3=t2;
f_2144(2,t3,C_SCHEME_UNDEFINED);}}

/* k2142 in k2139 in k2136 in k2133 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 532  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2099(t2,((C_word*)t0)[2]);}

/* k2119 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2130 in k2119 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 517  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[59],t1);}

/* k2126 in k2119 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 516  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[58],t1,((C_word*)t0)[2]);}

/* k2110 in loop in k2092 in tcp-accept in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 519  ##net#io-ports */
t2=lf[35];
f_1450(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1450(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1450,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=f_1004(t2);
if(C_truep(t4)){
t5=t3;
f_1454(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2071,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 333  ##sys#update-errno */
t6=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k2069 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2080 in k2069 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[57],t1);}

/* k2076 in k2069 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 334  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[13],t1);}

/* k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 335  make-string */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1024));}

/* k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1463,a[2]=t8,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t6,a[7]=t4,a[8]=t1,a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 341  tbs */
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}

/* k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1466(t4,(C_truep(t3)?lf[56]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1466(t3,C_SCHEME_FALSE);}}

/* k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1466(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1466,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 343  tcp-read-timeout */
t5=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* tcp.scm: 344  tcp-write-timeout */
t3=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[46],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1472,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1784,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1884,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1949,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 372  make-input-port */
t9=*((C_word*)lf[55]+1);
((C_proc8)(void*)(*((C_word*)t9+1)))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a1948 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1949,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?t3:(C_word)C_fudge(C_fix(21)));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1959,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_1959(t8,t1,C_SCHEME_FALSE,t4);}

/* loop in a1948 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1959(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1959,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_fixnum_min(((C_word*)((C_word*)t0)[6])[1],t3);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 420  ##sys#scan-buffer-line */
t6=*((C_word*)lf[54]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t1,((C_word*)t0)[5],t4,((C_word*)((C_word*)t0)[7])[1],t5);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2047,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 441  read-input */
t5=((C_word*)t0)[3];
f_1473(t5,t4);}}

/* k2045 in loop in a1948 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
/* tcp.scm: 443  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1959(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a1974 in loop in a1948 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1975,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[9])[1]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=t2,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 426  ##sys#make-string */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k1980 in a1974 in loop in a1948 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[13],t1,((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,((C_word*)t0)[10]);
t4=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[9]);
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[8])){
/* tcp.scm: 430  ##sys#string-append */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[7],((C_word*)t0)[8],t1);}
else{
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2004,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm: 432  read-input */
t7=((C_word*)t0)[3];
f_1473(t7,t6);}
else{
t6=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t7);
if(C_truep(((C_word*)t0)[8])){
/* tcp.scm: 439  ##sys#string-append */
t9=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[7],((C_word*)t0)[8],t1);}
else{
t9=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t1);}}}}

/* k2002 in k1980 in a1974 in loop in a1948 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2004,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[52]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
/* tcp.scm: 435  ##sys#string-append */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[2]);}
else{
t3=t2;
f_2020(2,t3,((C_word*)t0)[2]);}}}

/* k2018 in k2002 in k1980 in a1974 in loop in a1948 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* tcp.scm: 435  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1959(t3,((C_word*)t0)[2],t1,t2);}

/* a1883 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1884,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_1890(t9,t1,t3,C_fix(0),t5);}

/* loop in a1883 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1890,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* tcp.scm: 410  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1938,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 412  read-input */
t7=((C_word*)t0)[2];
f_1473(t7,t6);}}}

/* k1936 in loop in a1883 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 415  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1890(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1840 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_987(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_977(((C_word*)t0)[3]);
t6=t4;
f_1855(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1855(t5,C_SCHEME_FALSE);}}}

/* k1853 in a1840 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1855,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 396  ##sys#update-errno */
t3=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1856 in k1853 in a1840 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1869,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1867 in k1856 in k1853 in a1840 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 399  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k1863 in k1856 in k1853 in a1840 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 397  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* a1805 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_1048(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1819,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1828,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 385  ##sys#update-errno */
t7=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1819(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1826 in a1805 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1839,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1837 in k1826 in a1805 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 388  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[50],t1);}

/* k1833 in k1826 in a1805 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 386  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1817 in a1805 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1783 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 375  read-input */
t3=((C_word*)t0)[2];
f_1473(t3,t2);}
else{
t3=t2;
f_1788(2,t3,C_SCHEME_UNDEFINED);}}

/* k1786 in a1783 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1748,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1669,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1732,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):C_SCHEME_FALSE);
/* tcp.scm: 473  make-output-port */
t7=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,t5,t6);}

/* f_1732 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1742,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 497  output */
t4=((C_word*)t0)[2];
f_1547(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1740 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[48]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1677,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1716,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1716(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1716(t5,C_SCHEME_FALSE);}}}

/* k1714 in a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1716,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 487  output */
t3=((C_word*)t0)[2];
f_1547(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1677(t2,C_SCHEME_UNDEFINED);}}

/* k1717 in k1714 in a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[47]);
t3=((C_word*)t0)[2];
f_1677(t3,t2);}

/* k1675 in a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))?C_SCHEME_UNDEFINED:f_987(((C_word*)t0)[4],C_fix((C_word)SD_SEND)));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=f_977(((C_word*)t0)[4]);
t5=t3;
f_1686(t5,(C_word)C_eqp(C_fix(-1),t4));}
else{
t4=t3;
f_1686(t4,C_SCHEME_FALSE);}}

/* k1684 in k1675 in a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1686,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 491  ##sys#update-errno */
t3=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1687 in k1684 in k1675 in a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1700,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1698 in k1687 in k1684 in k1675 in a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 493  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[46],t1);}

/* k1694 in k1687 in k1684 in k1675 in a1668 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 492  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* f_1768 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1768,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 482  output */
t4=((C_word*)t0)[2];
f_1547(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1748 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1748,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 476  ##sys#string-append */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1751 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1762,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 478  output */
t5=((C_word*)t0)[2];
f_1547(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1760 in k1751 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[45]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1640 in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[42]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[43]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[44]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[44]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 505  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1547,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1557(t7,t1,t3,C_fix(0));}

/* loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1557(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1557,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=t3;
t8=(C_truep(t6)?t6:C_SCHEME_FALSE);
t9=(C_word)stub122(C_SCHEME_UNDEFINED,t5,t8,t7,t4,C_fix(0));
t10=(C_word)C_eqp(C_fix(-1),t9);
if(C_truep(t10)){
t11=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1579,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t13=(C_word)C_fudge(C_fix(16));
t14=(C_word)C_u_fixnum_plus(t13,((C_word*)t0)[2]);
/* tcp.scm: 454  ##sys#thread-block-for-timeout! */
t15=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,*((C_word*)lf[9]+1),t14);}
else{
t13=t12;
f_1579(2,t13,C_SCHEME_UNDEFINED);}}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1611,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 465  ##sys#update-errno */
t13=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t9,t2))){
t11=(C_word)C_u_fixnum_difference(t2,t9);
t12=(C_word)C_u_fixnum_plus(t3,t9);
/* tcp.scm: 471  loop */
t19=t1;
t20=t11;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}

/* k1609 in loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1622,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1620 in k1609 in loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 468  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[41],t1);}

/* k1616 in k1609 in loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 466  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1577 in loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 457  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1580 in k1577 in loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 458  yield */
f_1068(t2);}

/* k1583 in k1580 in k1577 in loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 460  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[13],lf[40],((C_word*)t0)[2]);}
else{
t3=t2;
f_1588(2,t3,C_SCHEME_UNDEFINED);}}

/* k1586 in k1583 in k1580 in k1577 in loop in output in k1544 in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 463  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1557(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1473,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1479(t5,t1);}

/* loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1479,NULL,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=(C_word)stub85(C_SCHEME_UNDEFINED,t2,t4,C_fix(1024),C_fix(0));
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_plus(t9,((C_word*)t0)[4]);
/* tcp.scm: 352  ##sys#thread-block-for-timeout! */
t11=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,*((C_word*)lf[9]+1),t10);}
else{
t9=t8;
f_1498(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1530,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 363  ##sys#update-errno */
t9=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1528 in loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1541,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1539 in k1528 in loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 366  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[39],t1);}

/* k1535 in k1528 in loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 364  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1496 in loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 355  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1499 in k1496 in loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 356  yield */
f_1068(t2);}

/* k1502 in k1499 in k1496 in loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 358  ##sys#signal-hook */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[13],lf[36],((C_word*)t0)[2]);}
else{
t3=t2;
f_1507(2,t3,C_SCHEME_UNDEFINED);}}

/* k1505 in k1502 in k1499 in k1496 in loop in read-input in k1470 in k1467 in k1464 in k1461 in k1455 in k1452 in ##net#io-ports in k1446 in k1442 in k1438 in k1434 in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 361  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1479(t2,((C_word*)t0)[2]);}

/* check in k1411 in k1027 in k943 in k940 in k937 */
static void C_fcall f_1419(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1419,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_1421 in check in k1411 in k1027 in k943 in k940 in k937 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1421,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k1027 in k943 in k940 in k937 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1378,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[25]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_977(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1394,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 304  ##sys#update-errno */
t8=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k1392 in tcp-close in k1027 in k943 in k940 in k937 */
static void C_ccall f_1394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1403 in k1392 in tcp-close in k1027 in k943 in k940 in k937 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[29],t1);}

/* k1399 in k1392 in tcp-close in k1027 in k943 in k940 in k937 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 305  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[28],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k1027 in k943 in k940 in k937 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1369,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[25]):C_SCHEME_FALSE));}

/* tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_1274r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1274r(t0,t1,t2,t3);}}

static void C_ccall f_1274r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1324,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w324360 */
t7=t6;
f_1324(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host325356 */
t9=t5;
f_1319(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body322331 */
t11=t4;
f_1276(t11,t1,t7,t9);}}}

/* def-w324 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_fcall f_1324(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1324,NULL,2,t0,t1);}
/* def-host325356 */
t2=((C_word*)t0)[2];
f_1319(t2,t1,C_fix(10));}

/* def-host325 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_fcall f_1319(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1319,NULL,3,t0,t1,t2);}
/* body322331 */
t3=((C_word*)t0)[2];
f_1276(t3,t1,t2,C_SCHEME_FALSE);}

/* body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_fcall f_1276(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1276,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1282,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a1287 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1288,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)stub53(C_SCHEME_UNDEFINED,t5,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1307,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 292  ##sys#update-errno */
t11=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_1298(2,t10,C_SCHEME_UNDEFINED);}}

/* k1305 in a1287 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1316 in k1305 in a1287 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[26],t1);}

/* k1312 in k1305 in a1287 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 293  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[11],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1296 in a1287 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1298,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[25],((C_word*)t0)[2]));}

/* a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1175,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 261  ##sys#signal-hook */
t9=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[23],lf[11],lf[24],t2);}
else{
t9=t6;
f_1175(2,t9,C_SCHEME_UNDEFINED);}}

/* k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1175,2,t0,t1);}
t2=f_947(C_fix((C_word)AF_INET),((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1257,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 264  ##sys#update-errno */
t6=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1181(2,t5,C_SCHEME_UNDEFINED);}}

/* k1255 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 265  ##sys#error */
t2=*((C_word*)lf[21]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[22]);}

/* k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1181,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1184,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1250,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_1250 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1250,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub289(C_SCHEME_UNDEFINED,t2));}

/* k1247 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 271  ##sys#update-errno */
t4=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_1184(2,t3,C_SCHEME_UNDEFINED);}}

/* k1232 in k1247 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1245,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1243 in k1232 in k1247 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[20],t1);}

/* k1239 in k1232 in k1247 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 272  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[11],t1,((C_word*)t0)[2]);}

/* k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1184,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1187,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 273  make-string */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1185 in k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1187,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 275  ##net#gethostaddr */
f_1054(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=t2;
f_1190(2,t5,(C_word)stub254(C_SCHEME_UNDEFINED,t4,((C_word*)t0)[3]));}}

/* k1220 in k1185 in k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_1190(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 276  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[11],lf[18],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1188 in k1185 in k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
t5=(C_word)stub41(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 280  ##sys#update-errno */
t9=*((C_word*)lf[17]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1196(2,t8,C_SCHEME_UNDEFINED);}}

/* k1203 in k1188 in k1185 in k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1214 in k1203 in k1188 in k1185 in k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#string-append */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[15],t1);}

/* k1210 in k1203 in k1188 in k1185 in k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 281  ##sys#signal-hook */
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[11],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1194 in k1188 in k1185 in k1182 in k1179 in k1173 in a1281 in body322 in tcp-listen in k1027 in k943 in k940 in k937 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 282  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k1027 in k943 in k940 in k937 */
static void C_fcall f_1068(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1068,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1074,tmp=(C_word)a,a+=2,tmp);
/* tcp.scm: 220  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a1073 in yield in k1027 in k943 in k940 in k937 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1074,3,t0,t1,t2);}
t3=*((C_word*)lf[9]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1083,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 224  ##sys#schedule */
t6=*((C_word*)lf[10]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a1082 in a1073 in yield in k1027 in k943 in k940 in k937 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
/* tcp.scm: 223  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k1027 in k943 in k940 in k937 */
static void C_fcall f_1054(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1054,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?t2:C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1063,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* ##sys#make-c-string */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t7=t6;
f_1063(2,t7,C_SCHEME_FALSE);}}

/* k1061 in ##net#gethostaddr in k1027 in k943 in k940 in k937 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub204(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* ##net#select in k1027 in k943 in k940 in k937 */
static C_word C_fcall f_1048(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub190(C_SCHEME_UNDEFINED,t1));}

/* ##net#getsockport in k943 in k940 in k937 */
static C_word C_fcall f_1013(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub149(C_SCHEME_UNDEFINED,t1));}

/* ##net#make-nonblocking in k943 in k940 in k937 */
static C_word C_fcall f_1004(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub135(C_SCHEME_UNDEFINED,t1));}

/* ##net#shutdown in k943 in k940 in k937 */
static C_word C_fcall f_987(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub98(C_SCHEME_UNDEFINED,t1,t2));}

/* ##net#close in k943 in k940 in k937 */
static C_word C_fcall f_977(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub76(C_SCHEME_UNDEFINED,t1));}

/* ##net#socket in k943 in k940 in k937 */
static C_word C_fcall f_947(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)stub31(C_SCHEME_UNDEFINED,t1,t2,t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[213] = {
{"toplevel:tcp_scm",(void*)C_tcp_toplevel},
{"f_939:tcp_scm",(void*)f_939},
{"f_942:tcp_scm",(void*)f_942},
{"f_945:tcp_scm",(void*)f_945},
{"f_1029:tcp_scm",(void*)f_1029},
{"f_1413:tcp_scm",(void*)f_1413},
{"f_2647:tcp_scm",(void*)f_2647},
{"f_1436:tcp_scm",(void*)f_1436},
{"f_2643:tcp_scm",(void*)f_2643},
{"f_1440:tcp_scm",(void*)f_1440},
{"f_2639:tcp_scm",(void*)f_2639},
{"f_1444:tcp_scm",(void*)f_1444},
{"f_2635:tcp_scm",(void*)f_2635},
{"f_1448:tcp_scm",(void*)f_1448},
{"f_2624:tcp_scm",(void*)f_2624},
{"f_2604:tcp_scm",(void*)f_2604},
{"f_2608:tcp_scm",(void*)f_2608},
{"f_2615:tcp_scm",(void*)f_2615},
{"f_2575:tcp_scm",(void*)f_2575},
{"f_2602:tcp_scm",(void*)f_2602},
{"f_2598:tcp_scm",(void*)f_2598},
{"f_2588:tcp_scm",(void*)f_2588},
{"f_2527:tcp_scm",(void*)f_2527},
{"f_2531:tcp_scm",(void*)f_2531},
{"f_2534:tcp_scm",(void*)f_2534},
{"f_2573:tcp_scm",(void*)f_2573},
{"f_2569:tcp_scm",(void*)f_2569},
{"f_2544:tcp_scm",(void*)f_2544},
{"f_2562:tcp_scm",(void*)f_2562},
{"f_2558:tcp_scm",(void*)f_2558},
{"f_2551:tcp_scm",(void*)f_2551},
{"f_2479:tcp_scm",(void*)f_2479},
{"f_2483:tcp_scm",(void*)f_2483},
{"f_2486:tcp_scm",(void*)f_2486},
{"f_2493:tcp_scm",(void*)f_2493},
{"f_2525:tcp_scm",(void*)f_2525},
{"f_2521:tcp_scm",(void*)f_2521},
{"f_2496:tcp_scm",(void*)f_2496},
{"f_2500:tcp_scm",(void*)f_2500},
{"f_2514:tcp_scm",(void*)f_2514},
{"f_2510:tcp_scm",(void*)f_2510},
{"f_2503:tcp_scm",(void*)f_2503},
{"f_2461:tcp_scm",(void*)f_2461},
{"f_2465:tcp_scm",(void*)f_2465},
{"f_2215:tcp_scm",(void*)f_2215},
{"f_2222:tcp_scm",(void*)f_2222},
{"f_2444:tcp_scm",(void*)f_2444},
{"f_2438:tcp_scm",(void*)f_2438},
{"f_1098:tcp_scm",(void*)f_1098},
{"f_1121:tcp_scm",(void*)f_1121},
{"f_1125:tcp_scm",(void*)f_1125},
{"f_1036:tcp_scm",(void*)f_1036},
{"f_1040:tcp_scm",(void*)f_1040},
{"f_1137:tcp_scm",(void*)f_1137},
{"f_1148:tcp_scm",(void*)f_1148},
{"f_1144:tcp_scm",(void*)f_1144},
{"f_1131:tcp_scm",(void*)f_1131},
{"f_2430:tcp_scm",(void*)f_2430},
{"f_2228:tcp_scm",(void*)f_2228},
{"f_2234:tcp_scm",(void*)f_2234},
{"f_2416:tcp_scm",(void*)f_2416},
{"f_2427:tcp_scm",(void*)f_2427},
{"f_2423:tcp_scm",(void*)f_2423},
{"f_2260:tcp_scm",(void*)f_2260},
{"f_2407:tcp_scm",(void*)f_2407},
{"f_2263:tcp_scm",(void*)f_2263},
{"f_2393:tcp_scm",(void*)f_2393},
{"f_2404:tcp_scm",(void*)f_2404},
{"f_2400:tcp_scm",(void*)f_2400},
{"f_2266:tcp_scm",(void*)f_2266},
{"f_2329:tcp_scm",(void*)f_2329},
{"f_2336:tcp_scm",(void*)f_2336},
{"f_2345:tcp_scm",(void*)f_2345},
{"f_2348:tcp_scm",(void*)f_2348},
{"f_2351:tcp_scm",(void*)f_2351},
{"f_2354:tcp_scm",(void*)f_2354},
{"f_2269:tcp_scm",(void*)f_2269},
{"f_2315:tcp_scm",(void*)f_2315},
{"f_2311:tcp_scm",(void*)f_2311},
{"f_2295:tcp_scm",(void*)f_2295},
{"f_2291:tcp_scm",(void*)f_2291},
{"f_2275:tcp_scm",(void*)f_2275},
{"f_2239:tcp_scm",(void*)f_2239},
{"f_2246:tcp_scm",(void*)f_2246},
{"f_2257:tcp_scm",(void*)f_2257},
{"f_2253:tcp_scm",(void*)f_2253},
{"f_2170:tcp_scm",(void*)f_2170},
{"f_2189:tcp_scm",(void*)f_2189},
{"f_2200:tcp_scm",(void*)f_2200},
{"f_2196:tcp_scm",(void*)f_2196},
{"f_2180:tcp_scm",(void*)f_2180},
{"f_2084:tcp_scm",(void*)f_2084},
{"f_2094:tcp_scm",(void*)f_2094},
{"f_2099:tcp_scm",(void*)f_2099},
{"f_2135:tcp_scm",(void*)f_2135},
{"f_2138:tcp_scm",(void*)f_2138},
{"f_2141:tcp_scm",(void*)f_2141},
{"f_2144:tcp_scm",(void*)f_2144},
{"f_2121:tcp_scm",(void*)f_2121},
{"f_2132:tcp_scm",(void*)f_2132},
{"f_2128:tcp_scm",(void*)f_2128},
{"f_2112:tcp_scm",(void*)f_2112},
{"f_1450:tcp_scm",(void*)f_1450},
{"f_2071:tcp_scm",(void*)f_2071},
{"f_2082:tcp_scm",(void*)f_2082},
{"f_2078:tcp_scm",(void*)f_2078},
{"f_1454:tcp_scm",(void*)f_1454},
{"f_1457:tcp_scm",(void*)f_1457},
{"f_1463:tcp_scm",(void*)f_1463},
{"f_1466:tcp_scm",(void*)f_1466},
{"f_1469:tcp_scm",(void*)f_1469},
{"f_1472:tcp_scm",(void*)f_1472},
{"f_1949:tcp_scm",(void*)f_1949},
{"f_1959:tcp_scm",(void*)f_1959},
{"f_2047:tcp_scm",(void*)f_2047},
{"f_1975:tcp_scm",(void*)f_1975},
{"f_1982:tcp_scm",(void*)f_1982},
{"f_2004:tcp_scm",(void*)f_2004},
{"f_2020:tcp_scm",(void*)f_2020},
{"f_1884:tcp_scm",(void*)f_1884},
{"f_1890:tcp_scm",(void*)f_1890},
{"f_1938:tcp_scm",(void*)f_1938},
{"f_1841:tcp_scm",(void*)f_1841},
{"f_1855:tcp_scm",(void*)f_1855},
{"f_1858:tcp_scm",(void*)f_1858},
{"f_1869:tcp_scm",(void*)f_1869},
{"f_1865:tcp_scm",(void*)f_1865},
{"f_1806:tcp_scm",(void*)f_1806},
{"f_1828:tcp_scm",(void*)f_1828},
{"f_1839:tcp_scm",(void*)f_1839},
{"f_1835:tcp_scm",(void*)f_1835},
{"f_1819:tcp_scm",(void*)f_1819},
{"f_1784:tcp_scm",(void*)f_1784},
{"f_1788:tcp_scm",(void*)f_1788},
{"f_1546:tcp_scm",(void*)f_1546},
{"f_1732:tcp_scm",(void*)f_1732},
{"f_1742:tcp_scm",(void*)f_1742},
{"f_1669:tcp_scm",(void*)f_1669},
{"f_1716:tcp_scm",(void*)f_1716},
{"f_1719:tcp_scm",(void*)f_1719},
{"f_1677:tcp_scm",(void*)f_1677},
{"f_1686:tcp_scm",(void*)f_1686},
{"f_1689:tcp_scm",(void*)f_1689},
{"f_1700:tcp_scm",(void*)f_1700},
{"f_1696:tcp_scm",(void*)f_1696},
{"f_1768:tcp_scm",(void*)f_1768},
{"f_1748:tcp_scm",(void*)f_1748},
{"f_1753:tcp_scm",(void*)f_1753},
{"f_1762:tcp_scm",(void*)f_1762},
{"f_1642:tcp_scm",(void*)f_1642},
{"f_1547:tcp_scm",(void*)f_1547},
{"f_1557:tcp_scm",(void*)f_1557},
{"f_1611:tcp_scm",(void*)f_1611},
{"f_1622:tcp_scm",(void*)f_1622},
{"f_1618:tcp_scm",(void*)f_1618},
{"f_1579:tcp_scm",(void*)f_1579},
{"f_1582:tcp_scm",(void*)f_1582},
{"f_1585:tcp_scm",(void*)f_1585},
{"f_1588:tcp_scm",(void*)f_1588},
{"f_1473:tcp_scm",(void*)f_1473},
{"f_1479:tcp_scm",(void*)f_1479},
{"f_1530:tcp_scm",(void*)f_1530},
{"f_1541:tcp_scm",(void*)f_1541},
{"f_1537:tcp_scm",(void*)f_1537},
{"f_1498:tcp_scm",(void*)f_1498},
{"f_1501:tcp_scm",(void*)f_1501},
{"f_1504:tcp_scm",(void*)f_1504},
{"f_1507:tcp_scm",(void*)f_1507},
{"f_1419:tcp_scm",(void*)f_1419},
{"f_1421:tcp_scm",(void*)f_1421},
{"f_1378:tcp_scm",(void*)f_1378},
{"f_1394:tcp_scm",(void*)f_1394},
{"f_1405:tcp_scm",(void*)f_1405},
{"f_1401:tcp_scm",(void*)f_1401},
{"f_1369:tcp_scm",(void*)f_1369},
{"f_1274:tcp_scm",(void*)f_1274},
{"f_1324:tcp_scm",(void*)f_1324},
{"f_1319:tcp_scm",(void*)f_1319},
{"f_1276:tcp_scm",(void*)f_1276},
{"f_1288:tcp_scm",(void*)f_1288},
{"f_1307:tcp_scm",(void*)f_1307},
{"f_1318:tcp_scm",(void*)f_1318},
{"f_1314:tcp_scm",(void*)f_1314},
{"f_1298:tcp_scm",(void*)f_1298},
{"f_1282:tcp_scm",(void*)f_1282},
{"f_1175:tcp_scm",(void*)f_1175},
{"f_1257:tcp_scm",(void*)f_1257},
{"f_1181:tcp_scm",(void*)f_1181},
{"f_1250:tcp_scm",(void*)f_1250},
{"f_1249:tcp_scm",(void*)f_1249},
{"f_1234:tcp_scm",(void*)f_1234},
{"f_1245:tcp_scm",(void*)f_1245},
{"f_1241:tcp_scm",(void*)f_1241},
{"f_1184:tcp_scm",(void*)f_1184},
{"f_1187:tcp_scm",(void*)f_1187},
{"f_1222:tcp_scm",(void*)f_1222},
{"f_1190:tcp_scm",(void*)f_1190},
{"f_1205:tcp_scm",(void*)f_1205},
{"f_1216:tcp_scm",(void*)f_1216},
{"f_1212:tcp_scm",(void*)f_1212},
{"f_1196:tcp_scm",(void*)f_1196},
{"f_1068:tcp_scm",(void*)f_1068},
{"f_1074:tcp_scm",(void*)f_1074},
{"f_1083:tcp_scm",(void*)f_1083},
{"f_1054:tcp_scm",(void*)f_1054},
{"f_1063:tcp_scm",(void*)f_1063},
{"f_1048:tcp_scm",(void*)f_1048},
{"f_1013:tcp_scm",(void*)f_1013},
{"f_1004:tcp_scm",(void*)f_1004},
{"f_987:tcp_scm",(void*)f_987},
{"f_977:tcp_scm",(void*)f_977},
{"f_947:tcp_scm",(void*)f_947},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
