/* Generated from nsample.scm by the Chicken compiler
   2005-08-24 19:48
   Version 2, Build 106 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: nsample.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file nsample.c -explicit-use -uses library -uses eval
   used units: library eval
   default installation home: /usr/local/share/chicken
   default heap size: 0
   default nursery (stack) size: 65536
*/

#include "chicken.h"

C_externimport void C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[50];


C_externexport void C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_139(C_word c,C_word t0,C_word t1) C_noret;
static void f_142(C_word c,C_word t0,C_word t1) C_noret;
static void f_146(C_word c,C_word t0,C_word t1) C_noret;
static void f_958(C_word c,C_word t0,C_word t1) C_noret;
static void f_961(C_word c,C_word t0,C_word t1) C_noret;
static void f_964(C_word c,C_word t0,C_word t1) C_noret;
static void f_970(C_word c,C_word t0,C_word t1) C_noret;
static void f_967(C_word c,C_word t0,C_word t1) C_noret;
static void f_875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_881(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_900(C_word t0,C_word t1,C_word t2) C_noret;
static void f_921(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_923(C_word t0,C_word t1,C_word t2) C_noret;
static void f_933(C_word c,C_word t0,C_word t1) C_noret;
static void f_910(C_word c,C_word t0,C_word t1) C_noret;
static void f_891(C_word c,C_word t0,C_word t1) C_noret;
static void f_861(C_word c,C_word t0,C_word t1) C_noret;
static void f_873(C_word c,C_word t0,C_word t1) C_noret;
static void f_869(C_word c,C_word t0,C_word t1) C_noret;
static void f_526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_551(C_word t0,C_word t1) C_noret;
static void f_793(C_word c,C_word t0,C_word t1) C_noret;
static void f_781(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_709(C_word c,C_word t0,C_word t1) C_noret;
static void f_722(C_word c,C_word t0,C_word t1) C_noret;
static void f_682(C_word c,C_word t0,C_word t1) C_noret;
static void f_809(C_word c,C_word t0,C_word t1) C_noret;
static void f_571(C_word c,C_word t0,C_word t1) C_noret;
static void f_577(C_word c,C_word t0,C_word t1) C_noret;
static void f_441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_447(C_word t0,C_word t1,C_word t2) C_noret;
static void f_520(C_word c,C_word t0,C_word t1) C_noret;
static void f_457(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_460(C_word c,C_word t0,C_word t1) C_noret;
static void f_430(C_word c,C_word t0,C_word t1) C_noret;
static void f_435(C_word c,C_word t0,C_word t1) C_noret;
static void f_266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_270(C_word c,C_word t0,C_word t1) C_noret;
static void f_280(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_282(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_384(C_word t0,C_word t1,C_word t2) C_noret;
static void f_405(C_word c,C_word t0,C_word t1) C_noret;
static void f_394(C_word c,C_word t0,C_word t1) C_noret;
static void f_296(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_356(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_354(C_word c,C_word t0,C_word t1) C_noret;
static void f_299(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_329(C_word t0,C_word t1,C_word t2) C_noret;
static void f_350(C_word c,C_word t0,C_word t1) C_noret;
static void f_339(C_word c,C_word t0,C_word t1) C_noret;
static void f_302(C_word c,C_word t0,C_word t1) C_noret;
static void f_317(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_407(C_word t0,C_word t1);
static void f_233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_247(C_word c,C_word t0,C_word t1) C_noret;
static void f_251(C_word c,C_word t0,C_word t1) C_noret;
static void f_198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_214(C_word t0,C_word t1,C_word t2);
static void f_169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_176(C_word c,C_word t0,C_word t1) C_noret;
static void f_148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_155(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_158(C_word t0,C_word t1) C_noret;

static void C_fcall trf_881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_881(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_881(t0,t1,t2);}

static void C_fcall trf_900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_900(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_900(t0,t1,t2);}

static void C_fcall trf_923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_923(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_923(t0,t1,t2);}

static void C_fcall trf_551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_551(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_551(t0,t1);}

static void C_fcall trf_699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_699(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_699(t0,t1,t2,t3,t4);}

static void C_fcall trf_447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_447(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_447(t0,t1,t2);}

static void C_fcall trf_483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_483(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_483(t0,t1,t2,t3);}

static void C_fcall trf_282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_282(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_282(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_384(t0,t1,t2);}

static void C_fcall trf_356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_356(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_356(t0,t1,t2,t3,t4);}

static void C_fcall trf_329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_329(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_329(t0,t1,t2);}

static void C_fcall trf_158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_158(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_158(t0,t1);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(65536);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1005)){
C_save(t1);
C_rereclaim2(1005*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,50);
lf[0]=C_h_intern(&lf[0],18,"plists:plist-table");
lf[1]=C_h_intern(&lf[1],3,"get");
lf[2]=C_h_intern(&lf[2],18,"\003syshash-table-ref");
lf[3]=C_static_lambda_info(C_heaptop,16,"(get key2 prop3)");
lf[4]=C_h_intern(&lf[4],3,"put");
lf[5]=C_h_intern(&lf[5],19,"\003syshash-table-set!");
lf[6]=C_static_lambda_info(C_heaptop,23,"(put key9 prop10 val11)");
lf[7]=C_h_intern(&lf[7],7,"append!");
lf[8]=C_static_lambda_info(C_heaptop,10,"(do17 b20)");
lf[9]=C_static_lambda_info(C_heaptop,17,"(append! x15 y16)");
lf[10]=C_h_intern(&lf[10],9,"copy-tree");
lf[11]=C_static_lambda_info(C_heaptop,15,"(copy-tree x23)");
lf[12]=C_h_intern(&lf[12],6,"*rand*");
lf[13]=C_h_intern(&lf[13],4,"init");
lf[14]=C_static_lambda_info(C_heaptop,6,"(do29)");
lf[15]=C_h_intern(&lf[15],6,"gensym");
lf[16]=C_static_lambda_info(C_heaptop,10,"(do51 j53)");
lf[17]=C_h_intern(&lf[17],7,"pattern");
lf[18]=C_static_lambda_info(C_heaptop,22,"(do44 i46 ipats47 a48)");
lf[19]=C_static_lambda_info(C_heaptop,10,"(do39 i41)");
lf[20]=C_static_lambda_info(C_heaptop,25,"(do33 n35 i36 name37 a38)");
lf[21]=C_static_lambda_info(C_heaptop,30,"(init n24 m25 npats26 ipats27)");
lf[22]=C_h_intern(&lf[22],13,"browse-random");
lf[23]=C_h_intern(&lf[23],9,"remainder");
lf[24]=C_static_lambda_info(C_heaptop,15,"(browse-random)");
lf[25]=C_h_intern(&lf[25],9,"randomize");
lf[26]=C_static_lambda_info(C_heaptop,14,"(do70 n72 x73)");
lf[27]=C_static_lambda_info(C_heaptop,10,"(do64 a66)");
lf[28]=C_static_lambda_info(C_heaptop,15,"(randomize l63)");
lf[29]=C_h_intern(&lf[29],6,"bmatch");
lf[30]=C_h_intern(&lf[30],1,"\077");
lf[31]=C_h_intern(&lf[31],1,"*");
lf[32]=C_h_intern(&lf[32],6,"append");
lf[33]=C_static_lambda_info(C_heaptop,18,"(do90 l92 e93 d94)");
lf[34]=C_h_intern(&lf[34],14,"symbol->string");
lf[35]=C_static_lambda_info(C_heaptop,28,"(bmatch pat79 dat80 alist81)");
lf[36]=C_h_intern(&lf[36],6,"browse");
lf[37]=C_h_intern(&lf[37],11,"investigate");
tmp=C_intern(C_heaptop,2,"*a");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"\077b");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*b");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"\077b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*b");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*a");
C_save(tmp);
tmp=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*a");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*b");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*b");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*a");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*a");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,2,"*b");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_h_list(6,C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(6);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"\077");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"\077");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"*");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"*");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"\077");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"\077");
C_save(tmp);
tmp=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
C_save(tmp);
lf[38]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_h_list(17,C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(17);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_h_list(10,C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(10);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
C_save(tmp);
lf[39]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[40]=C_static_lambda_info(C_heaptop,8,"(browse)");
lf[41]=C_static_lambda_info(C_heaptop,12,"(do106 p108)");
lf[42]=C_static_lambda_info(C_heaptop,15,"(do103 pats105)");
lf[43]=C_static_lambda_info(C_heaptop,16,"(do100 units102)");
lf[44]=C_static_lambda_info(C_heaptop,28,"(investigate units98 pats99)");
lf[45]=C_h_intern(&lf[45],25,"\003sysimplicit-exit-handler");
lf[46]=C_h_intern(&lf[46],7,"newline");
lf[47]=C_h_intern(&lf[47],5,"write");
lf[48]=C_h_intern(&lf[48],11,"make-vector");
lf[49]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,50);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_139,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k137 */
static void f_139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_142,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k140 in k137 */
static void f_142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_146,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[48]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(997),C_SCHEME_END_OF_LIST);}

/* k144 in k140 in k137 */
static void f_146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_146,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1,t1);
t3=C_mutate((C_word*)lf[1]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_148,a[2]=lf[3],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[4]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_169,a[2]=lf[6],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_198,a[2]=lf[9],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_233,a[2]=lf[11],tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(lf[12],0,C_fix(21));
t8=C_mutate((C_word*)lf[13]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_266,a[2]=lf[21],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_430,a[2]=lf[24],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=lf[28],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_526,a[2]=lf[35],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_861,a[2]=lf[40],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_875,a[2]=lf[44],tmp=(C_word)a,a+=3,tmp));
t14=(C_word)C_fudge(C_fix(6));
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_958,a[2]=t14,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t16=C_retrieve(lf[36]);
((C_proc2)C_retrieve_proc(t16))(2,t16,t15);}

/* k956 in k144 in k140 in k137 */
static void f_958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_fudge(C_fix(6));
t4=(C_word)C_a_i_minus(&a,2,t3,((C_word*)t0)[2]);
t5=*((C_word*)lf[47]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}

/* k959 in k956 in k144 in k140 in k137 */
static void f_961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[46]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k962 in k959 in k956 in k144 in k140 in k137 */
static void f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_967,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_970,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[45]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k968 in k962 in k959 in k956 in k144 in k140 in k137 */
static void f_970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k965 in k962 in k959 in k956 in k144 in k140 in k137 */
static void f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* investigate in k144 in k140 in k137 */
static void f_875(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_875,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_881,a[2]=t3,a[3]=t5,a[4]=lf[43],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_881(t7,t1,t2);}

/* do100 in investigate in k144 in k140 in k137 */
static void C_fcall f_881(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_881,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_891,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_900,a[2]=t2,a[3]=t5,a[4]=lf[42],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_900(t7,t3,((C_word*)t0)[2]);}}

/* do103 in do100 in investigate in k144 in k140 in k137 */
static void C_fcall f_900(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_900,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_910,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_921,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[2]);
t6=C_retrieve(lf[1]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[17]);}}

/* k919 in do103 in do100 in investigate in k144 in k140 in k137 */
static void f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_921,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=lf[41],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_923(t5,((C_word*)t0)[2],t1);}

/* do106 in k919 in do103 in do100 in investigate in k144 in k140 in k137 */
static void C_fcall f_923(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_923,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_933,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[2]);
t5=(C_word)C_i_car(t2);
t6=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t3,t4,t5,C_SCHEME_END_OF_LIST);}}

/* k931 in do106 in k919 in do103 in do100 in investigate in k144 in k140 in k137 */
static void f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_923(t3,((C_word*)t0)[2],t2);}

/* k908 in do103 in do100 in investigate in k144 in k140 in k137 */
static void f_910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_900(t3,((C_word*)t0)[2],t2);}

/* k889 in do100 in investigate in k144 in k140 in k137 */
static void f_891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_881(t3,((C_word*)t0)[2],t2);}

/* browse in k144 in k140 in k137 */
static void f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_869,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_873,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve(lf[13]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_fix(100),C_fix(10),C_fix(4),lf[39]);}

/* k871 in browse in k144 in k140 in k137 */
static void f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[25]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k867 in browse in k144 in k140 in k137 */
static void f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[37]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[38]);}

/* bmatch in k144 in k140 in k137 */
static void f_526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_526,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_nullp(t3));}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[30]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_551,a[2]=t4,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_551(t8,t6);}
else{
t8=(C_word)C_i_car(t2);
t9=(C_word)C_i_car(t3);
t10=t7;
f_551(t10,(C_word)C_eqp(t8,t9));}}}}

/* k549 in bmatch in k144 in k140 in k137 */
static void C_fcall f_551(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_551,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(t2,lf[31]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_571,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
t6=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t4))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_i_car(((C_word*)t0)[4]);
t9=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,((C_word*)t0)[2]);}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_793,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}}}}

/* k791 in k549 in bmatch in k144 in k140 in k137 */
static void f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_793,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_eqp(t2,C_make_character(63));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_assv(t4,((C_word*)t0)[4]);
if(C_truep(t5)){
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_cdr(((C_word*)t0)[5]);
t8=(C_word)C_a_i_cons(&a,2,t6,t7);
t9=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t9))(5,t9,((C_word*)t0)[3],t8,((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t6=(C_word)C_i_cdr(((C_word*)t0)[5]);
t7=(C_word)C_i_cdr(((C_word*)t0)[2]);
t8=(C_word)C_i_car(((C_word*)t0)[5]);
t9=(C_word)C_i_car(((C_word*)t0)[2]);
t10=(C_word)C_a_i_cons(&a,2,t8,t9);
t11=(C_word)C_a_i_cons(&a,2,t10,((C_word*)t0)[4]);
t12=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t12))(5,t12,((C_word*)t0)[3],t6,t7,t11);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=*((C_word*)lf[34]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k779 in k791 in k549 in bmatch in k144 in k140 in k137 */
static void f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_781,2,t0,t1);}
t2=(C_word)C_i_string_ref(t1,C_fix(0));
t3=(C_word)C_eqp(t2,C_make_character(42));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_assv(t4,((C_word*)t0)[4]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_682,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_cdr(((C_word*)t0)[5]);
t9=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}
else{
t6=(C_word)C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_699,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t8,a[5]=lf[33],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_699(t10,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* do90 in k779 in k791 in k549 in bmatch in k144 in k140 in k137 */
static void C_fcall f_699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_699,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_709,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_709(2,t7,t5);}
else{
t7=(C_word)C_i_cdr(((C_word*)t0)[3]);
t8=(C_word)C_i_car(((C_word*)t0)[3]);
t9=(C_word)C_a_i_cons(&a,2,t8,t2);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t0)[2]);
t11=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t11))(5,t11,t6,t7,t4,t10);}}

/* k707 in do90 in k779 in k791 in k549 in bmatch in k144 in k140 in k137 */
static void f_709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_709,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_nullp(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:C_SCHEME_TRUE));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_nullp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:(C_word)C_i_car(((C_word*)t0)[4]));
t5=(C_word)C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,((C_word*)t0)[2],t5);}}

/* k720 in k707 in do90 in k779 in k791 in k549 in bmatch in k144 in k140 in k137 */
static void f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_nullp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(((C_word*)t0)[4]));
t5=((C_word*)((C_word*)t0)[3])[1];
f_699(t5,((C_word*)t0)[2],t1,t2,t4);}

/* k680 in k779 in k791 in k549 in bmatch in k144 in k140 in k137 */
static void f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k807 in k549 in bmatch in k144 in k140 in k137 */
static void f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k569 in k549 in bmatch in k144 in k140 in k137 */
static void f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_571,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=(C_word)C_i_cdr(((C_word*)t0)[4]);
t5=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t3,t4,((C_word*)t0)[2]);}}

/* k575 in k569 in k549 in bmatch in k144 in k140 in k137 */
static void f_577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=C_retrieve(lf[29]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[5],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* randomize in k144 in k140 in k137 */
static void f_441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_441,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_447,a[2]=t5,a[3]=t3,a[4]=lf[27],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_447(t7,t1,C_SCHEME_END_OF_LIST);}

/* do64 in randomize in k144 in k140 in k137 */
static void C_fcall f_447(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_447,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t3)[1]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_457,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_520,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_retrieve(lf[22]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}}

/* k518 in do64 in randomize in k144 in k140 in k137 */
static void f_520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_length(((C_word*)((C_word*)t0)[3])[1]);
t3=*((C_word*)lf[23]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k455 in do64 in randomize in k144 in k140 in k137 */
static void f_457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_zerop(t1))){
t3=(C_word)C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=(C_word)C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_460(2,t8,((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_483,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=lf[26],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_483(t6,t2,t1,((C_word*)((C_word*)t0)[2])[1]);}}

/* do70 in k455 in do64 in randomize in k144 in k140 in k137 */
static void C_fcall f_483(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_483,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nequalp(t2,C_fix(1)))){
t4=(C_word)C_i_cadr(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)((C_word*)t0)[3])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(C_word)C_i_cddr(t3);
t8=(C_word)C_i_set_cdr(t3,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t3);}
else{
t4=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t5=(C_word)C_i_cdr(t3);
t12=t1;
t13=t4;
t14=t5;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k458 in k455 in do64 in randomize in k144 in k140 in k137 */
static void f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_447(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* browse-random in k144 in k140 in k137 */
static void f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_435,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_times(&a,2,C_retrieve(lf[12]),C_fix(17));
t4=*((C_word*)lf[23]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_fix(251));}

/* k433 in browse-random in k144 in k140 in k137 */
static void f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[12]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[12]));}

/* init in k144 in k140 in k137 */
static void f_266(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=6) C_bad_argc(c,6);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_266,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_270,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k268 in init in k144 in k140 in k137 */
static void f_270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_407,a[2]=t1,a[3]=lf[14],tmp=(C_word)a,a+=4,tmp);
t3=f_407(t2,t1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k278 in k268 in init in k144 in k140 in k137 */
static void f_280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_280,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=lf[20],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_282(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[6],t1,C_SCHEME_END_OF_LIST);}

/* do33 in k278 in k268 in init in k144 in k140 in k137 */
static void C_fcall f_282(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_282,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_nequalp(t2,C_fix(0)))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t6)[1]);}
else{
t7=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t6)[1]);
t8=C_set_block_item(t6,0,t7);
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_384,a[2]=t4,a[3]=t11,a[4]=lf[19],tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_384(t13,t9,t3);}}

/* do39 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void C_fcall f_384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_384,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_zerop(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_394,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_405,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k403 in do39 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k392 in do39 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_394,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_384(t3,((C_word*)t0)[2],t2);}

/* k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_299,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_354,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_356,a[2]=t5,a[3]=lf[18],tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_356(t7,t3,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* do44 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void C_fcall f_356(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_356,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_zerop(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(C_word)C_i_car(t3);
t6=(C_word)C_a_i_cons(&a,2,t5,t4);
t7=t4=t6;
t8=(C_word)C_a_i_minus(&a,2,t2,C_fix(1));
t9=(C_word)C_i_cdr(t3);
t11=t1;
t12=t8;
t13=t9;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k352 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[17],t1);}

/* k297 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],((C_word*)t0)[7]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_329,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=lf[16],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_329(t7,t2,t3);}

/* do51 in k297 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void C_fcall f_329(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_329,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_zerop(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_339,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k348 in do51 in k297 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k337 in do51 in k297 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_339,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_329(t3,((C_word*)t0)[2],t2);}

/* k300 in k297 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_302,2,t0,t1);}
t2=(C_word)C_a_i_minus(&a,2,((C_word*)t0)[7],C_fix(1));
t3=(C_word)C_i_zerop(((C_word*)t0)[6]);
t4=(C_truep(t3)?((C_word*)t0)[5]:(C_word)C_a_i_minus(&a,2,((C_word*)t0)[6],C_fix(1)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_317,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=C_retrieve(lf[15]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k315 in k300 in k297 in k294 in do33 in k278 in k268 in init in k144 in k140 in k137 */
static void f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[6])[1];
f_282(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* do29 in k268 in init in k144 in k140 in k137 */
static C_word C_fcall f_407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
return((C_word)C_i_set_cdr(t1,((C_word*)t0)[2]));}
else{
t3=(C_word)C_i_cdr(t1);
t5=t3;
t1=t5;
goto loop;}}

/* copy-tree in k144 in k140 in k137 */
static void f_233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_233,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_247,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
t5=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k245 in copy-tree in k144 in k140 in k137 */
static void f_247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_251,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k249 in k245 in copy-tree in k144 in k140 in k137 */
static void f_251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_251,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append! in k144 in k140 in k137 */
static void f_198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_198,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_214,a[2]=t2,a[3]=t3,a[4]=lf[8],tmp=(C_word)a,a+=5,tmp);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_214(t5,t2,t4));}}

/* do17 in append! in k144 in k140 in k137 */
static C_word C_fcall f_214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_set_cdr(t1,((C_word*)t0)[3]);
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_i_cdr(t2);
t6=t2;
t7=t3;
t1=t6;
t2=t7;
goto loop;}}

/* put in k144 in k140 in k137 */
static void f_169(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_169,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_symbol(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_176,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,*((C_word*)lf[0]+1),t2);}

/* k174 in put in k144 in k140 in k137 */
static void f_176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_176,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t2,C_fix(1),((C_word*)t0)[3]));}
else{
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_a_i_cons(&a,2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[3]),t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t1,C_fix(1),t4));}}
else{
t2=*((C_word*)lf[5]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],*((C_word*)lf[0]+1),((C_word*)t0)[2],(C_word)C_a_i_cons(&a,2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[3]),C_SCHEME_END_OF_LIST));}}

/* get in k144 in k140 in k137 */
static void f_148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_148,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_155,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[2]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,*((C_word*)lf[0]+1),t2);}

/* k153 in get in k144 in k140 in k137 */
static void f_155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_158,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_assq(((C_word*)t0)[2],t1);
t4=t2;
f_158(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_158(t3,C_SCHEME_FALSE);}}

/* k156 in k153 in get in k144 in k140 in k137 */
static void C_fcall f_158(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:C_SCHEME_END_OF_LIST));}
/* end of file */
