/* Generated from pregexp.scm by the Chicken compiler
   2005-09-10 23:31
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: pregexp.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file upregexp.c -explicit-use
   unit: regex
*/

#include "chicken.h"


static C_TLS C_word lf[153];


C_externexport void C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_671(C_word c,C_word t0,C_word t1) C_noret;
static void f_5521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5525(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5533(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5565(C_word c,C_word t0,C_word t1) C_noret;
static void f_5552(C_word c,C_word t0,C_word t1) C_noret;
static void f_5555(C_word c,C_word t0,C_word t1) C_noret;
static void f_5484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5490(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5509(C_word c,C_word t0,C_word t1) C_noret;
static void f_5516(C_word c,C_word t0,C_word t1) C_noret;
static void f_5395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5407(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5479(C_word c,C_word t0,C_word t1) C_noret;
static void f_5475(C_word c,C_word t0,C_word t1) C_noret;
static void f_5468(C_word c,C_word t0,C_word t1) C_noret;
static void f_5452(C_word c,C_word t0,C_word t1) C_noret;
static void f_5439(C_word c,C_word t0,C_word t1) C_noret;
static void f_5435(C_word c,C_word t0,C_word t1) C_noret;
static void f_5403(C_word c,C_word t0,C_word t1) C_noret;
static void f_5248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_5287(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5317(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5326(C_word t0,C_word t1) C_noret;
static void C_fcall f_5373(C_word t0,C_word t1) C_noret;
static void f_5358(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5332(C_word t0,C_word t1) C_noret;
static void f_5282(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5272(C_word t0,C_word t1) C_noret;
static void f_5268(C_word c,C_word t0,C_word t1) C_noret;
static void f_5000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_5000r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_5162(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5166(C_word c,C_word t0,C_word t1) C_noret;
static void f_5236(C_word c,C_word t0,C_word t1) C_noret;
static void f_5232(C_word c,C_word t0,C_word t1) C_noret;
static void f_5215(C_word c,C_word t0,C_word t1) C_noret;
static void f_5197(C_word c,C_word t0,C_word t1) C_noret;
static void f_5190(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5124(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5128(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5133(C_word t0,C_word t1,C_word t2);
static void C_fcall f_5027(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5100(C_word c,C_word t0,C_word t1) C_noret;
static void f_5088(C_word c,C_word t0,C_word t1) C_noret;
static void f_5047(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5012(C_word *a,C_word t0,C_word t1);
static void f_4825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4825r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4981(C_word c,C_word t0,C_word t1) C_noret;
static void f_4940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4841(C_word t0,C_word t1) C_noret;
static void C_fcall f_4849(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4853(C_word c,C_word t0,C_word t1) C_noret;
static void f_4914(C_word c,C_word t0,C_word t1) C_noret;
static void f_4895(C_word c,C_word t0,C_word t1) C_noret;
static void f_4929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4799r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4803(C_word c,C_word t0,C_word t1) C_noret;
static void f_4811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4793r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4767r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4771(C_word c,C_word t0,C_word t1) C_noret;
static void f_4779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4755(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_4736(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4744(C_word c,C_word t0,C_word t1) C_noret;
static void f_4676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4680(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4691(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4695(C_word c,C_word t0,C_word t1) C_noret;
static void f_4728(C_word c,C_word t0,C_word t1) C_noret;
static void f_4713(C_word c,C_word t0,C_word t1) C_noret;
static void f_4717(C_word c,C_word t0,C_word t1) C_noret;
static void f_4709(C_word c,C_word t0,C_word t1) C_noret;
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4644(C_word c,C_word t0,C_word t1) C_noret;
static void f_4666(C_word c,C_word t0,C_word t1) C_noret;
static void f_4670(C_word c,C_word t0,C_word t1) C_noret;
static void f_4674(C_word c,C_word t0,C_word t1) C_noret;
static void f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4564(C_word c,C_word t0,C_word t1) C_noret;
static void f_4635(C_word c,C_word t0,C_word t1) C_noret;
static void f_4621(C_word c,C_word t0,C_word t1) C_noret;
static void f_4597(C_word c,C_word t0,C_word t1) C_noret;
static void f_4513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4513r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4517(C_word c,C_word t0,C_word t1) C_noret;
static void f_4525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4448r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4452(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4455(C_word t0,C_word t1) C_noret;
static void C_fcall f_4463(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_2936(C_word t0,C_word t1) C_noret;
static void C_fcall f_2965(C_word t0,C_word t1) C_noret;
static void C_fcall f_2991(C_word t0,C_word t1) C_noret;
static void C_fcall f_3519(C_word t0,C_word t1) C_noret;
static void C_fcall f_3524(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3581(C_word t0,C_word t1) C_noret;
static void f_3609(C_word c,C_word t0,C_word t1) C_noret;
static void f_3617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3596(C_word c,C_word t0,C_word t1) C_noret;
static void f_3554(C_word c,C_word t0,C_word t1) C_noret;
static void f_3562(C_word c,C_word t0,C_word t1) C_noret;
static void f_3536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3489(C_word c,C_word t0,C_word t1) C_noret;
static void f_3482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3459(C_word c,C_word t0,C_word t1) C_noret;
static void f_3436(C_word c,C_word t0,C_word t1) C_noret;
static void f_3422(C_word c,C_word t0,C_word t1) C_noret;
static void f_3406(C_word c,C_word t0,C_word t1) C_noret;
static void f_3391(C_word c,C_word t0,C_word t1) C_noret;
static void f_3375(C_word c,C_word t0,C_word t1) C_noret;
static void f_3364(C_word c,C_word t0,C_word t1) C_noret;
static void f_3349(C_word c,C_word t0,C_word t1) C_noret;
static void f_3339(C_word c,C_word t0,C_word t1) C_noret;
static void f_3324(C_word c,C_word t0,C_word t1) C_noret;
static void f_3295(C_word c,C_word t0,C_word t1) C_noret;
static void f_3304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3252(C_word c,C_word t0,C_word t1) C_noret;
static void f_3262(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2426(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3264(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3200(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3235(C_word c,C_word t0,C_word t1) C_noret;
static void f_3219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3223(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3135(C_word c,C_word t0,C_word t1) C_noret;
static void f_3129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3078(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3097(C_word c,C_word t0,C_word t1) C_noret;
static void f_3016(C_word c,C_word t0,C_word t1) C_noret;
static void f_3003(C_word c,C_word t0,C_word t1) C_noret;
static void f_2971(C_word c,C_word t0,C_word t1) C_noret;
static void f_2942(C_word c,C_word t0,C_word t1) C_noret;
static void f_2924(C_word c,C_word t0,C_word t1) C_noret;
static void f_2906(C_word c,C_word t0,C_word t1) C_noret;
static void f_2845(C_word c,C_word t0,C_word t1) C_noret;
static void f_4473(C_word c,C_word t0,C_word t1) C_noret;
static void f_4432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4373(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4373r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4387(C_word c,C_word t0,C_word t1) C_noret;
static void f_4399(C_word c,C_word t0,C_word t1) C_noret;
static void f_4381(C_word c,C_word t0,C_word t1) C_noret;
static void f_4354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4367(C_word c,C_word t0,C_word t1) C_noret;
static void f_3950(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4341(C_word c,C_word t0,C_word t1) C_noret;
static void f_4337(C_word c,C_word t0,C_word t1) C_noret;
static void f_4256(C_word c,C_word t0,C_word t1) C_noret;
static void f_4252(C_word c,C_word t0,C_word t1) C_noret;
static void f_4248(C_word c,C_word t0,C_word t1) C_noret;
static void f_4233(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3985(C_word t0,C_word t1) C_noret;
static void f_4011(C_word c,C_word t0,C_word t1) C_noret;
static void f_3970(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4090(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4120(C_word t0,C_word t1) C_noret;
static void f_4184(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4132(C_word t0,C_word t1) C_noret;
static void f_4154(C_word c,C_word t0,C_word t1) C_noret;
static void f_4158(C_word c,C_word t0,C_word t1) C_noret;
static void f_4150(C_word c,C_word t0,C_word t1) C_noret;
static void f_4108(C_word c,C_word t0,C_word t1) C_noret;
static void f_4104(C_word c,C_word t0,C_word t1) C_noret;
static void f_3861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3871(C_word c,C_word t0,C_word t1) C_noret;
static void f_3900(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3902(C_word t0,C_word t1,C_word t2);
static void f_3855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3701(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_3707(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3831(C_word c,C_word t0,C_word t1) C_noret;
static void f_3827(C_word c,C_word t0,C_word t1) C_noret;
static void f_3726(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3729(C_word t0,C_word t1) C_noret;
static void f_3762(C_word c,C_word t0,C_word t1) C_noret;
static void f_3752(C_word c,C_word t0,C_word t1) C_noret;
static void f_3769(C_word c,C_word t0,C_word t1) C_noret;
static void f_3779(C_word c,C_word t0,C_word t1) C_noret;
static void f_3772(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2804(C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_2810(C_word t0,C_word t1,C_word t2);
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2769(C_word c,C_word t0,C_word t1) C_noret;
static void f_2775(C_word c,C_word t0,C_word t1) C_noret;
static void f_2781(C_word c,C_word t0,C_word t1) C_noret;
static void f_2787(C_word c,C_word t0,C_word t1) C_noret;
static void f_2793(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2493(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2515(C_word c,C_word t0,C_word t1) C_noret;
static void f_2518(C_word c,C_word t0,C_word t1) C_noret;
static void f_2475(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2208(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1462(C_word t0,C_word t1) C_noret;
static void f_1490(C_word c,C_word t0,C_word t1) C_noret;
static void f_1486(C_word c,C_word t0,C_word t1) C_noret;
static void f_1468(C_word c,C_word t0,C_word t1) C_noret;
static void f_2357(C_word c,C_word t0,C_word t1) C_noret;
static void f_2259(C_word c,C_word t0,C_word t1) C_noret;
static void f_2192(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1772(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1785(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1817(C_word t0,C_word t1) C_noret;
static void C_fcall f_2050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_2054(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2110(C_word t0,C_word t1) C_noret;
static void f_2172(C_word c,C_word t0,C_word t1) C_noret;
static void f_2168(C_word c,C_word t0,C_word t1) C_noret;
static void f_2126(C_word c,C_word t0,C_word t1) C_noret;
static void f_2164(C_word c,C_word t0,C_word t1) C_noret;
static void f_2160(C_word c,C_word t0,C_word t1) C_noret;
static void f_2129(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2135(C_word t0,C_word t1) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1) C_noret;
static void f_1985(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1826(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1835(C_word t0,C_word t1);
static C_word C_fcall f_1223(C_word *a,C_word t0,C_word t1,C_word t2);
static void C_fcall f_1127(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1213(C_word c,C_word t0,C_word t1) C_noret;
static void f_1209(C_word c,C_word t0,C_word t1) C_noret;
static void f_1205(C_word c,C_word t0,C_word t1) C_noret;
static void f_1178(C_word c,C_word t0,C_word t1) C_noret;
static void f_1174(C_word c,C_word t0,C_word t1) C_noret;
static void f_1170(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_704(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_727(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_737(C_word t0,C_word t1) C_noret;
static void C_fcall f_795(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1032(C_word t0,C_word t1) C_noret;
static void C_fcall f_1048(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_988(C_word c,C_word t0,C_word t1) C_noret;
static void f_991(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1598(C_word c,C_word t0,C_word t1) C_noret;
static void f_1700(C_word c,C_word t0,C_word t1) C_noret;
static void f_1709(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1722(C_word t0,C_word t1) C_noret;
static void C_fcall f_1735(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1729(C_word c,C_word t0,C_word t1) C_noret;
static void f_971(C_word c,C_word t0,C_word t1) C_noret;
static void f_928(C_word c,C_word t0,C_word t1) C_noret;
static void f_922(C_word c,C_word t0,C_word t1) C_noret;
static void f_839(C_word c,C_word t0,C_word t1) C_noret;
static void f_836(C_word c,C_word t0,C_word t1) C_noret;
static void f_813(C_word c,C_word t0,C_word t1) C_noret;
static void f_751(C_word c,C_word t0,C_word t1) C_noret;
static void f_748(C_word c,C_word t0,C_word t1) C_noret;
static void f_698(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_698r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_674(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_680(C_word t0,C_word t1);

static void C_fcall trf_5533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5533(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5533(t0,t1,t2);}

static void C_fcall trf_5490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5490(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5490(t0,t1,t2);}

static void C_fcall trf_5409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5409(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5409(t0,t1,t2);}

static void C_fcall trf_5254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5254(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5254(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_5287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5287(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5287(t0,t1,t2,t3);}

static void C_fcall trf_5326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5326(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5326(t0,t1);}

static void C_fcall trf_5373(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5373(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5373(t0,t1);}

static void C_fcall trf_5332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5332(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5332(t0,t1);}

static void C_fcall trf_5272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5272(t0,t1);}

static void C_fcall trf_5162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5162(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5162(t0,t1,t2,t3);}

static void C_fcall trf_5124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5124(t0,t1,t2);}

static void C_fcall trf_5027(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5027(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5027(t0,t1,t2);}

static void C_fcall trf_5033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5033(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5033(t0,t1,t2,t3);}

static void C_fcall trf_4841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4841(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4841(t0,t1);}

static void C_fcall trf_4849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4849(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4849(t0,t1,t2,t3);}

static void C_fcall trf_4755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4755(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4755(t0,t1,t2,t3,t4);}

static void C_fcall trf_4736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4736(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4736(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_4691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4691(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4691(t0,t1,t2,t3);}

static void C_fcall trf_4551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4551(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4551(t0,t1,t2,t3,t4);}

static void C_fcall trf_4455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4455(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4455(t0,t1);}

static void C_fcall trf_4463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4463(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4463(t0,t1,t2);}

static void C_fcall trf_2848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2848(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2848(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2936(t0,t1);}

static void C_fcall trf_2965(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2965(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2965(t0,t1);}

static void C_fcall trf_2991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2991(t0,t1);}

static void C_fcall trf_3519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3519(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3519(t0,t1);}

static void C_fcall trf_3524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3524(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3524(t0,t1,t2,t3,t4);}

static void C_fcall trf_3552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3552(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3552(t0,t1,t2,t3,t4);}

static void C_fcall trf_3581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3581(t0,t1);}

static void C_fcall trf_2426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2426(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2426(t0,t1,t2,t3);}

static void C_fcall trf_3264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3264(t0,t1,t2);}

static void C_fcall trf_3200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3200(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3200(t0,t1,t2);}

static void C_fcall trf_3158(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3158(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3158(t0,t1,t2,t3,t4);}

static void C_fcall trf_3078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3078(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3078(t0,t1,t2);}

static void C_fcall trf_4196(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4196(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4196(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3956(t0,t1,t2,t3);}

static void C_fcall trf_3985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3985(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3985(t0,t1);}

static void C_fcall trf_4084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4084(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4084(t0,t1,t2);}

static void C_fcall trf_4090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4090(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4090(t0,t1,t2,t3);}

static void C_fcall trf_4120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4120(t0,t1);}

static void C_fcall trf_4132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4132(t0,t1);}

static void C_fcall trf_3701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3701(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3701(t0,t1,t2,t3,t4);}

static void C_fcall trf_3707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3707(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3707(t0,t1,t2,t3);}

static void C_fcall trf_3729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3729(t0,t1);}

static void C_fcall trf_2804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2804(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2804(t0,t1,t2);}

static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2539(t0,t1,t2);}

static void C_fcall trf_2493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2493(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2493(t0,t1,t2,t3);}

static void C_fcall trf_2202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2202(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2202(t0,t1,t2,t3);}

static void C_fcall trf_2208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2208(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2208(t0,t1,t2,t3);}

static void C_fcall trf_1403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1403(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1403(t0,t1,t2,t3);}

static void C_fcall trf_1462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1462(t0,t1);}

static void C_fcall trf_1772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1772(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1772(t0,t1,t2,t3);}

static void C_fcall trf_1785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1785(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1785(t0,t1,t2);}

static void C_fcall trf_1817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1817(t0,t1);}

static void C_fcall trf_2050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2050(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2050(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_2110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2110(t0,t1);}

static void C_fcall trf_2135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2135(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2135(t0,t1);}

static void C_fcall trf_1826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1826(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1826(t0,t1);}

static void C_fcall trf_1127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1127(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1127(t0,t1,t2,t3);}

static void C_fcall trf_1156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1156(t0,t1,t2,t3);}

static void C_fcall trf_704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_704(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_704(t0,t1,t2,t3);}

static void C_fcall trf_727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_727(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_727(t0,t1,t2,t3);}

static void C_fcall trf_737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_737(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_737(t0,t1);}

static void C_fcall trf_795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_795(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_795(t0,t1,t2,t3);}

static void C_fcall trf_1032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1032(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1032(t0,t1);}

static void C_fcall trf_1048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1048(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1048(t0,t1,t2,t3);}

static void C_fcall trf_1623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1623(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1623(t0,t1,t2,t3,t4);}

static void C_fcall trf_1722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1722(t0,t1);}

static void C_fcall trf_1735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1735(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1735(t0,t1,t2,t3);}

static void C_fcall trf_674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_674(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1460)){
C_save(t1);
C_rereclaim2(1460*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,153);
lf[0]=C_h_intern(&lf[0],26,"*pregexp-space-sensitive\077*");
lf[2]=C_h_intern(&lf[2],13,"pregexp-error");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_static_string(C_heaptop,15,"pregexp-error: ");
lf[6]=C_h_intern(&lf[6],4,":seq");
lf[7]=C_h_intern(&lf[7],3,":or");
lf[8]=C_h_intern(&lf[8],4,":bos");
lf[9]=C_h_intern(&lf[9],4,":eos");
lf[10]=C_h_intern(&lf[10],4,":any");
lf[12]=C_h_intern(&lf[12],9,":neg-char");
lf[14]=C_h_intern(&lf[14],23,"pregexp-read-subpattern");
tmp=C_intern(C_heaptop,10,":lookahead");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[15]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,":neg-lookahead");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[16]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,13,":no-backtrack");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[17]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,11,":lookbehind");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[18]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,15,":neg-lookbehind");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[19]=C_h_pair(C_restore,tmp);
lf[20]=C_h_intern(&lf[20],25,"pregexp-read-cluster-type");
lf[21]=C_h_intern(&lf[21],15,":case-sensitive");
lf[22]=C_h_intern(&lf[22],17,":case-insensitive");
tmp=C_intern(C_heaptop,4,":sub");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[23]=C_h_pair(C_restore,tmp);
lf[24]=C_h_intern(&lf[24],8,":backref");
lf[26]=C_h_intern(&lf[26],18,"pregexp-read-piece");
lf[27]=C_static_string(C_heaptop,9,"backslash");
lf[29]=C_h_intern(&lf[29],6,":empty");
lf[30]=C_h_intern(&lf[30],12,"list->string");
lf[31]=C_h_intern(&lf[31],6,":wbdry");
lf[32]=C_h_intern(&lf[32],10,":not-wbdry");
lf[33]=C_h_intern(&lf[33],6,":digit");
tmp=C_intern(C_heaptop,9,":neg-char");
C_save(tmp);
tmp=C_intern(C_heaptop,6,":digit");
C_save(tmp);
lf[34]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[35]=C_h_intern(&lf[35],6,":space");
tmp=C_intern(C_heaptop,9,":neg-char");
C_save(tmp);
tmp=C_intern(C_heaptop,6,":space");
C_save(tmp);
lf[36]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[37]=C_h_intern(&lf[37],5,":word");
tmp=C_intern(C_heaptop,9,":neg-char");
C_save(tmp);
tmp=C_intern(C_heaptop,5,":word");
C_save(tmp);
lf[38]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[39]=C_h_intern(&lf[39],8,":between");
lf[40]=C_h_intern(&lf[40],8,"minimal\077");
lf[41]=C_h_intern(&lf[41],8,"at-least");
lf[42]=C_h_intern(&lf[42],7,"at-most");
lf[43]=C_h_intern(&lf[43],6,"next-i");
lf[44]=C_h_intern(&lf[44],30,"pregexp-wrap-quantifier-if-any");
lf[45]=C_static_string(C_heaptop,39,"left bracket must be followed by number");
lf[46]=C_h_intern(&lf[46],17,"pregexp-read-nums");
lf[48]=C_h_intern(&lf[48],14,":none-of-chars");
lf[49]=C_h_intern(&lf[49],22,"pregexp-read-char-list");
lf[50]=C_static_string(C_heaptop,30,"character class ended too soon");
lf[51]=C_h_intern(&lf[51],13,":one-of-chars");
lf[52]=C_static_string(C_heaptop,9,"backslash");
lf[53]=C_h_intern(&lf[53],11,":char-range");
lf[54]=C_h_intern(&lf[54],29,"pregexp-read-posix-char-class");
lf[55]=C_h_intern(&lf[55],14,"string->symbol");
lf[59]=C_h_intern(&lf[59],6,":alnum");
lf[60]=C_h_intern(&lf[60],6,":alpha");
lf[61]=C_h_intern(&lf[61],6,":ascii");
lf[62]=C_h_intern(&lf[62],6,":blank");
lf[63]=C_h_intern(&lf[63],6,":cntrl");
lf[64]=C_h_intern(&lf[64],6,":graph");
lf[65]=C_h_intern(&lf[65],6,":lower");
lf[66]=C_h_intern(&lf[66],6,":print");
lf[67]=C_h_intern(&lf[67],6,":punct");
lf[68]=C_h_intern(&lf[68],6,":upper");
lf[69]=C_h_intern(&lf[69],7,":xdigit");
lf[70]=C_h_intern(&lf[70],9,"char-ci=\077");
lf[71]=C_h_intern(&lf[71],31,"pregexp-check-if-in-char-class\077");
lf[74]=C_h_intern(&lf[74],17,"\003sysstring-append");
lf[75]=C_h_intern(&lf[75],13,"\003syssubstring");
lf[76]=C_h_intern(&lf[76],6,"string");
lf[77]=C_static_string(C_heaptop,0,"");
lf[78]=C_h_intern(&lf[78],17,"extract-bit-field");
lf[79]=C_h_intern(&lf[79],23,"utf8-start-byte->length");
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(3);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(4);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(5);
C_save(tmp);
tmp=C_fix(6);
C_save(tmp);
tmp=C_fix(6);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[80]=C_h_vector(256,C_pick(255),C_pick(254),C_pick(253),C_pick(252),C_pick(251),C_pick(250),C_pick(249),C_pick(248),C_pick(247),C_pick(246),C_pick(245),C_pick(244),C_pick(243),C_pick(242),C_pick(241),C_pick(240),C_pick(239),C_pick(238),C_pick(237),C_pick(236),C_pick(235),C_pick(234),C_pick(233),C_pick(232),C_pick(231),C_pick(230),C_pick(229),C_pick(228),C_pick(227),C_pick(226),C_pick(225),C_pick(224),C_pick(223),C_pick(222),C_pick(221),C_pick(220),C_pick(219),C_pick(218),C_pick(217),C_pick(216),C_pick(215),C_pick(214),C_pick(213),C_pick(212),C_pick(211),C_pick(210),C_pick(209),C_pick(208),C_pick(207),C_pick(206),C_pick(205),C_pick(204),C_pick(203),C_pick(202),C_pick(201),C_pick(200),C_pick(199),C_pick(198),C_pick(197),C_pick(196),C_pick(195),C_pick(194),C_pick(193),C_pick(192),C_pick(191),C_pick(190),C_pick(189),C_pick(188),C_pick(187),C_pick(186),C_pick(185),C_pick(184),C_pick(183),C_pick(182),C_pick(181),C_pick(180),C_pick(179),C_pick(178),C_pick(177),C_pick(176),C_pick(175),C_pick(174),C_pick(173),C_pick(172),C_pick(171),C_pick(170),C_pick(169),C_pick(168),C_pick(167),C_pick(166),C_pick(165),C_pick(164),C_pick(163),C_pick(162),C_pick(161),C_pick(160),C_pick(159),C_pick(158),C_pick(157),C_pick(156),C_pick(155),C_pick(154),C_pick(153),C_pick(152),C_pick(151),C_pick(150),C_pick(149),C_pick(148),C_pick(147),C_pick(146),C_pick(145),C_pick(144),C_pick(143),C_pick(142),C_pick(141),C_pick(140),C_pick(139),C_pick(138),C_pick(137),C_pick(136),C_pick(135),C_pick(134),C_pick(133),C_pick(132),C_pick(131),C_pick(130),C_pick(129),C_pick(128),C_pick(127),C_pick(126),C_pick(125),C_pick(124),C_pick(123),C_pick(122),C_pick(121),C_pick(120),C_pick(119),C_pick(118),C_pick(117),C_pick(116),C_pick(115),C_pick(114),C_pick(113),C_pick(112),C_pick(111),C_pick(110),C_pick(109),C_pick(108),C_pick(107),C_pick(106),C_pick(105),C_pick(104),C_pick(103),C_pick(102),C_pick(101),C_pick(100),C_pick(99),C_pick(98),C_pick(97),C_pick(96),C_pick(95),C_pick(94),C_pick(93),C_pick(92),C_pick(91),C_pick(90),C_pick(89),C_pick(88),C_pick(87),C_pick(86),C_pick(85),C_pick(84),C_pick(83),C_pick(82),C_pick(81),C_pick(80),C_pick(79),C_pick(78),C_pick(77),C_pick(76),C_pick(75),C_pick(74),C_pick(73),C_pick(72),C_pick(71),C_pick(70),C_pick(69),C_pick(68),C_pick(67),C_pick(66),C_pick(65),C_pick(64),C_pick(63),C_pick(62),C_pick(61),C_pick(60),C_pick(59),C_pick(58),C_pick(57),C_pick(56),C_pick(55),C_pick(54),C_pick(53),C_pick(52),C_pick(51),C_pick(50),C_pick(49),C_pick(48),C_pick(47),C_pick(46),C_pick(45),C_pick(44),C_pick(43),C_pick(42),C_pick(41),C_pick(40),C_pick(39),C_pick(38),C_pick(37),C_pick(36),C_pick(35),C_pick(34),C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(256);
lf[81]=C_h_intern(&lf[81],18,"string-ref-at-byte");
lf[82]=C_h_intern(&lf[82],6,"regexp");
lf[83]=C_static_string(C_heaptop,27,"utf8 trailing char overflow");
tmp=C_make_character(41);
C_save(tmp);
tmp=C_make_character(125);
C_save(tmp);
tmp=C_make_character(50);
C_save(tmp);
tmp=C_make_character(123);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(194);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(124);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(194);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(195);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(124);
C_save(tmp);
tmp=C_make_character(93);
C_save(tmp);
tmp=C_make_character(127);
C_save(tmp);
tmp=C_make_character(45);
C_save(tmp);
tmp=C_make_character(1);
C_save(tmp);
tmp=C_make_character(91);
C_save(tmp);
tmp=C_make_character(58);
C_save(tmp);
tmp=C_make_character(63);
C_save(tmp);
tmp=C_make_character(40);
C_save(tmp);
lf[85]=C_h_list(34,C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(34);
lf[86]=C_h_intern(&lf[86],26,"utf8-pattern->byte-pattern");
lf[87]=C_h_intern(&lf[87],12,"string->list");
lf[88]=C_h_intern(&lf[88],13,"string-append");
lf[89]=C_static_string(C_heaptop,3,"(\077:");
lf[90]=C_static_string(C_heaptop,1,")");
lf[91]=C_h_intern(&lf[91],18,"string-intersperse");
lf[92]=C_static_string(C_heaptop,1,"|");
lf[93]=C_static_string(C_heaptop,34,"full unicode classes not supported");
lf[94]=C_static_string(C_heaptop,1,"[");
lf[95]=C_static_string(C_heaptop,1,"-");
lf[96]=C_static_string(C_heaptop,1,"]");
lf[97]=C_h_intern(&lf[97],12,"char->string");
lf[98]=C_h_intern(&lf[98],7,"reverse");
lf[99]=C_h_intern(&lf[99],6,"append");
lf[100]=C_static_string(C_heaptop,26,"incomplete character class");
lf[101]=C_h_intern(&lf[101],8,"%pregexp");
lf[102]=C_h_intern(&lf[102],4,":sub");
lf[103]=C_h_intern(&lf[103],7,"pregexp");
lf[104]=C_static_string(C_heaptop,4,"(\077x:");
lf[105]=C_static_string(C_heaptop,1,")");
lf[106]=C_static_string(C_heaptop,4,"(\077i:");
lf[107]=C_static_string(C_heaptop,1,")");
lf[108]=C_h_intern(&lf[108],7,"regexp\077");
lf[110]=C_h_intern(&lf[110],6,"char=\077");
lf[111]=C_h_intern(&lf[111],7,"char<=\077");
lf[112]=C_h_intern(&lf[112],10,"char-ci<=\077");
lf[113]=C_h_intern(&lf[113],27,"pregexp-match-positions-aux");
lf[114]=C_h_intern(&lf[114],10,":lookahead");
lf[115]=C_h_intern(&lf[115],4,"list");
lf[116]=C_h_intern(&lf[116],14,":neg-lookahead");
lf[117]=C_h_intern(&lf[117],11,":lookbehind");
tmp=C_intern(C_heaptop,8,":between");
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_intern(C_heaptop,4,":any");
C_save(tmp);
lf[118]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[119]=C_h_intern(&lf[119],15,":neg-lookbehind");
tmp=C_intern(C_heaptop,8,":between");
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_SCHEME_FALSE;
C_save(tmp);
tmp=C_intern(C_heaptop,4,":any");
C_save(tmp);
lf[120]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[121]=C_h_intern(&lf[121],13,":no-backtrack");
lf[122]=C_h_intern(&lf[122],12,"no-match-yet");
lf[124]=C_h_intern(&lf[124],7,"\003sysmap");
lf[128]=C_static_string(C_heaptop,0,"");
lf[129]=C_static_string(C_heaptop,1,"^");
lf[130]=C_static_string(C_heaptop,1,"$");
lf[131]=C_h_intern(&lf[131],12,"string-match");
lf[132]=C_h_intern(&lf[132],22,"string-match-positions");
lf[133]=C_h_intern(&lf[133],13,"string-search");
lf[134]=C_h_intern(&lf[134],23,"string-search-positions");
lf[135]=C_h_intern(&lf[135],9,"substring");
lf[136]=C_h_intern(&lf[136],19,"string-split-fields");
lf[137]=C_h_intern(&lf[137],6,"\000infix");
lf[138]=C_h_intern(&lf[138],7,"\000suffix");
lf[139]=C_static_string(C_heaptop,31,"record does not end with suffix");
lf[140]=C_h_intern(&lf[140],11,"make-string");
lf[141]=C_h_intern(&lf[141],17,"string-substitute");
lf[142]=C_h_intern(&lf[142],18,"string-substitute*");
lf[143]=C_h_intern(&lf[143],21,"\003sysfragments->string");
lf[144]=C_h_intern(&lf[144],12,"glob->regexp");
lf[145]=C_h_intern(&lf[145],8,"\003syscons");
lf[146]=C_h_intern(&lf[146],4,"grep");
lf[147]=C_h_intern(&lf[147],18,"open-output-string");
lf[148]=C_h_intern(&lf[148],17,"get-output-string");
lf[149]=C_h_intern(&lf[149],13,"regexp-escape");
lf[150]=C_h_intern(&lf[150],16,"\003syswrite-char-0");
lf[151]=C_h_intern(&lf[151],17,"register-feature!");
lf[152]=C_h_intern(&lf[152],5,"regex");
C_register_lf(lf,153);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 51   register-feature! */
t3=*((C_word*)lf[151]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[152],lf[103]);}

/* k669 */
static void f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word ab[92],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_671,2,t0,t1);}
t2=C_set_block_item(lf[0],0,C_SCHEME_TRUE);
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_674,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_698,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_704,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[28],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1127,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[25],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1223,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1772,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[47],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2192,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2202,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[56],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2475,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[57],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2493,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2539,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate(&lf[72],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2804,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3701,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3833,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3855,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3861,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[84],lf[85]);
t20=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3950,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4354,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4373,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[82]+1,*((C_word*)lf[103]+1));
t24=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4432,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[109],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4448,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate(&lf[123],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4513,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate(&lf[125],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4542,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate(&lf[126],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4637,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate(&lf[127],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4676,tmp=(C_word)a,a+=2,tmp));
t30=*((C_word*)lf[88]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4736,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4755,tmp=(C_word)a,a+=2,tmp);
t33=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4761,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4767,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[133]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4793,a[2]=t32,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4799,a[2]=t32,tmp=(C_word)a,a+=3,tmp));
t37=*((C_word*)lf[98]+1);
t38=*((C_word*)lf[135]+1);
t39=*((C_word*)lf[134]+1);
t40=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4825,a[2]=t37,a[3]=t39,a[4]=t38,tmp=(C_word)a,a+=5,tmp));
t41=*((C_word*)lf[135]+1);
t42=*((C_word*)lf[98]+1);
t43=*((C_word*)lf[140]+1);
t44=*((C_word*)lf[134]+1);
t45=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5000,a[2]=t44,a[3]=t42,a[4]=t43,a[5]=t41,tmp=(C_word)a,a+=6,tmp));
t46=*((C_word*)lf[134]+1);
t47=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5248,a[2]=t46,tmp=(C_word)a,a+=3,tmp));
t48=*((C_word*)lf[30]+1);
t49=*((C_word*)lf[87]+1);
t50=C_mutate((C_word*)lf[144]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5395,a[2]=t49,a[3]=t48,tmp=(C_word)a,a+=4,tmp));
t51=*((C_word*)lf[133]+1);
t52=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=t51,tmp=(C_word)a,a+=3,tmp));
t53=*((C_word*)lf[147]+1);
t54=*((C_word*)lf[148]+1);
t55=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5521,a[2]=t53,a[3]=t54,tmp=(C_word)a,a+=4,tmp));
t56=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t56+1)))(2,t56,C_SCHEME_UNDEFINED);}

/* regexp-escape in k669 */
static void f_5521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5521,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5525,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 1038 open-output-string */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5523 in regexp-escape in k669 */
static void f_5525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5525,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5533,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5533(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k5523 in regexp-escape in k669 */
static void C_fcall f_5533(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5533,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* pregexp.scm: 1041 get-output-string */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 1043 ##sys#write-char-0 */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5565,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 1047 ##sys#write-char-0 */
t5=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k5563 in loop in k5523 in regexp-escape in k669 */
static void f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 1048 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5533(t3,((C_word*)t0)[2],t2);}

/* k5550 in loop in k5523 in regexp-escape in k669 */
static void f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 1044 ##sys#write-char-0 */
t3=*((C_word*)lf[150]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k5553 in k5550 in loop in k5523 in regexp-escape in k669 */
static void f_5555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 1045 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5533(t3,((C_word*)t0)[2],t2);}

/* grep in k669 */
static void f_5484(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5484,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5490,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5490(t7,t1,t3);}

/* loop in grep in k669 */
static void C_fcall f_5490(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5490,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5509,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 1026 string-search */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k5507 in loop in grep in k669 */
static void f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5509,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 1027 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5490(t3,t2,((C_word*)t0)[2]);}
else{
/* pregexp.scm: 1028 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5490(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k5514 in k5507 in loop in grep in k669 */
static void f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k669 */
static void f_5395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5395,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5403,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5407,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 1007 string->list */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5405 in glob->regexp in k669 */
static void f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5409,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5409(t5,((C_word*)t0)[2],t1);}

/* loop in k5405 in glob->regexp in k669 */
static void C_fcall f_5409(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5409,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5435,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5439,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 1012 loop */
t14=t6;
t15=t4;
t1=t14;
t2=t15;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 1013 loop */
t14=t5;
t15=t4;
t1=t14;
t2=t15;
goto loop;
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5468,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 1014 loop */
t14=t7;
t15=t4;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5475,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5479,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 1015 loop */
t14=t8;
t15=t4;
t1=t14;
t2=t15;
goto loop;}}}}

/* k5477 in loop in k5405 in glob->regexp in k669 */
static void f_5479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5473 in loop in k5405 in glob->regexp in k669 */
static void f_5475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(92),t1);}

/* k5466 in loop in k5405 in glob->regexp in k669 */
static void f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5468,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5450 in loop in k5405 in glob->regexp in k669 */
static void f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k5437 in loop in k5405 in glob->regexp in k669 */
static void f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(42),t1);}

/* k5433 in loop in k5405 in glob->regexp in k669 */
static void f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1001 ##sys#cons */
t2=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(46),t1);}

/* k5401 in glob->regexp in k669 */
static void f_5403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 1006 list->string */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* string-substitute* in k669 */
static void f_5248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5248,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5254,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
/* pregexp.scm: 996  collect */
t8=((C_word*)t6)[1];
f_5254(t8,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-substitute* in k669 */
static void C_fcall f_5254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5254,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5268,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5272,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5282,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 973  ##sys#substring */
t10=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[5],t3,t2);}
else{
t9=t8;
f_5272(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t2,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_5287(t10,t1,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* loop in collect in string-substitute* in k669 */
static void C_fcall f_5287(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5287,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[9]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t4);
/* pregexp.scm: 977  collect */
t6=((C_word*)((C_word*)t0)[7])[1];
f_5254(t6,t1,t3,((C_word*)t0)[6],t5,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5317,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[8],a[12]=t6,tmp=(C_word)a,a+=13,tmp);
/* pregexp.scm: 981  string-search-positions */
t8=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t5,((C_word*)t0)[4],((C_word*)t0)[9]);}}

/* k5315 in loop in collect in string-substitute* in k669 */
static void f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5317,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_slot(t1,C_fix(0)):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_5326(t5,(C_word)C_eqp(((C_word*)t0)[7],t4));}
else{
t4=t3;
f_5326(t4,C_SCHEME_FALSE);}}

/* k5324 in k5315 in loop in collect in string-substitute* in k669 */
static void C_fcall f_5326(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5326,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5332,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[7],((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5358,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 987  ##sys#substring */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
t5=t4;
f_5332(t5,C_SCHEME_UNDEFINED);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5373,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[13])){
t4=(C_word)C_slot(((C_word*)t0)[13],C_fix(0));
t5=t3;
f_5373(t5,(C_word)C_i_fixnum_min(((C_word*)t0)[2],t4));}
else{
t4=t3;
f_5373(t4,((C_word*)t0)[2]);}}}

/* k5371 in k5324 in k5315 in loop in collect in string-substitute* in k669 */
static void C_fcall f_5373(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 992  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5287(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5356 in k5324 in k5315 in loop in collect in string-substitute* in k669 */
static void f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5358,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_5332(t4,t3);}

/* k5330 in k5324 in k5315 in loop in collect in string-substitute* in k669 */
static void C_fcall f_5332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5332,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
/* pregexp.scm: 988  collect */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5254(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k5280 in collect in string-substitute* in k669 */
static void f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5282,2,t0,t1);}
t2=((C_word*)t0)[3];
f_5272(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k5270 in collect in string-substitute* in k669 */
static void C_fcall f_5272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 971  reverse */
t2=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5266 in collect in string-substitute* in k669 */
static void f_5268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 969  ##sys#fragments->string */
t2=*((C_word*)lf[143]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-substitute in k669 */
static void f_5000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+35)){
C_save_and_reclaim((void*)tr5rv,(void*)f_5000r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_5000r(t0,t1,t2,t3,t4,t5);}}

static void f_5000r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(35);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t8=(C_word)C_block_size(t3);
t9=(C_word)C_u_fixnum_difference(t8,C_fix(1));
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5012,a[2]=t13,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5027,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t14,a[7]=t9,tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5124,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5162,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=((C_word*)t0)[3],a[6]=t16,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t15,a[10]=t18,a[11]=t14,a[12]=t7,tmp=(C_word)a,a+=13,tmp));
t20=((C_word*)t18)[1];
f_5162(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k669 */
static void C_fcall f_5162(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5162,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* pregexp.scm: 946  string-search-positions */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k5164 in loop in string-substitute in k669 */
static void f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_fixnump(((C_word*)t0)[13]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[12],((C_word*)t0)[13]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5197,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_u_i_car(t2);
/* pregexp.scm: 951  substring */
t9=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,((C_word*)t0)[6],((C_word*)t0)[5],t8);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5215,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 955  substring */
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
/* pregexp.scm: 958  substring */
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k5234 in k5164 in loop in string-substitute in k669 */
static void f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5236,2,t0,t1);}
t2=f_5012(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5232,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 959  reverse */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k5230 in k5234 in k5164 in loop in string-substitute in k669 */
static void f_5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 959  concatenate */
t2=((C_word*)t0)[3];
f_5124(t2,((C_word*)t0)[2],t1);}

/* k5213 in k5164 in loop in string-substitute in k669 */
static void f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5215,2,t0,t1);}
t2=f_5012(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* pregexp.scm: 956  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5162(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k5195 in k5164 in loop in string-substitute in k669 */
static void f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5197,2,t0,t1);}
t2=f_5012(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 952  substitute */
t4=((C_word*)t0)[3];
f_5027(t4,t3,((C_word*)t0)[2]);}

/* k5188 in k5195 in k5164 in loop in string-substitute in k669 */
static void f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 953  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5162(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* concatenate in string-substitute in k669 */
static void C_fcall f_5124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5124,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5128,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 936  make-string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k5126 in concatenate in string-substitute in k669 */
static void f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5133,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_5133(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop in k5126 in concatenate in string-substitute in k669 */
static C_word C_fcall f_5133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_block_size(t3);
t5=(C_word)C_substring_copy(t3,((C_word*)t0)[2],C_fix(0),t4,t2);
t6=(C_word)C_slot(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,t4);
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* substitute in string-substitute in k669 */
static void C_fcall f_5027(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5027,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_5033(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k669 */
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5033,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5047,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_5047(2,t6,((C_word*)t0)[7]);}
else{
/* pregexp.scm: 922  substring */
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(t5,C_fix(1));
/* pregexp.scm: 932  loop */
t17=t1;
t18=t2;
t19=t9;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t9=(C_word)C_fix((C_word)C_character_code(t7));
t10=(C_word)C_u_fixnum_difference(t9,C_fix(48));
t11=(C_word)C_u_i_list_ref(((C_word*)t0)[3],t10);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* pregexp.scm: 929  substring */
t13=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,((C_word*)t0)[7],t2,t3);}}
else{
/* pregexp.scm: 933  loop */
t17=t1;
t18=t2;
t19=t5;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k5098 in loop in substitute in string-substitute in k669 */
static void f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5100,2,t0,t1);}
t2=f_5012(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* pregexp.scm: 930  substring */
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k5086 in k5098 in loop in substitute in string-substitute in k669 */
static void f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5088,2,t0,t1);}
t2=f_5012(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
/* pregexp.scm: 931  loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5033(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5045 in loop in substitute in string-substitute in k669 */
static void f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
/* pregexp.scm: 922  push */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_5012(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k669 */
static C_word C_fcall f_5012(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k669 */
static void f_4825(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4rv,(void*)f_4825r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_4825r(t0,t1,t2,t3,t4);}}

static void f_4825r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(25);
t5=(C_word)C_block_size(t4);
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t5,C_fix(0));
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t9=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t10=(C_truep(t9)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4841,a[2]=t10,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t12=(C_word)C_eqp(t8,lf[138]);
if(C_truep(t12)){
t13=t11;
f_4841(t13,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));}
else{
t13=(C_word)C_eqp(t8,lf[137]);
t14=t11;
f_4841(t14,(C_truep(t13)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4960,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_4982 in string-split-fields in k669 */
static void f_4982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4982,4,t0,t1,t2,t3);}
/* pregexp.scm: 882  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_4960 in string-split-fields in k669 */
static void f_4960(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4960,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
/* pregexp.scm: 880  reverse */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4981,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 881  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k4979 */
static void f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* pregexp.scm: 881  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_4940 in string-split-fields in k669 */
static void f_4940(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4940,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
/* pregexp.scm: 875  ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[136],lf[139],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 876  reverse */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k4839 in string-split-fields in k669 */
static void C_fcall f_4841(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4841,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[137]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[138]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_4849(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k4839 in string-split-fields in k669 */
static void C_fcall f_4849(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4849,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 887  string-search-positions */
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k4851 in loop in k4839 in string-split-fields in k669 */
static void f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
/* pregexp.scm: 894  fini */
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
/* pregexp.scm: 895  fetch */
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4914,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 896  fetch */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
/* pregexp.scm: 897  fini */
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k4912 in k4851 in loop in k4839 in string-split-fields in k669 */
static void f_4914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4914,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 896  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4849(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4893 in k4851 in loop in k4839 in string-split-fields in k669 */
static void f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 895  loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4849(t4,((C_word*)t0)[2],t2,t3);}

/* f_4929 in k4839 in string-split-fields in k669 */
static void f_4929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4929,5,t0,t1,t2,t3,t4);}
/* pregexp.scm: 885  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_4924 in k4839 in string-split-fields in k669 */
static void f_4924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4924,5,t0,t1,t2,t3,t4);}
/* pregexp.scm: 884  substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k669 */
static void f_4799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_4799r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4799r(t0,t1,t2,t3,t4);}}

static void f_4799r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4803,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 855  prep2 */
f_4755(t5,lf[109],t2,t3,t4);}

/* k4801 in string-search-positions in k669 */
static void f_4803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4803,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4811,tmp=(C_word)a,a+=2,tmp);
/* map */
t3=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4810 in k4801 in string-search-positions in k669 */
static void f_4811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4811,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t3,t4));}

/* string-search in k669 */
static void f_4793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_4793r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4793r(t0,t1,t2,t3,t4);}}

static void f_4793r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* pregexp.scm: 852  prep2 */
f_4755(t1,lf[123],t2,t3,t4);}

/* string-match-positions in k669 */
static void f_4767(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr4r,(void*)f_4767r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4767r(t0,t1,t2,t3,t4);}}

static void f_4767r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4771,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 850  prep */
t6=((C_word*)t0)[2];
f_4736(t6,t5,lf[109],t2,t3,t4);}

/* k4769 in string-match-positions in k669 */
static void f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4771,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4779,tmp=(C_word)a,a+=2,tmp);
/* map */
t3=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4778 in k4769 in string-match-positions in k669 */
static void f_4779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4779,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,t3,t4));}

/* string-match in k669 */
static void f_4761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_4761r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4761r(t0,t1,t2,t3,t4);}}

static void f_4761r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* pregexp.scm: 847  prep */
t5=((C_word*)t0)[2];
f_4736(t5,t1,lf[123],t2,t3,t4);}

/* prep2 in k669 */
static void C_fcall f_4755(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4755,NULL,5,t1,t2,t3,t4,t5);}
C_apply(6,0,t1,t2,t3,t4,t5);}

/* prep in k669 */
static void C_fcall f_4736(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4736,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4744,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_stringp(t3))){
/* pregexp.scm: 842  string-append */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[129],t3,lf[130]);}
else{
t7=t6;
f_4744(2,t7,(C_word)C_a_i_list(&a,4,lf[6],lf[8],t3,lf[9]));}}

/* k4742 in prep in k669 */
static void f_4744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pregexp-replace* in k669 */
static void f_4676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4676,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4680,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* pregexp.scm: 821  pregexp */
t6=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t6=t5;
f_4680(2,t6,t2);}}

/* k4678 in pregexp-replace* in k669 */
static void f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4]));
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[3]));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4691,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t5,tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_4691(t7,((C_word*)t0)[2],C_fix(0),lf[128]);}

/* loop in k4678 in pregexp-replace* in k669 */
static void C_fcall f_4691(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4691,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* pregexp.scm: 825  pregexp-match-positions */
t5=lf[109];
f_4448(6,t5,t4,((C_word*)t0)[2],((C_word*)t0)[6],t2,((C_word*)t0)[3]);}

/* k4693 in loop in k4678 in pregexp-replace* in k669 */
static void f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cdar(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4709,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4713,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_u_i_caar(t1);
/* substring */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[6],((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4728,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* substring */
t3=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4726 in k4693 in loop in k4678 in pregexp-replace* in k669 */
static void f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4711 in k4693 in loop in k4678 in pregexp-replace* in k669 */
static void f_4713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4713,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4717,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 830  pregexp-replace-aux */
f_3701(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4715 in k4711 in k4693 in loop in k4678 in pregexp-replace* in k669 */
static void f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 828  string-append */
t2=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4707 in k4693 in loop in k4678 in pregexp-replace* in k669 */
static void f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 827  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4691(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pregexp-replace in k669 */
static void f_4637(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4637,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fix((C_word)C_header_size(t3));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4644,a[2]=t5,a[3]=t3,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 809  pregexp-match-positions */
t7=lf[109];
f_4448(6,t7,t6,t2,t3,C_fix(0),t5);}

/* k4642 in pregexp-replace in k669 */
static void f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[5]));
t4=(C_word)C_u_i_caar(t1);
t5=(C_word)C_u_i_cdar(t1);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4666,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* substring */
t7=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[3],C_fix(0),t4);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k4664 in k4642 in pregexp-replace in k669 */
static void f_4666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4670,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 816  pregexp-replace-aux */
f_3701(t2,((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4668 in k4664 in k4642 in pregexp-replace in k669 */
static void f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4674,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* substring */
t3=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4672 in k4668 in k4664 in k4642 in pregexp-replace in k669 */
static void f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 814  string-append */
t2=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pregexp-split in k669 */
static void f_4542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4542,4,t0,t1,t2,t3);}
t4=(C_word)C_fix((C_word)C_header_size(t3));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4551,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4551(t8,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in pregexp-split in k669 */
static void C_fcall f_4551(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4551,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,((C_word*)t0)[5]))){
/* pregexp.scm: 788  pregexp-reverse! */
f_674(t1,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4564,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 789  pregexp-match-positions */
t7=lf[109];
f_4448(6,t7,t6,((C_word*)t0)[2],((C_word*)t0)[3],t2,((C_word*)t0)[5]);}}

/* k4562 in loop in pregexp-split in k669 */
static void f_4564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4564,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t4,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4597,a[2]=t6,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* substring */
t9=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,((C_word*)t0)[5],((C_word*)t0)[4],t8);}
else{
t6=((C_word*)t0)[4];
t7=(C_word)C_eqp(t3,t6);
t8=(C_truep(t7)?((C_word*)t0)[3]:C_SCHEME_FALSE);
if(C_truep(t8)){
/* pregexp.scm: 800  loop */
t9=((C_word*)((C_word*)t0)[7])[1];
f_4551(t9,((C_word*)t0)[6],t4,((C_word*)t0)[8],C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4621,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* substring */
t10=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[5],((C_word*)t0)[4],t3);}}}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* substring */
t3=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k4633 in k4562 in loop in pregexp-split in k669 */
static void f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 804  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4551(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4619 in k4562 in loop in pregexp-split in k669 */
static void f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4621,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 803  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4551(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4595 in k4562 in loop in pregexp-split in k669 */
static void f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4597,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 797  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4551(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* pregexp-match in k669 */
static void f_4513(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4513r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4513r(t0,t1,t2,t3,t4);}}

static void f_4513r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4517,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t5,lf[109],t2,t3,t4);}

/* k4515 in pregexp-match in k669 */
static void f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* map */
t3=*((C_word*)lf[124]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4524 in k4515 in pregexp-match in k669 */
static void f_4525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4525,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
/* substring */
t5=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pregexp-match-positions in k669 */
static void f_4448(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_4448r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4448r(t0,t1,t2,t3,t4);}}

static void f_4448r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4452,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
/* pregexp.scm: 759  pregexp */
t7=*((C_word*)lf[103]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
t7=t6;
f_4452(2,t7,t2);}}

/* k4450 in pregexp-match-positions in k669 */
static void f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
t3=t2;
f_4455(t3,C_fix(0));}
else{
t3=(C_word)C_u_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_slot(((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=t2;
f_4455(t6,t3);}}

/* k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_4455(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4455,NULL,2,t0,t1);}
t2=(C_word)C_i_nullp(((C_word*)((C_word*)t0)[5])[1]);
t3=(C_truep(t2)?(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[4])):(C_word)C_u_i_car(((C_word*)((C_word*)t0)[5])[1]));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4463,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4463(t7,((C_word*)t0)[2],t1);}

/* loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_4463(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4463,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t3,((C_word*)t0)[6]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=((C_word*)t0)[6];
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=t2;
t11=C_SCHEME_TRUE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2845,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2848,a[2]=t15,a[3]=t12,a[4]=t6,a[5]=t9,a[6]=t7,tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_2848(t17,t4,t5,t10,C_SCHEME_END_OF_LIST,*((C_word*)lf[115]+1),t13);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2848,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_eqp(t2,lf[8]);
if(C_truep(t7)){
t8=t3;
t9=(C_word)C_eqp(t8,((C_word*)t0)[6]);
if(C_truep(t9)){
/* pregexp.scm: 453  sk */
t10=t5;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t3,t4);}
else{
/* pregexp.scm: 453  fk */
t10=t6;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t1);}}
else{
t8=(C_word)C_eqp(t2,lf[9]);
if(C_truep(t8)){
t9=t3;
t10=((C_word*)((C_word*)t0)[5])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t9,t10))){
/* pregexp.scm: 455  sk */
t11=t5;
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,t3,t4);}
else{
/* pregexp.scm: 455  fk */
t11=t6;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t1);}}
else{
t9=(C_word)C_eqp(t2,lf[29]);
if(C_truep(t9)){
/* pregexp.scm: 457  sk */
t10=t5;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,t3,t4);}
else{
t10=(C_word)C_eqp(t2,lf[31]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2906,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 459  pregexp-at-word-boundary? */
f_2493(t11,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t11=(C_word)C_eqp(t2,lf[32]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2924,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 463  pregexp-at-word-boundary? */
f_2493(t12,((C_word*)t0)[4],t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,a[8]=t4,a[9]=t1,a[10]=t5,a[11]=t3,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_charp(t2))){
t13=t3;
t14=((C_word*)((C_word*)t0)[5])[1];
t15=t12;
f_2936(t15,(C_word)C_fixnum_lessp(t13,t14));}
else{
t13=t12;
f_2936(t13,C_SCHEME_FALSE);}}}}}}}

/* k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_2936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2936,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2942,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_subchar(((C_word*)t0)[6],((C_word*)t0)[11]);
t4=(C_truep(((C_word*)((C_word*)t0)[5])[1])?*((C_word*)lf[110]+1):*((C_word*)lf[70]+1));
t5=t4;
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=t2;
f_2965(t3,C_SCHEME_FALSE);}
else{
t3=((C_word*)t0)[11];
t4=((C_word*)((C_word*)t0)[3])[1];
t5=t2;
f_2965(t5,(C_word)C_fixnum_lessp(t3,t4));}}}

/* k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_2965(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2965,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2971,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_subchar(((C_word*)t0)[6],((C_word*)t0)[11]);
/* pregexp.scm: 471  pregexp-check-if-in-char-class? */
f_2539(t2,t3,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[5]))){
t3=(C_word)C_u_i_car(((C_word*)t0)[5]);
t4=(C_word)C_eqp(t3,lf[53]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
t6=((C_word*)((C_word*)t0)[3])[1];
t7=t2;
f_2991(t7,(C_word)C_fixnum_lessp(t5,t6));}
else{
t5=t2;
f_2991(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2991(t3,C_SCHEME_FALSE);}}}

/* k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_2991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word ab[166],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2991,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_subchar(((C_word*)t0)[11],((C_word*)t0)[10]);
t3=(C_truep(((C_word*)((C_word*)t0)[9])[1])?*((C_word*)lf[111]+1):*((C_word*)lf[112]+1));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3003,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3016,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* pregexp.scm: 477  c< */
t7=t3;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(C_word)C_eqp(t2,lf[53]);
if(C_truep(t3)){
t4=((C_word*)t0)[10];
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* pregexp.scm: 483  fk */
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[7]);}
else{
/* pregexp.scm: 483  pregexp-error */
t6=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,((C_word*)t0)[7],lf[113]);}}
else{
t4=(C_word)C_eqp(t2,lf[51]);
if(C_truep(t4)){
t5=((C_word*)t0)[10];
t6=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,t6))){
/* pregexp.scm: 485  fk */
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[7]);}
else{
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3078,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[2],a[6]=t9,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_3078(t11,((C_word*)t0)[7],t7);}}
else{
t5=(C_word)C_eqp(t2,lf[12]);
if(C_truep(t5)){
t6=((C_word*)t0)[10];
t7=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t6,t7))){
/* pregexp.scm: 492  fk */
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[7]);}
else{
t8=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 493  sub */
t11=((C_word*)((C_word*)t0)[2])[1];
f_2848(t11,((C_word*)t0)[7],t8,((C_word*)t0)[10],((C_word*)t0)[6],t9,t10);}}
else{
t6=(C_word)C_eqp(t2,lf[6]);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3158,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_3158(t11,((C_word*)t0)[7],t7,((C_word*)t0)[10],((C_word*)t0)[6]);}
else{
t7=(C_word)C_eqp(t2,lf[7]);
if(C_truep(t7)){
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3200,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[8],a[6]=t10,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t12=((C_word*)t10)[1];
f_3200(t12,((C_word*)t0)[7],t8);}
else{
t8=(C_word)C_eqp(t2,lf[24]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
/* pregexp.scm: 512  pregexp-list-ref */
f_2804(t9,((C_word*)t0)[6],t10);}
else{
t9=(C_word)C_eqp(t2,lf[102]);
if(C_truep(t9)){
t10=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[10]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[8],a[7]=t10,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_a_i_list(&a,1,t10);
/* pregexp.scm: 520  append */
t13=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,((C_word*)t0)[6],t12);}
else{
t10=(C_word)C_eqp(t2,lf[114]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t12=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3339,tmp=(C_word)a,a+=2,tmp);
/* pregexp.scm: 527  sub */
t14=((C_word*)((C_word*)t0)[2])[1];
f_2848(t14,t11,t12,((C_word*)t0)[10],((C_word*)t0)[6],*((C_word*)lf[115]+1),t13);}
else{
t11=(C_word)C_eqp(t2,lf[116]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3349,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t13=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3364,tmp=(C_word)a,a+=2,tmp);
/* pregexp.scm: 532  sub */
t15=((C_word*)((C_word*)t0)[2])[1];
f_2848(t15,t12,t13,((C_word*)t0)[10],((C_word*)t0)[6],*((C_word*)lf[115]+1),t14);}
else{
t12=(C_word)C_eqp(t2,lf[117]);
if(C_truep(t12)){
t13=((C_word*)((C_word*)t0)[3])[1];
t14=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[10]);
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t13,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t16=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t17=(C_word)C_a_i_list(&a,4,lf[6],lf[118],t16,lf[9]);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3391,tmp=(C_word)a,a+=2,tmp);
/* pregexp.scm: 538  sub */
t19=((C_word*)((C_word*)t0)[2])[1];
f_2848(t19,t15,t17,C_fix(0),((C_word*)t0)[6],*((C_word*)lf[115]+1),t18);}
else{
t13=(C_word)C_eqp(t2,lf[119]);
if(C_truep(t13)){
t14=((C_word*)((C_word*)t0)[3])[1];
t15=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[10]);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3406,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=t14,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t17=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t18=(C_word)C_a_i_list(&a,4,lf[6],lf[120],t17,lf[9]);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3422,tmp=(C_word)a,a+=2,tmp);
/* pregexp.scm: 546  sub */
t20=((C_word*)((C_word*)t0)[2])[1];
f_2848(t20,t16,t18,C_fix(0),((C_word*)t0)[6],*((C_word*)lf[115]+1),t19);}
else{
t14=(C_word)C_eqp(t2,lf[121]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3459,tmp=(C_word)a,a+=2,tmp);
/* pregexp.scm: 552  sub */
t18=((C_word*)((C_word*)t0)[2])[1];
f_2848(t18,t15,t16,((C_word*)t0)[10],((C_word*)t0)[6],*((C_word*)lf[115]+1),t17);}
else{
t15=(C_word)C_eqp(t2,lf[21]);
t16=(C_truep(t15)?t15:(C_word)C_eqp(t2,lf[22]));
if(C_truep(t16)){
t17=((C_word*)((C_word*)t0)[9])[1];
t18=(C_word)C_u_i_car(((C_word*)t0)[4]);
t19=(C_word)C_eqp(t18,lf[21]);
t20=C_mutate(((C_word *)((C_word*)t0)[9])+1,t19);
t21=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3482,a[2]=((C_word*)t0)[8],a[3]=t17,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[5],a[3]=t17,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 561  sub */
t24=((C_word*)((C_word*)t0)[2])[1];
f_2848(t24,((C_word*)t0)[7],t21,((C_word*)t0)[10],((C_word*)t0)[6],t22,t23);}
else{
t17=(C_word)C_eqp(t2,lf[39]);
if(C_truep(t17)){
t18=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t19=(C_word)C_i_not(t18);
t20=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t21=(C_word)C_u_i_cadddr(((C_word*)t0)[4]);
t22=(C_word)C_u_i_cddddr(((C_word*)t0)[4]);
t23=(C_word)C_u_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=t19,a[5]=((C_word*)t0)[8],a[6]=t21,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t23,a[10]=((C_word*)t0)[2],a[11]=t20,tmp=(C_word)a,a+=12,tmp);
if(C_truep((C_word)C_i_pairp(t23))){
t25=(C_word)C_u_i_car(t23);
t26=t24;
f_3519(t26,(C_word)C_eqp(t25,lf[102]));}
else{
t25=t24;
f_3519(t25,C_SCHEME_FALSE);}}
else{
/* pregexp.scm: 601  pregexp-error */
t18=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,((C_word*)t0)[7],lf[113]);}}}}}}}}}}}}}}}
else{
t2=((C_word*)t0)[10];
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
/* pregexp.scm: 602  fk */
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[7]);}
else{
/* pregexp.scm: 603  pregexp-error */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[7],lf[113]);}}}}

/* k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3519(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3519,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_3524(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2],lf[122]);}

/* loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3524(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3524,NULL,5,t0,t1,t2,t3,t4);}
t5=t2;
if(C_truep((C_word)C_fixnum_lessp(t5,((C_word*)t0)[11]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 575  sub */
t7=((C_word*)((C_word*)t0)[9])[1];
f_2848(t7,t1,((C_word*)t0)[8],t3,((C_word*)t0)[7],t6,((C_word*)t0)[6]);}
else{
t6=(C_truep(((C_word*)t0)[5])?(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[11]):C_SCHEME_FALSE);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3552,a[2]=t6,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t8,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_3552(t10,t1,C_fix(0),t3,t4);}}

/* loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3552(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3552,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3554,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3581,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
t7=t2;
t8=t6;
f_3581(t8,(C_word)C_fixnum_greater_or_equal_p(t7,((C_word*)t0)[2]));}
else{
t7=t6;
f_3581(t7,C_SCHEME_FALSE);}}

/* k3579 in loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3581,NULL,2,t0,t1);}
if(C_truep(t1)){
/* pregexp.scm: 589  fk */
t2=((C_word*)t0)[10];
f_3554(2,t2,((C_word*)t0)[9]);}
else{
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 591  sub */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2848(t3,((C_word*)t0)[9],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2,((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* pregexp.scm: 596  fk */
t3=((C_word*)t0)[10];
f_3554(2,t3,t2);}}}

/* k3607 in k3579 in loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3609,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 597  sub */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2848(t3,((C_word*)t0)[9],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* a3616 in k3607 in k3579 in loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3617(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3617,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 599  loup-q */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3552(t5,t1,t4,t2,t3);}

/* a3591 in k3579 in loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3592(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3592,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3596,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 593  loup-q */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3552(t6,t4,t5,t2,t3);}

/* k3594 in a3591 in k3579 in loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* pregexp.scm: 594  fk */
t2=((C_word*)t0)[2];
f_3554(2,t2,((C_word*)t0)[3]);}}

/* fk in loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3562,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[122]);
if(C_truep(t3)){
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_a_i_list(&a,1,C_SCHEME_FALSE);
/* pregexp.scm: 585  append */
t5=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[2],t4);}
else{
t4=t2;
f_3562(2,t4,((C_word*)t0)[2]);}}
else{
t4=t2;
f_3562(2,t4,((C_word*)t0)[4]);}}

/* k3560 in fk in loup-q in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 582  sk */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3535 in loup-p in k3517 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3536(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3536,4,t0,t1,t2,t3);}
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 577  loup-p */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3524(t5,t1,t4,t2,t3);}

/* a3488 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3489,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
/* pregexp.scm: 567  fk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a3481 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3482(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3482,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
/* pregexp.scm: 564  sk */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a3458 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3434 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t1);
/* pregexp.scm: 555  sk */
t4=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t2,t3);}
else{
/* pregexp.scm: 556  fk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* a3421 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3422,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3404 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
if(C_truep(t1)){
/* pregexp.scm: 550  fk */
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* pregexp.scm: 550  sk */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a3390 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3373 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
if(C_truep(t1)){
/* pregexp.scm: 542  sk */
t3=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 542  fk */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}}

/* a3363 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3347 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 534  fk */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* pregexp.scm: 534  sk */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a3338 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3322 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 529  sk */
t2=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 529  fk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k3293 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 521  sub */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2848(t4,((C_word*)t0)[4],t2,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* a3303 in k3293 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3304,4,t0,t1,t2,t3);}
t4=(C_word)C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
/* pregexp.scm: 524  sk */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* k3250 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_slot(t1,C_fix(1));
/* substring */
t5=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}
else{
/* pregexp.scm: 517  sk */
t2=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[7]);}}

/* k3260 in k3250 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3264,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)((C_word*)t0)[4])[1];
t6=((C_word*)t0)[3];
t7=(C_word)C_fix((C_word)C_header_size(t1));
if(C_truep((C_word)C_fixnum_greaterp(t7,t5))){
/* pregexp.scm: 370  fk */
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t3);}
else{
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2426,a[2]=t9,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t6,a[6]=t5,a[7]=t2,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_2426(t11,t3,C_fix(0),t4);}}

/* loop in k3260 in k3250 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_2426(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2426,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[8]))){
/* pregexp.scm: 372  sk */
t5=((C_word*)t0)[7];
f_3264(t5,t1,t3);}
else{
t5=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,((C_word*)t0)[6]))){
/* pregexp.scm: 373  fk */
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
t7=(C_word)C_subchar(((C_word*)t0)[3],t3);
t8=(C_word)C_eqp(t6,t7);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 375  loop */
t12=t1;
t13=t9;
t14=t10;
t1=t12;
t2=t13;
t3=t14;
goto loop;}
else{
/* pregexp.scm: 376  fk */
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t1);}}}}

/* a3263 in k3260 in k3250 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3264,NULL,3,t0,t1,t2);}
/* pregexp.scm: 516  sk */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* loup-or in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3200(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3200,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* pregexp.scm: 505  fk */
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3219,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 506  sub */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2848(t6,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2],t4,t5);}}

/* a3234 in loup-or in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 510  loup-or */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3200(t3,t1,t2);}

/* a3218 in loup-or in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3219(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3219,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 508  sk */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k3221 in a3218 in loup-or in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 509  loup-or */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3200(t3,((C_word*)t0)[4],t2);}}

/* loup-seq in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3158(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3158,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
/* pregexp.scm: 498  sk */
t5=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}
else{
t5=(C_word)C_u_i_car(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 499  sub */
t7=((C_word*)((C_word*)t0)[3])[1];
f_2848(t7,t1,t5,t3,t4,t6,((C_word*)t0)[2]);}}

/* a3176 in loup-seq in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3177,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 501  loup-seq */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3158(t5,t1,t4,t2,t3);}

/* a3134 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* pregexp.scm: 495  sk */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3128 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3129(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3129,4,t0,t1,t2,t3);}
/* pregexp.scm: 494  fk */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* loup-one-of-chars in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void C_fcall f_3078(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3078,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* pregexp.scm: 487  fk */
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 488  sub */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2848(t5,t1,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t4);}}

/* a3096 in loup-one-of-chars in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 490  loup-one-of-chars */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3078(t3,t1,t2);}

/* k3014 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
/* pregexp.scm: 478  c< */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_3003(2,t2,C_SCHEME_FALSE);}}

/* k3001 in k2989 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_3003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* pregexp.scm: 479  sk */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* pregexp.scm: 479  fk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k2969 in k2963 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_2971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* pregexp.scm: 473  sk */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* pregexp.scm: 473  fk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k2940 in k2934 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_2942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
/* pregexp.scm: 469  sk */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* pregexp.scm: 469  fk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* k2922 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 464  fk */
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
/* pregexp.scm: 465  sk */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2904 in sub in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_2906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* pregexp.scm: 460  sk */
t2=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* pregexp.scm: 461  fk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* a2844 in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_2845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2845,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4471 in loop in k4453 in k4450 in pregexp-match-positions in k669 */
static void f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_cadr(t1));}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* pregexp.scm: 771  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4463(t3,((C_word*)t0)[4],t2);}}

/* regexp? in k669 */
static void f_4432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4432,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[102],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pregexp in k669 */
static void f_4373(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_4373r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4373r(t0,t1,t2,t3);}}

static void f_4373r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4381,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_4381(2,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4387,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_u_i_car(t3))){
/* pregexp.scm: 744  string-append */
t6=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[106],t2,lf[107]);}
else{
t6=t5;
f_4387(2,t6,t2);}}}

/* k4385 in pregexp in k669 */
static void f_4387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4387,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
if(C_truep((C_word)C_i_nullp(t2))){
t3=((C_word*)t0)[2];
f_4381(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_u_i_car(t2))){
/* pregexp.scm: 748  string-append */
t4=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[104],t1,lf[105]);}
else{
t4=t3;
f_4399(2,t4,t1);}}}

/* k4397 in k4385 in pregexp in k669 */
static void f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?(C_word)C_u_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t4)){
/* pregexp.scm: 751  utf8-pattern->byte-pattern */
t5=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,((C_word*)t0)[2],t1);}
else{
t5=((C_word*)t0)[2];
f_4381(2,t5,t1);}}

/* k4379 in pregexp in k669 */
static void f_4381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 741  %pregexp */
t2=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* %pregexp in k669 */
static void f_4354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4354,3,t0,t1,t2);}
t3=C_set_block_item(lf[0],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4367,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fix((C_word)C_header_size(t2));
/* pregexp.scm: 738  pregexp-read-pattern */
f_704(t4,t2,C_fix(0),t5);}

/* k4365 in %pregexp in k669 */
static void f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[102],t2));}

/* utf8-pattern->byte-pattern in k669 */
static void f_3950(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3950,3,t0,t1,t2);}
t3=(C_word)C_fix((C_word)C_header_size(t2));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4084,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3956,a[2]=t8,a[3]=t6,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4196,a[2]=t8,a[3]=t4,a[4]=t6,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
/* pregexp.scm: 733  scan */
t11=((C_word*)t6)[1];
f_3956(t11,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* class in utf8-pattern->byte-pattern in k669 */
static void C_fcall f_4196(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word *a;
loop:
a=C_alloc(40);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4196,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_eqp(t6,((C_word*)t0)[6]);
if(C_truep(t7)){
/* pregexp.scm: 715  ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[82],lf[100],((C_word*)t0)[5]);}
else{
t8=(C_word)C_subchar(((C_word*)t0)[5],t2);
switch(t8){
case C_make_character(93):
if(C_truep(t4)){
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4233,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_a_i_cons(&a,2,C_make_character(91),t5);
/* pregexp.scm: 720  append */
t12=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t3,t11);}
else{
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4248,a[2]=t9,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4252,a[2]=t5,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4256,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 721  class->group */
t13=((C_word*)t0)[3];
f_4084(t13,t12,t3);}
case C_make_character(92):
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_subchar(((C_word*)t0)[5],t9);
t11=(C_word)C_fix((C_word)C_character_code(t10));
if(C_truep((C_word)C_fixnum_lessp(t11,C_fix(128)))){
t12=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t13=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
t14=(C_word)C_a_i_cons(&a,2,t10,t13);
/* pregexp.scm: 725  class */
t30=t1;
t31=t12;
t32=t14;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
else{
t12=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
/* pregexp.scm: 726  class */
t30=t1;
t31=t12;
t32=t13;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
default:
t9=(C_word)C_fix((C_word)C_character_code(t8));
if(C_truep((C_word)C_fixnum_lessp(t9,C_fix(128)))){
t10=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t11=(C_word)C_a_i_cons(&a,2,t8,t3);
/* pregexp.scm: 729  class */
t30=t1;
t31=t10;
t32=t11;
t33=t4;
t34=t5;
t1=t30;
t2=t31;
t3=t32;
t4=t33;
t5=t34;
goto loop;}
else{
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=(C_word)C_fix((C_word)C_character_code(t8));
/* pregexp.scm: 730  utf8-start-byte->length */
t12=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}}}

/* k4339 in class in utf8-pattern->byte-pattern in k669 */
static void f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4337,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 731  string-ref-at-byte */
t4=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k4335 in k4339 in class in utf8-pattern->byte-pattern in k669 */
static void f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* pregexp.scm: 730  class */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4196(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4254 in class in utf8-pattern->byte-pattern in k669 */
static void f_4256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 721  reverse */
t2=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4250 in class in utf8-pattern->byte-pattern in k669 */
static void f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 721  append */
t2=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4246 in class in utf8-pattern->byte-pattern in k669 */
static void f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 721  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3956(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4231 in class in utf8-pattern->byte-pattern in k669 */
static void f_4233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4233,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_make_character(93),t1);
/* pregexp.scm: 720  scan */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3956(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* scan in utf8-pattern->byte-pattern in k669 */
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word *a;
loop:
a=C_alloc(18);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3956,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_eqp(t4,((C_word*)t0)[5]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3970,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 686  reverse */
t7=*((C_word*)lf[98]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[4],t2);
switch(t6){
case C_make_character(46):
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3985,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_lessp(t8,((C_word*)t0)[5]))){
t9=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=(C_word)C_subchar(((C_word*)t0)[4],t9);
t11=t7;
f_3985(t11,(C_word)C_eqp(C_make_character(42),t10));}
else{
t9=t7;
f_3985(t9,C_SCHEME_FALSE);}
case C_make_character(92):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t9=(C_word)C_subchar(((C_word*)t0)[4],t8);
t10=(C_word)C_a_i_cons(&a,2,C_make_character(92),t3);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
/* pregexp.scm: 694  scan */
t21=t1;
t22=t7;
t23=t11;
t1=t21;
t2=t22;
t3=t23;
goto loop;
case C_make_character(91):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 695  class */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4196(t8,t1,t7,C_SCHEME_END_OF_LIST,C_SCHEME_TRUE,t3);
default:
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* pregexp.scm: 696  scan */
t21=t1;
t22=t7;
t23=t8;
t1=t21;
t2=t22;
t3=t23;
goto loop;}}}

/* k3983 in scan in utf8-pattern->byte-pattern in k669 */
static void C_fcall f_3985(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3985,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
t3=(C_word)C_a_i_cons(&a,2,C_make_character(46),((C_word*)t0)[4]);
t4=(C_word)C_a_i_cons(&a,2,C_make_character(42),t3);
/* pregexp.scm: 691  scan */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3956(t5,((C_word*)t0)[2],t2,t4);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4011,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* pregexp.scm: 692  append */
t4=*((C_word*)lf[99]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[85],((C_word*)t0)[4]);}}

/* k4009 in k3983 in scan in utf8-pattern->byte-pattern in k669 */
static void f_4011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 692  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3956(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3968 in scan in utf8-pattern->byte-pattern in k669 */
static void f_3970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 686  list->string */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* class->group in utf8-pattern->byte-pattern in k669 */
static void C_fcall f_4084(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4084,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4090,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4090(t6,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in class->group in utf8-pattern->byte-pattern in k669 */
static void C_fcall f_4090(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4090,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4104,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4108,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 701  string-intersperse */
t6=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[92]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4120,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=t4,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_u_i_car(t5);
t8=t6;
f_4120(t8,(C_word)C_eqp(C_make_character(45),t7));}
else{
t7=t6;
f_4120(t7,C_SCHEME_FALSE);}}}

/* k4118 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void C_fcall f_4120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4120,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[7]));
t4=(C_word)C_fixnum_greaterp(t3,C_fix(128));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4132,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=t5;
f_4132(t6,t4);}
else{
t6=(C_word)C_fix((C_word)C_character_code(t2));
t7=t5;
f_4132(t7,(C_word)C_fixnum_greaterp(t6,C_fix(128)));}}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4184,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 712  char->string */
t4=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}}

/* k4182 in k4118 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4184,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 712  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4090(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4130 in k4118 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void C_fcall f_4132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4132,NULL,2,t0,t1);}
if(C_truep(t1)){
/* pregexp.scm: 707  ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[8],lf[82],lf[93],((C_word*)t0)[7]);}
else{
t2=(C_word)C_u_i_cddr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4150,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4154,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 709  char->string */
t5=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k4152 in k4130 in k4118 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4158,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 710  char->string */
t3=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4156 in k4152 in k4130 in k4118 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void f_4158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 709  string-append */
t2=*((C_word*)lf[88]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[3],lf[94],((C_word*)t0)[2],lf[95],t1,lf[96]);}

/* k4148 in k4130 in k4118 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* pregexp.scm: 708  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4090(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4106 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 701  string-append */
t2=*((C_word*)lf[88]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[89],t1,lf[90]);}

/* k4102 in loop in class->group in utf8-pattern->byte-pattern in k669 */
static void f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 700  string->list */
t2=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* string-ref-at-byte in k669 */
static void f_3861(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3861,4,t0,t1,t2,t3);}
t4=(C_word)C_subchar(t2,t3);
t5=(C_word)C_fix((C_word)C_character_code(t4));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3871,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 659  utf8-start-byte->length */
t7=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k3869 in string-ref-at-byte in k669 */
static void f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],t1);
t4=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[2]));
if(C_truep((C_word)C_fixnum_greaterp(t3,t4))){
/* pregexp.scm: 664  ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,((C_word*)t0)[5],lf[82],lf[83],((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3900,a[2]=t5,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_u_fixnum_difference(C_fix(7),t1);
/* pregexp.scm: 665  extract-bit-field */
t8=*((C_word*)lf[78]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t7,C_fix(0),((C_word*)t0)[4]);}}}

/* k3898 in k3869 in string-ref-at-byte in k669 */
static void f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_3902(t2,((C_word*)t0)[2],t1));}

/* loop in k3898 in k3869 in string-ref-at-byte in k669 */
static C_word C_fcall f_3902(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
loop:
t3=t1;
t4=(C_word)C_eqp(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
return((C_word)C_make_character((C_word)C_unfix(t2)));}
else{
t5=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_fixnum_shift_left(t2,C_fix(6));
t7=(C_word)C_subchar(((C_word*)t0)[2],t1);
t8=(C_word)C_fix((C_word)C_character_code(t7));
t9=(C_word)C_u_fixnum_and(C_fix(63),t8);
t10=(C_word)C_u_fixnum_or(t6,t9);
t12=t5;
t13=t10;
t1=t12;
t2=t13;
goto loop;}}

/* utf8-start-byte->length in k669 */
static void f_3855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3855,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(lf[80],t2));}

/* extract-bit-field in k669 */
static void f_3833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3833,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_fixnum_arithmetic_shift(C_fix(-1),t2);
t6=(C_word)C_fixnum_not(t5);
t7=(C_word)C_u_fixnum_negate(t3);
t8=(C_word)C_i_fixnum_arithmetic_shift(t4,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_u_fixnum_and(t6,t8));}

/* pregexp-replace-aux in k669 */
static void C_fcall f_3701(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3701,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3707,a[2]=t5,a[3]=t2,a[4]=t7,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_3707(t9,t1,C_fix(0),lf[77]);}

/* loop in pregexp-replace-aux in k669 */
static void C_fcall f_3707(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3707,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[5],t2);
t7=(C_word)C_eqp(t6,C_make_character(92));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3726,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* pregexp.scm: 611  pregexp-read-escaped-number */
f_1127(t8,((C_word*)t0)[5],t2,((C_word*)t0)[6]);}
else{
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3827,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3831,a[2]=t3,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 629  string */
t11=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t6);}}}

/* k3829 in loop in pregexp-replace-aux in k669 */
static void f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3825 in loop in pregexp-replace-aux in k669 */
static void f_3827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 629  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3707(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3724 in loop in pregexp-replace-aux in k669 */
static void f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3729,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_3729(t3,(C_word)C_u_i_car(t1));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=(C_word)C_subchar(((C_word*)t0)[2],t3);
t5=(C_word)C_eqp(t4,C_make_character(38));
t6=t2;
f_3729(t6,(C_truep(t5)?C_fix(0):C_SCHEME_FALSE));}}

/* k3727 in k3724 in loop in pregexp-replace-aux in k669 */
static void C_fcall f_3729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3729,NULL,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[9])?(C_word)C_u_i_cadr(((C_word*)t0)[9]):(C_truep(t1)?(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(2)):(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(1))));
t3=t1;
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 624  pregexp-list-ref */
f_2804(t4,((C_word*)t0)[3],t1);}
else{
t4=(C_word)C_subchar(((C_word*)t0)[2],t2);
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3752,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t4,C_make_character(36));
if(C_truep(t7)){
t8=t6;
f_3752(2,t8,((C_word*)t0)[5]);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 622  string */
t9=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}}}

/* k3760 in k3727 in k3724 in loop in pregexp-replace-aux in k669 */
static void f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3750 in k3727 in k3724 in loop in pregexp-replace-aux in k669 */
static void f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 620  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3707(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3767 in k3727 in k3724 in loop in pregexp-replace-aux in k669 */
static void f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_i_car(t1);
t5=(C_word)C_slot(t1,C_fix(1));
/* substring */
t6=*((C_word*)lf[75]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}
else{
t3=t2;
f_3772(2,t3,((C_word*)t0)[3]);}}

/* k3777 in k3767 in k3727 in k3724 in loop in pregexp-replace-aux in k669 */
static void f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
t2=*((C_word*)lf[74]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3770 in k3767 in k3727 in k3724 in loop in pregexp-replace-aux in k669 */
static void f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 623  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3707(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pregexp-list-ref in k669 */
static void C_fcall f_2804(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2804,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2810,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2810(t4,t2,C_fix(0)));}

/* loop in pregexp-list-ref in k669 */
static C_word C_fcall f_2810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=t2;
t4=((C_word*)t0)[2];
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
return((C_word)C_u_i_car(t1));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}}

/* pregexp-check-if-in-char-class? in k669 */
static void C_fcall f_2539(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2539,NULL,3,t1,t2,t3);}
t4=(C_word)C_eqp(t3,lf[10]);
if(C_truep(t4)){
t5=(C_word)C_eqp(t2,C_make_character(10));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_not(t5));}
else{
t5=(C_word)C_eqp(t3,lf[59]);
if(C_truep(t5)){
t6=(C_word)C_u_i_char_alphabeticp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:(C_word)C_u_i_char_numericp(t2)));}
else{
t6=(C_word)C_eqp(t3,lf[60]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_u_i_char_alphabeticp(t2));}
else{
t7=(C_word)C_eqp(t3,lf[61]);
if(C_truep(t7)){
t8=(C_word)C_fix((C_word)C_character_code(t2));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_lessp(t8,C_fix(128)));}
else{
t8=(C_word)C_eqp(t3,lf[62]);
if(C_truep(t8)){
t9=(C_word)C_eqp(t2,C_make_character(32));
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_truep(t9)?t9:(C_word)C_eqp(t2,C_make_character(9))));}
else{
t9=(C_word)C_eqp(t3,lf[63]);
if(C_truep(t9)){
t10=(C_word)C_fix((C_word)C_character_code(t2));
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_fixnum_lessp(t10,C_fix(32)));}
else{
t10=(C_word)C_eqp(t3,lf[33]);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_u_i_char_numericp(t2));}
else{
t11=(C_word)C_eqp(t3,lf[64]);
if(C_truep(t11)){
t12=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t12,C_fix(32)))){
t13=(C_word)C_u_i_char_whitespacep(t2);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_i_not(t13));}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t3,lf[65]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,(C_word)C_u_i_char_lower_casep(t2));}
else{
t13=(C_word)C_eqp(t3,lf[66]);
if(C_truep(t13)){
t14=(C_word)C_fix((C_word)C_character_code(t2));
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_fixnum_greater_or_equal_p(t14,C_fix(32)));}
else{
t14=(C_word)C_eqp(t3,lf[67]);
if(C_truep(t14)){
t15=(C_word)C_fix((C_word)C_character_code(t2));
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t15,C_fix(32)))){
if(C_truep((C_word)C_u_i_char_whitespacep(t2))){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t2))){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_u_i_char_numericp(t2);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_i_not(t16));}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_eqp(t3,lf[35]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,(C_word)C_u_i_char_whitespacep(t2));}
else{
t16=(C_word)C_eqp(t3,lf[68]);
if(C_truep(t16)){
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,(C_word)C_u_i_char_upper_casep(t2));}
else{
t17=(C_word)C_eqp(t3,lf[37]);
if(C_truep(t17)){
t18=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t18)){
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t19=(C_word)C_u_i_char_numericp(t2);
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,(C_truep(t19)?t19:(C_word)C_eqp(t2,C_make_character(95))));}}
else{
t18=(C_word)C_eqp(t3,lf[69]);
if(C_truep(t18)){
t19=(C_word)C_u_i_char_numericp(t2);
if(C_truep(t19)){
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,t19);}
else{
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2769,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 423  char-ci=? */
t21=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t20,t2,C_make_character(97));}}
else{
/* pregexp.scm: 426  pregexp-error */
t19=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t1,lf[71]);}}}}}}}}}}}}}}}}

/* k2767 in pregexp-check-if-in-char-class? in k669 */
static void f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2769,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 423  char-ci=? */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_make_character(98));}}

/* k2773 in k2767 in pregexp-check-if-in-char-class? in k669 */
static void f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 424  char-ci=? */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_make_character(99));}}

/* k2779 in k2773 in k2767 in pregexp-check-if-in-char-class? in k669 */
static void f_2781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2781,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 424  char-ci=? */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_make_character(100));}}

/* k2785 in k2779 in k2773 in k2767 in pregexp-check-if-in-char-class? in k669 */
static void f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2787,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 425  char-ci=? */
t3=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_make_character(101));}}

/* k2791 in k2785 in k2779 in k2773 in k2767 in pregexp-check-if-in-char-class? in k669 */
static void f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* pregexp.scm: 425  char-ci=? */
t2=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(102));}}

/* pregexp-at-word-boundary? in k669 */
static void C_fcall f_2493(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2493,NULL,4,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_eqp(t5,C_fix(0));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=t3;
t8=(C_word)C_fixnum_greater_or_equal_p(t7,t4);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=(C_word)C_subchar(t2,t3);
t10=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t11=(C_word)C_subchar(t2,t10);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2515,a[2]=t11,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 391  pregexp-check-if-in-char-class? */
f_2539(t12,t9,lf[37]);}}}

/* k2513 in pregexp-at-word-boundary? in k669 */
static void f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 393  pregexp-check-if-in-char-class? */
f_2539(t2,((C_word*)t0)[2],lf[37]);}

/* k2516 in k2513 in pregexp-at-word-boundary? in k669 */
static void f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(((C_word*)t0)[3])?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t1));}}

/* pregexp-char-word? in k669 */
static void f_2475(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2475,3,t0,t1,t2);}
t3=(C_word)C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:(C_word)C_eqp(t2,C_make_character(95))));}}

/* pregexp-read-char-list in k669 */
static void C_fcall f_2202(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2202,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=t6,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2208(t8,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in pregexp-read-char-list in k669 */
static void C_fcall f_2208(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word *a;
loop:
a=C_alloc(121);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2208,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
/* pregexp.scm: 339  pregexp-error */
t6=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[49],lf[50]);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[3],t3);
switch(t6){
case C_make_character(93):
if(C_truep((C_word)C_i_nullp(t2))){
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 344  loop */
t41=t1;
t42=t7;
t43=t8;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2259,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 345  pregexp-reverse! */
f_674(t7,t2);}
case C_make_character(92):
t7=f_1223(C_a_i(&a,72),((C_word*)t0)[3],t3,((C_word*)t0)[4]);
if(C_truep(t7)){
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_a_i_cons(&a,2,t8,t2);
t10=(C_word)C_u_i_cadr(t7);
/* pregexp.scm: 349  loop */
t41=t1;
t42=t9;
t43=t10;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
else{
/* pregexp.scm: 350  pregexp-error */
t8=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,lf[49],lf[52]);}
case C_make_character(45):
t7=(C_word)C_u_i_car(t2);
if(C_truep((C_word)C_charp(t7))){
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_subchar(((C_word*)t0)[3],t8);
t10=(C_word)C_a_i_list(&a,3,lf[53],t7,t9);
t11=(C_word)C_slot(t2,C_fix(1));
t12=(C_word)C_a_i_cons(&a,2,t10,t11);
t13=(C_word)C_u_fixnum_plus(t3,C_fix(2));
/* pregexp.scm: 353  loop */
t41=t1;
t42=t12;
t43=t13;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
else{
t8=(C_word)C_a_i_cons(&a,2,t6,t2);
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 356  loop */
t41=t1;
t42=t8;
t43=t9;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
case C_make_character(91):
t7=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t8=(C_word)C_subchar(((C_word*)t0)[3],t7);
t9=(C_word)C_eqp(t8,C_make_character(58));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2357,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_u_fixnum_plus(t3,C_fix(2));
t12=((C_word*)t0)[3];
t13=((C_word*)t0)[4];
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(C_word)C_a_i_list(&a,1,C_make_character(58));
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1403,a[2]=t18,a[3]=t15,a[4]=t12,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t20=((C_word*)t18)[1];
f_1403(t20,t10,t11,t16);}
else{
t10=(C_word)C_a_i_cons(&a,2,t6,t2);
t11=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 362  loop */
t41=t1;
t42=t10;
t43=t11;
t1=t41;
t2=t42;
t3=t43;
goto loop;}
default:
t7=(C_word)C_a_i_cons(&a,2,t6,t2);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* pregexp.scm: 363  loop */
t41=t1;
t42=t7;
t43=t8;
t1=t41;
t2=t42;
t3=t43;
goto loop;}}}

/* loop in loop in pregexp-read-char-list in k669 */
static void C_fcall f_1403(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1403,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
/* pregexp.scm: 186  pregexp-error */
t5=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[54]);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[4],t2);
t6=(C_word)C_eqp(t5,C_make_character(94));
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 190  loop */
t19=t1;
t20=t8;
t21=t3;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
if(C_truep((C_word)C_u_i_char_alphabeticp(t5))){
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t5,t3);
/* pregexp.scm: 192  loop */
t19=t1;
t20=t7;
t21=t8;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t7=(C_word)C_eqp(t5,C_make_character(58));
if(C_truep(t7)){
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t9=(C_word)C_fixnum_greater_or_equal_p(t8,((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1462,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t9)){
t11=t10;
f_1462(t11,t9);}
else{
t11=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t12=(C_word)C_subchar(((C_word*)t0)[4],t11);
t13=(C_word)C_eqp(t12,C_make_character(93));
t14=t10;
f_1462(t14,(C_word)C_i_not(t13));}}
else{
/* pregexp.scm: 204  pregexp-error */
t8=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,lf[54]);}}}}}

/* k1460 in loop in loop in pregexp-read-char-list in k669 */
static void C_fcall f_1462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1462,NULL,2,t0,t1);}
if(C_truep(t1)){
/* pregexp.scm: 196  pregexp-error */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],lf[54]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1486,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1490,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 199  pregexp-reverse! */
f_674(t4,((C_word*)t0)[2]);}}

/* k1488 in k1460 in loop in loop in pregexp-read-char-list in k669 */
static void f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 199  list->string */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1484 in k1460 in loop in loop in pregexp-read-char-list in k669 */
static void f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 198  string->symbol */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1466 in k1460 in loop in loop in pregexp-read-char-list in k669 */
static void f_1468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1468,2,t0,t1);}
t2=(C_truep(((C_word*)((C_word*)t0)[4])[1])?(C_word)C_a_i_list(&a,2,lf[12],t1):t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(2));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2355 in loop in pregexp-read-char-list in k669 */
static void f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=(C_word)C_u_i_cadr(t1);
/* pregexp.scm: 360  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2208(t5,((C_word*)t0)[2],t3,t4);}

/* k2257 in loop in pregexp-read-char-list in k669 */
static void f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2259,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[51],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* pregexp-invert-char-list in k669 */
static void f_2192(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2192,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_i_setslot(t3,C_fix(0),lf[48]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* pregexp-wrap-quantifier-if-any in k669 */
static void C_fcall f_1772(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1772,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_u_i_cadr(t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1785,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1785(t10,t1,t6);}

/* loop in pregexp-wrap-quantifier-if-any in k669 */
static void C_fcall f_1785(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1785,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t3)[1];
t5=((C_word*)t0)[6];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[5]);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[4],((C_word*)t3)[1]);
t7=(C_word)C_u_i_char_whitespacep(t6);
t8=(C_truep(t7)?(C_word)C_i_not(*((C_word*)lf[0]+1)):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(((C_word*)t3)[1],C_fix(1));
/* pregexp.scm: 266  loop */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t9=(C_word)C_eqp(t6,C_make_character(42));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t9)){
t11=t10;
f_1817(t11,t9);}
else{
t11=(C_word)C_eqp(t6,C_make_character(43));
if(C_truep(t11)){
t12=t10;
f_1817(t12,t11);}
else{
t12=(C_word)C_eqp(t6,C_make_character(63));
t13=t10;
f_1817(t13,(C_truep(t12)?t12:(C_word)C_eqp(t6,C_make_character(123))));}}}}}

/* k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void C_fcall f_1817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1817,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,5,lf[39],lf[40],lf[41],lf[42],((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,2,t2,lf[43]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1826,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
switch(((C_word*)t0)[3]){
case C_make_character(42):
t5=(C_word)C_u_i_cddr(t2);
t6=(C_word)C_i_set_i_slot(t5,C_fix(0),C_fix(0));
t7=(C_word)C_u_i_cdddr(t2);
t8=t4;
f_1826(t8,(C_word)C_i_set_i_slot(t7,C_fix(0),C_SCHEME_FALSE));
case C_make_character(43):
t5=(C_word)C_u_i_cddr(t2);
t6=(C_word)C_i_set_i_slot(t5,C_fix(0),C_fix(1));
t7=(C_word)C_u_i_cdddr(t2);
t8=t4;
f_1826(t8,(C_word)C_i_set_i_slot(t7,C_fix(0),C_SCHEME_FALSE));
case C_make_character(63):
t5=(C_word)C_u_i_cddr(t2);
t6=(C_word)C_i_set_i_slot(t5,C_fix(0),C_fix(0));
t7=(C_word)C_u_i_cdddr(t2);
t8=t4;
f_1826(t8,(C_word)C_i_set_i_slot(t7,C_fix(0),C_fix(1)));
case C_make_character(123):
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1982,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t7=((C_word*)t0)[5];
t8=((C_word*)t0)[6];
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2050,a[2]=t8,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_2050(t12,t5,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t6,C_fix(1));
default:
t5=t4;
f_1826(t5,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void C_fcall f_2050(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2050,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2054,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t5,a[7]=t4,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t7=t4;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t7,((C_word*)t0)[2]))){
/* pregexp.scm: 310  pregexp-error */
t8=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,lf[46]);}
else{
t8=t6;
f_2054(2,t8,C_SCHEME_UNDEFINED);}}

/* k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(C_word)C_subchar(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=((C_word*)t0)[6];
t4=(C_word)C_eqp(t3,C_fix(1));
if(C_truep(t4)){
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* pregexp.scm: 314  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2050(t7,((C_word*)t0)[3],t5,((C_word*)t0)[2],t6,C_fix(1));}
else{
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[2]);
t6=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* pregexp.scm: 315  loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2050(t7,((C_word*)t0)[3],((C_word*)t0)[5],t5,t6,C_fix(2));}}
else{
t3=(C_word)C_u_i_char_whitespacep(t2);
t4=(C_truep(t3)?(C_word)C_i_not(*((C_word*)lf[0]+1)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* pregexp.scm: 317  loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2050(t6,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[6]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2110,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t6)){
t7=((C_word*)t0)[6];
t8=t5;
f_2110(t8,(C_word)C_eqp(t7,C_fix(1)));}
else{
t7=t5;
f_2110(t7,C_SCHEME_FALSE);}}}}

/* k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void C_fcall f_2110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2110,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],C_fix(1));
/* pregexp.scm: 319  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2050(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t2,C_fix(2));}
else{
t2=(C_word)C_eqp(((C_word*)t0)[3],C_make_character(125));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2168,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2172,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 321  pregexp-reverse! */
f_674(t5,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k2170 in k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 321  list->string */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2166 in k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 321  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k2124 in k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2129,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2160,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2164,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 322  pregexp-reverse! */
f_674(t4,((C_word*)t0)[2]);}

/* k2162 in k2124 in k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 322  list->string */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2158 in k2124 in k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 322  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k2127 in k2124 in k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2135,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
if(C_truep(t3)){
t4=t2;
f_2135(t4,C_SCHEME_FALSE);}
else{
t4=((C_word*)t0)[3];
t5=t2;
f_2135(t5,(C_word)C_eqp(t4,C_fix(1)));}}

/* k2133 in k2127 in k2124 in k2108 in k2052 in loop in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void C_fcall f_2135(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2135,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,C_fix(0),C_SCHEME_FALSE,((C_word*)t0)[5]));}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_eqp(t2,C_fix(1));
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[3],((C_word*)t0)[5]):(C_word)C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5])));}}

/* k1980 in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=t1;
if(C_truep(t3)){
t4=t2;
f_1985(2,t4,C_SCHEME_UNDEFINED);}
else{
/* pregexp.scm: 281  pregexp-error */
t4=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[44],lf[45]);}}

/* k1983 in k1980 in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=(C_word)C_u_i_cddr(((C_word*)t0)[5]);
t3=(C_word)C_u_i_car(((C_word*)t0)[4]);
t4=(C_word)C_i_setslot(t2,C_fix(0),t3);
t5=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
t6=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t7=(C_word)C_i_setslot(t5,C_fix(0),t6);
t8=(C_word)C_u_i_caddr(((C_word*)t0)[4]);
t9=C_mutate(((C_word *)((C_word*)t0)[3])+1,t8);
t10=((C_word*)t0)[2];
f_1826(t10,t9);}

/* k1824 in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static void C_fcall f_1826(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1826,NULL,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1835,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=f_1835(t3,t2);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}

/* loop in k1824 in k1815 in loop in pregexp-wrap-quantifier-if-any in k669 */
static C_word C_fcall f_1835(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
loop:
t2=t1;
t3=((C_word*)t0)[5];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=(C_word)C_i_set_i_slot(t4,C_fix(0),C_SCHEME_FALSE);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
return((C_word)C_i_setslot(t6,C_fix(0),t1));}
else{
t4=(C_word)C_subchar(((C_word*)t0)[2],t1);
t5=(C_word)C_u_i_char_whitespacep(t4);
t6=(C_truep(t5)?(C_word)C_i_not(*((C_word*)lf[0]+1)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(C_word)C_u_fixnum_plus(t1,C_fix(1));
t20=t7;
t1=t20;
goto loop;}
else{
t7=(C_word)C_eqp(t4,C_make_character(63));
if(C_truep(t7)){
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t9=(C_word)C_i_set_i_slot(t8,C_fix(0),C_SCHEME_TRUE);
t10=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t11=(C_word)C_u_fixnum_plus(t1,C_fix(1));
return((C_word)C_i_setslot(t10,C_fix(0),t11));}
else{
t8=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t9=(C_word)C_i_set_i_slot(t8,C_fix(0),C_SCHEME_FALSE);
t10=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
return((C_word)C_i_setslot(t10,C_fix(0),t1));}}}}

/* pregexp-read-escaped-char in k669 */
static C_word C_fcall f_1223(C_word *a,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=(C_word)C_subchar(t1,t5);
switch(t6){
case C_make_character(98):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[31],t7));
case C_make_character(66):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[32],t7));
case C_make_character(100):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[33],t7));
case C_make_character(68):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[34],t7));
case C_make_character(110):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,C_make_character(10),t7));
case C_make_character(114):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,C_make_character(13),t7));
case C_make_character(115):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[35],t7));
case C_make_character(83):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[36],t7));
case C_make_character(116):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,C_make_character(9),t7));
case C_make_character(119):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[37],t7));
case C_make_character(87):
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,lf[38],t7));
default:
t7=(C_word)C_u_fixnum_plus(t2,C_fix(2));
return((C_word)C_a_i_list(&a,2,t6,t7));}}
else{
return(C_SCHEME_FALSE);}}

/* pregexp-read-escaped-number in k669 */
static void C_fcall f_1127(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1127,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=t4;
if(C_truep((C_word)C_fixnum_lessp(t5,t6))){
t7=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
if(C_truep((C_word)C_u_i_char_numericp(t8))){
t9=(C_word)C_u_fixnum_plus(t3,C_fix(2));
t10=(C_word)C_a_i_list(&a,1,t8);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1156,a[2]=t12,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_1156(t14,t1,t9,t10);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}

/* loop in pregexp-read-escaped-number in k669 */
static void C_fcall f_1156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(23);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1156,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[4];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1170,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1178,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 153  pregexp-reverse! */
f_674(t8,t3);}
else{
t6=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_word)C_u_i_char_numericp(t6))){
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=(C_word)C_a_i_cons(&a,2,t6,t3);
/* pregexp.scm: 156  loop */
t16=t1;
t17=t7;
t18=t8;
t1=t16;
t2=t17;
t3=t18;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1205,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1209,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1213,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* pregexp.scm: 158  pregexp-reverse! */
f_674(t9,t3);}}}

/* k1211 in loop in pregexp-read-escaped-number in k669 */
static void f_1213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 158  list->string */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1207 in loop in pregexp-read-escaped-number in k669 */
static void f_1209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 157  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1203 in loop in pregexp-read-escaped-number in k669 */
static void f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* k1176 in loop in pregexp-read-escaped-number in k669 */
static void f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 153  list->string */
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1172 in loop in pregexp-read-escaped-number in k669 */
static void f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 152  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k1168 in loop in pregexp-read-escaped-number in k669 */
static void f_1170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1170,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[2]));}

/* pregexp-read-pattern in k669 */
static void C_fcall f_704(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_704,NULL,4,t1,t2,t3,t4);}
t5=t3;
t6=t4;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t5,t6))){
t7=(C_word)C_a_i_list(&a,1,lf[6]);
t8=(C_word)C_a_i_list(&a,2,lf[7],t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_list(&a,2,t8,t3));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_727,a[2]=t2,a[3]=t8,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_727(t10,t1,C_SCHEME_END_OF_LIST,t3);}}

/* loop in pregexp-read-pattern in k669 */
static void C_fcall f_727(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_727,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=((C_word*)t0)[4];
t6=(C_word)C_fixnum_greater_or_equal_p(t4,t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_737,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t3,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_737(t8,t6);}
else{
t8=(C_word)C_subchar(((C_word*)t0)[2],t3);
t9=t7;
f_737(t9,(C_word)C_eqp(t8,C_make_character(41)));}}

/* k735 in loop in pregexp-read-pattern in k669 */
static void C_fcall f_737(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_737,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_748,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 80   pregexp-reverse! */
f_674(t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_751,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]);
t4=(C_word)C_eqp(t3,C_make_character(124));
t5=(C_truep(t4)?(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1)):((C_word*)t0)[6]);
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[2];
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_795,a[2]=t9,a[3]=t6,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_795(t11,t2,C_SCHEME_END_OF_LIST,t5);}}

/* loop in k735 in loop in pregexp-read-pattern in k669 */
static void C_fcall f_795(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word ab[103],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_795,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[4]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_813,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 90   pregexp-reverse! */
f_674(t5,t2);}
else{
t5=(C_word)C_subchar(((C_word*)t0)[3],t3);
t6=(C_word)C_eqp(t5,C_make_character(124));
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,C_make_character(41)));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_836,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* pregexp.scm: 94   pregexp-reverse! */
f_674(t8,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_839,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=t3;
t10=(C_word)C_subchar(((C_word*)t0)[3],t9);
switch(t10){
case C_make_character(94):
t11=(C_word)C_u_fixnum_plus(t9,C_fix(1));
t12=t8;
f_839(2,t12,(C_word)C_a_i_list(&a,2,lf[8],t11));
case C_make_character(36):
t11=(C_word)C_u_fixnum_plus(t9,C_fix(1));
t12=t8;
f_839(2,t12,(C_word)C_a_i_list(&a,2,lf[9],t11));
case C_make_character(46):
t11=(C_word)C_u_fixnum_plus(t9,C_fix(1));
t12=(C_word)C_a_i_list(&a,2,lf[10],t11);
/* pregexp.scm: 104  pregexp-wrap-quantifier-if-any */
f_1772(t8,t12,((C_word*)t0)[3],((C_word*)t0)[4]);
case C_make_character(91):
t11=(C_word)C_u_fixnum_plus(t9,C_fix(1));
t12=(C_word)C_subchar(((C_word*)t0)[3],t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_922,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_eqp(t12,C_make_character(94));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_928,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t16=(C_word)C_u_fixnum_plus(t9,C_fix(2));
/* pregexp.scm: 109  pregexp-read-char-list */
f_2202(t15,((C_word*)t0)[3],t16,((C_word*)t0)[4]);}
else{
t15=(C_word)C_u_fixnum_plus(t9,C_fix(1));
/* pregexp.scm: 111  pregexp-read-char-list */
f_2202(t13,((C_word*)t0)[3],t15,((C_word*)t0)[4]);}
case C_make_character(40):
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_u_fixnum_plus(t9,C_fix(1));
t13=*((C_word*)lf[0]+1);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t11,a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_subchar(((C_word*)t0)[3],t12);
t16=(C_word)C_eqp(t15,C_make_character(63));
if(C_truep(t16)){
t17=(C_word)C_u_fixnum_plus(t12,C_fix(1));
t18=(C_word)C_subchar(((C_word*)t0)[3],t17);
switch(t18){
case C_make_character(58):
t19=(C_word)C_u_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1700(2,t20,(C_word)C_a_i_list(&a,2,C_SCHEME_END_OF_LIST,t19));
case C_make_character(61):
t19=(C_word)C_u_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1700(2,t20,(C_word)C_a_i_list(&a,2,lf[15],t19));
case C_make_character(33):
t19=(C_word)C_u_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1700(2,t20,(C_word)C_a_i_list(&a,2,lf[16],t19));
case C_make_character(62):
t19=(C_word)C_u_fixnum_plus(t17,C_fix(1));
t20=t14;
f_1700(2,t20,(C_word)C_a_i_list(&a,2,lf[17],t19));
case C_make_character(60):
t19=(C_word)C_u_fixnum_plus(t17,C_fix(1));
t20=(C_word)C_subchar(((C_word*)t0)[3],t19);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1598,a[2]=t14,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
switch(t20){
case C_make_character(61):
t22=t21;
f_1598(2,t22,lf[18]);
case C_make_character(33):
t22=t21;
f_1598(2,t22,lf[19]);
default:
/* pregexp.scm: 222  pregexp-error */
t22=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t22+1)))(3,t22,t21,lf[20]);}
default:
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1623,a[2]=t20,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t22=((C_word*)t20)[1];
f_1623(t22,t14,t17,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}}
else{
t17=t14;
f_1700(2,t17,(C_word)C_a_i_list(&a,2,lf[23],t12));}
case C_make_character(92):
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_988,a[2]=t9,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* pregexp.scm: 118  pregexp-read-escaped-number */
f_1127(t11,((C_word*)t0)[3],t9,((C_word*)t0)[4]);
default:
t11=*((C_word*)lf[0]+1);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t10,a[6]=t9,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t11)){
t13=t12;
f_1032(t13,t11);}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t10))){
t13=t12;
f_1032(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(t10,C_make_character(35));
t14=t12;
f_1032(t14,(C_word)C_i_not(t13));}}}}}}

/* k1030 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void C_fcall f_1032(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1032,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t2);
/* pregexp.scm: 130  pregexp-wrap-quantifier-if-any */
f_1772(((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1048,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1048(t5,((C_word*)t0)[4],((C_word*)t0)[6],C_SCHEME_FALSE);}}

/* loop in k1030 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void C_fcall f_1048(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(12);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1048,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[4]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,2,lf[29],t2));}
else{
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(C_word)C_eqp(t5,C_make_character(10));
t8=(C_word)C_i_not(t7);
/* pregexp.scm: 136  loop */
t13=t1;
t14=t6;
t15=t8;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
if(C_truep((C_word)C_u_i_char_whitespacep(t5))){
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 139  loop */
t13=t1;
t14=t6;
t15=C_SCHEME_FALSE;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t6=(C_word)C_eqp(t5,C_make_character(35));
if(C_truep(t6)){
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 141  loop */
t13=t1;
t14=t7;
t15=C_SCHEME_TRUE;
t1=t13;
t2=t14;
t3=t15;
goto loop;}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,lf[29],t2));}}}}}

/* k986 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[95],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,lf[24],t3);
t5=(C_word)C_u_i_cadr(t1);
t6=t2;
f_991(2,t6,(C_word)C_a_i_list(&a,2,t4,t5));}
else{
t3=f_1223(C_a_i(&a,72),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=(C_word)C_u_i_car(t3);
t5=(C_word)C_u_i_cadr(t3);
t6=t2;
f_991(2,t6,(C_word)C_a_i_list(&a,2,t4,t5));}
else{
/* pregexp.scm: 124  pregexp-error */
t4=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[26],lf[27]);}}}

/* k989 in k986 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 117  pregexp-wrap-quantifier-if-any */
f_1772(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in loop in k735 in loop in pregexp-read-pattern in k669 */
static void C_fcall f_1623(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1623,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_subchar(((C_word*)t0)[3],t2);
switch(t5){
case C_make_character(45):
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 227  loop */
t14=t1;
t15=t6;
t16=t3;
t17=C_SCHEME_TRUE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;
case C_make_character(105):
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=(C_truep(t4)?lf[21]:lf[22]);
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
/* pregexp.scm: 228  loop */
t14=t1;
t15=t6;
t16=t8;
t17=C_SCHEME_FALSE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;
case C_make_character(120):
t6=C_mutate((C_word*)lf[0]+1,t4);
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* pregexp.scm: 233  loop */
t14=t1;
t15=t7;
t16=t3;
t17=C_SCHEME_FALSE;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;
case C_make_character(58):
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_list(&a,2,t3,t6));
default:
/* pregexp.scm: 235  pregexp-error */
t6=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,lf[20]);}}

/* k1596 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(2));
t3=((C_word*)t0)[2];
f_1700(2,t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k1698 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_1700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1700,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* pregexp.scm: 244  pregexp-read-pattern */
f_704(t4,((C_word*)t0)[2],t3,((C_word*)t0)[3]);}

/* k1707 in k1698 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1709,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1,((C_word*)t0)[6]);
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_u_i_cadr(t1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1722,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,((C_word*)t0)[3]))){
t6=(C_word)C_subchar(((C_word*)t0)[2],t4);
t7=t5;
f_1722(t7,(C_word)C_eqp(t6,C_make_character(41)));}
else{
t6=t5;
f_1722(t6,C_SCHEME_FALSE);}}

/* k1720 in k1707 in k1698 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void C_fcall f_1722(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1722,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1729,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1735,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1735(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* pregexp.scm: 257  pregexp-error */
t2=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],lf[14]);}}

/* loop in k1720 in k1707 in k1698 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void C_fcall f_1735(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1735,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
/* pregexp.scm: 254  loop */
t8=t1;
t9=t4;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* k1727 in k1720 in k1707 in k1698 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_1729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1729,2,t0,t1);}
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)t0)[2];
f_971(2,t3,(C_word)C_a_i_list(&a,2,t1,t2));}

/* k969 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 114  pregexp-wrap-quantifier-if-any */
f_1772(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k926 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_928,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_a_i_list(&a,2,lf[12],t2);
t4=(C_word)C_u_i_cadr(t1);
t5=((C_word*)t0)[2];
f_922(2,t5,(C_word)C_a_i_list(&a,2,t3,t4));}

/* k920 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* pregexp.scm: 106  pregexp-wrap-quantifier-if-any */
f_1772(((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k837 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_839,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=(C_word)C_u_i_cadr(t1);
/* pregexp.scm: 96   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_795(t5,((C_word*)t0)[2],t3,t4);}

/* k834 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[6],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k811 in loop in k735 in loop in pregexp-read-pattern in k669 */
static void f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_813,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[6],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* k749 in k735 in loop in pregexp-read-pattern in k669 */
static void f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_751,2,t0,t1);}
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=(C_word)C_u_i_cadr(t1);
/* pregexp.scm: 84   loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_727(t5,((C_word*)t0)[2],t3,t4);}

/* k746 in k735 in loop in pregexp-read-pattern in k669 */
static void f_748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_748,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[7],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,t2,((C_word*)t0)[2]));}

/* pregexp-error in k669 */
static void f_698(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_698r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_698r(t0,t1,t2);}}

static void f_698r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[3]+1),lf[4],t2);}

/* pregexp-reverse! in k669 */
static void C_fcall f_674(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_674,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_680,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_680(t2,C_SCHEME_END_OF_LIST));}

/* loop in pregexp-reverse! in k669 */
static C_word C_fcall f_680(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_i_setslot(t1,C_fix(1),t2);
t6=t3;
t7=t1;
t1=t6;
t2=t7;
goto loop;}}
/* end of file */
