/* Generated from eval.scm by the Chicken compiler
   2005-09-24 22:19
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: eval.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file ueval.c -explicit-use
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_LIB_HOME
# define C_INSTALL_LIB_HOME    "."
#endif

#define C_METHOD_CACHE_SIZE 8

#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();


static C_TLS C_word lf[501];


C_externexport void C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1574(C_word c,C_word t0,C_word t1) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1) C_noret;
static void f_10318(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_10318r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_10322(C_word t0,C_word t1) C_noret;
static void f_10343(C_word c,C_word t0,C_word t1) C_noret;
static void f_10337(C_word c,C_word t0,C_word t1) C_noret;
static void f_10330(C_word c,C_word t0,C_word t1) C_noret;
static void f_10328(C_word c,C_word t0,C_word t1) C_noret;
static void f_5624(C_word c,C_word t0,C_word t1) C_noret;
static void f_5723(C_word c,C_word t0,C_word t1) C_noret;
static void f_5802(C_word c,C_word t0,C_word t1) C_noret;
static void f_10312(C_word c,C_word t0,C_word t1) C_noret;
static void f_10308(C_word c,C_word t0,C_word t1) C_noret;
static void f_10304(C_word c,C_word t0,C_word t1) C_noret;
static void f_10300(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10290(C_word t0,C_word t1) C_noret;
static void C_fcall f_6309(C_word t0,C_word t1) C_noret;
static void f_10275(C_word c,C_word t0,C_word t1) C_noret;
static void f_10271(C_word c,C_word t0,C_word t1) C_noret;
static void f_10267(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10257(C_word t0,C_word t1) C_noret;
static void C_fcall f_6313(C_word t0,C_word t1) C_noret;
static void f_6317(C_word c,C_word t0,C_word t1) C_noret;
static void f_10236(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6320(C_word t0,C_word t1) C_noret;
static void f_10226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_10221(C_word c,C_word t0,C_word t1) C_noret;
static void f_10223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6324(C_word c,C_word t0,C_word t1) C_noret;
static void f_10205(C_word c,C_word t0,C_word t1) C_noret;
static void f_10211(C_word c,C_word t0,C_word t1) C_noret;
static void f_10208(C_word c,C_word t0,C_word t1) C_noret;
static void f_6662(C_word c,C_word t0,C_word t1) C_noret;
static void f_10154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_10168(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10201(C_word c,C_word t0,C_word t1) C_noret;
static void f_10197(C_word c,C_word t0,C_word t1) C_noret;
static void f_10185(C_word c,C_word t0,C_word t1) C_noret;
static void f_10189(C_word c,C_word t0,C_word t1) C_noret;
static void f_10162(C_word c,C_word t0,C_word t1) C_noret;
static void f_7292(C_word c,C_word t0,C_word t1) C_noret;
static void f_10063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_10070(C_word t0,C_word t1) C_noret;
static void f_10079(C_word c,C_word t0,C_word t1) C_noret;
static void f_10098(C_word c,C_word t0,C_word t1) C_noret;
static void f_10102(C_word c,C_word t0,C_word t1) C_noret;
static void f_10088(C_word c,C_word t0,C_word t1) C_noret;
static void f_10085(C_word c,C_word t0,C_word t1) C_noret;
static void f_7295(C_word c,C_word t0,C_word t1) C_noret;
static void f_7353(C_word c,C_word t0,C_word t1) C_noret;
static void f_10061(C_word c,C_word t0,C_word t1) C_noret;
static void f_7536(C_word c,C_word t0,C_word t1) C_noret;
static void f_7540(C_word c,C_word t0,C_word t1) C_noret;
static void f_10057(C_word c,C_word t0,C_word t1) C_noret;
static void f_7543(C_word c,C_word t0,C_word t1) C_noret;
static void f_9963(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9969(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9985(C_word c,C_word t0,C_word t1) C_noret;
static void f_9988(C_word c,C_word t0,C_word t1) C_noret;
static void f_10023(C_word c,C_word t0,C_word t1) C_noret;
static void f_10026(C_word c,C_word t0,C_word t1) C_noret;
static void f_10041(C_word c,C_word t0,C_word t1) C_noret;
static void f_10037(C_word c,C_word t0,C_word t1) C_noret;
static void f_10010(C_word c,C_word t0,C_word t1) C_noret;
static void f_10013(C_word c,C_word t0,C_word t1) C_noret;
static void f_10020(C_word c,C_word t0,C_word t1) C_noret;
static void f_8232(C_word c,C_word t0,C_word t1) C_noret;
static void f_9935(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9961(C_word c,C_word t0,C_word t1) C_noret;
static void f_8235(C_word c,C_word t0,C_word t1) C_noret;
static void f_9892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9914(C_word c,C_word t0,C_word t1) C_noret;
static void f_9929(C_word c,C_word t0,C_word t1) C_noret;
static void f_8238(C_word c,C_word t0,C_word t1) C_noret;
static void f_9751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9757(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9773(C_word c,C_word t0,C_word t1) C_noret;
static void f_9862(C_word c,C_word t0,C_word t1) C_noret;
static void f_9866(C_word c,C_word t0,C_word t1) C_noret;
static void f_9812(C_word c,C_word t0,C_word t1) C_noret;
static void f_9831(C_word c,C_word t0,C_word t1) C_noret;
static void f_9803(C_word c,C_word t0,C_word t1) C_noret;
static void f_8241(C_word c,C_word t0,C_word t1) C_noret;
static void f_9648(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9658(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9671(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9687(C_word c,C_word t0,C_word t1) C_noret;
static void f_9725(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9723(C_word c,C_word t0,C_word t1) C_noret;
static void f_9707(C_word c,C_word t0,C_word t1) C_noret;
static void f_9711(C_word c,C_word t0,C_word t1) C_noret;
static void f_9715(C_word c,C_word t0,C_word t1) C_noret;
static void f_9669(C_word c,C_word t0,C_word t1) C_noret;
static void f_8244(C_word c,C_word t0,C_word t1) C_noret;
static void f_9595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9605(C_word c,C_word t0,C_word t1) C_noret;
static void f_9608(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9613(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9638(C_word c,C_word t0,C_word t1) C_noret;
static void f_9627(C_word c,C_word t0,C_word t1) C_noret;
static void f_8247(C_word c,C_word t0,C_word t1) C_noret;
static void f_9525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9535(C_word c,C_word t0,C_word t1) C_noret;
static void f_9538(C_word c,C_word t0,C_word t1) C_noret;
static void f_9585(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9549(C_word c,C_word t0,C_word t1) C_noret;
static void f_9571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9557(C_word c,C_word t0,C_word t1) C_noret;
static void f_9569(C_word c,C_word t0,C_word t1) C_noret;
static void f_9565(C_word c,C_word t0,C_word t1) C_noret;
static void f_9553(C_word c,C_word t0,C_word t1) C_noret;
static void f_9545(C_word c,C_word t0,C_word t1) C_noret;
static void f_8250(C_word c,C_word t0,C_word t1) C_noret;
static void f_9406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_9406r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_9410(C_word c,C_word t0,C_word t1) C_noret;
static void f_9413(C_word c,C_word t0,C_word t1) C_noret;
static void f_9416(C_word c,C_word t0,C_word t1) C_noret;
static void f_9507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9423(C_word c,C_word t0,C_word t1) C_noret;
static void f_9438(C_word c,C_word t0,C_word t1) C_noret;
static void f_9499(C_word c,C_word t0,C_word t1) C_noret;
static void f_9446(C_word c,C_word t0,C_word t1) C_noret;
static void f_9460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9458(C_word c,C_word t0,C_word t1) C_noret;
static void f_9454(C_word c,C_word t0,C_word t1) C_noret;
static void f_9450(C_word c,C_word t0,C_word t1) C_noret;
static void f_8253(C_word c,C_word t0,C_word t1) C_noret;
static void f_9114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9324(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9328(C_word c,C_word t0,C_word t1) C_noret;
static void f_9349(C_word c,C_word t0,C_word t1) C_noret;
static void f_9391(C_word c,C_word t0,C_word t1) C_noret;
static void f_9372(C_word c,C_word t0,C_word t1) C_noret;
static void f_9368(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9127(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9315(C_word c,C_word t0,C_word t1) C_noret;
static void f_9319(C_word c,C_word t0,C_word t1) C_noret;
static void f_9298(C_word c,C_word t0,C_word t1) C_noret;
static void f_9302(C_word c,C_word t0,C_word t1) C_noret;
static void f_9287(C_word c,C_word t0,C_word t1) C_noret;
static void f_9279(C_word c,C_word t0,C_word t1) C_noret;
static void f_9268(C_word c,C_word t0,C_word t1) C_noret;
static void f_9234(C_word c,C_word t0,C_word t1) C_noret;
static void f_9215(C_word c,C_word t0,C_word t1) C_noret;
static void f_9188(C_word c,C_word t0,C_word t1) C_noret;
static void f_9145(C_word c,C_word t0,C_word t1) C_noret;
static void f_9141(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9117(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9125(C_word c,C_word t0,C_word t1) C_noret;
static void f_8256(C_word c,C_word t0,C_word t1) C_noret;
static void f_9104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8259(C_word c,C_word t0,C_word t1) C_noret;
static void f_8263(C_word c,C_word t0,C_word t1) C_noret;
static void f_9101(C_word c,C_word t0,C_word t1) C_noret;
static void f_8279(C_word c,C_word t0,C_word t1) C_noret;
static void f_8504(C_word c,C_word t0,C_word t1) C_noret;
static void f_8976(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_8976r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_9077(C_word c,C_word t0,C_word t1) C_noret;
static void f_9080(C_word c,C_word t0,C_word t1) C_noret;
static void f_9095(C_word c,C_word t0,C_word t1) C_noret;
static void f_9091(C_word c,C_word t0,C_word t1) C_noret;
static void f_9067(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8979(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8983(C_word t0,C_word t1) C_noret;
static void f_9009(C_word c,C_word t0,C_word t1) C_noret;
static void f_9005(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8994(C_word t0,C_word t1) C_noret;
static void f_8587(C_word c,C_word t0,C_word t1) C_noret;
static void f_8957(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_8957r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_8961(C_word c,C_word t0,C_word t1) C_noret;
static void f_8970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8968(C_word c,C_word t0,C_word t1) C_noret;
static void f_8590(C_word c,C_word t0,C_word t1) C_noret;
static void f_8951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8593(C_word c,C_word t0,C_word t1) C_noret;
static void f_8945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8596(C_word c,C_word t0,C_word t1) C_noret;
static void f_8936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8943(C_word c,C_word t0,C_word t1) C_noret;
static void f_8926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8915(C_word c,C_word t0,C_word t1) C_noret;
static void f_8920(C_word c,C_word t0,C_word t1) C_noret;
static void f_8924(C_word c,C_word t0,C_word t1) C_noret;
static void f_8889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8893(C_word c,C_word t0,C_word t1) C_noret;
static void f_8898(C_word c,C_word t0,C_word t1) C_noret;
static void f_8902(C_word c,C_word t0,C_word t1) C_noret;
static void f_8909(C_word c,C_word t0,C_word t1) C_noret;
static void f_8863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_8869(C_word c,C_word t0,C_word t1) C_noret;
static void f_8873(C_word c,C_word t0,C_word t1) C_noret;
static void f_8887(C_word c,C_word t0,C_word t1) C_noret;
static void f_8876(C_word c,C_word t0,C_word t1) C_noret;
static void f_8883(C_word c,C_word t0,C_word t1) C_noret;
static void f_8847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8853(C_word c,C_word t0,C_word t1) C_noret;
static void f_8861(C_word c,C_word t0,C_word t1) C_noret;
static void f_8810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8814(C_word c,C_word t0,C_word t1) C_noret;
static void f_8819(C_word c,C_word t0,C_word t1) C_noret;
static void f_8823(C_word c,C_word t0,C_word t1) C_noret;
static void f_8845(C_word c,C_word t0,C_word t1) C_noret;
static void f_8841(C_word c,C_word t0,C_word t1) C_noret;
static void f_8837(C_word c,C_word t0,C_word t1) C_noret;
static void f_8826(C_word c,C_word t0,C_word t1) C_noret;
static void f_8833(C_word c,C_word t0,C_word t1) C_noret;
static void f_8784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8790(C_word c,C_word t0,C_word t1) C_noret;
static void f_8794(C_word c,C_word t0,C_word t1) C_noret;
static void f_8808(C_word c,C_word t0,C_word t1) C_noret;
static void f_8797(C_word c,C_word t0,C_word t1) C_noret;
static void f_8804(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_8771(C_word t0,C_word t1,C_word t2);
static void f_8745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8749(C_word c,C_word t0,C_word t1) C_noret;
static void f_8754(C_word c,C_word t0,C_word t1) C_noret;
static void f_8758(C_word c,C_word t0,C_word t1) C_noret;
static void f_8769(C_word c,C_word t0,C_word t1) C_noret;
static void f_8765(C_word c,C_word t0,C_word t1) C_noret;
static void f_8729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8735(C_word c,C_word t0,C_word t1) C_noret;
static void f_8743(C_word c,C_word t0,C_word t1) C_noret;
static void f_8717(C_word c,C_word t0,C_word t1) C_noret;
static void f_8723(C_word c,C_word t0,C_word t1) C_noret;
static void f_8727(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8708(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8712(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8649(C_word t0,C_word t1) C_noret;
static void f_8659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8684(C_word c,C_word t0,C_word t1) C_noret;
static void f_8696(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_8696r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_8702(C_word c,C_word t0,C_word t1) C_noret;
static void f_8690(C_word c,C_word t0,C_word t1) C_noret;
static void f_8665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8671(C_word c,C_word t0,C_word t1) C_noret;
static void f_8675(C_word c,C_word t0,C_word t1) C_noret;
static void f_8678(C_word c,C_word t0,C_word t1) C_noret;
static void f_8682(C_word c,C_word t0,C_word t1) C_noret;
static void f_8657(C_word c,C_word t0,C_word t1) C_noret;
static void f_8623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8646(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8627(C_word t0,C_word t1) C_noret;
static void f_8635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8639(C_word c,C_word t0,C_word t1) C_noret;
static void f_8598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8621(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8602(C_word t0,C_word t1) C_noret;
static void f_8610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8614(C_word c,C_word t0,C_word t1) C_noret;
static void f_8512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8522(C_word c,C_word t0,C_word t1) C_noret;
static void f_8525(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8539(C_word t0,C_word t1) C_noret;
static void f_8557(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8526(C_word t0,C_word t1) C_noret;
static void f_8506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8297(C_word c,C_word t0,C_word t1) C_noret;
static void f_8344(C_word c,C_word t0,C_word t1) C_noret;
static void f_8347(C_word c,C_word t0,C_word t1) C_noret;
static void f_8493(C_word c,C_word t0,C_word t1) C_noret;
static void f_8497(C_word c,C_word t0,C_word t1) C_noret;
static void f_8410(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8416(C_word t0,C_word t1) C_noret;
static void f_8474(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8480(C_word c,C_word t0,C_word t1) C_noret;
static void f_8423(C_word c,C_word t0,C_word t1) C_noret;
static void f_8426(C_word c,C_word t0,C_word t1) C_noret;
static void f_8429(C_word c,C_word t0,C_word t1) C_noret;
static void f_8469(C_word c,C_word t0,C_word t1) C_noret;
static void f_8438(C_word c,C_word t0,C_word t1) C_noret;
static void f_8452(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_8452r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_8456(C_word c,C_word t0,C_word t1) C_noret;
static void f_8443(C_word c,C_word t0,C_word t1) C_noret;
static void f_8364(C_word c,C_word t0,C_word t1) C_noret;
static void f_8370(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_8370r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_8377(C_word c,C_word t0,C_word t1) C_noret;
static void f_8380(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8386(C_word t0,C_word t1) C_noret;
static void f_8395(C_word c,C_word t0,C_word t1) C_noret;
static void f_8389(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_8355(C_word t0);
static C_word C_fcall f_8349(C_word t0);
static void C_fcall f_8321(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8331(C_word t0,C_word t1) C_noret;
static void C_fcall f_8315(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8309(C_word c,C_word t0,C_word t1) C_noret;
static void f_8304(C_word c,C_word t0,C_word t1) C_noret;
static void f_8281(C_word c,C_word t0,C_word t1) C_noret;
static void f_8295(C_word c,C_word t0,C_word t1) C_noret;
static void f_8292(C_word c,C_word t0,C_word t1) C_noret;
static void f_8285(C_word c,C_word t0,C_word t1) C_noret;
static void f_8265(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8269(C_word c,C_word t0,C_word t1) C_noret;
static void f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_7840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_7977(C_word t0,C_word t1) C_noret;
static void C_fcall f_7982(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8200(C_word c,C_word t0,C_word t1) C_noret;
static void f_8181(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7998(C_word t0,C_word t1) C_noret;
static void C_fcall f_8003(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8022(C_word c,C_word t0,C_word t1) C_noret;
static void f_7948(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_7954(C_word t0);
static void f_7886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7890(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7898(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7921(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7850(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7855(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7859(C_word c,C_word t0,C_word t1) C_noret;
static void f_7884(C_word c,C_word t0,C_word t1) C_noret;
static void f_7873(C_word c,C_word t0,C_word t1) C_noret;
static void f_7877(C_word c,C_word t0,C_word t1) C_noret;
static void f_7866(C_word c,C_word t0,C_word t1) C_noret;
static void f_7804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7826(C_word c,C_word t0,C_word t1) C_noret;
static void f_7796(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_7796r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_7742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7746(C_word c,C_word t0,C_word t1) C_noret;
static void f_7749(C_word c,C_word t0,C_word t1) C_noret;
static void f_7752(C_word c,C_word t0,C_word t1) C_noret;
static void f_7755(C_word c,C_word t0,C_word t1) C_noret;
static void f_7758(C_word c,C_word t0,C_word t1) C_noret;
static void f_7761(C_word c,C_word t0,C_word t1) C_noret;
static void f_7764(C_word c,C_word t0,C_word t1) C_noret;
static void f_7767(C_word c,C_word t0,C_word t1) C_noret;
static void f_7770(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7721(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7725(C_word c,C_word t0,C_word t1) C_noret;
static void f_7728(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7697(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7703(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7713(C_word c,C_word t0,C_word t1) C_noret;
static void f_7566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_7566r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_7570(C_word t0,C_word t1) C_noret;
static void f_7624(C_word c,C_word t0,C_word t1) C_noret;
static void f_7679(C_word c,C_word t0,C_word t1) C_noret;
static void f_7634(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7636(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7668(C_word c,C_word t0,C_word t1) C_noret;
static void f_7660(C_word c,C_word t0,C_word t1) C_noret;
static void f_7646(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7572(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7588(C_word c,C_word t0,C_word t1) C_noret;
static void f_7594(C_word c,C_word t0,C_word t1) C_noret;
static void f_7585(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7547(C_word t0,C_word t1) C_noret;
static void f_7551(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7520(C_word t0,C_word t1) C_noret;
static void f_7522(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7526(C_word c,C_word t0,C_word t1) C_noret;
static void f_7485(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7485r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7489(C_word c,C_word t0,C_word t1) C_noret;
static void f_7496(C_word c,C_word t0,C_word t1) C_noret;
static void f_7444(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7444r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7474(C_word c,C_word t0,C_word t1) C_noret;
static void f_7461(C_word c,C_word t0,C_word t1) C_noret;
static void f_7441(C_word c,C_word t0,C_word t1) C_noret;
static void f_7360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7367(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7372(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7399(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7420(C_word c,C_word t0,C_word t1) C_noret;
static void f_7393(C_word c,C_word t0,C_word t1) C_noret;
static void f_7297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7301(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7329(C_word t0,C_word t1) C_noret;
static void f_7256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7285(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7132(C_word t0,C_word t1) C_noret;
static void f_7141(C_word c,C_word t0,C_word t1) C_noret;
static void f_7167(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7169(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7192(C_word c,C_word t0,C_word t1) C_noret;
static void f_7187(C_word c,C_word t0,C_word t1) C_noret;
static void f_7183(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6946(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6956(C_word c,C_word t0,C_word t1) C_noret;
static void f_7067(C_word c,C_word t0,C_word t1) C_noret;
static void f_7106(C_word c,C_word t0,C_word t1) C_noret;
static void f_7093(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7077(C_word t0,C_word t1) C_noret;
static void f_7057(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7035(C_word t0,C_word t1) C_noret;
static void f_7042(C_word c,C_word t0,C_word t1) C_noret;
static void f_7007(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7014(C_word t0,C_word t1) C_noret;
static void f_6968(C_word c,C_word t0,C_word t1) C_noret;
static void f_6992(C_word c,C_word t0,C_word t1) C_noret;
static void f_6988(C_word c,C_word t0,C_word t1) C_noret;
static void f_6980(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6971(C_word t0,C_word t1) C_noret;
static void C_fcall f_6925(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6940(C_word c,C_word t0,C_word t1) C_noret;
static void f_6934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6879(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6893(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6896(C_word t0,C_word t1) C_noret;
static void f_6903(C_word c,C_word t0,C_word t1) C_noret;
static void f_6867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6849(C_word c,C_word t0,C_word t1) C_noret;
static void f_6865(C_word c,C_word t0,C_word t1) C_noret;
static void f_6852(C_word c,C_word t0,C_word t1) C_noret;
static void f_6858(C_word c,C_word t0,C_word t1) C_noret;
static void f_6832(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6832r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_6838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6818(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6829(C_word c,C_word t0,C_word t1) C_noret;
static void f_6801(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6801r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_6807(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6811(C_word c,C_word t0,C_word t1) C_noret;
static void f_6742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_6742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_6746(C_word c,C_word t0,C_word t1) C_noret;
static void f_6764(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6780(C_word t0,C_word t1) C_noret;
static void f_6770(C_word c,C_word t0,C_word t1) C_noret;
static void f_6665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6739(C_word c,C_word t0,C_word t1) C_noret;
static void f_6732(C_word c,C_word t0,C_word t1) C_noret;
static void f_6699(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6701(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6714(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6668(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6672(C_word c,C_word t0,C_word t1) C_noret;
static void f_6692(C_word c,C_word t0,C_word t1) C_noret;
static void f_6678(C_word c,C_word t0,C_word t1) C_noret;
static void f_6688(C_word c,C_word t0,C_word t1) C_noret;
static void f_6681(C_word c,C_word t0,C_word t1) C_noret;
static void f_6514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6607(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6624(C_word c,C_word t0,C_word t1) C_noret;
static void f_6632(C_word c,C_word t0,C_word t1) C_noret;
static void f_6524(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6529(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6568(C_word c,C_word t0,C_word t1) C_noret;
static void f_6555(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6517(C_word t0,C_word t1) C_noret;
static void f_6458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6467(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6505(C_word c,C_word t0,C_word t1) C_noret;
static void f_6485(C_word c,C_word t0,C_word t1) C_noret;
static void f_6432(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6432r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6436(C_word c,C_word t0,C_word t1) C_noret;
static void f_6446(C_word c,C_word t0,C_word t1) C_noret;
static void f_6326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6330(C_word c,C_word t0,C_word t1) C_noret;
static void f_6422(C_word c,C_word t0,C_word t1) C_noret;
static void f_6426(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6339(C_word t0,C_word t1) C_noret;
static void f_6408(C_word c,C_word t0,C_word t1) C_noret;
static void f_6404(C_word c,C_word t0,C_word t1) C_noret;
static void f_6342(C_word c,C_word t0,C_word t1) C_noret;
static void f_6391(C_word c,C_word t0,C_word t1) C_noret;
static void f_6394(C_word c,C_word t0,C_word t1) C_noret;
static void f_6397(C_word c,C_word t0,C_word t1) C_noret;
static void f_6345(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6350(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6384(C_word c,C_word t0,C_word t1) C_noret;
static void f_6363(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6366(C_word t0,C_word t1) C_noret;
static void f_6267(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6267r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6304(C_word c,C_word t0,C_word t1) C_noret;
static void f_6271(C_word c,C_word t0,C_word t1) C_noret;
static void f_6301(C_word c,C_word t0,C_word t1) C_noret;
static void f_6274(C_word c,C_word t0,C_word t1) C_noret;
static void f_6298(C_word c,C_word t0,C_word t1) C_noret;
static void f_6277(C_word c,C_word t0,C_word t1) C_noret;
static void f_6293(C_word c,C_word t0,C_word t1) C_noret;
static void f_6287(C_word c,C_word t0,C_word t1) C_noret;
static void f_6282(C_word c,C_word t0,C_word t1) C_noret;
static void f_6225(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6225r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6262(C_word c,C_word t0,C_word t1) C_noret;
static void f_6236(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6244(C_word t0,C_word t1) C_noret;
static void f_6231(C_word c,C_word t0,C_word t1) C_noret;
static void f_5850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_5850r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_6180(C_word t0,C_word t1) C_noret;
static void C_fcall f_6175(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5852(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6174(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5856(C_word t0,C_word t1) C_noret;
static void f_6108(C_word c,C_word t0,C_word t1) C_noret;
static void f_6123(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6126(C_word t0,C_word t1) C_noret;
static void f_6129(C_word c,C_word t0,C_word t1) C_noret;
static void f_6135(C_word c,C_word t0,C_word t1) C_noret;
static void f_6138(C_word c,C_word t0,C_word t1) C_noret;
static void f_6144(C_word c,C_word t0,C_word t1) C_noret;
static void f_5859(C_word c,C_word t0,C_word t1) C_noret;
static void f_6086(C_word c,C_word t0,C_word t1) C_noret;
static void f_6077(C_word c,C_word t0,C_word t1) C_noret;
static void f_6080(C_word c,C_word t0,C_word t1) C_noret;
static void f_5865(C_word c,C_word t0,C_word t1) C_noret;
static void f_6062(C_word c,C_word t0,C_word t1) C_noret;
static void f_6034(C_word c,C_word t0,C_word t1) C_noret;
static void f_6054(C_word c,C_word t0,C_word t1) C_noret;
static void f_6050(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5814(C_word t0,C_word t1);
static void f_5868(C_word c,C_word t0,C_word t1) C_noret;
static void f_5876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6024(C_word c,C_word t0,C_word t1) C_noret;
static void f_5896(C_word c,C_word t0,C_word t1) C_noret;
static void f_5900(C_word c,C_word t0,C_word t1) C_noret;
static void f_6015(C_word c,C_word t0,C_word t1) C_noret;
static void f_5908(C_word c,C_word t0,C_word t1) C_noret;
static void f_5912(C_word c,C_word t0,C_word t1) C_noret;
static void f_6009(C_word c,C_word t0,C_word t1) C_noret;
static void f_5915(C_word c,C_word t0,C_word t1) C_noret;
static void f_5922(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5924(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5934(C_word c,C_word t0,C_word t1) C_noret;
static void f_5980(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_5980r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_5989(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5993(C_word c,C_word t0,C_word t1) C_noret;
static void f_5946(C_word c,C_word t0,C_word t1) C_noret;
static void f_5953(C_word c,C_word t0,C_word t1) C_noret;
static void f_5964(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_5964r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_5975(C_word c,C_word t0,C_word t1) C_noret;
static void f_5968(C_word c,C_word t0,C_word t1) C_noret;
static void f_5958(C_word c,C_word t0,C_word t1) C_noret;
static void f_5937(C_word c,C_word t0,C_word t1) C_noret;
static void f_5944(C_word c,C_word t0,C_word t1) C_noret;
static void f_5905(C_word c,C_word t0,C_word t1) C_noret;
static void f_5887(C_word c,C_word t0,C_word t1) C_noret;
static void f_5878(C_word c,C_word t0,C_word t1) C_noret;
static void f_5871(C_word c,C_word t0,C_word t1) C_noret;
static void f_6093(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6093r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6101(C_word c,C_word t0,C_word t1) C_noret;
static void f_6105(C_word c,C_word t0,C_word t1) C_noret;
static void f_5729(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5741(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5754(C_word c,C_word t0,C_word t1) C_noret;
static void f_5736(C_word c,C_word t0,C_word t1) C_noret;
static void f_5725(C_word c,C_word t0,C_word t1) C_noret;
static void f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5654(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5687(C_word c,C_word t0,C_word t1) C_noret;
static void f_5668(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5644(C_word t0,C_word t1) C_noret;
static void f_5627(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5627r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5635(C_word c,C_word t0,C_word t1) C_noret;
static void f_5639(C_word c,C_word t0,C_word t1) C_noret;
static void f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_5410(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5414(C_word c,C_word t0,C_word t1) C_noret;
static void f_5609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5588(C_word c,C_word t0,C_word t1) C_noret;
static void f_5589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5597(C_word c,C_word t0,C_word t1) C_noret;
static void f_5603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5601(C_word c,C_word t0,C_word t1) C_noret;
static void f_5548(C_word c,C_word t0,C_word t1) C_noret;
static void f_5551(C_word c,C_word t0,C_word t1) C_noret;
static void f_5554(C_word c,C_word t0,C_word t1) C_noret;
static void f_5557(C_word c,C_word t0,C_word t1) C_noret;
static void f_5558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5566(C_word c,C_word t0,C_word t1) C_noret;
static void f_5570(C_word c,C_word t0,C_word t1) C_noret;
static void f_5574(C_word c,C_word t0,C_word t1) C_noret;
static void f_5578(C_word c,C_word t0,C_word t1) C_noret;
static void f_5581(C_word c,C_word t0,C_word t1) C_noret;
static void f_5509(C_word c,C_word t0,C_word t1) C_noret;
static void f_5512(C_word c,C_word t0,C_word t1) C_noret;
static void f_5515(C_word c,C_word t0,C_word t1) C_noret;
static void f_5516(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5524(C_word c,C_word t0,C_word t1) C_noret;
static void f_5528(C_word c,C_word t0,C_word t1) C_noret;
static void f_5532(C_word c,C_word t0,C_word t1) C_noret;
static void f_5535(C_word c,C_word t0,C_word t1) C_noret;
static void f_5477(C_word c,C_word t0,C_word t1) C_noret;
static void f_5480(C_word c,C_word t0,C_word t1) C_noret;
static void f_5481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5489(C_word c,C_word t0,C_word t1) C_noret;
static void f_5493(C_word c,C_word t0,C_word t1) C_noret;
static void f_5496(C_word c,C_word t0,C_word t1) C_noret;
static void f_5452(C_word c,C_word t0,C_word t1) C_noret;
static void f_5453(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5461(C_word c,C_word t0,C_word t1) C_noret;
static void f_5464(C_word c,C_word t0,C_word t1) C_noret;
static void f_5436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5443(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5384(C_word t0,C_word t1);
static void C_fcall f_3748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_3818(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3874(C_word t0,C_word t1) C_noret;
static void f_3900(C_word c,C_word t0,C_word t1) C_noret;
static void f_3906(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5220(C_word t0,C_word t1) C_noret;
static void f_5207(C_word c,C_word t0,C_word t1) C_noret;
static void f_5203(C_word c,C_word t0,C_word t1) C_noret;
static void f_5199(C_word c,C_word t0,C_word t1) C_noret;
static void f_5168(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5157(C_word c,C_word t0,C_word t1) C_noret;
static void f_5119(C_word c,C_word t0,C_word t1) C_noret;
static void f_5113(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5067(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5097(C_word c,C_word t0,C_word t1) C_noret;
static void f_5079(C_word c,C_word t0,C_word t1) C_noret;
static void f_5061(C_word c,C_word t0,C_word t1) C_noret;
static void f_5037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5044(C_word c,C_word t0,C_word t1) C_noret;
static void f_5006(C_word c,C_word t0,C_word t1) C_noret;
static void f_5009(C_word c,C_word t0,C_word t1) C_noret;
static void f_5012(C_word c,C_word t0,C_word t1) C_noret;
static void f_5031(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5029(C_word c,C_word t0,C_word t1) C_noret;
static void f_5019(C_word c,C_word t0,C_word t1) C_noret;
static void f_4989(C_word c,C_word t0,C_word t1) C_noret;
static void f_4972(C_word c,C_word t0,C_word t1) C_noret;
static void f_4612(C_word c,C_word t0,C_word t1) C_noret;
static void f_4941(C_word c,C_word t0,C_word t1) C_noret;
static void f_4952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4946(C_word c,C_word t0,C_word t1) C_noret;
static void f_4624(C_word c,C_word t0,C_word t1) C_noret;
static void f_4629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4932(C_word c,C_word t0,C_word t1) C_noret;
static void f_4636(C_word c,C_word t0,C_word t1) C_noret;
static void f_4894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4900(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4900r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4924(C_word c,C_word t0,C_word t1) C_noret;
static void f_4920(C_word c,C_word t0,C_word t1) C_noret;
static void f_4871(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4877(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4877r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_5351(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4893(C_word c,C_word t0,C_word t1) C_noret;
static void f_4889(C_word c,C_word t0,C_word t1) C_noret;
static void f_4885(C_word c,C_word t0,C_word t1) C_noret;
static void f_4849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4867(C_word c,C_word t0,C_word t1) C_noret;
static void f_4863(C_word c,C_word t0,C_word t1) C_noret;
static void f_4830(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_4836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_4802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4783(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_4789r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_4755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4708(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4689(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4695(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4695r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4671(C_word c,C_word t0,C_word t1) C_noret;
static void f_4646(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4652(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4652r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4318(C_word c,C_word t0,C_word t1) C_noret;
static void f_4599(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4327(C_word c,C_word t0,C_word t1) C_noret;
static void f_4593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4587(C_word c,C_word t0,C_word t1) C_noret;
static void f_4333(C_word c,C_word t0,C_word t1) C_noret;
static void f_4575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4528(C_word c,C_word t0,C_word t1) C_noret;
static void f_4529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4533(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4570(C_word c,C_word t0,C_word t1) C_noret;
static void f_4536(C_word c,C_word t0,C_word t1) C_noret;
static void f_4468(C_word c,C_word t0,C_word t1) C_noret;
static void f_4521(C_word c,C_word t0,C_word t1) C_noret;
static void f_4471(C_word c,C_word t0,C_word t1) C_noret;
static void f_4477(C_word c,C_word t0,C_word t1) C_noret;
static void f_4513(C_word c,C_word t0,C_word t1) C_noret;
static void f_4480(C_word c,C_word t0,C_word t1) C_noret;
static void f_4481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4497(C_word c,C_word t0,C_word t1) C_noret;
static void f_4501(C_word c,C_word t0,C_word t1) C_noret;
static void f_4505(C_word c,C_word t0,C_word t1) C_noret;
static void f_4509(C_word c,C_word t0,C_word t1) C_noret;
static void f_4413(C_word c,C_word t0,C_word t1) C_noret;
static void f_4455(C_word c,C_word t0,C_word t1) C_noret;
static void f_4416(C_word c,C_word t0,C_word t1) C_noret;
static void f_4422(C_word c,C_word t0,C_word t1) C_noret;
static void f_4423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4439(C_word c,C_word t0,C_word t1) C_noret;
static void f_4443(C_word c,C_word t0,C_word t1) C_noret;
static void f_4447(C_word c,C_word t0,C_word t1) C_noret;
static void f_4372(C_word c,C_word t0,C_word t1) C_noret;
static void f_4400(C_word c,C_word t0,C_word t1) C_noret;
static void f_4375(C_word c,C_word t0,C_word t1) C_noret;
static void f_4376(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4392(C_word c,C_word t0,C_word t1) C_noret;
static void f_4396(C_word c,C_word t0,C_word t1) C_noret;
static void f_4342(C_word c,C_word t0,C_word t1) C_noret;
static void f_4343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4359(C_word c,C_word t0,C_word t1) C_noret;
static void f_4212(C_word c,C_word t0,C_word t1) C_noret;
static void f_4226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4230(C_word c,C_word t0,C_word t1) C_noret;
static void f_4269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4277(C_word c,C_word t0,C_word t1) C_noret;
static void f_4242(C_word c,C_word t0,C_word t1) C_noret;
static void f_4245(C_word c,C_word t0,C_word t1) C_noret;
static void f_4261(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4252(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4260(C_word c,C_word t0,C_word t1) C_noret;
static void f_4297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4305(C_word c,C_word t0,C_word t1) C_noret;
static void f_4284(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4296(C_word c,C_word t0,C_word t1) C_noret;
static void f_4220(C_word c,C_word t0,C_word t1) C_noret;
static void f_4104(C_word c,C_word t0,C_word t1) C_noret;
static void f_4163(C_word c,C_word t0,C_word t1) C_noret;
static void f_4166(C_word c,C_word t0,C_word t1) C_noret;
static void f_4184(C_word c,C_word t0,C_word t1) C_noret;
static void f_4169(C_word c,C_word t0,C_word t1) C_noret;
static void f_4170(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4174(C_word c,C_word t0,C_word t1) C_noret;
static void f_4177(C_word c,C_word t0,C_word t1) C_noret;
static void f_4141(C_word c,C_word t0,C_word t1) C_noret;
static void f_4144(C_word c,C_word t0,C_word t1) C_noret;
static void f_4145(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4149(C_word c,C_word t0,C_word t1) C_noret;
static void f_4047(C_word c,C_word t0,C_word t1) C_noret;
static void f_4050(C_word c,C_word t0,C_word t1) C_noret;
static void f_4053(C_word c,C_word t0,C_word t1) C_noret;
static void f_4056(C_word c,C_word t0,C_word t1) C_noret;
static void f_4057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4064(C_word c,C_word t0,C_word t1) C_noret;
static void f_4037(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4003(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3997(C_word c,C_word t0,C_word t1) C_noret;
static void f_3998(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3921(C_word c,C_word t0,C_word t1) C_noret;
static void f_3981(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3979(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3971(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3963(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3955(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3947(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3939(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3931(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3875(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3864(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3862(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3851(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3849(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3841(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3833(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3825(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3791(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3779(C_word c,C_word t0,C_word t1) C_noret;
static void f_3782(C_word c,C_word t0,C_word t1) C_noret;
static void f_3783(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3760(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3742(C_word c,C_word t0,C_word t1) C_noret;
static void f_3740(C_word c,C_word t0,C_word t1) C_noret;
static void f_3736(C_word c,C_word t0,C_word t1) C_noret;
static void f_3715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3660(C_word c,C_word t0,C_word t1) C_noret;
static void f_3707(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3675(C_word t0,C_word t1) C_noret;
static void C_fcall f_3684(C_word t0,C_word t1) C_noret;
static void C_fcall f_3544(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3550(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3502(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_3626(C_word t0,C_word t1,C_word t2);
static void f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3440(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3448(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3415(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3406(C_word c,C_word t0,C_word t1) C_noret;
static void f_3335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3339(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3347(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3294(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3303(C_word t0,C_word t1);
static void f_3275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3270(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3259(C_word c,C_word t0,C_word t1) C_noret;
static void f_3255(C_word c,C_word t0,C_word t1) C_noret;
static void f_3236(C_word c,C_word t0,C_word t1) C_noret;
static void f_3124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3213(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3127(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3182(C_word c,C_word t0,C_word t1) C_noret;
static void f_2673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2673r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_2677(C_word t0,C_word t1) C_noret;
static void C_fcall f_2859(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2865(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2899(C_word c,C_word t0,C_word t1) C_noret;
static void f_3071(C_word c,C_word t0,C_word t1) C_noret;
static void f_3057(C_word c,C_word t0,C_word t1) C_noret;
static void f_3064(C_word c,C_word t0,C_word t1) C_noret;
static void f_3029(C_word c,C_word t0,C_word t1) C_noret;
static void f_2911(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2916(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2929(C_word c,C_word t0,C_word t1) C_noret;
static void f_2981(C_word c,C_word t0,C_word t1) C_noret;
static void f_3000(C_word c,C_word t0,C_word t1) C_noret;
static void f_2996(C_word c,C_word t0,C_word t1) C_noret;
static void f_2963(C_word c,C_word t0,C_word t1) C_noret;
static void f_2974(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2761(C_word c,C_word t0,C_word t1) C_noret;
static void f_2851(C_word c,C_word t0,C_word t1) C_noret;
static void f_2839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2772(C_word c,C_word t0,C_word t1) C_noret;
static void f_2837(C_word c,C_word t0,C_word t1) C_noret;
static void f_2829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2780(C_word c,C_word t0,C_word t1) C_noret;
static void f_2823(C_word c,C_word t0,C_word t1) C_noret;
static void f_2827(C_word c,C_word t0,C_word t1) C_noret;
static void f_2790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2794(C_word c,C_word t0,C_word t1) C_noret;
static void f_2815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2813(C_word c,C_word t0,C_word t1) C_noret;
static void f_2809(C_word c,C_word t0,C_word t1) C_noret;
static void f_2805(C_word c,C_word t0,C_word t1) C_noret;
static void f_2788(C_word c,C_word t0,C_word t1) C_noret;
static void f_2784(C_word c,C_word t0,C_word t1) C_noret;
static void f_2776(C_word c,C_word t0,C_word t1) C_noret;
static void f_2768(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2710(C_word t0,C_word t1) C_noret;
static void f_2721(C_word c,C_word t0,C_word t1) C_noret;
static void f_2729(C_word c,C_word t0,C_word t1) C_noret;
static void f_2717(C_word c,C_word t0,C_word t1) C_noret;
static void f_2154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2176(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_2616(C_word t0,C_word t1) C_noret;
static void f_2554(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2535(C_word t0,C_word t1) C_noret;
static void C_fcall f_2489(C_word t0,C_word t1) C_noret;
static void C_fcall f_2492(C_word t0,C_word t1) C_noret;
static void f_2471(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2452(C_word t0,C_word t1) C_noret;
static void C_fcall f_2420(C_word t0,C_word t1) C_noret;
static void f_2399(C_word c,C_word t0,C_word t1) C_noret;
static void f_2190(C_word c,C_word t0,C_word t1) C_noret;
static void f_2392(C_word c,C_word t0,C_word t1) C_noret;
static void f_2335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2388(C_word c,C_word t0,C_word t1) C_noret;
static void f_2376(C_word c,C_word t0,C_word t1) C_noret;
static void f_2372(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2362(C_word t0,C_word t1) C_noret;
static void f_2358(C_word c,C_word t0,C_word t1) C_noret;
static void f_2350(C_word c,C_word t0,C_word t1) C_noret;
static void f_2346(C_word c,C_word t0,C_word t1) C_noret;
static void f_2333(C_word c,C_word t0,C_word t1) C_noret;
static void f_2329(C_word c,C_word t0,C_word t1) C_noret;
static void f_2325(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2194(C_word t0,C_word t1) C_noret;
static void C_fcall f_2206(C_word t0,C_word t1) C_noret;
static void f_2285(C_word c,C_word t0,C_word t1) C_noret;
static void f_2281(C_word c,C_word t0,C_word t1) C_noret;
static void f_2277(C_word c,C_word t0,C_word t1) C_noret;
static void f_2273(C_word c,C_word t0,C_word t1) C_noret;
static void f_2269(C_word c,C_word t0,C_word t1) C_noret;
static void f_2262(C_word c,C_word t0,C_word t1) C_noret;
static void f_2258(C_word c,C_word t0,C_word t1) C_noret;
static void f_2254(C_word c,C_word t0,C_word t1) C_noret;
static void f_2250(C_word c,C_word t0,C_word t1) C_noret;
static void f_2217(C_word c,C_word t0,C_word t1) C_noret;
static void f_2213(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2197(C_word t0,C_word t1) C_noret;
static void C_fcall f_2157(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2117(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2136(C_word t0,C_word t1) C_noret;
static void f_2040(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2044(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2076(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2102(C_word c,C_word t0,C_word t1) C_noret;
static void f_2070(C_word c,C_word t0,C_word t1) C_noret;
static void f_2023(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2023r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1987(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1987r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2002(C_word c,C_word t0,C_word t1) C_noret;
static void f_1981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1975(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1915(C_word t0,C_word t1) C_noret;
static void f_1921(C_word c,C_word t0,C_word t1) C_noret;
static void f_1928(C_word c,C_word t0,C_word t1) C_noret;
static void f_1842(C_word c,C_word t0,C_word t1) C_noret;
static void f_1854(C_word c,C_word t0,C_word t1) C_noret;
static void f_1902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1896(C_word c,C_word t0,C_word t1) C_noret;
static void f_1892(C_word c,C_word t0,C_word t1) C_noret;
static void f_1888(C_word c,C_word t0,C_word t1) C_noret;
static void f_1876(C_word c,C_word t0,C_word t1) C_noret;
static void f_1868(C_word c,C_word t0,C_word t1) C_noret;
static void f_1864(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1782(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1802(C_word c,C_word t0,C_word t1) C_noret;
static void f_1812(C_word c,C_word t0,C_word t1) C_noret;
static void f_1796(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1636(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1758(C_word c,C_word t0,C_word t1) C_noret;
static void f_1770(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1770r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1776(C_word c,C_word t0,C_word t1) C_noret;
static void f_1764(C_word c,C_word t0,C_word t1) C_noret;
static void f_1651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1657(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1668(C_word t0,C_word t1) C_noret;
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1704(C_word t0,C_word t1) C_noret;
static void f_1715(C_word c,C_word t0,C_word t1) C_noret;
static void f_1679(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1665(C_word t0,C_word t1) C_noret;
static void f_1643(C_word c,C_word t0,C_word t1) C_noret;
static void f_1627(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1619(C_word c,C_word t0,C_word t1) C_noret;
static void f_1596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x, *a=C_alloc(0+3);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_8926,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))));
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8911,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8889,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8863,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8847,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8810,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8784,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8745,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8729,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x, *a=C_alloc(0);
return C_truep(C_callback_wrapper((void *)f_8717,0));}

static void C_fcall trf_10322(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10322(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10322(t0,t1);}

static void C_fcall trf_10290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10290(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10290(t0,t1);}

static void C_fcall trf_6309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6309(t0,t1);}

static void C_fcall trf_10257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10257(t0,t1);}

static void C_fcall trf_6313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6313(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6313(t0,t1);}

static void C_fcall trf_6320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6320(t0,t1);}

static void C_fcall trf_10168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10168(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10168(t0,t1,t2);}

static void C_fcall trf_10070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10070(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10070(t0,t1);}

static void C_fcall trf_9969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9969(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9969(t0,t1,t2);}

static void C_fcall trf_9757(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9757(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9757(t0,t1,t2);}

static void C_fcall trf_9671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9671(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9671(t0,t1,t2);}

static void C_fcall trf_9613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9613(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9613(t0,t1,t2);}

static void C_fcall trf_9324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9324(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9324(t0,t1,t2);}

static void C_fcall trf_9127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9127(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9127(t0,t1,t2,t3);}

static void C_fcall trf_9117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9117(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9117(t0,t1,t2,t3);}

static void C_fcall trf_8979(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8979(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8979(t0,t1,t2);}

static void C_fcall trf_8983(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8983(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8983(t0,t1);}

static void C_fcall trf_8994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8994(t0,t1);}

static void C_fcall trf_8708(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8708(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8708(t0,t1,t2);}

static void C_fcall trf_8649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8649(t0,t1);}

static void C_fcall trf_8627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8627(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8627(t0,t1);}

static void C_fcall trf_8602(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8602(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8602(t0,t1);}

static void C_fcall trf_8539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8539(t0,t1);}

static void C_fcall trf_8526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8526(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8526(t0,t1);}

static void C_fcall trf_8416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8416(t0,t1);}

static void C_fcall trf_8386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8386(t0,t1);}

static void C_fcall trf_8321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8321(t0,t1,t2);}

static void C_fcall trf_8331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8331(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8331(t0,t1);}

static void C_fcall trf_8315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8315(t0,t1,t2);}

static void C_fcall trf_7977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7977(t0,t1);}

static void C_fcall trf_7982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7982(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7982(t0,t1,t2,t3);}

static void C_fcall trf_7998(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7998(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7998(t0,t1);}

static void C_fcall trf_8003(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8003(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8003(t0,t1,t2,t3);}

static void C_fcall trf_7898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7898(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7898(t0,t1,t2);}

static void C_fcall trf_7843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7843(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7843(t0,t1,t2,t3,t4);}

static void C_fcall trf_7855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7855(t0,t1,t2);}

static void C_fcall trf_7721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7721(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7721(t0,t1,t2,t3);}

static void C_fcall trf_7697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7697(t0,t1,t2);}

static void C_fcall trf_7703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7703(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7703(t0,t1,t2);}

static void C_fcall trf_7570(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7570(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7570(t0,t1);}

static void C_fcall trf_7636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7636(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7636(t0,t1,t2);}

static void C_fcall trf_7607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7607(t0,t1,t2);}

static void C_fcall trf_7572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7572(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7572(t0,t1,t2,t3);}

static void C_fcall trf_7547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7547(t0,t1);}

static void C_fcall trf_7520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7520(t0,t1);}

static void C_fcall trf_7372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7372(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7372(t0,t1,t2);}

static void C_fcall trf_7399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7399(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7399(t0,t1,t2);}

static void C_fcall trf_7309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7309(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7309(t0,t1,t2);}

static void C_fcall trf_7329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7329(t0,t1);}

static void C_fcall trf_7132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7132(t0,t1);}

static void C_fcall trf_7169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7169(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7169(t0,t1,t2,t3,t4);}

static void C_fcall trf_6946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6946(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6946(t0,t1,t2);}

static void C_fcall trf_7077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7077(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7077(t0,t1);}

static void C_fcall trf_7035(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7035(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7035(t0,t1);}

static void C_fcall trf_7014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7014(t0,t1);}

static void C_fcall trf_6971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6971(t0,t1);}

static void C_fcall trf_6925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6925(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6925(t0,t1,t2);}

static void C_fcall trf_6879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6879(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6879(t0,t1,t2);}

static void C_fcall trf_6896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6896(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6896(t0,t1);}

static void C_fcall trf_6780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6780(t0,t1);}

static void C_fcall trf_6701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6701(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6701(t0,t1,t2);}

static void C_fcall trf_6668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6668(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6668(t0,t1,t2);}

static void C_fcall trf_6607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6607(t0,t1,t2);}

static void C_fcall trf_6529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6529(t0,t1,t2);}

static void C_fcall trf_6517(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6517(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6517(t0,t1);}

static void C_fcall trf_6467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6467(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6467(t0,t1,t2,t3,t4);}

static void C_fcall trf_6339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6339(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6339(t0,t1);}

static void C_fcall trf_6350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6350(t0,t1,t2);}

static void C_fcall trf_6366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6366(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6366(t0,t1);}

static void C_fcall trf_6244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6244(t0,t1);}

static void C_fcall trf_6180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6180(t0,t1);}

static void C_fcall trf_6175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6175(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6175(t0,t1,t2);}

static void C_fcall trf_5852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5852(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5852(t0,t1,t2,t3);}

static void C_fcall trf_5856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5856(t0,t1);}

static void C_fcall trf_6126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6126(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6126(t0,t1);}

static void C_fcall trf_5924(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5924(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5924(t0,t1,t2);}

static void C_fcall trf_5741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5741(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5741(t0,t1,t2);}

static void C_fcall trf_5654(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5654(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5654(t0,t1,t2,t3,t4);}

static void C_fcall trf_5644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5644(t0,t1);}

static void C_fcall trf_5410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5410(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5410(t0,t1,t2,t3,t4);}

static void C_fcall trf_3748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3748(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3748(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_3874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3874(t0,t1);}

static void C_fcall trf_5220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5220(t0,t1);}

static void C_fcall trf_5067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5067(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5067(t0,t1,t2);}

static void C_fcall trf_5351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5351(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5351(t0,t1,t2,t3,t4);}

static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4545(t0,t1,t2,t3);}

static void C_fcall trf_3709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3709(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3709(t0,t1,t2,t3);}

static void C_fcall trf_3656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3656(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3656(t0,t1,t2,t3,t4);}

static void C_fcall trf_3675(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3675(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3675(t0,t1);}

static void C_fcall trf_3684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3684(t0,t1);}

static void C_fcall trf_3544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3544(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3544(t0,t1,t2,t3);}

static void C_fcall trf_3502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3502(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3502(t0,t1,t2);}

static void C_fcall trf_3508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3508(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3508(t0,t1,t2,t3);}

static void C_fcall trf_3448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3448(t0,t1,t2);}

static void C_fcall trf_3396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3396(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3396(t0,t1,t2);}

static void C_fcall trf_3347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3347(t0,t1,t2);}

static void C_fcall trf_3218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3218(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3218(t0,t1,t2,t3);}

static void C_fcall trf_3127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3127(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3127(t0,t1,t2,t3);}

static void C_fcall trf_2677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2677(t0,t1);}

static void C_fcall trf_2859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2859(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2859(t0,t1,t2);}

static void C_fcall trf_2865(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2865(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2865(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2916(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2916(t0,t1,t2);}

static void C_fcall trf_2679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2679(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2679(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2691(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2691(t0,t1,t2,t3);}

static void C_fcall trf_2710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2710(t0,t1);}

static void C_fcall trf_2176(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2176(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2176(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2616(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2616(t0,t1);}

static void C_fcall trf_2535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2535(t0,t1);}

static void C_fcall trf_2489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2489(t0,t1);}

static void C_fcall trf_2492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2492(t0,t1);}

static void C_fcall trf_2452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2452(t0,t1);}

static void C_fcall trf_2420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2420(t0,t1);}

static void C_fcall trf_2362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2362(t0,t1);}

static void C_fcall trf_2194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2194(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2194(t0,t1);}

static void C_fcall trf_2206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2206(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2206(t0,t1);}

static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2197(t0,t1);}

static void C_fcall trf_2157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2157(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2157(t0,t1,t2);}

static void C_fcall trf_2117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2117(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2117(t0,t1,t2);}

static void C_fcall trf_2136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2136(t0,t1);}

static void C_fcall trf_2049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2049(t0,t1,t2);}

static void C_fcall trf_2076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2076(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2076(t0,t1,t2);}

static void C_fcall trf_1996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1996(t0,t1,t2);}

static void C_fcall trf_1633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1633(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1633(t0,t1,t2,t3);}

static void C_fcall trf_1915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1915(t0,t1);}

static void C_fcall trf_1782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1782(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1782(t0,t1,t2,t3);}

static void C_fcall trf_1636(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1636(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1636(t0,t1,t2,t3,t4);}

static void C_fcall trf_1668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1668(t0,t1);}

static void C_fcall trf_1685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1685(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1685(t0,t1,t2);}

static void C_fcall trf_1704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1704(t0,t1);}

static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1665(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6920)){
C_save(t1);
C_rereclaim2(6920*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,501);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[11]=C_h_pair(C_restore,tmp);
lf[13]=C_static_string(C_heaptop,6,".dylib");
lf[15]=C_static_string(C_heaptop,4,".dll");
lf[17]=C_static_string(C_heaptop,3,".sl");
lf[19]=C_static_string(C_heaptop,3,".so");
lf[21]=C_static_string(C_heaptop,4,".scm");
lf[23]=C_static_string(C_heaptop,6,".setup");
lf[25]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[27]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[29]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[31]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[33]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[35]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[37]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[39]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[41]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[43]=C_h_intern(&lf[43],28,"pathname-directory-separator");
lf[45]=C_h_intern(&lf[45],21,"\003sysmacro-environment");
lf[46]=C_h_intern(&lf[46],20,"\003sysregister-macro-2");
lf[47]=C_h_intern(&lf[47],19,"\003syshash-table-set!");
lf[48]=C_h_intern(&lf[48],18,"\003sysregister-macro");
lf[49]=C_h_intern(&lf[49],6,"macro\077");
lf[50]=C_h_intern(&lf[50],18,"\003syshash-table-ref");
lf[51]=C_h_intern(&lf[51],15,"undefine-macro!");
lf[52]=C_h_intern(&lf[52],13,"string-append");
lf[54]=C_h_intern(&lf[54],9,"\003sysabort");
lf[55]=C_h_intern(&lf[55],9,"condition");
lf[56]=C_h_intern(&lf[56],7,"message");
lf[57]=C_static_string(C_heaptop,21,"during expansion of (");
lf[58]=C_static_string(C_heaptop,8," ...) - ");
lf[59]=C_h_intern(&lf[59],3,"exn");
lf[60]=C_h_intern(&lf[60],22,"with-exception-handler");
lf[61]=C_h_intern(&lf[61],30,"call-with-current-continuation");
lf[62]=C_h_intern(&lf[62],3,"let");
lf[63]=C_h_intern(&lf[63],8,"\003syscons");
lf[64]=C_h_intern(&lf[64],8,"\004coreapp");
lf[65]=C_h_intern(&lf[65],6,"letrec");
lf[66]=C_h_intern(&lf[66],7,"\003sysmap");
lf[67]=C_h_intern(&lf[67],4,"cadr");
lf[68]=C_h_intern(&lf[68],16,"\004coreloop-lambda");
lf[69]=C_h_intern(&lf[69],16,"\003syscheck-syntax");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[70]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
lf[71]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[72]=C_h_intern(&lf[72],10,"\003syssetter");
lf[73]=C_h_intern(&lf[73],6,"append");
lf[74]=C_h_intern(&lf[74],4,"set!");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[75]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[76]=C_h_intern(&lf[76],9,"\004coreset!");
lf[77]=C_h_intern(&lf[77],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[78]=C_h_intern(&lf[78],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[79]=C_h_intern(&lf[79],23,"\003sysmacroexpand-1-local");
lf[80]=C_h_intern(&lf[80],11,"macroexpand");
lf[81]=C_h_intern(&lf[81],13,"macroexpand-1");
lf[82]=C_h_intern(&lf[82],25,"\003sysenable-runtime-macros");
lf[83]=C_h_intern(&lf[83],32,"\003sysundefine-non-standard-macros");
lf[84]=C_h_intern(&lf[84],10,"\003sysappend");
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"and");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"or");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cond");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"case");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"let*");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"letrec");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"do");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"quasiquote");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"delay");
C_save(tmp);
lf[85]=C_h_list(10,C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(10);
lf[86]=C_h_intern(&lf[86],25,"\003sysextended-lambda-list\077");
lf[87]=C_h_intern(&lf[87],6,"#!rest");
lf[88]=C_h_intern(&lf[88],10,"#!optional");
lf[89]=C_h_intern(&lf[89],5,"#!key");
lf[90]=C_h_intern(&lf[90],7,"reverse");
lf[91]=C_h_intern(&lf[91],6,"gensym");
lf[92]=C_h_intern(&lf[92],31,"\003sysexpand-extended-lambda-list");
lf[93]=C_h_intern(&lf[93],9,":optional");
lf[94]=C_h_intern(&lf[94],13,"let-optionals");
lf[95]=C_h_intern(&lf[95],14,"let-optionals*");
lf[96]=C_h_intern(&lf[96],4,"let*");
lf[97]=C_h_intern(&lf[97],15,"\003sysget-keyword");
lf[98]=C_h_intern(&lf[98],5,"quote");
lf[99]=C_h_intern(&lf[99],6,"lambda");
lf[100]=C_h_intern(&lf[100],15,"string->keyword");
lf[101]=C_static_string(C_heaptop,43,"rest argument list specified more than once");
lf[102]=C_static_string(C_heaptop,45,"`#!optional\047 argument marker in wrong context");
lf[103]=C_static_string(C_heaptop,35,"invalid syntax of `#!rest\047 argument");
lf[104]=C_static_string(C_heaptop,41,"`#!rest\047 argument marker in wrong context");
lf[105]=C_static_string(C_heaptop,40,"`#!key\047 argument marker in wrong context");
lf[106]=C_static_string(C_heaptop,48,"invalid lambda list syntax after `#!rest\047 marker");
lf[107]=C_static_string(C_heaptop,32,"invalid required argument syntax");
lf[108]=C_static_string(C_heaptop,48,"invalid lambda list syntax after `#!rest\047 marker");
lf[109]=C_static_string(C_heaptop,26,"invalid lambda list syntax");
lf[110]=C_static_string(C_heaptop,26,"invalid lambda list syntax");
lf[111]=C_h_intern(&lf[111],3,"map");
lf[112]=C_h_intern(&lf[112],21,"\003syscanonicalize-body");
lf[113]=C_h_intern(&lf[113],5,"begin");
lf[114]=C_h_intern(&lf[114],6,"define");
lf[115]=C_h_intern(&lf[115],13,"define-values");
lf[116]=C_h_intern(&lf[116],20,"\003syscall-with-values");
lf[117]=C_h_intern(&lf[117],14,"\004coreundefined");
lf[118]=C_h_intern(&lf[118],25,"\003sysexpand-curried-define");
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[119]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[120]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[121]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[122]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[123]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,13,"define-values");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[124]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[125]=C_h_pair(C_restore,tmp);
lf[126]=C_h_intern(&lf[126],20,"\003sysmatch-expression");
lf[127]=C_h_intern(&lf[127],15,"\003syshash-symbol");
lf[128]=C_h_intern(&lf[128],23,"\003syshash-table-for-each");
lf[129]=C_h_intern(&lf[129],12,"\003sysfor-each");
lf[130]=C_h_intern(&lf[130],28,"\003sysarbitrary-unbound-symbol");
lf[131]=C_h_intern(&lf[131],23,"\003syshash-table-location");
lf[132]=C_h_intern(&lf[132],20,"\003syseval-environment");
lf[133]=C_h_intern(&lf[133],26,"\003sysenvironment-is-mutable");
lf[134]=C_h_intern(&lf[134],5,"write");
lf[135]=C_h_intern(&lf[135],6,"cadadr");
lf[136]=C_h_intern(&lf[136],20,"with-input-from-file");
lf[137]=C_h_intern(&lf[137],7,"display");
lf[138]=C_h_intern(&lf[138],22,"\003syscompile-to-closure");
lf[139]=C_h_intern(&lf[139],20,"\003sysmake-lambda-info");
lf[140]=C_h_intern(&lf[140],21,"with-output-to-string");
lf[141]=C_h_intern(&lf[141],19,"\003sysdecorate-lambda");
lf[142]=C_h_intern(&lf[142],21,"\003syssyntax-error-hook");
lf[143]=C_static_string(C_heaptop,33,"reference to undefined identifier");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[144]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[145]=C_h_intern(&lf[145],15,"\004coreglobal-ref");
lf[146]=C_h_intern(&lf[146],10,"\004corecheck");
lf[147]=C_h_intern(&lf[147],14,"\004coreimmutable");
lf[148]=C_h_intern(&lf[148],2,"if");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[149]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,2,"if");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
lf[150]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[151]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[152]=C_h_pair(C_restore,tmp);
lf[153]=C_h_intern(&lf[153],9,"\003syserror");
lf[154]=C_static_string(C_heaptop,32,"assignment to immutable variable");
lf[155]=C_static_string(C_heaptop,34,"assignment of undefined identifier");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[156]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[157]=C_h_intern(&lf[157],15,"\003sysmake-vector");
tmp=C_intern(C_heaptop,3,"let");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[158]=C_h_pair(C_restore,tmp);
lf[159]=C_h_intern(&lf[159],1,"\077");
lf[160]=C_h_intern(&lf[160],10,"\003sysvector");
lf[161]=C_static_string(C_heaptop,18,"bad argument count");
lf[162]=C_h_intern(&lf[162],25,"\003sysdecompose-lambda-list");
tmp=C_intern(C_heaptop,6,"lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[163]=C_h_pair(C_restore,tmp);
lf[164]=C_h_intern(&lf[164],17,"\004corenamed-lambda");
lf[165]=C_h_intern(&lf[165],23,"\004corerequire-for-syntax");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[166]=C_h_pair(C_restore,tmp);
lf[167]=C_h_intern(&lf[167],11,"\003sysrequire");
lf[168]=C_h_intern(&lf[168],31,"\003syslookup-runtime-requirements");
lf[169]=C_h_intern(&lf[169],22,"\004corerequire-extension");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[170]=C_h_pair(C_restore,tmp);
lf[171]=C_h_intern(&lf[171],22,"\003sysdo-the-right-thing");
lf[172]=C_h_intern(&lf[172],24,"\004coreelaborationtimeonly");
lf[173]=C_h_intern(&lf[173],23,"\004coreelaborationtimetoo");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[174]=C_h_pair(C_restore,tmp);
lf[175]=C_h_intern(&lf[175],19,"\004corecompiletimetoo");
lf[176]=C_h_intern(&lf[176],20,"\004corecompiletimeonly");
lf[177]=C_h_intern(&lf[177],13,"\004corecallunit");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[178]=C_h_pair(C_restore,tmp);
lf[179]=C_h_intern(&lf[179],12,"\004coredeclare");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[180]=C_h_pair(C_restore,tmp);
lf[181]=C_h_intern(&lf[181],10,"\000compiling");
lf[182]=C_h_intern(&lf[182],12,"\003sysfeatures");
lf[183]=C_h_intern(&lf[183],28,"\010compilerprocess-declaration");
lf[184]=C_h_intern(&lf[184],8,"\003syswarn");
lf[185]=C_static_string(C_heaptop,44,"declarations are ignored in interpreted code");
lf[186]=C_h_intern(&lf[186],18,"\004coredefine-inline");
lf[187]=C_h_intern(&lf[187],20,"\004coredefine-constant");
lf[188]=C_h_intern(&lf[188],14,"\004coreprimitive");
lf[189]=C_static_string(C_heaptop,38,"can not evaluate compiler-special-form");
lf[190]=C_h_intern(&lf[190],8,"location");
lf[191]=C_static_string(C_heaptop,38,"can not evaluate compiler-special-form");
lf[192]=C_h_intern(&lf[192],11,"\004coreinline");
lf[193]=C_h_intern(&lf[193],20,"\004coreinline_allocate");
lf[194]=C_h_intern(&lf[194],19,"\004coreforeign-lambda");
lf[195]=C_h_intern(&lf[195],28,"\004coredefine-foreign-variable");
lf[196]=C_h_intern(&lf[196],29,"\004coredefine-external-variable");
lf[197]=C_h_intern(&lf[197],17,"\004corelet-location");
lf[198]=C_h_intern(&lf[198],22,"\004coreforeign-primitive");
lf[199]=C_h_intern(&lf[199],20,"\004coreforeign-lambda*");
lf[200]=C_h_intern(&lf[200],24,"\004coredefine-foreign-type");
lf[201]=C_static_string(C_heaptop,25,"illegal non-atomic object");
lf[202]=C_h_intern(&lf[202],11,"\003sysnumber\077");
lf[203]=C_static_string(C_heaptop,20,"malformed expression");
lf[204]=C_h_intern(&lf[204],16,"\003syseval-handler");
lf[205]=C_h_intern(&lf[205],12,"eval-handler");
lf[206]=C_h_intern(&lf[206],4,"eval");
lf[207]=C_h_intern(&lf[207],24,"\003syssyntax-error-culprit");
lf[208]=C_static_string(C_heaptop,26,"illegal lambda-list syntax");
lf[209]=C_h_intern(&lf[209],12,"load-verbose");
lf[210]=C_h_intern(&lf[210],14,"\003sysabort-load");
lf[211]=C_h_intern(&lf[211],21,"\003syscurrent-load-file");
lf[212]=C_h_intern(&lf[212],22,"set-dynamic-load-mode!");
lf[213]=C_h_intern(&lf[213],21,"\003sysset-dlopen-flags!");
lf[214]=C_h_intern(&lf[214],6,"global");
lf[215]=C_h_intern(&lf[215],5,"local");
lf[216]=C_h_intern(&lf[216],4,"lazy");
lf[217]=C_h_intern(&lf[217],3,"now");
lf[218]=C_h_intern(&lf[218],15,"\003syssignal-hook");
lf[219]=C_static_string(C_heaptop,25,"invalid dynamic-load mode");
lf[220]=C_h_intern(&lf[220],4,"read");
lf[221]=C_h_intern(&lf[221],7,"newline");
lf[222]=C_h_intern(&lf[222],15,"open-input-file");
lf[223]=C_h_intern(&lf[223],16,"close-input-port");
lf[224]=C_h_intern(&lf[224],8,"\003sysload");
lf[225]=C_h_intern(&lf[225],31,"\003sysread-error-with-line-number");
lf[226]=C_h_intern(&lf[226],17,"\003sysdisplay-times");
lf[227]=C_h_intern(&lf[227],14,"\003sysstop-timer");
lf[228]=C_h_intern(&lf[228],15,"\003sysstart-timer");
lf[229]=C_h_intern(&lf[229],4,"load");
lf[230]=C_static_string(C_heaptop,30,"unable to load compiled module");
lf[231]=C_h_intern(&lf[231],17,"\003syspeek-c-string");
lf[232]=C_h_intern(&lf[232],9,"peek-char");
lf[233]=C_h_intern(&lf[233],16,"\003sysdynamic-wind");
lf[234]=C_h_intern(&lf[234],9,"\003sysdload");
lf[235]=C_h_intern(&lf[235],17,"\003sysmake-c-string");
lf[236]=C_static_string(C_heaptop,1,".");
lf[237]=C_h_intern(&lf[237],11,"\000file-error");
lf[238]=C_static_string(C_heaptop,17,"can not open file");
lf[239]=C_static_string(C_heaptop,5," ...\012");
lf[240]=C_static_string(C_heaptop,10,"; loading ");
lf[241]=C_h_intern(&lf[241],5,"isdir");
lf[242]=C_h_intern(&lf[242],13,"\003sysfile-info");
lf[243]=C_h_intern(&lf[243],17,"\003sysstring-append");
lf[244]=C_h_intern(&lf[244],26,"\003sysload-dynamic-extension");
lf[245]=C_h_intern(&lf[245],11,"\000type-error");
lf[246]=C_static_string(C_heaptop,40,"bad argument type - not a port or string");
lf[247]=C_h_intern(&lf[247],5,"port\077");
lf[248]=C_h_intern(&lf[248],20,"\003sysexpand-home-path");
lf[249]=C_h_intern(&lf[249],21,"\003syscurrent-namespace");
lf[250]=C_h_intern(&lf[250],12,"load-noisily");
lf[251]=C_h_intern(&lf[251],8,"\000printer");
lf[252]=C_h_intern(&lf[252],5,"\000time");
lf[253]=C_h_intern(&lf[253],10,"\000evaluator");
lf[254]=C_h_intern(&lf[254],26,"\003sysload-library-extension");
lf[255]=C_h_intern(&lf[255],34,"\003sysdefault-dynamic-load-libraries");
lf[256]=C_h_intern(&lf[256],22,"dynamic-load-libraries");
lf[257]=C_h_intern(&lf[257],16,"\003sysload-library");
lf[258]=C_static_string(C_heaptop,5," ...\012");
lf[259]=C_static_string(C_heaptop,18,"; loading library ");
lf[260]=C_static_string(C_heaptop,2,"C_");
lf[261]=C_static_string(C_heaptop,9,"_toplevel");
lf[262]=C_h_intern(&lf[262],24,"\003sysstring->c-identifier");
lf[263]=C_h_intern(&lf[263],16,"\003sys->feature-id");
lf[264]=C_h_intern(&lf[264],12,"load-library");
lf[265]=C_static_string(C_heaptop,22,"unable to load library");
lf[267]=C_h_intern(&lf[267],13,"\003syssubstring");
lf[268]=C_h_intern(&lf[268],31,"\003syscanonicalize-extension-path");
lf[269]=C_static_string(C_heaptop,22,"invalid extension path");
lf[270]=C_h_intern(&lf[270],18,"\003syssymbol->string");
lf[271]=C_static_string(C_heaptop,0,"");
lf[272]=C_static_string(C_heaptop,0,"");
lf[273]=C_h_intern(&lf[273],19,"\003sysrepository-path");
lf[274]=C_h_intern(&lf[274],15,"repository-path");
lf[275]=C_h_intern(&lf[275],12,"file-exists\077");
lf[276]=C_h_intern(&lf[276],18,"\003sysfind-extension");
lf[277]=C_h_intern(&lf[277],21,"\003sysinclude-pathnames");
tmp=C_static_string(C_heaptop,1,".");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[278]=C_h_pair(C_restore,tmp);
lf[279]=C_h_intern(&lf[279],21,"\003sysloaded-extensions");
lf[280]=C_h_intern(&lf[280],18,"\003sysload-extension");
lf[281]=C_static_string(C_heaptop,22,"can not load extension");
lf[282]=C_h_intern(&lf[282],11,"\003sysprovide");
lf[283]=C_h_intern(&lf[283],7,"provide");
lf[284]=C_h_intern(&lf[284],13,"\003sysprovided\077");
lf[285]=C_h_intern(&lf[285],9,"provided\077");
lf[286]=C_h_intern(&lf[286],7,"require");
lf[287]=C_h_intern(&lf[287],18,"\003sysextension-info");
lf[288]=C_h_intern(&lf[288],14,"extension-info");
lf[289]=C_h_intern(&lf[289],18,"require-at-runtime");
lf[290]=C_h_intern(&lf[290],12,"vector->list");
lf[291]=C_h_intern(&lf[291],13,"test-feature\077");
lf[292]=C_h_intern(&lf[292],11,"lset-adjoin");
lf[293]=C_h_intern(&lf[293],3,"eq\077");
lf[294]=C_h_intern(&lf[294],18,"hash-table-update!");
lf[295]=C_h_intern(&lf[295],26,"\010compilerfile-requirements");
lf[296]=C_h_intern(&lf[296],19,"syntax-requirements");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[297]=C_h_pair(C_restore,tmp);
lf[298]=C_h_intern(&lf[298],20,"chicken-match-macros");
lf[299]=C_h_intern(&lf[299],18,"chicken-ffi-macros");
lf[300]=C_h_intern(&lf[300],19,"chicken-more-macros");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[301]=C_h_pair(C_restore,tmp);
lf[302]=C_h_intern(&lf[302],28,"\003sysresolve-include-filename");
lf[303]=C_h_intern(&lf[303],4,"uses");
lf[304]=C_h_intern(&lf[304],6,"syntax");
lf[305]=C_h_intern(&lf[305],17,"require-extension");
lf[306]=C_h_intern(&lf[306],24,"\003sysextension-specifiers");
lf[307]=C_static_string(C_heaptop,29,"undefined extension specifier");
lf[308]=C_static_string(C_heaptop,27,"invalid extension specifier");
lf[309]=C_h_intern(&lf[309],24,"set-extension-specifier!");
lf[310]=C_h_intern(&lf[310],11,"string-copy");
lf[313]=C_h_intern(&lf[313],11,"environment");
lf[315]=C_h_intern(&lf[315],18,"\003syscopy-env-table");
lf[316]=C_h_intern(&lf[316],23,"interaction-environment");
lf[317]=C_h_intern(&lf[317],25,"scheme-report-environment");
lf[318]=C_static_string(C_heaptop,22,"no support for version");
lf[319]=C_h_intern(&lf[319],11,"make-vector");
lf[320]=C_h_intern(&lf[320],16,"null-environment");
lf[321]=C_static_string(C_heaptop,22,"no support for version");
lf[322]=C_h_intern(&lf[322],6,"string");
lf[323]=C_static_string(C_heaptop,1,"0");
lf[324]=C_static_string(C_heaptop,11," major GCs\012");
lf[325]=C_static_string(C_heaptop,11," minor GCs\012");
lf[326]=C_static_string(C_heaptop,11," mutations\012");
lf[327]=C_static_string(C_heaptop,23," seconds in (major) GC\012");
lf[328]=C_static_string(C_heaptop,17," seconds elapsed\012");
lf[329]=C_h_intern(&lf[329],24,"\003sysline-number-database");
lf[330]=C_h_intern(&lf[330],13,"\000syntax-error");
lf[331]=C_h_intern(&lf[331],12,"syntax-error");
lf[332]=C_h_intern(&lf[332],15,"get-line-number");
lf[333]=C_h_intern(&lf[333],8,"keyword\077");
lf[334]=C_h_intern(&lf[334],14,"symbol->string");
lf[335]=C_static_string(C_heaptop,1,"(");
lf[336]=C_static_string(C_heaptop,10,") in line ");
lf[337]=C_static_string(C_heaptop,3," - ");
lf[338]=C_static_string(C_heaptop,1,"(");
lf[339]=C_static_string(C_heaptop,2,") ");
lf[340]=C_static_string(C_heaptop,20,"not enough arguments");
lf[341]=C_static_string(C_heaptop,18,"too many arguments");
lf[342]=C_static_string(C_heaptop,17,"not a proper list");
lf[343]=C_h_intern(&lf[343],1,"_");
lf[344]=C_h_intern(&lf[344],4,"pair");
lf[345]=C_h_intern(&lf[345],5,"pair\077");
lf[346]=C_static_string(C_heaptop,13,"pair expected");
lf[347]=C_h_intern(&lf[347],8,"variable");
lf[348]=C_static_string(C_heaptop,19,"identifier expected");
lf[349]=C_h_intern(&lf[349],6,"symbol");
lf[350]=C_h_intern(&lf[350],7,"symbol\077");
lf[351]=C_static_string(C_heaptop,15,"symbol expected");
lf[352]=C_h_intern(&lf[352],4,"list");
lf[353]=C_static_string(C_heaptop,20,"proper list expected");
lf[354]=C_h_intern(&lf[354],6,"number");
lf[355]=C_h_intern(&lf[355],7,"number\077");
lf[356]=C_static_string(C_heaptop,15,"number expected");
lf[357]=C_h_intern(&lf[357],7,"string\077");
lf[358]=C_static_string(C_heaptop,15,"string expected");
lf[359]=C_h_intern(&lf[359],11,"lambda-list");
lf[360]=C_static_string(C_heaptop,20,"lambda-list expected");
lf[361]=C_static_string(C_heaptop,15,"missing keyword");
lf[362]=C_static_string(C_heaptop,15,"incomplete form");
lf[363]=C_static_string(C_heaptop,17,"unexpected object");
lf[364]=C_h_intern(&lf[364],16,"\003systest-feature");
lf[365]=C_h_intern(&lf[365],18,"\003sysrepl-eval-hook");
lf[366]=C_h_intern(&lf[366],27,"\003sysrepl-print-length-limit");
lf[367]=C_h_intern(&lf[367],18,"\003sysrepl-read-hook");
lf[368]=C_h_intern(&lf[368],11,"repl-prompt");
lf[369]=C_h_intern(&lf[369],20,"\003sysread-prompt-hook");
lf[370]=C_h_intern(&lf[370],16,"\003sysflush-output");
lf[371]=C_h_intern(&lf[371],19,"\003sysstandard-output");
lf[372]=C_h_intern(&lf[372],5,"reset");
lf[373]=C_h_intern(&lf[373],4,"repl");
lf[374]=C_h_intern(&lf[374],16,"\003syswrite-char-0");
lf[375]=C_h_intern(&lf[375],27,"\003syswith-print-length-limit");
lf[376]=C_h_intern(&lf[376],18,"\003sysstandard-input");
lf[377]=C_h_intern(&lf[377],18,"\003sysstandard-error");
lf[378]=C_static_string(C_heaptop,2,": ");
lf[379]=C_static_string(C_heaptop,7,"Error: ");
lf[380]=C_h_intern(&lf[380],17,"\003syserror-handler");
lf[381]=C_h_intern(&lf[381],15,"\003sysread-char-0");
lf[382]=C_h_intern(&lf[382],15,"\003syspeek-char-0");
lf[383]=C_h_intern(&lf[383],28,"\003sysdefault-namespace-prefix");
lf[384]=C_h_intern(&lf[384],21,"\003sysenable-qualifiers");
lf[385]=C_h_intern(&lf[385],17,"\003sysreset-handler");
lf[386]=C_h_intern(&lf[386],28,"\003syssharp-comma-reader-ctors");
lf[387]=C_h_intern(&lf[387],18,"define-reader-ctor");
lf[388]=C_h_intern(&lf[388],18,"\003sysuser-read-hook");
lf[389]=C_h_intern(&lf[389],9,"read-char");
lf[390]=C_h_intern(&lf[390],14,"\003sysread-error");
lf[391]=C_static_string(C_heaptop,33,"invalid sharp-comma external form");
lf[392]=C_static_string(C_heaptop,33,"undefined sharp-comma constructor");
lf[393]=C_h_intern(&lf[393],16,"set-read-syntax!");
lf[394]=C_h_intern(&lf[394],29,"\003sysspecial-read-syntax-table");
lf[395]=C_h_intern(&lf[395],25,"set-dispatch-read-syntax!");
lf[396]=C_h_intern(&lf[396],38,"\003sysspecial-dispatch-read-syntax-table");
lf[399]=C_h_intern(&lf[399],17,"get-output-string");
lf[400]=C_h_intern(&lf[400],19,"print-error-message");
lf[401]=C_h_intern(&lf[401],18,"open-output-string");
lf[403]=C_h_intern(&lf[403],6,"\003sysgc");
lf[405]=C_h_intern(&lf[405],13,"thread-yield!");
lf[408]=C_h_intern(&lf[408],17,"open-input-string");
lf[410]=C_static_string(C_heaptop,40,"Error: not enough room for result string");
lf[414]=C_h_intern(&lf[414],23,"CHICKEN_apply_to_string");
lf[418]=C_static_string(C_heaptop,8,"No error");
lf[419]=C_h_intern(&lf[419],15,"\003sysmake-string");
lf[420]=C_h_intern(&lf[420],6,"module");
lf[421]=C_static_string(C_heaptop,25,"modules are not supported");
lf[422]=C_h_intern(&lf[422],13,"define-syntax");
lf[423]=C_static_string(C_heaptop,34,"highlevel macros are not supported");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[424]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[425]=C_h_intern(&lf[425],12,"define-macro");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[426]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[427]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[428]=C_h_pair(C_restore,tmp);
lf[429]=C_static_string(C_heaptop,4,"#;> ");
lf[430]=C_h_intern(&lf[430],14,"make-parameter");
tmp=C_intern(C_heaptop,7,"\000srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\000srfi-10");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-9");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\000srfi-55");
C_save(tmp);
lf[431]=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
lf[432]=C_h_intern(&lf[432],16,"\003sysmake-promise");
lf[433]=C_h_intern(&lf[433],5,"delay");
lf[434]=C_h_intern(&lf[434],16,"\003syslist->vector");
lf[435]=C_h_intern(&lf[435],7,"unquote");
lf[436]=C_h_intern(&lf[436],8,"\003syslist");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
lf[437]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
lf[438]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[439]=C_h_intern(&lf[439],10,"quasiquote");
lf[440]=C_h_intern(&lf[440],16,"unquote-splicing");
lf[441]=C_h_intern(&lf[441],1,"a");
lf[442]=C_h_intern(&lf[442],1,"b");
tmp=C_intern(C_heaptop,10,"\003sysappend");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
lf[443]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[444]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syslist");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[445]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
lf[446]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
lf[447]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[448]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[449]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[450]=C_h_pair(C_restore,tmp);
lf[451]=C_static_string(C_heaptop,2,"do");
lf[452]=C_h_intern(&lf[452],2,"do");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[453]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[454]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[455]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[456]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[457]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[458]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[459]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[460]=C_h_intern(&lf[460],4,"else");
lf[461]=C_h_intern(&lf[461],2,"or");
lf[462]=C_h_intern(&lf[462],4,"eqv\077");
lf[463]=C_h_intern(&lf[463],4,"case");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[464]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[465]=C_h_pair(C_restore,tmp);
lf[466]=C_h_intern(&lf[466],2,"=>");
lf[467]=C_h_intern(&lf[467],4,"cond");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[468]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[469]=C_h_pair(C_restore,tmp);
lf[470]=C_h_intern(&lf[470],3,"and");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[471]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[472]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[473]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[474]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[475]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[476]=C_h_vector(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,12,"dynamic-wind");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"values");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"call-with-values");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"eval");
C_save(tmp);
tmp=C_intern(C_heaptop,25,"scheme-report-environment");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"null-environment");
C_save(tmp);
tmp=C_intern(C_heaptop,23,"interaction-environment");
C_save(tmp);
lf[477]=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
tmp=C_intern(C_heaptop,3,"not");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"boolean\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"eq\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"eqv\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"equal\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"pair\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cons");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdddar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddddr");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"set-car!");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"set-cdr!");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"null\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"list\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"list");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"length");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"list-tail");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"list-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"append");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"reverse");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"memq");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"memv");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"member");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"assq");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"assv");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"assoc");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"symbol\077");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"symbol->string");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"string->symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"number\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"integer\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"exact\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"real\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"complex\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"inexact\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"rational\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"zero\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"odd\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"even\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"positive\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"negative\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"max");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"min");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"+");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"-");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"*");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"/");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"=");
C_save(tmp);
tmp=C_intern(C_heaptop,1,">");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"<");
C_save(tmp);
tmp=C_intern(C_heaptop,2,">=");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"<=");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"quotient");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"remainder");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"modulo");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"gcd");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"lcm");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"abs");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"floor");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"ceiling");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"truncate");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"round");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"exact->inexact");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"inexact->exact");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"exp");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"log");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"expt");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"sqrt");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"sin");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cos");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tan");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"asin");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"acos");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"atan");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"number->string");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"string->number");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"char\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"char>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"char<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"char-ci>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"char-ci<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-alphabetic\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-whitespace\077");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char-numeric\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-upper-case\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-lower-case\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"char-upcase");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char-downcase");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char->integer");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"integer->char");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"string\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"string>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"string<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-ci>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-ci<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"make-string");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"string-length");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"string-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-set!");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"string-append");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-copy");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string->list");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"list->string");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"substring");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-fill!");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"vector\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"make-vector");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"vector-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"vector-set!");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"string");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"vector");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"vector-length");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"vector->list");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"list->vector");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"vector-fill!");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"procedure\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"map");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"for-each");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"apply");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"force");
C_save(tmp);
tmp=C_intern(C_heaptop,30,"call-with-current-continuation");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"input-port\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"output-port\077");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"current-input-port");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"current-output-port");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"call-with-input-file");
C_save(tmp);
tmp=C_intern(C_heaptop,21,"call-with-output-file");
C_save(tmp);
tmp=C_intern(C_heaptop,15,"open-input-file");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"open-output-file");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"close-input-port");
C_save(tmp);
tmp=C_intern(C_heaptop,17,"close-output-port");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"load");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"transcript-on");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"transcript-off");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"read");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"eof-object\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"read-char");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"peek-char");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"write");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"display");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"write-char");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"newline");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"with-input-from-file");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"with-output-to-file");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"\003syscall-with-values");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"\003sysvalues");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003sysdynamic-wind");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003syslist->vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syslist");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"\003sysappend");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003sysmake-promise");
C_save(tmp);
lf[478]=C_h_list(191,C_pick(190),C_pick(189),C_pick(188),C_pick(187),C_pick(186),C_pick(185),C_pick(184),C_pick(183),C_pick(182),C_pick(181),C_pick(180),C_pick(179),C_pick(178),C_pick(177),C_pick(176),C_pick(175),C_pick(174),C_pick(173),C_pick(172),C_pick(171),C_pick(170),C_pick(169),C_pick(168),C_pick(167),C_pick(166),C_pick(165),C_pick(164),C_pick(163),C_pick(162),C_pick(161),C_pick(160),C_pick(159),C_pick(158),C_pick(157),C_pick(156),C_pick(155),C_pick(154),C_pick(153),C_pick(152),C_pick(151),C_pick(150),C_pick(149),C_pick(148),C_pick(147),C_pick(146),C_pick(145),C_pick(144),C_pick(143),C_pick(142),C_pick(141),C_pick(140),C_pick(139),C_pick(138),C_pick(137),C_pick(136),C_pick(135),C_pick(134),C_pick(133),C_pick(132),C_pick(131),C_pick(130),C_pick(129),C_pick(128),C_pick(127),C_pick(126),C_pick(125),C_pick(124),C_pick(123),C_pick(122),C_pick(121),C_pick(120),C_pick(119),C_pick(118),C_pick(117),C_pick(116),C_pick(115),C_pick(114),C_pick(113),C_pick(112),C_pick(111),C_pick(110),C_pick(109),C_pick(108),C_pick(107),C_pick(106),C_pick(105),C_pick(104),C_pick(103),C_pick(102),C_pick(101),C_pick(100),C_pick(99),C_pick(98),C_pick(97),C_pick(96),C_pick(95),C_pick(94),C_pick(93),C_pick(92),C_pick(91),C_pick(90),C_pick(89),C_pick(88),C_pick(87),C_pick(86),C_pick(85),C_pick(84),C_pick(83),C_pick(82),C_pick(81),C_pick(80),C_pick(79),C_pick(78),C_pick(77),C_pick(76),C_pick(75),C_pick(74),C_pick(73),C_pick(72),C_pick(71),C_pick(70),C_pick(69),C_pick(68),C_pick(67),C_pick(66),C_pick(65),C_pick(64),C_pick(63),C_pick(62),C_pick(61),C_pick(60),C_pick(59),C_pick(58),C_pick(57),C_pick(56),C_pick(55),C_pick(54),C_pick(53),C_pick(52),C_pick(51),C_pick(50),C_pick(49),C_pick(48),C_pick(47),C_pick(46),C_pick(45),C_pick(44),C_pick(43),C_pick(42),C_pick(41),C_pick(40),C_pick(39),C_pick(38),C_pick(37),C_pick(36),C_pick(35),C_pick(34),C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(191);
lf[479]=C_h_intern(&lf[479],7,"version");
lf[480]=C_h_intern(&lf[480],5,"error");
lf[481]=C_static_string(C_heaptop,51,"installed extension does not match required version");
lf[482]=C_h_intern(&lf[482],9,"string>=\077");
lf[483]=C_h_intern(&lf[483],8,"->string");
lf[484]=C_static_string(C_heaptop,29,"invalid version specification");
lf[485]=C_h_intern(&lf[485],12,"list->vector");
lf[486]=C_h_intern(&lf[486],18,"\003sysstring->symbol");
lf[487]=C_static_string(C_heaptop,5,"srfi-");
lf[488]=C_h_intern(&lf[488],4,"srfi");
lf[489]=C_h_intern(&lf[489],6,"getenv");
lf[490]=C_h_intern(&lf[490],7,"windows");
lf[491]=C_h_intern(&lf[491],4,"msvc");
lf[492]=C_h_intern(&lf[492],7,"mingw32");
lf[493]=C_h_intern(&lf[493],14,"build-platform");
lf[494]=C_h_intern(&lf[494],13,"software-type");
lf[495]=C_h_intern(&lf[495],6,"macosx");
lf[496]=C_h_intern(&lf[496],4,"hpux");
lf[497]=C_h_intern(&lf[497],4,"hppa");
lf[498]=C_h_intern(&lf[498],12,"machine-type");
lf[499]=C_h_intern(&lf[499],16,"software-version");
lf[500]=C_static_string(C_heaptop,10,"C_toplevel");
C_register_lf(lf,501);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate(&lf[8],lf[9]);
t7=C_mutate(&lf[10],lf[11]);
t8=C_mutate(&lf[12],lf[13]);
t9=C_mutate(&lf[14],lf[15]);
t10=C_mutate(&lf[16],lf[17]);
t11=C_mutate(&lf[18],lf[19]);
t12=C_mutate(&lf[20],lf[21]);
t13=C_mutate(&lf[22],lf[23]);
t14=C_mutate(&lf[24],lf[25]);
t15=C_mutate(&lf[26],lf[27]);
t16=C_mutate(&lf[28],lf[29]);
t17=C_mutate(&lf[30],lf[31]);
t18=C_mutate(&lf[32],lf[33]);
t19=C_mutate(&lf[34],lf[35]);
t20=C_mutate(&lf[36],lf[37]);
t21=C_mutate(&lf[38],lf[39]);
t22=C_mutate(&lf[40],lf[41]);
t23=C_mutate(&lf[42],*((C_word*)lf[43]+1));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1574,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 94   string */
t25=*((C_word*)lf[322]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,*((C_word*)lf[43]+1));}

/* k1572 */
static void f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=C_mutate(&lf[44],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 99   make-vector */
t4=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1576 in k1572 */
static void f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[63],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1580,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1596,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[49]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1612,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1627,tmp=(C_word)a,a+=2,tmp));
t7=*((C_word*)lf[52]+1);
t8=C_mutate(&lf[53],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1633,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1975,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1978,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1981,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1987,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2023,tmp=(C_word)a,a+=2,tmp));
t14=C_set_block_item(lf[82],0,C_SCHEME_FALSE);
t15=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2040,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2111,tmp=(C_word)a,a+=2,tmp));
t17=*((C_word*)lf[90]+1);
t18=*((C_word*)lf[91]+1);
t19=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2154,a[2]=t18,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[90]+1);
t21=*((C_word*)lf[111]+1);
t22=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2673,a[2]=t21,a[3]=t20,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3124,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3215,tmp=(C_word)a,a+=2,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3275,a[2]=t28,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3290,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3335,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3390,tmp=(C_word)a,a+=2,tmp));
t33=(C_word)C_slot(lf[130],C_fix(0));
t34=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=t33,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(lf[132],0,C_SCHEME_FALSE);
t36=C_set_block_item(lf[133],0,C_SCHEME_FALSE);
t37=*((C_word*)lf[49]+1);
t38=*((C_word*)lf[134]+1);
t39=*((C_word*)lf[135]+1);
t40=*((C_word*)lf[90]+1);
t41=*((C_word*)lf[136]+1);
t42=(C_word)C_slot(lf[130],C_fix(0));
t43=*((C_word*)lf[137]+1);
t44=C_mutate((C_word*)lf[138]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3499,a[2]=t39,a[3]=t38,tmp=(C_word)a,a+=4,tmp));
t45=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10318,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 947  make-parameter */
t47=*((C_word*)lf[430]+1);
((C_proc3)(void*)(*((C_word*)t47+1)))(3,t47,t45,t46);}

/* a10317 in k1576 in k1572 */
static void f_10318(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10318r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10318r(t0,t1,t2,t3);}}

static void f_10318r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[133]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10322,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_slot(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_slot(t9,C_fix(1));
t11=C_set_block_item(t7,0,t10);
t12=(C_word)C_slot(t9,C_fix(2));
t13=C_set_block_item(t5,0,t12);
t14=t8;
f_10322(t14,t13);}
else{
t10=t8;
f_10322(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_10322(t9,C_SCHEME_UNDEFINED);}}

/* k10320 in a10317 in k1576 in k1572 */
static void C_fcall f_10322(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10322,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10328,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10330,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10343,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 957  ##sys#dynamic-wind */
t14=*((C_word*)lf[233]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a10342 in k10320 in a10317 in k1576 in k1572 */
static void f_10343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10343,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[133]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[132]+1));
t4=C_mutate((C_word*)lf[133]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[132]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a10336 in k10320 in a10317 in k1576 in k1572 */
static void f_10337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10337,2,t0,t1);}
/* eval.scm: 959  ##sys#compile-to-closure */
t2=*((C_word*)lf[138]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a10329 in k10320 in a10317 in k1576 in k1572 */
static void f_10330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10330,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[133]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[132]+1));
t4=C_mutate((C_word*)lf[133]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[132]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10326 in k10320 in a10317 in k1576 in k1572 */
static void f_10328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5622 in k1576 in k1572 */
static void f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5624,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1,t1);
t3=C_mutate((C_word*)lf[205]+1,*((C_word*)lf[204]+1));
t4=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5627,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[90]+1);
t6=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5641,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 991  make-parameter */
t9=*((C_word*)lf[430]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k5721 in k5622 in k1576 in k1572 */
static void f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5723,2,t0,t1);}
t2=C_mutate((C_word*)lf[209]+1,t1);
t3=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5725,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[211],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5729,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[220]+1);
t7=*((C_word*)lf[134]+1);
t8=*((C_word*)lf[137]+1);
t9=*((C_word*)lf[221]+1);
t10=*((C_word*)lf[222]+1);
t11=*((C_word*)lf[223]+1);
t12=*((C_word*)lf[52]+1);
t13=*((C_word*)lf[209]+1);
t14=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=t8,a[5]=t12,a[6]=t10,a[7]=t11,a[8]=t7,a[9]=t9,a[10]=t6,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1021 ##sys#make-c-string */
t15=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[500]);}

/* k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=C_mutate((C_word*)lf[224]+1,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5850,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp));
t3=C_mutate((C_word*)lf[229]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6225,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6267,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10312,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1104 software-type */
t7=*((C_word*)lf[494]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k10310 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10312,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[490]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6309(t3,lf[15]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10308,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1105 software-version */
t4=*((C_word*)lf[499]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10306 in k10310 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10308,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[495]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6309(t3,lf[13]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10290,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10304,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1106 software-version */
t5=*((C_word*)lf[499]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10302 in k10306 in k10310 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10304,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[496]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1107 machine-type */
t4=*((C_word*)lf[498]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_10290(t3,C_SCHEME_FALSE);}}

/* k10298 in k10302 in k10306 in k10310 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10290(t2,(C_word)C_eqp(t1,lf[497]));}

/* k10288 in k10306 in k10310 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_10290(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6309(t2,(C_truep(t1)?lf[17]:lf[18]));}

/* k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6309,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[254]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10275,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1111 software-version */
t5=*((C_word*)lf[499]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k10273 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10275,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[495]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6313(t3,lf[18]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10257,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10271,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1112 software-version */
t5=*((C_word*)lf[499]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10269 in k10273 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10271,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[496]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10267,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1113 machine-type */
t4=*((C_word*)lf[498]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_10257(t3,C_SCHEME_FALSE);}}

/* k10265 in k10269 in k10273 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10257(t2,(C_word)C_eqp(t1,lf[497]));}

/* k10255 in k10273 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_10257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6313(t2,(C_truep(t1)?lf[18]:*((C_word*)lf[254]+1)));}

/* k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6313(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6313,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[244]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6317,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1117 software-type */
t4=*((C_word*)lf[494]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6320,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(t1,lf[490]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10236,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1119 build-platform */
t5=*((C_word*)lf[493]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_6320(t4,lf[5]);}}

/* k10234 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[491]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6320(t3,lf[11]);}
else{
t3=(C_word)C_eqp(t1,lf[492]);
t4=((C_word*)t0)[2];
f_6320(t4,(C_truep(t3)?lf[9]:lf[7]));}}

/* k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6320,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[255]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10221,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10226,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[255]+1));}

/* a10225 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10226,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[254]+1));}

/* k10219 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10223,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1126 make-parameter */
t3=*((C_word*)lf[430]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a10222 in k10219 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10223,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=C_mutate((C_word*)lf[256]+1,t1);
t3=*((C_word*)lf[209]+1);
t4=*((C_word*)lf[52]+1);
t5=*((C_word*)lf[256]+1);
t6=*((C_word*)lf[137]+1);
t7=C_mutate((C_word*)lf[257]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6326,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[264]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6432,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[90]+1);
t10=C_mutate(&lf[266],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6458,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=*((C_word*)lf[52]+1);
t12=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6514,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10205,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1213 getenv */
t15=*((C_word*)lf[489]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[25]);}

/* k10203 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_10208(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10211,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1214 getenv */
t4=*((C_word*)lf[489]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[27]);}}

/* k10209 in k10203 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10211,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10208(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}}

/* k10206 in k10203 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1212 make-parameter */
t2=*((C_word*)lf[430]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6662,2,t0,t1);}
t2=C_mutate((C_word*)lf[273]+1,t1);
t3=C_mutate((C_word*)lf[274]+1,*((C_word*)lf[273]+1));
t4=*((C_word*)lf[275]+1);
t5=*((C_word*)lf[52]+1);
t6=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6665,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t7=C_set_block_item(lf[279],0,C_SCHEME_END_OF_LIST);
t8=C_mutate((C_word*)lf[280]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6742,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6801,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[283]+1,*((C_word*)lf[282]+1));
t11=C_mutate((C_word*)lf[284]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6818,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[285]+1,*((C_word*)lf[284]+1));
t13=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6832,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[286]+1,*((C_word*)lf[167]+1));
t15=*((C_word*)lf[136]+1);
t16=*((C_word*)lf[275]+1);
t17=*((C_word*)lf[52]+1);
t18=*((C_word*)lf[220]+1);
t19=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6845,a[2]=t17,a[3]=t16,a[4]=t18,a[5]=t15,tmp=(C_word)a,a+=6,tmp));
t20=C_mutate((C_word*)lf[288]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6867,tmp=(C_word)a,a+=2,tmp));
t21=*((C_word*)lf[136]+1);
t22=*((C_word*)lf[220]+1);
t23=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6873,tmp=(C_word)a,a+=2,tmp));
t24=*((C_word*)lf[290]+1);
t25=*((C_word*)lf[291]+1);
t26=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6922,a[2]=t24,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t27=C_set_block_item(lf[306],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7256,tmp=(C_word)a,a+=2,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7292,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[485]+1);
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10154,a[2]=t30,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1386 set-extension-specifier! */
t32=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t32+1)))(4,t32,t29,lf[488],t31);}

/* a10153 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10154,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10162,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10168,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_10168(t9,t4,t5);}

/* loop in a10153 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_10168(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10168,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10185,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10197,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10201,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1396 number->string */
C_number_to_string(3,0,t6,t3);}}

/* k10199 in loop in a10153 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1396 ##sys#string-append */
t2=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[487],t1);}

/* k10195 in loop in a10153 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1396 ##sys#string->symbol */
t2=*((C_word*)lf[486]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k10183 in loop in a10153 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10189,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1397 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10168(t4,t2,t3);}

/* k10187 in k10183 in loop in a10153 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10160 in a10153 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1390 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10063,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1402 set-extension-specifier! */
t4=*((C_word*)lf[309]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[479],t3);}

/* a10062 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10063,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10070,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_eqp(t5,lf[479]);
if(C_truep(t6)){
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_u_i_cdddr(t2);
t10=t4;
f_10070(t10,(C_word)C_i_nullp(t9));}
else{
t9=t4;
f_10070(t9,C_SCHEME_FALSE);}}
else{
t8=t4;
f_10070(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_10070(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_10070(t5,C_SCHEME_FALSE);}}

/* k10068 in a10062 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_10070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10070,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10079,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1407 extension-info */
t5=*((C_word*)lf[288]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[331]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[305],lf[484],((C_word*)t0)[3]);}}

/* k10077 in k10068 in a10062 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10079,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_u_i_assq(lf[479],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10085,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10088,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10098,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_u_i_car(t2);
/* eval.scm: 1409 ->string */
t7=*((C_word*)lf[483]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t5=t4;
f_10088(2,t5,C_SCHEME_FALSE);}}

/* k10096 in k10077 in k10068 in a10062 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10102,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1409 ->string */
t3=*((C_word*)lf[483]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k10100 in k10096 in k10077 in k10068 in a10062 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1409 string>=? */
t2=*((C_word*)lf[482]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10086 in k10077 in k10068 in a10062 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10085(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1410 error */
t2=*((C_word*)lf[480]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[481],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k10083 in k10077 in k10068 in a10062 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7295,2,t0,t1);}
t2=*((C_word*)lf[310]+1);
t3=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7297,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1431 make-vector */
t5=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7353,2,t0,t1);}
t2=C_mutate(&lf[311],t1);
t3=lf[312]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[313],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[314],t4);
t6=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7360,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[316]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7441,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7444,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[319]+1);
t10=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7485,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7520,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7536,a[2]=t11,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10061,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1481 initb */
f_7520(t13,lf[311]);}

/* k10059 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[478]);}

/* k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1502 ##sys#copy-env-table */
t3=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[311],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7540,2,t0,t1);}
t2=C_mutate(&lf[312],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7543,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10057,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1504 initb */
f_7520(t4,lf[312]);}

/* k10055 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[477]);}

/* k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7543,2,t0,t1);}
t2=C_set_block_item(lf[277],0,C_SCHEME_END_OF_LIST);
t3=*((C_word*)lf[322]+1);
t4=*((C_word*)lf[52]+1);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7547,tmp=(C_word)a,a+=2,tmp);
t6=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7566,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=*((C_word*)lf[137]+1);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7697,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7721,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t10=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7742,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(lf[329],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[142]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7796,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(lf[207],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[331]+1,*((C_word*)lf[142]+1));
t15=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7804,tmp=(C_word)a,a+=2,tmp));
t16=*((C_word*)lf[52]+1);
t17=*((C_word*)lf[333]+1);
t18=*((C_word*)lf[332]+1);
t19=*((C_word*)lf[334]+1);
t20=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7840,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,tmp=(C_word)a,a+=6,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8232,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9963,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1671 ##sys#register-macro-2 */
t23=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[114],t22);}

/* a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9963(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9963,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9969,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9969(t6,t1,t2);}

/* loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_9969(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9969,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10010,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1682 ##sys#check-syntax */
t7=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[114],t3,lf[472]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10023,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1686 ##sys#check-syntax */
t7=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[114],t3,lf[474]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9985,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1678 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[114],t3,lf[349]);}}

/* k9983 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1679 ##sys#check-syntax */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[114],((C_word*)t0)[4],lf[476]);}

/* k9986 in k9983 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9988,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_u_i_car(((C_word*)t0)[4]):lf[475]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[76],((C_word*)t0)[2],t3));}

/* k10021 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1687 ##sys#check-syntax */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[114],((C_word*)t0)[2],lf[473]);}

/* k10024 in k10021 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10026,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10037,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10041,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* ##sys#cons */
t6=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* k10039 in k10024 in k10021 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k10035 in k10024 in k10021 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10037,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[76],((C_word*)t0)[2],t1));}

/* k10008 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1683 ##sys#check-syntax */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[114],((C_word*)t0)[2],lf[471]);}

/* k10011 in k10008 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10020,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1684 ##sys#expand-curried-define */
t3=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10018 in k10011 in k10008 in loop in a9962 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_10020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1684 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9969(t2,((C_word*)t0)[2],t1);}

/* k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8235,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9935,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1690 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[470],t3);}

/* a9934 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9935(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9935,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9961,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#cons */
t8=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[470],t4);}}}

/* k9959 in a9934 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9961,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[148],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[91]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9892,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1701 ##sys#register-macro-2 */
t5=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[461],t4);}

/* a9891 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9892,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9914,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1711 gensym */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}}

/* k9912 in a9891 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9914,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9929,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#cons */
t5=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[461],((C_word*)t0)[2]);}

/* k9927 in k9912 in a9891 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9929,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[148],((C_word*)t0)[4],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[62],((C_word*)t0)[2],t2));}

/* k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8241,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[91]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9751,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1715 ##sys#register-macro-2 */
t5=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[467],t4);}

/* a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9751,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9757,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9757(t6,t1,t2);}

/* expand in a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_9757(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9757,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9773,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1724 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[467],t3,lf[468]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[469]);}}

/* k9771 in expand in a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9773,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[460],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1725 ##sys#cons */
t5=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[113],t4);}
else{
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_u_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9803,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1726 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_9757(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_eqp(lf[466],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1728 gensym */
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=(C_word)C_u_i_car(((C_word*)t0)[6]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9862,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t9,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1725 ##sys#cons */
t12=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[113],t11);}}}}

/* k9860 in k9771 in expand in a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9866,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1735 expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9757(t3,t2,((C_word*)t0)[2]);}

/* k9864 in k9860 in k9771 in expand in a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9866,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[148],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9810 in k9771 in expand in a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9812,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t6=(C_word)C_slot(t5,C_fix(1));
t7=(C_word)C_u_i_car(t6);
t8=(C_word)C_a_i_list(&a,2,t7,t1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9831,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1732 expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_9757(t10,t9,((C_word*)t0)[2]);}

/* k9829 in k9810 in k9771 in expand in a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9831,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[148],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[62],((C_word*)t0)[2],t2));}

/* k9801 in k9771 in expand in a9750 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9803,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[461],((C_word*)t0)[2],t1));}

/* k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[91]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9648,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1737 ##sys#register-macro-2 */
t5=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[463],t4);}

/* a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9648(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9648,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9658,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1743 gensym */
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9658,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9669,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9671,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_9671(t8,t4,((C_word*)t0)[2]);}

/* expand in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_9671(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9671,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9687,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1750 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[463],t3,lf[464]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[465]);}}

/* k9685 in expand in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9687,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[460],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1745 ##sys#cons */
t5=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[113],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9707,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9723,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 1753 ##sys#map */
t8=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}}

/* a9724 in k9685 in expand in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9725(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9725,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[98],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[462],((C_word*)t0)[2],t3));}

/* k9721 in k9685 in expand in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1745 ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[461],t1);}

/* k9705 in k9685 in expand in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 1745 ##sys#cons */
t4=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[113],t3);}

/* k9709 in k9705 in k9685 in expand in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9715,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1755 expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9671(t3,t2,((C_word*)t0)[2]);}

/* k9713 in k9709 in k9705 in k9685 in expand in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9715,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[148],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9667 in k9656 in a9647 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9669,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[62],((C_word*)t0)[2],t1));}

/* k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9595,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1757 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[96],t3);}

/* a9594 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9595,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9605,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1762 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[96],t3,lf[459]);}

/* k9603 in a9594 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1763 ##sys#check-syntax */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[96],((C_word*)t0)[4],lf[458]);}

/* k9606 in k9603 in a9594 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9608,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9613,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_9613(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k9606 in k9603 in a9594 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_9613(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9613,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9627,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1764 ##sys#cons */
t5=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9638,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1767 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k9636 in expand in k9606 in k9603 in a9594 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9638,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[62],((C_word*)t0)[2],t1));}

/* k9625 in expand in k9606 in k9603 in a9594 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1764 ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8250,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9525,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1769 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[65],t3);}

/* a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9525,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9535,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1774 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[65],t3,lf[457]);}

/* k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1775 ##sys#check-syntax */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[65],((C_word*)t0)[3],lf[456]);}

/* k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9545,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9585,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1776 ##sys#map */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9584 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9585(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9585,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[455]));}

/* k9547 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9553,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9557,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9571,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1777 ##sys#map */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9570 in k9547 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9571,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_u_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[76],t3,t4));}

/* k9555 in k9547 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9565,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9569,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#cons */
t4=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* k9567 in k9555 in k9547 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k9563 in k9555 in k9547 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9565,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9551 in k9547 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9543 in k9536 in k9533 in a9524 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8253,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[91]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9406,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1780 ##sys#register-macro */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[452],t4);}

/* a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9406(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_9406r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9406r(t0,t1,t2,t3,t4);}}

static void f_9406r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9410,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1784 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[452],t2,lf[454]);}

/* k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1785 ##sys#check-syntax */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[452],((C_word*)t0)[6],lf[453]);}

/* k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1786 gensym */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[451]);}

/* k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9507,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1787 ##sys#map */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a9506 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9507,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_u_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9423,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[6]);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9438,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_9438(2,t6,lf[450]);}
else{
/* ##sys#cons */
t6=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[113],t3);}}

/* k9436 in k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9446,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_9446(2,t4,lf[449]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9499,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#cons */
t5=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}}

/* k9497 in k9436 in k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k9444 in k9436 in k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9454,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9458,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9460,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1798 ##sys#map */
t6=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9459 in k9444 in k9436 in k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9460,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_u_i_car(t2));}
else{
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_u_i_car(t7));}}

/* k9456 in k9444 in k9436 in k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9452 in k9444 in k9436 in k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[64],t1);}

/* k9448 in k9444 in k9436 in k9421 in k9414 in k9411 in k9408 in a9405 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9450,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[113],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,4,lf[148],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[62],((C_word*)t0)[3],((C_word*)t0)[2],t3));}

/* k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8256,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[290]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9114,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1804 ##sys#register-macro */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[439],t4);}

/* a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9114,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9117,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9127,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9324,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
/* eval.scm: 1865 walk */
t12=((C_word*)t4)[1];
f_9117(t12,t1,t2,C_fix(0));}

/* simplify in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_9324(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9324,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9328,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1852 ##sys#match-expression */
t4=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[447],lf[448]);}

/* k9326 in simplify in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9328,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[441],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[436],t3);
/* eval.scm: 1853 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9324(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1854 ##sys#match-expression */
t3=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[445],lf[446]);}}

/* k9347 in k9326 in simplify in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9349,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[442],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9368,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9372,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_u_i_assq(lf[441],t1);
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_slot(t2,C_fix(1));
/* ##sys#cons */
t9=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t5,t7,t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1861 ##sys#match-expression */
t3=*((C_word*)lf[126]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[443],lf[444]);}}

/* k9389 in k9347 in k9326 in simplify in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(lf[441],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9370 in k9347 in k9326 in simplify in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[436],t1);}

/* k9366 in k9347 in k9326 in simplify in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1858 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9324(t2,((C_word*)t0)[2],t1);}

/* walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_9127(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9127,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9141,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9145,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1814 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[435]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9188,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1826 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_9117(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[438]);}}
else{
t7=(C_word)C_eqp(t4,lf[439]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[98],lf[439]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9215,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1831 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_9117(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[98],lf[439]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9234,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1832 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_9117(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[440]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9268,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1843 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_9117(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[98],lf[440]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9287,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1845 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_9117(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9298,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1847 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_9117(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9315,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1848 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_9117(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[98],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[98],t2));}}

/* k9313 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9319,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1848 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9117(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9317 in k9313 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9319,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[63],((C_word*)t0)[2],t1));}

/* k9296 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9302,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1847 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9117(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9300 in k9296 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9302,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[63],((C_word*)t0)[2],t1));}

/* k9285 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9287,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[436],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9279,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1846 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9117(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9277 in k9285 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9279,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[63],((C_word*)t0)[2],t1));}

/* k9266 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9268,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[84],((C_word*)t0)[2],t1));}

/* k9232 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9234,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[63],((C_word*)t0)[2],t1));}

/* k9213 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9215,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[436],((C_word*)t0)[2],t1));}

/* k9186 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[436],lf[437],t1));}

/* k9143 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1814 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9117(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9139 in walk1 in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9141,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[434],t1));}

/* walk in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_9117(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9117,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9125,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1809 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9127(t5,t4,t2,t3);}

/* k9123 in walk in a9113 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1809 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9324(t2,((C_word*)t0)[2],t1);}

/* k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8259,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9104,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1867 ##sys#register-macro */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[433],t3);}

/* a9103 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9104,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[432],t3));}

/* k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1874 append */
t3=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[431],*((C_word*)lf[182]+1));}

/* k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8263,2,t0,t1);}
t2=C_mutate((C_word*)lf[182]+1,t1);
t3=C_mutate((C_word*)lf[364]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8265,tmp=(C_word)a,a+=2,tmp));
t4=C_set_block_item(lf[365],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[366],0,C_SCHEME_FALSE);
t6=C_set_block_item(lf[367],0,C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9101,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1887 make-parameter */
t9=*((C_word*)lf[430]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a9100 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9101,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[429]);}

/* k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8279,2,t0,t1);}
t2=C_mutate((C_word*)lf[368]+1,t1);
t3=*((C_word*)lf[137]+1);
t4=*((C_word*)lf[368]+1);
t5=C_mutate((C_word*)lf[369]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8281,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t6=*((C_word*)lf[206]+1);
t7=*((C_word*)lf[220]+1);
t8=*((C_word*)lf[134]+1);
t9=*((C_word*)lf[61]+1);
t10=*((C_word*)lf[137]+1);
t11=*((C_word*)lf[372]+1);
t12=C_mutate((C_word*)lf[373]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8297,a[2]=t9,a[3]=t7,a[4]=t6,a[5]=t10,a[6]=t8,tmp=(C_word)a,a+=7,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8504,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1974 make-vector */
t14=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8504,2,t0,t1);}
t2=C_mutate((C_word*)lf[386]+1,t1);
t3=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8506,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[388]+1);
t5=*((C_word*)lf[389]+1);
t6=*((C_word*)lf[220]+1);
t7=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8512,a[2]=t4,a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8587,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8976,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2004 ##sys#register-macro */
t10=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[425],t9);}

/* a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8976(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr3r,(void*)f_8976r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8976r(t0,t1,t2,t3);}}

static void f_8976r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(14);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8979,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9067,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2015 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[425],t3,lf[426]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9077,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2018 ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[425],t2,lf[428]);}}

/* k9075 in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2019 ##sys#check-syntax */
t3=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[425],((C_word*)t0)[2],lf[427]);}

/* k9078 in k9075 in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9080,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9091,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9095,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* ##sys#cons */
t6=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* k9093 in k9078 in k9075 in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k9089 in k9078 in k9075 in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2020 expand */
f_8979(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9065 in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_car(((C_word*)t0)[5]);
/* eval.scm: 2016 expand */
f_8979(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8979(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8979,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8983,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(lf[99],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_u_i_cadr(t3);
t9=t4;
f_8983(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_8983(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_8983(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_8983(t5,C_SCHEME_FALSE);}}

/* k8981 in expand in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8983(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8983,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[82]+1))?lf[173]:lf[172]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8994,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[98],((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9005,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9009,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* ##sys#cons */
t10=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t6,t8,t9);}
else{
t4=(C_word)C_a_i_list(&a,2,lf[98],((C_word*)t0)[3]);
t5=t3;
f_8994(t5,(C_word)C_a_i_list(&a,3,lf[48],t4,((C_word*)t0)[2]));}}

/* k9007 in k8981 in expand in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k9003 in k8981 in expand in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_9005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9005,2,t0,t1);}
t2=((C_word*)t0)[3];
f_8994(t2,(C_word)C_a_i_list(&a,3,lf[46],((C_word*)t0)[2],t1));}

/* k8992 in k8981 in expand in a8975 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8994,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8590,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8957,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2022 ##sys#register-macro */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[305],t3);}

/* a8956 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8957(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8957r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8957r(t0,t1,t2);}}

static void f_8957r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8961,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2025 ##sys#check-syntax */
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[305],t2,lf[424]);}

/* k8959 in a8956 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8968,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8970,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a8969 in k8959 in a8956 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8970,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[98],t2));}

/* k8966 in k8959 in a8956 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[169],t1);}

/* k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8593,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8951,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2031 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[422],t3);}

/* a8950 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8951,3,t0,t1,t2);}
/* eval.scm: 2034 ##sys#syntax-error-hook */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[422],lf[423]);}

/* k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8596,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8945,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2036 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[420],t3);}

/* a8944 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8945,3,t0,t1,t2);}
/* eval.scm: 2039 ##sys#syntax-error-hook */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[420],lf[421]);}

/* k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8596,2,t0,t1);}
t2=C_mutate((C_word*)lf[393]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8598,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8623,tmp=(C_word)a,a+=2,tmp));
t4=lf[397]=C_SCHEME_FALSE;;
t5=C_mutate(&lf[398],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8649,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[402],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8708,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[404],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8717,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[406],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8729,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[407],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8745,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[409],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8771,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[411],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8784,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[412],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8810,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[413],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8847,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[414]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8863,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[415],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8889,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[416],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8911,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[417],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8926,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8936,tmp=(C_word)a,a+=2,tmp));
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8936,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8943,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2175 ##sys#make-string */
t5=*((C_word*)lf[419]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8941 in ##sys#make-lambda-info in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8926,4,t0,t1,t2,t3);}
t4=lf[397];
t5=(C_truep(t4)?t4:lf[418]);
/* eval.scm: 2168 store-string */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_8771(t5,t3,t2));}

/* CHICKEN_load in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8911,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8915,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k8913 in CHICKEN_load in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8920,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2165 run-safe */
f_8649(((C_word*)t0)[2],t2);}

/* a8919 in k8913 in CHICKEN_load in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8924,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2165 load */
t3=*((C_word*)lf[229]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8922 in a8919 in k8913 in CHICKEN_load in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8889,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8893,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k8891 in CHICKEN_read in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8893,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8898,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2159 run-safe */
f_8649(((C_word*)t0)[2],t3);}

/* a8897 in k8891 in CHICKEN_read in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8902,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2161 open-input-string */
t3=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8900 in a8897 in k8891 in CHICKEN_read in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2162 read */
t3=*((C_word*)lf[220]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k8907 in k8900 in a8897 in k8891 in CHICKEN_read in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2162 store-result */
f_8708(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8863(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8863,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8869,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2152 run-safe */
f_8649(t1,t6);}

/* a8868 in CHICKEN_apply_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2154 open-output-string */
t3=*((C_word*)lf[401]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8871 in a8868 in CHICKEN_apply_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8876,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8887,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8885 in k8871 in a8868 in CHICKEN_apply_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2155 write */
t2=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8874 in k8871 in a8868 in CHICKEN_apply_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8883,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2156 get-output-string */
t3=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8881 in k8874 in k8871 in a8868 in CHICKEN_apply_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2156 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_8771(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8847,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8853,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2147 run-safe */
f_8649(t1,t5);}

/* a8852 in CHICKEN_apply in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8853,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8861,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8859 in a8852 in CHICKEN_apply in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2147 store-result */
f_8708(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8810,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8814,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8814,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8819,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2138 run-safe */
f_8649(((C_word*)t0)[2],t4);}

/* a8818 in k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2140 open-output-string */
t3=*((C_word*)lf[401]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8821 in a8818 in k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8826,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8837,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8841,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8845,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2141 open-input-string */
t6=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k8843 in k8821 in a8818 in k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2141 read */
t2=*((C_word*)lf[220]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8839 in k8821 in a8818 in k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2141 eval */
t2=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8835 in k8821 in a8818 in k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2141 write */
t2=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8824 in k8821 in a8818 in k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2142 get-output-string */
t3=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8831 in k8824 in k8821 in a8818 in k8812 in CHICKEN_eval_string_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2142 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_8771(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8784(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8784,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8790,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2129 run-safe */
f_8649(t1,t5);}

/* a8789 in CHICKEN_eval_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2131 open-output-string */
t3=*((C_word*)lf[401]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8792 in a8789 in CHICKEN_eval_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8797,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8808,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2132 eval */
t4=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k8806 in k8792 in a8789 in CHICKEN_eval_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2132 write */
t2=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8795 in k8792 in a8789 in CHICKEN_eval_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2133 get-output-string */
t3=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8802 in k8795 in k8792 in a8789 in CHICKEN_eval_to_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2133 store-string */
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_8771(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static C_word C_fcall f_8771(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[397],lf[410]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8745(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8745,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8749,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k8747 in CHICKEN_eval_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8749,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8754,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2110 run-safe */
f_8649(((C_word*)t0)[2],t3);}

/* a8753 in k8747 in CHICKEN_eval_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8758,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2112 open-input-string */
t3=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8756 in a8753 in k8747 in CHICKEN_eval_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8769,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2113 read */
t4=*((C_word*)lf[220]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k8767 in k8756 in a8753 in k8747 in CHICKEN_eval_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2113 eval */
t2=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8763 in k8756 in a8753 in k8747 in CHICKEN_eval_string in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2113 store-result */
f_8708(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8729(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8729,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8735,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2105 run-safe */
f_8649(t1,t4);}

/* a8734 in CHICKEN_eval in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8735,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8743,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2107 eval */
t3=*((C_word*)lf[206]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8741 in a8734 in CHICKEN_eval in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2107 store-result */
f_8708(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8723,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 2102 run-safe */
f_8649(t1,t2);}

/* a8722 in CHICKEN_yield in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8727,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2102 thread-yield! */
t3=*((C_word*)lf[405]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8725 in a8722 in CHICKEN_yield in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8708(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8708,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8712,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2096 ##sys#gc */
t5=*((C_word*)lf[403]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_FALSE);}

/* k8710 in store-result in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8649(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8649,NULL,2,t1,t2);}
t3=lf[397]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8657,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8659,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2084 call-with-current-continuation */
t6=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8659,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8684,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2084 with-exception-handler */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a8683 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8690,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2084 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a8695 in a8683 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8696(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_8696r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8696r(t0,t1,t2);}}

static void f_8696r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8702,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2084 g1340 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a8701 in a8695 in a8683 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8702,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a8689 in a8683 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8690,2,t0,t1);}
/* eval.scm: 2089 thunk */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a8664 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8665,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8671,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2084 g1340 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a8670 in a8664 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8675,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2085 open-output-string */
t3=*((C_word*)lf[401]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8673 in a8670 in a8664 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8678,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2086 print-error-message */
t3=*((C_word*)lf[400]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k8676 in k8673 in a8670 in a8664 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8682,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2087 get-output-string */
t3=*((C_word*)lf[399]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8680 in k8676 in k8673 in a8670 in a8664 in a8658 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[397],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k8655 in run-safe in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* set-dispatch-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8623,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8627,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[396]+1))){
t5=t4;
f_8627(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8646,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2059 make-vector */
t6=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(256),C_SCHEME_FALSE);}}

/* k8644 in set-dispatch-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[396]+1,t1);
t3=((C_word*)t0)[2];
f_8627(t3,t2);}

/* k8625 in set-dispatch-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8627(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8627,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8635,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(*((C_word*)lf[396]+1),t2,t3));}

/* a8634 in k8625 in set-dispatch-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8635(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8635,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8639,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2067 ##sys#read-char-0 */
t5=*((C_word*)lf[381]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8637 in a8634 in k8625 in set-dispatch-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2068 proc */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8598,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8602,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[394]+1))){
t5=t4;
f_8602(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8621,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2046 make-vector */
t6=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_fix(256),C_SCHEME_FALSE);}}

/* k8619 in set-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[394]+1,t1);
t3=((C_word*)t0)[2];
f_8602(t3,t2);}

/* k8600 in set-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8602(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8602,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[4]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8610,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_setslot(*((C_word*)lf[394]+1),t2,t3));}

/* a8609 in k8600 in set-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8610,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8614,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2054 ##sys#read-char-0 */
t5=*((C_word*)lf[381]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k8612 in a8609 in k8600 in set-read-syntax! in k8594 in k8591 in k8588 in k8585 in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2055 proc */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8512,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1987 read-char */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* eval.scm: 1999 old */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k8520 in ##sys#user-read-hook in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1988 read */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k8523 in k8520 in ##sys#user-read-hook in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8526,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_8539(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_8539(t6,(C_word)C_i_not(t5));}}

/* k8537 in k8523 in k8520 in ##sys#user-read-hook in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8539,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1991 err */
t2=((C_word*)t0)[5];
f_8526(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8557,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1995 ##sys#hash-table-ref */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[386]+1),t2);}
else{
/* eval.scm: 1994 err */
t3=((C_word*)t0)[5];
f_8526(t3,((C_word*)t0)[4]);}}}

/* k8555 in k8537 in k8523 in k8520 in ##sys#user-read-hook in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 1998 ##sys#read-error */
t2=*((C_word*)lf[390]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[392],((C_word*)t0)[2]);}}

/* err in k8523 in k8520 in ##sys#user-read-hook in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8526(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8526,NULL,2,t0,t1);}
/* eval.scm: 1989 ##sys#read-error */
t2=*((C_word*)lf[390]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[391],((C_word*)t0)[2]);}

/* define-reader-ctor in k8502 in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8506,4,t0,t1,t2,t3);}
/* eval.scm: 1978 ##sys#hash-table-set! */
t4=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[386]+1),t2,t3);}

/* repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8300,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8315,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[376]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[371]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[377]+1);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8344,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=t10,a[10]=t8,a[11]=t6,tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1919 ##sys#error-handler */
t12=*((C_word*)lf[380]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}

/* k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8347,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1920 ##sys#reset-handler */
t3=*((C_word*)lf[385]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8355,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8364,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8410,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8493,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1932 ##sys#dynamic-wind */
t7=*((C_word*)lf[233]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[2],t4,t5,t6);}

/* a8492 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8497,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1968 ##sys#error-handler */
t3=*((C_word*)lf[380]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8495 in a8492 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1969 ##sys#reset-handler */
t2=*((C_word*)lf[385]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8410,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_8416(t5,t1);}

/* loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8416,NULL,2,t0,t1);}
t2=f_8349(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8423,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8474,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1949 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8473 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8474(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8474,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8480,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1951 ##sys#reset-handler */
t4=*((C_word*)lf[385]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a8479 in a8473 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8480,2,t0,t1);}
t2=C_set_block_item(lf[225],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[383],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[384],0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[249],0,C_SCHEME_FALSE);
t6=f_8355(((C_word*)t0)[3]);
/* eval.scm: 1958 c */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,C_SCHEME_FALSE);}

/* k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1959 ##sys#read-prompt-hook */
t3=*((C_word*)lf[369]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8424 in k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[367]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k8427 in k8424 in k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8429,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8438,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8469,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1962 ##sys#peek-char-0 */
t4=*((C_word*)lf[382]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,*((C_word*)lf[376]+1));}}

/* k8467 in k8427 in k8424 in k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 1963 ##sys#read-char-0 */
t3=*((C_word*)lf[381]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[376]+1));}
else{
t3=((C_word*)t0)[2];
f_8438(2,t3,C_SCHEME_UNDEFINED);}}

/* k8436 in k8427 in k8424 in k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8443,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8452,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1964 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8451 in k8436 in k8427 in k8424 in k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8452(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8452r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8452r(t0,t1,t2);}}

static void f_8452r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8456,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1965 write-results */
t4=((C_word*)t0)[2];
f_8321(t4,t3,t2);}

/* k8454 in a8451 in k8436 in k8427 in k8424 in k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1966 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8416(t2,((C_word*)t0)[2]);}

/* a8442 in k8436 in k8427 in k8424 in k8421 in loop in a8409 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8443,2,t0,t1);}
t2=*((C_word*)lf[365]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,((C_word*)t0)[2]);}

/* a8363 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1934 ##sys#error-handler */
t3=*((C_word*)lf[380]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* a8369 in a8363 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8370(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8370r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8370r(t0,t1,t2,t3);}}

static void f_8370r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=f_8355(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8377,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1937 display */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[379]);}

/* k8375 in a8369 in a8363 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1938 display */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8378 in k8375 in a8369 in a8363 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=t2;
f_8386(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_8386(t3,C_SCHEME_FALSE);}}

/* k8384 in k8378 in k8375 in a8369 in a8363 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8386,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1941 display */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[378]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8395,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1944 ##sys#write-char-0 */
t3=*((C_word*)lf[374]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[371]+1));}}

/* k8393 in k8384 in k8378 in k8375 in a8369 in a8363 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1945 write-err */
t2=((C_word*)t0)[4];
f_8315(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8387 in k8384 in k8378 in k8375 in a8369 in a8363 in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1942 write-err */
t2=((C_word*)t0)[4];
f_8315(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* resetports in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static C_word C_fcall f_8355(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate((C_word*)lf[376]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[371]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[377]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k8345 in k8342 in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static C_word C_fcall f_8349(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[376]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[371]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[377]+1));
return(t3);}

/* write-results in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8321,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8331,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8331(t5,t3);}
else{
t5=(C_word)C_u_i_car(t2);
t6=t4;
f_8331(t6,(C_word)C_eqp(C_SCHEME_UNDEFINED,t5));}}

/* k8329 in write-results in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8331(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* write-err in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8315,NULL,3,t0,t1,t2);}
/* for-each */
t3=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* write-one in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8300,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8304,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8309,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1906 ##sys#with-print-length-limit */
t5=*((C_word*)lf[375]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,*((C_word*)lf[366]+1),t4);}

/* a8308 in write-one in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8309,2,t0,t1);}
/* write1240 */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k8302 in write-one in repl in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1907 ##sys#write-char-0 */
t2=*((C_word*)lf[374]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[371]+1));}

/* ##sys#read-prompt-hook in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8285,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8292,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1893 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8293 in ##sys#read-prompt-hook in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8290 in ##sys#read-prompt-hook in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1893 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8283 in ##sys#read-prompt-hook in k8277 in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1894 ##sys#flush-output */
t2=*((C_word*)lf[370]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[371]+1));}

/* ##sys#test-feature in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8265(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8265,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8269,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1877 ##sys#->feature-id */
t4=*((C_word*)lf[263]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8267 in ##sys#test-feature in k8261 in k8257 in k8254 in k8251 in k8248 in k8245 in k8242 in k8239 in k8236 in k8233 in k8230 in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1)));}

/* ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7840r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7840r(t0,t1,t2,t3,t4,t5);}}

static void f_7840r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(24);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7855,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7843,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7948,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7977,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_slot(t5,C_fix(0));
t12=C_mutate((C_word*)lf[207]+1,t11);
t13=t10;
f_7977(t13,t12);}
else{
t11=t10;
f_7977(t11,C_SCHEME_UNDEFINED);}}

/* k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7977,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7982,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7982(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7982(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(19);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7982,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7998,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_7998(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_7998(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[343]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[344]);
if(C_truep(t7)){
/* eval.scm: 1654 test */
t8=((C_word*)t0)[4];
f_7843(t8,t1,t2,*((C_word*)lf[345]+1),lf[346]);}
else{
t8=(C_word)C_eqp(t5,lf[347]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8127,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1655 test */
t10=((C_word*)t0)[4];
f_7843(t10,t1,t2,t9,lf[348]);}
else{
t9=(C_word)C_eqp(t5,lf[349]);
if(C_truep(t9)){
/* eval.scm: 1656 test */
t10=((C_word*)t0)[4];
f_7843(t10,t1,t2,*((C_word*)lf[350]+1),lf[351]);}
else{
t10=(C_word)C_eqp(t5,lf[352]);
if(C_truep(t10)){
/* eval.scm: 1657 test */
t11=((C_word*)t0)[4];
f_7843(t11,t1,t2,((C_word*)t0)[3],lf[353]);}
else{
t11=(C_word)C_eqp(t5,lf[354]);
if(C_truep(t11)){
/* eval.scm: 1658 test */
t12=((C_word*)t0)[4];
f_7843(t12,t1,t2,*((C_word*)lf[355]+1),lf[356]);}
else{
t12=(C_word)C_eqp(t5,lf[322]);
if(C_truep(t12)){
/* eval.scm: 1659 test */
t13=((C_word*)t0)[4];
f_7843(t13,t1,t2,*((C_word*)lf[357]+1),lf[358]);}
else{
t13=(C_word)C_eqp(t5,lf[359]);
if(C_truep(t13)){
/* eval.scm: 1660 test */
t14=((C_word*)t0)[4];
f_7843(t14,t1,t2,((C_word*)t0)[2],lf[360]);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8181,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1661 test */
t15=((C_word*)t0)[4];
f_7843(t15,t1,t2,t14,lf[361]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1663 err */
t7=((C_word*)t0)[6];
f_7855(t7,t1,lf[362]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8200,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1665 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1650 err */
t6=((C_word*)t0)[6];
f_7855(t6,t1,lf[363]);}}}}

/* k8198 in walk in k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1666 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7982(t4,((C_word*)t0)[2],t2,t3);}

/* a8180 in walk in k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8181(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8181,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8126 in walk in k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8127,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k7996 in walk in k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7998(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7998,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8003,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8003(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1114 in k7996 in walk in k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_8003(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8003,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1643 err */
t5=((C_word*)t0)[6];
f_7855(t5,t1,lf[340]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8022,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1645 err */
t6=((C_word*)t0)[6];
f_7855(t6,t5,lf[341]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1647 err */
t8=((C_word*)t0)[6];
f_7855(t8,t5,lf[342]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1648 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_7982(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8020 in do1114 in k7996 in walk in k7975 in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8003(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7948(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7948,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7954,tmp=(C_word)a,a+=2,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_7954(t2));}

/* loop in proper-list? in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static C_word C_fcall f_7954(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7886,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7890,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1610 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7888 in lambda-list? in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7890,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7898,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7898(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k7888 in lambda-list? in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7898,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7921,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1614 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1619 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k7919 in loop in k7888 in lambda-list? in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7843,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7850,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1598 pred */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k7848 in test in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1598 err */
t2=((C_word*)t0)[3];
f_7855(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7855,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[207]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1602 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k7857 in err in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7873,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1605 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7884,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1606 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}

/* k7882 in k7857 in err in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1606 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[338],t1,lf[339],((C_word*)t0)[2]);}

/* k7871 in k7857 in err in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7877,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1605 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k7875 in k7871 in k7857 in err in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1605 string-append */
t2=((C_word*)t0)[5];
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[4],lf[335],((C_word*)t0)[3],lf[336],t1,lf[337],((C_word*)t0)[2]);}

/* k7864 in k7857 in err in ##sys#check-syntax in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1603 ##sys#syntax-error-hook */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7804,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[329]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7826,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1584 ##sys#hash-table-ref */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[329]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7824 in get-line-number in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_u_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7796(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_7796r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7796r(t0,t1,t2);}}

static void f_7796r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[218]+1),lf[330],t2);}

/* ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7742,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7746,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1559 display-rj */
t5=((C_word*)t0)[2];
f_7721(t5,t3,t4,C_fix(8));}

/* k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1560 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[328]);}

/* k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1561 display-rj */
t4=((C_word*)t0)[2];
f_7721(t4,t2,t3,C_fix(8));}

/* k7750 in k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1562 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[327]);}

/* k7753 in k7750 in k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7755,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1563 display-rj */
t4=((C_word*)t0)[2];
f_7721(t4,t2,t3,C_fix(8));}

/* k7756 in k7753 in k7750 in k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1564 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[326]);}

/* k7759 in k7756 in k7753 in k7750 in k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1565 display-rj */
t4=((C_word*)t0)[2];
f_7721(t4,t2,t3,C_fix(8));}

/* k7762 in k7759 in k7756 in k7753 in k7750 in k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1566 display */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[325]);}

/* k7765 in k7762 in k7759 in k7756 in k7753 in k7750 in k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7767,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7770,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1567 display-rj */
t4=((C_word*)t0)[2];
f_7721(t4,t2,t3,C_fix(8));}

/* k7768 in k7765 in k7762 in k7759 in k7756 in k7753 in k7750 in k7747 in k7744 in ##sys#display-times in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1568 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[324]);}

/* display-rj in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7721(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7721,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7725,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_7725(2,t5,lf[323]);}
else{
/* eval.scm: 1554 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k7723 in display-rj in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7725,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7728,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1556 spaces */
t5=((C_word*)t0)[2];
f_7697(t5,t3,t4);}

/* k7726 in k7723 in display-rj in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1557 display */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7697,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_7703(t6,t1,t2);}

/* do1044 in spaces in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7703(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7703,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7713,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1551 display */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(32));}}

/* k7711 in do1044 in spaces in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7703(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7566(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7566r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7566r(t0,t1,t2,t3,t4);}}

static void f_7566r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7570(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_i_nullp(t6);
t8=t5;
f_7570(t8,(C_truep(t7)?(C_word)C_u_i_car(t4):C_SCHEME_TRUE));}}

/* k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7570(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7570,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7572,a[2]=t3,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7607,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7624,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1532 test */
t7=t5;
f_7607(t7,t6,((C_word*)t0)[4]);}

/* k7622 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7624,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7634,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7679,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1534 ##sys#repository-path */
t4=*((C_word*)lf[273]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_7634(2,t3,*((C_word*)lf[277]+1));}}}

/* k7677 in k7622 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7679,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1534 ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[277]+1),t2);}

/* k7632 in k7622 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7634,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7636(t5,((C_word*)t0)[2],t1);}

/* loop in k7632 in k7622 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7636(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7636,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7646,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7660,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1538 string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,*((C_word*)lf[43]+1));}}

/* k7666 in loop in k7632 in k7622 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1537 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7658 in loop in k7632 in k7622 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1537 test */
t2=((C_word*)t0)[3];
f_7607(t2,((C_word*)t0)[2],t1);}

/* k7644 in loop in k7632 in k7622 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1540 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7636(t3,((C_word*)t0)[4],t2);}}

/* test in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7607,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[20],*((C_word*)lf[244]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[244]+1),lf[20]));
/* eval.scm: 1527 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7572(t4,t1,t2,t3);}

/* test2 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7572(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7572,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7585,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1521 exists? */
f_7547(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7588,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_u_i_car(t3);
/* eval.scm: 1522 ##sys#string-append */
t6=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t2,t5);}}

/* k7586 in test2 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1523 exists? */
f_7547(t2,t1);}

/* k7592 in k7586 in test2 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1525 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7572(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k7583 in test2 in k7568 in ##sys#resolve-include-filename in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7547(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7547,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7551,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1516 ##sys#file-info */
t4=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7549 in exists? in k7541 in k7538 in k7534 in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7520(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7520,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7522,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_7522 in initb in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7522(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7522,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7526,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1478 ##sys#hash-table-location */
t4=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7524 */
static void f_7526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7485(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7485r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7485r(t0,t1,t2,t3);}}

static void f_7485r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7489,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_fixnum_lessp(t2,C_fix(4));
t6=(C_truep(t5)?t5:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t6)){
/* eval.scm: 1469 ##sys#error */
t7=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,lf[320],lf[321],t2);}
else{
t7=t4;
f_7489(2,t7,C_SCHEME_UNDEFINED);}}

/* k7487 in null-environment in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7496,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1472 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7494 in k7487 in null-environment in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7496,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[313],t1,t3));}

/* scheme-report-environment in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7444(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7444r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7444r(t0,t1,t2,t3);}}

static void f_7444r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(8);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=t2;
switch(t6){
case C_fix(4):
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7461,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1460 ##sys#copy-env-table */
t8=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[311],C_SCHEME_TRUE,t5);
case C_fix(5):
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7474,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1461 ##sys#copy-env-table */
t8=*((C_word*)lf[315]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[312],C_SCHEME_TRUE,t5);
default:
/* eval.scm: 1462 ##sys#error */
t7=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,lf[317],lf[318],t2);}}

/* k7472 in scheme-report-environment in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7474,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[313],t1,((C_word*)t0)[2]));}

/* k7459 in scheme-report-environment in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7461,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[313],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7441,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[314]);}

/* ##sys#copy-env-table in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7360(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7360,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7367,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1438 ##sys#make-vector */
t7=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,C_SCHEME_END_OF_LIST);}

/* k7365 in ##sys#copy-env-table in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7367,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7372,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_7372(t5,((C_word*)t0)[2],C_fix(0));}

/* do986 in k7365 in ##sys#copy-env-table in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7372(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7372,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7393,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7399,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_7399(t8,t3,t4);}}

/* copy in do986 in k7365 in ##sys#copy-env-table in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7399(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7399,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t7=(C_word)C_a_i_vector(&a,3,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7420,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1451 copy */
t11=t8;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k7418 in copy in do986 in k7365 in ##sys#copy-env-table in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7420,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7391 in do986 in k7365 in ##sys#copy-env-table in k7351 in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7372(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7301,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1420 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7299 in ##sys#string->c-identifier in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7301,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7309,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7309(t6,((C_word*)t0)[2],C_fix(0));}

/* do973 in k7299 in ##sys#string->c-identifier in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7309(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7309,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7329,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7329(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7329(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7327 in do973 in k7299 in ##sys#string->c-identifier in k7293 in k7290 in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7309(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7256(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7256,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_assq(t2,*((C_word*)lf[306]+1));
if(C_truep(t4)){
t5=(C_word)C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7271,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7285,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_a_i_cons(&a,2,t2,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,*((C_word*)lf[306]+1));
t8=C_mutate((C_word*)lf[306]+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* a7284 in set-extension-specifier! in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7285(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7285,3,t0,t1,t2);}
/* eval.scm: 1380 proc */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7270 in set-extension-specifier! in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7271,3,t0,t1,t2);}
/* eval.scm: 1378 proc */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6922,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6925,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6946,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7132,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_u_i_car(t2);
t8=t6;
f_7132(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7132(t7,C_SCHEME_FALSE);}}

/* k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7132,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_u_i_assq(t2,*((C_word*)lf[306]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1366 ##sys#error */
t4=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[307],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1368 doit */
t2=((C_word*)t0)[2];
f_6946(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1369 ##sys#error */
t2=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[308],((C_word*)t0)[6]);}}}

/* k7139 in k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7141,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[229],t1);
/* eval.scm: 1354 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1356 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}
else{
/* eval.scm: 1365 ##sys#do-the-right-thing */
t2=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7165 in k7139 in k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7167,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7169,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_7169(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7165 in k7139 in k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7169(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7169,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7183,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7187,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1360 reverse */
t7=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7192,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7202,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1361 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}}

/* a7201 in loop in k7165 in k7139 in k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7202,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1362 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7169(t7,t1,t4,t5,t6);}

/* a7191 in loop in k7165 in k7139 in k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7192,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[3]);
/* eval.scm: 1361 ##sys#do-the-right-thing */
t3=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7185 in loop in k7165 in k7139 in k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1304 ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[113],t1);}

/* k7181 in loop in k7165 in k7139 in k7130 in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1360 values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6946(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6946,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_memq(t2,lf[37]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_6956(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[4])){
t5=t4;
f_6956(2,t5,(C_word)C_u_i_memq(t2,lf[39]));}
else{
/* eval.scm: 1319 test-feature? */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}}

/* k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6956,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1320 values */
C_values(4,0,((C_word*)t0)[5],lf[297],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[298]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[299]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[300]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6968,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1322 ##sys#->feature-id */
t4=*((C_word*)lf[263]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],lf[30]))){
t3=(C_word)C_u_i_assq(((C_word*)t0)[4],lf[33]);
t4=(C_truep(t3)?(C_word)C_u_i_cadr(t3):((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7007,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7035,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7057,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_u_i_car(t3);
/* eval.scm: 1330 ##sys#->feature-id */
t9=*((C_word*)lf[263]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}
else{
t7=t6;
f_7035(t7,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1338 ##sys#extension-info */
t4=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],lf[305]);}}}}

/* k7065 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7067,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_u_i_assq(lf[304],t1);
t4=(C_truep(t3)?t3:(C_word)C_u_i_assq(lf[289],t1));
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,lf[98],((C_word*)t0)[3]);
t6=t2;
f_7077(t6,(C_word)C_a_i_list(&a,2,lf[165],t5));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7093,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1344 add-req */
t6=((C_word*)t0)[2];
f_6925(t6,t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7106,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1348 add-req */
t3=((C_word*)t0)[2];
f_6925(t3,t2,((C_word*)t0)[3]);}}

/* k7104 in k7065 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7106,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[167],t2);
/* eval.scm: 1349 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7091 in k7065 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7093,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_7077(t3,(C_word)C_a_i_list(&a,2,lf[167],t2));}

/* k7075 in k7065 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7077(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1340 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7055 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1));
t3=((C_word*)t0)[2];
f_7035(t3,(C_word)C_i_not(t2));}

/* k7033 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7035(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7035,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7042,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[2]);
/* eval.scm: 1331 ##sys#resolve-include-filename */
t4=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7007(2,t2,C_SCHEME_UNDEFINED);}}

/* k7040 in k7033 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1331 ##sys#load */
t2=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7005 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_7007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7014,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[303],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[98],t3);
t5=t2;
f_7014(t5,(C_word)C_a_i_list(&a,2,lf[179],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[98],((C_word*)t0)[2]);
t4=t2;
f_7014(t4,(C_word)C_a_i_list(&a,2,lf[264],t3));}}

/* k7012 in k7005 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_7014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1332 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k6966 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6971,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1)))){
t3=t2;
f_6971(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6980,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6988,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6992,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1324 ##sys#symbol->string */
t6=*((C_word*)lf[270]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k6990 in k6966 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1324 ##sys#resolve-include-filename */
t2=*((C_word*)lf[302]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k6986 in k6966 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1324 ##sys#load */
t2=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k6978 in k6966 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6980,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[182]+1));
t3=C_mutate((C_word*)lf[182]+1,t2);
t4=((C_word*)t0)[2];
f_6971(t4,t3);}

/* k6969 in k6966 in k6954 in doit in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1326 values */
C_values(4,0,((C_word*)t0)[2],lf[301],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6925,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6940,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1310 hash-table-update! */
t5=*((C_word*)lf[294]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,*((C_word*)lf[295]+1),lf[296],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6939 in add-req in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6940,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a6933 in add-req in ##sys#do-the-right-thing in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6934,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[292]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[293]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6873,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6879,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6879(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6879(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6879,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6893,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_u_i_car(t2);
/* eval.scm: 1298 ##sys#extension-info */
t5=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k6891 in loop1 in ##sys#lookup-runtime-requirements in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_u_i_assq(lf[289],t1);
t4=t2;
f_6896(t4,(C_truep(t3)?(C_word)C_slot(t3,C_fix(1)):C_SCHEME_FALSE));}
else{
t3=t2;
f_6896(t3,C_SCHEME_FALSE);}}

/* k6894 in k6891 in loop1 in ##sys#lookup-runtime-requirements in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6896(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6896,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6903,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1302 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6879(t5,t3,t4);}

/* k6901 in k6894 in k6891 in loop1 in ##sys#lookup-runtime-requirements in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1297 append */
t2=*((C_word*)lf[73]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-info in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6867,3,t0,t1,t2);}
/* eval.scm: 1288 ##sys#extension-info */
t3=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[288]);}

/* ##sys#extension-info in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6845,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1282 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[268]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,t3);}

/* k6847 in ##sys#extension-info in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6865,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1283 ##sys#repository-path */
t4=*((C_word*)lf[273]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6863 in k6847 in ##sys#extension-info in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1283 string-append */
t2=((C_word*)t0)[4];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],t1,lf[44],((C_word*)t0)[2],lf[23]);}

/* k6850 in k6847 in ##sys#extension-info in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1284 file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6856 in k6850 in k6847 in ##sys#extension-info in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 1285 with-input-from-file */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#require in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6832(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_6832r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6832r(t0,t1,t2);}}

static void f_6832r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6838,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6837 in ##sys#require in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6838,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[280]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[286]);}

/* ##sys#provided? in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6818(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6818,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1263 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[268]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[285]);}

/* k6827 in ##sys#provided? in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[279]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6801(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_6801r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6801r(t0,t1,t2);}}

static void f_6801r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6807,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6806 in ##sys#provide in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6807(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6807,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6811,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1256 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[268]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[283]);}

/* k6809 in a6806 in ##sys#provide in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6811,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[279]+1));
t3=C_mutate((C_word*)lf[279]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6742r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6742r(t0,t1,t2,t3,t4);}}

static void f_6742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6746,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1239 ##sys#canonicalize-extension-path */
t6=*((C_word*)lf[268]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k6744 in ##sys#load-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6746,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[279]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],lf[30]))){
/* eval.scm: 1242 ##sys#load-library */
t3=*((C_word*)lf[257]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6764,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1244 ##sys#find-extension */
t4=*((C_word*)lf[276]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k6762 in k6744 in ##sys#load-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6764,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6770,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1246 ##sys#load */
t3=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6780,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_6780(t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t3;
f_6780(t6,(C_truep(t5)?(C_word)C_u_i_car(t2):C_SCHEME_TRUE));}}}

/* k6778 in k6762 in k6744 in ##sys#load-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6780(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 1249 ##sys#error */
t2=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[281],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6768 in k6762 in k6744 in ##sys#load-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6770,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[279]+1));
t3=C_mutate((C_word*)lf[279]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6665(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6665,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6668,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6699,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6739,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1228 ##sys#repository-path */
t7=*((C_word*)lf[273]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k6737 in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6739,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6732,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1229 ##sys#append */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[277]+1),lf[278]);}
else{
t4=t3;
f_6732(2,t4,C_SCHEME_END_OF_LIST);}}

/* k6730 in k6737 in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1228 ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6697 in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6699,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6701,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6701(t5,((C_word*)t0)[2],t1);}

/* loop in k6697 in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6701,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1232 check */
t5=((C_word*)t0)[2];
f_6668(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6712 in loop in k6697 in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1233 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6701(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6668(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6668,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6672,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1224 string-append */
t4=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[44],((C_word*)t0)[2]);}

/* k6670 in check in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6678,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6692,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1225 ##sys#string-append */
t4=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,*((C_word*)lf[244]+1));}

/* k6690 in k6670 in check in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1225 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6676 in k6670 in check in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6681(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6688,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1226 ##sys#string-append */
t4=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[20]);}}

/* k6686 in k6676 in k6670 in check in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1226 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6679 in k6676 in k6670 in check in ##sys#find-extension in k6660 in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6514(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6514,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6517,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6524,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=t5;
f_6524(2,t6,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1188 ##sys#symbol->string */
t6=*((C_word*)lf[270]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6607,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_6607(t9,t5,t2);}
else{
t6=t5;
f_6524(2,t6,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6607,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[271]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6624,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1195 ##sys#symbol->string */
t5=*((C_word*)lf[270]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_6624(2,t5,t3);}
else{
/* eval.scm: 1197 err */
t5=((C_word*)t0)[2];
f_6517(t5,t4);}}}}

/* k6622 in loop in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6624,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[272]:lf[44]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6632,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1201 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6607(t7,t5,t6);}

/* k6630 in k6622 in loop in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1193 string-append */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6522 in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6529,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6529(t5,((C_word*)t0)[2],t1);}

/* check in k6522 in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6529,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1204 err */
t5=((C_word*)t0)[3];
f_6517(t5,t1);}
else{
t5=(C_word)C_subchar(t2,C_fix(0));
t6=(C_word)C_eqp(lf[42],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6555,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1206 ##sys#substring */
t8=*((C_word*)lf[267]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_subchar(t2,t7);
t9=(C_word)C_eqp(lf[42],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6568,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_u_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1208 ##sys#substring */
t12=*((C_word*)lf[267]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k6566 in check in k6522 in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1208 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6529(t2,((C_word*)t0)[2],t1);}

/* k6553 in check in k6522 in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1206 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6529(t2,((C_word*)t0)[2],t1);}

/* err in ##sys#canonicalize-extension-path in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6517(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6517,NULL,2,t0,t1);}
/* eval.scm: 1186 ##sys#error */
t2=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[269],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6458,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6467,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6467(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6467(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6467,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6485,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1174 ##sys#substring */
t6=*((C_word*)lf[267]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6505,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1177 ##sys#substring */
t8=*((C_word*)lf[267]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1178 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6503 in loop in ##sys#split-at-separator in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6505,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1177 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6467(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6483 in loop in ##sys#split-at-separator in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1174 reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6432(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6432r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6432r(t0,t1,t2,t3);}}

static void f_6432r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6436,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1165 ##sys#load-library */
t7=*((C_word*)lf[257]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t2,t6);}

/* k6434 in load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6436,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6444 in k6434 in load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1166 ##sys#error */
t2=*((C_word*)lf[153]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[264],lf[265],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6326(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6326,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1138 ##sys#->feature-id */
t5=*((C_word*)lf[263]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6330,2,t0,t1);}
t2=(C_word)C_u_i_memq(t1,*((C_word*)lf[182]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6339(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1143 ##sys#string-append */
t6=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[254]+1));}}}

/* k6420 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6426,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1144 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6424 in k6420 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6339(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6339(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6339,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6342,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6404,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6408,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1149 ##sys#string->c-identifier */
t6=*((C_word*)lf[262]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6406 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1147 string-append */
t2=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[260],t1,lf[261]);}

/* k6402 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1146 ##sys#make-c-string */
t2=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6345,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6391,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1151 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6389 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6391,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1152 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[259]);}
else{
t2=((C_word*)t0)[3];
f_6345(2,t2,C_SCHEME_UNDEFINED);}}

/* k6392 in k6389 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1153 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6395 in k6392 in k6389 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1154 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[258]);}

/* k6343 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6345,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6350,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6350(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6343 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6350(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6350,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6363,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6384,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1157 ##sys#make-c-string */
t6=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6382 in loop in k6343 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1157 ##sys#dload */
t2=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6361 in loop in k6343 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6363,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6366,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_u_i_memq(((C_word*)t0)[4],*((C_word*)lf[182]+1)))){
t3=t2;
f_6366(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[182]+1));
t4=C_mutate((C_word*)lf[182]+1,t3);
t5=t2;
f_6366(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1160 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6350(t3,((C_word*)t0)[5],t2);}}

/* k6364 in k6361 in loop in k6343 in k6340 in k6337 in k6328 in ##sys#load-library in k6322 in k6318 in k6315 in k6311 in k6307 in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6366(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6267(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_6267r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6267r(t0,t1,t2,t3);}}

static void f_6267r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6271,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6304,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[97]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[253],t3,t5);}

/* a6303 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6304,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6301,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[97]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[252],((C_word*)t0)[2],t3);}

/* a6300 in k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6301,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6272 in k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6298,tmp=(C_word)a,a+=2,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[97]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[251],((C_word*)t0)[2],t3);}

/* a6297 in k6272 in k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6298,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6275 in k6272 in k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6277,2,t0,t1);}
t2=*((C_word*)lf[249]+1);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6287,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6293,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[233]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a6292 in k6275 in k6272 in k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6293,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[249]+1));
t3=C_mutate((C_word*)lf[249]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a6286 in k6275 in k6272 in k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6287,2,t0,t1);}
/* eval.scm: 1101 ##sys#load */
t2=*((C_word*)lf[224]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6281 in k6275 in k6272 in k6269 in load-noisily in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6282,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[249]+1));
t3=C_mutate((C_word*)lf[249]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6225(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr3r,(void*)f_6225r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6225r(t0,t1,t2,t3);}}

static void f_6225r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(16);
t4=*((C_word*)lf[249]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6231,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6236,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6262,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[233]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t1,t8,t9,t10);}

/* a6261 in load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6262,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[249]+1));
t3=C_mutate((C_word*)lf[249]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a6235 in load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6236,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6244,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_6244(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t3;
f_6244(t6,(C_truep(t5)?(C_word)C_u_i_car(t2):C_SCHEME_TRUE));}}

/* k6242 in a6235 in load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1097 ##sys#load */
t2=*((C_word*)lf[224]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* a6230 in load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6231,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[249]+1));
t3=C_mutate((C_word*)lf[249]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+22)){
C_save_and_reclaim((void*)tr5r,(void*)f_5850r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5850r(t0,t1,t2,t3,t4,t5);}}

static void f_5850r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(22);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6175,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6180,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer695763 */
t10=t9;
f_6180(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer696761 */
t12=t8;
f_6175(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body693698 */
t14=t7;
f_5852(t14,t1,t10,t12);}}}

/* def-timer695 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6180,NULL,2,t0,t1);}
/* def-printer696761 */
t2=((C_word*)t0)[2];
f_6175(t2,t1,C_SCHEME_FALSE);}

/* def-printer696 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6175(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6175,NULL,3,t0,t1,t2);}
/* body693698 */
t3=((C_word*)t0)[2];
f_5852(t3,t1,t2,C_SCHEME_FALSE);}

/* body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_5852(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5852,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6174,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1032 ##sys#expand-home-path */
t6=*((C_word*)lf[248]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_5856(t5,C_SCHEME_UNDEFINED);}}

/* k6172 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5856(t3,t2);}

/* k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_5856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5856,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6108,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1035 port? */
t4=*((C_word*)lf[247]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k6106 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6108,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_5859(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1037 ##sys#file-info */
t3=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
/* eval.scm: 1028 ##sys#signal-hook */
t3=*((C_word*)lf[218]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[245],lf[229],lf[246],t2);}}}

/* k6121 in k6106 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate((C_word*)lf[241]+1,t4);
t6=t2;
f_6126(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6126(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6126(t3,C_SCHEME_FALSE);}}

/* k6124 in k6121 in k6106 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_6126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6126,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_5859(2,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1043 ##sys#string-append */
t3=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[244]+1));}}

/* k6127 in k6124 in k6121 in k6106 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6135,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1044 ##sys#file-info */
t3=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6133 in k6127 in k6124 in k6121 in k6106 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6135,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5859(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1046 ##sys#string-append */
t3=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[20]);}}

/* k6136 in k6133 in k6127 in k6124 in k6121 in k6106 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1047 ##sys#file-info */
t3=*((C_word*)lf[242]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k6142 in k6136 in k6133 in k6127 in k6124 in k6121 in k6106 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5859(2,t2,((C_word*)t0)[3]);}
else{
t2=*((C_word*)lf[241]+1);
t3=((C_word*)t0)[4];
f_5859(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5859,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=(C_truep(t2)?t2:(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6093,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5865,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1056 ##sys#signal-hook */
t7=*((C_word*)lf[218]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,lf[237],lf[229],lf[238],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6086,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1057 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k6084 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6086,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6077,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1058 display */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[240]);}
else{
t3=((C_word*)t0)[2];
f_5865(2,t3,C_SCHEME_UNDEFINED);}}

/* k6075 in k6084 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1059 display */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6078 in k6075 in k6084 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1060 display */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[239]);}

/* k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1062 ##sys#make-c-string */
t5=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_5868(2,t3,C_SCHEME_FALSE);}}

/* k6060 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1062 ##sys#dload */
t2=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6032 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6034,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_5868(2,t2,t1);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_block_size(t2);
t4=(C_word)C_u_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5814,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=f_5814(t5,t4);
if(C_truep(t6)){
t7=((C_word*)t0)[5];
f_5868(2,t7,C_SCHEME_FALSE);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6054,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1064 string-append */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[236],lf[44],((C_word*)t0)[4]);}}}

/* k6052 in k6032 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1064 ##sys#make-c-string */
t2=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6048 in k6032 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1064 ##sys#dload */
t2=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6032 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static C_word C_fcall f_5814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(lf[42],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_u_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5871,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5871(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1065 call-with-current-continuation */
t4=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[44],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5876,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[12];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5878,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5887,a[2]=t8,a[3]=t6,a[4]=t4,a[5]=t14,a[6]=t12,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6024,a[2]=t14,a[3]=t12,a[4]=t10,a[5]=t8,a[6]=t6,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* ##sys#dynamic-wind */
t18=*((C_word*)lf[233]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,t15,t16,t17);}

/* a6023 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6024,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[225]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[211]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[210]+1));
t5=C_mutate((C_word*)lf[225]+1,((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate((C_word*)lf[211]+1,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate((C_word*)lf[210]+1,((C_word*)((C_word*)t0)[2])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5900,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1070 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_5900(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5905,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5908,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6015,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1071 ##sys#dynamic-wind */
t5=*((C_word*)lf[233]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6014 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6015,2,t0,t1);}
/* eval.scm: 1092 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5912,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1074 peek-char */
t3=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6009,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_5915(2,t4,C_SCHEME_UNDEFINED);}}

/* k6007 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1076 ##sys#error */
t2=*((C_word*)lf[153]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[229],lf[230],((C_word*)t0)[2],t1);}

/* k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1077 read */
t3=((C_word*)t0)[10];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[9]);}

/* k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5922,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5924,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_5924(t5,((C_word*)t0)[2],t1);}

/* do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_5924(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5924,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1079 printer */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_5934(2,t4,C_SCHEME_UNDEFINED);}}}

/* k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5946,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1080 ##sys#call-with-values */
C_u_call_with_values(4,0,t2,t3,t4);}

/* a5979 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5980(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5980r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5980r(t0,t1,t2);}}

static void f_5980r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a5988 in a5979 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5989(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5989,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5993,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1089 write */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5991 in a5988 in a5979 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1090 newline */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a5945 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5946,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5953,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1083 ##sys#start-timer */
t3=*((C_word*)lf[228]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1084 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}}

/* k5951 in a5945 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5964,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 1083 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a5963 in k5951 in a5945 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5964(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_5964r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5964r(t0,t1,t2);}}

static void f_5964r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5968,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5975,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1083 ##sys#stop-timer */
t5=*((C_word*)lf[227]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5973 in a5963 in k5951 in a5945 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1083 ##sys#display-times */
t2=*((C_word*)lf[226]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5966 in a5963 in k5951 in a5945 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5957 in k5951 in a5945 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5958,2,t0,t1);}
/* eval.scm: 1083 evproc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k5935 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1077 read */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5942 in k5935 in k5932 in do739 in k5920 in k5913 in k5910 in a5907 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_5924(t2,((C_word*)t0)[2],t1);}

/* a5904 in k5898 in a5895 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5905,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a5886 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5887,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[225]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[211]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[210]+1));
t5=C_mutate((C_word*)lf[225]+1,((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate((C_word*)lf[211]+1,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate((C_word*)lf[210]+1,((C_word*)((C_word*)t0)[2])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* f_5878 in a5875 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5878,2,t0,t1);}
/* eval.scm: 1069 abrt */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* k5869 in k5866 in k5863 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_5871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* f_6093 in k5857 in k5854 in body693 in ##sys#load in k5800 in k5721 in k5622 in k1576 in k1572 */
static void f_6093(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6093r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6093r(t0,t1,t2,t3);}}

static void f_6093r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6101,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1052 ##sys#eval-handler */
t5=*((C_word*)lf[204]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6099 */
static void f_6101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6105,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1053 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6103 in k6099 */
static void f_6105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* set-dynamic-load-mode! in k5721 in k5622 in k1576 in k1572 */
static void f_5729(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5729,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5736,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5741,a[2]=t6,a[3]=t8,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_5741(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k5721 in k5622 in k1576 in k1572 */
static void C_fcall f_5741(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5741,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5754,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[214]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_5754(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[215]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_5754(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[216]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_5754(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[217]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_5754(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1009 ##sys#signal-hook */
t10=*((C_word*)lf[218]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t4,lf[212],lf[219],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5752 in loop in set-dynamic-load-mode! in k5721 in k5622 in k1576 in k1572 */
static void f_5754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1010 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5741(t3,((C_word*)t0)[2],t2);}

/* k5734 in set-dynamic-load-mode! in k5721 in k5622 in k1576 in k1572 */
static void f_5736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1011 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_5725 in k5721 in k5622 in k1576 in k1572 */
static void f_5725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5725,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k5622 in k1576 in k1572 */
static void f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5641,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5644,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5654,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5654(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k5622 in k1576 in k1572 */
static void C_fcall f_5654(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5654,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5668,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 980  reverse */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5687,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 982  reverse */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_u_fixnum_plus(t4,C_fix(1));
/* eval.scm: 984  loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 983  err */
t6=((C_word*)t0)[2];
f_5644(t6,t1);}}}
else{
/* eval.scm: 981  err */
t6=((C_word*)t0)[2];
f_5644(t6,t1);}}}

/* k5685 in loop in ##sys#decompose-lambda-list in k5622 in k1576 in k1572 */
static void f_5687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 982  k */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5666 in loop in ##sys#decompose-lambda-list in k5622 in k1576 in k1572 */
static void f_5668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 980  k */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k5622 in k1576 in k1572 */
static void C_fcall f_5644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5644,NULL,2,t0,t1);}
t2=C_set_block_item(lf[207],0,C_SCHEME_FALSE);
/* eval.scm: 977  ##sys#syntax-error-hook */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[208],((C_word*)t0)[2]);}

/* eval in k5622 in k1576 in k1572 */
static void f_5627(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5627r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5627r(t0,t1,t2,t3);}}

static void f_5627r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5635,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 965  ##sys#eval-handler */
t5=*((C_word*)lf[204]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5633 in eval in k5622 in k1576 in k1572 */
static void f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 966  ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5637 in k5633 in eval in k5622 in k1576 in k1572 */
static void f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1576 in k1572 */
static void f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3499,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3502,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3544,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3656,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3709,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3748,a[2]=t8,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t12,a[7]=t14,a[8]=t5,tmp=(C_word)a,a+=9,tmp));
t16=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5410,a[2]=t12,tmp=(C_word)a,a+=3,tmp));
/* eval.scm: 944  compile */
t17=((C_word*)t12)[1];
f_3748(t17,t1,t2,t3,C_SCHEME_FALSE,t4);}

/* compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_5410(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5410,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5414,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 921  compile */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3748(t7,t5,t6,t3,C_SCHEME_FALSE,t4);}

/* k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5414,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5384,tmp=(C_word)a,a+=2,tmp);
t4=f_5384(t2,C_fix(0));
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 925  ##sys#syntax-error-hook */
t5=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[203],((C_word*)t0)[6]);
case C_fix(0):
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5436,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
case C_fix(1):
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5452,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 927  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3748(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(2):
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 929  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3748(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(3):
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 932  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3748(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(4):
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 936  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3748(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
default:
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5588,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 941  ##sys#map */
t7=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a5608 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5609,3,t0,t1,t2);}
/* eval.scm: 941  compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3748(t3,t1,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5586 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5588,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5589,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_5589 in k5586 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5589,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5597,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5595 */
static void f_5597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5601,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 942  ##sys#map */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5602 in k5595 */
static void f_5603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5603,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k5599 in k5595 */
static void f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5546 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 937  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3748(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5549 in k5546 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 938  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3748(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5552 in k5549 in k5546 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 939  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3748(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(3)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5555 in k5552 in k5549 in k5546 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_5558 in k5555 in k5552 in k5549 in k5546 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5558,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5564 */
static void f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k5568 in k5564 */
static void f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5572 in k5568 in k5564 */
static void f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5576 in k5572 in k5568 in k5564 */
static void f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5581,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5579 in k5576 in k5572 in k5568 in k5564 */
static void f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5507 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 933  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3748(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5510 in k5507 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 934  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3748(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5513 in k5510 in k5507 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_5516 in k5513 in k5510 in k5507 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5516(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5516,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5522 */
static void f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5528,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5526 in k5522 */
static void f_5528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5530 in k5526 in k5522 */
static void f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5535,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5533 in k5530 in k5526 in k5522 */
static void f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5475 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5480,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 930  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3748(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5478 in k5475 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5481,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_5481 in k5478 in k5475 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5489,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5487 */
static void f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5491 in k5487 */
static void f_5493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5496,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5494 in k5491 in k5487 */
static void f_5496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5450 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5452,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5453,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_5453 in k5450 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5453(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5453,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5461,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5459 */
static void f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5464,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5462 in k5459 */
static void f_5464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5436 in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5436,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5443,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 926  fn */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5441 */
static void f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* loop in k5412 in compile-call in ##sys#compile-to-closure in k1576 in k1572 */
static C_word C_fcall f_5384(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3748(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3748,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3760,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3766,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 584  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t5,a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 602  ##sys#number? */
t7=*((C_word*)lf[202]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}}

/* k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3818,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3825,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3833,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3841,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3849,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[13]))){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[13])?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3862,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3864,tmp=(C_word)a,a+=2,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3874,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=t3;
f_3874(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[13]);
t5=t3;
f_3874(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[13])));}}}}

/* k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3874,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(C_word)C_slot(((C_word*)t0)[12],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[12],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* eval.scm: 620  defined? */
t5=((C_word*)t0)[4];
f_3544(t5,t4,t3,((C_word*)t0)[10]);}
else{
/* eval.scm: 902  compile-call */
t3=((C_word*)((C_word*)t0)[11])[1];
f_5410(t3,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10],((C_word*)t0)[9]);}}
else{
/* eval.scm: 617  ##sys#syntax-error-hook */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[13],lf[201],((C_word*)t0)[12]);}}}

/* k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 621  compile-call */
t2=((C_word*)((C_word*)t0)[14])[1];
f_5410(t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 622  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3656(t3,t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}}

/* k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word ab[122],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[13]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[98]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 627  ##sys#check-syntax */
t5=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[98],((C_word*)t0)[13],lf[144],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[145]);
if(C_truep(t4)){
t5=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
if(C_truep(*((C_word*)lf[132]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 642  ##sys#hash-table-location */
t7=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[132]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4003,a[2]=t5,tmp=(C_word)a,a+=3,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[146]);
if(C_truep(t5)){
t6=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 647  compile */
t7=((C_word*)((C_word*)t0)[10])[1];
f_3748(t7,((C_word*)t0)[11],t6,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[12],lf[147]);
if(C_truep(t6)){
t7=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 650  compile */
t8=((C_word*)((C_word*)t0)[10])[1];
f_3748(t8,((C_word*)t0)[11],t7,((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[12],lf[117]);
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4037,tmp=(C_word)a,a+=2,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[12],lf[148]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 655  ##sys#check-syntax */
t10=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[148],((C_word*)t0)[13],lf[150],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[12],lf[113]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4104,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 664  ##sys#check-syntax */
t11=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[113],((C_word*)t0)[13],lf[152],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[12],lf[74]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[12],lf[76]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 680  ##sys#check-syntax */
t13=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[74],((C_word*)t0)[13],lf[156],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[12],lf[62]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 701  ##sys#check-syntax */
t14=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[62],((C_word*)t0)[13],lf[158],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[12],lf[99]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 752  ##sys#check-syntax */
t15=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[99],((C_word*)t0)[13],lf[163],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[12],lf[68]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
/* eval.scm: 518  ##sys#cons */
t17=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t15,lf[99],t16);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[12],lf[164]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_u_i_cddr(((C_word*)t0)[13]);
/* eval.scm: 518  ##sys#cons */
t18=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t16,lf[99],t17);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[12],lf[165]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5006,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5037,tmp=(C_word)a,a+=2,tmp);
t19=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
/* map */
t20=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[12],lf[169]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5061,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t19=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5067,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=((C_word*)t21)[1];
f_5067(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[12],lf[172]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[12],lf[173]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5113,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5119,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 867  ##sys#compile-to-closure */
t23=*((C_word*)lf[138]+1);
((C_proc5)(void*)(*((C_word*)t23+1)))(5,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[12],lf[175]);
if(C_truep(t20)){
t21=(C_word)C_u_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 871  compile */
t22=((C_word*)((C_word*)t0)[10])[1];
f_3748(t22,((C_word*)t0)[11],t21,((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[12],lf[176]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[12],lf[177]));
if(C_truep(t22)){
/* eval.scm: 874  compile */
t23=((C_word*)((C_word*)t0)[10])[1];
f_3748(t23,((C_word*)t0)[11],lf[178],((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[12],lf[179]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5157,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_memq(lf[181],*((C_word*)lf[182]+1)))){
t25=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5168,tmp=(C_word)a,a+=2,tmp);
t26=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
/* for-each */
t27=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 879  ##sys#warn */
t25=*((C_word*)lf[184]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[185],((C_word*)t0)[13]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[12],lf[186]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[12],lf[187]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5203,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5207,a[2]=t27,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 883  cadadr */
t29=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t29+1)))(3,t29,t28,((C_word*)t0)[13]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[12],lf[188]);
t27=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5220,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t26)){
t28=t27;
f_5220(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[12],lf[192]);
if(C_truep(t28)){
t29=t27;
f_5220(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[12],lf[193]);
if(C_truep(t29)){
t30=t27;
f_5220(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[12],lf[194]);
if(C_truep(t30)){
t31=t27;
f_5220(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[12],lf[195]);
if(C_truep(t31)){
t32=t27;
f_5220(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[12],lf[196]);
if(C_truep(t32)){
t33=t27;
f_5220(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[12],lf[197]);
if(C_truep(t33)){
t34=t27;
f_5220(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[12],lf[198]);
if(C_truep(t34)){
t35=t27;
f_5220(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[12],lf[199]);
t36=t27;
f_5220(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[12],lf[200])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 900  compile */
t3=((C_word*)((C_word*)t0)[10])[1];
f_3748(t3,((C_word*)t0)[11],t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k5218 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_5220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 889  ##sys#syntax-error-hook */
t2=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[189],((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[64]);
if(C_truep(t2)){
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 892  compile-call */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5410(t4,((C_word*)t0)[7],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[190]);
if(C_truep(t3)){
/* eval.scm: 896  ##sys#syntax-error-hook */
t4=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[7],lf[191],((C_word*)t0)[6]);}
else{
/* eval.scm: 898  compile-call */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5410(t4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5205 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 518  ##sys#cons */
t3=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k5201 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 518  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[74],t1);}

/* k5197 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 883  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a5167 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5168(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5168,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
/* eval.scm: 878  ##compiler#process-declaration */
t4=*((C_word*)lf[183]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k5155 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 880  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],lf[180],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5117 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5111 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 868  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],lf[174],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* loop in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_5067(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5067,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[170]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5079,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 862  ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}}

/* a5088 in loop in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5089(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5089,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5097,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 863  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5067(t6,t4,t5);}

/* k5095 in a5088 in loop in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5097,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[113],((C_word*)t0)[2],t1));}

/* a5078 in loop in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5079,2,t0,t1);}
t2=(C_word)C_u_i_cadar(((C_word*)t0)[2]);
/* eval.scm: 862  ##sys#do-the-right-thing */
t3=*((C_word*)lf[171]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* k5059 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 858  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a5036 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5037,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5044,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 848  ##sys#compile-to-closure */
t4=*((C_word*)lf[138]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5042 in a5036 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5004 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5009,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_apply(4,0,t2,*((C_word*)lf[167]+1),t1);}

/* k5007 in k5004 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 850  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[168]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5010 in k5007 in k5004 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5019(2,t3,lf[166]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5029,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5031,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5030 in k5010 in k5007 in k5004 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5031(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5031,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[98],t2));}

/* k5027 in k5010 in k5007 in k5004 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 518  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[167],t1);}

/* k5017 in k5010 in k5007 in k5004 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 851  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4987 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 845  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3748(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4970 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 842  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4612,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[7];
t9=(C_truep(t8)?t8:lf[159]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4624,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t10,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4941,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 756  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t4)[1]);}

/* k4939 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4941,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 757  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4624(2,t2,C_SCHEME_UNDEFINED);}}

/* a4951 in k4939 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4952(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4952,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a4945 in k4939 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
/* eval.scm: 759  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[92]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[142]+1));}

/* k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4629,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 762  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[162]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4629,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4636,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4932,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 767  ##sys#canonicalize-body */
t9=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4]);}

/* a4933 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4934,3,t0,t1,t2);}
/* defined?300 */
t3=((C_word*)t0)[3];
f_3544(t3,t1,t2,((C_word*)t0)[2]);}

/* k4930 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 766  ##sys#compile-to-closure */
t2=*((C_word*)lf[138]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[62],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4636,2,t0,t1);}
t2=((C_word*)t0)[6];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp)));
case C_fix(1):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4708,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp)));
case C_fix(2):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp)));
case C_fix(3):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp)):(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp))));}}

/* f_4894 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4894,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4900,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 833  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4899 */
static void f_4900(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_4900r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4900r(t0,t1,t2);}}

static void f_4900r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4920,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,*((C_word*)lf[160]+1),t2);}
else{
/* eval.scm: 837  ##sys#error */
t5=*((C_word*)lf[153]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[161],((C_word*)t0)[4],t3);}}

/* k4922 in a4899 */
static void f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 838  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4918 in a4899 */
static void f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4871 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4871(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4871,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 828  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4876 */
static void f_4877(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr2r,(void*)f_4877r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4877r(t0,t1,t2);}}

static void f_4877r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(20);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4885,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4889,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4893,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t7=t5;
f_4893(2,t7,(C_word)C_a_i_list(&a,1,t2));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5351,a[2]=t8,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_5351(t10,t5,t6,t2,C_SCHEME_FALSE);}}

/* do574 in a4876 */
static void C_fcall f_5351(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5351,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,1,t3);
t7=(C_word)C_i_setslot(t4,C_fix(1),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t6=(C_word)C_u_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
t11=t1;
t12=t6;
t13=t7;
t14=t3;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k4891 in a4876 */
static void f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[160]+1),t1);}

/* k4887 in a4876 */
static void f_4889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 830  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4883 in a4876 */
static void f_4885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4849 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4849,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4855,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 821  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4854 */
static void f_4855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4855,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4863,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4867,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 823  ##sys#vector */
t8=*((C_word*)lf[160]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,t2,t3,t4,t5);}

/* k4865 in a4854 */
static void f_4867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 823  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4861 in a4854 */
static void f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4830 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4830(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4830,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 816  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4835 */
static void f_4836(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_4836r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_4836r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_4836r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_4802 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4802,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 810  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4807 */
static void f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4808,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4783 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4783(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4783,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 805  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4788 */
static void f_4789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4789r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4789r(t0,t1,t2,t3,t4,t5);}}

static void f_4789r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_4755 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4755,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 799  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4760 */
static void f_4761(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4761,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4736 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4736,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 794  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4741 */
static void f_4742(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_4742r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4742r(t0,t1,t2,t3,t4);}}

static void f_4742r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4708 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4708(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4708,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4714,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 788  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4713 */
static void f_4714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4714,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_4689 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4689(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4689,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 783  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4694 */
static void f_4695(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_4695r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4695r(t0,t1,t2,t3);}}

static void f_4695r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4665 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4665,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4671,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 778  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4670 */
static void f_4671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4671,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_4646 in k4634 in a4628 in k4622 in k4610 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4646(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4646,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4652,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 773  decorate */
t4=((C_word*)t0)[3];
f_3709(t4,t1,t3,((C_word*)t0)[2]);}

/* a4651 */
static void f_4652(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4652r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4652r(t0,t1,t2);}}

static void f_4652r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4318,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4599,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4598 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4599(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4599,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4333,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4593,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 707  ##sys#canonicalize-body */
t7=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,t6,((C_word*)t0)[5]);}

/* a4592 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4593,3,t0,t1,t2);}
/* defined?300 */
t3=((C_word*)t0)[3];
f_3544(t3,t1,t2,((C_word*)t0)[2]);}

/* k4585 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 706  ##sys#compile-to-closure */
t2=*((C_word*)lf[138]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[41],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4333,2,t0,t1);}
switch(((C_word*)t0)[8]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4342,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[6]);
/* eval.scm: 711  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3748(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4372,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[6]);
/* eval.scm: 714  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3748(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4413,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[6]);
/* eval.scm: 718  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3748(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_u_i_cadar(((C_word*)t0)[6]);
/* eval.scm: 726  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3748(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4528,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* map */
t4=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}}

/* a4574 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4575,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
/* eval.scm: 737  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3748(t4,t1,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4526 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4528,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4529,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4529 in k4526 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4529,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 739  ##sys#make-vector */
t4=*((C_word*)lf[157]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4531 */
static void f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4545,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4545(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do462 in k4531 */
static void C_fcall f_4545(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4545,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4570,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4568 in do462 in k4531 */
static void f_4570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4545(t5,((C_word*)t0)[2],t3,t4);}

/* k4534 in k4531 */
static void f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4466 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 727  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* k4519 in k4466 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 727  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4469 in k4466 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4471,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4477,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t4=(C_word)C_u_i_cadar(t2);
/* eval.scm: 729  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3748(t5,t3,t4,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4475 in k4469 in k4466 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 730  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4511 in k4475 in k4469 in k4466 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 730  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4478 in k4475 in k4469 in k4466 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4480,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));}

/* f_4481 in k4478 in k4475 in k4469 in k4466 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4481,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4495 */
static void f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4499 in k4495 */
static void f_4501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4503 in k4499 in k4495 */
static void f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4507 in k4503 in k4499 in k4495 */
static void f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4411 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4416,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 719  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* k4453 in k4411 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 719  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4414 in k4411 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4416,2,t0,t1);}
t2=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_u_i_cadar(t2);
/* eval.scm: 721  compile */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3748(t5,t3,t4,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4420 in k4414 in k4411 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));}

/* f_4423 in k4420 in k4414 in k4411 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4423,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4437 */
static void f_4439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4443,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4441 in k4437 */
static void f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4445 in k4441 in k4437 */
static void f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4370 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4375,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 715  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4398 in k4370 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 715  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4373 in k4370 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4375,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4376 in k4373 in k4370 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4376(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4376,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4392,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4390 */
static void f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4394 in k4390 */
static void f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4340 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4343,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));}

/* f_4343 in k4340 in k4331 in k4325 in k4316 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4343,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4359,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4357 */
static void f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4359,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4226(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4226,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4230,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
/* eval.scm: 683  compile */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3748(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4230,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4297,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp)));}
else{
if(C_truep(*((C_word*)lf[132]+1))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4242,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 686  ##sys#hash-table-location */
t4=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[132]+1),((C_word*)t0)[2],*((C_word*)lf[133]+1));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4269,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));}}}

/* f_4269 in k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4269,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4275 */
static void f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4240 in k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4245(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 690  ##sys#error */
t3=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[155],((C_word*)t0)[2]);}}

/* k4243 in k4240 in k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}

/* f_4261 in k4243 in k4240 in k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4261(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4261,2,t0,t1);}
/* eval.scm: 693  ##sys#error */
t2=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[154],((C_word*)t0)[2]);}

/* f_4252 in k4243 in k4240 in k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4252(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4252,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4258 */
static void f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4297 in k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4303 */
static void f_4305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4284 in k4228 in a4225 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4284(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4284,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4294 */
static void f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4219 in k4210 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
/* eval.scm: 682  lookup */
f_3502(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4104,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 668  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3748(t4,((C_word*)t0)[4],lf[151],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 669  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3748(t5,((C_word*)t0)[4],t4,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 670  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3748(t6,t4,t5,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4163,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 674  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3748(t6,t4,t5,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}}

/* k4161 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 675  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3748(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4164 in k4161 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4184,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_slot(t4,C_fix(1));
/* eval.scm: 518  ##sys#cons */
t6=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[113],t5);}

/* k4182 in k4164 in k4161 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 676  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3748(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4167 in k4164 in k4161 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp));}

/* f_4170 in k4167 in k4164 in k4161 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4170(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4170,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4172 */
static void f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4175 in k4172 */
static void f_4177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4139 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4144,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
/* eval.scm: 671  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3748(t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4142 in k4139 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp));}

/* f_4145 in k4142 in k4139 in k4102 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4145(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4145,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4149,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4147 */
static void f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4045 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_u_i_cadr(((C_word*)t0)[5]);
/* eval.scm: 656  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3748(t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4048 in k4045 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_u_i_caddr(((C_word*)t0)[5]);
/* eval.scm: 657  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3748(t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4051 in k4048 in k4045 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4053,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4056,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_u_i_cadddr(((C_word*)t0)[5]);
/* eval.scm: 659  compile */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3748(t5,t2,t4,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
/* eval.scm: 660  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3748(t4,t2,lf[149],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}}

/* k4054 in k4051 in k4048 in k4045 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));}

/* f_4057 in k4054 in k4051 in k4048 in k4045 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4057,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4064,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4062 */
static void f_4064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4037 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4037(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4037,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4003 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_4003(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k3995 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3998,a[2]=t1,tmp=(C_word)a,a+=3,tmp));}

/* f_3998 in k3995 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3998(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3998,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3931,tmp=(C_word)a,a+=2,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3939,tmp=(C_word)a,a+=2,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3947,tmp=(C_word)a,a+=2,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3955,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3963,tmp=(C_word)a,a+=2,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3971,tmp=(C_word)a,a+=2,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3979,tmp=(C_word)a,a+=2,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3981,a[2]=t2,tmp=(C_word)a,a+=3,tmp)));}}

/* f_3981 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3981(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3981,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3979 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3979(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3979,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_3971 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3971(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3971,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3963 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3963(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3963,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3955 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3955(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3955,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_3947 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3947(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_3939 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3939(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3931 in k3919 in k3904 in k3898 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3931(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_3875 in k3872 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3875(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3864 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3864(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3862 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3862(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3862,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3851 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3851(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3851,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3849 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3849(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_3841 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3841(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_3833 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3833(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3825 in k3816 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3825(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3825,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3765 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3766(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3766,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3799,a[2]=t3,tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3808,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp)));}
else{
if(C_truep(*((C_word*)lf[132]+1))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3779,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 587  ##sys#hash-table-location */
t6=*((C_word*)lf[131]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[132]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}}}

/* f_3791 in a3765 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3791(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3791,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k3777 in a3765 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3782,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3782(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 588  ##sys#syntax-error-hook */
t3=*((C_word*)lf[142]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[143],((C_word*)t0)[2]);}}

/* k3780 in k3777 in a3765 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3782,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp));}

/* f_3783 in k3780 in k3777 in a3765 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3783(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3783,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* f_3808 in a3765 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3808,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_3799 in a3765 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3799,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3759 in compile in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3760,2,t0,t1);}
/* eval.scm: 584  lookup */
f_3502(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3709(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3709,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3715,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3728,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 572  ##sys#decorate-lambda */
t6=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t4,t5);}

/* a3727 in decorate in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3728,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3736,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 579  with-output-to-string */
t7=*((C_word*)lf[140]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a3741 in a3727 in decorate in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
/* write290 */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k3738 in a3727 in decorate in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 578  ##sys#make-lambda-info */
t2=*((C_word*)lf[139]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3734 in a3727 in decorate in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3714 in decorate in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3715,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3656(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3656,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3660,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 560  ##sys#macroexpand-1-local */
t6=*((C_word*)lf[79]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t4);}

/* k3658 in macroexpand-1-checked in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3660,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,lf[62]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3707,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 563  defined? */
t6=((C_word*)t0)[2];
f_3544(t6,t5,lf[62],((C_word*)t0)[4]);}
else{
t5=t3;
f_3675(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3705 in k3658 in macroexpand-1-checked in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3675(t2,(C_word)C_i_not(t1));}

/* k3673 in k3658 in macroexpand-1-checked in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3675(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3675,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_3684(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_3684(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k3682 in k3673 in k3658 in macroexpand-1-checked in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 566  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3656(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* defined? in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3544(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3544,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3550,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3556,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a3555 in defined? in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3556,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3549 in defined? in ##sys#compile-to-closure in k1576 in k1572 */
static void f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3550,2,t0,t1);}
/* eval.scm: 535  lookup */
f_3502(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3502(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3502,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3508,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3508(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1576 in k1572 */
static void C_fcall f_3508(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3508,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 530  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3626,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=f_3626(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 531  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
/* eval.scm: 532  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1576 in k1572 */
static C_word C_fcall f_3626(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#hash-table-location in k1576 in k1572 */
static void f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3436,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3440,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 499  ##sys#hash-symbol */
t7=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3438 in ##sys#hash-table-location in k1576 in k1572 */
static void f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3448,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3448(t6,((C_word*)t0)[2],t2);}

/* loop in k3438 in ##sys#hash-table-location in k1576 in k1572 */
static void C_fcall f_3448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3448,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 510  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k1576 in k1572 */
static void f_3390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3390,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3396,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3396(t8,t1,C_fix(0));}

/* do271 in ##sys#hash-table-for-each in k1576 in k1572 */
static void C_fcall f_3396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3396,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3406,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 491  ##sys#for-each */
t6=*((C_word*)lf[129]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3414 in do271 in ##sys#hash-table-for-each in k1576 in k1572 */
static void f_3415(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3415,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 492  p */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k3404 in do271 in ##sys#hash-table-for-each in k1576 in k1572 */
static void f_3406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3396(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-set! in k1576 in k1572 */
static void f_3335(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3335,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3339,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 477  ##sys#hash-symbol */
t6=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3337 in ##sys#hash-table-set! in k1576 in k1572 */
static void f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3347,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_3347(t6,((C_word*)t0)[2],t2);}

/* loop in k3337 in ##sys#hash-table-set! in k1576 in k1572 */
static void C_fcall f_3347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3347,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 485  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1576 in k1572 */
static void f_3290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3290,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3294,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 466  ##sys#hash-symbol */
t5=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3292 in ##sys#hash-table-ref in k1576 in k1572 */
static void f_3294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3294,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3303,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3303(t3,t2));}

/* loop in k3292 in ##sys#hash-table-ref in k1576 in k1572 */
static C_word C_fcall f_3303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1576 in k1572 */
static void f_3275(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3275,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1576 in k1572 */
static void f_3215(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3215,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3218,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 448  loop */
t10=((C_word*)t7)[1];
f_3218(t10,t9,t2,t3);}

/* k3268 in ##sys#expand-curried-define in k1576 in k1572 */
static void f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3270,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1576 in k1572 */
static void C_fcall f_3218(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3218,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3236,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 440  ##sys#cons */
t9=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t3);}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3255,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 440  ##sys#cons */
t9=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t3);}}

/* k3257 in loop in ##sys#expand-curried-define in k1576 in k1572 */
static void f_3259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 440  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k3253 in loop in ##sys#expand-curried-define in k1576 in k1572 */
static void f_3255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3255,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 447  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3218(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3234 in loop in ##sys#expand-curried-define in k1576 in k1572 */
static void f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 440  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* ##sys#match-expression in k1576 in k1572 */
static void f_3124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3124,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3127,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3213,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 435  mwalk */
t11=((C_word*)t8)[1];
f_3127(t11,t10,t2,t3);}

/* k3211 in ##sys#match-expression in k1576 in k1572 */
static void f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1576 in k1572 */
static void C_fcall f_3127(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3127,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_u_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_u_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3182,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 432  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3180 in mwalk in ##sys#match-expression in k1576 in k1572 */
static void f_3182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 433  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3127(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1576 in k1572 */
static void f_2673(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_2673r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2673r(t0,t1,t2,t3,t4);}}

static void f_2673r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2677,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2677(t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_slot(t4,C_fix(1));
t7=(C_word)C_i_nullp(t6);
t8=t5;
f_2677(t8,(C_truep(t7)?(C_word)C_u_i_car(t4):C_SCHEME_TRUE));}}

/* k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void C_fcall f_2677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2677,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2859,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
/* eval.scm: 416  expand */
t8=((C_word*)t5)[1];
f_2859(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void C_fcall f_2859(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2859,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2865(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void C_fcall f_2865(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2865,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2899,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 382  lookup */
t12=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t10);}
else{
t12=t11;
f_2899(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 381  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2679(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 377  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2679(t7,t1,t3,t4,t5,t6,t2);}}

/* k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2899,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 383  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2679(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[114],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 385  ##sys#check-syntax */
t4=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[114],((C_word*)t0)[3],lf[123],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[115],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3029,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 406  ##sys#check-syntax */
t5=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[115],((C_word*)t0)[3],lf[124],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[113],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 409  ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[113],((C_word*)t0)[3],lf[125],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 412  ##sys#macroexpand-0 */
t6=lf[53];
f_1633(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3069 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3071,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 414  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2679(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 415  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2865(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3055 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3064,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 410  ##sys#append */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3062 in k3055 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_3064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 410  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2865(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3027 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_u_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 407  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2865(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2916(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void C_fcall f_2916(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2916,NULL,3,t0,t1,t2);}
t3=(C_word)C_u_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2963,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 397  ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[114],t2,lf[119],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2981,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 400  ##sys#check-syntax */
t6=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[114],t2,lf[120],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 389  ##sys#check-syntax */
t5=*((C_word*)lf[69]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[114],t2,lf[122],C_SCHEME_FALSE);}}

/* k2927 in loop2 in k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2929,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_u_i_caddr(((C_word*)t0)[8]):lf[121]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 390  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_2865(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2979 in loop2 in k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_u_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 347  ##sys#cons */
t8=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k2998 in k2979 in loop2 in k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 347  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k2994 in k2979 in loop2 in k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2996,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]);
/* eval.scm: 401  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2865(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2961 in loop2 in k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 398  ##sys#expand-curried-define */
t4=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k2972 in k2961 in loop2 in k2909 in k2897 in loop in expand in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[114],t1);
/* eval.scm: 398  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2916(t3,((C_word*)t0)[2],t2);}

/* fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void C_fcall f_2679(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2679,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2691,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2691(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2761,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 361  reverse */
t10=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}}

/* k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2772,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2839,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2851,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t5,*((C_word*)lf[84]+1),t1,((C_word*)t0)[3]);}

/* k2849 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 362  ##sys#map */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2838 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2839,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[117]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2780,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2829,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2837,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 364  reverse */
t6=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2835 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 364  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2828 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2829,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[76],t2,t3));}

/* k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2784,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2790,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2823,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 371  reverse */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2821 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 372  reverse */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2825 in k2821 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 365  map */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2789 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2790(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2790,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2794,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 366  ##sys#map */
t5=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[91]+1),t2);}

/* k2792 in a2789 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[99],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2805,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2813,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2815,tmp=(C_word)a,a+=2,tmp);
/* eval.scm: 370  map */
t7=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,t6,((C_word*)t0)[2],t1);}

/* a2814 in k2792 in a2789 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2815,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[76],t2,t3));}

/* k2811 in k2792 in a2789 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2807 in k2792 in a2789 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k2803 in k2792 in a2789 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[116],((C_word*)t0)[2],t1));}

/* k2786 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2782 in k2778 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2774 in k2770 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2766 in k2759 in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* loop in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2691,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[114],lf[115]);
t8=t5;
f_2710(t8,(C_word)C_u_i_memq(t6,t7));}
else{
t6=t5;
f_2710(t6,C_SCHEME_FALSE);}}
else{
/* eval.scm: 347  ##sys#cons */
t4=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[113],((C_word*)t0)[2]);}}

/* k2708 in loop in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void C_fcall f_2710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2710,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 359  reverse */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 360  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2691(t4,((C_word*)t0)[8],t2,t3);}}

/* k2719 in k2708 in loop in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 359  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2859(t3,t2,((C_word*)t0)[2]);}

/* k2727 in k2719 in k2708 in loop in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 359  ##sys#append */
t3=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2715 in k2708 in loop in fini in k2675 in ##sys#canonicalize-body in k1576 in k1572 */
static void f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 347  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[113],t1);}

/* ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2154,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2157,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,tmp=(C_word)a,a+=9,tmp));
t13=((C_word*)t11)[1];
f_2176(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2176(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2176,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 276  reverse */
t9=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
/* eval.scm: 276  reverse */
t8=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 299  err */
t7=((C_word*)t0)[4];
f_2157(t7,t1,lf[101]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2420,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2420(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2420(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[88]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2452(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2471,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 311  gensym */
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[87]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2489(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2489(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 323  err */
t11=((C_word*)t0)[4];
f_2157(t11,t1,lf[104]);}}
else{
t11=(C_word)C_eqp(t7,lf[89]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2535(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2554,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 325  gensym */
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 332  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 333  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 334  err */
t13=((C_word*)t0)[4];
f_2157(t13,t1,lf[106]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 335  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2616,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2616(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2616(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 305  err */
t7=((C_word*)t0)[4];
f_2157(t7,t1,lf[110]);}}}}

/* k2614 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2616(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2616,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 338  err */
t3=((C_word*)t0)[9];
f_2157(t3,((C_word*)t0)[8],lf[107]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 339  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2176(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 340  err */
t3=((C_word*)t0)[9];
f_2157(t3,((C_word*)t0)[8],lf[108]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 341  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2176(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 342  err */
t2=((C_word*)t0)[9];
f_2157(t2,((C_word*)t0)[8],lf[109]);}}

/* k2552 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2535(t3,t2);}

/* k2533 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 327  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2176(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 328  err */
t2=((C_word*)t0)[2];
f_2157(t2,((C_word*)t0)[6],lf[105]);}}

/* k2487 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2489,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2492(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2492(t6,t5);}}
else{
/* eval.scm: 322  err */
t2=((C_word*)t0)[2];
f_2157(t2,((C_word*)t0)[6],lf[103]);}}

/* k2490 in k2487 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 321  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2176(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2469 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2452(t3,t2);}

/* k2450 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2452(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 313  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2176(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 314  err */
t3=((C_word*)t0)[2];
f_2157(t3,((C_word*)t0)[5],lf[102]);}}

/* k2418 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 303  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2176(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2397 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 276  ##sys#append */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2194(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2329,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 287  reverse */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[4]);}}

/* k2390 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2335,3,t0,t1,t2);}
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2350,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2388,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 266  string->keyword */
t8=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* k2386 in a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2388,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[98],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2372,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2376,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 261  ##sys#cons */
t9=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_SCHEME_END_OF_LIST,t8);}
else{
t6=t4;
f_2362(t6,C_SCHEME_END_OF_LIST);}}

/* k2374 in k2386 in a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[99],t1);}

/* k2370 in k2386 in a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2372,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2362(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2360 in k2386 in a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2356 in k2386 in a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2348 in a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[97],t1);}

/* k2344 in a2334 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2331 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2327 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[96],t1);}

/* k2323 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2325,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2194(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2194(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2194,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2197(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2206(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t6=t3;
f_2206(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2206(t5,C_SCHEME_FALSE);}}}}

/* k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2206(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[57],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2206,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2213,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_i_caar(((C_word*)t0)[7]);
t5=(C_word)C_u_i_cadar(((C_word*)t0)[7]);
t6=(C_word)C_a_i_list(&a,3,lf[93],((C_word*)((C_word*)t0)[6])[1],t5);
t7=(C_word)C_a_i_list(&a,2,t4,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
/* eval.scm: 261  ##sys#cons */
t9=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t3,t8,((C_word*)t0)[5]);}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2250,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2254,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 293  reverse */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2273,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2277,a[2]=((C_word*)t0)[6],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2281,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2285,a[2]=t7,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 295  reverse */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[7]);}}}

/* k2283 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 295  ##sys#append */
t5=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2279 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2275 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2271 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[95],t1);}

/* k2267 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2269,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2197(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2260 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2256 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2252 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[94],t1);}

/* k2248 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2250,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2197(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2215 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k2211 in k2204 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void f_2213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2213,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2197(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2195 in k2192 in k2188 in loop in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 275  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1576 in k1572 */
static void C_fcall f_2157(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2157,NULL,3,t0,t1,t2);}
/* eval.scm: 265  errh */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1576 in k1572 */
static void f_2111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2111,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2117(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1576 in k1572 */
static void C_fcall f_2117(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2117,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[87]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2136,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2136(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[88]);
t7=t5;
f_2136(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[89])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2134 in loop in ##sys#extended-lambda-list? in k1576 in k1572 */
static void C_fcall f_2136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 259  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2117(t3,((C_word*)t0)[4],t2);}}

/* ##sys#undefine-non-standard-macros in k1576 in k1572 */
static void f_2040(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2040,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2044,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 227  ##sys#append */
t4=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[85]);}

/* k2042 in ##sys#undefine-non-standard-macros in k1576 in k1572 */
static void f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2049,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2049(t5,((C_word*)t0)[2],C_fix(0));}

/* do108 in k2042 in ##sys#undefine-non-standard-macros in k1576 in k1572 */
static void C_fcall f_2049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2049,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(301)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2070,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(*((C_word*)lf[45]+1),t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2076,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2076(t8,t3,t4);}}

/* loop in do108 in k2042 in ##sys#undefine-non-standard-macros in k1576 in k1572 */
static void C_fcall f_2076(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2076,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_u_i_memq(t5,((C_word*)t0)[3]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2102,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 238  loop */
t8=t6;
t9=t4;
t1=t8;
t2=t9;
goto loop;}
else{
/* eval.scm: 239  loop */
t8=t1;
t9=t4;
t1=t8;
t2=t9;
goto loop;}}}

/* k2100 in loop in do108 in k2042 in ##sys#undefine-non-standard-macros in k1576 in k1572 */
static void f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2068 in do108 in k2042 in ##sys#undefine-non-standard-macros in k1576 in k1572 */
static void f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(*((C_word*)lf[45]+1),((C_word*)t0)[4],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2049(t4,((C_word*)t0)[2],t3);}

/* macroexpand-1 in k1576 in k1572 */
static void f_2023(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2023r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2023r(t0,t1,t2,t3);}}

static void f_2023r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 219  ##sys#macroexpand-0 */
t6=lf[53];
f_1633(t6,t1,t2,t5);}

/* macroexpand in k1576 in k1572 */
static void f_1987(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1987r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1987r(t0,t1,t2,t3);}}

static void f_1987r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1996,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1996(t9,t1,t2);}

/* loop in macroexpand in k1576 in k1572 */
static void C_fcall f_1996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1996,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2008,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}

/* a2007 in loop in macroexpand in k1576 in k1572 */
static void f_2008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2008,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 215  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1996(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2001 in loop in macroexpand in k1576 in k1572 */
static void f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
/* eval.scm: 213  ##sys#macroexpand-0 */
t2=lf[53];
f_1633(t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1576 in k1572 */
static void f_1981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1981,4,t0,t1,t2,t3);}
/* eval.scm: 205  ##sys#macroexpand-0 */
t4=lf[53];
f_1633(t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1576 in k1572 */
static void f_1978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1978,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1576 in k1572 */
static void f_1975(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1975,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1633(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1633,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[62]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1842,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 174  ##sys#check-syntax */
t10=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[62],t7,lf[71]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1915,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[74]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[76]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_1915(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_1915(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1915(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 197  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 198  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k1913 in ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1915,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 190  ##sys#check-syntax */
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[74],((C_word*)t0)[6],lf[75]);}
else{
/* eval.scm: 196  expand */
t2=((C_word*)t0)[4];
f_1782(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1919 in k1913 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[72],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 192  append */
t8=*((C_word*)lf[73]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t2,t5,t6,t7);}

/* k1926 in k1919 in k1913 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 191  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=(C_word)C_u_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1854,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 177  ##sys#check-syntax */
t4=*((C_word*)lf[69]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[62],((C_word*)t0)[4],lf[70]);}
else{
/* eval.scm: 185  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1868,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1888,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1896,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1902,tmp=(C_word)a,a+=2,tmp);
/* map */
t9=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t2);}

/* a1901 in k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1902,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_u_i_car(t2));}

/* k1894 in k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 126  ##sys#cons */
t3=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k1890 in k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 126  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[68],t1);}

/* k1886 in k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,3,lf[65],t3,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1876,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 183  ##sys#map */
t6=*((C_word*)lf[66]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[67]+1),((C_word*)t0)[2]);}

/* k1874 in k1886 in k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 126  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1866 in k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 126  ##sys#cons */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[64],t1);}

/* k1862 in k1852 in k1840 in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 179  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1782(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1782,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_u_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1796,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1802,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 158  ##sys#hash-table-ref */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[45]+1),t3);}}

/* k1800 in expand in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 161  call-handler */
t3=((C_word*)t0)[4];
f_1636(t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* eval.scm: 167  values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k1810 in k1800 in expand in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 161  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k1794 in expand in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 157  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1636(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1636,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1643,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1645,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1645,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1651,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1758,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a1757 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1770,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t2,t3);}

/* a1769 in a1757 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1770(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1770r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1770r(t0,t1,t2);}}

static void f_1770r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g5961 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1775 in a1769 in a1757 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1763 in a1757 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1764,2,t0,t1);}
/* eval.scm: 154  handler */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1651,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* g5961 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1656 in a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1665,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[55]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1668(t5,(C_word)C_i_memv(lf[59],t4));}
else{
t4=t3;
f_1668(t4,C_SCHEME_FALSE);}}

/* k1666 in a1656 in a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1668,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1679,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1685,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_1685(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1665(t2,((C_word*)t0)[5]);}}

/* copy in k1666 in a1656 in a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1685(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1685,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_eqp(lf[56],t3);
if(C_truep(t6)){
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_u_i_car(t4);
t8=t5;
f_1704(t8,(C_word)C_i_stringp(t7));}
else{
t7=t5;
f_1704(t7,C_SCHEME_FALSE);}}
else{
t7=t5;
f_1704(t7,C_SCHEME_FALSE);}}}

/* k1702 in copy in k1666 in a1656 in a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1704,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1715,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_u_i_car(((C_word*)t0)[6]);
/* eval.scm: 148  string-append */
t5=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t2,lf[57],t3,lf[58],t4);}
else{
/* eval.scm: 152  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1685(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1713 in k1702 in copy in k1666 in a1656 in a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[56],t3));}

/* k1677 in k1666 in a1656 in a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1665(t2,(C_word)C_a_i_record(&a,3,lf[55],((C_word*)t0)[2],t1));}

/* k1663 in a1656 in a1650 in a1644 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void C_fcall f_1665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 132  ##sys#abort */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1641 in call-handler in ##sys#macroexpand-0 in k1576 in k1572 */
static void f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1576 in k1572 */
static void f_1627(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1627,3,t0,t1,t2);}
/* eval.scm: 117  ##sys#hash-table-set! */
t3=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,*((C_word*)lf[45]+1),t2,C_SCHEME_FALSE);}

/* macro? in k1576 in k1572 */
static void f_1612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1612,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1619,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 114  ##sys#hash-table-ref */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[45]+1),t2);}

/* k1617 in macro? in k1576 in k1572 */
static void f_1619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#register-macro in k1576 in k1572 */
static void f_1596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1596,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1602,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 108  ##sys#hash-table-set! */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[45]+1),t2,t4);}

/* a1601 in ##sys#register-macro in k1576 in k1572 */
static void f_1602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1602,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1576 in k1572 */
static void f_1580(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1580,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1586,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 102  ##sys#hash-table-set! */
t5=*((C_word*)lf[47]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[45]+1),t2,t4);}

/* a1585 in ##sys#register-macro-2 in k1576 in k1572 */
static void f_1586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1586,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 104  handler */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
/* end of file */
