/* Generated from posix.scm by the Chicken compiler
   2005-09-10 23:12
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: posix.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file uposix.c -explicit-use
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#ifdef ECOS
#include <cyg/posix/signal.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANONYMOUS
# define MAP_ANONYMOUS    0
#endif

#ifndef C_MACOSX
extern char **environ;
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
#ifndef ECOS
static C_TLS struct passwd *C_user;
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)   	(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name),	C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#ifndef ECOS
#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#endif
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#ifdef C_MACOSX
# define C_getenventry(i)   NULL
#else
# define C_getenventry(i)   environ[ i ]
#endif

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y);
C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);				       
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_exec_args() {
  char **a = C_exec_args;
  while((*a) != NULL) C_free(*(a++));
}

static void C_fcall C_free_exec_env() {
  char **a = C_exec_env;
  while((*a) != NULL) C_free(*(a++));
}

#define C_set_exec_arg(i, a, len)      C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)      C_set_arg_string(C_exec_env, i, a, len)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigprocmask(d)    C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)    FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd) FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd) FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_timeval.tv_sec = C_unfix(t), C_timeval.tv_usec = 0, C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if !defined(C_GNU_ENV)
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )
#else
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), asctime(&C_tm) )
#endif

#ifndef ECOS
static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))
#endif

C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[354];


/* from k4514 in set-root-directory! in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub895(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub895(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from select */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub748(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub748(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_return:
#undef return

return C_r;}

/* from sleep in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub718(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub718(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub715(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub715(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub713(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub713(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub654(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub654(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k3654 */
static C_word C_fcall stub647(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub647(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub642(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub642(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k3646 */
static C_word C_fcall stub635(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub635(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from f_3631 in k3625 in process-fork in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub623(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub623(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub618(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub618(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub581(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub581(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);
              else return(C_hostbuf);
C_return:
#undef return

return C_r;}

/* from ttyname */
static C_word C_fcall stub574(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub574(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from set-alarm! in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub560(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub560(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from ex0 */
static C_word C_fcall stub554(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub554(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from asctime */
static C_word C_fcall stub543(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub543(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub534(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub534(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k3250 */
static C_word C_fcall stub507(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub507(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k3192 */
static C_word C_fcall stub482(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub482(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from get */
static C_word C_fcall stub460(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub460(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k2674 in k2670 in file-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub357(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub357(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from current-effective-group-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub319(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub319(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from current-effective-user-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub317(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub317(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from current-group-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub315(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub315(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from current-user-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub313(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub313(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from k2396 in initialize-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub291(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub291(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from _ensure-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub265(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub265(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_return:
#undef return

return C_r;}

/* from _get-groups */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub261(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub261(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_return:
#undef return

return C_r;}

/* from group-member */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub250(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub250(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_return:
#undef return

return C_r;}

/* from fd_test in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub65(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub65(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from fd_set in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub59(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub59(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from fd_zero in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall stub54(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub54(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from strerror */
static C_word C_fcall stub9(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub9(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from make-nonblocking in k1061 in k1058 in k1055 in k1052 in k1049 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_return:
#undef return

return C_r;}

C_externexport void C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1051(C_word c,C_word t0,C_word t1) C_noret;
static void f_1054(C_word c,C_word t0,C_word t1) C_noret;
static void f_1057(C_word c,C_word t0,C_word t1) C_noret;
static void f_1060(C_word c,C_word t0,C_word t1) C_noret;
static void f_1063(C_word c,C_word t0,C_word t1) C_noret;
static void f_2085(C_word c,C_word t0,C_word t1) C_noret;
static void f_4540(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2134(C_word c,C_word t0,C_word t1) C_noret;
static void f_2643(C_word c,C_word t0,C_word t1) C_noret;
static void f_4520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4516(C_word c,C_word t0,C_word t1) C_noret;
static void f_4297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4297r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_4445(C_word t0,C_word t1) C_noret;
static void f_4451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4440(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4435(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_4299(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4422(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4430(C_word c,C_word t0,C_word t1,...) C_noret;
static void C_fcall f_4303(C_word t0,C_word t1) C_noret;
static void f_4410(C_word c,C_word t0,C_word t1) C_noret;
static void f_4313(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4334(C_word c,C_word t0,C_word t1) C_noret;
static void f_4396(C_word c,C_word t0,C_word t1) C_noret;
static void f_4403(C_word c,C_word t0,C_word t1) C_noret;
static void f_4390(C_word c,C_word t0,C_word t1) C_noret;
static void f_4349(C_word c,C_word t0,C_word t1) C_noret;
static void f_4380(C_word c,C_word t0,C_word t1) C_noret;
static void f_4366(C_word c,C_word t0,C_word t1) C_noret;
static void f_4378(C_word c,C_word t0,C_word t1) C_noret;
static void f_4374(C_word c,C_word t0,C_word t1) C_noret;
static void f_4361(C_word c,C_word t0,C_word t1) C_noret;
static void f_4359(C_word c,C_word t0,C_word t1) C_noret;
static void f_4414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3989(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3989r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_4252(C_word t0,C_word t1) C_noret;
static void C_fcall f_4247(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3991(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4196(C_word c,C_word t0,C_word t1) C_noret;
static void f_4200(C_word c,C_word t0,C_word t1) C_noret;
static void f_4203(C_word c,C_word t0,C_word t1) C_noret;
static void f_4243(C_word c,C_word t0,C_word t1) C_noret;
static void f_4206(C_word c,C_word t0,C_word t1) C_noret;
static void f_4234(C_word c,C_word t0,C_word t1) C_noret;
static void f_4209(C_word c,C_word t0,C_word t1) C_noret;
static void f_4218(C_word c,C_word t0,C_word t1) C_noret;
static void f_4019(C_word c,C_word t0,C_word t1) C_noret;
static void f_4022(C_word c,C_word t0,C_word t1) C_noret;
static void f_4025(C_word c,C_word t0,C_word t1) C_noret;
static void f_4038(C_word c,C_word t0,C_word t1) C_noret;
static void f_4183(C_word c,C_word t0,C_word t1) C_noret;
static void f_4187(C_word c,C_word t0,C_word t1) C_noret;
static void f_4167(C_word c,C_word t0,C_word t1) C_noret;
static void f_4151(C_word c,C_word t0,C_word t1) C_noret;
static void f_4155(C_word c,C_word t0,C_word t1) C_noret;
static void f_4082(C_word c,C_word t0,C_word t1) C_noret;
static void f_4138(C_word c,C_word t0,C_word t1) C_noret;
static void f_4142(C_word c,C_word t0,C_word t1) C_noret;
static void f_4088(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_4097(C_word t0,C_word t1) C_noret;
static void f_4129(C_word c,C_word t0,C_word t1) C_noret;
static void f_4113(C_word c,C_word t0,C_word t1) C_noret;
static void f_4086(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4040(C_word t0,C_word t1) C_noret;
static void C_fcall f_4054(C_word t0,C_word t1) C_noret;
static void f_4070(C_word c,C_word t0,C_word t1) C_noret;
static void f_4073(C_word c,C_word t0,C_word t1) C_noret;
static void f_4050(C_word c,C_word t0,C_word t1) C_noret;
static void f_4009(C_word c,C_word t0,C_word t1) C_noret;
static void f_3997(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3969(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3975(C_word c,C_word t0,C_word t1) C_noret;
static void f_3923(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3923r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3930(C_word c,C_word t0,C_word t1) C_noret;
static void f_3945(C_word c,C_word t0,C_word t1) C_noret;
static void f_3902(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3902r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3899(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3896(C_word c,C_word t0,C_word t1) C_noret;
static void f_3893(C_word c,C_word t0,C_word t1) C_noret;
static void f_3823(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3823r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_3659(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3659r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_3778(C_word t0,C_word t1) C_noret;
static void C_fcall f_3773(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3661(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3665(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3673(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_3716(C_word t0,C_word t1,C_word t2);
static void C_fcall f_3686(C_word t0,C_word t1) C_noret;
static void f_3711(C_word c,C_word t0,C_word t1) C_noret;
static void f_3689(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3651(C_word t0,C_word t1,C_word t2);
static C_word C_fcall f_3643(C_word t0,C_word t1,C_word t2);
static void f_3605(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3605r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_3627(C_word c,C_word t0,C_word t1) C_noret;
static void f_3631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3499(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3499r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3597(C_word c,C_word t0,C_word t1) C_noret;
static void f_3530(C_word c,C_word t0,C_word t1) C_noret;
static void f_3537(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3539(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3556(C_word c,C_word t0,C_word t1) C_noret;
static void f_3566(C_word c,C_word t0,C_word t1) C_noret;
static void f_3570(C_word c,C_word t0,C_word t1) C_noret;
static void f_3520(C_word c,C_word t0,C_word t1) C_noret;
static void f_3487(C_word c,C_word t0,C_word t1) C_noret;
static void f_3491(C_word c,C_word t0,C_word t1) C_noret;
static void f_3494(C_word c,C_word t0,C_word t1) C_noret;
static void f_3460(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3464(C_word c,C_word t0,C_word t1) C_noret;
static void f_3439(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3443(C_word c,C_word t0,C_word t1) C_noret;
static void f_3386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_3386r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_3393(C_word c,C_word t0,C_word t1) C_noret;
static void f_3383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3364(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3364r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_3368(C_word c,C_word t0,C_word t1) C_noret;
static void f_3334(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3341(C_word c,C_word t0,C_word t1) C_noret;
static void f_3344(C_word c,C_word t0,C_word t1) C_noret;
static void f_3347(C_word c,C_word t0,C_word t1) C_noret;
static void f_3317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3321(C_word c,C_word t0,C_word t1) C_noret;
static void f_3324(C_word c,C_word t0,C_word t1) C_noret;
static void f_3306(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3294(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3288(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3256(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3256r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_3198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
static void f_3198r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
static void f_3202(C_word c,C_word t0,C_word t1) C_noret;
static void f_3208(C_word c,C_word t0,C_word t1) C_noret;
static void f_3227(C_word c,C_word t0,C_word t1) C_noret;
static void f_3214(C_word c,C_word t0,C_word t1) C_noret;
static void f_3115(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3121(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3125(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3133(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3159(C_word c,C_word t0,C_word t1) C_noret;
static void f_3163(C_word c,C_word t0,C_word t1) C_noret;
static void f_3151(C_word c,C_word t0,C_word t1) C_noret;
static void f_3103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3108(C_word c,C_word t0,C_word t1) C_noret;
static void f_3092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3097(C_word c,C_word t0,C_word t1) C_noret;
static void f_3101(C_word c,C_word t0,C_word t1) C_noret;
static void f_3069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3090(C_word c,C_word t0,C_word t1) C_noret;
static void f_3073(C_word c,C_word t0,C_word t1) C_noret;
static void f_3032(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_3032r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_3036(C_word t0,C_word t1) C_noret;
static void f_3054(C_word c,C_word t0,C_word t1) C_noret;
static void f_3050(C_word c,C_word t0,C_word t1) C_noret;
static void f_3007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2985(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2985r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2989(C_word c,C_word t0,C_word t1) C_noret;
static void f_2970(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2970r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2974(C_word c,C_word t0,C_word t1) C_noret;
static void f_2955(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2955r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2959(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2937(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2875(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2894(C_word t0,C_word t1) C_noret;
static void f_2839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2864(C_word c,C_word t0,C_word t1) C_noret;
static void f_2860(C_word c,C_word t0,C_word t1) C_noret;
static void f_2853(C_word c,C_word t0,C_word t1) C_noret;
static void f_2818(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2818r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2822(C_word t0,C_word t1) C_noret;
static void f_2825(C_word c,C_word t0,C_word t1) C_noret;
static void f_2776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2812(C_word c,C_word t0,C_word t1) C_noret;
static void f_2795(C_word c,C_word t0,C_word t1) C_noret;
static void f_2765(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2765r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2774(C_word c,C_word t0,C_word t1) C_noret;
static void f_2754(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2754r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2763(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2739(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2752(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2702(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2710(C_word c,C_word t0,C_word t1) C_noret;
static void f_2683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2672(C_word c,C_word t0,C_word t1) C_noret;
static void f_2676(C_word c,C_word t0,C_word t1) C_noret;
static void f_2644(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2665(C_word c,C_word t0,C_word t1) C_noret;
static void f_2649(C_word c,C_word t0,C_word t1) C_noret;
static void f_2652(C_word c,C_word t0,C_word t1) C_noret;
static void f_2612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2639(C_word c,C_word t0,C_word t1) C_noret;
static void f_2627(C_word c,C_word t0,C_word t1) C_noret;
static void f_2635(C_word c,C_word t0,C_word t1) C_noret;
static void f_2631(C_word c,C_word t0,C_word t1) C_noret;
static void f_2597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2607(C_word c,C_word t0,C_word t1) C_noret;
static void f_2582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2592(C_word c,C_word t0,C_word t1) C_noret;
static void f_2586(C_word c,C_word t0,C_word t1) C_noret;
static void f_2567(C_word c,C_word t0,C_word t1) C_noret;
static void f_2577(C_word c,C_word t0,C_word t1) C_noret;
static void f_2571(C_word c,C_word t0,C_word t1) C_noret;
static void f_2561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2555(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2528(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2547(C_word c,C_word t0,C_word t1) C_noret;
static void f_2543(C_word c,C_word t0,C_word t1) C_noret;
static void f_2535(C_word c,C_word t0,C_word t1) C_noret;
static void f_2513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2523(C_word c,C_word t0,C_word t1) C_noret;
static void f_2498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2508(C_word c,C_word t0,C_word t1) C_noret;
static void f_2495(C_word c,C_word t0,C_word t1) C_noret;
static void f_2492(C_word c,C_word t0,C_word t1) C_noret;
static void f_2489(C_word c,C_word t0,C_word t1) C_noret;
static void f_2486(C_word c,C_word t0,C_word t1) C_noret;
static void f_2465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2484(C_word c,C_word t0,C_word t1) C_noret;
static void f_2480(C_word c,C_word t0,C_word t1) C_noret;
static void f_2444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2463(C_word c,C_word t0,C_word t1) C_noret;
static void f_2459(C_word c,C_word t0,C_word t1) C_noret;
static void f_2402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2398(C_word c,C_word t0,C_word t1) C_noret;
static void f_2412(C_word c,C_word t0,C_word t1) C_noret;
static void f_2339(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2343(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2364(C_word c,C_word t0,C_word t1) C_noret;
static void f_2276(C_word c,C_word t0,C_word t1) C_noret;
static void f_2334(C_word c,C_word t0,C_word t1) C_noret;
static void f_2280(C_word c,C_word t0,C_word t1) C_noret;
static void f_2283(C_word c,C_word t0,C_word t1) C_noret;
static void f_2315(C_word c,C_word t0,C_word t1) C_noret;
static void f_2286(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2291(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2305(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2273(C_word t0);
static void f_2219(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2268(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2223(C_word t0,C_word t1) C_noret;
static void f_2233(C_word c,C_word t0,C_word t1) C_noret;
static void f_2237(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2243(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2247(C_word c,C_word t0,C_word t1) C_noret;
static void f_2257(C_word c,C_word t0,C_word t1) C_noret;
static void f_2241(C_word c,C_word t0,C_word t1) C_noret;
static void f_2174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2211(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2178(C_word t0,C_word t1) C_noret;
static void f_2188(C_word c,C_word t0,C_word t1) C_noret;
static void f_2192(C_word c,C_word t0,C_word t1) C_noret;
static void f_2196(C_word c,C_word t0,C_word t1) C_noret;
static void f_2200(C_word c,C_word t0,C_word t1) C_noret;
static void f_2204(C_word c,C_word t0,C_word t1) C_noret;
static void f_2136(C_word c,C_word t0,C_word t1) C_noret;
static void f_2169(C_word c,C_word t0,C_word t1) C_noret;
static void f_2140(C_word c,C_word t0,C_word t1) C_noret;
static void f_2147(C_word c,C_word t0,C_word t1) C_noret;
static void f_2151(C_word c,C_word t0,C_word t1) C_noret;
static void f_2155(C_word c,C_word t0,C_word t1) C_noret;
static void f_2159(C_word c,C_word t0,C_word t1) C_noret;
static void f_2163(C_word c,C_word t0,C_word t1) C_noret;
static void f_2115(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2119(C_word c,C_word t0,C_word t1) C_noret;
static void f_2097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2107(C_word c,C_word t0,C_word t1) C_noret;
static void f_2087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2044(C_word c,C_word t0,C_word t1) C_noret;
static void f_2048(C_word c,C_word t0,C_word t1) C_noret;
static void f_2024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2024r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2028(C_word c,C_word t0,C_word t1) C_noret;
static void f_2034(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2034r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2038(C_word c,C_word t0,C_word t1) C_noret;
static void f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2004r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2008(C_word c,C_word t0,C_word t1) C_noret;
static void f_2014(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2014r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2018(C_word c,C_word t0,C_word t1) C_noret;
static void f_1980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1980r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1984(C_word c,C_word t0,C_word t1) C_noret;
static void f_1995(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1995r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1999(C_word c,C_word t0,C_word t1) C_noret;
static void f_1989(C_word c,C_word t0,C_word t1) C_noret;
static void f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1956r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1960(C_word c,C_word t0,C_word t1) C_noret;
static void f_1971(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1971r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1975(C_word c,C_word t0,C_word t1) C_noret;
static void f_1965(C_word c,C_word t0,C_word t1) C_noret;
static void f_1943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1947(C_word c,C_word t0,C_word t1) C_noret;
static void f_1910(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1910r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1938(C_word c,C_word t0,C_word t1) C_noret;
static void f_1928(C_word c,C_word t0,C_word t1) C_noret;
static void f_1921(C_word c,C_word t0,C_word t1) C_noret;
static void f_1877(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1877r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1905(C_word c,C_word t0,C_word t1) C_noret;
static void f_1895(C_word c,C_word t0,C_word t1) C_noret;
static void f_1888(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1862(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1875(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1856(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1844(C_word t0);
static void f_1804(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1804r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_1808(C_word t0,C_word t1) C_noret;
static void f_1817(C_word c,C_word t0,C_word t1) C_noret;
static void f_1784(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1802(C_word c,C_word t0,C_word t1) C_noret;
static void f_1788(C_word c,C_word t0,C_word t1) C_noret;
static void f_1733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1737(C_word c,C_word t0,C_word t1) C_noret;
static void f_1740(C_word c,C_word t0,C_word t1) C_noret;
static void f_1743(C_word c,C_word t0,C_word t1) C_noret;
static void f_1782(C_word c,C_word t0,C_word t1) C_noret;
static void f_1747(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1761(C_word t0,C_word t1) C_noret;
static void f_1771(C_word c,C_word t0,C_word t1) C_noret;
static void f_1778(C_word c,C_word t0,C_word t1) C_noret;
static void f_1712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1731(C_word c,C_word t0,C_word t1) C_noret;
static void f_1727(C_word c,C_word t0,C_word t1) C_noret;
static void f_1691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1710(C_word c,C_word t0,C_word t1) C_noret;
static void f_1706(C_word c,C_word t0,C_word t1) C_noret;
static void f_1670(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1689(C_word c,C_word t0,C_word t1) C_noret;
static void f_1685(C_word c,C_word t0,C_word t1) C_noret;
static void f_1618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1618r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1625(C_word c,C_word t0,C_word t1) C_noret;
static void f_1637(C_word c,C_word t0,C_word t1) C_noret;
static void f_1631(C_word c,C_word t0,C_word t1) C_noret;
static void f_1581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1597(C_word c,C_word t0,C_word t1) C_noret;
static void f_1585(C_word c,C_word t0,C_word t1) C_noret;
static void f_1588(C_word c,C_word t0,C_word t1) C_noret;
static void f_1575(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1579(C_word c,C_word t0,C_word t1) C_noret;
static void f_1569(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1573(C_word c,C_word t0,C_word t1) C_noret;
static void f_1563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1567(C_word c,C_word t0,C_word t1) C_noret;
static void f_1557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1561(C_word c,C_word t0,C_word t1) C_noret;
static void f_1551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1555(C_word c,C_word t0,C_word t1) C_noret;
static void f_1545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1549(C_word c,C_word t0,C_word t1) C_noret;
static void f_1539(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1543(C_word c,C_word t0,C_word t1) C_noret;
static void f_1533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1537(C_word c,C_word t0,C_word t1) C_noret;
static void f_1504(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1504r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1515(C_word t0,C_word t1) C_noret;
static void f_1508(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1467(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1499(C_word c,C_word t0,C_word t1) C_noret;
static void f_1492(C_word c,C_word t0,C_word t1) C_noret;
static void f_1471(C_word c,C_word t0,C_word t1) C_noret;
static void f_1290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1290r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1306(C_word c,C_word t0,C_word t1) C_noret;
static void f_1431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1312(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1315(C_word t0,C_word t1) C_noret;
static void f_1397(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1395(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1354(C_word t0,C_word t1) C_noret;
static void f_1372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1370(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1358(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1288(C_word t0,C_word t1);
static C_word C_fcall f_1286(C_word t0,C_word t1);
static C_word C_fcall f_1284(C_word t0);
static void f_1255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1259(C_word c,C_word t0,C_word t1) C_noret;
static void f_1262(C_word c,C_word t0,C_word t1) C_noret;
static void f_1265(C_word c,C_word t0,C_word t1) C_noret;
static void f_1272(C_word c,C_word t0,C_word t1) C_noret;
static void f_1222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1226(C_word c,C_word t0,C_word t1) C_noret;
static void f_1232(C_word c,C_word t0,C_word t1) C_noret;
static void f_1186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1190(C_word c,C_word t0,C_word t1) C_noret;
static void f_1193(C_word c,C_word t0,C_word t1) C_noret;
static void f_1196(C_word c,C_word t0,C_word t1) C_noret;
static void f_1174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1145r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1166(C_word c,C_word t0,C_word t1) C_noret;
static void f_1153(C_word c,C_word t0,C_word t1) C_noret;
static void f_1156(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1090(C_word t0) C_noret;
static void f_1096(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1105(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1073(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1077(C_word c,C_word t0,C_word t1) C_noret;
static void f_1088(C_word c,C_word t0,C_word t1) C_noret;
static void f_1084(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1065(C_word t0);

static void C_fcall trf_4445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4445(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4445(t0,t1);}

static void C_fcall trf_4440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4440(t0,t1,t2);}

static void C_fcall trf_4435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4435(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4435(t0,t1,t2,t3);}

static void C_fcall trf_4299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4299(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4299(t0,t1,t2,t3,t4);}

static void C_fcall trf_4303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4303(t0,t1);}

static void C_fcall trf_4315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4315(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4315(t0,t1,t2,t3);}

static void C_fcall trf_4252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4252(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4252(t0,t1);}

static void C_fcall trf_4247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4247(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4247(t0,t1,t2);}

static void C_fcall trf_3991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3991(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3991(t0,t1,t2,t3);}

static void C_fcall trf_4097(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4097(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4097(t0,t1);}

static void C_fcall trf_4040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4040(t0,t1);}

static void C_fcall trf_4054(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4054(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4054(t0,t1);}

static void C_fcall trf_3969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3969(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3969(t0,t1,t2);}

static void C_fcall trf_3778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3778(t0,t1);}

static void C_fcall trf_3773(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3773(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3773(t0,t1,t2);}

static void C_fcall trf_3661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3661(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3661(t0,t1,t2,t3);}

static void C_fcall trf_3673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3673(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3673(t0,t1,t2,t3);}

static void C_fcall trf_3686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3686(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3686(t0,t1);}

static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3505(t0,t1,t2);}

static void C_fcall trf_3539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3539(t0,t1,t2);}

static void C_fcall trf_3121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3121(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3121(t0,t1,t2);}

static void C_fcall trf_3133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3133(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3133(t0,t1,t2);}

static void C_fcall trf_3036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3036(t0,t1);}

static void C_fcall trf_2937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2937(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2937(t0,t1,t2,t3);}

static void C_fcall trf_2875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2875(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2875(t0,t1,t2);}

static void C_fcall trf_2894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2894(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2894(t0,t1);}

static void C_fcall trf_2822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2822(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2822(t0,t1);}

static void C_fcall trf_2739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2739(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2739(t0,t1,t2,t3,t4);}

static void C_fcall trf_2702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2702(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2702(t0,t1,t2);}

static void C_fcall trf_2528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2528(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2528(t0,t1,t2);}

static void C_fcall trf_2348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2348(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2348(t0,t1,t2,t3);}

static void C_fcall trf_2291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2291(t0,t1,t2);}

static void C_fcall trf_2223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2223(t0,t1);}

static void C_fcall trf_2243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2243(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2243(t0,t1,t2);}

static void C_fcall trf_2178(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2178(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2178(t0,t1);}

static void C_fcall trf_1862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1862(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1862(t0,t1,t2,t3,t4);}

static void C_fcall trf_1856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1856(t0,t1);}

static void C_fcall trf_1808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1808(t0,t1);}

static void C_fcall trf_1761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1761(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1761(t0,t1);}

static void C_fcall trf_1515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1515(t0,t1);}

static void C_fcall trf_1467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1467(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1467(t0,t1,t2,t3);}

static void C_fcall trf_1315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1315(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1315(t0,t1);}

static void C_fcall trf_1354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1354(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1354(t0,t1);}

static void C_fcall trf_1358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1358(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1358(t0,t1);}

static void C_fcall trf_1090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1090(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1090(t0);}

static void C_fcall trf_1073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1073(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1073(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2295)){
C_save(t1);
C_rereclaim2(2295*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,354);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_h_intern(&lf[3],13,"string-append");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_static_string(C_heaptop,3," - ");
lf[7]=C_h_intern(&lf[7],17,"\003syspeek-c-string");
lf[8]=C_h_intern(&lf[8],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],18,"\003syscurrent-thread");
lf[11]=C_h_intern(&lf[11],12,"\003sysschedule");
lf[12]=C_h_intern(&lf[12],8,"pipe/buf");
lf[13]=C_h_intern(&lf[13],11,"open/rdonly");
lf[14]=C_h_intern(&lf[14],11,"open/wronly");
lf[15]=C_h_intern(&lf[15],9,"open/rdwr");
lf[16]=C_h_intern(&lf[16],9,"open/read");
lf[17]=C_h_intern(&lf[17],10,"open/write");
lf[18]=C_h_intern(&lf[18],10,"open/creat");
lf[19]=C_h_intern(&lf[19],11,"open/append");
lf[20]=C_h_intern(&lf[20],9,"open/excl");
lf[21]=C_h_intern(&lf[21],11,"open/noctty");
lf[22]=C_h_intern(&lf[22],13,"open/nonblock");
lf[23]=C_h_intern(&lf[23],10,"open/trunc");
lf[24]=C_h_intern(&lf[24],9,"open/sync");
lf[25]=C_h_intern(&lf[25],10,"open/fsync");
lf[26]=C_h_intern(&lf[26],11,"open/binary");
lf[27]=C_h_intern(&lf[27],9,"open/text");
lf[28]=C_h_intern(&lf[28],10,"perm/irusr");
lf[29]=C_h_intern(&lf[29],10,"perm/iwusr");
lf[30]=C_h_intern(&lf[30],10,"perm/ixusr");
lf[31]=C_h_intern(&lf[31],10,"perm/irgrp");
lf[32]=C_h_intern(&lf[32],10,"perm/iwgrp");
lf[33]=C_h_intern(&lf[33],10,"perm/ixgrp");
lf[34]=C_h_intern(&lf[34],10,"perm/iroth");
lf[35]=C_h_intern(&lf[35],10,"perm/iwoth");
lf[36]=C_h_intern(&lf[36],10,"perm/ixoth");
lf[37]=C_h_intern(&lf[37],10,"perm/irwxu");
lf[38]=C_h_intern(&lf[38],10,"perm/irwxg");
lf[39]=C_h_intern(&lf[39],10,"perm/irwxo");
lf[40]=C_h_intern(&lf[40],10,"perm/isvtx");
lf[41]=C_h_intern(&lf[41],10,"perm/isuid");
lf[42]=C_h_intern(&lf[42],10,"perm/isgid");
lf[43]=C_h_intern(&lf[43],9,"file-open");
lf[44]=C_h_intern(&lf[44],11,"\000file-error");
lf[45]=C_static_string(C_heaptop,17,"can not open file");
lf[46]=C_h_intern(&lf[46],17,"\003sysmake-c-string");
lf[47]=C_h_intern(&lf[47],20,"\003sysexpand-home-path");
lf[48]=C_h_intern(&lf[48],10,"file-close");
lf[49]=C_static_string(C_heaptop,18,"can not close file");
lf[50]=C_h_intern(&lf[50],11,"make-string");
lf[51]=C_h_intern(&lf[51],9,"file-read");
lf[52]=C_static_string(C_heaptop,22,"can not read from file");
lf[53]=C_h_intern(&lf[53],11,"\000type-error");
lf[54]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[55]=C_h_intern(&lf[55],10,"file-write");
lf[56]=C_static_string(C_heaptop,21,"can not write to file");
lf[57]=C_static_string(C_heaptop,47,"bad argument type - not a string or byte-vector");
lf[58]=C_h_intern(&lf[58],13,"string-length");
lf[59]=C_h_intern(&lf[59],12,"file-mkstemp");
lf[60]=C_h_intern(&lf[60],13,"\003syssubstring");
lf[61]=C_static_string(C_heaptop,29,"can not create temporary file");
lf[62]=C_h_intern(&lf[62],11,"file-select");
lf[63]=C_static_string(C_heaptop,6,"failed");
lf[64]=C_h_intern(&lf[64],12,"\003sysfor-each");
lf[65]=C_h_intern(&lf[65],8,"seek/set");
lf[66]=C_h_intern(&lf[66],8,"seek/end");
lf[67]=C_h_intern(&lf[67],8,"seek/cur");
lf[69]=C_static_string(C_heaptop,19,"can not access file");
lf[70]=C_static_string(C_heaptop,42,"bad argument type - not a fixnum or string");
lf[71]=C_h_intern(&lf[71],9,"file-stat");
lf[72]=C_h_intern(&lf[72],9,"file-size");
lf[73]=C_h_intern(&lf[73],22,"file-modification-time");
lf[74]=C_h_intern(&lf[74],16,"file-access-time");
lf[75]=C_h_intern(&lf[75],16,"file-change-time");
lf[76]=C_h_intern(&lf[76],10,"file-owner");
lf[77]=C_h_intern(&lf[77],16,"file-permissions");
lf[78]=C_h_intern(&lf[78],13,"regular-file\077");
lf[79]=C_h_intern(&lf[79],14,"symbolic-link\077");
lf[80]=C_h_intern(&lf[80],13,"file-position");
lf[81]=C_static_string(C_heaptop,38,"can not retrieve file position of port");
lf[82]=C_h_intern(&lf[82],6,"stream");
lf[83]=C_static_string(C_heaptop,12,"invalid file");
lf[84]=C_h_intern(&lf[84],5,"port\077");
lf[85]=C_h_intern(&lf[85],18,"set-file-position!");
lf[86]=C_static_string(C_heaptop,25,"can not set file position");
lf[87]=C_static_string(C_heaptop,12,"invalid file");
lf[88]=C_h_intern(&lf[88],13,"\000bounds-error");
lf[89]=C_static_string(C_heaptop,30,"invalid negative port position");
lf[90]=C_h_intern(&lf[90],16,"create-directory");
lf[91]=C_static_string(C_heaptop,24,"can not create directory");
lf[92]=C_h_intern(&lf[92],16,"change-directory");
lf[93]=C_static_string(C_heaptop,32,"can not change current directory");
lf[94]=C_h_intern(&lf[94],16,"delete-directory");
lf[95]=C_static_string(C_heaptop,24,"can not delete directory");
lf[96]=C_h_intern(&lf[96],6,"string");
lf[97]=C_h_intern(&lf[97],9,"substring");
lf[98]=C_h_intern(&lf[98],9,"directory");
lf[99]=C_static_string(C_heaptop,22,"can not open directory");
lf[100]=C_h_intern(&lf[100],16,"\003sysmake-pointer");
lf[101]=C_h_intern(&lf[101],10,"directory\077");
lf[102]=C_h_intern(&lf[102],13,"\003sysfile-info");
lf[103]=C_h_intern(&lf[103],17,"current-directory");
lf[104]=C_static_string(C_heaptop,34,"can not retrieve current directory");
lf[105]=C_h_intern(&lf[105],5,"\000text");
lf[106]=C_h_intern(&lf[106],9,"\003syserror");
lf[107]=C_static_string(C_heaptop,35,"illegal input/output mode specifier");
lf[108]=C_static_string(C_heaptop,17,"can not open pipe");
lf[109]=C_h_intern(&lf[109],13,"\003sysmake-port");
lf[110]=C_h_intern(&lf[110],21,"\003sysstream-port-class");
lf[111]=C_static_string(C_heaptop,6,"(pipe)");
lf[112]=C_h_intern(&lf[112],15,"open-input-pipe");
lf[113]=C_h_intern(&lf[113],7,"\000binary");
lf[114]=C_h_intern(&lf[114],16,"open-output-pipe");
lf[115]=C_h_intern(&lf[115],16,"close-input-pipe");
lf[116]=C_h_intern(&lf[116],23,"close-input/output-pipe");
lf[117]=C_static_string(C_heaptop,24,"error while closing pipe");
lf[118]=C_h_intern(&lf[118],17,"close-output-pipe");
lf[119]=C_h_intern(&lf[119],20,"call-with-input-pipe");
lf[120]=C_h_intern(&lf[120],21,"call-with-output-pipe");
lf[121]=C_h_intern(&lf[121],20,"with-input-from-pipe");
lf[122]=C_h_intern(&lf[122],18,"\003sysstandard-input");
lf[123]=C_h_intern(&lf[123],19,"with-output-to-pipe");
lf[124]=C_h_intern(&lf[124],19,"\003sysstandard-output");
lf[125]=C_h_intern(&lf[125],11,"create-pipe");
lf[126]=C_static_string(C_heaptop,19,"can not create pipe");
lf[127]=C_h_intern(&lf[127],11,"signal/term");
lf[128]=C_h_intern(&lf[128],11,"signal/kill");
lf[129]=C_h_intern(&lf[129],10,"signal/int");
lf[130]=C_h_intern(&lf[130],10,"signal/hup");
lf[131]=C_h_intern(&lf[131],10,"signal/fpe");
lf[132]=C_h_intern(&lf[132],10,"signal/ill");
lf[133]=C_h_intern(&lf[133],11,"signal/segv");
lf[134]=C_h_intern(&lf[134],11,"signal/abrt");
lf[135]=C_h_intern(&lf[135],11,"signal/trap");
lf[136]=C_h_intern(&lf[136],11,"signal/quit");
lf[137]=C_h_intern(&lf[137],11,"signal/alrm");
lf[138]=C_h_intern(&lf[138],13,"signal/vtalrm");
lf[139]=C_h_intern(&lf[139],11,"signal/prof");
lf[140]=C_h_intern(&lf[140],9,"signal/io");
lf[141]=C_h_intern(&lf[141],10,"signal/urg");
lf[142]=C_h_intern(&lf[142],11,"signal/chld");
lf[143]=C_h_intern(&lf[143],11,"signal/cont");
lf[144]=C_h_intern(&lf[144],11,"signal/stop");
lf[145]=C_h_intern(&lf[145],11,"signal/tstp");
lf[146]=C_h_intern(&lf[146],11,"signal/pipe");
lf[147]=C_h_intern(&lf[147],11,"signal/xcpu");
lf[148]=C_h_intern(&lf[148],11,"signal/xfsz");
lf[149]=C_h_intern(&lf[149],11,"signal/usr1");
lf[150]=C_h_intern(&lf[150],11,"signal/usr2");
lf[151]=C_h_intern(&lf[151],12,"signal/winch");
lf[152]=C_h_intern(&lf[152],18,"\003sysinterrupt-hook");
lf[153]=C_h_intern(&lf[153],19,"set-signal-handler!");
lf[154]=C_h_intern(&lf[154],18,"\003syscontext-switch");
lf[155]=C_h_intern(&lf[155],16,"set-signal-mask!");
lf[156]=C_h_intern(&lf[156],14,"\000process-error");
lf[157]=C_static_string(C_heaptop,23,"can not set signal mask");
lf[158]=C_h_intern(&lf[158],18,"system-information");
lf[159]=C_h_intern(&lf[159],25,"\003syspeek-nonnull-c-string");
lf[160]=C_static_string(C_heaptop,35,"can not retrieve system information");
lf[161]=C_h_intern(&lf[161],16,"user-information");
lf[162]=C_h_intern(&lf[162],17,"group-information");
lf[164]=C_h_intern(&lf[164],10,"get-groups");
lf[165]=C_static_string(C_heaptop,40,"can not retrieve supplementary group ids");
lf[166]=C_static_string(C_heaptop,13,"out of memory");
lf[167]=C_static_string(C_heaptop,40,"can not retrieve supplementary group ids");
lf[168]=C_h_intern(&lf[168],11,"set-groups!");
lf[169]=C_static_string(C_heaptop,35,"can not set supplementary group ids");
lf[170]=C_static_string(C_heaptop,13,"out of memory");
lf[171]=C_h_intern(&lf[171],17,"initialize-groups");
lf[172]=C_static_string(C_heaptop,42,"can not initialize supplementary group ids");
lf[173]=C_h_intern(&lf[173],10,"errno/perm");
lf[174]=C_h_intern(&lf[174],11,"errno/noent");
lf[175]=C_h_intern(&lf[175],10,"errno/srch");
lf[176]=C_h_intern(&lf[176],10,"errno/intr");
lf[177]=C_h_intern(&lf[177],8,"errno/io");
lf[178]=C_h_intern(&lf[178],12,"errno/noexec");
lf[179]=C_h_intern(&lf[179],10,"errno/badf");
lf[180]=C_h_intern(&lf[180],11,"errno/child");
lf[181]=C_h_intern(&lf[181],11,"errno/nomem");
lf[182]=C_h_intern(&lf[182],11,"errno/acces");
lf[183]=C_h_intern(&lf[183],11,"errno/fault");
lf[184]=C_h_intern(&lf[184],10,"errno/busy");
lf[185]=C_h_intern(&lf[185],12,"errno/notdir");
lf[186]=C_h_intern(&lf[186],11,"errno/isdir");
lf[187]=C_h_intern(&lf[187],11,"errno/inval");
lf[188]=C_h_intern(&lf[188],11,"errno/mfile");
lf[189]=C_h_intern(&lf[189],11,"errno/nospc");
lf[190]=C_h_intern(&lf[190],11,"errno/spipe");
lf[191]=C_h_intern(&lf[191],10,"errno/pipe");
lf[192]=C_h_intern(&lf[192],11,"errno/again");
lf[193]=C_h_intern(&lf[193],10,"errno/rofs");
lf[194]=C_h_intern(&lf[194],11,"errno/exist");
lf[195]=C_h_intern(&lf[195],16,"errno/wouldblock");
lf[196]=C_h_intern(&lf[196],16,"change-file-mode");
lf[197]=C_static_string(C_heaptop,24,"can not change file mode");
lf[198]=C_h_intern(&lf[198],17,"change-file-owner");
lf[199]=C_static_string(C_heaptop,25,"can not change file owner");
lf[200]=C_h_intern(&lf[200],15,"current-user-id");
lf[201]=C_h_intern(&lf[201],16,"current-group-id");
lf[202]=C_h_intern(&lf[202],25,"current-effective-user-id");
lf[203]=C_h_intern(&lf[203],26,"current-effective-group-id");
lf[204]=C_h_intern(&lf[204],12,"set-user-id!");
lf[205]=C_static_string(C_heaptop,19,"can not set user ID");
lf[206]=C_h_intern(&lf[206],13,"set-group-id!");
lf[207]=C_static_string(C_heaptop,20,"can not set group ID");
lf[208]=C_h_intern(&lf[208],17,"file-read-access\077");
lf[209]=C_h_intern(&lf[209],18,"file-write-access\077");
lf[210]=C_h_intern(&lf[210],20,"file-execute-access\077");
lf[211]=C_h_intern(&lf[211],14,"create-session");
lf[212]=C_static_string(C_heaptop,22,"can not create session");
lf[213]=C_h_intern(&lf[213],16,"process-group-id");
lf[214]=C_static_string(C_heaptop,33,"can not retrieve process group ID");
lf[215]=C_h_intern(&lf[215],21,"set-process-group-id!");
lf[216]=C_static_string(C_heaptop,28,"can not set process group ID");
lf[217]=C_h_intern(&lf[217],20,"create-symbolic-link");
lf[218]=C_h_intern(&lf[218],18,"create-symbol-link");
lf[219]=C_static_string(C_heaptop,28,"can not create symbolic link");
lf[220]=C_h_intern(&lf[220],18,"read-symbolic-link");
lf[221]=C_static_string(C_heaptop,26,"can not read symbolic link");
lf[222]=C_h_intern(&lf[222],9,"file-link");
lf[223]=C_h_intern(&lf[223],9,"hard-link");
lf[224]=C_static_string(C_heaptop,26,"could not create hard link");
lf[225]=C_h_intern(&lf[225],12,"fileno/stdin");
lf[226]=C_h_intern(&lf[226],13,"fileno/stdout");
lf[227]=C_h_intern(&lf[227],13,"fileno/stderr");
lf[228]=C_h_intern(&lf[228],7,"\000append");
lf[229]=C_static_string(C_heaptop,27,"invalid mode for input file");
lf[230]=C_static_string(C_heaptop,1,"a");
lf[231]=C_static_string(C_heaptop,21,"invalid mode argument");
lf[232]=C_static_string(C_heaptop,1,"r");
lf[233]=C_static_string(C_heaptop,1,"w");
lf[234]=C_static_string(C_heaptop,17,"can not open file");
lf[235]=C_static_string(C_heaptop,8,"(fdport)");
lf[236]=C_h_intern(&lf[236],16,"open-input-file*");
lf[237]=C_h_intern(&lf[237],17,"open-output-file*");
lf[238]=C_h_intern(&lf[238],12,"port->fileno");
lf[239]=C_h_intern(&lf[239],6,"socket");
lf[240]=C_h_intern(&lf[240],20,"\003systcp-port->fileno");
lf[241]=C_static_string(C_heaptop,25,"port has no attached file");
lf[242]=C_static_string(C_heaptop,38,"can not access file-descriptor of port");
lf[243]=C_h_intern(&lf[243],25,"\003syspeek-unsigned-integer");
lf[244]=C_h_intern(&lf[244],16,"duplicate-fileno");
lf[245]=C_static_string(C_heaptop,33,"can not duplicate file descriptor");
lf[246]=C_h_intern(&lf[246],13,"file-truncate");
lf[247]=C_static_string(C_heaptop,21,"can not truncate file");
lf[248]=C_static_string(C_heaptop,12,"invalid file");
lf[249]=C_h_intern(&lf[249],4,"lock");
lf[250]=C_h_intern(&lf[250],9,"file-lock");
lf[251]=C_static_string(C_heaptop,17,"can not lock file");
lf[252]=C_h_intern(&lf[252],18,"file-lock/blocking");
lf[253]=C_static_string(C_heaptop,17,"can not lock file");
lf[254]=C_h_intern(&lf[254],14,"file-test-lock");
lf[255]=C_static_string(C_heaptop,19,"can not unlock file");
lf[256]=C_h_intern(&lf[256],11,"file-unlock");
lf[257]=C_static_string(C_heaptop,19,"can not unlock file");
lf[258]=C_h_intern(&lf[258],11,"create-fifo");
lf[259]=C_static_string(C_heaptop,19,"can not create FIFO");
lf[260]=C_h_intern(&lf[260],5,"fifo\077");
lf[261]=C_static_string(C_heaptop,19,"file does not exist");
lf[262]=C_h_intern(&lf[262],6,"setenv");
lf[263]=C_h_intern(&lf[263],8,"unsetenv");
lf[264]=C_h_intern(&lf[264],19,"current-environment");
lf[265]=C_h_intern(&lf[265],9,"prot/read");
lf[266]=C_h_intern(&lf[266],10,"prot/write");
lf[267]=C_h_intern(&lf[267],9,"prot/exec");
lf[268]=C_h_intern(&lf[268],9,"prot/none");
lf[269]=C_h_intern(&lf[269],9,"map/fixed");
lf[270]=C_h_intern(&lf[270],10,"map/shared");
lf[271]=C_h_intern(&lf[271],11,"map/private");
lf[272]=C_h_intern(&lf[272],13,"map/anonymous");
lf[273]=C_h_intern(&lf[273],8,"map/file");
lf[274]=C_h_intern(&lf[274],18,"map-file-to-memory");
lf[275]=C_h_intern(&lf[275],4,"mmap");
lf[276]=C_static_string(C_heaptop,26,"can not map file to memory");
lf[277]=C_h_intern(&lf[277],20,"\003syspointer->address");
lf[278]=C_static_string(C_heaptop,41,"bad argument type - not a foreign pointer");
lf[279]=C_h_intern(&lf[279],16,"\003sysnull-pointer");
lf[280]=C_h_intern(&lf[280],22,"unmap-file-from-memory");
lf[281]=C_static_string(C_heaptop,30,"can not unmap file from memory");
lf[282]=C_h_intern(&lf[282],26,"memory-mapped-file-pointer");
lf[283]=C_h_intern(&lf[283],19,"memory-mapped-file\077");
lf[284]=C_h_intern(&lf[284],19,"seconds->local-time");
lf[285]=C_h_intern(&lf[285],18,"\003sysdecode-seconds");
lf[286]=C_h_intern(&lf[286],17,"seconds->utc-time");
lf[287]=C_h_intern(&lf[287],15,"seconds->string");
lf[288]=C_static_string(C_heaptop,33,"can not convert seconds to string");
lf[289]=C_h_intern(&lf[289],12,"time->string");
lf[290]=C_static_string(C_heaptop,29,"can not time vector to string");
lf[291]=C_static_string(C_heaptop,21,"time vector too short");
lf[292]=C_h_intern(&lf[292],5,"_exit");
lf[293]=C_h_intern(&lf[293],23,"\003syscleanup-before-exit");
lf[294]=C_h_intern(&lf[294],10,"set-alarm!");
lf[295]=C_h_intern(&lf[295],19,"set-buffering-mode!");
lf[296]=C_static_string(C_heaptop,26,"can not set buffering mode");
lf[297]=C_h_intern(&lf[297],5,"\000full");
lf[298]=C_h_intern(&lf[298],5,"\000line");
lf[299]=C_h_intern(&lf[299],5,"\000none");
lf[300]=C_static_string(C_heaptop,22,"invalid buffering-mode");
lf[301]=C_h_intern(&lf[301],14,"terminal-port\077");
lf[302]=C_h_intern(&lf[302],13,"terminal-name");
lf[303]=C_static_string(C_heaptop,35,"port is not connected to a terminal");
lf[304]=C_h_intern(&lf[304],13,"get-host-name");
lf[305]=C_h_intern(&lf[305],6,"\000error");
lf[306]=C_static_string(C_heaptop,26,"can not retrieve host-name");
lf[307]=C_h_intern(&lf[307],12,"glob->regexp");
lf[308]=C_h_intern(&lf[308],13,"make-pathname");
lf[309]=C_h_intern(&lf[309],18,"decompose-pathname");
lf[310]=C_h_intern(&lf[310],4,"glob");
lf[311]=C_h_intern(&lf[311],12,"string-match");
lf[312]=C_static_string(C_heaptop,1,".");
lf[313]=C_static_string(C_heaptop,1,"*");
lf[314]=C_h_intern(&lf[314],12,"process-fork");
lf[315]=C_static_string(C_heaptop,28,"can not create child process");
lf[316]=C_h_intern(&lf[316],24,"pathname-strip-directory");
lf[317]=C_h_intern(&lf[317],15,"process-execute");
lf[318]=C_static_string(C_heaptop,23,"can not execute process");
lf[319]=C_h_intern(&lf[319],12,"process-wait");
lf[320]=C_static_string(C_heaptop,32,"waiting for child process failed");
lf[321]=C_h_intern(&lf[321],18,"current-process-id");
lf[322]=C_h_intern(&lf[322],17,"parent-process-id");
lf[323]=C_h_intern(&lf[323],5,"sleep");
lf[324]=C_h_intern(&lf[324],14,"process-signal");
lf[325]=C_static_string(C_heaptop,32,"could not send signal to process");
lf[326]=C_h_intern(&lf[326],6,"getenv");
lf[327]=C_h_intern(&lf[327],11,"process-run");
lf[328]=C_static_string(C_heaptop,7,"/bin/sh");
lf[329]=C_static_string(C_heaptop,2,"-c");
lf[330]=C_static_string(C_heaptop,5,"SHELL");
lf[331]=C_h_intern(&lf[331],15,"make-input-port");
lf[332]=C_h_intern(&lf[332],16,"make-output-port");
lf[333]=C_h_intern(&lf[333],7,"process");
lf[334]=C_static_string(C_heaptop,25,"process exited abnormally");
lf[335]=C_h_intern(&lf[335],25,"\003systhread-block-for-i/o!");
lf[336]=C_static_string(C_heaptop,22,"can not read from pipe");
lf[337]=C_static_string(C_heaptop,21,"can not write to pipe");
lf[338]=C_static_string(C_heaptop,7,"/bin/sh");
lf[339]=C_static_string(C_heaptop,2,"-c");
lf[340]=C_static_string(C_heaptop,5,"SHELL");
lf[341]=C_h_intern(&lf[341],10,"find-files");
lf[342]=C_static_string(C_heaptop,1,".");
lf[343]=C_static_string(C_heaptop,2,"..");
lf[344]=C_static_string(C_heaptop,1,"*");
lf[345]=C_h_intern(&lf[345],16,"\003sysdynamic-wind");
lf[346]=C_h_intern(&lf[346],13,"pathname-file");
lf[347]=C_static_string(C_heaptop,1,"*");
lf[348]=C_h_intern(&lf[348],19,"set-root-directory!");
lf[349]=C_static_string(C_heaptop,31,"unable to change root directory");
lf[350]=C_h_intern(&lf[350],23,"\003sysuser-interrupt-hook");
lf[351]=C_h_intern(&lf[351],11,"make-vector");
lf[352]=C_h_intern(&lf[352],17,"register-feature!");
lf[353]=C_h_intern(&lf[353],5,"posix");
C_register_lf(lf,354);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1051,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1049 */
static void f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1052 in k1049 */
static void f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1057,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1055 in k1052 in k1049 */
static void f_1057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1058 in k1055 in k1052 in k1049 */
static void f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1063,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[352]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[353]);}

/* k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word ab[119],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1065,tmp=(C_word)a,a+=2,tmp));
t3=*((C_word*)lf[3]+1);
t4=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1073,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[9],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1090,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[12]+1,C_fix((C_word)PIPE_BUF));
t7=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_RDONLY));
t8=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_WRONLY));
t9=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_RDONLY));
t11=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_WRONLY));
t12=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_CREAT));
t13=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_APPEND));
t14=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_EXCL));
t15=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_NOCTTY));
t16=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_NONBLOCK));
t17=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_TRUNC));
t18=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_FSYNC));
t19=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_FSYNC));
t20=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_BINARY));
t21=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_TEXT));
t22=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IRUSR));
t23=C_mutate((C_word*)lf[29]+1,C_fix((C_word)S_IWUSR));
t24=C_mutate((C_word*)lf[30]+1,C_fix((C_word)S_IXUSR));
t25=C_mutate((C_word*)lf[31]+1,C_fix((C_word)S_IRGRP));
t26=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IWGRP));
t27=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IXGRP));
t28=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IROTH));
t29=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IWOTH));
t30=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IXOTH));
t31=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IRWXU));
t32=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IRWXG));
t33=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IRWXO));
t34=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_ISVTX));
t35=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_ISUID));
t36=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_ISGID));
t37=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t38=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t37);
t39=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1145,a[2]=t38,tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1174,tmp=(C_word)a,a+=2,tmp));
t41=*((C_word*)lf[50]+1);
t42=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1186,a[2]=t41,tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1222,tmp=(C_word)a,a+=2,tmp));
t44=*((C_word*)lf[58]+1);
t45=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1255,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1284,tmp=(C_word)a,a+=2,tmp);
t47=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1286,tmp=(C_word)a,a+=2,tmp);
t48=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1288,tmp=(C_word)a,a+=2,tmp);
t49=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1290,a[2]=t47,a[3]=t48,a[4]=t46,tmp=(C_word)a,a+=5,tmp));
t50=C_mutate((C_word*)lf[65]+1,C_fix((C_word)SEEK_SET));
t51=C_mutate((C_word*)lf[66]+1,C_fix((C_word)SEEK_END));
t52=C_mutate((C_word*)lf[67]+1,C_fix((C_word)SEEK_CUR));
t53=C_mutate(&lf[68],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1467,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1504,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1533,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1539,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1545,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1551,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1557,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1563,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1569,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1575,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1581,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1618,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[90]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1670,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1691,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1712,tmp=(C_word)a,a+=2,tmp));
t68=*((C_word*)lf[3]+1);
t69=*((C_word*)lf[50]+1);
t70=*((C_word*)lf[96]+1);
t71=*((C_word*)lf[97]+1);
t72=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1733,a[2]=t69,a[3]=t71,tmp=(C_word)a,a+=4,tmp));
t73=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1784,tmp=(C_word)a,a+=2,tmp));
t74=*((C_word*)lf[50]+1);
t75=*((C_word*)lf[97]+1);
t76=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1804,a[2]=t74,a[3]=t75,tmp=(C_word)a,a+=4,tmp));
t77=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1844,tmp=(C_word)a,a+=2,tmp);
t78=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1856,tmp=(C_word)a,a+=2,tmp);
t79=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1862,tmp=(C_word)a,a+=2,tmp);
t80=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1877,a[2]=t78,a[3]=t79,a[4]=t77,tmp=(C_word)a,a+=5,tmp));
t81=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1910,a[2]=t78,a[3]=t79,a[4]=t77,tmp=(C_word)a,a+=5,tmp));
t82=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1943,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[118]+1,*((C_word*)lf[115]+1));
t84=*((C_word*)lf[112]+1);
t85=*((C_word*)lf[114]+1);
t86=*((C_word*)lf[115]+1);
t87=*((C_word*)lf[118]+1);
t88=C_mutate((C_word*)lf[119]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1956,a[2]=t84,a[3]=t86,tmp=(C_word)a,a+=4,tmp));
t89=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=t85,a[3]=t87,tmp=(C_word)a,a+=4,tmp));
t90=C_mutate((C_word*)lf[121]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2004,a[2]=t84,a[3]=t86,tmp=(C_word)a,a+=4,tmp));
t91=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=t85,a[3]=t87,tmp=(C_word)a,a+=4,tmp));
t92=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2044,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[127]+1,C_fix((C_word)SIGTERM));
t94=C_mutate((C_word*)lf[128]+1,C_fix((C_word)SIGKILL));
t95=C_mutate((C_word*)lf[129]+1,C_fix((C_word)SIGINT));
t96=C_mutate((C_word*)lf[130]+1,C_fix((C_word)SIGHUP));
t97=C_mutate((C_word*)lf[131]+1,C_fix((C_word)SIGFPE));
t98=C_mutate((C_word*)lf[132]+1,C_fix((C_word)SIGILL));
t99=C_mutate((C_word*)lf[133]+1,C_fix((C_word)SIGSEGV));
t100=C_mutate((C_word*)lf[134]+1,C_fix((C_word)SIGABRT));
t101=C_mutate((C_word*)lf[135]+1,C_fix((C_word)SIGTRAP));
t102=C_mutate((C_word*)lf[136]+1,C_fix((C_word)SIGQUIT));
t103=C_mutate((C_word*)lf[137]+1,C_fix((C_word)SIGALRM));
t104=C_mutate((C_word*)lf[138]+1,C_fix((C_word)SIGVTALRM));
t105=C_mutate((C_word*)lf[139]+1,C_fix((C_word)SIGPROF));
t106=C_mutate((C_word*)lf[140]+1,C_fix((C_word)SIGIO));
t107=C_mutate((C_word*)lf[141]+1,C_fix((C_word)SIGURG));
t108=C_mutate((C_word*)lf[142]+1,C_fix((C_word)SIGCHLD));
t109=C_mutate((C_word*)lf[143]+1,C_fix((C_word)SIGCONT));
t110=C_mutate((C_word*)lf[144]+1,C_fix((C_word)SIGSTOP));
t111=C_mutate((C_word*)lf[145]+1,C_fix((C_word)SIGTSTP));
t112=C_mutate((C_word*)lf[146]+1,C_fix((C_word)SIGPIPE));
t113=C_mutate((C_word*)lf[147]+1,C_fix((C_word)SIGXCPU));
t114=C_mutate((C_word*)lf[148]+1,C_fix((C_word)SIGXFSZ));
t115=C_mutate((C_word*)lf[149]+1,C_fix((C_word)SIGUSR1));
t116=C_mutate((C_word*)lf[150]+1,C_fix((C_word)SIGUSR2));
t117=C_mutate((C_word*)lf[151]+1,C_fix((C_word)SIGWINCH));
t118=*((C_word*)lf[152]+1);
t119=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[2],a[3]=t118,tmp=(C_word)a,a+=4,tmp);
t120=*((C_word*)lf[351]+1);
((C_proc4)(void*)(*((C_word*)t120+1)))(4,t120,t119,C_fix(256),C_SCHEME_FALSE);}

/* k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=C_mutate((C_word*)lf[153]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2087,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2115,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4540,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[153]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,*((C_word*)lf[129]+1),t6);}

/* a4539 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4540(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4540,3,t0,t1,t2);}
t3=*((C_word*)lf[350]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2136,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[161]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2174,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2219,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[163],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2273,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2276,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2339,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[171]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2402,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[173]+1,C_fix((C_word)EPERM));
t10=C_mutate((C_word*)lf[174]+1,C_fix((C_word)ENOENT));
t11=C_mutate((C_word*)lf[175]+1,C_fix((C_word)ESRCH));
t12=C_mutate((C_word*)lf[176]+1,C_fix((C_word)EINTR));
t13=C_mutate((C_word*)lf[177]+1,C_fix((C_word)EIO));
t14=C_mutate((C_word*)lf[178]+1,C_fix((C_word)ENOEXEC));
t15=C_mutate((C_word*)lf[179]+1,C_fix((C_word)EBADF));
t16=C_mutate((C_word*)lf[180]+1,C_fix((C_word)ECHILD));
t17=C_mutate((C_word*)lf[181]+1,C_fix((C_word)ENOMEM));
t18=C_mutate((C_word*)lf[182]+1,C_fix((C_word)EACCES));
t19=C_mutate((C_word*)lf[183]+1,C_fix((C_word)EFAULT));
t20=C_mutate((C_word*)lf[184]+1,C_fix((C_word)EBUSY));
t21=C_mutate((C_word*)lf[185]+1,C_fix((C_word)ENOTDIR));
t22=C_mutate((C_word*)lf[186]+1,C_fix((C_word)EISDIR));
t23=C_mutate((C_word*)lf[187]+1,C_fix((C_word)EINVAL));
t24=C_mutate((C_word*)lf[188]+1,C_fix((C_word)EMFILE));
t25=C_mutate((C_word*)lf[189]+1,C_fix((C_word)ENOSPC));
t26=C_mutate((C_word*)lf[190]+1,C_fix((C_word)ESPIPE));
t27=C_mutate((C_word*)lf[191]+1,C_fix((C_word)EPIPE));
t28=C_mutate((C_word*)lf[192]+1,C_fix((C_word)EAGAIN));
t29=C_mutate((C_word*)lf[193]+1,C_fix((C_word)EROFS));
t30=C_mutate((C_word*)lf[194]+1,C_fix((C_word)EEXIST));
t31=C_mutate((C_word*)lf[195]+1,C_fix((C_word)EWOULDBLOCK));
t32=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2444,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[198]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2465,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[200]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2486,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[201]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2489,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2492,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2495,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[204]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2498,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[206]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2513,tmp=(C_word)a,a+=2,tmp));
t40=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2528,tmp=(C_word)a,a+=2,tmp);
t41=C_mutate((C_word*)lf[208]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2549,a[2]=t40,tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2555,a[2]=t40,tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2561,a[2]=t40,tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[211]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2567,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2582,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2597,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[217]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2612,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[97]+1);
t49=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2643,a[2]=((C_word*)t0)[2],a[3]=t48,tmp=(C_word)a,a+=4,tmp);
t50=(C_word)C_u_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
t51=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t51+1)))(3,t51,t49,t50);}

/* k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word ab[133],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2643,2,t0,t1);}
t2=C_mutate((C_word*)lf[220]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2683,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[225]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[226]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[227]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2702,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2739,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[236]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2754,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2765,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[238]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2776,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2818,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2839,tmp=(C_word)a,a+=2,tmp));
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2875,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2937,tmp=(C_word)a,a+=2,tmp);
t16=C_mutate((C_word*)lf[250]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2955,a[2]=t14,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[252]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2970,a[2]=t14,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t18=C_mutate((C_word*)lf[254]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2985,a[2]=t14,a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t19=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3007,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3032,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3069,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[262]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3092,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[263]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3103,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[264]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3115,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[265]+1,C_fix((C_word)PROT_READ));
t26=C_mutate((C_word*)lf[266]+1,C_fix((C_word)PROT_WRITE));
t27=C_mutate((C_word*)lf[267]+1,C_fix((C_word)PROT_EXEC));
t28=C_mutate((C_word*)lf[268]+1,C_fix((C_word)PROT_NONE));
t29=C_mutate((C_word*)lf[269]+1,C_fix((C_word)MAP_FIXED));
t30=C_mutate((C_word*)lf[270]+1,C_fix((C_word)MAP_SHARED));
t31=C_mutate((C_word*)lf[271]+1,C_fix((C_word)MAP_PRIVATE));
t32=C_mutate((C_word*)lf[272]+1,C_fix((C_word)MAP_ANONYMOUS));
t33=C_mutate((C_word*)lf[273]+1,C_fix((C_word)MAP_FILE));
t34=C_mutate((C_word*)lf[274]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3198,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[280]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3256,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3288,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[283]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3294,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[284]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3300,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[286]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3306,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3317,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3334,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[292]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3364,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[294]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3383,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[295]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3386,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3439,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3460,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3487,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[307]+1);
t49=*((C_word*)lf[98]+1);
t50=*((C_word*)lf[308]+1);
t51=*((C_word*)lf[309]+1);
t52=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3499,a[2]=t48,a[3]=t49,a[4]=t50,a[5]=t51,tmp=(C_word)a,a+=6,tmp));
t53=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3605,tmp=(C_word)a,a+=2,tmp));
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3643,tmp=(C_word)a,a+=2,tmp);
t55=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3651,tmp=(C_word)a,a+=2,tmp);
t56=*((C_word*)lf[316]+1);
t57=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3659,a[2]=t56,a[3]=t55,a[4]=t54,tmp=(C_word)a,a+=5,tmp));
t58=C_mutate((C_word*)lf[319]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3823,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3893,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3896,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3899,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3902,tmp=(C_word)a,a+=2,tmp));
t63=*((C_word*)lf[314]+1);
t64=*((C_word*)lf[317]+1);
t65=*((C_word*)lf[326]+1);
t66=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3923,a[2]=t63,a[3]=t65,a[4]=t64,tmp=(C_word)a,a+=5,tmp));
t67=*((C_word*)lf[125]+1);
t68=*((C_word*)lf[314]+1);
t69=*((C_word*)lf[244]+1);
t70=*((C_word*)lf[48]+1);
t71=*((C_word*)lf[327]+1);
t72=*((C_word*)lf[50]+1);
t73=*((C_word*)lf[51]+1);
t74=*((C_word*)lf[331]+1);
t75=*((C_word*)lf[332]+1);
t76=*((C_word*)lf[55]+1);
t77=*((C_word*)lf[319]+1);
t78=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3969,a[2]=t77,tmp=(C_word)a,a+=3,tmp);
t79=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3989,a[2]=t68,a[3]=t69,a[4]=t72,a[5]=t74,a[6]=t75,a[7]=t70,a[8]=t78,a[9]=t67,tmp=(C_word)a,a+=10,tmp));
t80=*((C_word*)lf[310]+1);
t81=*((C_word*)lf[311]+1);
t82=*((C_word*)lf[308]+1);
t83=*((C_word*)lf[101]+1);
t84=C_mutate((C_word*)lf[341]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4297,a[2]=t83,a[3]=t82,a[4]=t80,a[5]=t81,tmp=(C_word)a,a+=6,tmp));
t85=C_mutate((C_word*)lf[348]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4520,tmp=(C_word)a,a+=2,tmp));
t86=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t86+1)))(2,t86,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4520,3,t0,t1,t2);}
t3=t2;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4516,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t5=t4;
f_4516(2,t5,C_SCHEME_FALSE);}}

/* k4514 in set-root-directory! in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4516,2,t0,t1);}
t2=(C_word)stub895(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[4];
f_1073(t3,((C_word*)t0)[3],lf[44],lf[348],lf[349],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4297(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_4297r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4297r(t0,t1,t2,t3,t4);}}

static void f_4297r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4299,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4435,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4440,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4445,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t9=t8;
f_4445(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
t11=t7;
f_4440(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
t13=t6;
f_4435(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
t15=t5;
f_4299(t15,t1,t9,t11,t13);}}}}

/* def-action853 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4445(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4445,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4451,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
f_4440(t3,t1,t2);}

/* a4450 in def-action853 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4451,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id854 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4440(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4440,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_4435(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit855 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4435(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4435,NULL,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
f_4299(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4299(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4299,NULL,5,t0,t1,t2,t3,t4);}
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t6,a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t8=t4;
if(C_truep(t8)){
t9=(C_word)C_fixnump(t4);
t10=t7;
f_4303(t10,(C_truep(t9)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4430,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t9=t7;
f_4303(t9,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4422,tmp=(C_word)a,a+=2,tmp));}}

/* f_4422 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4422(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4430 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4430(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4303,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4414,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4410,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],lf[347]);}

/* k4408 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4313,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_4315(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4315,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4390,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=*((C_word*)lf[346]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4396,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k4394 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4396,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)((C_word*)t0)[7])[1];
f_4315(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4401 in k4394 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_4315(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4390,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[342]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[343]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t2=((C_word*)((C_word*)t0)[10])[1];
f_4315(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k4347 in k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4359,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4361,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4380,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t11=*((C_word*)lf[345]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=((C_word*)((C_word*)t0)[8])[1];
f_4315(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a4379 in k4347 in k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4380,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a4365 in k4347 in k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4374,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4378,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[344]);}

/* k4376 in a4365 in k4347 in k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4372 in a4365 in k4347 in k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_4315(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a4360 in k4347 in k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4361,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4357 in k4347 in k4388 in k4332 in loop in k4311 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_4315(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_4414 in k4301 in body851 in find-files in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4414,3,t0,t1,t2);}
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3989(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3989r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3989r(t0,t1,t2,t3);}}

static void f_3989r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4247,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4252,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t7=t6;
f_4252(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
t9=t5;
f_4247(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
t11=t4;
f_3991(t11,t1,t7,t9);}}}

/* def-args763 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4252,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4247(t2,t1,C_SCHEME_FALSE);}

/* def-env764 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4247(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4247,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_3991(t3,t1,t2,C_SCHEME_FALSE);}

/* body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3991(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3991,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3997,a[2]=((C_word*)t0)[10],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4003(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4003,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=((C_word*)t0)[12],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t3,tmp=(C_word)a,a+=14,tmp);
C_u_call_with_values(4,0,t1,t4,t5);}

/* a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4015(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4015,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=t1,a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4196,a[2]=((C_word*)t0)[13],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4200,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4198 in a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4201 in k4198 in a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_eqp(*((C_word*)lf[225]+1),((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_4206(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],*((C_word*)lf[225]+1));}}

/* k4241 in k4201 in k4198 in a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4204 in k4201 in k4198 in a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4209,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(*((C_word*)lf[226]+1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_4209(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],*((C_word*)lf[226]+1));}}

/* k4232 in k4204 in k4201 in k4198 in a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4207 in k4204 in k4201 in k4198 in a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=*((C_word*)lf[317]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[340]);}}

/* k4216 in k4207 in k4204 in k4201 in k4198 in a4195 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[338]);
t3=(C_word)C_a_i_list(&a,2,lf[339],((C_word*)t0)[4]);
t4=*((C_word*)lf[317]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2]);}

/* k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t3,a[9]=t5,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
t7=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=f_1065(((C_word*)t0)[13]);
t3=f_1065(((C_word*)t0)[12]);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4038,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_fix(256));}

/* k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[41],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[11],a[3]=t1,a[4]=((C_word*)t0)[12],a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4151,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4167,a[2]=((C_word*)t0)[12],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}

/* a4182 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4187,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4185 in a4182 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)t0)[4];
f_3969(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a4166 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4167,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)t0)[2];
t4=(C_word)stub748(C_SCHEME_UNDEFINED,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_eqp(C_fix(1),t4));}}

/* a4150 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4155,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
f_4040(t3,t2);}

/* k4153 in a4150 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_i_greater_or_equalp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_subchar(((C_word*)t0)[2],t2));}}

/* k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4138,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a4137 in k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4140 in a4137 in k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=((C_word*)t0)[4];
f_3969(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a4087 in k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4088(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4088,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_block_size(((C_word*)t3)[1]);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4097(t10,t1);}

/* loop in a4087 in k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4097(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4097,NULL,2,t0,t1);}
t2=(C_word)C_write(((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]);
t3=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4113,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1090(t5);}
else{
t5=lf[4];
f_1073(t5,t1,lf[44],lf[337],((C_word*)t0)[2],(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]));}}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,((C_word*)((C_word*)t0)[4])[1]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4129,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)((C_word*)t0)[5])[1],t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}}

/* k4127 in loop in a4087 in k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)((C_word*)t0)[3])[1];
f_4097(t5,((C_word*)t0)[2]);}

/* k4111 in loop in a4087 in k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4097(t2,((C_word*)t0)[2]);}

/* k4084 in k4080 in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fetch in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4040,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4050,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4054(t6,t2);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_4054(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4054,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],C_fix(256));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[335]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[10]+1),((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
t5=lf[4];
f_1073(t5,t1,lf[44],lf[333],lf[336],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[5]));}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k4068 in loop in fetch in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1090(t2);}

/* k4071 in k4068 in loop in fetch in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_4054(t2,((C_word*)t0)[2]);}

/* k4048 in fetch in k4036 in k4023 in k4020 in k4017 in a4014 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a4008 in a4002 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4009,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* a3996 in body761 in process in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* wait in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3969(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3969,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3975,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_u_call_with_values(4,0,t1,t3,t4);}

/* a3980 in wait in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3981,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[106]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[333],lf[334],((C_word*)t0)[2],t4);}}

/* a3974 in wait in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3923(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3923r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3923r(t0,t1,t2,t3);}}

static void f_3923r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3928 in process-run in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[6])){
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[330]);}}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k3943 in k3928 in process-run in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[328]);
t3=(C_word)C_a_i_list(&a,2,lf[329],((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* process-signal in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3902(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3902r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3902r(t0,t1,t2,t3);}}

static void f_3902r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_kill(t2,t5);
t7=(C_word)C_eqp(t6,C_fix(-1));
if(C_truep(t7)){
t8=lf[4];
f_1073(t8,t1,lf[156],lf[324],lf[325],(C_word)C_a_i_list(&a,2,t2,t5));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}}

/* sleep in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3899(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3899,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub718(C_SCHEME_UNDEFINED,t2));}

/* parent-process-id in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub715(C_SCHEME_UNDEFINED));}

/* current-process-id in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub713(C_SCHEME_UNDEFINED));}

/* process-wait in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3823(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3823r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3823r(t0,t1,t2);}}

static void f_3823r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(3);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t2,C_fix(1)));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_truep(t8)?C_fix((C_word)WNOHANG):C_fix(0));
t13=(C_word)C_waitpid(t11,t12);
t14=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t15=(C_word)C_eqp(t13,C_fix(-1));
if(C_truep(t15)){
t16=lf[4];
f_1073(t16,t1,lf[156],lf[319],lf[320],(C_word)C_a_i_list(&a,1,t11));}
else{
t16=(C_truep(t14)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
C_values(5,0,t1,t13,t14,t16);}}

/* process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3659(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3659r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3659r(t0,t1,t2,t3);}}

static void f_3659r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3773,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t7=t6;
f_3778(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
t9=t5;
f_3773(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
t11=t4;
f_3661(t11,t1,t7,t9);}}}

/* def-arglist663 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3778,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3773(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist664 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3773(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3773,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_3661(t3,t1,t2,C_SCHEME_FALSE);}

/* body661 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3661(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3661,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3665,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k3663 in body661 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_3643(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3673,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3673(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do670 in k3663 in body661 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3673(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3673,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_3643(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=t5;
f_3686(t7,f_3716(t6,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_3686(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_block_size(t4);
t6=f_3643(t3,t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t13=t1;
t14=t7;
t15=t8;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* do674 in do670 in k3663 in body661 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_3716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(f_3651(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_block_size(t3);
t5=f_3651(t2,t3,t4);
t6=(C_word)C_slot(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* k3684 in do670 in k3663 in body661 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3686(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3686,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3711,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3709 in k3684 in do670 in k3663 in body661 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3687 in k3684 in do670 in k3663 in body661 in process-execute in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub642(C_SCHEME_UNDEFINED);
t5=(C_word)stub654(C_SCHEME_UNDEFINED);
t6=lf[4];
f_1073(t6,((C_word*)t0)[3],lf[156],lf[317],lf[318],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_3651(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub647(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* setarg in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_3643(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub635(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* process-fork in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3605(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3605r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3605r(t0,t1,t2);}}

static void f_3605r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub618(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
t5=lf[4];
f_1073(t5,t1,lf[156],lf[314],lf[315],C_SCHEME_END_OF_LIST);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k3625 in process-fork in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3631,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_3631 in k3625 in process-fork in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3631,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub623(C_SCHEME_UNDEFINED,t2));}

/* glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3499(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_3499r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3499r(t0,t1,t2);}}

static void f_3499r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(9);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_3505(t6,t1,t2);}

/* conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3505,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3520,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3526,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3530,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3597,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[313]);
t8=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k3595 in a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3528 in a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:lf[312]);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k3535 in k3528 in a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3539(t5,((C_word*)t0)[2],t1);}

/* loop in k3535 in k3528 in a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3539,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
t4=((C_word*)((C_word*)t0)[6])[1];
f_3505(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3556,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
t5=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k3554 in loop in k3535 in k3528 in a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3556,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3566,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)((C_word*)t0)[4])[1];
f_3539(t3,((C_word*)t0)[6],t2);}}

/* k3564 in k3554 in loop in k3535 in k3528 in a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3570,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_3539(t4,t2,t3);}

/* k3568 in k3564 in k3554 in loop in k3535 in k3528 in a3525 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3570,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a3519 in conc in glob in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3520,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3491,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub581(t3),C_fix(0));}

/* k3489 in get-host-name in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3494,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3494(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[4];
f_1073(t3,t2,lf[305],lf[304],lf[306],C_SCHEME_END_OF_LIST);}}

/* k3492 in k3489 in get-host-name in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-name in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3460(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3460,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3464,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(t2,C_fix(7));
t5=(C_word)C_eqp(lf[82],t4);
t6=(C_truep(t5)?(C_word)C_tty_portp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t3;
f_3464(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,lf[302],lf[303],t2);}}

/* k3462 in terminal-name in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub574(t4,t3),C_fix(0));}

/* terminal-port? in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3439(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3439,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k3441 in terminal-port? in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3386(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_3386r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_3386r(t0,t1,t2,t3,t4);}}

static void f_3386r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(5);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)BUFSIZ));
t7=t3;
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3393,a[2]=t1,a[3]=t6,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=(C_word)C_eqp(t7,lf[297]);
if(C_truep(t9)){
t10=t8;
f_3393(2,t10,C_fix((C_word)_IOFBF));}
else{
t10=(C_word)C_eqp(t7,lf[298]);
if(C_truep(t10)){
t11=t8;
f_3393(2,t11,C_fix((C_word)_IOLBF));}
else{
t11=(C_word)C_eqp(t7,lf[299]);
if(C_truep(t11)){
t12=t8;
f_3393(2,t12,C_fix((C_word)_IONBF));}
else{
t12=*((C_word*)lf[106]+1);
((C_proc6)(void*)(*((C_word*)t12+1)))(6,t12,t8,lf[295],lf[300],t3,t2);}}}}

/* k3391 in set-buffering-mode! in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[82],t2);
t4=(C_truep(t3)?(C_word)C_setvbuf(((C_word*)t0)[4],t1,((C_word*)t0)[3]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=*((C_word*)lf[106]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,((C_word*)t0)[2],lf[295],lf[296],((C_word*)t0)[4],t1,((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3383,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub560(C_SCHEME_UNDEFINED,t2));}

/* _exit in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3364(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2rv,(void*)f_3364r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_3364r(t0,t1,t2);}}

static void f_3364r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3368,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[293]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3366 in _exit in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[3],C_fix(0)):C_fix(0));
t4=((C_word*)t0)[2];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub554(C_SCHEME_UNDEFINED,t3));}

/* time->string in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3334(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3334,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[289]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3341,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
t6=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[289],lf[291],t2);}
else{
t6=t4;
f_3341(2,t6,C_SCHEME_UNDEFINED);}}

/* k3339 in time->string in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub543(t4,t3),C_fix(0));}

/* k3342 in k3339 in time->string in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3347,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3347(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[289],lf[290],((C_word*)t0)[2]);}}

/* k3345 in k3342 in k3339 in time->string in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->string in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3317,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3321,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub534(t5,t4),C_fix(0));}

/* k3319 in seconds->string in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3324,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_3324(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[287],lf[288],((C_word*)t0)[2]);}}

/* k3322 in k3319 in seconds->string in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* seconds->utc-time in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3306(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3306,3,t0,t1,t2);}
t3=*((C_word*)lf[285]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3300,3,t0,t1,t2);}
t3=*((C_word*)lf[285]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3294(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3294,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[275]));}

/* memory-mapped-file-pointer in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3288(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3288,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3256(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3256r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3256r(t0,t1,t2,t3);}}

static void f_3256r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_truep(t6)?(C_word)C_i_foreign_pointer_argumentp(t6):C_SCHEME_FALSE);
t8=(C_word)stub507(C_SCHEME_UNDEFINED,t7,t5);
t9=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=lf[4];
f_1073(t10,t1,lf[44],lf[280],lf[281],(C_word)C_a_i_list(&a,2,t2,t5));}}

/* map-file-to-memory in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3198(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_3198r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_3198r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void f_3198r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3202,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_3202(2,t10,t2);}
else{
t10=*((C_word*)lf[279]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k3200 in map-file-to-memory in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3202,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_3208(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[53],lf[274],lf[278],t1);}}

/* k3206 in k3200 in map-file-to-memory in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3208,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)stub482(t7,t8,t3,t4,t5,t6,((C_word*)t0)[3]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[7],a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=*((C_word*)lf[277]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t9);}

/* k3225 in k3206 in k3200 in map-file-to-memory in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=lf[4];
f_1073(t3,((C_word*)t0)[8],lf[44],lf[274],lf[276],(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[8];
f_3214(2,t3,C_SCHEME_UNDEFINED);}}

/* k3212 in k3206 in k3200 in map-file-to-memory in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[275],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3115,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3121,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3121(t5,t1,C_fix(0));}

/* loop in current-environment in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3121(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3121,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3125,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub460(t5,t4),C_fix(0));}

/* k3123 in loop in current-environment in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3133,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_3133(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k3123 in loop in current-environment in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3133,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k3157 in scan in k3123 in loop in current-environment in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3163,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
t5=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k3161 in k3157 in scan in k3123 in loop in current-environment in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3163,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3151,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t5=((C_word*)((C_word*)t0)[2])[1];
f_3121(t5,t3,t4);}

/* k3149 in k3161 in k3157 in scan in k3123 in loop in current-environment in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3151,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3108,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3106 in unsetenv in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3092,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3095 in setenv in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3101,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3099 in k3095 in setenv in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3069,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3073,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3090,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3088 in fifo? in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3071 in fifo? in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3073,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
t2=lf[4];
f_1073(t2,((C_word*)t0)[3],lf[44],lf[260],lf[261],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* create-fifo in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3032(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3032r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3032r(t0,t1,t2,t3);}}

static void f_3032r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3036,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t5=t4;
f_3036(t5,(C_word)C_slot(t3,C_fix(0)));}
else{
t5=(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t6=t4;
f_3036(t6,(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXU),t5));}}

/* k3034 in create-fifo in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_3036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3036,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3054,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3052 in k3034 in create-fifo in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3048 in k3034 in create-fifo in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[4];
f_1073(t3,((C_word*)t0)[3],lf[44],lf[258],lf[259],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_3007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3007,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(2));
t4=(C_word)C_slot(t2,C_fix(3));
t5=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_flock_lock(t6);
if(C_truep((C_word)C_fixnum_lessp(t7,C_fix(0)))){
t8=lf[4];
f_1073(t8,t1,lf[44],lf[256],lf[257],(C_word)C_a_i_list(&a,1,t2));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2985(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2985r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2985r(t0,t1,t2,t3);}}

static void f_2985r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_2875(t4,t2,t3);}

/* k2987 in file-test-lock in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
f_2937(((C_word*)t0)[3],lf[255],t1,lf[254]);}}

/* file-lock/blocking in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2970(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2970r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2970r(t0,t1,t2,t3);}}

static void f_2970r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2974,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_2875(t4,t2,t3);}

/* k2972 in file-lock/blocking in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
f_2937(((C_word*)t0)[2],lf[253],t1,lf[252]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2955(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2955r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2955r(t0,t1,t2,t3);}}

static void f_2955r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2959,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_2875(t4,t2,t3);}

/* k2957 in file-lock in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
f_2937(((C_word*)t0)[2],lf[251],t1,lf[250]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2937(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2937,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
t8=lf[4];
f_1073(t8,t1,lf[44],t4,t2,(C_word)C_a_i_list(&a,3,t5,t6,t7));}

/* setup in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2875(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2875,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(0):(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_TRUE:(C_word)C_u_i_car(t7));
t10=t9;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_i_nullp(t7);
t13=(C_truep(t12)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t7,C_fix(1)));
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2894,a[2]=t1,a[3]=t11,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t15=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t11)[1]);
if(C_truep(t15)){
t16=C_set_block_item(t11,0,C_fix(0));
t17=t14;
f_2894(t17,t16);}
else{
t16=t14;
f_2894(t16,C_SCHEME_UNDEFINED);}}

/* k2892 in setup in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2894(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2894,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[249],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2839,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2853,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2860,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t5=t4;
f_2853(2,t5,(C_word)C_ftruncate(t2,t3));}
else{
t5=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[246],lf[248],t2);}}}

/* k2862 in file-truncate in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2858 in file-truncate in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2853(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k2851 in file-truncate in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2853,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=lf[4];
f_1073(t2,((C_word*)t0)[4],lf[44],lf[246],lf[247],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2818(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2818r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2818r(t0,t1,t2,t3);}}

static void f_2818r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2822,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t5=t4;
f_2822(t5,(C_word)C_dup(t2));}
else{
t5=(C_word)C_slot(t3,C_fix(0));
t6=t4;
f_2822(t6,(C_word)C_dup2(t2,t5));}}

/* k2820 in duplicate-fileno in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2822(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2822,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2825,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=lf[4];
f_1073(t3,t2,lf[44],lf[244],lf[245],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t3=t2;
f_2825(2,t3,C_SCHEME_UNDEFINED);}}

/* k2823 in k2820 in duplicate-fileno in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2776,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(7));
t4=(C_word)C_eqp(lf[239],t3);
if(C_truep(t4)){
t5=*((C_word*)lf[240]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2812,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[243]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}}

/* k2810 in port->fileno in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
t2=lf[4];
f_1073(t2,((C_word*)t0)[3],lf[53],lf[238],lf[241],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2795,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=lf[4];
f_1073(t4,t3,lf[44],lf[238],lf[242],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=t3;
f_2795(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2793 in k2810 in port->fileno in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2765(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2765r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2765r(t0,t1,t2,t3);}}

static void f_2765r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2774,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_2702(t4,C_SCHEME_FALSE,t3);}

/* k2772 in open-output-file* in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2774,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
f_2739(((C_word*)t0)[2],lf[237],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2754(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2754r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2754r(t0,t1,t2,t3);}}

static void f_2754r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2763,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_2702(t4,C_SCHEME_TRUE,t3);}

/* k2761 in open-input-file* in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
f_2739(((C_word*)t0)[2],lf[236],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2739(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2739,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
t6=lf[4];
f_1073(t6,t1,lf[44],t2,lf[234],(C_word)C_a_i_list(&a,1,t3));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2752,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[109]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[110]+1),lf[235],lf[82]);}}

/* k2750 in check in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2702(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2702,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[228]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
t8=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[229],t5);}
else{
t8=t4;
f_2710(2,t8,lf[230]);}}
else{
t7=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[231],t5);}}
else{
t5=t4;
f_2710(2,t5,(C_truep(t2)?lf[232]:lf[233]));}}

/* k2708 in mode in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2683(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2683,4,t0,t1,t2,t3);}
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2672,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t7=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t7=t6;
f_2672(2,t7,C_SCHEME_FALSE);}}

/* k2670 in file-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2676,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_2676(2,t3,C_SCHEME_FALSE);}}

/* k2674 in k2670 in file-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2676,2,t0,t1);}
t2=(C_word)stub357(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[4];
f_1073(t3,((C_word*)t0)[4],lf[44],lf[223],lf[224],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2644(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2644,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2649,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2663 in read-symbolic-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2647 in read-symbolic-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=lf[4];
f_1073(t4,t3,lf[44],lf[220],lf[221],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=t3;
f_2652(2,t4,C_SCHEME_UNDEFINED);}}

/* k2650 in k2647 in read-symbolic-link in k2641 in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2612,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2627,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2639,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2637 in create-symbolic-link in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2625 in create-symbolic-link in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2633 in k2625 in create-symbolic-link in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2629 in k2625 in create-symbolic-link in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2631,2,t0,t1);}
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[4];
f_1073(t3,((C_word*)t0)[4],lf[44],lf[218],lf[219],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2597,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2607,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2605 in set-process-group-id! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[215],lf[216],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* process-group-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2582,3,t0,t1,t2);}
t3=(C_word)C_getpgid(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2586,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2592,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t4;
f_2586(2,t5,C_SCHEME_UNDEFINED);}}

/* k2590 in process-group-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[213],lf[214],((C_word*)t0)[2]);}

/* k2584 in process-group-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* create-session in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2571,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2577,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2571(2,t4,C_SCHEME_UNDEFINED);}}

/* k2575 in create-session in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[211],lf[212]);}

/* k2569 in create-session in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2561,3,t0,t1,t2);}
f_2528(t1,t2,C_fix((C_word)X_OK));}

/* file-write-access? in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2555(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2555,3,t0,t1,t2);}
f_2528(t1,t2,C_fix((C_word)W_OK));}

/* file-read-access? in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2549,3,t0,t1,t2);}
f_2528(t1,t2,C_fix((C_word)R_OK));}

/* check in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2528(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2528,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2543,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2547,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2545 in check in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2541 in check in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2535,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2535(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2533 in k2541 in check in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* set-group-id! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2513,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2523,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2521 in set-group-id! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[204],lf[207],((C_word*)t0)[2]);}

/* set-user-id! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2498,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2508,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2506 in set-user-id! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[204],lf[205],((C_word*)t0)[2]);}

/* current-effective-group-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub319(C_SCHEME_UNDEFINED));}

/* current-effective-user-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2492,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub317(C_SCHEME_UNDEFINED));}

/* current-group-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub315(C_SCHEME_UNDEFINED));}

/* current-user-id in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub313(C_SCHEME_UNDEFINED));}

/* change-file-owner in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2465(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2465,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2480,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2484,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2482 in change-file-owner in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2478 in change-file-owner in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[4];
f_1073(t3,((C_word*)t0)[3],lf[44],lf[198],lf[199],(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2444,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2459,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2461 in change-file-mode in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2457 in change-file-mode in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=lf[4];
f_1073(t3,((C_word*)t0)[3],lf[44],lf[196],lf[197],(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2402(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2402,4,t0,t1,t2,t3);}
t4=t2;
t5=t3;
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2398,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t7=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}
else{
t7=t6;
f_2398(2,t7,C_SCHEME_FALSE);}}

/* k2396 in initialize-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2398,2,t0,t1);}
t2=(C_word)stub291(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2410 in k2396 in initialize-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[171],lf[172],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2339(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2339,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2343,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_2273(t4);
if(C_truep(t5)){
t6=t3;
f_2343(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[168],lf[170]);}}

/* k2341 in set-groups! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2348,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2348(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do279 in k2341 in set-groups! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2348(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2348,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_set_gid(t3,t4);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t10=t1;
t11=t6;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* k2362 in do279 in k2341 in set-groups! in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[168],lf[169],((C_word*)t0)[2]);}

/* get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2280,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2334,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2280(2,t4,C_SCHEME_UNDEFINED);}}

/* k2332 in get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[164],lf[167]);}

/* k2278 in get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_2273(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_2283(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[164],lf[166]);}}

/* k2281 in k2278 in get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)stub261(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_2286(2,t4,C_SCHEME_UNDEFINED);}}

/* k2313 in k2281 in k2278 in get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[164],lf[165]);}

/* k2284 in k2281 in k2278 in get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2286,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2291(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2284 in k2281 in k2278 in get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2291,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2305,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k2303 in loop in k2284 in k2281 in k2278 in get-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_2273(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub265(C_SCHEME_UNDEFINED,t1));}

/* group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2219(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2219,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2223,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2223(t4,(C_word)C_getgrgid(t2));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k2266 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2223(t2,(C_word)C_getgrnam(t1));}

/* k2221 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2223,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2231 in k2221 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k2235 in k2231 in k2221 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2241,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2243,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2243(t6,t2,C_fix(0));}

/* rec in k2235 in k2231 in k2221 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2243(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2243,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2247,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub250(t5,t4),C_fix(0));}

/* k2245 in rec in k2235 in k2231 in k2221 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2247,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_2243(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k2255 in k2245 in rec in k2235 in k2231 in k2221 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2257,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2239 in k2235 in k2231 in k2221 in group-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(6,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2174,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_2178(t4,(C_word)C_getpwuid(t2));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2211,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k2209 in user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2178(t2,(C_word)C_getpwnam(t1));}

/* k2176 in user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_2178(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2178,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2186 in k2176 in user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2192,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k2190 in k2186 in k2176 in user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2196,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k2194 in k2190 in k2186 in k2176 in user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2200,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k2198 in k2194 in k2190 in k2186 in k2176 in user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2204,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k2202 in k2198 in k2194 in k2190 in k2186 in k2176 in user-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2204,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,7,((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2136,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2169,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2140(2,t3,C_SCHEME_UNDEFINED);}}

/* k2167 in system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[158],lf[160]);}

/* k2138 in system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k2145 in k2138 in system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2151,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k2149 in k2145 in k2138 in system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2155,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k2153 in k2149 in k2145 in k2138 in system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2159,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k2157 in k2153 in k2149 in k2145 in k2138 in system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2163,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k2161 in k2157 in k2153 in k2149 in k2145 in k2138 in system-information in k2132 in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(7,0,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-signal-mask! in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2115(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2115,3,t0,t1,t2);}
t3=(C_word)C_sigemptyset(C_fix(0));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2119,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2130,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a2129 in set-signal-mask! in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2130,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_sigaddset(t2));}

/* k2117 in set-signal-mask! in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask(C_fix(0)),C_fix(0)))){
t2=lf[4];
f_1073(t2,((C_word*)t0)[2],lf[156],lf[155],lf[157],C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2097,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2105 in ##sys#interrupt-hook in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[154]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2083 in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2087,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?t2:C_SCHEME_FALSE);
t5=(C_word)C_establish_signal_handler(t2,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* create-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2048,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
t3=lf[4];
f_1073(t3,t2,lf[44],lf[125],lf[126],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2048(2,t3,C_SCHEME_UNDEFINED);}}

/* k2046 in create-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2024(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2024r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2024r(t0,t1,t2,t3,t4);}}

static void f_2024r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[124]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2028,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2026 in with-output-to-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2028,2,t0,t1);}
t2=C_mutate((C_word*)lf[124]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2034,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2033 in k2026 in with-output-to-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2034(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2034r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2034r(t0,t1,t2);}}

static void f_2034r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2038,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2036 in a2033 in k2026 in with-output-to-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[124]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2004(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2004r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2004r(t0,t1,t2,t3,t4);}}

static void f_2004r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[122]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2008,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2006 in with-input-from-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2008,2,t0,t1);}
t2=C_mutate((C_word*)lf[122]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2014,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2013 in k2006 in with-input-from-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2014(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2014r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2014r(t0,t1,t2);}}

static void f_2014r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2018,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2016 in a2013 in k2006 in with-input-from-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[122]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1980(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1980r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1980r(t0,t1,t2,t3,t4);}}

static void f_1980r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1984,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1982 in call-with-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1989,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1995,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1994 in k1982 in call-with-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1995(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1995r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1995r(t0,t1,t2);}}

static void f_1995r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1997 in a1994 in k1982 in call-with-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1988 in k1982 in call-with-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1956r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1956r(t0,t1,t2,t3,t4);}}

static void f_1956r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1960,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1958 in call-with-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1965,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1971,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1970 in k1958 in call-with-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1971(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1971r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1971r(t0,t1,t2);}}

static void f_1971r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1975,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1973 in a1970 in k1958 in call-with-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1964 in k1958 in call-with-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1965,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1943,3,t0,t1,t2);}
t3=(C_word)close_pipe(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1947,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t5)){
t6=lf[4];
f_1073(t6,t4,lf[44],lf[116],lf[117],(C_word)C_a_i_list(&a,1,t2));}
else{
t6=t4;
f_1947(2,t6,C_SCHEME_UNDEFINED);}}

/* k1945 in close-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1910(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1910r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1910r(t0,t1,t2,t3);}}

static void f_1910r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t4=f_1844(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1921,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[105]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1928,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=(C_word)C_eqp(t4,lf[113]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1938,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
f_1856(t5,t4);}}}

/* k1936 in open-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1921(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k1926 in open-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1921(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k1919 in open-output-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1862(((C_word*)t0)[3],lf[114],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1877(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1877r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1877r(t0,t1,t2,t3);}}

static void f_1877r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(11);
t4=f_1844(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1888,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[105]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1895,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t7=(C_word)C_eqp(t4,lf[113]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
f_1856(t5,t4);}}}

/* k1903 in open-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1888(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k1893 in open-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1888(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k1886 in open-input-pipe in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1862(((C_word*)t0)[3],lf[112],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1862(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1862,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
t6=lf[4];
f_1073(t6,t1,lf[44],t2,lf[108],(C_word)C_a_i_list(&a,1,t3));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1875,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[109]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[110]+1),lf[111],lf[82]);}}

/* k1873 in check in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1856(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1856,NULL,2,t1,t2);}
t3=*((C_word*)lf[106]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[107],t2);}

/* mode in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_1844(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[105]));}

/* current-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1804(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1804r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1804r(t0,t1,t2);}}

static void f_1804r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_1808(t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_i_nullp(t4);
t6=t3;
f_1808(t6,(C_truep(t5)?(C_word)C_u_i_car(t2):C_SCHEME_TRUE));}}

/* k1806 in current-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1808,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(256));}}

/* k1815 in k1806 in current-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
t3=lf[4];
f_1073(t3,((C_word*)t0)[2],lf[44],lf[103],lf[104],C_SCHEME_END_OF_LIST);}}

/* directory? in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1784(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1784,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1788,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1802,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1800 in directory? in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[102]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1786 in directory? in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1733,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1737,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix(256));}

/* k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1740,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[100]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1738 in k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=*((C_word*)lf[100]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1741 in k1738 in k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1780 in k1741 in k1738 in k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1745 in k1741 in k1738 in k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=lf[4];
f_1073(t3,((C_word*)t0)[6],lf[44],lf[98],lf[99],(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1761,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1761(t6,((C_word*)t0)[6]);}}

/* loop in k1745 in k1741 in k1738 in k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1761(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1761,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1769 in loop in k1745 in k1741 in k1738 in k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1778,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
f_1761(t3,t2);}

/* k1776 in k1769 in loop in k1745 in k1741 in k1738 in k1735 in directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1712,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1727,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1729 in delete-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1725 in delete-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[4];
f_1073(t3,((C_word*)t0)[3],lf[44],lf[94],lf[95],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* change-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1691,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1706,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1710,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1708 in change-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1704 in change-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1706,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[4];
f_1073(t3,((C_word*)t0)[3],lf[44],lf[92],lf[93],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* create-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1670(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1670,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1685,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1689,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1687 in create-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1683 in create-directory in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1685,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=lf[4];
f_1073(t3,((C_word*)t0)[3],lf[44],lf[90],lf[91],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* set-file-position! in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1618(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1618r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1618r(t0,t1,t2,t3,t4);}}

static void f_1618r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1625,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t8=*((C_word*)lf[5]+1);
((C_proc7)(void*)(*((C_word*)t8+1)))(7,t8,t7,lf[88],lf[85],lf[89],t3,t2);}
else{
t8=t7;
f_1625(2,t8,C_SCHEME_UNDEFINED);}}

/* k1623 in set-file-position! in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1635 in k1623 in set-file-position! in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[82]);
t4=((C_word*)t0)[4];
f_1631(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1631(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
t2=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[53],lf[85],lf[87],((C_word*)t0)[5]);}}}

/* k1629 in k1623 in set-file-position! in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=lf[4];
f_1073(t2,((C_word*)t0)[4],lf[44],lf[85],lf[86],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* file-position in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1581,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1585,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1597,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1595 in file-position in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[82]);
t4=((C_word*)t0)[2];
f_1585(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1585(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
t2=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[53],lf[80],lf[83],((C_word*)t0)[3]);}}}

/* k1583 in file-position in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1588,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=lf[4];
f_1073(t3,t2,lf[44],lf[80],lf[81],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t3=t2;
f_1588(2,t3,C_SCHEME_UNDEFINED);}}

/* k1586 in k1583 in file-position in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* symbolic-link? in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1575(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1575,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_TRUE,lf[79]);}

/* k1577 in symbolic-link? in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1569(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1569,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1573,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_TRUE,lf[78]);}

/* k1571 in regular-file? in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1563,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1567,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k1565 in file-permissions in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1557,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1561,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_FALSE,lf[76]);}

/* k1559 in file-owner in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1551,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1555,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_FALSE,lf[75]);}

/* k1553 in file-change-time in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1545,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1549,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_FALSE,lf[74]);}

/* k1547 in file-access-time in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1539(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1539,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1543,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_FALSE,lf[73]);}

/* k1541 in file-modification-time in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1533,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1537,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1467(t3,t2,C_SCHEME_FALSE,lf[72]);}

/* k1535 in file-size in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1504(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1504r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1504r(t0,t1,t2,t3);}}

static void f_1504r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1515,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_1515(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_i_nullp(t6);
t8=t5;
f_1515(t8,(C_truep(t7)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k1513 in file-stat in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1467(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[71]);}

/* k1506 in file-stat in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,9,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime)));}

/* ##sys#stat in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1467(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1467,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1471,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_1471(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
t6=*((C_word*)lf[5]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[53],lf[70],t2);}}}

/* k1497 in ##sys#stat in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1490 in ##sys#stat in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1471(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k1469 in ##sys#stat in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=lf[4];
f_1073(t2,((C_word*)t0)[4],lf[44],((C_word*)t0)[3],lf[69],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1290r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1290r(t0,t1,t2,t3,t4);}}

static void f_1290r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(15);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1284(C_fix(0));
t10=f_1284(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1306(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
t14=t12;
f_1306(2,t14,f_1286(C_fix(0),t2));}
else{
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t14=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}}}

/* a1450 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1451,3,t0,t1,t2);}
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1286(C_fix(0),t2));}

/* k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1312(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
t5=t3;
f_1312(2,t5,f_1286(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[8]);}}}

/* a1430 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1431,3,t0,t1,t2);}
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1286(C_fix(1),t2));}

/* k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1315(t4,(C_word)C_C_select_t(t3,((C_word*)t0)[3]));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1315(t4,(C_word)C_C_select(t3));}}

/* k1313 in k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1315(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1315,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=lf[4];
f_1073(t2,((C_word*)t0)[5],lf[44],lf[62],lf[63],(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
t4=t3;
f_1354(t4,f_1288(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1395,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_1354(t4,C_SCHEME_FALSE);}}}}

/* a1396 in k1313 in k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1397(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1397,3,t0,t1,t2);}
t3=f_1288(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1393 in k1313 in k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1354(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1352 in k1313 in k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1354(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1354,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1358,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t3=t2;
f_1358(t3,f_1288(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1372,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[64]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_1358(t3,C_SCHEME_FALSE);}}

/* a1371 in k1352 in k1313 in k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1372,3,t0,t1,t2);}
t3=f_1288(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1368 in k1352 in k1313 in k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1358(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1356 in k1352 in k1313 in k1310 in k1304 in file-select in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1358(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_1288(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub65(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_set in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_1286(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub59(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_zero in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_1284(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub54(C_SCHEME_UNDEFINED,t1));}

/* file-mkstemp in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1255,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1257 in file-mkstemp in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1259,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1262,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k1260 in k1257 in file-mkstemp in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1265,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=lf[4];
f_1073(t4,t2,lf[44],lf[59],lf[61],(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t4=t2;
f_1265(2,t4,C_SCHEME_UNDEFINED);}}

/* k1263 in k1260 in k1257 in file-mkstemp in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1270 in k1263 in k1260 in k1257 in file-mkstemp in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1222r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1222r(t0,t1,t2,t3,t4);}}

static void f_1222r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1226,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_1226(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[53],lf[55],lf[57],t3);}}

/* k1224 in file-write in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1226,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1232,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=lf[4];
f_1073(t7,t5,lf[44],lf[55],lf[56],(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3));}
else{
t7=t5;
f_1232(2,t7,C_SCHEME_UNDEFINED);}}

/* k1230 in k1224 in file-write in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1186(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1186r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1186r(t0,t1,t2,t3,t4);}}

static void f_1186r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1190,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t6=t5;
f_1190(2,t6,(C_word)C_slot(t4,C_fix(0)));}
else{
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k1188 in file-read in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1193(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=*((C_word*)lf[5]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[53],lf[51],lf[54],t1);}}

/* k1191 in k1188 in file-read in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1196,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=lf[4];
f_1073(t5,t3,lf[44],lf[51],lf[52],(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[3]));}
else{
t5=t3;
f_1196(2,t5,C_SCHEME_UNDEFINED);}}

/* k1194 in k1191 in k1188 in file-read in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1196,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1174,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t3=lf[4];
f_1073(t3,t1,lf[44],lf[48],lf[49],(C_word)C_a_i_list(&a,1,t2));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-open in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1145r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1145r(t0,t1,t2,t3,t4);}}

static void f_1145r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1153,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}

/* k1164 in file-open in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[46]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1151 in file-open in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1156,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=lf[4];
f_1073(t5,t3,lf[44],lf[43],lf[45],(C_word)C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]));}
else{
t5=t3;
f_1156(2,t5,C_SCHEME_UNDEFINED);}}

/* k1154 in k1151 in file-open in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* yield in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1090(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1090,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1096,tmp=(C_word)a,a+=2,tmp);
C_call_cc(3,0,t1,t2);}

/* a1095 in yield in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1096(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1096,3,t0,t1,t2);}
t3=*((C_word*)lf[10]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1105,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a1104 in a1095 in yield in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1105,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* posix-error in k1061 in k1058 in k1055 in k1052 in k1049 */
static void C_fcall f_1073(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1073,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1077,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t7=*((C_word*)lf[8]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1075 in posix-error in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1084,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub9(t4,t1),C_fix(0));}

/* k1086 in k1075 in posix-error in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[6],t1);}

/* k1082 in k1075 in posix-error in k1061 in k1058 in k1055 in k1052 in k1049 */
static void f_1084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[5]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* make-nonblocking in k1061 in k1058 in k1055 in k1052 in k1049 */
static C_word C_fcall f_1065(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub3(C_SCHEME_UNDEFINED,t1));}
/* end of file */
