/* Generated from srfi-14.scm by the Chicken compiler
   2005-08-24 19:38
   Version 2, Build 105 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: srfi-14.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file srfi-14.c -explicit-use
   unit: srfi_14
*/

#include "chicken.h"


static C_TLS C_word lf[218];


C_externexport void C_srfi_14_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_631(C_word c,C_word t0,C_word t1) C_noret;
static void f_747(C_word c,C_word t0,C_word t1) C_noret;
static void f_751(C_word c,C_word t0,C_word t1) C_noret;
static void f_2638(C_word c,C_word t0,C_word t1) C_noret;
static void f_2642(C_word c,C_word t0,C_word t1) C_noret;
static void f_2646(C_word c,C_word t0,C_word t1) C_noret;
static void f_2649(C_word c,C_word t0,C_word t1) C_noret;
static void f_2652(C_word c,C_word t0,C_word t1) C_noret;
static void f_2754(C_word c,C_word t0,C_word t1) C_noret;
static void f_2655(C_word c,C_word t0,C_word t1) C_noret;
static void f_2659(C_word c,C_word t0,C_word t1) C_noret;
static void f_2750(C_word c,C_word t0,C_word t1) C_noret;
static void f_2662(C_word c,C_word t0,C_word t1) C_noret;
static void f_2667(C_word c,C_word t0,C_word t1) C_noret;
static void f_2742(C_word c,C_word t0,C_word t1) C_noret;
static void f_2746(C_word c,C_word t0,C_word t1) C_noret;
static void f_2670(C_word c,C_word t0,C_word t1) C_noret;
static void f_2674(C_word c,C_word t0,C_word t1) C_noret;
static void f_2678(C_word c,C_word t0,C_word t1) C_noret;
static void f_2682(C_word c,C_word t0,C_word t1) C_noret;
static void f_2686(C_word c,C_word t0,C_word t1) C_noret;
static void f_2689(C_word c,C_word t0,C_word t1) C_noret;
static void f_2692(C_word c,C_word t0,C_word t1) C_noret;
static void f_2696(C_word c,C_word t0,C_word t1) C_noret;
static void f_2699(C_word c,C_word t0,C_word t1) C_noret;
static void f_2702(C_word c,C_word t0,C_word t1) C_noret;
static void f_2706(C_word c,C_word t0,C_word t1) C_noret;
static void f_2738(C_word c,C_word t0,C_word t1) C_noret;
static void f_2710(C_word c,C_word t0,C_word t1) C_noret;
static void f_2714(C_word c,C_word t0,C_word t1) C_noret;
static void f_2734(C_word c,C_word t0,C_word t1) C_noret;
static void f_2718(C_word c,C_word t0,C_word t1) C_noret;
static void f_2730(C_word c,C_word t0,C_word t1) C_noret;
static void f_2722(C_word c,C_word t0,C_word t1) C_noret;
static void f_2726(C_word c,C_word t0,C_word t1) C_noret;
static void f_2609(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2609r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2634(C_word c,C_word t0,C_word t1) C_noret;
static void f_2613(C_word c,C_word t0,C_word t1) C_noret;
static void f_2616(C_word c,C_word t0,C_word t1) C_noret;
static void f_2619(C_word c,C_word t0,C_word t1) C_noret;
static void f_2626(C_word c,C_word t0,C_word t1) C_noret;
static void f_2630(C_word c,C_word t0,C_word t1) C_noret;
static void f_2558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2558r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2562(C_word c,C_word t0,C_word t1) C_noret;
static void f_2565(C_word c,C_word t0,C_word t1) C_noret;
static void f_2576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2568(C_word c,C_word t0,C_word t1) C_noret;
static void f_2571(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2505(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2556(C_word c,C_word t0,C_word t1) C_noret;
static void f_2517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2441(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2441r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2496(C_word c,C_word t0,C_word t1) C_noret;
static void f_2451(C_word c,C_word t0,C_word t1) C_noret;
static void f_2463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2480(C_word c,C_word t0,C_word t1) C_noret;
static void f_2454(C_word c,C_word t0,C_word t1) C_noret;
static void f_2400(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2400r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2408(C_word c,C_word t0,C_word t1) C_noret;
static void f_2410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2427(C_word c,C_word t0,C_word t1) C_noret;
static void f_2404(C_word c,C_word t0,C_word t1) C_noret;
static void f_2359(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2359r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2395(C_word c,C_word t0,C_word t1) C_noret;
static void f_2369(C_word c,C_word t0,C_word t1) C_noret;
static void f_2377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2372(C_word c,C_word t0,C_word t1) C_noret;
static void f_2333(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2333r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2341(C_word c,C_word t0,C_word t1) C_noret;
static void f_2343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2337(C_word c,C_word t0,C_word t1) C_noret;
static void f_2288(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2288r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2324(C_word c,C_word t0,C_word t1) C_noret;
static void f_2298(C_word c,C_word t0,C_word t1) C_noret;
static void f_2310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2301(C_word c,C_word t0,C_word t1) C_noret;
static void f_2266(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2266r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2274(C_word c,C_word t0,C_word t1) C_noret;
static void f_2276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2270(C_word c,C_word t0,C_word t1) C_noret;
static void f_2217(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2217r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2257(C_word c,C_word t0,C_word t1) C_noret;
static void f_2227(C_word c,C_word t0,C_word t1) C_noret;
static void f_2239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2230(C_word c,C_word t0,C_word t1) C_noret;
static void f_2191(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2191r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2199(C_word c,C_word t0,C_word t1) C_noret;
static void f_2201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2195(C_word c,C_word t0,C_word t1) C_noret;
static void f_2169(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2173(C_word c,C_word t0,C_word t1) C_noret;
static void f_2178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2189(C_word c,C_word t0,C_word t1) C_noret;
static void f_2176(C_word c,C_word t0,C_word t1) C_noret;
static void f_2141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2145(C_word c,C_word t0,C_word t1) C_noret;
static void f_2148(C_word c,C_word t0,C_word t1) C_noret;
static void f_2156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2167(C_word c,C_word t0,C_word t1) C_noret;
static void f_2151(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2099(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2109(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2124(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2058(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2068(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2078(C_word c,C_word t0,C_word t1) C_noret;
static void f_2028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2035(C_word c,C_word t0,C_word t1) C_noret;
static void f_2014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_2022(C_word c,C_word t0,C_word t1) C_noret;
static void f_2026(C_word c,C_word t0,C_word t1) C_noret;
static void f_2018(C_word c,C_word t0,C_word t1) C_noret;
static void f_1998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1998r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2002(C_word c,C_word t0,C_word t1) C_noret;
static void f_2012(C_word c,C_word t0,C_word t1) C_noret;
static void f_2005(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1945(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1951(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1984(C_word c,C_word t0,C_word t1) C_noret;
static void f_1971(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1961(C_word t0,C_word t1) C_noret;
static void f_1935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1943(C_word c,C_word t0,C_word t1) C_noret;
static void f_1939(C_word c,C_word t0,C_word t1) C_noret;
static void f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_1905r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_1915(C_word c,C_word t0,C_word t1) C_noret;
static void f_1918(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1848(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_1891(C_word t0,C_word t1) C_noret;
static void f_1858(C_word c,C_word t0,C_word t1) C_noret;
static void f_1888(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1867(C_word t0,C_word t1);
static void f_1792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1796(C_word c,C_word t0,C_word t1) C_noret;
static void f_1846(C_word c,C_word t0,C_word t1) C_noret;
static void f_1799(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1804(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1834(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1814(C_word t0,C_word t1) C_noret;
static void f_1782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1790(C_word c,C_word t0,C_word t1) C_noret;
static void f_1786(C_word c,C_word t0,C_word t1) C_noret;
static void f_1770(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1770r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1774(C_word c,C_word t0,C_word t1) C_noret;
static void f_1777(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1727(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1740(C_word t0,C_word t1);
static void f_1680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1684(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1689(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1717(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1707(C_word t0,C_word t1) C_noret;
static void f_1670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1678(C_word c,C_word t0,C_word t1) C_noret;
static void f_1674(C_word c,C_word t0,C_word t1) C_noret;
static void f_1658(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1658r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1662(C_word c,C_word t0,C_word t1) C_noret;
static void f_1665(C_word c,C_word t0,C_word t1) C_noret;
static void f_1646(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1646r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1650(C_word c,C_word t0,C_word t1) C_noret;
static void f_1653(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1631(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_1629(C_word c,C_word t0,C_word t1) C_noret;
static void f_1625(C_word c,C_word t0,C_word t1) C_noret;
static void f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_1609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_1613(C_word c,C_word t0,C_word t1) C_noret;
static void f_1616(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1573(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_1579(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1607(C_word c,C_word t0,C_word t1) C_noret;
static void f_1603(C_word c,C_word t0,C_word t1) C_noret;
static void f_1599(C_word c,C_word t0,C_word t1) C_noret;
static void f_1520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1524(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1529(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1559(C_word c,C_word t0,C_word t1) C_noret;
static void f_1539(C_word c,C_word t0,C_word t1) C_noret;
static void f_1471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1475(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1480(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1510(C_word c,C_word t0,C_word t1) C_noret;
static void f_1496(C_word c,C_word t0,C_word t1) C_noret;
static void f_1424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1428(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1433(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1461(C_word c,C_word t0,C_word t1) C_noret;
static void f_1451(C_word c,C_word t0,C_word t1) C_noret;
static void f_1361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1365(C_word c,C_word t0,C_word t1) C_noret;
static void f_1368(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1376(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1410(C_word c,C_word t0,C_word t1) C_noret;
static void f_1406(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1386(C_word t0,C_word t1) C_noret;
static void f_1371(C_word c,C_word t0,C_word t1) C_noret;
static void f_1311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1315(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1320(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1347(C_word c,C_word t0,C_word t1) C_noret;
static void f_1330(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1269(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1273(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1278(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1291(C_word t0,C_word t1) C_noret;
static void f_1260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1230(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1230r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1218(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1218r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1206(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1206r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1194(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1194r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1175(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1179(C_word c,C_word t0,C_word t1) C_noret;
static void f_1184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1182(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1149(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1173(C_word c,C_word t0,C_word t1) C_noret;
static void f_1153(C_word c,C_word t0,C_word t1) C_noret;
static void f_1161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1156(C_word c,C_word t0,C_word t1) C_noret;
static void f_1092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1096(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1101(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1135(C_word c,C_word t0,C_word t1) C_noret;
static void f_1122(C_word c,C_word t0,C_word t1) C_noret;
static void f_1055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1059(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1064(C_word t0,C_word t1,C_word t2);
static void f_1028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1035(C_word c,C_word t0,C_word t1) C_noret;
static void f_920(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_920r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_924(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_927(C_word t0,C_word t1) C_noret;
static void f_933(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_941(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_962(C_word t0,C_word t1) C_noret;
static C_word C_fcall f_986(C_word t0,C_word t1);
static void f_822(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_822r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_842(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_844(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_854(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_871(C_word t0,C_word t1,C_word t2) C_noret;
static void f_767(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_767r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_783(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_788(C_word t0,C_word t1,C_word t2) C_noret;
static void f_812(C_word c,C_word t0,C_word t1) C_noret;
static void f_753(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_765(C_word c,C_word t0,C_word t1) C_noret;
static void f_761(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_720(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_726(C_word t0,C_word t1,C_word t2) C_noret;
static void f_733(C_word c,C_word t0,C_word t1) C_noret;
static void f_743(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_673(C_word t0,C_word t1,C_word t2) C_noret;
static void f_718(C_word c,C_word t0,C_word t1) C_noret;
static void f_698(C_word c,C_word t0,C_word t1) C_noret;
static void f_705(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_663(C_word t0,C_word t1) C_noret;
static void f_657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_639(C_word t0);
static void f_633(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

static void C_fcall trf_2505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2505(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2505(t0,t1,t2,t3,t4);}

static void C_fcall trf_2099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2099(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2099(t0,t1,t2,t3,t4);}

static void C_fcall trf_2114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2114(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2114(t0,t1,t2);}

static void C_fcall trf_2058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2058(t0,t1,t2);}

static void C_fcall trf_2068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2068(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2068(t0,t1,t2);}

static void C_fcall trf_1945(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1945(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1945(t0,t1,t2,t3);}

static void C_fcall trf_1951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1951(t0,t1,t2);}

static void C_fcall trf_1961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1961(t0,t1);}

static void C_fcall trf_1848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1848(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1848(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1891(t0,t1);}

static void C_fcall trf_1804(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1804(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1804(t0,t1,t2,t3);}

static void C_fcall trf_1814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1814(t0,t1);}

static void C_fcall trf_1727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1727(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1727(t0,t1,t2,t3);}

static void C_fcall trf_1689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1689(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1689(t0,t1,t2,t3);}

static void C_fcall trf_1707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1707(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1707(t0,t1);}

static void C_fcall trf_1631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1631(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1631(t0,t1,t2);}

static void C_fcall trf_1573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1573(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1573(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1579(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1579(t0,t1,t2);}

static void C_fcall trf_1529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1529(t0,t1,t2);}

static void C_fcall trf_1480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1480(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1480(t0,t1,t2);}

static void C_fcall trf_1433(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1433(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1433(t0,t1,t2,t3);}

static void C_fcall trf_1376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1376(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1376(t0,t1,t2);}

static void C_fcall trf_1386(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1386(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1386(t0,t1);}

static void C_fcall trf_1320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1320(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1320(t0,t1,t2);}

static void C_fcall trf_1269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1269(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1269(t0,t1,t2,t3);}

static void C_fcall trf_1278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1278(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1278(t0,t1,t2);}

static void C_fcall trf_1291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1291(t0,t1);}

static void C_fcall trf_1175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1175(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1175(t0,t1,t2,t3,t4);}

static void C_fcall trf_1149(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1149(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1149(t0,t1,t2,t3,t4);}

static void C_fcall trf_1101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1101(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1101(t0,t1,t2,t3);}

static void C_fcall trf_927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_927(t0,t1);}

static void C_fcall trf_941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_941(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_941(t0,t1,t2,t3);}

static void C_fcall trf_962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_962(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_962(t0,t1);}

static void C_fcall trf_844(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_844(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_844(t0,t1,t2,t3);}

static void C_fcall trf_871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_871(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_871(t0,t1,t2);}

static void C_fcall trf_788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_788(t0,t1,t2);}

static void C_fcall trf_720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_720(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_720(t0,t1,t2);}

static void C_fcall trf_726(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_726(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_726(t0,t1,t2);}

static void C_fcall trf_673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_673(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_673(t0,t1,t2);}

static void C_fcall trf_663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_663(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_663(t0,t1);}

static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_14_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_srfi_14_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_14_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(786)){
C_save(t1);
C_rereclaim2(786*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,218);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_lambda_info(C_heaptop,18,"(%latin1->char n2)");
lf[5]=C_static_lambda_info(C_heaptop,15,"(%char->latin1)");
lf[6]=C_h_intern(&lf[6],13,"make-char-set");
lf[7]=C_h_intern(&lf[7],8,"char-set");
lf[8]=C_static_lambda_info(C_heaptop,18,"(make-char-set s4)");
lf[9]=C_h_intern(&lf[9],10,"char-set:s");
lf[10]=C_static_lambda_info(C_heaptop,16,"(char-set:s cs5)");
lf[11]=C_h_intern(&lf[11],9,"char-set\077");
lf[12]=C_static_lambda_info(C_heaptop,14,"(char-set\077 x6)");
lf[14]=C_h_intern(&lf[14],9,"substring");
lf[15]=C_static_lambda_info(C_heaptop,17,"(%string-copy s7)");
lf[17]=C_h_intern(&lf[17],9,"\003syserror");
lf[18]=C_static_string(C_heaptop,32,"BASE-CS parameter not a char-set");
lf[19]=C_static_string(C_heaptop,51,"Expected final base char set -- too many parameters");
lf[20]=C_h_intern(&lf[20],11,"make-string");
lf[21]=C_static_lambda_info(C_heaptop,33,"(%default-base maybe-base8 proc9)");
lf[23]=C_static_string(C_heaptop,14,"Not a char-set");
lf[24]=C_static_lambda_info(C_heaptop,9,"(lp cs15)");
lf[25]=C_static_lambda_info(C_heaptop,31,"(%char-set:s/check cs12 proc13)");
lf[28]=C_h_intern(&lf[28],13,"char-set-copy");
lf[29]=C_static_lambda_info(C_heaptop,20,"(char-set-copy cs61)");
lf[30]=C_h_intern(&lf[30],9,"char-set=");
lf[31]=C_static_lambda_info(C_heaptop,11,"(lp rest69)");
lf[32]=C_static_lambda_info(C_heaptop,20,"(char-set= . rest62)");
lf[33]=C_h_intern(&lf[33],10,"char-set<=");
lf[34]=C_static_lambda_info(C_heaptop,9,"(lp2 i86)");
lf[35]=C_static_lambda_info(C_heaptop,16,"(lp s179 rest80)");
lf[36]=C_static_lambda_info(C_heaptop,21,"(char-set<= . rest73)");
lf[37]=C_h_intern(&lf[37],13,"char-set-hash");
lf[38]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[39]=C_h_intern(&lf[39],6,"modulo");
lf[40]=C_static_lambda_info(C_heaptop,16,"(lp i105 ans106)");
lf[41]=C_static_lambda_info(C_heaptop,36,"(char-set-hash cs93 . maybe-bound94)");
lf[42]=C_h_intern(&lf[42],18,"char-set-contains\077");
lf[43]=C_static_lambda_info(C_heaptop,34,"(char-set-contains\077 cs112 char113)");
lf[44]=C_h_intern(&lf[44],13,"char-set-size");
lf[45]=C_static_lambda_info(C_heaptop,12,"(lp size123)");
lf[46]=C_static_lambda_info(C_heaptop,21,"(char-set-size cs119)");
lf[47]=C_h_intern(&lf[47],14,"char-set-count");
lf[48]=C_static_lambda_info(C_heaptop,18,"(lp i131 count132)");
lf[49]=C_static_lambda_info(C_heaptop,32,"(char-set-count pred127 cset128)");
lf[51]=C_static_lambda_info(C_heaptop,12,"(a1160 c143)");
lf[52]=C_h_intern(&lf[52],12,"\003sysfor-each");
lf[53]=C_static_lambda_info(C_heaptop,45,"(%set-char-set set138 proc139 cs140 chars141)");
lf[55]=C_static_lambda_info(C_heaptop,12,"(a1183 c150)");
lf[56]=C_static_lambda_info(C_heaptop,46,"(%set-char-set! set145 proc146 cs147 chars148)");
lf[57]=C_h_intern(&lf[57],15,"char-set-adjoin");
lf[58]=C_static_lambda_info(C_heaptop,21,"(a1199 s27154 i28155)");
lf[59]=C_static_lambda_info(C_heaptop,34,"(char-set-adjoin cs152 . chars153)");
lf[60]=C_h_intern(&lf[60],16,"char-set-adjoin!");
lf[61]=C_static_lambda_info(C_heaptop,21,"(a1211 s27158 i28159)");
lf[62]=C_static_lambda_info(C_heaptop,35,"(char-set-adjoin! cs156 . chars157)");
lf[63]=C_h_intern(&lf[63],15,"char-set-delete");
lf[64]=C_static_lambda_info(C_heaptop,21,"(a1223 s25162 i26163)");
lf[65]=C_static_lambda_info(C_heaptop,34,"(char-set-delete cs160 . chars161)");
lf[66]=C_h_intern(&lf[66],16,"char-set-delete!");
lf[67]=C_static_lambda_info(C_heaptop,21,"(a1235 s25166 i26167)");
lf[68]=C_static_lambda_info(C_heaptop,35,"(char-set-delete! cs164 . chars165)");
lf[69]=C_h_intern(&lf[69],15,"char-set-cursor");
lf[71]=C_static_lambda_info(C_heaptop,25,"(char-set-cursor cset168)");
lf[72]=C_h_intern(&lf[72],16,"end-of-char-set\077");
lf[73]=C_static_lambda_info(C_heaptop,28,"(end-of-char-set\077 cursor169)");
lf[74]=C_h_intern(&lf[74],12,"char-set-ref");
lf[75]=C_static_lambda_info(C_heaptop,32,"(char-set-ref cset170 cursor171)");
lf[76]=C_h_intern(&lf[76],20,"char-set-cursor-next");
lf[77]=C_static_lambda_info(C_heaptop,40,"(char-set-cursor-next cset172 cursor173)");
lf[78]=C_static_lambda_info(C_heaptop,11,"(lp cur180)");
lf[79]=C_static_lambda_info(C_heaptop,49,"(%char-set-cursor-next cset175 cursor176 proc177)");
lf[80]=C_h_intern(&lf[80],17,"char-set-for-each");
lf[81]=C_static_lambda_info(C_heaptop,9,"(lp i193)");
lf[82]=C_static_lambda_info(C_heaptop,33,"(char-set-for-each proc189 cs190)");
lf[83]=C_h_intern(&lf[83],12,"char-set-map");
lf[84]=C_static_lambda_info(C_heaptop,9,"(lp i205)");
lf[85]=C_static_lambda_info(C_heaptop,28,"(char-set-map proc200 cs201)");
lf[86]=C_h_intern(&lf[86],13,"char-set-fold");
lf[87]=C_static_lambda_info(C_heaptop,16,"(lp i220 ans221)");
lf[88]=C_static_lambda_info(C_heaptop,37,"(char-set-fold kons215 knil216 cs217)");
lf[89]=C_h_intern(&lf[89],14,"char-set-every");
lf[90]=C_static_lambda_info(C_heaptop,9,"(lp i229)");
lf[91]=C_static_lambda_info(C_heaptop,30,"(char-set-every pred225 cs226)");
lf[92]=C_h_intern(&lf[92],12,"char-set-any");
lf[93]=C_static_lambda_info(C_heaptop,9,"(lp i241)");
lf[94]=C_static_lambda_info(C_heaptop,28,"(char-set-any pred237 cs238)");
lf[96]=C_static_lambda_info(C_heaptop,12,"(lp seed256)");
lf[97]=C_static_lambda_info(C_heaptop,47,"(%char-set-unfold! p250 f251 g252 s253 seed254)");
lf[98]=C_h_intern(&lf[98],15,"char-set-unfold");
lf[99]=C_static_lambda_info(C_heaptop,56,"(char-set-unfold p261 f262 g263 seed264 . maybe-base265)");
lf[100]=C_h_intern(&lf[100],16,"char-set-unfold!");
lf[101]=C_static_lambda_info(C_heaptop,54,"(char-set-unfold! p268 f269 g270 seed271 base-cset272)");
lf[103]=C_static_lambda_info(C_heaptop,15,"(a1636 char276)");
lf[104]=C_static_lambda_info(C_heaptop,32,"(%list->char-set! chars274 s275)");
lf[105]=C_static_lambda_info(C_heaptop,21,"(char-set . chars279)");
lf[106]=C_h_intern(&lf[106],14,"list->char-set");
lf[107]=C_static_lambda_info(C_heaptop,41,"(list->char-set chars282 . maybe-base283)");
lf[108]=C_h_intern(&lf[108],15,"list->char-set!");
lf[109]=C_static_lambda_info(C_heaptop,37,"(list->char-set! chars286 base-cs287)");
lf[110]=C_h_intern(&lf[110],14,"char-set->list");
lf[111]=C_static_lambda_info(C_heaptop,16,"(lp i292 ans293)");
lf[112]=C_static_lambda_info(C_heaptop,22,"(char-set->list cs289)");
lf[114]=C_static_lambda_info(C_heaptop,7,"(do300)");
lf[115]=C_static_lambda_info(C_heaptop,41,"(%string->char-set! str297 bs298 proc299)");
lf[116]=C_h_intern(&lf[116],16,"string->char-set");
lf[117]=C_static_lambda_info(C_heaptop,41,"(string->char-set str308 . maybe-base309)");
lf[118]=C_h_intern(&lf[118],17,"string->char-set!");
lf[119]=C_static_lambda_info(C_heaptop,37,"(string->char-set! str312 base-cs313)");
lf[120]=C_h_intern(&lf[120],16,"char-set->string");
lf[121]=C_static_lambda_info(C_heaptop,14,"(lp i319 j320)");
lf[122]=C_static_lambda_info(C_heaptop,24,"(char-set->string cs315)");
lf[124]=C_static_lambda_info(C_heaptop,4,"(lp)");
lf[125]=C_h_intern(&lf[125],3,"min");
lf[126]=C_static_string(C_heaptop,96,"Requested UCS range contains unavailable characters -- this implementation only "
"supports Latin-1");
lf[127]=C_static_lambda_info(C_heaptop,65,"(%ucs-range->char-set! lower326 upper327 error\077328 bs329 proc330)");
lf[128]=C_h_intern(&lf[128],19,"ucs-range->char-set");
lf[129]=C_static_lambda_info(C_heaptop,49,"(ucs-range->char-set lower340 upper341 . rest342)");
lf[130]=C_h_intern(&lf[130],20,"ucs-range->char-set!");
lf[131]=C_static_lambda_info(C_heaptop,61,"(ucs-range->char-set! lower351 upper352 error\077353 base-cs354)");
lf[133]=C_static_lambda_info(C_heaptop,9,"(lp i361)");
lf[134]=C_static_lambda_info(C_heaptop,39,"(%char-set-filter! pred356 ds357 bs358)");
lf[135]=C_h_intern(&lf[135],15,"char-set-filter");
lf[136]=C_h_intern(&lf[136],16,"char-set-filter!");
lf[137]=C_static_lambda_info(C_heaptop,56,"(char-set-filter predicate370 domain371 . maybe-base372)");
lf[138]=C_static_lambda_info(C_heaptop,52,"(char-set-filter! predicate375 domain376 base-cs377)");
lf[139]=C_h_intern(&lf[139],10,"->char-set");
lf[140]=C_static_string(C_heaptop,30,"Not a charset, string or char.");
lf[141]=C_static_lambda_info(C_heaptop,17,"(->char-set x379)");
lf[143]=C_static_lambda_info(C_heaptop,9,"(lp i383)");
lf[144]=C_static_lambda_info(C_heaptop,24,"(%string-iter p380 s381)");
lf[146]=C_static_lambda_info(C_heaptop,9,"(lp i393)");
lf[147]=C_static_lambda_info(C_heaptop,15,"(a2104 cset390)");
lf[148]=C_static_lambda_info(C_heaptop,47,"(%char-set-algebra s386 csets387 op388 proc389)");
lf[149]=C_h_intern(&lf[149],19,"char-set-complement");
lf[150]=C_static_lambda_info(C_heaptop,17,"(a2155 i401 v402)");
lf[151]=C_static_lambda_info(C_heaptop,27,"(char-set-complement cs398)");
lf[152]=C_h_intern(&lf[152],20,"char-set-complement!");
lf[153]=C_static_lambda_info(C_heaptop,17,"(a2177 i412 v413)");
lf[154]=C_static_lambda_info(C_heaptop,30,"(char-set-complement! cset410)");
lf[155]=C_h_intern(&lf[155],15,"char-set-union!");
lf[156]=C_static_lambda_info(C_heaptop,28,"(a2200 s43423 i44424 v45425)");
lf[157]=C_static_lambda_info(C_heaptop,37,"(char-set-union! cset1421 . csets422)");
lf[158]=C_h_intern(&lf[158],14,"char-set-union");
lf[159]=C_static_lambda_info(C_heaptop,28,"(a2238 s43431 i44432 v45433)");
lf[160]=C_h_intern(&lf[160],14,"char-set:empty");
lf[161]=C_static_lambda_info(C_heaptop,27,"(char-set-union . csets429)");
lf[162]=C_h_intern(&lf[162],22,"char-set-intersection!");
lf[163]=C_static_lambda_info(C_heaptop,28,"(a2275 s38439 i39440 v40441)");
lf[164]=C_static_lambda_info(C_heaptop,44,"(char-set-intersection! cset1437 . csets438)");
lf[165]=C_h_intern(&lf[165],21,"char-set-intersection");
lf[166]=C_static_lambda_info(C_heaptop,28,"(a2309 s38447 i39448 v40449)");
lf[167]=C_h_intern(&lf[167],13,"char-set:full");
lf[168]=C_static_lambda_info(C_heaptop,34,"(char-set-intersection . csets445)");
lf[169]=C_h_intern(&lf[169],20,"char-set-difference!");
lf[170]=C_static_lambda_info(C_heaptop,28,"(a2342 s48455 i49456 v50457)");
lf[171]=C_static_lambda_info(C_heaptop,42,"(char-set-difference! cset1453 . csets454)");
lf[172]=C_h_intern(&lf[172],19,"char-set-difference");
lf[173]=C_static_lambda_info(C_heaptop,28,"(a2376 s48464 i49465 v50466)");
lf[174]=C_static_lambda_info(C_heaptop,39,"(char-set-difference cs1461 . csets462)");
lf[175]=C_h_intern(&lf[175],13,"char-set-xor!");
lf[176]=C_static_lambda_info(C_heaptop,28,"(a2409 s53472 i54473 v55474)");
lf[177]=C_static_lambda_info(C_heaptop,35,"(char-set-xor! cset1470 . csets471)");
lf[178]=C_h_intern(&lf[178],12,"char-set-xor");
lf[179]=C_static_lambda_info(C_heaptop,28,"(a2462 s53483 i54484 v55485)");
lf[180]=C_static_lambda_info(C_heaptop,25,"(char-set-xor . csets481)");
lf[182]=C_static_lambda_info(C_heaptop,17,"(a2516 i497 v498)");
lf[183]=C_static_lambda_info(C_heaptop,13,"(a2510 cs496)");
lf[184]=C_static_lambda_info(C_heaptop,62,"(%char-set-diff+intersection! diff492 int493 csets494 proc495)");
lf[185]=C_h_intern(&lf[185],27,"char-set-diff+intersection!");
lf[186]=C_static_lambda_info(C_heaptop,17,"(a2575 i513 v514)");
lf[187]=C_static_lambda_info(C_heaptop,54,"(char-set-diff+intersection! cs1508 cs2509 . csets510)");
lf[188]=C_h_intern(&lf[188],26,"char-set-diff+intersection");
lf[189]=C_h_intern(&lf[189],11,"string-copy");
lf[190]=C_static_lambda_info(C_heaptop,46,"(char-set-diff+intersection cs1525 . csets526)");
lf[191]=C_h_intern(&lf[191],19,"char-set:lower-case");
lf[192]=C_h_intern(&lf[192],19,"char-set:upper-case");
lf[193]=C_h_intern(&lf[193],19,"char-set:title-case");
lf[194]=C_h_intern(&lf[194],15,"char-set:letter");
lf[195]=C_h_intern(&lf[195],14,"char-set:digit");
lf[196]=C_h_intern(&lf[196],18,"char-set:hex-digit");
lf[197]=C_h_intern(&lf[197],21,"char-set:letter+digit");
lf[198]=C_h_intern(&lf[198],20,"char-set:punctuation");
lf[199]=C_h_intern(&lf[199],15,"char-set:symbol");
lf[200]=C_h_intern(&lf[200],16,"char-set:graphic");
lf[201]=C_h_intern(&lf[201],19,"char-set:whitespace");
lf[202]=C_h_intern(&lf[202],17,"char-set:printing");
lf[203]=C_h_intern(&lf[203],14,"char-set:blank");
lf[204]=C_h_intern(&lf[204],20,"char-set:iso-control");
lf[205]=C_h_intern(&lf[205],14,"char-set:ascii");
lf[206]=C_h_intern(&lf[206],7,"\003sysmap");
tmp=C_fix(9);
C_save(tmp);
tmp=C_fix(32);
C_save(tmp);
tmp=C_fix(160);
C_save(tmp);
lf[207]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_fix(9);
C_save(tmp);
tmp=C_fix(10);
C_save(tmp);
tmp=C_fix(11);
C_save(tmp);
tmp=C_fix(12);
C_save(tmp);
tmp=C_fix(13);
C_save(tmp);
tmp=C_fix(32);
C_save(tmp);
tmp=C_fix(160);
C_save(tmp);
lf[208]=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
tmp=C_fix(162);
C_save(tmp);
tmp=C_fix(163);
C_save(tmp);
tmp=C_fix(164);
C_save(tmp);
tmp=C_fix(165);
C_save(tmp);
tmp=C_fix(166);
C_save(tmp);
tmp=C_fix(167);
C_save(tmp);
tmp=C_fix(168);
C_save(tmp);
tmp=C_fix(169);
C_save(tmp);
tmp=C_fix(172);
C_save(tmp);
tmp=C_fix(174);
C_save(tmp);
tmp=C_fix(175);
C_save(tmp);
tmp=C_fix(176);
C_save(tmp);
tmp=C_fix(177);
C_save(tmp);
tmp=C_fix(180);
C_save(tmp);
tmp=C_fix(182);
C_save(tmp);
tmp=C_fix(184);
C_save(tmp);
tmp=C_fix(215);
C_save(tmp);
tmp=C_fix(247);
C_save(tmp);
lf[209]=C_h_list(18,C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(18);
lf[210]=C_static_string(C_heaptop,9,"$+<=>^`|~");
tmp=C_fix(161);
C_save(tmp);
tmp=C_fix(171);
C_save(tmp);
tmp=C_fix(173);
C_save(tmp);
tmp=C_fix(183);
C_save(tmp);
tmp=C_fix(187);
C_save(tmp);
tmp=C_fix(191);
C_save(tmp);
lf[211]=C_h_list(6,C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(6);
lf[212]=C_static_string(C_heaptop,23,"!\042#%&\047()*,-./:;\077@[\134]_{}");
lf[213]=C_static_string(C_heaptop,22,"0123456789abcdefABCDEF");
lf[214]=C_static_string(C_heaptop,10,"0123456789");
lf[215]=C_h_intern(&lf[215],17,"register-feature!");
lf[216]=C_h_intern(&lf[216],7,"srfi-14");
lf[217]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,218);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_631,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[215]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[216]);}

/* k629 */
static void f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_631,2,t0,t1);}
t2=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_633,a[2]=lf[3],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_639,a[2]=lf[5],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_645,a[2]=lf[8],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_651,a[2]=lf[10],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[11]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_657,a[2]=lf[12],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[13],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_663,a[2]=lf[15],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_673,a[2]=lf[21],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[22],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_720,a[2]=lf[25],tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=lf[2];
f_633(3,t11,t10,C_fix(0));}

/* k745 in k629 */
static void f_747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_747,2,t0,t1);}
t2=C_mutate(&lf[26],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=lf[2];
f_633(3,t4,t3,C_fix(1));}

/* k749 in k745 in k629 */
static void f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word ab[174],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_751,2,t0,t1);}
t2=C_mutate(&lf[27],t1);
t3=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_753,a[2]=lf[29],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_767,a[2]=lf[32],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[33]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_822,a[2]=lf[36],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_920,a[2]=lf[41],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=lf[43],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1055,a[2]=lf[46],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1092,a[2]=lf[49],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[50],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1149,a[2]=lf[53],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[54],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1175,a[2]=lf[56],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1194,a[2]=lf[59],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[60]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1206,a[2]=lf[62],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1218,a[2]=lf[65],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1230,a[2]=lf[68],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1242,a[2]=lf[71],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[72]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1248,a[2]=lf[73],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[74]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1254,a[2]=lf[75],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=lf[77],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate(&lf[70],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1269,a[2]=lf[79],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1311,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=lf[85],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[86]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=lf[88],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=lf[91],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1520,a[2]=lf[94],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[95],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1573,a[2]=lf[97],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1609,a[2]=lf[99],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1621,a[2]=lf[101],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate(&lf[102],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1631,a[2]=lf[104],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[7]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1658,a[2]=lf[107],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[108]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1670,a[2]=lf[109],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1680,a[2]=lf[112],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate(&lf[113],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1727,a[2]=lf[115],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[116]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1770,a[2]=lf[117],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=lf[119],tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1792,a[2]=lf[122],tmp=(C_word)a,a+=3,tmp));
t38=C_mutate(&lf[123],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1848,a[2]=lf[127],tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[128]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1905,a[2]=lf[129],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[130]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1935,a[2]=lf[131],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate(&lf[132],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=lf[134],tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1998,a[2]=lf[137],tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=lf[138],tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2028,a[2]=lf[141],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate(&lf[142],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=lf[144],tmp=(C_word)a,a+=3,tmp));
t46=C_mutate(&lf[145],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2099,a[2]=lf[148],tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=lf[151],tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2169,a[2]=lf[154],tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[155]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2191,a[2]=lf[157],tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=lf[161],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2266,a[2]=lf[164],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2288,a[2]=lf[168],tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2333,a[2]=lf[171],tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=lf[174],tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[175]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2400,a[2]=lf[177],tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2441,a[2]=lf[180],tmp=(C_word)a,a+=3,tmp));
t57=C_mutate(&lf[181],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2505,a[2]=lf[184],tmp=(C_word)a,a+=3,tmp));
t58=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2558,a[2]=lf[187],tmp=(C_word)a,a+=3,tmp));
t59=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2609,a[2]=lf[190],tmp=(C_word)a,a+=3,tmp));
t60=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t61=*((C_word*)lf[7]+1);
((C_proc2)C_retrieve_proc(t61))(2,t61,t60);}

/* k2636 in k749 in k745 in k629 */
static void f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=C_mutate((C_word*)lf[160]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[149]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[160]+1));}

/* k2640 in k2636 in k749 in k745 in k629 */
static void f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=C_mutate((C_word*)lf[167]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[128]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(97),C_fix(123));}

/* k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2649,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[130]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_fix(223),C_fix(247),C_SCHEME_TRUE,t1);}

/* k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2652,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[130]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_fix(248),C_fix(256),C_SCHEME_TRUE,t1);}

/* k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2754,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=lf[2];
f_633(3,t4,t3,C_fix(181));}

/* k2752 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[60]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=C_mutate((C_word*)lf[191]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[128]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(65),C_fix(91));}

/* k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2750,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[130]+1);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_fix(192),C_fix(215),C_SCHEME_TRUE,t1);}

/* k2748 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[130]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_fix(216),C_fix(223),C_SCHEME_TRUE,t1);}

/* k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=C_mutate((C_word*)lf[192]+1,t1);
t3=C_mutate((C_word*)lf[193]+1,*((C_word*)lf[160]+1));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2667,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,*((C_word*)lf[192]+1),*((C_word*)lf[191]+1));}

/* k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2742,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=lf[2];
f_633(3,t4,t3,C_fix(170));}

/* k2740 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2746,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=lf[2];
f_633(3,t3,t2,C_fix(186));}

/* k2744 in k2740 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[60]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=C_mutate((C_word*)lf[194]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[214]);}

/* k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2674,2,t0,t1);}
t2=C_mutate((C_word*)lf[195]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2678,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[213]);}

/* k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2678,2,t0,t1);}
t2=C_mutate((C_word*)lf[196]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2682,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[194]+1),*((C_word*)lf[195]+1));}

/* k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=C_mutate((C_word*)lf[197]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[212]);}

/* k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2689,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[2],lf[211]);}

/* k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2692,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2692,2,t0,t1);}
t2=C_mutate((C_word*)lf[198]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[210]);}

/* k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2699,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[2],lf[209]);}

/* k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2699,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[108]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2702,2,t0,t1);}
t2=C_mutate((C_word*)lf[199]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2706,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[158]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[197]+1),*((C_word*)lf[198]+1),*((C_word*)lf[199]+1));}

/* k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2706,2,t0,t1);}
t2=C_mutate((C_word*)lf[200]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2738,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[2],lf[208]);}

/* k2736 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2708 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2710,2,t0,t1);}
t2=C_mutate((C_word*)lf[201]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[158]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,*((C_word*)lf[201]+1),*((C_word*)lf[200]+1));}

/* k2712 in k2708 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
t2=C_mutate((C_word*)lf[202]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2734,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[2],lf[207]);}

/* k2732 in k2712 in k2708 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[106]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2716 in k2712 in k2708 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=C_mutate((C_word*)lf[203]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2722,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2730,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[128]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(0),C_fix(32));}

/* k2728 in k2716 in k2712 in k2708 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[130]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_fix(127),C_fix(160),C_SCHEME_TRUE,t1);}

/* k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2722,2,t0,t1);}
t2=C_mutate((C_word*)lf[204]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2726,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[128]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(0),C_fix(128));}

/* k2724 in k2720 in k2716 in k2712 in k2708 in k2704 in k2700 in k2697 in k2694 in k2690 in k2687 in k2684 in k2680 in k2676 in k2672 in k2668 in k2665 in k2660 in k2657 in k2653 in k2650 in k2647 in k2644 in k2640 in k2636 in k749 in k745 in k629 */
static void f_2726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[205]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* char-set-diff+intersection in k749 in k745 in k629 */
static void f_2609(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2609r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2609r(t0,t1,t2,t3);}}

static void f_2609r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2613,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2634,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
f_720(t5,t2,lf[188]);}

/* k2632 in char-set-diff+intersection in k749 in k745 in k629 */
static void f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[189]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2611 in char-set-diff+intersection in k749 in k745 in k629 */
static void f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(256),lf[26]);}

/* k2614 in k2611 in char-set-diff+intersection in k749 in k745 in k629 */
static void f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_2505(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[188]);}

/* k2617 in k2614 in k2611 in char-set-diff+intersection in k749 in k745 in k629 */
static void f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2624 in k2617 in k2614 in k2611 in char-set-diff+intersection in k749 in k745 in k629 */
static void f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2630,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2628 in k2624 in k2617 in k2614 in k2611 in char-set-diff+intersection in k749 in k745 in k629 */
static void f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2558r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2558r(t0,t1,t2,t3,t4);}}

static void f_2558r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2562,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
f_720(t5,t2,lf[185]);}

/* k2560 in char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2565,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
f_720(t2,((C_word*)t0)[3],lf[185]);}

/* k2563 in k2560 in char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=lf[186],tmp=(C_word)a,a+=5,tmp);
f_2058(t2,t3,((C_word*)t0)[3]);}

/* a2575 in k2563 in k2560 in char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2576,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_string_set(((C_word*)t0)[3],t5,lf[26]));}
else{
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t5);
t7=f_639(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=t2;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,(C_word)C_i_string_set(((C_word*)t0)[2],t9,lf[26]));}}}

/* k2566 in k2563 in k2560 in char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
f_2505(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[185]);}

/* k2569 in k2566 in k2563 in k2560 in char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-diff+intersection! in k749 in k745 in k629 */
static void C_fcall f_2505(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2505,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2511,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=lf[183],tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t4);}

/* a2510 in %char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2511,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[182],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2556,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_720(t4,t2,((C_word*)t0)[2]);}

/* k2554 in a2510 in %char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_2058(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2516 in a2510 in %char-set-diff+intersection! in k749 in k745 in k629 */
static void f_2517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2517,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=((C_word*)t0)[3];
t6=t2;
t7=(C_word)C_i_string_ref(t5,t6);
t8=f_639(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}
else{
t10=((C_word*)t0)[3];
t11=t2;
t12=(C_word)C_i_string_set(t10,t11,lf[26]);
t13=((C_word*)t0)[2];
t14=t2;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,(C_word)C_i_string_set(t13,t14,lf[27]));}}}

/* char-set-xor in k749 in k745 in k629 */
static void f_2441(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2441r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2441r(t0,t1,t2);}}

static void f_2441r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2451,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
f_720(t4,t5,lf[178]);}
else{
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[160]+1));}}

/* k2494 in char-set-xor in k749 in k745 in k629 */
static void f_2496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_663(((C_word*)t0)[2],t1);}

/* k2449 in char-set-xor in k749 in k745 in k629 */
static void f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2454,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=lf[179],tmp=(C_word)a,a+=3,tmp);
f_2099(t2,t1,t3,t4,lf[178]);}

/* a2462 in k2449 in char-set-xor in k749 in k745 in k629 */
static void f_2463(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2463,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_i_string_ref(t8,t9);
t11=f_639(t10);
t12=(C_word)C_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2480,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=lf[2];
f_633(3,t14,t13,t12);}}

/* k2478 in a2462 in k2449 in char-set-xor in k749 in k745 in k629 */
static void f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2452 in k2449 in char-set-xor in k749 in k745 in k629 */
static void f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-xor! in k749 in k745 in k629 */
static void f_2400(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2400r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2400r(t0,t1,t2,t3);}}

static void f_2400r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2408,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t2,lf[175]);}

/* k2406 in char-set-xor! in k749 in k745 in k629 */
static void f_2408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2410,a[2]=lf[176],tmp=(C_word)a,a+=3,tmp);
f_2099(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[175]);}

/* a2409 in k2406 in char-set-xor! in k749 in k745 in k629 */
static void f_2410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2410,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=t2;
t7=t3;
t8=t2;
t9=t3;
t10=(C_word)C_i_string_ref(t8,t9);
t11=f_639(t10);
t12=(C_word)C_fixnum_difference(C_fix(1),t11);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2427,a[2]=t7,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=lf[2];
f_633(3,t14,t13,t12);}}

/* k2425 in a2409 in k2406 in char-set-xor! in k749 in k745 in k629 */
static void f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2402 in char-set-xor! in k749 in k745 in k629 */
static void f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-difference in k749 in k745 in k629 */
static void f_2359(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2359r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2359r(t0,t1,t2,t3);}}

static void f_2359r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2369,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2395,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
f_720(t5,t2,lf[172]);}
else{
t4=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}}

/* k2393 in char-set-difference in k749 in k745 in k629 */
static void f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_663(((C_word*)t0)[2],t1);}

/* k2367 in char-set-difference in k749 in k745 in k629 */
static void f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=lf[173],tmp=(C_word)a,a+=3,tmp);
f_2099(t2,t1,((C_word*)t0)[2],t3,lf[172]);}

/* a2376 in k2367 in char-set-difference in k749 in k745 in k629 */
static void f_2377(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2377,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[26])));}

/* k2370 in k2367 in char-set-difference in k749 in k745 in k629 */
static void f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-difference! in k749 in k745 in k629 */
static void f_2333(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2333r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2333r(t0,t1,t2,t3);}}

static void f_2333r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2337,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2341,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t2,lf[169]);}

/* k2339 in char-set-difference! in k749 in k745 in k629 */
static void f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2343,a[2]=lf[170],tmp=(C_word)a,a+=3,tmp);
f_2099(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[169]);}

/* a2342 in k2339 in char-set-difference! in k749 in k745 in k629 */
static void f_2343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2343,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[26])));}

/* k2335 in char-set-difference! in k749 in k745 in k629 */
static void f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-intersection in k749 in k745 in k629 */
static void f_2288(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2288r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2288r(t0,t1,t2);}}

static void f_2288r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2324,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
f_720(t4,t5,lf[165]);}
else{
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[167]+1));}}

/* k2322 in char-set-intersection in k749 in k745 in k629 */
static void f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_663(((C_word*)t0)[2],t1);}

/* k2296 in char-set-intersection in k749 in k745 in k629 */
static void f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2310,a[2]=lf[166],tmp=(C_word)a,a+=3,tmp);
f_2099(t2,t1,t3,t4,lf[165]);}

/* a2309 in k2296 in char-set-intersection in k749 in k745 in k629 */
static void f_2310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2310,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_i_string_set(t2,t3,lf[26]):C_SCHEME_UNDEFINED));}

/* k2299 in k2296 in char-set-intersection in k749 in k745 in k629 */
static void f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-intersection! in k749 in k745 in k629 */
static void f_2266(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2266r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2266r(t0,t1,t2,t3);}}

static void f_2266r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2270,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2274,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t2,lf[162]);}

/* k2272 in char-set-intersection! in k749 in k745 in k629 */
static void f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2276,a[2]=lf[163],tmp=(C_word)a,a+=3,tmp);
f_2099(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[162]);}

/* a2275 in k2272 in char-set-intersection! in k749 in k745 in k629 */
static void f_2276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2276,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(C_word)C_i_string_set(t2,t3,lf[26]):C_SCHEME_UNDEFINED));}

/* k2268 in char-set-intersection! in k749 in k745 in k629 */
static void f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-union in k749 in k745 in k629 */
static void f_2217(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2217r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2217r(t0,t1,t2);}}

static void f_2217r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2227,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2257,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_car(t2);
f_720(t4,t5,lf[158]);}
else{
t3=*((C_word*)lf[28]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,*((C_word*)lf[160]+1));}}

/* k2255 in char-set-union in k749 in k745 in k629 */
static void f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_663(((C_word*)t0)[2],t1);}

/* k2225 in char-set-union in k749 in k745 in k629 */
static void f_2227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2230,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2239,a[2]=lf[159],tmp=(C_word)a,a+=3,tmp);
f_2099(t2,t1,t3,t4,lf[158]);}

/* a2238 in k2225 in char-set-union in k749 in k745 in k629 */
static void f_2239(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2239,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[27])));}

/* k2228 in k2225 in char-set-union in k749 in k745 in k629 */
static void f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-union! in k749 in k745 in k629 */
static void f_2191(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2191r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2191r(t0,t1,t2,t3);}}

static void f_2191r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2195,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2199,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t2,lf[155]);}

/* k2197 in char-set-union! in k749 in k745 in k629 */
static void f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=lf[156],tmp=(C_word)a,a+=3,tmp);
f_2099(((C_word*)t0)[3],t1,((C_word*)t0)[2],t2,lf[155]);}

/* a2200 in k2197 in char-set-union! in k749 in k745 in k629 */
static void f_2201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2201,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t4,C_fix(0));
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?C_SCHEME_UNDEFINED:(C_word)C_i_string_set(t2,t3,lf[27])));}

/* k2193 in char-set-union! in k749 in k745 in k629 */
static void f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement! in k749 in k745 in k629 */
static void f_2169(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2169,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2173,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_720(t3,t2,lf[152]);}

/* k2171 in char-set-complement! in k749 in k745 in k629 */
static void f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2178,a[2]=t1,a[3]=lf[153],tmp=(C_word)a,a+=4,tmp);
f_2058(t2,t3,t1);}

/* a2177 in k2171 in char-set-complement! in k749 in k745 in k629 */
static void f_2178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2178,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2189,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=lf[2];
f_633(3,t6,t5,t4);}

/* k2187 in a2177 in k2171 in char-set-complement! in k749 in k745 in k629 */
static void f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2174 in k2171 in char-set-complement! in k749 in k745 in k629 */
static void f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-complement in k749 in k745 in k629 */
static void f_2141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2141,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2145,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_720(t3,t2,lf[149]);}

/* k2143 in char-set-complement in k749 in k745 in k629 */
static void f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2148,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(256));}

/* k2146 in k2143 in char-set-complement in k749 in k745 in k629 */
static void f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2151,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2156,a[2]=t1,a[3]=lf[150],tmp=(C_word)a,a+=4,tmp);
f_2058(t2,t3,((C_word*)t0)[2]);}

/* a2155 in k2146 in k2143 in char-set-complement in k749 in k745 in k629 */
static void f_2156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2156,4,t0,t1,t2,t3);}
t4=(C_word)C_fixnum_difference(C_fix(1),t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2167,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=lf[2];
f_633(3,t6,t5,t4);}

/* k2165 in a2155 in k2146 in k2143 in char-set-complement in k749 in k745 in k629 */
static void f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_string_set(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2149 in k2146 in k2143 in char-set-complement in k749 in k745 in k629 */
static void f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-algebra in k749 in k745 in k629 */
static void C_fcall f_2099(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2099,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2105,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=lf[147],tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,t6,t3);}

/* a2104 in %char-set-algebra in k749 in k745 in k629 */
static void f_2105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2105,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2109,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_720(t3,t2,((C_word*)t0)[2]);}

/* k2107 in a2104 in %char-set-algebra in k749 in k745 in k629 */
static void f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=lf[146],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2114(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k2107 in a2104 in %char-set-algebra in k749 in k745 in k629 */
static void C_fcall f_2114(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2114,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2124,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t5);
t7=f_639(t6);
t8=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t8))(5,t8,t4,((C_word*)t0)[2],t2,t7);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2122 in lp in k2107 in a2104 in %char-set-algebra in k749 in k745 in k629 */
static void f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2114(t3,((C_word*)t0)[2],t2);}

/* %string-iter in k749 in k745 in k629 */
static void C_fcall f_2058(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2058,NULL,3,t1,t2,t3);}
t4=(C_word)C_i_string_length(t3);
t5=(C_word)C_fixnum_difference(t4,C_fix(1));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2068,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=lf[143],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_2068(t9,t1,t5);}

/* lp in %string-iter in k749 in k745 in k629 */
static void C_fcall f_2068(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2068,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2078,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t6=f_639(t5);
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t2,t6);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k2076 in lp in %string-iter in k749 in k745 in k629 */
static void f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2068(t3,((C_word*)t0)[2],t2);}

/* ->char-set in k749 in k745 in k629 */
static void f_2028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2028,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2035,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2033 in ->char-set in k749 in k745 in k629 */
static void f_2035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[2]))){
t2=*((C_word*)lf[116]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[2]))){
t2=*((C_word*)lf[7]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[139],lf[140],((C_word*)t0)[2]);}}}}

/* char-set-filter! in k749 in k745 in k629 */
static void f_2014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2014,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2022,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
f_720(t6,t3,lf[136]);}

/* k2020 in char-set-filter! in k749 in k745 in k629 */
static void f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2026,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
f_720(t2,((C_word*)t0)[2],lf[136]);}

/* k2024 in k2020 in char-set-filter! in k749 in k745 in k629 */
static void f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1945(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2016 in char-set-filter! in k749 in k745 in k629 */
static void f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-filter in k749 in k745 in k629 */
static void f_1998(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1998r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1998r(t0,t1,t2,t3,t4);}}

static void f_1998r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2002,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
f_673(t5,t4,*((C_word*)lf[135]+1));}

/* k2000 in char-set-filter in k749 in k745 in k629 */
static void f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2002,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2012,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_720(t3,((C_word*)t0)[2],lf[136]);}

/* k2010 in k2000 in char-set-filter in k749 in k745 in k629 */
static void f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1945(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2003 in k2000 in char-set-filter in k749 in k745 in k629 */
static void f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-filter! in k749 in k745 in k629 */
static void C_fcall f_1945(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1945,NULL,4,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1951,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=lf[133],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1951(t8,t1,C_fix(255));}

/* lp in %char-set-filter! in k749 in k745 in k629 */
static void C_fcall f_1951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1951,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1961,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1971,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[3];
t7=t2;
t8=(C_word)C_i_string_ref(t6,t7);
t9=f_639(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t5;
f_1971(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1984,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t12=lf[2];
f_633(3,t12,t11,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1982 in lp in %char-set-filter! in k749 in k745 in k629 */
static void f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1969 in lp in %char-set-filter! in k749 in k745 in k629 */
static void f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_1961(t4,(C_word)C_i_string_set(t2,t3,lf[27]));}
else{
t2=((C_word*)t0)[2];
f_1961(t2,C_SCHEME_UNDEFINED);}}

/* k1959 in lp in %char-set-filter! in k749 in k745 in k629 */
static void C_fcall f_1961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1951(t3,((C_word*)t0)[2],t2);}

/* ucs-range->char-set! in k749 in k745 in k629 */
static void f_1935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=6) C_bad_argc(c,6);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1935,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1939,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1943,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
f_720(t7,t5,lf[130]);}

/* k1941 in ucs-range->char-set! in k749 in k745 in k629 */
static void f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1848(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[128]);}

/* k1937 in ucs-range->char-set! in k749 in k745 in k629 */
static void f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ucs-range->char-set in k749 in k745 in k629 */
static void f_1905(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1905r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1905r(t0,t1,t2,t3,t4);}}

static void f_1905r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_car(t4));
t7=(C_word)C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_i_cdr(t4));
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1915,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
f_673(t9,t8,*((C_word*)lf[128]+1));}

/* k1913 in ucs-range->char-set in k749 in k745 in k629 */
static void f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1918,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
f_1848(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[128]);}

/* k1916 in k1913 in ucs-range->char-set in k749 in k745 in k629 */
static void f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %ucs-range->char-set! in k749 in k745 in k629 */
static void C_fcall f_1848(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1848,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_exact_2(t2,t6);
t8=(C_word)C_i_check_exact_2(t3,t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1858,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1891,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=t2;
t12=t3;
if(C_truep((C_word)C_fixnum_lessp(t11,t12))){
t13=t3;
t14=(C_word)C_fixnum_lessp(C_fix(256),t13);
t15=t10;
f_1891(t15,(C_truep(t14)?t4:C_SCHEME_FALSE));}
else{
t13=t10;
f_1891(t13,C_SCHEME_FALSE);}}

/* k1889 in %ucs-range->char-set! in k749 in k745 in k629 */
static void C_fcall f_1891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=*((C_word*)lf[17]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[126],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1858(2,t2,C_SCHEME_UNDEFINED);}}

/* k1856 in %ucs-range->char-set! in k749 in k745 in k629 */
static void f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[125]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_fix(256));}

/* k1886 in k1856 in %ucs-range->char-set! in k749 in k745 in k629 */
static void f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1888,2,t0,t1);}
t2=(C_word)C_fixnum_difference(t1,C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[124],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_1867(t3,t2));}

/* lp in k1886 in k1856 in %ucs-range->char-set! in k749 in k745 in k629 */
static C_word C_fcall f_1867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
t2=((C_word*)t0)[3];
t3=t1;
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=((C_word*)t0)[2];
t5=t1;
t6=(C_word)C_i_string_set(t4,t5,lf[27]);
t7=(C_word)C_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}
else{
return(C_SCHEME_UNDEFINED);}}

/* char-set->string in k749 in k745 in k629 */
static void f_1792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1792,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1796,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_720(t3,t2,lf[120]);}

/* k1794 in char-set->string in k749 in k745 in k629 */
static void f_1796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[44]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k1844 in k1794 in char-set->string in k749 in k745 in k629 */
static void f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[20]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1797 in k1794 in char-set->string in k749 in k745 in k629 */
static void f_1799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1799,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=lf[121],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1804(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1797 in k1794 in char-set->string in k749 in k745 in k629 */
static void C_fcall f_1804(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1804,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1814,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=t2;
t7=(C_word)C_i_string_ref(((C_word*)t0)[2],t6);
t8=f_639(t7);
t9=(C_word)C_eqp(t8,C_fix(0));
if(C_truep(t9)){
t10=t5;
f_1814(t10,t3);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1834,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t11=lf[2];
f_633(3,t11,t10,t2);}}}

/* k1832 in lp in k1797 in k1794 in char-set->string in k749 in k745 in k629 */
static void f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_set(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_1814(t3,(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1)));}

/* k1812 in lp in k1797 in k1794 in char-set->string in k749 in k745 in k629 */
static void C_fcall f_1814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1804(t3,((C_word*)t0)[2],t2,t1);}

/* string->char-set! in k749 in k745 in k629 */
static void f_1782(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1782,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1786,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1790,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t3,lf[118]);}

/* k1788 in string->char-set! in k749 in k745 in k629 */
static void f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1727(((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[118]);}

/* k1784 in string->char-set! in k749 in k745 in k629 */
static void f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string->char-set in k749 in k745 in k629 */
static void f_1770(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1770r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1770r(t0,t1,t2,t3);}}

static void f_1770r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1774,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_673(t4,t3,*((C_word*)lf[116]+1));}

/* k1772 in string->char-set in k749 in k745 in k629 */
static void f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1777,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1727(t2,((C_word*)t0)[2],t1,lf[116]);}

/* k1775 in k1772 in string->char-set in k749 in k745 in k629 */
static void f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %string->char-set! in k749 in k745 in k629 */
static void C_fcall f_1727(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1727,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(C_word)C_i_string_length(t2);
t7=(C_word)C_fixnum_difference(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1740,a[2]=t2,a[3]=t3,a[4]=lf[114],tmp=(C_word)a,a+=5,tmp);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,f_1740(t8,t7));}

/* do300 in %string->char-set! in k749 in k745 in k629 */
static C_word C_fcall f_1740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
t2=t1;
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
return(C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[3];
t4=(C_word)C_i_string_ref(((C_word*)t0)[2],t1);
t5=f_639(t4);
t6=(C_word)C_i_string_set(t3,t5,lf[27]);
t7=(C_word)C_fixnum_difference(t1,C_fix(1));
t9=t7;
t1=t9;
goto loop;}}

/* char-set->list in k749 in k745 in k629 */
static void f_1680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1680,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1684,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_720(t3,t2,lf[110]);}

/* k1682 in char-set->list in k749 in k745 in k629 */
static void f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1689,a[2]=t1,a[3]=t3,a[4]=lf[111],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1689(t5,((C_word*)t0)[2],C_fix(255),C_SCHEME_END_OF_LIST);}

/* lp in k1682 in char-set->list in k749 in k745 in k629 */
static void C_fcall f_1689(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1689,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1707,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[2],t7);
t9=f_639(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1707(t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1717,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t12=lf[2];
f_633(3,t12,t11,t2);}}}

/* k1715 in lp in k1682 in char-set->list in k749 in k745 in k629 */
static void f_1717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1717,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1707(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k1705 in lp in k1682 in char-set->list in k749 in k745 in k629 */
static void C_fcall f_1707(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1689(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* list->char-set! in k749 in k745 in k629 */
static void f_1670(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1670,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1674,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1678,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t3,lf[108]);}

/* k1676 in list->char-set! in k749 in k745 in k629 */
static void f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1631(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1672 in list->char-set! in k749 in k745 in k629 */
static void f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* list->char-set in k749 in k745 in k629 */
static void f_1658(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1658r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1658r(t0,t1,t2,t3);}}

static void f_1658r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1662,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_673(t4,t3,*((C_word*)lf[106]+1));}

/* k1660 in list->char-set in k749 in k745 in k629 */
static void f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1631(t2,((C_word*)t0)[2],t1);}

/* k1663 in k1660 in list->char-set in k749 in k745 in k629 */
static void f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set in k749 in k745 in k629 */
static void f_1646(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1646r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1646r(t0,t1,t2);}}

static void f_1646r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1650,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(256),lf[26]);}

/* k1648 in char-set in k749 in k745 in k629 */
static void f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1653,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_1631(t2,((C_word*)t0)[2],t1);}

/* k1651 in k1648 in char-set in k749 in k745 in k629 */
static void f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %list->char-set! in k749 in k745 in k629 */
static void C_fcall f_1631(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1631,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1637,a[2]=t3,a[3]=lf[103],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1636 in %list->char-set! in k749 in k745 in k629 */
static void f_1637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1637,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
t4=f_639(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_string_set(t3,t4,lf[27]));}

/* char-set-unfold! in k749 in k745 in k629 */
static void f_1621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=7) C_bad_argc(c,7);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1621,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1625,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1629,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
f_720(t8,t6,lf[100]);}

/* k1627 in char-set-unfold! in k749 in k745 in k629 */
static void f_1629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_1573(((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1623 in char-set-unfold! in k749 in k745 in k629 */
static void f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* char-set-unfold in k749 in k745 in k629 */
static void f_1609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr6r,(void*)f_1609r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_1609r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_1609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1613,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
f_673(t7,t6,*((C_word*)lf[98]+1));}

/* k1611 in char-set-unfold in k749 in k745 in k629 */
static void f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1616,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
f_1573(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1614 in k1611 in char-set-unfold in k749 in k745 in k629 */
static void f_1616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* %char-set-unfold! in k749 in k745 in k629 */
static void C_fcall f_1573(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1573,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1579,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t8,a[6]=t5,a[7]=lf[96],tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_1579(t10,t1,t6);}

/* lp in %char-set-unfold! in k749 in k745 in k629 */
static void C_fcall f_1579(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1579,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1607,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1605 in lp in %char-set-unfold! in k749 in k745 in k629 */
static void f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=((C_word*)t0)[6];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}

/* k1601 in k1605 in lp in %char-set-unfold! in k749 in k745 in k629 */
static void f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=f_639(t1);
t3=(C_word)C_i_string_set(((C_word*)t0)[6],t2,lf[27]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1597 in k1601 in k1605 in lp in %char-set-unfold! in k749 in k745 in k629 */
static void f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1579(t2,((C_word*)t0)[2],t1);}

/* char-set-any in k749 in k745 in k629 */
static void f_1520(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1520,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1524,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_720(t4,t3,lf[92]);}

/* k1522 in char-set-any in k749 in k745 in k629 */
static void f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1524,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=lf[93],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1529(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1522 in char-set-any in k749 in k745 in k629 */
static void C_fcall f_1529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1529,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1539,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t5);
t7=f_639(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1539(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1559,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=lf[2];
f_633(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1557 in lp in k1522 in char-set-any in k749 in k745 in k629 */
static void f_1559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1537 in lp in k1522 in char-set-any in k749 in k745 in k629 */
static void f_1539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)((C_word*)t0)[2])[1];
f_1529(t3,((C_word*)t0)[4],t2);}}

/* char-set-every in k749 in k745 in k629 */
static void f_1471(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1471,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1475,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_720(t4,t3,lf[89]);}

/* k1473 in char-set-every in k749 in k745 in k629 */
static void f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1480,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=lf[90],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1480(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1473 in char-set-every in k749 in k745 in k629 */
static void C_fcall f_1480(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1480,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t5);
t7=f_639(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1496,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t8)){
t10=t9;
f_1496(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=lf[2];
f_633(3,t11,t10,t2);}}}

/* k1508 in lp in k1473 in char-set-every in k749 in k745 in k629 */
static void f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1494 in lp in k1473 in char-set-every in k749 in k745 in k629 */
static void f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1480(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-fold in k749 in k745 in k629 */
static void f_1424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1424,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1428,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_720(t5,t4,lf[86]);}

/* k1426 in char-set-fold in k749 in k745 in k629 */
static void f_1428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1428,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=lf[87],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1433(t5,((C_word*)t0)[3],C_fix(255),((C_word*)t0)[2]);}

/* lp in k1426 in char-set-fold in k749 in k745 in k629 */
static void C_fcall f_1433(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1433,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1451,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t7);
t9=f_639(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1451(2,t11,t3);}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1461,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t12=lf[2];
f_633(3,t12,t11,t2);}}}

/* k1459 in lp in k1426 in char-set-fold in k749 in k745 in k629 */
static void f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1449 in lp in k1426 in char-set-fold in k749 in k745 in k629 */
static void f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1433(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* char-set-map in k749 in k745 in k629 */
static void f_1361(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1361,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1365,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_720(t4,t3,lf[83]);}

/* k1363 in char-set-map in k749 in k745 in k629 */
static void f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1368,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(256),lf[26]);}

/* k1366 in k1363 in char-set-map in k749 in k745 in k629 */
static void f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1371,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1376,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=lf[84],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1376(t6,t2,C_fix(255));}

/* lp in k1366 in k1363 in char-set-map in k749 in k745 in k629 */
static void C_fcall f_1376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1376,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1386,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[4],t5);
t7=f_639(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1386(t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1406,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1410,a[2]=t9,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=lf[2];
f_633(3,t11,t10,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1408 in lp in k1366 in k1363 in char-set-map in k749 in k745 in k629 */
static void f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1404 in lp in k1366 in k1363 in char-set-map in k749 in k745 in k629 */
static void f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_639(t1);
t3=((C_word*)t0)[3];
f_1386(t3,(C_word)C_i_string_set(((C_word*)t0)[2],t2,lf[27]));}

/* k1384 in lp in k1366 in k1363 in char-set-map in k749 in k745 in k629 */
static void C_fcall f_1386(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1376(t3,((C_word*)t0)[2],t2);}

/* k1369 in k1366 in k1363 in char-set-map in k749 in k745 in k629 */
static void f_1371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-for-each in k749 in k745 in k629 */
static void f_1311(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1311,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1315,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_720(t4,t3,lf[80]);}

/* k1313 in char-set-for-each in k749 in k745 in k629 */
static void f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=lf[81],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1320(t5,((C_word*)t0)[2],C_fix(255));}

/* lp in k1313 in char-set-for-each in k749 in k745 in k629 */
static void C_fcall f_1320(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1320,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1330,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=(C_word)C_i_string_ref(((C_word*)t0)[3],t5);
t7=f_639(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
if(C_truep(t8)){
t9=t4;
f_1330(2,t9,C_SCHEME_UNDEFINED);}
else{
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1347,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=lf[2];
f_633(3,t10,t9,t2);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1345 in lp in k1313 in char-set-for-each in k749 in k745 in k629 */
static void f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1328 in lp in k1313 in char-set-for-each in k749 in k745 in k629 */
static void f_1330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1320(t3,((C_word*)t0)[2],t2);}

/* %char-set-cursor-next in k749 in k745 in k629 */
static void C_fcall f_1269(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1269,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1273,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t2,t4);}

/* k1271 in %char-set-cursor-next in k749 in k745 in k629 */
static void f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1273,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1278,a[2]=t1,a[3]=t3,a[4]=lf[78],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1278(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k1271 in %char-set-cursor-next in k749 in k745 in k629 */
static void C_fcall f_1278(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1278,NULL,3,t0,t1,t2);}
t3=(C_word)C_fixnum_difference(t2,C_fix(1));
t4=(C_word)C_fixnum_lessp(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_1291(t6,t4);}
else{
t6=(C_word)C_i_string_ref(((C_word*)t0)[2],t3);
t7=f_639(t6);
t8=(C_word)C_eqp(t7,C_fix(0));
t9=t5;
f_1291(t9,(C_word)C_i_not(t8));}}

/* k1289 in lp in k1271 in %char-set-cursor-next in k749 in k745 in k629 */
static void C_fcall f_1291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
f_1278(t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* char-set-cursor-next in k749 in k745 in k629 */
static void f_1260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1260,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t3,lf[76]);
f_1269(t1,t2,t3,lf[76]);}

/* char-set-ref in k749 in k745 in k629 */
static void f_1254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1254,4,t0,t1,t2,t3);}
t4=lf[2];
f_633(3,t4,t1,t3);}

/* end-of-char-set? in k749 in k745 in k629 */
static void f_1248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1248,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_fixnum_lessp(t2,C_fix(0)));}

/* char-set-cursor in k749 in k745 in k629 */
static void f_1242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1242,3,t0,t1,t2);}
f_1269(t1,t2,C_fix(256),lf[69]);}

/* char-set-delete! in k749 in k745 in k629 */
static void f_1230(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1230r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1230r(t0,t1,t2,t3);}}

static void f_1230r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=lf[67],tmp=(C_word)a,a+=3,tmp);
f_1175(t1,t4,lf[66],t2,t3);}

/* a1235 in char-set-delete! in k749 in k745 in k629 */
static void f_1236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1236,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[26]));}

/* char-set-delete in k749 in k745 in k629 */
static void f_1218(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1218r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1218r(t0,t1,t2,t3);}}

static void f_1218r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1224,a[2]=lf[64],tmp=(C_word)a,a+=3,tmp);
f_1149(t1,t4,lf[63],t2,t3);}

/* a1223 in char-set-delete in k749 in k745 in k629 */
static void f_1224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1224,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[26]));}

/* char-set-adjoin! in k749 in k745 in k629 */
static void f_1206(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1206r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1206r(t0,t1,t2,t3);}}

static void f_1206r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1212,a[2]=lf[61],tmp=(C_word)a,a+=3,tmp);
f_1175(t1,t4,lf[60],t2,t3);}

/* a1211 in char-set-adjoin! in k749 in k745 in k629 */
static void f_1212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1212,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[27]));}

/* char-set-adjoin in k749 in k745 in k629 */
static void f_1194(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_1194r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1194r(t0,t1,t2,t3);}}

static void f_1194r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=lf[58],tmp=(C_word)a,a+=3,tmp);
f_1149(t1,t4,lf[57],t2,t3);}

/* a1199 in char-set-adjoin in k749 in k745 in k629 */
static void f_1200(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1200,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_string_set(t2,t3,lf[27]));}

/* %set-char-set! in k749 in k745 in k629 */
static void C_fcall f_1175(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1175,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1179,a[2]=t5,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
f_720(t6,t4,t3);}

/* k1177 in %set-char-set! in k749 in k745 in k629 */
static void f_1179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1182,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1184,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[55],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1183 in k1177 in %set-char-set! in k749 in k745 in k629 */
static void f_1184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1184,3,t0,t1,t2);}
t3=f_639(t2);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1180 in k1177 in %set-char-set! in k749 in k745 in k629 */
static void f_1182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* %set-char-set in k749 in k745 in k629 */
static void C_fcall f_1149(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1149,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1153,a[2]=t5,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1173,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
f_720(t7,t4,t3);}

/* k1171 in %set-char-set in k749 in k745 in k629 */
static void f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_663(((C_word*)t0)[2],t1);}

/* k1151 in %set-char-set in k749 in k745 in k629 */
static void f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1156,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1161,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[51],tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[52]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a1160 in k1151 in %set-char-set in k749 in k745 in k629 */
static void f_1161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1161,3,t0,t1,t2);}
t3=f_639(t2);
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,((C_word*)t0)[2],t3);}

/* k1154 in k1151 in %set-char-set in k749 in k745 in k629 */
static void f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* char-set-count in k749 in k745 in k629 */
static void f_1092(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1092,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1096,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_720(t4,t3,lf[47]);}

/* k1094 in char-set-count in k749 in k745 in k629 */
static void f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1096,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1101,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=lf[48],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1101(t5,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k1094 in char-set-count in k749 in k745 in k629 */
static void C_fcall f_1101(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1101,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1122,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t7);
t9=f_639(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_1122(2,t11,C_SCHEME_FALSE);}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1135,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t12=lf[2];
f_633(3,t12,t11,t2);}}}

/* k1133 in lp in k1094 in char-set-count in k749 in k745 in k629 */
static void f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1120 in lp in k1094 in char-set-count in k749 in k745 in k629 */
static void f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1)):((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_1101(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* char-set-size in k749 in k745 in k629 */
static void f_1055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1055,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1059,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_720(t3,t2,lf[44]);}

/* k1057 in char-set-size in k749 in k745 in k629 */
static void f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1064,a[2]=t1,a[3]=lf[45],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1064(t2,C_fix(255),C_fix(0)));}

/* lp in k1057 in char-set-size in k749 in k745 in k629 */
static C_word C_fcall f_1064(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
t3=t1;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
return(t2);}
else{
t4=(C_word)C_fixnum_difference(t1,C_fix(1));
t5=t1;
t6=(C_word)C_i_string_ref(((C_word*)t0)[2],t5);
t7=f_639(t6);
t8=(C_word)C_fixnum_plus(t2,t7);
t10=t4;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* char-set-contains? in k749 in k745 in k629 */
static void f_1028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1028,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_char_2(t3,lf[42]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1035,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
f_720(t5,t2,lf[42]);}

/* k1033 in char-set-contains? in k749 in k745 in k629 */
static void f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=f_639(((C_word*)t0)[3]);
t3=(C_word)C_i_string_ref(t1,t2);
t4=f_639(t3);
t5=(C_word)C_eqp(t4,C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_not(t5));}

/* char-set-hash in k749 in k745 in k629 */
static void f_920(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_920r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_920r(t0,t1,t2,t3);}}

static void f_920r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_924,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_924(2,t5,C_fix(4194304));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_924(2,t6,(C_word)C_i_car(t3));}
else{
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[1],t3);}}}

/* k922 in char-set-hash in k749 in k745 in k629 */
static void f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_924,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(0));
if(C_truep(t5)){
t6=C_set_block_item(t3,0,C_fix(4194304));
t7=t4;
f_927(t7,t6);}
else{
t6=t4;
f_927(t6,C_SCHEME_UNDEFINED);}}

/* k925 in k922 in char-set-hash in k749 in k745 in k629 */
static void C_fcall f_927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_927,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[37]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_933,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
f_720(t3,((C_word*)t0)[2],lf[37]);}

/* k931 in k925 in k922 in char-set-hash in k749 in k745 in k629 */
static void f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_986,a[2]=((C_word*)t0)[3],a[3]=lf[38],tmp=(C_word)a,a+=4,tmp);
t3=f_986(t2,C_fix(65536));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_941,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=lf[40],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_941(t7,((C_word*)t0)[2],C_fix(255),C_fix(0));}

/* lp in k931 in k925 in k922 in char-set-hash in k749 in k745 in k629 */
static void C_fcall f_941(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_941,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t5=*((C_word*)lf[39]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t5=(C_word)C_fixnum_difference(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_962,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=(C_word)C_i_string_ref(((C_word*)t0)[3],t7);
t9=f_639(t8);
t10=(C_word)C_eqp(t9,C_fix(0));
if(C_truep(t10)){
t11=t6;
f_962(t11,t3);}
else{
t11=(C_word)C_fixnum_times(C_fix(37),t3);
t12=(C_word)C_fixnum_plus(t11,t2);
t13=t6;
f_962(t13,(C_word)C_fixnum_and(((C_word*)t0)[2],t12));}}}

/* k960 in lp in k931 in k925 in k922 in char-set-hash in k749 in k745 in k629 */
static void C_fcall f_962(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_941(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* lp in k931 in k925 in k922 in char-set-hash in k749 in k745 in k629 */
static C_word C_fcall f_986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=t1;
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,t3))){
return((C_word)C_fixnum_difference(t1,C_fix(1)));}
else{
t4=(C_word)C_fixnum_plus(t1,t1);
t6=t4;
t1=t6;
goto loop;}}

/* char-set<= in k749 in k745 in k629 */
static void f_822(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_822r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_822r(t0,t1,t2);}}

static void f_822r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_842,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_720(t6,t4,lf[33]);}}

/* k840 in char-set<= in k749 in k745 in k629 */
static void f_842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_842,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_844,a[2]=t3,a[3]=lf[35],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_844(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* lp in k840 in char-set<= in k749 in k745 in k629 */
static void C_fcall f_844(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_844,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_pairp(t3);
t5=(C_word)C_i_not(t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_854,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_i_car(t3);
f_720(t6,t7,lf[33]);}}

/* k852 in lp in k840 in char-set<= in k749 in k745 in k629 */
static void f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_854,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)((C_word*)t0)[3])[1];
f_844(t4,((C_word*)t0)[2],t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_871,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=lf[34],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_871(t7,((C_word*)t0)[2],C_fix(255));}}

/* lp2 in k852 in lp in k840 in char-set<= in k749 in k745 in k629 */
static void C_fcall f_871(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_871,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=((C_word*)((C_word*)t0)[6])[1];
f_844(t4,t1,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=((C_word*)t0)[3];
t5=t2;
t6=(C_word)C_i_string_ref(t4,t5);
t7=f_639(t6);
t8=t2;
t9=(C_word)C_i_string_ref(((C_word*)t0)[5],t8);
t10=f_639(t9);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t7,t10))){
t11=(C_word)C_fixnum_difference(t2,C_fix(1));
t13=t1;
t14=t11;
t1=t13;
t2=t14;
goto loop;}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}}

/* char-set= in k749 in k745 in k629 */
static void f_767(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_767r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_767r(t0,t1,t2);}}

static void f_767r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_783,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
f_720(t6,t4,lf[30]);}}

/* k781 in char-set= in k749 in k745 in k629 */
static void f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_788,a[2]=t3,a[3]=t1,a[4]=lf[31],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_788(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lp in k781 in char-set= in k749 in k745 in k629 */
static void C_fcall f_788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_788,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_812,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t2);
f_720(t5,t6,lf[30]);}}

/* k810 in lp in k781 in char-set= in k749 in k745 in k629 */
static void f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(((C_word*)t0)[5],t1))){
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_788(t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* char-set-copy in k749 in k745 in k629 */
static void f_753(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_753,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_761,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
f_720(t4,t2,lf[28]);}

/* k763 in char-set-copy in k749 in k745 in k629 */
static void f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_663(((C_word*)t0)[2],t1);}

/* k759 in char-set-copy in k749 in k745 in k629 */
static void f_761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[6]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* %char-set:s/check in k629 */
static void C_fcall f_720(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_720,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_726,a[2]=t3,a[3]=t5,a[4]=lf[24],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_726(t7,t1,t2);}

/* lp in %char-set:s/check in k629 */
static void C_fcall f_726(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_726,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_733,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k731 in lp in %char-set:s/check in k629 */
static void f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_743,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[23],((C_word*)t0)[4]);}}

/* k741 in k731 in lp in %char-set:s/check in k629 */
static void f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_726(t2,((C_word*)t0)[2],t1);}

/* %default-base in k629 */
static void C_fcall f_673(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_673,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_i_car(t2);
t5=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t5))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_698,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[11]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
t6=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,lf[19],t3,t2);}}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_718,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=lf[2];
f_633(3,t5,t4,C_fix(0));}}

/* k716 in %default-base in k629 */
static void f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[20]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_fix(256),t1);}

/* k696 in %default-base in k629 */
static void f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_698,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_705,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[9]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=*((C_word*)lf[17]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[18],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k703 in k696 in %default-base in k629 */
static void f_705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_663(((C_word*)t0)[2],t1);}

/* %string-copy in k629 */
static void C_fcall f_663(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_663,NULL,2,t1,t2);}
t3=(C_word)C_i_string_length(t2);
t4=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,C_fix(0),t3);}

/* char-set? in k629 */
static void f_657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_657,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[7]));}

/* char-set:s in k629 */
static void f_651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_651,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* make-char-set in k629 */
static void f_645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_645,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,2,lf[7],t2));}

/* %char->latin1 in k629 */
static C_word C_fcall f_639(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)C_fix((C_word)C_character_code(t1)));}

/* %latin1->char in k629 */
static void f_633(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_633,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_make_character((C_word)C_unfix(t2)));}
/* end of file */
