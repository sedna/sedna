/* Generated from eval.scm by the Chicken compiler
   2005-09-24 22:13
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: eval.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file eval.c -explicit-use
   unit: eval
*/

#include "chicken.h"


#ifndef C_INSTALL_LIB_HOME
# define C_INSTALL_LIB_HOME    "."
#endif

#define C_METHOD_CACHE_SIZE 8

#define C_store_result(x, ptr)   (*((C_word *)C_block_item(ptr, 0)) = (x), C_SCHEME_TRUE)


#define C_copy_result_string(str, buf, n)  (C_memcpy((char *)C_block_item(buf, 0), C_c_string(str), C_unfix(n)), ((char *)C_block_item(buf, 0))[ C_unfix(n) ] = '\0', C_SCHEME_TRUE)


C_externexport  void  CHICKEN_get_error_message(char *t0,int t1);

C_externexport  int  CHICKEN_load(char * t0);

C_externexport  int  CHICKEN_read(char * t0,C_word *t1);

C_externexport  int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3);

C_externexport  int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2);

C_externexport  int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2);

C_externexport  int  CHICKEN_eval_string(char * t0,C_word *t1);

C_externexport  int  CHICKEN_eval(C_word t0,C_word *t1);

C_externexport  int  CHICKEN_yield();


static C_TLS C_word lf[865];


C_externexport void C_eval_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_1594(C_word c,C_word t0,C_word t1) C_noret;
static void f_1598(C_word c,C_word t0,C_word t1) C_noret;
static void f_10435(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_10435r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_10439(C_word t0,C_word t1) C_noret;
static void f_10460(C_word c,C_word t0,C_word t1) C_noret;
static void f_10454(C_word c,C_word t0,C_word t1) C_noret;
static void f_10447(C_word c,C_word t0,C_word t1) C_noret;
static void f_10445(C_word c,C_word t0,C_word t1) C_noret;
static void f_5690(C_word c,C_word t0,C_word t1) C_noret;
static void f_5789(C_word c,C_word t0,C_word t1) C_noret;
static void f_5868(C_word c,C_word t0,C_word t1) C_noret;
static void f_10429(C_word c,C_word t0,C_word t1) C_noret;
static void f_10425(C_word c,C_word t0,C_word t1) C_noret;
static void f_10421(C_word c,C_word t0,C_word t1) C_noret;
static void f_10417(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10407(C_word t0,C_word t1) C_noret;
static void C_fcall f_6381(C_word t0,C_word t1) C_noret;
static void f_10392(C_word c,C_word t0,C_word t1) C_noret;
static void f_10388(C_word c,C_word t0,C_word t1) C_noret;
static void f_10384(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_10374(C_word t0,C_word t1) C_noret;
static void C_fcall f_6385(C_word t0,C_word t1) C_noret;
static void f_6389(C_word c,C_word t0,C_word t1) C_noret;
static void f_10353(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6392(C_word t0,C_word t1) C_noret;
static void f_10343(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_10335(C_word c,C_word t0,C_word t1) C_noret;
static void f_10337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6396(C_word c,C_word t0,C_word t1) C_noret;
static void f_10319(C_word c,C_word t0,C_word t1) C_noret;
static void f_10325(C_word c,C_word t0,C_word t1) C_noret;
static void f_10322(C_word c,C_word t0,C_word t1) C_noret;
static void f_6737(C_word c,C_word t0,C_word t1) C_noret;
static void f_10265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_10279(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10315(C_word c,C_word t0,C_word t1) C_noret;
static void f_10311(C_word c,C_word t0,C_word t1) C_noret;
static void f_10299(C_word c,C_word t0,C_word t1) C_noret;
static void f_10303(C_word c,C_word t0,C_word t1) C_noret;
static void f_10273(C_word c,C_word t0,C_word t1) C_noret;
static void f_7379(C_word c,C_word t0,C_word t1) C_noret;
static void f_10174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_10181(C_word t0,C_word t1) C_noret;
static void f_10190(C_word c,C_word t0,C_word t1) C_noret;
static void f_10209(C_word c,C_word t0,C_word t1) C_noret;
static void f_10213(C_word c,C_word t0,C_word t1) C_noret;
static void f_10199(C_word c,C_word t0,C_word t1) C_noret;
static void f_10196(C_word c,C_word t0,C_word t1) C_noret;
static void f_7382(C_word c,C_word t0,C_word t1) C_noret;
static void f_7440(C_word c,C_word t0,C_word t1) C_noret;
static void f_10172(C_word c,C_word t0,C_word t1) C_noret;
static void f_7629(C_word c,C_word t0,C_word t1) C_noret;
static void f_7633(C_word c,C_word t0,C_word t1) C_noret;
static void f_10168(C_word c,C_word t0,C_word t1) C_noret;
static void f_7636(C_word c,C_word t0,C_word t1) C_noret;
static void f_10074(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_10080(C_word t0,C_word t1,C_word t2) C_noret;
static void f_10096(C_word c,C_word t0,C_word t1) C_noret;
static void f_10099(C_word c,C_word t0,C_word t1) C_noret;
static void f_10134(C_word c,C_word t0,C_word t1) C_noret;
static void f_10137(C_word c,C_word t0,C_word t1) C_noret;
static void f_10152(C_word c,C_word t0,C_word t1) C_noret;
static void f_10148(C_word c,C_word t0,C_word t1) C_noret;
static void f_10121(C_word c,C_word t0,C_word t1) C_noret;
static void f_10124(C_word c,C_word t0,C_word t1) C_noret;
static void f_10131(C_word c,C_word t0,C_word t1) C_noret;
static void f_8328(C_word c,C_word t0,C_word t1) C_noret;
static void f_10046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_10072(C_word c,C_word t0,C_word t1) C_noret;
static void f_8331(C_word c,C_word t0,C_word t1) C_noret;
static void f_10003(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_10025(C_word c,C_word t0,C_word t1) C_noret;
static void f_10040(C_word c,C_word t0,C_word t1) C_noret;
static void f_8334(C_word c,C_word t0,C_word t1) C_noret;
static void f_9862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9868(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9884(C_word c,C_word t0,C_word t1) C_noret;
static void f_9973(C_word c,C_word t0,C_word t1) C_noret;
static void f_9977(C_word c,C_word t0,C_word t1) C_noret;
static void f_9923(C_word c,C_word t0,C_word t1) C_noret;
static void f_9942(C_word c,C_word t0,C_word t1) C_noret;
static void f_9914(C_word c,C_word t0,C_word t1) C_noret;
static void f_8337(C_word c,C_word t0,C_word t1) C_noret;
static void f_9759(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9769(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9782(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9798(C_word c,C_word t0,C_word t1) C_noret;
static void f_9836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9834(C_word c,C_word t0,C_word t1) C_noret;
static void f_9818(C_word c,C_word t0,C_word t1) C_noret;
static void f_9822(C_word c,C_word t0,C_word t1) C_noret;
static void f_9826(C_word c,C_word t0,C_word t1) C_noret;
static void f_9780(C_word c,C_word t0,C_word t1) C_noret;
static void f_8340(C_word c,C_word t0,C_word t1) C_noret;
static void f_9706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9716(C_word c,C_word t0,C_word t1) C_noret;
static void f_9719(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9724(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9749(C_word c,C_word t0,C_word t1) C_noret;
static void f_9738(C_word c,C_word t0,C_word t1) C_noret;
static void f_8343(C_word c,C_word t0,C_word t1) C_noret;
static void f_9636(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9646(C_word c,C_word t0,C_word t1) C_noret;
static void f_9649(C_word c,C_word t0,C_word t1) C_noret;
static void f_9696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9660(C_word c,C_word t0,C_word t1) C_noret;
static void f_9682(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9668(C_word c,C_word t0,C_word t1) C_noret;
static void f_9680(C_word c,C_word t0,C_word t1) C_noret;
static void f_9676(C_word c,C_word t0,C_word t1) C_noret;
static void f_9664(C_word c,C_word t0,C_word t1) C_noret;
static void f_9656(C_word c,C_word t0,C_word t1) C_noret;
static void f_8346(C_word c,C_word t0,C_word t1) C_noret;
static void f_9517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_9517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_9521(C_word c,C_word t0,C_word t1) C_noret;
static void f_9524(C_word c,C_word t0,C_word t1) C_noret;
static void f_9527(C_word c,C_word t0,C_word t1) C_noret;
static void f_9618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9534(C_word c,C_word t0,C_word t1) C_noret;
static void f_9549(C_word c,C_word t0,C_word t1) C_noret;
static void f_9610(C_word c,C_word t0,C_word t1) C_noret;
static void f_9557(C_word c,C_word t0,C_word t1) C_noret;
static void f_9571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9569(C_word c,C_word t0,C_word t1) C_noret;
static void f_9565(C_word c,C_word t0,C_word t1) C_noret;
static void f_9561(C_word c,C_word t0,C_word t1) C_noret;
static void f_8349(C_word c,C_word t0,C_word t1) C_noret;
static void f_9225(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9435(C_word t0,C_word t1,C_word t2) C_noret;
static void f_9439(C_word c,C_word t0,C_word t1) C_noret;
static void f_9460(C_word c,C_word t0,C_word t1) C_noret;
static void f_9502(C_word c,C_word t0,C_word t1) C_noret;
static void f_9483(C_word c,C_word t0,C_word t1) C_noret;
static void f_9479(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9238(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9426(C_word c,C_word t0,C_word t1) C_noret;
static void f_9430(C_word c,C_word t0,C_word t1) C_noret;
static void f_9409(C_word c,C_word t0,C_word t1) C_noret;
static void f_9413(C_word c,C_word t0,C_word t1) C_noret;
static void f_9398(C_word c,C_word t0,C_word t1) C_noret;
static void f_9390(C_word c,C_word t0,C_word t1) C_noret;
static void f_9379(C_word c,C_word t0,C_word t1) C_noret;
static void f_9345(C_word c,C_word t0,C_word t1) C_noret;
static void f_9326(C_word c,C_word t0,C_word t1) C_noret;
static void f_9299(C_word c,C_word t0,C_word t1) C_noret;
static void f_9256(C_word c,C_word t0,C_word t1) C_noret;
static void f_9252(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9228(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9236(C_word c,C_word t0,C_word t1) C_noret;
static void f_8352(C_word c,C_word t0,C_word t1) C_noret;
static void f_9215(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8355(C_word c,C_word t0,C_word t1) C_noret;
static void f_8359(C_word c,C_word t0,C_word t1) C_noret;
static void f_9212(C_word c,C_word t0,C_word t1) C_noret;
static void f_8375(C_word c,C_word t0,C_word t1) C_noret;
static void f_8600(C_word c,C_word t0,C_word t1) C_noret;
static void f_9087(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_9087r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_9188(C_word c,C_word t0,C_word t1) C_noret;
static void f_9191(C_word c,C_word t0,C_word t1) C_noret;
static void f_9206(C_word c,C_word t0,C_word t1) C_noret;
static void f_9202(C_word c,C_word t0,C_word t1) C_noret;
static void f_9178(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9090(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_9094(C_word t0,C_word t1) C_noret;
static void f_9120(C_word c,C_word t0,C_word t1) C_noret;
static void f_9116(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_9105(C_word t0,C_word t1) C_noret;
static void f_8686(C_word c,C_word t0,C_word t1) C_noret;
static void f_9068(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_9068r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_9072(C_word c,C_word t0,C_word t1) C_noret;
static void f_9081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9079(C_word c,C_word t0,C_word t1) C_noret;
static void f_8689(C_word c,C_word t0,C_word t1) C_noret;
static void f_9062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8692(C_word c,C_word t0,C_word t1) C_noret;
static void f_9056(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8695(C_word c,C_word t0,C_word t1) C_noret;
static void f_9047(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9054(C_word c,C_word t0,C_word t1) C_noret;
static void f_9037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_9026(C_word c,C_word t0,C_word t1) C_noret;
static void f_9031(C_word c,C_word t0,C_word t1) C_noret;
static void f_9035(C_word c,C_word t0,C_word t1) C_noret;
static void f_9000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_9004(C_word c,C_word t0,C_word t1) C_noret;
static void f_9009(C_word c,C_word t0,C_word t1) C_noret;
static void f_9013(C_word c,C_word t0,C_word t1) C_noret;
static void f_9020(C_word c,C_word t0,C_word t1) C_noret;
static void f_8974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_8980(C_word c,C_word t0,C_word t1) C_noret;
static void f_8984(C_word c,C_word t0,C_word t1) C_noret;
static void f_8998(C_word c,C_word t0,C_word t1) C_noret;
static void f_8987(C_word c,C_word t0,C_word t1) C_noret;
static void f_8994(C_word c,C_word t0,C_word t1) C_noret;
static void f_8958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8964(C_word c,C_word t0,C_word t1) C_noret;
static void f_8972(C_word c,C_word t0,C_word t1) C_noret;
static void f_8921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8925(C_word c,C_word t0,C_word t1) C_noret;
static void f_8930(C_word c,C_word t0,C_word t1) C_noret;
static void f_8934(C_word c,C_word t0,C_word t1) C_noret;
static void f_8956(C_word c,C_word t0,C_word t1) C_noret;
static void f_8952(C_word c,C_word t0,C_word t1) C_noret;
static void f_8948(C_word c,C_word t0,C_word t1) C_noret;
static void f_8937(C_word c,C_word t0,C_word t1) C_noret;
static void f_8944(C_word c,C_word t0,C_word t1) C_noret;
static void f_8895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_8901(C_word c,C_word t0,C_word t1) C_noret;
static void f_8905(C_word c,C_word t0,C_word t1) C_noret;
static void f_8919(C_word c,C_word t0,C_word t1) C_noret;
static void f_8908(C_word c,C_word t0,C_word t1) C_noret;
static void f_8915(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_8882(C_word t0,C_word t1,C_word t2);
static void f_8856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8860(C_word c,C_word t0,C_word t1) C_noret;
static void f_8865(C_word c,C_word t0,C_word t1) C_noret;
static void f_8869(C_word c,C_word t0,C_word t1) C_noret;
static void f_8880(C_word c,C_word t0,C_word t1) C_noret;
static void f_8876(C_word c,C_word t0,C_word t1) C_noret;
static void f_8840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8846(C_word c,C_word t0,C_word t1) C_noret;
static void f_8854(C_word c,C_word t0,C_word t1) C_noret;
static void f_8828(C_word c,C_word t0,C_word t1) C_noret;
static void f_8834(C_word c,C_word t0,C_word t1) C_noret;
static void f_8838(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8819(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8823(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8760(C_word t0,C_word t1) C_noret;
static void f_8770(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8795(C_word c,C_word t0,C_word t1) C_noret;
static void f_8807(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_8807r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_8813(C_word c,C_word t0,C_word t1) C_noret;
static void f_8801(C_word c,C_word t0,C_word t1) C_noret;
static void f_8776(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8782(C_word c,C_word t0,C_word t1) C_noret;
static void f_8786(C_word c,C_word t0,C_word t1) C_noret;
static void f_8789(C_word c,C_word t0,C_word t1) C_noret;
static void f_8793(C_word c,C_word t0,C_word t1) C_noret;
static void f_8768(C_word c,C_word t0,C_word t1) C_noret;
static void f_8728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8757(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8732(C_word t0,C_word t1) C_noret;
static void f_8741(C_word c,C_word t0,C_word t1) C_noret;
static void f_8746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8750(C_word c,C_word t0,C_word t1) C_noret;
static void f_8697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8726(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8701(C_word t0,C_word t1) C_noret;
static void f_8710(C_word c,C_word t0,C_word t1) C_noret;
static void f_8715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8719(C_word c,C_word t0,C_word t1) C_noret;
static void f_8611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8621(C_word c,C_word t0,C_word t1) C_noret;
static void f_8624(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8638(C_word t0,C_word t1) C_noret;
static void f_8656(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8625(C_word t0,C_word t1) C_noret;
static void f_8602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8393(C_word c,C_word t0,C_word t1) C_noret;
static void f_8440(C_word c,C_word t0,C_word t1) C_noret;
static void f_8443(C_word c,C_word t0,C_word t1) C_noret;
static void f_8589(C_word c,C_word t0,C_word t1) C_noret;
static void f_8593(C_word c,C_word t0,C_word t1) C_noret;
static void f_8506(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8512(C_word t0,C_word t1) C_noret;
static void f_8570(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8576(C_word c,C_word t0,C_word t1) C_noret;
static void f_8519(C_word c,C_word t0,C_word t1) C_noret;
static void f_8522(C_word c,C_word t0,C_word t1) C_noret;
static void f_8525(C_word c,C_word t0,C_word t1) C_noret;
static void f_8565(C_word c,C_word t0,C_word t1) C_noret;
static void f_8534(C_word c,C_word t0,C_word t1) C_noret;
static void f_8548(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_8548r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_8552(C_word c,C_word t0,C_word t1) C_noret;
static void f_8539(C_word c,C_word t0,C_word t1) C_noret;
static void f_8460(C_word c,C_word t0,C_word t1) C_noret;
static void f_8466(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_8466r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_8473(C_word c,C_word t0,C_word t1) C_noret;
static void f_8476(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_8482(C_word t0,C_word t1) C_noret;
static void f_8491(C_word c,C_word t0,C_word t1) C_noret;
static void f_8485(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_8451(C_word t0);
static C_word C_fcall f_8445(C_word t0);
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8427(C_word t0,C_word t1) C_noret;
static void C_fcall f_8411(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8396(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8405(C_word c,C_word t0,C_word t1) C_noret;
static void f_8400(C_word c,C_word t0,C_word t1) C_noret;
static void f_8377(C_word c,C_word t0,C_word t1) C_noret;
static void f_8391(C_word c,C_word t0,C_word t1) C_noret;
static void f_8388(C_word c,C_word t0,C_word t1) C_noret;
static void f_8381(C_word c,C_word t0,C_word t1) C_noret;
static void f_8361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8365(C_word c,C_word t0,C_word t1) C_noret;
static void f_7936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_7936r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_8073(C_word t0,C_word t1) C_noret;
static void C_fcall f_8078(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8296(C_word c,C_word t0,C_word t1) C_noret;
static void f_8277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_8223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_8094(C_word t0,C_word t1) C_noret;
static void C_fcall f_8099(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_8118(C_word c,C_word t0,C_word t1) C_noret;
static void f_8044(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static C_word C_fcall f_8050(C_word t0);
static void f_7982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7986(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2) C_noret;
static void f_8017(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7939(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7946(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7955(C_word c,C_word t0,C_word t1) C_noret;
static void f_7980(C_word c,C_word t0,C_word t1) C_noret;
static void f_7969(C_word c,C_word t0,C_word t1) C_noret;
static void f_7973(C_word c,C_word t0,C_word t1) C_noret;
static void f_7962(C_word c,C_word t0,C_word t1) C_noret;
static void f_7900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7922(C_word c,C_word t0,C_word t1) C_noret;
static void f_7892(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_7892r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_7838(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7842(C_word c,C_word t0,C_word t1) C_noret;
static void f_7845(C_word c,C_word t0,C_word t1) C_noret;
static void f_7848(C_word c,C_word t0,C_word t1) C_noret;
static void f_7851(C_word c,C_word t0,C_word t1) C_noret;
static void f_7854(C_word c,C_word t0,C_word t1) C_noret;
static void f_7857(C_word c,C_word t0,C_word t1) C_noret;
static void f_7860(C_word c,C_word t0,C_word t1) C_noret;
static void f_7863(C_word c,C_word t0,C_word t1) C_noret;
static void f_7866(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7817(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7821(C_word c,C_word t0,C_word t1) C_noret;
static void f_7824(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7793(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7799(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7809(C_word c,C_word t0,C_word t1) C_noret;
static void f_7659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_7659r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_7663(C_word c,C_word t0,C_word t1) C_noret;
static void f_7717(C_word c,C_word t0,C_word t1) C_noret;
static void f_7772(C_word c,C_word t0,C_word t1) C_noret;
static void f_7727(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7729(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7761(C_word c,C_word t0,C_word t1) C_noret;
static void f_7753(C_word c,C_word t0,C_word t1) C_noret;
static void f_7739(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7700(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7665(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7681(C_word c,C_word t0,C_word t1) C_noret;
static void f_7687(C_word c,C_word t0,C_word t1) C_noret;
static void f_7678(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7640(C_word t0,C_word t1) C_noret;
static void f_7644(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7613(C_word t0,C_word t1) C_noret;
static void f_7615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7619(C_word c,C_word t0,C_word t1) C_noret;
static void f_7575(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7575r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7582(C_word c,C_word t0,C_word t1) C_noret;
static void f_7589(C_word c,C_word t0,C_word t1) C_noret;
static void f_7531(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_7531r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_7564(C_word c,C_word t0,C_word t1) C_noret;
static void f_7551(C_word c,C_word t0,C_word t1) C_noret;
static void f_7528(C_word c,C_word t0,C_word t1) C_noret;
static void f_7447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7454(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7459(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7486(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7507(C_word c,C_word t0,C_word t1) C_noret;
static void f_7480(C_word c,C_word t0,C_word t1) C_noret;
static void f_7384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7388(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7396(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_7416(C_word t0,C_word t1) C_noret;
static void f_7340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7372(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_7006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_7216(C_word t0,C_word t1) C_noret;
static void f_7225(C_word c,C_word t0,C_word t1) C_noret;
static void f_7251(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7253(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_7286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_7276(C_word c,C_word t0,C_word t1) C_noret;
static void f_7271(C_word c,C_word t0,C_word t1) C_noret;
static void f_7267(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7030(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7040(C_word c,C_word t0,C_word t1) C_noret;
static void f_7151(C_word c,C_word t0,C_word t1) C_noret;
static void f_7190(C_word c,C_word t0,C_word t1) C_noret;
static void f_7177(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7161(C_word t0,C_word t1) C_noret;
static void f_7141(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7119(C_word t0,C_word t1) C_noret;
static void f_7126(C_word c,C_word t0,C_word t1) C_noret;
static void f_7091(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7098(C_word t0,C_word t1) C_noret;
static void f_7052(C_word c,C_word t0,C_word t1) C_noret;
static void f_7076(C_word c,C_word t0,C_word t1) C_noret;
static void f_7072(C_word c,C_word t0,C_word t1) C_noret;
static void f_7064(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_7055(C_word t0,C_word t1) C_noret;
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2) C_noret;
static void f_7024(C_word c,C_word t0,C_word t1) C_noret;
static void f_7018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_6963(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6977(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6980(C_word t0,C_word t1) C_noret;
static void f_6987(C_word c,C_word t0,C_word t1) C_noret;
static void f_6951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6933(C_word c,C_word t0,C_word t1) C_noret;
static void f_6949(C_word c,C_word t0,C_word t1) C_noret;
static void f_6936(C_word c,C_word t0,C_word t1) C_noret;
static void f_6942(C_word c,C_word t0,C_word t1) C_noret;
static void f_6916(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6916r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_6922(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6913(C_word c,C_word t0,C_word t1) C_noret;
static void f_6882(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6882r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_6888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6895(C_word c,C_word t0,C_word t1) C_noret;
static void f_6817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_6817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_6824(C_word c,C_word t0,C_word t1) C_noret;
static void f_6842(C_word c,C_word t0,C_word t1) C_noret;
static void f_6858(C_word c,C_word t0,C_word t1) C_noret;
static void f_6848(C_word c,C_word t0,C_word t1) C_noret;
static void f_6740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6814(C_word c,C_word t0,C_word t1) C_noret;
static void f_6807(C_word c,C_word t0,C_word t1) C_noret;
static void f_6774(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6776(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6789(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6743(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6747(C_word c,C_word t0,C_word t1) C_noret;
static void f_6767(C_word c,C_word t0,C_word t1) C_noret;
static void f_6753(C_word c,C_word t0,C_word t1) C_noret;
static void f_6763(C_word c,C_word t0,C_word t1) C_noret;
static void f_6756(C_word c,C_word t0,C_word t1) C_noret;
static void f_6589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6682(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6699(C_word c,C_word t0,C_word t1) C_noret;
static void f_6707(C_word c,C_word t0,C_word t1) C_noret;
static void f_6599(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6643(C_word c,C_word t0,C_word t1) C_noret;
static void f_6630(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6592(C_word t0,C_word t1) C_noret;
static void f_6533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_6542(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_6580(C_word c,C_word t0,C_word t1) C_noret;
static void f_6560(C_word c,C_word t0,C_word t1) C_noret;
static void f_6504(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6504r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6511(C_word c,C_word t0,C_word t1) C_noret;
static void f_6521(C_word c,C_word t0,C_word t1) C_noret;
static void f_6398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6402(C_word c,C_word t0,C_word t1) C_noret;
static void f_6494(C_word c,C_word t0,C_word t1) C_noret;
static void f_6498(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6411(C_word t0,C_word t1) C_noret;
static void f_6480(C_word c,C_word t0,C_word t1) C_noret;
static void f_6476(C_word c,C_word t0,C_word t1) C_noret;
static void f_6414(C_word c,C_word t0,C_word t1) C_noret;
static void f_6463(C_word c,C_word t0,C_word t1) C_noret;
static void f_6466(C_word c,C_word t0,C_word t1) C_noret;
static void f_6469(C_word c,C_word t0,C_word t1) C_noret;
static void f_6417(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6422(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6456(C_word c,C_word t0,C_word t1) C_noret;
static void f_6435(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6438(C_word t0,C_word t1) C_noret;
static void f_6339(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6339r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6376(C_word c,C_word t0,C_word t1) C_noret;
static void f_6343(C_word c,C_word t0,C_word t1) C_noret;
static void f_6373(C_word c,C_word t0,C_word t1) C_noret;
static void f_6346(C_word c,C_word t0,C_word t1) C_noret;
static void f_6370(C_word c,C_word t0,C_word t1) C_noret;
static void f_6349(C_word c,C_word t0,C_word t1) C_noret;
static void f_6365(C_word c,C_word t0,C_word t1) C_noret;
static void f_6359(C_word c,C_word t0,C_word t1) C_noret;
static void f_6354(C_word c,C_word t0,C_word t1) C_noret;
static void f_6294(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6294r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6334(C_word c,C_word t0,C_word t1) C_noret;
static void f_6305(C_word c,C_word t0,C_word t1) C_noret;
static void f_6313(C_word c,C_word t0,C_word t1) C_noret;
static void f_6300(C_word c,C_word t0,C_word t1) C_noret;
static void f_5916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_5916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_6246(C_word t0,C_word t1) C_noret;
static void C_fcall f_6241(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5918(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_6240(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5922(C_word t0,C_word t1) C_noret;
static void f_6174(C_word c,C_word t0,C_word t1) C_noret;
static void f_6189(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_6192(C_word t0,C_word t1) C_noret;
static void f_6195(C_word c,C_word t0,C_word t1) C_noret;
static void f_6201(C_word c,C_word t0,C_word t1) C_noret;
static void f_6204(C_word c,C_word t0,C_word t1) C_noret;
static void f_6210(C_word c,C_word t0,C_word t1) C_noret;
static void f_5925(C_word c,C_word t0,C_word t1) C_noret;
static void f_6152(C_word c,C_word t0,C_word t1) C_noret;
static void f_6143(C_word c,C_word t0,C_word t1) C_noret;
static void f_6146(C_word c,C_word t0,C_word t1) C_noret;
static void f_5931(C_word c,C_word t0,C_word t1) C_noret;
static void f_6128(C_word c,C_word t0,C_word t1) C_noret;
static void f_6100(C_word c,C_word t0,C_word t1) C_noret;
static void f_6120(C_word c,C_word t0,C_word t1) C_noret;
static void f_6116(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5880(C_word t0,C_word t1);
static void f_5934(C_word c,C_word t0,C_word t1) C_noret;
static void f_5942(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6090(C_word c,C_word t0,C_word t1) C_noret;
static void f_5962(C_word c,C_word t0,C_word t1) C_noret;
static void f_5966(C_word c,C_word t0,C_word t1) C_noret;
static void f_6081(C_word c,C_word t0,C_word t1) C_noret;
static void f_5974(C_word c,C_word t0,C_word t1) C_noret;
static void f_5978(C_word c,C_word t0,C_word t1) C_noret;
static void f_6075(C_word c,C_word t0,C_word t1) C_noret;
static void f_5981(C_word c,C_word t0,C_word t1) C_noret;
static void f_5988(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2) C_noret;
static void f_6000(C_word c,C_word t0,C_word t1) C_noret;
static void f_6046(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6046r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_6055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_6059(C_word c,C_word t0,C_word t1) C_noret;
static void f_6012(C_word c,C_word t0,C_word t1) C_noret;
static void f_6019(C_word c,C_word t0,C_word t1) C_noret;
static void f_6030(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_6030r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_6041(C_word c,C_word t0,C_word t1) C_noret;
static void f_6034(C_word c,C_word t0,C_word t1) C_noret;
static void f_6024(C_word c,C_word t0,C_word t1) C_noret;
static void f_6003(C_word c,C_word t0,C_word t1) C_noret;
static void f_6010(C_word c,C_word t0,C_word t1) C_noret;
static void f_5971(C_word c,C_word t0,C_word t1) C_noret;
static void f_5953(C_word c,C_word t0,C_word t1) C_noret;
static void f_5944(C_word c,C_word t0,C_word t1) C_noret;
static void f_5937(C_word c,C_word t0,C_word t1) C_noret;
static void f_6159(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_6159r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_6167(C_word c,C_word t0,C_word t1) C_noret;
static void f_6171(C_word c,C_word t0,C_word t1) C_noret;
static void f_5795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5820(C_word c,C_word t0,C_word t1) C_noret;
static void f_5802(C_word c,C_word t0,C_word t1) C_noret;
static void f_5791(C_word c,C_word t0,C_word t1) C_noret;
static void f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_5720(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5753(C_word c,C_word t0,C_word t1) C_noret;
static void f_5734(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5710(C_word t0,C_word t1) C_noret;
static void f_5693(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_5693r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_5701(C_word c,C_word t0,C_word t1) C_noret;
static void f_5705(C_word c,C_word t0,C_word t1) C_noret;
static void f_3556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_5476(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5480(C_word c,C_word t0,C_word t1) C_noret;
static void f_5675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5654(C_word c,C_word t0,C_word t1) C_noret;
static void f_5655(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5663(C_word c,C_word t0,C_word t1) C_noret;
static void f_5669(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5667(C_word c,C_word t0,C_word t1) C_noret;
static void f_5614(C_word c,C_word t0,C_word t1) C_noret;
static void f_5617(C_word c,C_word t0,C_word t1) C_noret;
static void f_5620(C_word c,C_word t0,C_word t1) C_noret;
static void f_5623(C_word c,C_word t0,C_word t1) C_noret;
static void f_5624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5632(C_word c,C_word t0,C_word t1) C_noret;
static void f_5636(C_word c,C_word t0,C_word t1) C_noret;
static void f_5640(C_word c,C_word t0,C_word t1) C_noret;
static void f_5644(C_word c,C_word t0,C_word t1) C_noret;
static void f_5647(C_word c,C_word t0,C_word t1) C_noret;
static void f_5575(C_word c,C_word t0,C_word t1) C_noret;
static void f_5578(C_word c,C_word t0,C_word t1) C_noret;
static void f_5581(C_word c,C_word t0,C_word t1) C_noret;
static void f_5582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5590(C_word c,C_word t0,C_word t1) C_noret;
static void f_5594(C_word c,C_word t0,C_word t1) C_noret;
static void f_5598(C_word c,C_word t0,C_word t1) C_noret;
static void f_5601(C_word c,C_word t0,C_word t1) C_noret;
static void f_5543(C_word c,C_word t0,C_word t1) C_noret;
static void f_5546(C_word c,C_word t0,C_word t1) C_noret;
static void f_5547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5555(C_word c,C_word t0,C_word t1) C_noret;
static void f_5559(C_word c,C_word t0,C_word t1) C_noret;
static void f_5562(C_word c,C_word t0,C_word t1) C_noret;
static void f_5518(C_word c,C_word t0,C_word t1) C_noret;
static void f_5519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5527(C_word c,C_word t0,C_word t1) C_noret;
static void f_5530(C_word c,C_word t0,C_word t1) C_noret;
static void f_5502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5509(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_5450(C_word t0,C_word t1);
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_3884(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3940(C_word t0,C_word t1) C_noret;
static void f_3966(C_word c,C_word t0,C_word t1) C_noret;
static void f_3972(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5286(C_word t0,C_word t1) C_noret;
static void f_5273(C_word c,C_word t0,C_word t1) C_noret;
static void f_5269(C_word c,C_word t0,C_word t1) C_noret;
static void f_5265(C_word c,C_word t0,C_word t1) C_noret;
static void f_5234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5223(C_word c,C_word t0,C_word t1) C_noret;
static void f_5185(C_word c,C_word t0,C_word t1) C_noret;
static void f_5179(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_5133(C_word t0,C_word t1,C_word t2) C_noret;
static void f_5155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5163(C_word c,C_word t0,C_word t1) C_noret;
static void f_5145(C_word c,C_word t0,C_word t1) C_noret;
static void f_5153(C_word c,C_word t0,C_word t1) C_noret;
static void f_5127(C_word c,C_word t0,C_word t1) C_noret;
static void f_5103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5110(C_word c,C_word t0,C_word t1) C_noret;
static void f_5072(C_word c,C_word t0,C_word t1) C_noret;
static void f_5075(C_word c,C_word t0,C_word t1) C_noret;
static void f_5078(C_word c,C_word t0,C_word t1) C_noret;
static void f_5097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_5095(C_word c,C_word t0,C_word t1) C_noret;
static void f_5085(C_word c,C_word t0,C_word t1) C_noret;
static void f_5055(C_word c,C_word t0,C_word t1) C_noret;
static void f_5038(C_word c,C_word t0,C_word t1) C_noret;
static void f_4678(C_word c,C_word t0,C_word t1) C_noret;
static void f_5007(C_word c,C_word t0,C_word t1) C_noret;
static void f_5018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_5012(C_word c,C_word t0,C_word t1) C_noret;
static void f_4690(C_word c,C_word t0,C_word t1) C_noret;
static void f_4695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_5000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4998(C_word c,C_word t0,C_word t1) C_noret;
static void f_4702(C_word c,C_word t0,C_word t1) C_noret;
static void f_4960(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4966(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4966r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4990(C_word c,C_word t0,C_word t1) C_noret;
static void f_4986(C_word c,C_word t0,C_word t1) C_noret;
static void f_4937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4943(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4943r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_5417(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4959(C_word c,C_word t0,C_word t1) C_noret;
static void f_4955(C_word c,C_word t0,C_word t1) C_noret;
static void f_4951(C_word c,C_word t0,C_word t1) C_noret;
static void f_4915(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_4933(C_word c,C_word t0,C_word t1) C_noret;
static void f_4929(C_word c,C_word t0,C_word t1) C_noret;
static void f_4896(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...) C_noret;
static void f_4902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t7) C_noret;
static void f_4868(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_4849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_4855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void f_4821(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4802(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_4808r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_4774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4780(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4755(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4761(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_4761r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_4731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4737(C_word c,C_word t0,C_word t1) C_noret;
static void f_4712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4718(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4718r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_4384(C_word c,C_word t0,C_word t1) C_noret;
static void f_4665(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4393(C_word c,C_word t0,C_word t1) C_noret;
static void f_4659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4653(C_word c,C_word t0,C_word t1) C_noret;
static void f_4399(C_word c,C_word t0,C_word t1) C_noret;
static void f_4641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4594(C_word c,C_word t0,C_word t1) C_noret;
static void f_4595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4599(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_4611(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4636(C_word c,C_word t0,C_word t1) C_noret;
static void f_4602(C_word c,C_word t0,C_word t1) C_noret;
static void f_4591(C_word c,C_word t0,C_word t1) C_noret;
static void f_4534(C_word c,C_word t0,C_word t1) C_noret;
static void f_4587(C_word c,C_word t0,C_word t1) C_noret;
static void f_4537(C_word c,C_word t0,C_word t1) C_noret;
static void f_4583(C_word c,C_word t0,C_word t1) C_noret;
static void f_4543(C_word c,C_word t0,C_word t1) C_noret;
static void f_4579(C_word c,C_word t0,C_word t1) C_noret;
static void f_4546(C_word c,C_word t0,C_word t1) C_noret;
static void f_4547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4563(C_word c,C_word t0,C_word t1) C_noret;
static void f_4567(C_word c,C_word t0,C_word t1) C_noret;
static void f_4571(C_word c,C_word t0,C_word t1) C_noret;
static void f_4575(C_word c,C_word t0,C_word t1) C_noret;
static void f_4525(C_word c,C_word t0,C_word t1) C_noret;
static void f_4479(C_word c,C_word t0,C_word t1) C_noret;
static void f_4521(C_word c,C_word t0,C_word t1) C_noret;
static void f_4482(C_word c,C_word t0,C_word t1) C_noret;
static void f_4517(C_word c,C_word t0,C_word t1) C_noret;
static void f_4488(C_word c,C_word t0,C_word t1) C_noret;
static void f_4489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4505(C_word c,C_word t0,C_word t1) C_noret;
static void f_4509(C_word c,C_word t0,C_word t1) C_noret;
static void f_4513(C_word c,C_word t0,C_word t1) C_noret;
static void f_4470(C_word c,C_word t0,C_word t1) C_noret;
static void f_4438(C_word c,C_word t0,C_word t1) C_noret;
static void f_4466(C_word c,C_word t0,C_word t1) C_noret;
static void f_4441(C_word c,C_word t0,C_word t1) C_noret;
static void f_4442(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4458(C_word c,C_word t0,C_word t1) C_noret;
static void f_4462(C_word c,C_word t0,C_word t1) C_noret;
static void f_4429(C_word c,C_word t0,C_word t1) C_noret;
static void f_4408(C_word c,C_word t0,C_word t1) C_noret;
static void f_4409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4425(C_word c,C_word t0,C_word t1) C_noret;
static void f_4278(C_word c,C_word t0,C_word t1) C_noret;
static void f_4292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_4296(C_word c,C_word t0,C_word t1) C_noret;
static void f_4335(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4343(C_word c,C_word t0,C_word t1) C_noret;
static void f_4308(C_word c,C_word t0,C_word t1) C_noret;
static void f_4311(C_word c,C_word t0,C_word t1) C_noret;
static void f_4327(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4318(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4326(C_word c,C_word t0,C_word t1) C_noret;
static void f_4363(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4371(C_word c,C_word t0,C_word t1) C_noret;
static void f_4350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4362(C_word c,C_word t0,C_word t1) C_noret;
static void f_4286(C_word c,C_word t0,C_word t1) C_noret;
static void f_4170(C_word c,C_word t0,C_word t1) C_noret;
static void f_4229(C_word c,C_word t0,C_word t1) C_noret;
static void f_4232(C_word c,C_word t0,C_word t1) C_noret;
static void f_4250(C_word c,C_word t0,C_word t1) C_noret;
static void f_4235(C_word c,C_word t0,C_word t1) C_noret;
static void f_4236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4240(C_word c,C_word t0,C_word t1) C_noret;
static void f_4243(C_word c,C_word t0,C_word t1) C_noret;
static void f_4207(C_word c,C_word t0,C_word t1) C_noret;
static void f_4210(C_word c,C_word t0,C_word t1) C_noret;
static void f_4211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4215(C_word c,C_word t0,C_word t1) C_noret;
static void f_4113(C_word c,C_word t0,C_word t1) C_noret;
static void f_4116(C_word c,C_word t0,C_word t1) C_noret;
static void f_4119(C_word c,C_word t0,C_word t1) C_noret;
static void f_4122(C_word c,C_word t0,C_word t1) C_noret;
static void f_4123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4130(C_word c,C_word t0,C_word t1) C_noret;
static void f_4103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_4069(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4063(C_word c,C_word t0,C_word t1) C_noret;
static void f_4064(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3987(C_word c,C_word t0,C_word t1) C_noret;
static void f_4047(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4045(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4037(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4029(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4021(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4013(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_4005(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3997(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3941(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3930(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3928(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3917(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3915(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3907(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3899(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3891(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3857(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3836(C_word c,C_word t0,C_word t1) C_noret;
static void f_3839(C_word c,C_word t0,C_word t1) C_noret;
static void f_3840(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_3874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3817(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3799(C_word c,C_word t0,C_word t1) C_noret;
static void f_3797(C_word c,C_word t0,C_word t1) C_noret;
static void f_3793(C_word c,C_word t0,C_word t1) C_noret;
static void f_3772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3717(C_word c,C_word t0,C_word t1) C_noret;
static void f_3764(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3732(C_word t0,C_word t1) C_noret;
static void C_fcall f_3741(C_word t0,C_word t1) C_noret;
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3607(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3559(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_3565(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_3683(C_word t0,C_word t1,C_word t2);
static void f_3493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3497(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_3453(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_3463(C_word c,C_word t0,C_word t1) C_noret;
static void f_3392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3396(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3404(C_word t0,C_word t1,C_word t2) C_noret;
static void f_3347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3351(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_3360(C_word t0,C_word t1);
static void f_3332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3327(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3275(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3316(C_word c,C_word t0,C_word t1) C_noret;
static void f_3312(C_word c,C_word t0,C_word t1) C_noret;
static void f_3293(C_word c,C_word t0,C_word t1) C_noret;
static void f_3181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_3270(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_3184(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_3239(C_word c,C_word t0,C_word t1) C_noret;
static void f_2727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2727r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2731(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2913(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2919(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2953(C_word c,C_word t0,C_word t1) C_noret;
static void f_3125(C_word c,C_word t0,C_word t1) C_noret;
static void f_3111(C_word c,C_word t0,C_word t1) C_noret;
static void f_3118(C_word c,C_word t0,C_word t1) C_noret;
static void f_3083(C_word c,C_word t0,C_word t1) C_noret;
static void f_2965(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2983(C_word c,C_word t0,C_word t1) C_noret;
static void f_3035(C_word c,C_word t0,C_word t1) C_noret;
static void f_3054(C_word c,C_word t0,C_word t1) C_noret;
static void f_3050(C_word c,C_word t0,C_word t1) C_noret;
static void f_3017(C_word c,C_word t0,C_word t1) C_noret;
static void f_3028(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2733(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void f_2815(C_word c,C_word t0,C_word t1) C_noret;
static void f_2905(C_word c,C_word t0,C_word t1) C_noret;
static void f_2893(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2826(C_word c,C_word t0,C_word t1) C_noret;
static void f_2891(C_word c,C_word t0,C_word t1) C_noret;
static void f_2883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2834(C_word c,C_word t0,C_word t1) C_noret;
static void f_2877(C_word c,C_word t0,C_word t1) C_noret;
static void f_2881(C_word c,C_word t0,C_word t1) C_noret;
static void f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2848(C_word c,C_word t0,C_word t1) C_noret;
static void f_2869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2867(C_word c,C_word t0,C_word t1) C_noret;
static void f_2863(C_word c,C_word t0,C_word t1) C_noret;
static void f_2859(C_word c,C_word t0,C_word t1) C_noret;
static void f_2842(C_word c,C_word t0,C_word t1) C_noret;
static void f_2838(C_word c,C_word t0,C_word t1) C_noret;
static void f_2830(C_word c,C_word t0,C_word t1) C_noret;
static void f_2822(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2745(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_2764(C_word t0,C_word t1) C_noret;
static void f_2775(C_word c,C_word t0,C_word t1) C_noret;
static void f_2783(C_word c,C_word t0,C_word t1) C_noret;
static void f_2771(C_word c,C_word t0,C_word t1) C_noret;
static void f_2208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_2230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
static void C_fcall f_2670(C_word t0,C_word t1) C_noret;
static void f_2608(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2589(C_word t0,C_word t1) C_noret;
static void C_fcall f_2543(C_word t0,C_word t1) C_noret;
static void C_fcall f_2546(C_word t0,C_word t1) C_noret;
static void f_2525(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2506(C_word t0,C_word t1) C_noret;
static void C_fcall f_2474(C_word t0,C_word t1) C_noret;
static void f_2453(C_word c,C_word t0,C_word t1) C_noret;
static void f_2244(C_word c,C_word t0,C_word t1) C_noret;
static void f_2446(C_word c,C_word t0,C_word t1) C_noret;
static void f_2389(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2442(C_word c,C_word t0,C_word t1) C_noret;
static void f_2430(C_word c,C_word t0,C_word t1) C_noret;
static void f_2426(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2416(C_word t0,C_word t1) C_noret;
static void f_2412(C_word c,C_word t0,C_word t1) C_noret;
static void f_2404(C_word c,C_word t0,C_word t1) C_noret;
static void f_2400(C_word c,C_word t0,C_word t1) C_noret;
static void f_2387(C_word c,C_word t0,C_word t1) C_noret;
static void f_2383(C_word c,C_word t0,C_word t1) C_noret;
static void f_2379(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2248(C_word t0,C_word t1) C_noret;
static void C_fcall f_2260(C_word t0,C_word t1) C_noret;
static void f_2339(C_word c,C_word t0,C_word t1) C_noret;
static void f_2335(C_word c,C_word t0,C_word t1) C_noret;
static void f_2331(C_word c,C_word t0,C_word t1) C_noret;
static void f_2327(C_word c,C_word t0,C_word t1) C_noret;
static void f_2323(C_word c,C_word t0,C_word t1) C_noret;
static void f_2316(C_word c,C_word t0,C_word t1) C_noret;
static void f_2312(C_word c,C_word t0,C_word t1) C_noret;
static void f_2308(C_word c,C_word t0,C_word t1) C_noret;
static void f_2304(C_word c,C_word t0,C_word t1) C_noret;
static void f_2283(C_word c,C_word t0,C_word t1) C_noret;
static void f_2291(C_word c,C_word t0,C_word t1) C_noret;
static void f_2271(C_word c,C_word t0,C_word t1) C_noret;
static void f_2267(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2251(C_word t0,C_word t1) C_noret;
static void C_fcall f_2211(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2165(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2171(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2190(C_word t0,C_word t1) C_noret;
static void f_2094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2098(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2103(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2130(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2156(C_word c,C_word t0,C_word t1) C_noret;
static void f_2124(C_word c,C_word t0,C_word t1) C_noret;
static void f_2077(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2077r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2041(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2041r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2050(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2056(C_word c,C_word t0,C_word t1) C_noret;
static void f_2035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2032(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2029(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1969(C_word t0,C_word t1) C_noret;
static void f_1975(C_word c,C_word t0,C_word t1) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1) C_noret;
static void f_1896(C_word c,C_word t0,C_word t1) C_noret;
static void f_1908(C_word c,C_word t0,C_word t1) C_noret;
static void f_1956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1950(C_word c,C_word t0,C_word t1) C_noret;
static void f_1946(C_word c,C_word t0,C_word t1) C_noret;
static void f_1942(C_word c,C_word t0,C_word t1) C_noret;
static void f_1930(C_word c,C_word t0,C_word t1) C_noret;
static void f_1922(C_word c,C_word t0,C_word t1) C_noret;
static void f_1918(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1808(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1828(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1836(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1850(C_word c,C_word t0,C_word t1) C_noret;
static void f_1822(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1671(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1784(C_word c,C_word t0,C_word t1) C_noret;
static void f_1796(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1796r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1802(C_word c,C_word t0,C_word t1) C_noret;
static void f_1790(C_word c,C_word t0,C_word t1) C_noret;
static void f_1677(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1683(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1694(C_word t0,C_word t1) C_noret;
static void C_fcall f_1711(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1730(C_word t0,C_word t1) C_noret;
static void f_1741(C_word c,C_word t0,C_word t1) C_noret;
static void f_1705(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1691(C_word t0,C_word t1) C_noret;
static void f_1669(C_word c,C_word t0,C_word t1) C_noret;
static void f_1650(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1642(C_word c,C_word t0,C_word t1) C_noret;
static void f_1616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1622(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

/* from CHICKEN_get_error_message */
 void  CHICKEN_get_error_message(char *t0,int t1){
C_word x, *a=C_alloc(0+3);
x=C_mpointer_or_false(&a,(void*)t0);
C_save(x);
x=C_fix((C_word)t1);
C_save(x);C_callback_wrapper((void *)f_9037,2);}

/* from CHICKEN_load */
 int  CHICKEN_load(char * t0){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0))));
x=C_mpointer(&a,(void*)t0);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9022,1));}

/* from CHICKEN_read */
 int  CHICKEN_read(char * t0,C_word *t1){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_9000,2));}

/* from CHICKEN_apply_to_string */
 int  CHICKEN_apply_to_string(C_word t0,C_word t1,char *t2,int t3){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
x=C_fix((C_word)t3);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8974,4));}

/* from CHICKEN_apply */
 int  CHICKEN_apply(C_word t0,C_word t1,C_word *t2){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=((C_word)t1);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8958,3));}

/* from CHICKEN_eval_string_to_string */
 int  CHICKEN_eval_string_to_string(char * t0,char *t1,int t2){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8921,3));}

/* from CHICKEN_eval_to_string */
 int  CHICKEN_eval_to_string(C_word t0,char *t1,int t2){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
x=C_fix((C_word)t2);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8895,3));}

/* from CHICKEN_eval_string */
 int  CHICKEN_eval_string(char * t0,C_word *t1){
C_word x, *a=C_alloc(0+2+(t0==NULL?1:C_bytestowords(C_strlen(t0)))+3);
x=C_mpointer(&a,(void*)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8856,2));}

/* from CHICKEN_eval */
 int  CHICKEN_eval(C_word t0,C_word *t1){
C_word x, *a=C_alloc(0+3);
x=((C_word)t0);
C_save(x);
x=C_mpointer_or_false(&a,(void*)t1);
C_save(x);
return C_truep(C_callback_wrapper((void *)f_8840,2));}

/* from CHICKEN_yield */
 int  CHICKEN_yield(){
C_word x, *a=C_alloc(0);
return C_truep(C_callback_wrapper((void *)f_8828,0));}

static void C_fcall trf_10439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10439(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10439(t0,t1);}

static void C_fcall trf_10407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10407(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10407(t0,t1);}

static void C_fcall trf_6381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6381(t0,t1);}

static void C_fcall trf_10374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10374(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10374(t0,t1);}

static void C_fcall trf_6385(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6385(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6385(t0,t1);}

static void C_fcall trf_6392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6392(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6392(t0,t1);}

static void C_fcall trf_10279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10279(t0,t1,t2);}

static void C_fcall trf_10181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10181(t0,t1);}

static void C_fcall trf_10080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10080(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10080(t0,t1,t2);}

static void C_fcall trf_9868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9868(t0,t1,t2);}

static void C_fcall trf_9782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9782(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9782(t0,t1,t2);}

static void C_fcall trf_9724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9724(t0,t1,t2);}

static void C_fcall trf_9435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9435(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9435(t0,t1,t2);}

static void C_fcall trf_9238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9238(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9238(t0,t1,t2,t3);}

static void C_fcall trf_9228(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9228(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9228(t0,t1,t2,t3);}

static void C_fcall trf_9090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9090(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9090(t0,t1,t2);}

static void C_fcall trf_9094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9094(t0,t1);}

static void C_fcall trf_9105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9105(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9105(t0,t1);}

static void C_fcall trf_8819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8819(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8819(t0,t1,t2);}

static void C_fcall trf_8760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8760(t0,t1);}

static void C_fcall trf_8732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8732(t0,t1);}

static void C_fcall trf_8701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8701(t0,t1);}

static void C_fcall trf_8638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8638(t0,t1);}

static void C_fcall trf_8625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8625(t0,t1);}

static void C_fcall trf_8512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8512(t0,t1);}

static void C_fcall trf_8482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8482(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8482(t0,t1);}

static void C_fcall trf_8417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8417(t0,t1,t2);}

static void C_fcall trf_8427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8427(t0,t1);}

static void C_fcall trf_8411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8411(t0,t1,t2);}

static void C_fcall trf_8073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8073(t0,t1);}

static void C_fcall trf_8078(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8078(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8078(t0,t1,t2,t3);}

static void C_fcall trf_8094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8094(t0,t1);}

static void C_fcall trf_8099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8099(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8099(t0,t1,t2,t3);}

static void C_fcall trf_7994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7994(t0,t1,t2);}

static void C_fcall trf_7939(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7939(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7939(t0,t1,t2,t3,t4);}

static void C_fcall trf_7951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7951(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7951(t0,t1,t2);}

static void C_fcall trf_7817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7817(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7817(t0,t1,t2,t3);}

static void C_fcall trf_7793(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7793(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7793(t0,t1,t2);}

static void C_fcall trf_7799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7799(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7799(t0,t1,t2);}

static void C_fcall trf_7729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7729(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7729(t0,t1,t2);}

static void C_fcall trf_7700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7700(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7700(t0,t1,t2);}

static void C_fcall trf_7665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7665(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7665(t0,t1,t2,t3);}

static void C_fcall trf_7640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7640(t0,t1);}

static void C_fcall trf_7613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7613(t0,t1);}

static void C_fcall trf_7459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7459(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7459(t0,t1,t2);}

static void C_fcall trf_7486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7486(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7486(t0,t1,t2);}

static void C_fcall trf_7396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7396(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7396(t0,t1,t2);}

static void C_fcall trf_7416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7416(t0,t1);}

static void C_fcall trf_7216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7216(t0,t1);}

static void C_fcall trf_7253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7253(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7253(t0,t1,t2,t3,t4);}

static void C_fcall trf_7030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7030(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7030(t0,t1,t2);}

static void C_fcall trf_7161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7161(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7161(t0,t1);}

static void C_fcall trf_7119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7119(t0,t1);}

static void C_fcall trf_7098(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7098(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7098(t0,t1);}

static void C_fcall trf_7055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7055(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7055(t0,t1);}

static void C_fcall trf_7009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7009(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7009(t0,t1,t2);}

static void C_fcall trf_6963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6963(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6963(t0,t1,t2);}

static void C_fcall trf_6980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6980(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6980(t0,t1);}

static void C_fcall trf_6776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6776(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6776(t0,t1,t2);}

static void C_fcall trf_6743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6743(t0,t1,t2);}

static void C_fcall trf_6682(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6682(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6682(t0,t1,t2);}

static void C_fcall trf_6604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6604(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6604(t0,t1,t2);}

static void C_fcall trf_6592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6592(t0,t1);}

static void C_fcall trf_6542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6542(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6542(t0,t1,t2,t3,t4);}

static void C_fcall trf_6411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6411(t0,t1);}

static void C_fcall trf_6422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6422(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6422(t0,t1,t2);}

static void C_fcall trf_6438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6438(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6438(t0,t1);}

static void C_fcall trf_6246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6246(t0,t1);}

static void C_fcall trf_6241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6241(t0,t1,t2);}

static void C_fcall trf_5918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5918(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5918(t0,t1,t2,t3);}

static void C_fcall trf_5922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5922(t0,t1);}

static void C_fcall trf_6192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6192(t0,t1);}

static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5990(t0,t1,t2);}

static void C_fcall trf_5807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5807(t0,t1,t2);}

static void C_fcall trf_5720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5720(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5720(t0,t1,t2,t3,t4);}

static void C_fcall trf_5710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5710(t0,t1);}

static void C_fcall trf_5476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5476(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5476(t0,t1,t2,t3,t4);}

static void C_fcall trf_3805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3805(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3805(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_3940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3940(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3940(t0,t1);}

static void C_fcall trf_5286(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5286(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5286(t0,t1);}

static void C_fcall trf_5133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5133(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5133(t0,t1,t2);}

static void C_fcall trf_5417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5417(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5417(t0,t1,t2,t3,t4);}

static void C_fcall trf_4611(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4611(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4611(t0,t1,t2,t3);}

static void C_fcall trf_3766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3766(t0,t1,t2,t3);}

static void C_fcall trf_3713(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3713(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3713(t0,t1,t2,t3,t4);}

static void C_fcall trf_3732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3732(t0,t1);}

static void C_fcall trf_3741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3741(t0,t1);}

static void C_fcall trf_3601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3601(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3601(t0,t1,t2,t3);}

static void C_fcall trf_3559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3559(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3559(t0,t1,t2);}

static void C_fcall trf_3565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3565(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3565(t0,t1,t2,t3);}

static void C_fcall trf_3505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3505(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3505(t0,t1,t2);}

static void C_fcall trf_3453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3453(t0,t1,t2);}

static void C_fcall trf_3404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3404(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3404(t0,t1,t2);}

static void C_fcall trf_3275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3275(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3275(t0,t1,t2,t3);}

static void C_fcall trf_3184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3184(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3184(t0,t1,t2,t3);}

static void C_fcall trf_2913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2913(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2913(t0,t1,t2);}

static void C_fcall trf_2919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2919(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2919(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2970(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2970(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2970(t0,t1,t2);}

static void C_fcall trf_2733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2733(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2733(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2745(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2745(t0,t1,t2,t3);}

static void C_fcall trf_2764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2764(t0,t1);}

static void C_fcall trf_2230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2230(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2230(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall trf_2670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2670(t0,t1);}

static void C_fcall trf_2589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2589(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2589(t0,t1);}

static void C_fcall trf_2543(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2543(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2543(t0,t1);}

static void C_fcall trf_2546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2546(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2546(t0,t1);}

static void C_fcall trf_2506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2506(t0,t1);}

static void C_fcall trf_2474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2474(t0,t1);}

static void C_fcall trf_2416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2416(t0,t1);}

static void C_fcall trf_2248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2248(t0,t1);}

static void C_fcall trf_2260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2260(t0,t1);}

static void C_fcall trf_2251(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2251(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2251(t0,t1);}

static void C_fcall trf_2211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2211(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2211(t0,t1,t2);}

static void C_fcall trf_2171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2171(t0,t1,t2);}

static void C_fcall trf_2190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2190(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2190(t0,t1);}

static void C_fcall trf_2103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2103(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2103(t0,t1,t2);}

static void C_fcall trf_2130(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2130(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2130(t0,t1,t2);}

static void C_fcall trf_2050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2050(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2050(t0,t1,t2);}

static void C_fcall trf_1659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1659(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1659(t0,t1,t2,t3);}

static void C_fcall trf_1969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1969(t0,t1);}

static void C_fcall trf_1808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1808(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1808(t0,t1,t2,t3);}

static void C_fcall trf_1836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1836(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1836(t0,t1,t2);}

static void C_fcall trf_1662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1662(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1662(t0,t1,t2,t3,t4);}

static void C_fcall trf_1694(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1694(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1694(t0,t1);}

static void C_fcall trf_1711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1711(t0,t1,t2);}

static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1730(t0,t1);}

static void C_fcall trf_1691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1691(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr6r(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6r(C_proc6 k){
int n;
C_word *a,t6;
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
n=C_rest_count(0);
a=C_alloc(n*3);
t6=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6);}

static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_eval_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_eval_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("eval_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6947)){
C_save(t1);
C_rereclaim2(6947*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,865);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
lf[3]=C_static_string(C_heaptop,32,"(c)2000-2005 Felix L. Winkelmann");
tmp=C_static_string(C_heaptop,10,"libchicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[5]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"cygchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[7]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,12,"libchicken-0");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[9]=C_h_pair(C_restore,tmp);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[11]=C_h_pair(C_restore,tmp);
lf[13]=C_static_string(C_heaptop,6,".dylib");
lf[15]=C_static_string(C_heaptop,4,".dll");
lf[17]=C_static_string(C_heaptop,3,".sl");
lf[19]=C_static_string(C_heaptop,3,".so");
lf[21]=C_static_string(C_heaptop,4,".scm");
lf[23]=C_static_string(C_heaptop,6,".setup");
lf[25]=C_static_string(C_heaptop,18,"CHICKEN_REPOSITORY");
lf[27]=C_static_string(C_heaptop,12,"CHICKEN_HOME");
lf[29]=C_static_string(C_heaptop,10,"repository");
tmp=C_intern(C_heaptop,6,"extras");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"lolevel");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"tinyclos");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"utils");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tcp");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"regex");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"posix");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-1");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-4");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-14");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-18");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-13");
C_save(tmp);
lf[31]=C_h_list(13,C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(13);
tmp=C_intern(C_heaptop,5,"match");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"match-support");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[33]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,20,"chicken-match-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"chicken-ffi-macros");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"chicken-more-macros");
C_save(tmp);
lf[35]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-23");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-30");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-39");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-10");
C_save(tmp);
lf[37]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
tmp=C_intern(C_heaptop,7,"srfi-16");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-26");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"srfi-55");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"srfi-9");
C_save(tmp);
lf[39]=C_h_list(4,C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(4);
tmp=C_static_string(C_heaptop,7,"chicken");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csc");
C_save(tmp);
tmp=C_static_string(C_heaptop,3,"csi");
C_save(tmp);
tmp=C_static_string(C_heaptop,13,"chicken-setup");
C_save(tmp);
tmp=C_static_string(C_heaptop,15,"chicken-profile");
C_save(tmp);
lf[41]=C_h_list(5,C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(5);
lf[43]=C_h_intern(&lf[43],28,"pathname-directory-separator");
lf[45]=C_h_intern(&lf[45],21,"\003sysmacro-environment");
lf[46]=C_h_intern(&lf[46],20,"\003sysregister-macro-2");
lf[47]=C_static_lambda_info(C_heaptop,14,"(a1605 form44)");
lf[48]=C_h_intern(&lf[48],19,"\003syshash-table-set!");
lf[49]=C_static_lambda_info(C_heaptop,41,"(##sys#register-macro-2 name42 handler43)");
lf[50]=C_h_intern(&lf[50],18,"\003sysregister-macro");
lf[51]=C_static_lambda_info(C_heaptop,14,"(a1621 form47)");
lf[52]=C_static_lambda_info(C_heaptop,39,"(##sys#register-macro name45 handler46)");
lf[53]=C_h_intern(&lf[53],6,"macro\077");
lf[54]=C_h_intern(&lf[54],18,"\003syshash-table-ref");
lf[55]=C_static_lambda_info(C_heaptop,14,"(macro\077 sym48)");
lf[56]=C_h_intern(&lf[56],15,"undefine-macro!");
lf[57]=C_static_lambda_info(C_heaptop,24,"(undefine-macro! name51)");
lf[58]=C_h_intern(&lf[58],13,"string-append");
lf[60]=C_h_intern(&lf[60],9,"\003sysabort");
lf[61]=C_h_intern(&lf[61],9,"condition");
lf[62]=C_h_intern(&lf[62],7,"message");
lf[63]=C_static_string(C_heaptop,21,"during expansion of (");
lf[64]=C_static_string(C_heaptop,8," ...) - ");
lf[65]=C_static_lambda_info(C_heaptop,11,"(copy ps66)");
lf[66]=C_h_intern(&lf[66],3,"exn");
lf[67]=C_static_lambda_info(C_heaptop,7,"(a1682)");
lf[68]=C_static_lambda_info(C_heaptop,12,"(a1676 ex64)");
lf[69]=C_static_lambda_info(C_heaptop,7,"(a1789)");
lf[70]=C_static_lambda_info(C_heaptop,7,"(a1801)");
lf[71]=C_static_lambda_info(C_heaptop,15,"(a1795 . g6270)");
lf[72]=C_static_lambda_info(C_heaptop,7,"(a1783)");
lf[73]=C_h_intern(&lf[73],22,"with-exception-handler");
lf[74]=C_static_lambda_info(C_heaptop,13,"(a1670 g6163)");
lf[75]=C_h_intern(&lf[75],30,"call-with-current-continuation");
lf[76]=C_static_lambda_info(C_heaptop,37,"(call-handler name58 handler59 exp60)");
lf[77]=C_h_intern(&lf[77],21,"\003syssyntax-error-hook");
lf[78]=C_static_string(C_heaptop,28,"invalid syntax in macro form");
lf[79]=C_static_lambda_info(C_heaptop,10,"(scan x80)");
lf[80]=C_static_lambda_info(C_heaptop,21,"(expand exp71 head72)");
lf[81]=C_h_intern(&lf[81],3,"let");
lf[82]=C_h_intern(&lf[82],8,"\003syscons");
lf[83]=C_h_intern(&lf[83],8,"\004coreapp");
lf[84]=C_h_intern(&lf[84],6,"letrec");
lf[85]=C_h_intern(&lf[85],7,"\003sysmap");
lf[86]=C_h_intern(&lf[86],4,"cadr");
lf[87]=C_h_intern(&lf[87],16,"\004coreloop-lambda");
lf[88]=C_static_lambda_info(C_heaptop,11,"(a1955 b86)");
lf[89]=C_h_intern(&lf[89],16,"\003syscheck-syntax");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[90]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(2);
C_save(tmp);
lf[91]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[92]=C_h_intern(&lf[92],10,"\003syssetter");
lf[93]=C_h_intern(&lf[93],6,"append");
lf[94]=C_h_intern(&lf[94],4,"set!");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[95]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[96]=C_h_intern(&lf[96],9,"\004coreset!");
lf[97]=C_static_lambda_info(C_heaptop,32,"(##sys#macroexpand-0 exp54 me55)");
lf[98]=C_h_intern(&lf[98],38,"\003syscompiler-toplevel-macroexpand-hook");
lf[99]=C_static_lambda_info(C_heaptop,48,"(##sys#compiler-toplevel-macroexpand-hook exp93)");
lf[100]=C_h_intern(&lf[100],41,"\003sysinterpreter-toplevel-macroexpand-hook");
lf[101]=C_static_lambda_info(C_heaptop,51,"(##sys#interpreter-toplevel-macroexpand-hook exp94)");
lf[102]=C_h_intern(&lf[102],23,"\003sysmacroexpand-1-local");
lf[103]=C_static_lambda_info(C_heaptop,38,"(##sys#macroexpand-1-local exp95 me96)");
lf[104]=C_h_intern(&lf[104],11,"macroexpand");
lf[105]=C_static_lambda_info(C_heaptop,7,"(a2055)");
lf[106]=C_static_lambda_info(C_heaptop,26,"(a2061 exp2102104 m103105)");
lf[107]=C_static_lambda_info(C_heaptop,13,"(loop exp101)");
lf[108]=C_static_lambda_info(C_heaptop,26,"(macroexpand exp97 . me98)");
lf[109]=C_h_intern(&lf[109],13,"macroexpand-1");
lf[110]=C_static_lambda_info(C_heaptop,30,"(macroexpand-1 exp109 . me110)");
lf[111]=C_h_intern(&lf[111],25,"\003sysenable-runtime-macros");
lf[112]=C_h_intern(&lf[112],32,"\003sysundefine-non-standard-macros");
lf[113]=C_static_lambda_info(C_heaptop,12,"(loop bs117)");
lf[114]=C_static_lambda_info(C_heaptop,12,"(do113 i115)");
lf[115]=C_h_intern(&lf[115],10,"\003sysappend");
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"and");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"or");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cond");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"case");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"let*");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"letrec");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"do");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"quasiquote");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"delay");
C_save(tmp);
lf[116]=C_h_list(10,C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(10);
lf[117]=C_static_lambda_info(C_heaptop,45,"(##sys#undefine-non-standard-macros leave111)");
lf[118]=C_h_intern(&lf[118],25,"\003sysextended-lambda-list\077");
lf[119]=C_h_intern(&lf[119],6,"#!rest");
lf[120]=C_h_intern(&lf[120],10,"#!optional");
lf[121]=C_h_intern(&lf[121],5,"#!key");
lf[122]=C_static_lambda_info(C_heaptop,15,"(loop llist125)");
lf[123]=C_static_lambda_info(C_heaptop,38,"(##sys#extended-lambda-list\077 llist123)");
lf[124]=C_h_intern(&lf[124],7,"reverse");
lf[125]=C_h_intern(&lf[125],6,"gensym");
lf[126]=C_h_intern(&lf[126],31,"\003sysexpand-extended-lambda-list");
lf[127]=C_static_lambda_info(C_heaptop,12,"(err msg140)");
lf[128]=C_h_intern(&lf[128],9,":optional");
lf[129]=C_h_intern(&lf[129],5,"cadar");
lf[130]=C_h_intern(&lf[130],4,"caar");
lf[131]=C_h_intern(&lf[131],13,"let-optionals");
lf[132]=C_h_intern(&lf[132],14,"let-optionals*");
lf[133]=C_h_intern(&lf[133],4,"let*");
lf[134]=C_h_intern(&lf[134],15,"\003sysget-keyword");
lf[135]=C_h_intern(&lf[135],5,"quote");
lf[136]=C_h_intern(&lf[136],6,"lambda");
lf[137]=C_h_intern(&lf[137],15,"string->keyword");
lf[138]=C_static_lambda_info(C_heaptop,12,"(a2388 k151)");
lf[139]=C_static_string(C_heaptop,43,"rest argument list specified more than once");
lf[140]=C_static_string(C_heaptop,45,"`#!optional\047 argument marker in wrong context");
lf[141]=C_static_string(C_heaptop,35,"invalid syntax of `#!rest\047 argument");
lf[142]=C_static_string(C_heaptop,41,"`#!rest\047 argument marker in wrong context");
lf[143]=C_static_string(C_heaptop,40,"`#!key\047 argument marker in wrong context");
lf[144]=C_static_string(C_heaptop,48,"invalid lambda list syntax after `#!rest\047 marker");
lf[145]=C_static_string(C_heaptop,32,"invalid required argument syntax");
lf[146]=C_static_string(C_heaptop,48,"invalid lambda list syntax after `#!rest\047 marker");
lf[147]=C_static_string(C_heaptop,26,"invalid lambda list syntax");
lf[148]=C_static_string(C_heaptop,26,"invalid lambda list syntax");
lf[149]=C_static_lambda_info(C_heaptop,44,"(loop mode145 req146 opt147 key148 llist149)");
lf[150]=C_static_lambda_info(C_heaptop,61,"(##sys#expand-extended-lambda-list llist0135 body136 errh137)");
lf[151]=C_h_intern(&lf[151],3,"map");
lf[152]=C_h_intern(&lf[152],21,"\003syscanonicalize-body");
lf[153]=C_h_intern(&lf[153],5,"begin");
lf[154]=C_h_intern(&lf[154],6,"define");
lf[155]=C_h_intern(&lf[155],13,"define-values");
lf[156]=C_static_lambda_info(C_heaptop,23,"(loop body2189 exps190)");
lf[157]=C_h_intern(&lf[157],20,"\003syscall-with-values");
lf[158]=C_static_lambda_info(C_heaptop,17,"(a2868 v200 t201)");
lf[159]=C_static_lambda_info(C_heaptop,18,"(a2843 vs197 x198)");
lf[160]=C_static_lambda_info(C_heaptop,17,"(a2882 v195 x196)");
lf[161]=C_h_intern(&lf[161],14,"\004coreundefined");
lf[162]=C_static_lambda_info(C_heaptop,12,"(a2892 v194)");
lf[163]=C_static_lambda_info(C_heaptop,48,"(fini vars183 vals184 mvars185 mvals186 body187)");
lf[164]=C_h_intern(&lf[164],25,"\003sysexpand-curried-define");
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[165]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[166]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[167]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[168]=C_h_pair(C_restore,tmp);
lf[169]=C_static_lambda_info(C_heaptop,12,"(loop2 x213)");
tmp=C_intern(C_heaptop,6,"define");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[170]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,13,"define-values");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[171]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[172]=C_h_pair(C_restore,tmp);
lf[173]=C_static_lambda_info(C_heaptop,48,"(loop body204 vars205 vals206 mvars207 mvals208)");
lf[174]=C_static_lambda_info(C_heaptop,16,"(expand body202)");
lf[175]=C_h_intern(&lf[175],9,"\003syserror");
lf[176]=C_static_lambda_info(C_heaptop,51,"(##sys#canonicalize-body body174 lookup175 . me176)");
lf[177]=C_h_intern(&lf[177],20,"\003sysmatch-expression");
lf[178]=C_static_lambda_info(C_heaptop,17,"(mwalk x231 p232)");
lf[179]=C_static_lambda_info(C_heaptop,46,"(##sys#match-expression exp226 pat227 vars228)");
lf[180]=C_static_lambda_info(C_heaptop,22,"(loop head246 body247)");
lf[181]=C_static_lambda_info(C_heaptop,45,"(##sys#expand-curried-define head242 body243)");
lf[182]=C_h_intern(&lf[182],15,"\003syshash-symbol");
lf[183]=C_static_lambda_info(C_heaptop,29,"(##sys#hash-symbol s253 n254)");
lf[184]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[185]=C_static_lambda_info(C_heaptop,35,"(##sys#hash-table-ref ht258 key259)");
lf[186]=C_static_lambda_info(C_heaptop,16,"(loop bucket271)");
lf[187]=C_static_lambda_info(C_heaptop,43,"(##sys#hash-table-set! ht265 key266 val267)");
lf[188]=C_h_intern(&lf[188],23,"\003syshash-table-for-each");
lf[189]=C_static_lambda_info(C_heaptop,17,"(a3471 bucket280)");
lf[190]=C_h_intern(&lf[190],12,"\003sysfor-each");
lf[191]=C_static_lambda_info(C_heaptop,12,"(do277 i279)");
lf[192]=C_static_lambda_info(C_heaptop,38,"(##sys#hash-table-for-each p274 ht275)");
lf[193]=C_h_intern(&lf[193],28,"\003sysarbitrary-unbound-symbol");
lf[194]=C_h_intern(&lf[194],23,"\003syshash-table-location");
lf[195]=C_static_lambda_info(C_heaptop,16,"(loop bucket290)");
lf[196]=C_static_lambda_info(C_heaptop,48,"(##sys#hash-table-location ht284 key285 addp286)");
lf[197]=C_h_intern(&lf[197],20,"\003syseval-environment");
lf[198]=C_h_intern(&lf[198],26,"\003sysenvironment-is-mutable");
lf[199]=C_h_intern(&lf[199],5,"write");
lf[200]=C_h_intern(&lf[200],6,"cadadr");
lf[201]=C_h_intern(&lf[201],20,"with-input-from-file");
lf[202]=C_h_intern(&lf[202],7,"display");
lf[203]=C_h_intern(&lf[203],22,"\003syscompile-to-closure");
lf[204]=C_static_lambda_info(C_heaptop,11,"(loop i343)");
lf[205]=C_static_lambda_info(C_heaptop,20,"(loop envs318 ei319)");
lf[206]=C_static_lambda_info(C_heaptop,20,"(lookup var315 e316)");
lf[207]=C_static_lambda_info(C_heaptop,7,"(a3606)");
lf[208]=C_static_lambda_info(C_heaptop,17,"(a3612 i326 j327)");
lf[209]=C_static_lambda_info(C_heaptop,22,"(defined\077 var324 e325)");
lf[210]=C_static_lambda_info(C_heaptop,39,"(macroexpand-1-checked x345 e346 me347)");
lf[211]=C_static_lambda_info(C_heaptop,12,"(a3771 x353)");
lf[212]=C_h_intern(&lf[212],20,"\003sysmake-lambda-info");
lf[213]=C_static_lambda_info(C_heaptop,7,"(a3798)");
lf[214]=C_h_intern(&lf[214],21,"with-output-to-string");
lf[215]=C_static_lambda_info(C_heaptop,17,"(a3784 p354 i355)");
lf[216]=C_h_intern(&lf[216],19,"\003sysdecorate-lambda");
lf[217]=C_static_lambda_info(C_heaptop,21,"(decorate p351 ll352)");
lf[218]=C_static_lambda_info(C_heaptop,7,"(a3816)");
lf[219]=C_static_lambda_info(C_heaptop,13,"(f_3865 v368)");
lf[220]=C_static_lambda_info(C_heaptop,13,"(f_3874 v369)");
lf[221]=C_static_string(C_heaptop,16,"unbound variable");
lf[222]=C_static_lambda_info(C_heaptop,15,"(f_3840 . v364)");
lf[223]=C_static_string(C_heaptop,33,"reference to undefined identifier");
lf[224]=C_static_lambda_info(C_heaptop,15,"(f_3857 . v367)");
lf[225]=C_static_lambda_info(C_heaptop,17,"(a3822 i361 j362)");
lf[226]=C_static_lambda_info(C_heaptop,15,"(f_3891 . v372)");
lf[227]=C_static_lambda_info(C_heaptop,15,"(f_3899 . v373)");
lf[228]=C_static_lambda_info(C_heaptop,15,"(f_3907 . v374)");
lf[229]=C_static_lambda_info(C_heaptop,15,"(f_3915 . v375)");
lf[230]=C_static_lambda_info(C_heaptop,15,"(f_3917 . v376)");
lf[231]=C_static_lambda_info(C_heaptop,15,"(f_3928 . v377)");
lf[232]=C_static_lambda_info(C_heaptop,15,"(f_3930 . v378)");
lf[233]=C_static_lambda_info(C_heaptop,15,"(f_3941 . v383)");
lf[234]=C_static_lambda_info(C_heaptop,15,"(f_3997 . v391)");
lf[235]=C_static_lambda_info(C_heaptop,15,"(f_4005 . v392)");
lf[236]=C_static_lambda_info(C_heaptop,15,"(f_4013 . v393)");
lf[237]=C_static_lambda_info(C_heaptop,15,"(f_4021 . v394)");
lf[238]=C_static_lambda_info(C_heaptop,15,"(f_4029 . v395)");
lf[239]=C_static_lambda_info(C_heaptop,15,"(f_4037 . v396)");
lf[240]=C_static_lambda_info(C_heaptop,15,"(f_4045 . v397)");
lf[241]=C_static_lambda_info(C_heaptop,15,"(f_4047 . v398)");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[242]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[243]=C_h_intern(&lf[243],15,"\004coreglobal-ref");
lf[244]=C_static_lambda_info(C_heaptop,15,"(f_4064 . v402)");
lf[245]=C_static_lambda_info(C_heaptop,15,"(f_4069 . v403)");
lf[246]=C_h_intern(&lf[246],10,"\004corecheck");
lf[247]=C_h_intern(&lf[247],14,"\004coreimmutable");
lf[248]=C_static_lambda_info(C_heaptop,13,"(f_4103 v404)");
lf[249]=C_h_intern(&lf[249],2,"if");
lf[250]=C_static_lambda_info(C_heaptop,13,"(f_4123 v408)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[251]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,2,"if");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
lf[252]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[253]=C_h_pair(C_restore,tmp);
lf[254]=C_static_lambda_info(C_heaptop,13,"(f_4211 v416)");
lf[255]=C_static_lambda_info(C_heaptop,13,"(f_4236 v421)");
tmp=C_intern(C_heaptop,5,"begin");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[256]=C_h_pair(C_restore,tmp);
lf[257]=C_static_lambda_info(C_heaptop,7,"(a4285)");
lf[258]=C_static_lambda_info(C_heaptop,13,"(f_4350 v436)");
lf[259]=C_static_lambda_info(C_heaptop,13,"(f_4363 v437)");
lf[260]=C_static_lambda_info(C_heaptop,13,"(f_4318 v432)");
lf[261]=C_static_string(C_heaptop,32,"assignment to immutable variable");
lf[262]=C_static_lambda_info(C_heaptop,15,"(f_4327 . v433)");
lf[263]=C_static_string(C_heaptop,34,"assignment of undefined identifier");
lf[264]=C_static_lambda_info(C_heaptop,13,"(f_4335 v435)");
lf[265]=C_static_lambda_info(C_heaptop,17,"(a4291 i428 j429)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
lf[266]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[267]=C_static_lambda_info(C_heaptop,13,"(f_4409 v450)");
lf[268]=C_static_lambda_info(C_heaptop,13,"(f_4442 v453)");
lf[269]=C_static_lambda_info(C_heaptop,13,"(f_4489 v458)");
lf[270]=C_static_lambda_info(C_heaptop,13,"(f_4547 v464)");
lf[271]=C_static_lambda_info(C_heaptop,21,"(do469 i471 vlist472)");
lf[272]=C_h_intern(&lf[272],15,"\003sysmake-vector");
lf[273]=C_static_lambda_info(C_heaptop,13,"(f_4595 v467)");
lf[274]=C_static_lambda_info(C_heaptop,12,"(a4640 x466)");
lf[275]=C_static_lambda_info(C_heaptop,15,"(a4658 g445446)");
lf[276]=C_static_lambda_info(C_heaptop,12,"(a4664 x442)");
tmp=C_intern(C_heaptop,3,"let");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"variable");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[277]=C_h_pair(C_restore,tmp);
lf[278]=C_h_intern(&lf[278],1,"\077");
lf[279]=C_static_lambda_info(C_heaptop,14,"(a4717 . r497)");
lf[280]=C_static_lambda_info(C_heaptop,13,"(f_4712 v496)");
lf[281]=C_static_lambda_info(C_heaptop,7,"(a4736)");
lf[282]=C_static_lambda_info(C_heaptop,13,"(f_4731 v498)");
lf[283]=C_static_lambda_info(C_heaptop,20,"(a4760 a1500 . r501)");
lf[284]=C_static_lambda_info(C_heaptop,13,"(f_4755 v499)");
lf[285]=C_static_lambda_info(C_heaptop,13,"(a4779 a1503)");
lf[286]=C_static_lambda_info(C_heaptop,13,"(f_4774 v502)");
lf[287]=C_static_lambda_info(C_heaptop,26,"(a4807 a1505 a2506 . r507)");
lf[288]=C_static_lambda_info(C_heaptop,13,"(f_4802 v504)");
lf[289]=C_static_lambda_info(C_heaptop,19,"(a4826 a1509 a2510)");
lf[290]=C_static_lambda_info(C_heaptop,13,"(f_4821 v508)");
lf[291]=C_static_lambda_info(C_heaptop,32,"(a4854 a1512 a2513 a3514 . r515)");
lf[292]=C_static_lambda_info(C_heaptop,13,"(f_4849 v511)");
lf[293]=C_static_lambda_info(C_heaptop,25,"(a4873 a1517 a2518 a3519)");
lf[294]=C_static_lambda_info(C_heaptop,13,"(f_4868 v516)");
lf[295]=C_static_lambda_info(C_heaptop,38,"(a4901 a1521 a2522 a3523 a4524 . r525)");
lf[296]=C_static_lambda_info(C_heaptop,13,"(f_4896 v520)");
lf[297]=C_h_intern(&lf[297],10,"\003sysvector");
lf[298]=C_static_lambda_info(C_heaptop,31,"(a4920 a1527 a2528 a3529 a4530)");
lf[299]=C_static_lambda_info(C_heaptop,13,"(f_4915 v526)");
lf[300]=C_static_lambda_info(C_heaptop,28,"(do581 n583 args584 last585)");
lf[301]=C_static_lambda_info(C_heaptop,15,"(a4942 . as532)");
lf[302]=C_static_lambda_info(C_heaptop,13,"(f_4937 v531)");
lf[303]=C_static_string(C_heaptop,18,"bad argument count");
lf[304]=C_static_lambda_info(C_heaptop,15,"(a4965 . as534)");
lf[305]=C_static_lambda_info(C_heaptop,13,"(f_4960 v533)");
lf[306]=C_static_lambda_info(C_heaptop,15,"(a4999 g492493)");
lf[307]=C_static_lambda_info(C_heaptop,31,"(a4694 vars487 argc488 rest489)");
lf[308]=C_h_intern(&lf[308],25,"\003sysdecompose-lambda-list");
lf[309]=C_static_lambda_info(C_heaptop,7,"(a5011)");
lf[310]=C_static_lambda_info(C_heaptop,30,"(a5017 llist482484 body483485)");
tmp=C_intern(C_heaptop,6,"lambda");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
tmp=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_h_pair(C_restore,tmp);
lf[311]=C_h_pair(C_restore,tmp);
lf[312]=C_h_intern(&lf[312],17,"\004corenamed-lambda");
lf[313]=C_h_intern(&lf[313],23,"\004corerequire-for-syntax");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[314]=C_h_pair(C_restore,tmp);
lf[315]=C_h_intern(&lf[315],11,"\003sysrequire");
lf[316]=C_static_lambda_info(C_heaptop,12,"(a5096 x541)");
lf[317]=C_h_intern(&lf[317],31,"\003syslookup-runtime-requirements");
lf[318]=C_static_lambda_info(C_heaptop,12,"(a5102 x539)");
lf[319]=C_h_intern(&lf[319],22,"\004corerequire-extension");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[320]=C_h_pair(C_restore,tmp);
lf[321]=C_h_intern(&lf[321],22,"\003sysdo-the-right-thing");
lf[322]=C_static_lambda_info(C_heaptop,7,"(a5144)");
lf[323]=C_static_lambda_info(C_heaptop,25,"(a5154 exp545547 _546548)");
lf[324]=C_static_lambda_info(C_heaptop,13,"(loop ids544)");
lf[325]=C_h_intern(&lf[325],24,"\004coreelaborationtimeonly");
lf[326]=C_h_intern(&lf[326],23,"\004coreelaborationtimetoo");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[327]=C_h_pair(C_restore,tmp);
lf[328]=C_h_intern(&lf[328],19,"\004corecompiletimetoo");
lf[329]=C_h_intern(&lf[329],20,"\004corecompiletimeonly");
lf[330]=C_h_intern(&lf[330],13,"\004corecallunit");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[331]=C_h_pair(C_restore,tmp);
lf[332]=C_h_intern(&lf[332],12,"\004coredeclare");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[333]=C_h_pair(C_restore,tmp);
lf[334]=C_h_intern(&lf[334],10,"\000compiling");
lf[335]=C_h_intern(&lf[335],12,"\003sysfeatures");
lf[336]=C_h_intern(&lf[336],28,"\010compilerprocess-declaration");
lf[337]=C_static_lambda_info(C_heaptop,12,"(a5233 d557)");
lf[338]=C_h_intern(&lf[338],8,"\003syswarn");
lf[339]=C_static_string(C_heaptop,44,"declarations are ignored in interpreted code");
lf[340]=C_h_intern(&lf[340],18,"\004coredefine-inline");
lf[341]=C_h_intern(&lf[341],20,"\004coredefine-constant");
lf[342]=C_h_intern(&lf[342],14,"\004coreprimitive");
lf[343]=C_static_string(C_heaptop,38,"can not evaluate compiler-special-form");
lf[344]=C_h_intern(&lf[344],8,"location");
lf[345]=C_static_string(C_heaptop,38,"can not evaluate compiler-special-form");
lf[346]=C_h_intern(&lf[346],11,"\004coreinline");
lf[347]=C_h_intern(&lf[347],20,"\004coreinline_allocate");
lf[348]=C_h_intern(&lf[348],19,"\004coreforeign-lambda");
lf[349]=C_h_intern(&lf[349],28,"\004coredefine-foreign-variable");
lf[350]=C_h_intern(&lf[350],29,"\004coredefine-external-variable");
lf[351]=C_h_intern(&lf[351],17,"\004corelet-location");
lf[352]=C_h_intern(&lf[352],22,"\004coreforeign-primitive");
lf[353]=C_h_intern(&lf[353],20,"\004coreforeign-lambda*");
lf[354]=C_h_intern(&lf[354],24,"\004coredefine-foreign-type");
lf[355]=C_static_string(C_heaptop,25,"illegal non-atomic object");
lf[356]=C_h_intern(&lf[356],11,"\003sysnumber\077");
lf[357]=C_static_lambda_info(C_heaptop,30,"(compile x357 e358 h359 me360)");
lf[358]=C_static_lambda_info(C_heaptop,11,"(loop n591)");
lf[359]=C_static_string(C_heaptop,20,"malformed expression");
lf[360]=C_static_lambda_info(C_heaptop,13,"(f_5502 v601)");
lf[361]=C_static_lambda_info(C_heaptop,13,"(f_5519 v603)");
lf[362]=C_static_lambda_info(C_heaptop,13,"(f_5547 v606)");
lf[363]=C_static_lambda_info(C_heaptop,13,"(f_5582 v610)");
lf[364]=C_static_lambda_info(C_heaptop,13,"(f_5624 v615)");
lf[365]=C_static_lambda_info(C_heaptop,12,"(a5668 a619)");
lf[366]=C_static_lambda_info(C_heaptop,13,"(f_5655 v618)");
lf[367]=C_static_lambda_info(C_heaptop,12,"(a5674 a617)");
lf[368]=C_static_lambda_info(C_heaptop,30,"(compile-call x593 e594 me595)");
lf[369]=C_static_lambda_info(C_heaptop,46,"(##sys#compile-to-closure exp302 env303 me304)");
lf[370]=C_h_intern(&lf[370],16,"\003syseval-handler");
lf[371]=C_h_intern(&lf[371],12,"eval-handler");
lf[372]=C_h_intern(&lf[372],4,"eval");
lf[373]=C_static_lambda_info(C_heaptop,20,"(eval x652 . env653)");
lf[374]=C_h_intern(&lf[374],24,"\003syssyntax-error-culprit");
lf[375]=C_static_string(C_heaptop,26,"illegal lambda-list syntax");
lf[376]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[377]=C_static_lambda_info(C_heaptop,31,"(loop llist660 vars661 argc662)");
lf[378]=C_static_lambda_info(C_heaptop,44,"(##sys#decompose-lambda-list llist0655 k656)");
lf[379]=C_h_intern(&lf[379],12,"load-verbose");
lf[380]=C_h_intern(&lf[380],14,"\003sysabort-load");
lf[381]=C_static_lambda_info(C_heaptop,8,"(f_5791)");
lf[382]=C_h_intern(&lf[382],21,"\003syscurrent-load-file");
lf[383]=C_h_intern(&lf[383],22,"set-dynamic-load-mode!");
lf[384]=C_h_intern(&lf[384],21,"\003sysset-dlopen-flags!");
lf[385]=C_h_intern(&lf[385],6,"global");
lf[386]=C_h_intern(&lf[386],5,"local");
lf[387]=C_h_intern(&lf[387],4,"lazy");
lf[388]=C_h_intern(&lf[388],3,"now");
lf[389]=C_h_intern(&lf[389],15,"\003syssignal-hook");
lf[390]=C_static_string(C_heaptop,25,"invalid dynamic-load mode");
lf[391]=C_static_lambda_info(C_heaptop,14,"(loop mode670)");
lf[392]=C_static_lambda_info(C_heaptop,32,"(set-dynamic-load-mode! mode665)");
lf[393]=C_h_intern(&lf[393],4,"read");
lf[394]=C_h_intern(&lf[394],7,"newline");
lf[395]=C_h_intern(&lf[395],15,"open-input-file");
lf[396]=C_h_intern(&lf[396],16,"close-input-port");
lf[397]=C_h_intern(&lf[397],8,"\003sysload");
lf[398]=C_static_lambda_info(C_heaptop,22,"(f_6159 x719 . env720)");
lf[399]=C_static_lambda_info(C_heaptop,8,"(f_5944)");
lf[400]=C_h_intern(&lf[400],31,"\003sysread-error-with-line-number");
lf[401]=C_static_lambda_info(C_heaptop,7,"(a5952)");
lf[402]=C_static_lambda_info(C_heaptop,7,"(a5970)");
lf[403]=C_static_lambda_info(C_heaptop,7,"(a6023)");
lf[404]=C_h_intern(&lf[404],17,"\003sysdisplay-times");
lf[405]=C_h_intern(&lf[405],14,"\003sysstop-timer");
lf[406]=C_static_lambda_info(C_heaptop,17,"(a6029 . t750751)");
lf[407]=C_h_intern(&lf[407],15,"\003sysstart-timer");
lf[408]=C_static_lambda_info(C_heaptop,7,"(a6011)");
lf[409]=C_static_lambda_info(C_heaptop,12,"(a6054 r755)");
lf[410]=C_static_lambda_info(C_heaptop,20,"(a6045 . results754)");
lf[411]=C_static_lambda_info(C_heaptop,12,"(do747 x749)");
lf[412]=C_h_intern(&lf[412],4,"load");
lf[413]=C_static_string(C_heaptop,30,"unable to load compiled module");
lf[414]=C_h_intern(&lf[414],17,"\003syspeek-c-string");
lf[415]=C_h_intern(&lf[415],9,"peek-char");
lf[416]=C_static_lambda_info(C_heaptop,7,"(a5973)");
lf[417]=C_static_lambda_info(C_heaptop,7,"(a6080)");
lf[418]=C_h_intern(&lf[418],16,"\003sysdynamic-wind");
lf[419]=C_static_lambda_info(C_heaptop,7,"(a5961)");
lf[420]=C_static_lambda_info(C_heaptop,7,"(a6089)");
lf[421]=C_static_lambda_info(C_heaptop,15,"(a5941 abrt727)");
lf[422]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[423]=C_h_intern(&lf[423],9,"\003sysdload");
lf[424]=C_h_intern(&lf[424],17,"\003sysmake-c-string");
lf[425]=C_static_string(C_heaptop,1,".");
lf[426]=C_h_intern(&lf[426],11,"\000file-error");
lf[427]=C_static_string(C_heaptop,17,"can not open file");
lf[428]=C_static_string(C_heaptop,5," ...\012");
lf[429]=C_static_string(C_heaptop,10,"; loading ");
lf[430]=C_h_intern(&lf[430],5,"isdir");
lf[431]=C_h_intern(&lf[431],13,"\003sysfile-info");
lf[432]=C_h_intern(&lf[432],17,"\003sysstring-append");
lf[433]=C_h_intern(&lf[433],26,"\003sysload-dynamic-extension");
lf[434]=C_h_intern(&lf[434],11,"\000type-error");
lf[435]=C_static_string(C_heaptop,40,"bad argument type - not a port or string");
lf[436]=C_h_intern(&lf[436],5,"port\077");
lf[437]=C_h_intern(&lf[437],20,"\003sysexpand-home-path");
lf[438]=C_static_lambda_info(C_heaptop,29,"(body701 timer707 printer708)");
lf[439]=C_static_lambda_info(C_heaptop,29,"(def-printer704 %timer699770)");
lf[440]=C_static_lambda_info(C_heaptop,14,"(def-timer703)");
lf[441]=C_static_lambda_info(C_heaptop,50,"(##sys#load input695 evaluator696 pf697 . g694698)");
lf[442]=C_h_intern(&lf[442],21,"\003syscurrent-namespace");
lf[443]=C_static_lambda_info(C_heaptop,7,"(a6299)");
lf[444]=C_static_lambda_info(C_heaptop,7,"(a6304)");
lf[445]=C_static_lambda_info(C_heaptop,7,"(a6333)");
lf[446]=C_static_lambda_info(C_heaptop,33,"(load filename776 . evaluator777)");
lf[447]=C_h_intern(&lf[447],12,"load-noisily");
lf[448]=C_static_lambda_info(C_heaptop,7,"(a6353)");
lf[449]=C_static_lambda_info(C_heaptop,7,"(a6358)");
lf[450]=C_static_lambda_info(C_heaptop,7,"(a6364)");
lf[451]=C_static_lambda_info(C_heaptop,7,"(a6369)");
lf[452]=C_h_intern(&lf[452],8,"\000printer");
lf[453]=C_static_lambda_info(C_heaptop,7,"(a6372)");
lf[454]=C_h_intern(&lf[454],5,"\000time");
lf[455]=C_static_lambda_info(C_heaptop,7,"(a6375)");
lf[456]=C_h_intern(&lf[456],10,"\000evaluator");
lf[457]=C_static_lambda_info(C_heaptop,36,"(load-noisily filename787 . g786788)");
lf[458]=C_h_intern(&lf[458],26,"\003sysload-library-extension");
lf[459]=C_h_intern(&lf[459],34,"\003sysdefault-dynamic-load-libraries");
lf[460]=C_h_intern(&lf[460],22,"dynamic-load-libraries");
lf[461]=C_h_intern(&lf[461],16,"\003sysload-library");
lf[462]=C_static_lambda_info(C_heaptop,14,"(loop libs824)");
lf[463]=C_static_string(C_heaptop,5," ...\012");
lf[464]=C_static_string(C_heaptop,18,"; loading library ");
lf[465]=C_static_string(C_heaptop,2,"C_");
lf[466]=C_static_string(C_heaptop,9,"_toplevel");
lf[467]=C_h_intern(&lf[467],24,"\003sysstring->c-identifier");
lf[468]=C_h_intern(&lf[468],16,"\003sys->feature-id");
lf[469]=C_static_lambda_info(C_heaptop,36,"(##sys#load-library uname814 lib815)");
lf[470]=C_h_intern(&lf[470],12,"load-library");
lf[471]=C_static_string(C_heaptop,22,"unable to load library");
lf[472]=C_static_lambda_info(C_heaptop,32,"(load-library uname828 . lib829)");
lf[474]=C_h_intern(&lf[474],13,"\003syssubstring");
lf[475]=C_static_lambda_info(C_heaptop,25,"(loop items838 i839 j840)");
lf[476]=C_static_lambda_info(C_heaptop,40,"(##sys#split-at-separator str834 sep835)");
lf[477]=C_h_intern(&lf[477],31,"\003syscanonicalize-extension-path");
lf[478]=C_static_string(C_heaptop,22,"invalid extension path");
lf[479]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[480]=C_static_lambda_info(C_heaptop,12,"(check p853)");
lf[481]=C_h_intern(&lf[481],18,"\003syssymbol->string");
lf[482]=C_static_string(C_heaptop,0,"");
lf[483]=C_static_string(C_heaptop,0,"");
lf[484]=C_static_lambda_info(C_heaptop,12,"(loop id849)");
lf[485]=C_static_lambda_info(C_heaptop,48,"(##sys#canonicalize-extension-path id844 loc845)");
lf[486]=C_h_intern(&lf[486],19,"\003sysrepository-path");
lf[487]=C_h_intern(&lf[487],15,"repository-path");
lf[488]=C_h_intern(&lf[488],12,"file-exists\077");
lf[489]=C_h_intern(&lf[489],18,"\003sysfind-extension");
lf[490]=C_static_lambda_info(C_heaptop,15,"(check path866)");
lf[491]=C_static_lambda_info(C_heaptop,15,"(loop paths871)");
lf[492]=C_h_intern(&lf[492],21,"\003sysinclude-pathnames");
tmp=C_static_string(C_heaptop,1,".");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[493]=C_h_pair(C_restore,tmp);
lf[494]=C_static_lambda_info(C_heaptop,35,"(##sys#find-extension p863 inc\077864)");
lf[495]=C_h_intern(&lf[495],21,"\003sysloaded-extensions");
lf[496]=C_h_intern(&lf[496],18,"\003sysload-extension");
lf[497]=C_static_string(C_heaptop,22,"can not load extension");
lf[498]=C_static_lambda_info(C_heaptop,45,"(##sys#load-extension id877 loc878 . err\077879)");
lf[499]=C_h_intern(&lf[499],11,"\003sysprovide");
lf[500]=C_h_intern(&lf[500],7,"provide");
lf[501]=C_static_lambda_info(C_heaptop,13,"(a6887 id890)");
lf[502]=C_static_lambda_info(C_heaptop,24,"(##sys#provide . ids889)");
lf[503]=C_h_intern(&lf[503],13,"\003sysprovided\077");
lf[504]=C_h_intern(&lf[504],9,"provided\077");
lf[505]=C_static_lambda_info(C_heaptop,23,"(##sys#provided\077 id893)");
lf[506]=C_h_intern(&lf[506],7,"require");
lf[507]=C_static_lambda_info(C_heaptop,15,"(a6921 g895896)");
lf[508]=C_static_lambda_info(C_heaptop,24,"(##sys#require . ids894)");
lf[509]=C_h_intern(&lf[509],18,"\003sysextension-info");
lf[510]=C_static_lambda_info(C_heaptop,35,"(##sys#extension-info id901 loc902)");
lf[511]=C_h_intern(&lf[511],14,"extension-info");
lf[512]=C_static_lambda_info(C_heaptop,23,"(extension-info ext905)");
lf[513]=C_h_intern(&lf[513],18,"require-at-runtime");
lf[514]=C_static_lambda_info(C_heaptop,14,"(loop1 ids910)");
lf[515]=C_static_lambda_info(C_heaptop,42,"(##sys#lookup-runtime-requirements ids908)");
lf[516]=C_h_intern(&lf[516],12,"vector->list");
lf[517]=C_h_intern(&lf[517],13,"test-feature\077");
lf[518]=C_h_intern(&lf[518],11,"lset-adjoin");
lf[519]=C_h_intern(&lf[519],3,"eq\077");
lf[520]=C_static_lambda_info(C_heaptop,15,"(a7017 g923924)");
lf[521]=C_static_lambda_info(C_heaptop,7,"(a7023)");
lf[522]=C_h_intern(&lf[522],18,"hash-table-update!");
lf[523]=C_h_intern(&lf[523],26,"\010compilerfile-requirements");
lf[524]=C_h_intern(&lf[524],19,"syntax-requirements");
lf[525]=C_static_lambda_info(C_heaptop,15,"(add-req id922)");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[526]=C_h_pair(C_restore,tmp);
lf[527]=C_h_intern(&lf[527],20,"chicken-match-macros");
lf[528]=C_h_intern(&lf[528],18,"chicken-ffi-macros");
lf[529]=C_h_intern(&lf[529],19,"chicken-more-macros");
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[530]=C_h_pair(C_restore,tmp);
lf[531]=C_h_intern(&lf[531],28,"\003sysresolve-include-filename");
lf[532]=C_h_intern(&lf[532],4,"uses");
lf[533]=C_h_intern(&lf[533],6,"syntax");
lf[534]=C_h_intern(&lf[534],17,"require-extension");
lf[535]=C_static_lambda_info(C_heaptop,12,"(doit id925)");
lf[536]=C_h_intern(&lf[536],24,"\003sysextension-specifiers");
lf[537]=C_static_lambda_info(C_heaptop,7,"(a7275)");
lf[538]=C_static_lambda_info(C_heaptop,26,"(a7285 exp945947 fi946948)");
lf[539]=C_static_lambda_info(C_heaptop,28,"(loop specs942 exps943 f944)");
lf[540]=C_static_string(C_heaptop,29,"undefined extension specifier");
lf[541]=C_static_string(C_heaptop,27,"invalid extension specifier");
lf[542]=C_static_lambda_info(C_heaptop,41,"(##sys#do-the-right-thing id918 comp\077919)");
lf[543]=C_h_intern(&lf[543],24,"set-extension-specifier!");
lf[544]=C_static_lambda_info(C_heaptop,15,"(a7357 spec960)");
lf[545]=C_static_lambda_info(C_heaptop,15,"(a7371 spec961)");
lf[546]=C_static_lambda_info(C_heaptop,42,"(set-extension-specifier! name956 proc957)");
lf[547]=C_h_intern(&lf[547],11,"string-copy");
lf[548]=C_static_lambda_info(C_heaptop,12,"(do986 i988)");
lf[549]=C_static_lambda_info(C_heaptop,35,"(##sys#string->c-identifier str983)");
lf[552]=C_h_intern(&lf[552],11,"environment");
lf[554]=C_h_intern(&lf[554],18,"\003syscopy-env-table");
lf[555]=C_static_lambda_info(C_heaptop,12,"(copy b1003)");
lf[556]=C_static_lambda_info(C_heaptop,13,"(do999 i1001)");
lf[557]=C_static_lambda_info(C_heaptop,40,"(##sys#copy-env-table e994 mff995 mf996)");
lf[558]=C_h_intern(&lf[558],23,"interaction-environment");
lf[559]=C_static_lambda_info(C_heaptop,25,"(interaction-environment)");
lf[560]=C_h_intern(&lf[560],25,"scheme-report-environment");
lf[561]=C_static_string(C_heaptop,22,"no support for version");
lf[562]=C_static_lambda_info(C_heaptop,47,"(scheme-report-environment n1008 . mutable1009)");
lf[563]=C_h_intern(&lf[563],11,"make-vector");
lf[564]=C_h_intern(&lf[564],16,"null-environment");
lf[565]=C_static_string(C_heaptop,22,"no support for version");
lf[566]=C_static_lambda_info(C_heaptop,38,"(null-environment n1015 . mutable1016)");
lf[567]=C_static_lambda_info(C_heaptop,14,"(f_7615 b1023)");
lf[568]=C_static_lambda_info(C_heaptop,14,"(initb ht1022)");
lf[569]=C_h_intern(&lf[569],6,"string");
lf[570]=C_static_lambda_info(C_heaptop,19,"(exists\077 fname1031)");
lf[571]=C_static_lambda_info(C_heaptop,25,"(test2 fname1043 lst1044)");
lf[572]=C_static_lambda_info(C_heaptop,16,"(test fname1046)");
lf[573]=C_static_lambda_info(C_heaptop,16,"(loop paths1049)");
lf[574]=C_static_lambda_info(C_heaptop,72,"(##sys#resolve-include-filename fname1034 prefer-source1035 . g10331036)");
lf[575]=C_static_lambda_info(C_heaptop,14,"(do1059 i1061)");
lf[576]=C_static_lambda_info(C_heaptop,14,"(spaces n1058)");
lf[577]=C_static_string(C_heaptop,1,"0");
lf[578]=C_static_lambda_info(C_heaptop,24,"(display-rj x1065 w1066)");
lf[579]=C_static_string(C_heaptop,11," major GCs\012");
lf[580]=C_static_string(C_heaptop,11," minor GCs\012");
lf[581]=C_static_string(C_heaptop,11," mutations\012");
lf[582]=C_static_string(C_heaptop,23," seconds in (major) GC\012");
lf[583]=C_static_string(C_heaptop,17," seconds elapsed\012");
lf[584]=C_static_lambda_info(C_heaptop,30,"(##sys#display-times info1070)");
lf[585]=C_h_intern(&lf[585],24,"\003sysline-number-database");
lf[586]=C_h_intern(&lf[586],13,"\000syntax-error");
lf[587]=C_static_lambda_info(C_heaptop,36,"(##sys#syntax-error-hook . args1080)");
lf[588]=C_h_intern(&lf[588],12,"syntax-error");
lf[589]=C_h_intern(&lf[589],15,"get-line-number");
lf[590]=C_static_lambda_info(C_heaptop,26,"(get-line-number sexp1081)");
lf[591]=C_h_intern(&lf[591],8,"keyword\077");
lf[592]=C_h_intern(&lf[592],14,"symbol->string");
lf[593]=C_static_string(C_heaptop,1,"(");
lf[594]=C_static_string(C_heaptop,10,") in line ");
lf[595]=C_static_string(C_heaptop,3," - ");
lf[596]=C_static_string(C_heaptop,1,"(");
lf[597]=C_static_string(C_heaptop,2,") ");
lf[598]=C_static_lambda_info(C_heaptop,13,"(err msg1102)");
lf[599]=C_static_lambda_info(C_heaptop,29,"(test x1099 pred1100 msg1101)");
lf[600]=C_static_lambda_info(C_heaptop,12,"(loop x1109)");
lf[601]=C_static_lambda_info(C_heaptop,20,"(lambda-list\077 x1105)");
lf[602]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[603]=C_static_lambda_info(C_heaptop,20,"(proper-list\077 x1116)");
lf[604]=C_static_string(C_heaptop,20,"not enough arguments");
lf[605]=C_static_string(C_heaptop,18,"too many arguments");
lf[606]=C_static_string(C_heaptop,17,"not a proper list");
lf[607]=C_static_lambda_info(C_heaptop,20,"(do1129 x1131 n1132)");
lf[608]=C_h_intern(&lf[608],1,"_");
lf[609]=C_h_intern(&lf[609],4,"pair");
lf[610]=C_h_intern(&lf[610],5,"pair\077");
lf[611]=C_static_string(C_heaptop,13,"pair expected");
lf[612]=C_h_intern(&lf[612],8,"variable");
lf[613]=C_static_lambda_info(C_heaptop,13,"(a8222 x1139)");
lf[614]=C_static_string(C_heaptop,19,"identifier expected");
lf[615]=C_h_intern(&lf[615],6,"symbol");
lf[616]=C_h_intern(&lf[616],7,"symbol\077");
lf[617]=C_static_string(C_heaptop,15,"symbol expected");
lf[618]=C_h_intern(&lf[618],4,"list");
lf[619]=C_static_string(C_heaptop,20,"proper list expected");
lf[620]=C_h_intern(&lf[620],6,"number");
lf[621]=C_h_intern(&lf[621],7,"number\077");
lf[622]=C_static_string(C_heaptop,15,"number expected");
lf[623]=C_h_intern(&lf[623],7,"string\077");
lf[624]=C_static_string(C_heaptop,15,"string expected");
lf[625]=C_h_intern(&lf[625],11,"lambda-list");
lf[626]=C_static_string(C_heaptop,20,"lambda-list expected");
lf[627]=C_static_lambda_info(C_heaptop,13,"(a8276 y1140)");
lf[628]=C_static_string(C_heaptop,15,"missing keyword");
lf[629]=C_static_string(C_heaptop,15,"incomplete form");
lf[630]=C_static_string(C_heaptop,17,"unexpected object");
lf[631]=C_static_lambda_info(C_heaptop,18,"(walk x1123 p1124)");
lf[632]=C_static_lambda_info(C_heaptop,57,"(##sys#check-syntax id1091 exp1092 pat1093 . culprit1094)");
lf[633]=C_h_intern(&lf[633],16,"\003systest-feature");
lf[634]=C_static_lambda_info(C_heaptop,26,"(##sys#test-feature f1248)");
lf[635]=C_h_intern(&lf[635],18,"\003sysrepl-eval-hook");
lf[636]=C_h_intern(&lf[636],27,"\003sysrepl-print-length-limit");
lf[637]=C_h_intern(&lf[637],18,"\003sysrepl-read-hook");
lf[638]=C_h_intern(&lf[638],11,"repl-prompt");
lf[639]=C_h_intern(&lf[639],20,"\003sysread-prompt-hook");
lf[640]=C_h_intern(&lf[640],16,"\003sysflush-output");
lf[641]=C_h_intern(&lf[641],19,"\003sysstandard-output");
lf[642]=C_static_lambda_info(C_heaptop,24,"(##sys#read-prompt-hook)");
lf[643]=C_h_intern(&lf[643],5,"reset");
lf[644]=C_h_intern(&lf[644],4,"repl");
lf[645]=C_h_intern(&lf[645],16,"\003syswrite-char-0");
lf[646]=C_static_lambda_info(C_heaptop,7,"(a8404)");
lf[647]=C_h_intern(&lf[647],27,"\003syswith-print-length-limit");
lf[648]=C_static_lambda_info(C_heaptop,17,"(write-one x1262)");
lf[649]=C_static_lambda_info(C_heaptop,18,"(write-err xs1264)");
lf[650]=C_static_lambda_info(C_heaptop,22,"(write-results xs1265)");
lf[651]=C_h_intern(&lf[651],18,"\003sysstandard-input");
lf[652]=C_h_intern(&lf[652],18,"\003sysstandard-error");
lf[653]=C_static_lambda_info(C_heaptop,11,"(saveports)");
lf[654]=C_static_lambda_info(C_heaptop,12,"(resetports)");
lf[655]=C_static_string(C_heaptop,2,": ");
lf[656]=C_static_string(C_heaptop,7,"Error: ");
lf[657]=C_static_lambda_info(C_heaptop,26,"(a8465 msg1279 . args1280)");
lf[658]=C_h_intern(&lf[658],17,"\003syserror-handler");
lf[659]=C_static_lambda_info(C_heaptop,7,"(a8459)");
lf[660]=C_static_lambda_info(C_heaptop,7,"(a8538)");
lf[661]=C_static_lambda_info(C_heaptop,20,"(a8547 . result1298)");
lf[662]=C_h_intern(&lf[662],15,"\003sysread-char-0");
lf[663]=C_h_intern(&lf[663],15,"\003syspeek-char-0");
lf[664]=C_h_intern(&lf[664],28,"\003sysdefault-namespace-prefix");
lf[665]=C_h_intern(&lf[665],21,"\003sysenable-qualifiers");
lf[666]=C_static_lambda_info(C_heaptop,7,"(a8575)");
lf[667]=C_h_intern(&lf[667],17,"\003sysreset-handler");
lf[668]=C_static_lambda_info(C_heaptop,13,"(a8569 c1287)");
lf[669]=C_static_lambda_info(C_heaptop,6,"(loop)");
lf[670]=C_static_lambda_info(C_heaptop,7,"(a8505)");
lf[671]=C_static_lambda_info(C_heaptop,7,"(a8588)");
lf[672]=C_static_lambda_info(C_heaptop,6,"(repl)");
lf[673]=C_h_intern(&lf[673],28,"\003syssharp-comma-reader-ctors");
lf[674]=C_h_intern(&lf[674],18,"define-reader-ctor");
lf[675]=C_static_lambda_info(C_heaptop,38,"(define-reader-ctor spec1311 proc1312)");
lf[676]=C_h_intern(&lf[676],18,"\003sysuser-read-hook");
lf[677]=C_h_intern(&lf[677],9,"read-char");
lf[678]=C_h_intern(&lf[678],14,"\003sysread-error");
lf[679]=C_static_string(C_heaptop,33,"invalid sharp-comma external form");
lf[680]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[681]=C_static_string(C_heaptop,33,"undefined sharp-comma constructor");
lf[682]=C_static_lambda_info(C_heaptop,40,"(##sys#user-read-hook char1317 port1318)");
lf[683]=C_h_intern(&lf[683],16,"set-read-syntax!");
lf[684]=C_static_lambda_info(C_heaptop,22,"(a8714 _1344 port1345)");
lf[685]=C_h_intern(&lf[685],29,"\003sysspecial-read-syntax-table");
lf[686]=C_h_intern(&lf[686],15,"\003syscheck-range");
lf[687]=C_static_lambda_info(C_heaptop,35,"(set-read-syntax! chr1341 proc1342)");
lf[688]=C_h_intern(&lf[688],25,"set-dispatch-read-syntax!");
lf[689]=C_static_lambda_info(C_heaptop,22,"(a8745 _1353 port1354)");
lf[690]=C_h_intern(&lf[690],38,"\003sysspecial-dispatch-read-syntax-table");
lf[691]=C_static_lambda_info(C_heaptop,44,"(set-dispatch-read-syntax! chr1350 proc1351)");
lf[694]=C_h_intern(&lf[694],17,"get-output-string");
lf[695]=C_h_intern(&lf[695],19,"print-error-message");
lf[696]=C_h_intern(&lf[696],18,"open-output-string");
lf[697]=C_static_lambda_info(C_heaptop,7,"(a8781)");
lf[698]=C_static_lambda_info(C_heaptop,14,"(a8775 ex1363)");
lf[699]=C_static_lambda_info(C_heaptop,7,"(a8800)");
lf[700]=C_static_lambda_info(C_heaptop,7,"(a8812)");
lf[701]=C_static_lambda_info(C_heaptop,19,"(a8806 . g13611367)");
lf[702]=C_static_lambda_info(C_heaptop,7,"(a8794)");
lf[703]=C_static_lambda_info(C_heaptop,17,"(a8769 g13601362)");
lf[704]=C_static_lambda_info(C_heaptop,20,"(run-safe thunk1359)");
lf[706]=C_h_intern(&lf[706],6,"\003sysgc");
lf[707]=C_static_lambda_info(C_heaptop,31,"(store-result x1369 result1370)");
lf[709]=C_h_intern(&lf[709],13,"thread-yield!");
lf[710]=C_static_lambda_info(C_heaptop,7,"(a8833)");
lf[711]=C_static_lambda_info(C_heaptop,15,"(CHICKEN_yield)");
lf[713]=C_static_lambda_info(C_heaptop,7,"(a8845)");
lf[714]=C_static_lambda_info(C_heaptop,33,"(CHICKEN_eval exp1374 result1375)");
lf[716]=C_h_intern(&lf[716],17,"open-input-string");
lf[717]=C_static_lambda_info(C_heaptop,7,"(a8864)");
lf[718]=C_static_lambda_info(C_heaptop,40,"(CHICKEN_eval_string str1378 result1379)");
lf[720]=C_static_string(C_heaptop,40,"Error: not enough room for result string");
lf[721]=C_static_lambda_info(C_heaptop,34,"(store-string bufsize1384 buf1385)");
lf[723]=C_static_lambda_info(C_heaptop,7,"(a8900)");
lf[724]=C_static_lambda_info(C_heaptop,52,"(CHICKEN_eval_to_string exp1388 buf1389 bufsize1390)");
lf[726]=C_static_lambda_info(C_heaptop,7,"(a8929)");
lf[727]=C_static_lambda_info(C_heaptop,59,"(CHICKEN_eval_string_to_string str1396 buf1397 bufsize1398)");
lf[729]=C_static_lambda_info(C_heaptop,7,"(a8963)");
lf[730]=C_static_lambda_info(C_heaptop,44,"(CHICKEN_apply func1404 args1405 result1406)");
lf[731]=C_h_intern(&lf[731],23,"CHICKEN_apply_to_string");
lf[732]=C_static_lambda_info(C_heaptop,7,"(a8979)");
lf[733]=C_static_lambda_info(C_heaptop,63,"(CHICKEN_apply_to_string func1410 args1411 buf1412 bufsize1413)");
lf[735]=C_static_lambda_info(C_heaptop,7,"(a9008)");
lf[736]=C_static_lambda_info(C_heaptop,33,"(CHICKEN_read str1420 result1421)");
lf[738]=C_static_lambda_info(C_heaptop,7,"(a9030)");
lf[739]=C_static_lambda_info(C_heaptop,22,"(CHICKEN_load str1425)");
lf[741]=C_static_string(C_heaptop,8,"No error");
lf[742]=C_static_lambda_info(C_heaptop,47,"(CHICKEN_get_error_message buf1428 bufsize1429)");
lf[743]=C_h_intern(&lf[743],15,"\003sysmake-string");
lf[744]=C_static_lambda_info(C_heaptop,32,"(##sys#make-lambda-info str1434)");
lf[745]=C_h_intern(&lf[745],6,"module");
lf[746]=C_static_string(C_heaptop,25,"modules are not supported");
lf[747]=C_static_lambda_info(C_heaptop,16,"(a9055 form1340)");
lf[748]=C_h_intern(&lf[748],13,"define-syntax");
lf[749]=C_static_string(C_heaptop,34,"highlevel macros are not supported");
lf[750]=C_static_lambda_info(C_heaptop,16,"(a9061 form1339)");
lf[751]=C_static_lambda_info(C_heaptop,13,"(a9080 x1337)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[752]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[753]=C_static_lambda_info(C_heaptop,17,"(a9067 . ids1336)");
lf[754]=C_static_lambda_info(C_heaptop,25,"(expand name1329 val1330)");
lf[755]=C_h_intern(&lf[755],12,"define-macro");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[756]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[757]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[758]=C_h_pair(C_restore,tmp);
lf[759]=C_static_lambda_info(C_heaptop,27,"(a9086 head1326 . body1327)");
lf[760]=C_static_string(C_heaptop,4,"#;> ");
lf[761]=C_static_lambda_info(C_heaptop,7,"(a9211)");
lf[762]=C_h_intern(&lf[762],14,"make-parameter");
tmp=C_intern(C_heaptop,7,"\000srfi-8");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-6");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-2");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-0");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\000srfi-10");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"\000srfi-9");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\000srfi-55");
C_save(tmp);
lf[763]=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
lf[764]=C_h_intern(&lf[764],16,"\003sysmake-promise");
lf[765]=C_static_lambda_info(C_heaptop,13,"(a9214 x1247)");
lf[766]=C_h_intern(&lf[766],5,"delay");
lf[767]=C_static_lambda_info(C_heaptop,18,"(walk x1221 n1222)");
lf[768]=C_h_intern(&lf[768],16,"\003syslist->vector");
lf[769]=C_h_intern(&lf[769],7,"unquote");
lf[770]=C_h_intern(&lf[770],8,"\003syslist");
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
lf[771]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"unquote");
C_save(tmp);
lf[772]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
lf[773]=C_h_intern(&lf[773],10,"quasiquote");
lf[774]=C_h_intern(&lf[774],16,"unquote-splicing");
lf[775]=C_static_lambda_info(C_heaptop,19,"(walk1 x1223 n1224)");
lf[776]=C_h_intern(&lf[776],1,"a");
lf[777]=C_h_intern(&lf[777],1,"b");
tmp=C_intern(C_heaptop,10,"\003sysappend");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
lf[778]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[779]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syslist");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
lf[780]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"b");
C_save(tmp);
lf[781]=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"quote");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
lf[782]=C_h_list(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
tmp=C_intern(C_heaptop,1,"a");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[783]=C_h_pair(C_restore,tmp);
lf[784]=C_static_lambda_info(C_heaptop,16,"(simplify x1233)");
lf[785]=C_static_lambda_info(C_heaptop,16,"(a9224 form1217)");
lf[786]=C_static_lambda_info(C_heaptop,13,"(a9570 b1213)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[787]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[788]=C_h_pair(C_restore,tmp);
lf[789]=C_static_lambda_info(C_heaptop,13,"(a9617 b1211)");
lf[790]=C_static_string(C_heaptop,2,"do");
lf[791]=C_h_intern(&lf[791],2,"do");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[792]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_vector(1,C_pick(0));
C_drop(1);
tmp=C_h_pair(C_restore,tmp);
tmp=C_h_pair(C_restore,tmp);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[793]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[794]=C_static_lambda_info(C_heaptop,40,"(a9516 bindings1207 test1208 . body1209)");
lf[795]=C_static_lambda_info(C_heaptop,13,"(a9681 b1203)");
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[796]=C_h_pair(C_restore,tmp);
lf[797]=C_static_lambda_info(C_heaptop,13,"(a9695 b1202)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[798]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[799]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[800]=C_static_lambda_info(C_heaptop,16,"(a9635 form1199)");
lf[801]=C_static_lambda_info(C_heaptop,15,"(expand bs1195)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[802]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_h_list(2,C_pick(1),C_pick(0));
C_drop(2);
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
lf[803]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
lf[804]=C_static_lambda_info(C_heaptop,16,"(a9705 form1191)");
lf[805]=C_h_intern(&lf[805],4,"else");
lf[806]=C_h_intern(&lf[806],2,"or");
lf[807]=C_h_intern(&lf[807],4,"eqv\077");
lf[808]=C_static_lambda_info(C_heaptop,13,"(a9835 x1188)");
lf[809]=C_h_intern(&lf[809],4,"case");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[810]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[811]=C_h_pair(C_restore,tmp);
lf[812]=C_static_lambda_info(C_heaptop,20,"(expand clauses1185)");
lf[813]=C_static_lambda_info(C_heaptop,16,"(a9758 form1180)");
lf[814]=C_h_intern(&lf[814],2,"=>");
lf[815]=C_h_intern(&lf[815],4,"cond");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[816]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,14,"\004coreundefined");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[817]=C_h_pair(C_restore,tmp);
lf[818]=C_static_lambda_info(C_heaptop,20,"(expand clauses1173)");
lf[819]=C_static_lambda_info(C_heaptop,16,"(a9861 body1171)");
lf[820]=C_static_lambda_info(C_heaptop,17,"(a10002 body1166)");
lf[821]=C_h_intern(&lf[821],3,"and");
lf[822]=C_static_lambda_info(C_heaptop,17,"(a10045 body1162)");
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[823]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[824]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[825]=C_h_vector(2,C_pick(1),C_pick(0));
C_drop(2);
tmp=C_intern(C_heaptop,6,"symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"lambda-list");
lf[826]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_SCHEME_END_OF_LIST;
lf[827]=C_h_pair(C_restore,tmp);
tmp=C_intern(C_heaptop,1,"_");
C_save(tmp);
tmp=C_fix(0);
C_save(tmp);
tmp=C_fix(1);
C_save(tmp);
lf[828]=C_h_vector(3,C_pick(2),C_pick(1),C_pick(0));
C_drop(3);
lf[829]=C_static_lambda_info(C_heaptop,15,"(loop form1152)");
lf[830]=C_static_lambda_info(C_heaptop,17,"(a10073 form1150)");
tmp=C_intern(C_heaptop,12,"dynamic-wind");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"values");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"call-with-values");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"eval");
C_save(tmp);
tmp=C_intern(C_heaptop,25,"scheme-report-environment");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"null-environment");
C_save(tmp);
tmp=C_intern(C_heaptop,23,"interaction-environment");
C_save(tmp);
lf[831]=C_h_list(7,C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(7);
tmp=C_intern(C_heaptop,3,"not");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"boolean\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"eq\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"eqv\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"equal\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"pair\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cons");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"car");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cdr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"caar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cadr");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cdar");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"cddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cadar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"caddr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdaar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdadr");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cddar");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"cdddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"caaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cadddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdadar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdaddr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddaar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddadr");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cdddar");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"cddddr");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"set-car!");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"set-cdr!");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"null\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"list\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"list");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"length");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"list-tail");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"list-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"append");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"reverse");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"memq");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"memv");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"member");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"assq");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"assv");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"assoc");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"symbol\077");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"symbol->string");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"string->symbol");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"number\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"integer\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"exact\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"real\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"complex\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"inexact\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"rational\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"zero\077");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"odd\077");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"even\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"positive\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"negative\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"max");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"min");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"+");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"-");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"*");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"/");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"=");
C_save(tmp);
tmp=C_intern(C_heaptop,1,">");
C_save(tmp);
tmp=C_intern(C_heaptop,1,"<");
C_save(tmp);
tmp=C_intern(C_heaptop,2,">=");
C_save(tmp);
tmp=C_intern(C_heaptop,2,"<=");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"quotient");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"remainder");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"modulo");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"gcd");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"lcm");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"abs");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"floor");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"ceiling");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"truncate");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"round");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"exact->inexact");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"inexact->exact");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"exp");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"log");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"expt");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"sqrt");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"sin");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"cos");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"tan");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"asin");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"acos");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"atan");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"number->string");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"string->number");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"char\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"char<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"char>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"char<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"char-ci>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"char-ci>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"char-ci<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-alphabetic\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-whitespace\077");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char-numeric\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-upper-case\077");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"char-lower-case\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"char-upcase");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char-downcase");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"char->integer");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"integer->char");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"string\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"string<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"string>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"string<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci<\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-ci>\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-ci>=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-ci<=\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"make-string");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"string-length");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"string-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-set!");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"string-append");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"string-copy");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string->list");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"list->string");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"substring");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"string-fill!");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"vector\077");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"make-vector");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"vector-ref");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"vector-set!");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"string");
C_save(tmp);
tmp=C_intern(C_heaptop,6,"vector");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"vector-length");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"vector->list");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"list->vector");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"vector-fill!");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"procedure\077");
C_save(tmp);
tmp=C_intern(C_heaptop,3,"map");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"for-each");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"apply");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"force");
C_save(tmp);
tmp=C_intern(C_heaptop,30,"call-with-current-continuation");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"input-port\077");
C_save(tmp);
tmp=C_intern(C_heaptop,12,"output-port\077");
C_save(tmp);
tmp=C_intern(C_heaptop,18,"current-input-port");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"current-output-port");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"call-with-input-file");
C_save(tmp);
tmp=C_intern(C_heaptop,21,"call-with-output-file");
C_save(tmp);
tmp=C_intern(C_heaptop,15,"open-input-file");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"open-output-file");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"close-input-port");
C_save(tmp);
tmp=C_intern(C_heaptop,17,"close-output-port");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"load");
C_save(tmp);
tmp=C_intern(C_heaptop,13,"transcript-on");
C_save(tmp);
tmp=C_intern(C_heaptop,14,"transcript-off");
C_save(tmp);
tmp=C_intern(C_heaptop,4,"read");
C_save(tmp);
tmp=C_intern(C_heaptop,11,"eof-object\077");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"read-char");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"peek-char");
C_save(tmp);
tmp=C_intern(C_heaptop,5,"write");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"display");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"write-char");
C_save(tmp);
tmp=C_intern(C_heaptop,7,"newline");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"with-input-from-file");
C_save(tmp);
tmp=C_intern(C_heaptop,19,"with-output-to-file");
C_save(tmp);
tmp=C_intern(C_heaptop,20,"\003syscall-with-values");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"\003sysvalues");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003sysdynamic-wind");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003sysvoid");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003syslist->vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syslist");
C_save(tmp);
tmp=C_intern(C_heaptop,10,"\003sysappend");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"\003syscons");
C_save(tmp);
tmp=C_intern(C_heaptop,16,"\003sysmake-promise");
C_save(tmp);
lf[832]=C_h_list(191,C_pick(190),C_pick(189),C_pick(188),C_pick(187),C_pick(186),C_pick(185),C_pick(184),C_pick(183),C_pick(182),C_pick(181),C_pick(180),C_pick(179),C_pick(178),C_pick(177),C_pick(176),C_pick(175),C_pick(174),C_pick(173),C_pick(172),C_pick(171),C_pick(170),C_pick(169),C_pick(168),C_pick(167),C_pick(166),C_pick(165),C_pick(164),C_pick(163),C_pick(162),C_pick(161),C_pick(160),C_pick(159),C_pick(158),C_pick(157),C_pick(156),C_pick(155),C_pick(154),C_pick(153),C_pick(152),C_pick(151),C_pick(150),C_pick(149),C_pick(148),C_pick(147),C_pick(146),C_pick(145),C_pick(144),C_pick(143),C_pick(142),C_pick(141),C_pick(140),C_pick(139),C_pick(138),C_pick(137),C_pick(136),C_pick(135),C_pick(134),C_pick(133),C_pick(132),C_pick(131),C_pick(130),C_pick(129),C_pick(128),C_pick(127),C_pick(126),C_pick(125),C_pick(124),C_pick(123),C_pick(122),C_pick(121),C_pick(120),C_pick(119),C_pick(118),C_pick(117),C_pick(116),C_pick(115),C_pick(114),C_pick(113),C_pick(112),C_pick(111),C_pick(110),C_pick(109),C_pick(108),C_pick(107),C_pick(106),C_pick(105),C_pick(104),C_pick(103),C_pick(102),C_pick(101),C_pick(100),C_pick(99),C_pick(98),C_pick(97),C_pick(96),C_pick(95),C_pick(94),C_pick(93),C_pick(92),C_pick(91),C_pick(90),C_pick(89),C_pick(88),C_pick(87),C_pick(86),C_pick(85),C_pick(84),C_pick(83),C_pick(82),C_pick(81),C_pick(80),C_pick(79),C_pick(78),C_pick(77),C_pick(76),C_pick(75),C_pick(74),C_pick(73),C_pick(72),C_pick(71),C_pick(70),C_pick(69),C_pick(68),C_pick(67),C_pick(66),C_pick(65),C_pick(64),C_pick(63),C_pick(62),C_pick(61),C_pick(60),C_pick(59),C_pick(58),C_pick(57),C_pick(56),C_pick(55),C_pick(54),C_pick(53),C_pick(52),C_pick(51),C_pick(50),C_pick(49),C_pick(48),C_pick(47),C_pick(46),C_pick(45),C_pick(44),C_pick(43),C_pick(42),C_pick(41),C_pick(40),C_pick(39),C_pick(38),C_pick(37),C_pick(36),C_pick(35),C_pick(34),C_pick(33),C_pick(32),C_pick(31),C_pick(30),C_pick(29),C_pick(28),C_pick(27),C_pick(26),C_pick(25),C_pick(24),C_pick(23),C_pick(22),C_pick(21),C_pick(20),C_pick(19),C_pick(18),C_pick(17),C_pick(16),C_pick(15),C_pick(14),C_pick(13),C_pick(12),C_pick(11),C_pick(10),C_pick(9),C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(191);
lf[833]=C_h_intern(&lf[833],7,"version");
lf[834]=C_h_intern(&lf[834],5,"error");
lf[835]=C_static_string(C_heaptop,51,"installed extension does not match required version");
lf[836]=C_h_intern(&lf[836],9,"string>=\077");
lf[837]=C_h_intern(&lf[837],8,"->string");
lf[838]=C_static_string(C_heaptop,29,"invalid version specification");
lf[839]=C_static_lambda_info(C_heaptop,21,"(a10173 spec971 _972)");
lf[840]=C_h_intern(&lf[840],12,"list->vector");
lf[841]=C_h_intern(&lf[841],18,"\003sysstring->symbol");
lf[842]=C_static_string(C_heaptop,5,"srfi-");
lf[843]=C_static_lambda_info(C_heaptop,13,"(loop ids967)");
lf[844]=C_static_lambda_info(C_heaptop,23,"(a10264 spec964 old965)");
lf[845]=C_h_intern(&lf[845],4,"srfi");
lf[846]=C_h_intern(&lf[846],6,"getenv");
lf[847]=C_static_lambda_info(C_heaptop,13,"(a10336 x808)");
lf[848]=C_static_lambda_info(C_heaptop,16,"(a10342 g806807)");
lf[849]=C_h_intern(&lf[849],7,"windows");
lf[850]=C_h_intern(&lf[850],4,"msvc");
lf[851]=C_h_intern(&lf[851],7,"mingw32");
lf[852]=C_h_intern(&lf[852],14,"build-platform");
lf[853]=C_h_intern(&lf[853],13,"software-type");
lf[854]=C_h_intern(&lf[854],6,"macosx");
lf[855]=C_h_intern(&lf[855],4,"hpux");
lf[856]=C_h_intern(&lf[856],4,"hppa");
lf[857]=C_h_intern(&lf[857],12,"machine-type");
lf[858]=C_h_intern(&lf[858],16,"software-version");
lf[859]=C_static_string(C_heaptop,10,"C_toplevel");
lf[860]=C_static_lambda_info(C_heaptop,8,"(a10446)");
lf[861]=C_static_lambda_info(C_heaptop,8,"(a10453)");
lf[862]=C_static_lambda_info(C_heaptop,8,"(a10459)");
lf[863]=C_static_lambda_info(C_heaptop,22,"(a10434 x630 . env631)");
lf[864]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,865);
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate(&lf[8],lf[9]);
t7=C_mutate(&lf[10],lf[11]);
t8=C_mutate(&lf[12],lf[13]);
t9=C_mutate(&lf[14],lf[15]);
t10=C_mutate(&lf[16],lf[17]);
t11=C_mutate(&lf[18],lf[19]);
t12=C_mutate(&lf[20],lf[21]);
t13=C_mutate(&lf[22],lf[23]);
t14=C_mutate(&lf[24],lf[25]);
t15=C_mutate(&lf[26],lf[27]);
t16=C_mutate(&lf[28],lf[29]);
t17=C_mutate(&lf[30],lf[31]);
t18=C_mutate(&lf[32],lf[33]);
t19=C_mutate(&lf[34],lf[35]);
t20=C_mutate(&lf[36],lf[37]);
t21=C_mutate(&lf[38],lf[39]);
t22=C_mutate(&lf[40],lf[41]);
t23=C_mutate(&lf[42],*((C_word*)lf[43]+1));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1594,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 94   string */
t25=*((C_word*)lf[569]+1);
((C_proc3)C_retrieve_proc(t25))(3,t25,t24,*((C_word*)lf[43]+1));}

/* k1592 */
static void f_1594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1594,2,t0,t1);}
t2=C_mutate(&lf[44],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 99   make-vector */
t4=*((C_word*)lf[563]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1596 in k1592 */
static void f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[87],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=C_mutate((C_word*)lf[45]+1,t1);
t3=C_mutate((C_word*)lf[46]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1600,a[2]=lf[49],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1632,a[2]=lf[55],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[56]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1650,a[2]=lf[57],tmp=(C_word)a,a+=3,tmp));
t7=*((C_word*)lf[58]+1);
t8=C_mutate(&lf[59],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=t7,a[3]=lf[97],tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[98]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=lf[99],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[100]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2032,a[2]=lf[101],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2035,a[2]=lf[103],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2041,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2077,a[2]=lf[110],tmp=(C_word)a,a+=3,tmp));
t14=C_set_block_item(lf[111],0,C_SCHEME_FALSE);
t15=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2094,a[2]=lf[117],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2165,a[2]=lf[123],tmp=(C_word)a,a+=3,tmp));
t17=*((C_word*)lf[124]+1);
t18=*((C_word*)lf[125]+1);
t19=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2208,a[2]=t18,a[3]=t17,a[4]=lf[150],tmp=(C_word)a,a+=5,tmp));
t20=*((C_word*)lf[124]+1);
t21=*((C_word*)lf[151]+1);
t22=C_mutate((C_word*)lf[152]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2727,a[2]=t21,a[3]=t20,a[4]=lf[176],tmp=(C_word)a,a+=5,tmp));
t23=C_mutate((C_word*)lf[177]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3181,a[2]=lf[179],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3272,a[2]=lf[181],tmp=(C_word)a,a+=3,tmp));
t25=C_SCHEME_FALSE;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_FALSE;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_mutate((C_word*)lf[182]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3332,a[2]=t28,a[3]=t26,a[4]=lf[183],tmp=(C_word)a,a+=5,tmp));
t30=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3347,a[2]=lf[185],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=lf[187],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3447,a[2]=lf[192],tmp=(C_word)a,a+=3,tmp));
t33=(C_word)C_slot(lf[193],C_fix(0));
t34=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3493,a[2]=t33,a[3]=lf[196],tmp=(C_word)a,a+=4,tmp));
t35=C_set_block_item(lf[197],0,C_SCHEME_FALSE);
t36=C_set_block_item(lf[198],0,C_SCHEME_FALSE);
t37=*((C_word*)lf[53]+1);
t38=*((C_word*)lf[199]+1);
t39=*((C_word*)lf[200]+1);
t40=*((C_word*)lf[124]+1);
t41=*((C_word*)lf[201]+1);
t42=(C_word)C_slot(lf[193],C_fix(0));
t43=*((C_word*)lf[202]+1);
t44=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3556,a[2]=t39,a[3]=t42,a[4]=t38,a[5]=lf[369],tmp=(C_word)a,a+=6,tmp));
t45=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5690,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t46=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10435,a[2]=lf[863],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 947  make-parameter */
t47=*((C_word*)lf[762]+1);
((C_proc3)C_retrieve_proc(t47))(3,t47,t45,t46);}

/* a10434 in k1596 in k1592 */
static void f_10435(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_10435r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_10435r(t0,t1,t2,t3);}}

static void f_10435r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(10);
t4=*((C_word*)lf[198]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10439,a[2]=t2,a[3]=t1,a[4]=t7,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t9=(C_word)C_i_vector_ref(t3,C_fix(0));
if(C_truep(t9)){
t10=(C_word)C_i_check_structure(t9,lf[552]);
t11=(C_word)C_slot(t9,C_fix(1));
t12=C_set_block_item(t7,0,t11);
t13=(C_word)C_slot(t9,C_fix(2));
t14=C_set_block_item(t5,0,t13);
t15=t8;
f_10439(t15,t14);}
else{
t10=t8;
f_10439(t10,C_SCHEME_UNDEFINED);}}
else{
t9=t8;
f_10439(t9,C_SCHEME_UNDEFINED);}}

/* k10437 in a10434 in k1596 in k1592 */
static void C_fcall f_10439(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10439,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10445,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10447,a[2]=t5,a[3]=t3,a[4]=t9,a[5]=t7,a[6]=lf[860],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10454,a[2]=((C_word*)t0)[2],a[3]=lf[861],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10460,a[2]=t9,a[3]=t7,a[4]=t5,a[5]=t3,a[6]=lf[862],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 957  ##sys#dynamic-wind */
t14=*((C_word*)lf[418]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t10,t11,t12,t13);}

/* a10459 in k10437 in a10434 in k1596 in k1592 */
static void f_10460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10460,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[198]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[197]+1));
t4=C_mutate((C_word*)lf[198]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[197]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a10453 in k10437 in a10434 in k1596 in k1592 */
static void f_10454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10454,2,t0,t1);}
/* eval.scm: 959  ##sys#compile-to-closure */
t2=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* a10446 in k10437 in a10434 in k1596 in k1592 */
static void f_10447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10447,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[198]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[197]+1));
t4=C_mutate((C_word*)lf[198]+1,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate((C_word*)lf[197]+1,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k10443 in k10437 in a10434 in k1596 in k1592 */
static void f_10445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5688 in k1596 in k1592 */
static void f_5690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5690,2,t0,t1);}
t2=C_mutate((C_word*)lf[370]+1,t1);
t3=C_mutate((C_word*)lf[371]+1,*((C_word*)lf[370]+1));
t4=C_mutate((C_word*)lf[372]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5693,a[2]=lf[373],tmp=(C_word)a,a+=3,tmp));
t5=*((C_word*)lf[124]+1);
t6=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5707,a[2]=t5,a[3]=lf[378],tmp=(C_word)a,a+=4,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fudge(C_fix(13));
/* eval.scm: 991  make-parameter */
t9=*((C_word*)lf[762]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}

/* k5787 in k5688 in k1596 in k1592 */
static void f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=C_mutate((C_word*)lf[379]+1,t1);
t3=C_mutate((C_word*)lf[380]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5791,a[2]=lf[381],tmp=(C_word)a,a+=3,tmp));
t4=C_set_block_item(lf[382],0,C_SCHEME_FALSE);
t5=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5795,a[2]=lf[392],tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[393]+1);
t7=*((C_word*)lf[199]+1);
t8=*((C_word*)lf[202]+1);
t9=*((C_word*)lf[394]+1);
t10=*((C_word*)lf[395]+1);
t11=*((C_word*)lf[396]+1);
t12=*((C_word*)lf[58]+1);
t13=*((C_word*)lf[379]+1);
t14=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=t8,a[5]=t12,a[6]=t10,a[7]=t11,a[8]=t7,a[9]=t9,a[10]=t6,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1021 ##sys#make-c-string */
t15=*((C_word*)lf[424]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,lf[859]);}

/* k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5868,2,t0,t1);}
t2=C_mutate((C_word*)lf[397]+1,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=lf[441],tmp=(C_word)a,a+=12,tmp));
t3=C_mutate((C_word*)lf[412]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6294,a[2]=lf[446],tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[447]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6339,a[2]=lf[457],tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10429,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1104 software-type */
t7=*((C_word*)lf[853]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k10427 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10429,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[849]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6381(t3,lf[15]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10425,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1105 software-version */
t4=*((C_word*)lf[858]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k10423 in k10427 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10425,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[854]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6381(t3,lf[13]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10421,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1106 software-version */
t5=*((C_word*)lf[858]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k10419 in k10423 in k10427 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10421,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[855]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1107 machine-type */
t4=*((C_word*)lf[857]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_10407(t3,C_SCHEME_FALSE);}}

/* k10415 in k10419 in k10423 in k10427 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10407(t2,(C_word)C_eqp(t1,lf[856]));}

/* k10405 in k10423 in k10427 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_10407(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6381(t2,(C_truep(t1)?lf[17]:lf[18]));}

/* k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6381,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[458]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6385,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10392,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1111 software-version */
t5=*((C_word*)lf[858]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k10390 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10392,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[854]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6385(t3,lf[18]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10374,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10388,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1112 software-version */
t5=*((C_word*)lf[858]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k10386 in k10390 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10388,2,t0,t1);}
t2=(C_word)C_eqp(t1,lf[855]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10384,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1113 machine-type */
t4=*((C_word*)lf[857]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=((C_word*)t0)[2];
f_10374(t3,C_SCHEME_FALSE);}}

/* k10382 in k10386 in k10390 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_10374(t2,(C_word)C_eqp(t1,lf[856]));}

/* k10372 in k10390 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_10374(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6385(t2,(C_truep(t1)?lf[18]:*((C_word*)lf[458]+1)));}

/* k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6385(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6385,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[433]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1117 software-type */
t4=*((C_word*)lf[853]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(t1,lf[849]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10353,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1119 build-platform */
t5=*((C_word*)lf[852]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=t2;
f_6392(t4,lf[5]);}}

/* k10351 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_eqp(t1,lf[850]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_6392(t3,lf[11]);}
else{
t3=(C_word)C_eqp(t1,lf[851]);
t4=((C_word*)t0)[2];
f_6392(t4,(C_truep(t3)?lf[9]:lf[7]));}}

/* k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6392(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6392,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[459]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10335,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10343,a[2]=lf[848],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[459]+1));}

/* a10342 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10343(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10343,3,t0,t1,t2);}
/* ##sys#string-append */
t3=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,*((C_word*)lf[458]+1));}

/* k10333 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10337,a[2]=lf[847],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1126 make-parameter */
t3=*((C_word*)lf[762]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a10336 in k10333 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10337,3,t0,t1,t2);}
t3=(C_word)C_i_check_list(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6396,2,t0,t1);}
t2=C_mutate((C_word*)lf[460]+1,t1);
t3=*((C_word*)lf[379]+1);
t4=*((C_word*)lf[58]+1);
t5=*((C_word*)lf[460]+1);
t6=*((C_word*)lf[202]+1);
t7=C_mutate((C_word*)lf[461]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6398,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=lf[469],tmp=(C_word)a,a+=7,tmp));
t8=C_mutate((C_word*)lf[470]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6504,a[2]=lf[472],tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[124]+1);
t10=C_mutate(&lf[473],(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6533,a[2]=t9,a[3]=lf[476],tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[58]+1);
t12=C_mutate((C_word*)lf[477]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6589,a[2]=t11,a[3]=lf[485],tmp=(C_word)a,a+=4,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6737,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10319,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1213 getenv */
t15=*((C_word*)lf[846]+1);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,lf[25]);}

/* k10317 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_10322(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1214 getenv */
t4=*((C_word*)lf[846]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[27]);}}

/* k10323 in k10317 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10325,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10322(2,t2,t1);}
else{
/* ##sys#peek-c-string */
t2=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}}

/* k10320 in k10317 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1212 make-parameter */
t2=*((C_word*)lf[762]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6737,2,t0,t1);}
t2=C_mutate((C_word*)lf[486]+1,t1);
t3=C_mutate((C_word*)lf[487]+1,*((C_word*)lf[486]+1));
t4=*((C_word*)lf[488]+1);
t5=*((C_word*)lf[58]+1);
t6=C_mutate((C_word*)lf[489]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6740,a[2]=t5,a[3]=t4,a[4]=lf[494],tmp=(C_word)a,a+=5,tmp));
t7=C_set_block_item(lf[495],0,C_SCHEME_END_OF_LIST);
t8=C_mutate((C_word*)lf[496]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6817,a[2]=lf[498],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[499]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6882,a[2]=lf[502],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[500]+1,*((C_word*)lf[499]+1));
t11=C_mutate((C_word*)lf[503]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6902,a[2]=lf[505],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[504]+1,*((C_word*)lf[503]+1));
t13=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6916,a[2]=lf[508],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[506]+1,*((C_word*)lf[315]+1));
t15=*((C_word*)lf[201]+1);
t16=*((C_word*)lf[488]+1);
t17=*((C_word*)lf[58]+1);
t18=*((C_word*)lf[393]+1);
t19=C_mutate((C_word*)lf[509]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6929,a[2]=t17,a[3]=t16,a[4]=t18,a[5]=t15,a[6]=lf[510],tmp=(C_word)a,a+=7,tmp));
t20=C_mutate((C_word*)lf[511]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6951,a[2]=lf[512],tmp=(C_word)a,a+=3,tmp));
t21=*((C_word*)lf[201]+1);
t22=*((C_word*)lf[393]+1);
t23=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6957,a[2]=lf[515],tmp=(C_word)a,a+=3,tmp));
t24=*((C_word*)lf[516]+1);
t25=*((C_word*)lf[517]+1);
t26=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7006,a[2]=t24,a[3]=t25,a[4]=lf[542],tmp=(C_word)a,a+=5,tmp));
t27=C_set_block_item(lf[536],0,C_SCHEME_END_OF_LIST);
t28=C_mutate((C_word*)lf[543]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7340,a[2]=lf[546],tmp=(C_word)a,a+=3,tmp));
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t30=*((C_word*)lf[840]+1);
t31=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10265,a[2]=t30,a[3]=lf[844],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1386 set-extension-specifier! */
t32=*((C_word*)lf[543]+1);
((C_proc4)C_retrieve_proc(t32))(4,t32,t29,lf[845],t31);}

/* a10264 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10265,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10273,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10279,a[2]=t7,a[3]=lf[843],tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10279(t9,t4,t5);}

/* loop in a10264 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_10279(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10279,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_check_exact_2(t3,lf[534]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10299,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10311,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10315,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1396 number->string */
C_number_to_string(3,0,t7,t3);}}

/* k10313 in loop in a10264 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1396 ##sys#string-append */
t2=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[842],t1);}

/* k10309 in loop in a10264 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1396 ##sys#string->symbol */
t2=*((C_word*)lf[841]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k10297 in loop in a10264 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10303,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* eval.scm: 1397 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_10279(t4,t2,t3);}

/* k10301 in k10297 in loop in a10264 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10303,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k10271 in a10264 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1390 list->vector */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7382,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10174,a[2]=lf[839],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1402 set-extension-specifier! */
t4=*((C_word*)lf[543]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,lf[833],t3);}

/* a10173 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10174(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10174,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10181,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t5=(C_word)C_i_car(t2);
t6=(C_word)C_eqp(t5,lf[833]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cddr(t2);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cdddr(t2);
t10=t4;
f_10181(t10,(C_word)C_i_nullp(t9));}
else{
t9=t4;
f_10181(t9,C_SCHEME_FALSE);}}
else{
t8=t4;
f_10181(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_10181(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_10181(t5,C_SCHEME_FALSE);}}

/* k10179 in a10173 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_10181(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10181,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
t3=(C_word)C_i_caddr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10190,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1407 extension-info */
t5=*((C_word*)lf[511]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* syntax-error */
t2=*((C_word*)lf[588]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[534],lf[838],((C_word*)t0)[3]);}}

/* k10188 in k10179 in a10173 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10190,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_assq(lf[833],t1):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10199,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10209,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_car(t2);
/* eval.scm: 1409 ->string */
t7=*((C_word*)lf[837]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t5=t4;
f_10199(2,t5,C_SCHEME_FALSE);}}

/* k10207 in k10188 in k10179 in a10173 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10213,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1409 ->string */
t3=*((C_word*)lf[837]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k10211 in k10207 in k10188 in k10179 in a10173 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1409 string>=? */
t2=*((C_word*)lf[836]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10197 in k10188 in k10179 in a10173 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_10196(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1410 error */
t2=*((C_word*)lf[834]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],lf[835],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k10194 in k10188 in k10179 in a10173 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7382,2,t0,t1);}
t2=*((C_word*)lf[547]+1);
t3=C_mutate((C_word*)lf[467]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7384,a[2]=t2,a[3]=lf[549],tmp=(C_word)a,a+=4,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1431 make-vector */
t5=*((C_word*)lf[563]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7440,2,t0,t1);}
t2=C_mutate(&lf[550],t1);
t3=lf[551]=C_SCHEME_FALSE;;
t4=(C_word)C_a_i_record(&a,3,lf[552],C_SCHEME_FALSE,C_SCHEME_TRUE);
t5=C_mutate(&lf[553],t4);
t6=C_mutate((C_word*)lf[554]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7447,a[2]=lf[557],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[558]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7528,a[2]=lf[559],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[560]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7531,a[2]=lf[562],tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[563]+1);
t10=C_mutate((C_word*)lf[564]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7575,a[2]=t9,a[3]=lf[566],tmp=(C_word)a,a+=4,tmp));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7613,a[2]=lf[568],tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7629,a[2]=t11,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10172,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1481 initb */
f_7613(t13,lf[550]);}

/* k10170 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[832]);}

/* k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1502 ##sys#copy-env-table */
t3=*((C_word*)lf[554]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[550],C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7633,2,t0,t1);}
t2=C_mutate(&lf[551],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7636,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10168,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1504 initb */
f_7613(t4,lf[551]);}

/* k10166 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[831]);}

/* k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7636,2,t0,t1);}
t2=C_set_block_item(lf[492],0,C_SCHEME_END_OF_LIST);
t3=*((C_word*)lf[569]+1);
t4=*((C_word*)lf[58]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7640,a[2]=lf[570],tmp=(C_word)a,a+=3,tmp);
t6=C_mutate((C_word*)lf[531]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7659,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=lf[574],tmp=(C_word)a,a+=6,tmp));
t7=*((C_word*)lf[202]+1);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7793,a[2]=t7,a[3]=lf[576],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7817,a[2]=t8,a[3]=t7,a[4]=lf[578],tmp=(C_word)a,a+=5,tmp);
t10=C_mutate((C_word*)lf[404]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7838,a[2]=t9,a[3]=t7,a[4]=lf[584],tmp=(C_word)a,a+=5,tmp));
t11=C_set_block_item(lf[585],0,C_SCHEME_FALSE);
t12=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7892,a[2]=lf[587],tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(lf[374],0,C_SCHEME_FALSE);
t14=C_mutate((C_word*)lf[588]+1,*((C_word*)lf[77]+1));
t15=C_mutate((C_word*)lf[589]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7900,a[2]=lf[590],tmp=(C_word)a,a+=3,tmp));
t16=*((C_word*)lf[58]+1);
t17=*((C_word*)lf[591]+1);
t18=*((C_word*)lf[589]+1);
t19=*((C_word*)lf[592]+1);
t20=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7936,a[2]=t17,a[3]=t18,a[4]=t19,a[5]=t16,a[6]=lf[632],tmp=(C_word)a,a+=7,tmp));
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10074,a[2]=lf[830],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1671 ##sys#register-macro-2 */
t23=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t21,lf[154],t22);}

/* a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10074(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10074,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10080,a[2]=t4,a[3]=lf[829],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_10080(t6,t1,t2);}

/* loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_10080(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10080,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10121,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1682 ##sys#check-syntax */
t7=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[154],t3,lf[824]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10134,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1686 ##sys#check-syntax */
t7=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[154],t3,lf[826]);}}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10096,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1678 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[154],t3,lf[615]);}}

/* k10094 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1679 ##sys#check-syntax */
t3=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[154],((C_word*)t0)[4],lf[828]);}

/* k10097 in k10094 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10099,2,t0,t1);}
t2=(C_word)C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?(C_word)C_i_car(((C_word*)t0)[4]):lf[827]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[96],((C_word*)t0)[2],t3));}

/* k10132 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10137,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1687 ##sys#check-syntax */
t3=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[154],((C_word*)t0)[2],lf[825]);}

/* k10135 in k10132 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10137,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10148,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10152,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* ##sys#cons */
t6=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* k10150 in k10135 in k10132 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k10146 in k10135 in k10132 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10148,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[96],((C_word*)t0)[2],t1));}

/* k10119 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10121,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1683 ##sys#check-syntax */
t3=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[154],((C_word*)t0)[2],lf[823]);}

/* k10122 in k10119 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1684 ##sys#expand-curried-define */
t3=*((C_word*)lf[164]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10129 in k10122 in k10119 in loop in a10073 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1684 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_10080(t2,((C_word*)t0)[2],t1);}

/* k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10046,a[2]=lf[822],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1690 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[821],t3);}

/* a10045 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10046,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10072,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#cons */
t8=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[821],t4);}}}

/* k10070 in a10045 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10072,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[249],((C_word*)t0)[2],t1,C_SCHEME_FALSE));}

/* k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[125]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10003,a[2]=t3,a[3]=lf[820],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1701 ##sys#register-macro-2 */
t5=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[806],t4);}

/* a10002 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10003(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10003,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t2,C_fix(0));
t6=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10025,a[2]=t4,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1711 gensym */
t8=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}}

/* k10023 in a10002 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10025,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10040,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ##sys#cons */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[806],((C_word*)t0)[2]);}

/* k10038 in k10023 in a10002 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_10040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10040,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[249],((C_word*)t0)[4],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[2],t2));}

/* k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[125]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9862,a[2]=t3,a[3]=lf[819],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1715 ##sys#register-macro-2 */
t5=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[815],t4);}

/* a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9862,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9868,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[818],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_9868(t6,t1,t2);}

/* expand in a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9868,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9884,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1724 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[815],t3,lf[816]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[817]);}}

/* k9882 in expand in a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9884,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[805],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* eval.scm: 1725 ##sys#cons */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[153],t4);}
else{
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[6]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9914,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1726 expand */
t8=((C_word*)((C_word*)t0)[4])[1];
f_9868(t8,t7,((C_word*)t0)[3]);}
else{
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_car(t6);
t8=(C_word)C_eqp(lf[814],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1728 gensym */
t10=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t10))(2,t10,t9);}
else{
t9=(C_word)C_i_car(((C_word*)t0)[6]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9973,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t9,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* eval.scm: 1725 ##sys#cons */
t12=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[153],t11);}}}}

/* k9971 in k9882 in expand in a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9977,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1735 expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9868(t3,t2,((C_word*)t0)[2]);}

/* k9975 in k9971 in k9882 in expand in a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9977,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[249],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9921 in k9882 in expand in a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9923,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,t1,t2);
t4=(C_word)C_a_i_list(&a,1,t3);
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
t6=(C_word)C_i_cdr(t5);
t7=(C_word)C_i_car(t6);
t8=(C_word)C_a_i_list(&a,2,t7,t1);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9942,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1732 expand */
t10=((C_word*)((C_word*)t0)[3])[1];
f_9868(t10,t9,((C_word*)t0)[2]);}

/* k9940 in k9921 in k9882 in expand in a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9942,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,4,lf[249],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[2],t2));}

/* k9912 in k9882 in expand in a9861 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9914,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[806],((C_word*)t0)[2],t1));}

/* k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[125]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9759,a[2]=t3,a[3]=lf[813],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1737 ##sys#register-macro-2 */
t5=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[809],t4);}

/* a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9759(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9759,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9769,a[2]=t4,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1743 gensym */
t6=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9769,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,t1,((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9780,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9782,a[2]=t1,a[3]=t6,a[4]=lf[812],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_9782(t8,t4,((C_word*)t0)[2]);}

/* expand in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9782(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9782,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9798,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1750 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[809],t3,lf[810]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[811]);}}

/* k9796 in expand in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9798,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_eqp(lf[805],t2);
if(C_truep(t3)){
t4=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* eval.scm: 1745 ##sys#cons */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[153],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9818,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9834,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9836,a[2]=((C_word*)t0)[2],a[3]=lf[808],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
/* eval.scm: 1753 ##sys#map */
t8=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}}

/* a9835 in k9796 in expand in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9836,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,2,lf[135],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[807],((C_word*)t0)[2],t3));}

/* k9832 in k9796 in expand in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1745 ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[806],t1);}

/* k9816 in k9796 in expand in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* eval.scm: 1745 ##sys#cons */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[153],t3);}

/* k9820 in k9816 in k9796 in expand in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9826,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1755 expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9782(t3,t2,((C_word*)t0)[2]);}

/* k9824 in k9820 in k9816 in k9796 in expand in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9826,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,4,lf[249],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k9778 in k9767 in a9758 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9780,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[2],t1));}

/* k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9706,a[2]=lf[804],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1757 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[133],t3);}

/* a9705 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9706,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9716,a[2]=t3,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1762 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[133],t3,lf[803]);}

/* k9714 in a9705 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9719,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1763 ##sys#check-syntax */
t3=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[133],((C_word*)t0)[4],lf[802]);}

/* k9717 in k9714 in a9705 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9719,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9724,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=lf[801],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_9724(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k9717 in k9714 in a9705 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9724,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9738,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1764 ##sys#cons */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9749,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_i_cdr(t2);
/* eval.scm: 1767 expand */
t10=t6;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k9747 in expand in k9717 in k9714 in a9705 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9749,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[81],((C_word*)t0)[2],t1));}

/* k9736 in expand in k9717 in k9714 in a9705 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1764 ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9636,a[2]=lf[800],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1769 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[84],t3);}

/* a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9636(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9636,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9646,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1774 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[84],t3,lf[799]);}

/* k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1775 ##sys#check-syntax */
t3=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[84],((C_word*)t0)[3],lf[798]);}

/* k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9656,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9660,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9696,a[2]=lf[797],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1776 ##sys#map */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9695 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9696,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t3,lf[796]));}

/* k9658 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9664,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9668,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9682,a[2]=lf[795],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1777 ##sys#map */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a9681 in k9658 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9682(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9682,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_list(&a,3,lf[96],t3,t4));}

/* k9666 in k9658 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9676,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9680,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#cons */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* k9678 in k9666 in k9658 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k9674 in k9666 in k9658 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9676,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* ##sys#append */
t3=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9662 in k9658 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9654 in k9647 in k9644 in a9635 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[125]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9517,a[2]=t3,a[3]=lf[794],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1780 ##sys#register-macro */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[791],t4);}

/* a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9517(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_9517r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9517r(t0,t1,t2,t3,t4);}}

static void f_9517r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9521,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1784 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[791],t2,lf[793]);}

/* k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1785 ##sys#check-syntax */
t3=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[791],((C_word*)t0)[6],lf[792]);}

/* k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9527,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1786 gensym */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[790]);}

/* k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9618,a[2]=lf[789],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1787 ##sys#map */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* a9617 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9618,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_car(t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_list(&a,2,t3,t5));}

/* k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9534,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_eqp(t3,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t4;
f_9549(2,t6,lf[788]);}
else{
/* ##sys#cons */
t6=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[153],t3);}}

/* k9547 in k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9557,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t2;
f_9557(2,t4,lf[787]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9610,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#cons */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}}

/* k9608 in k9547 in k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k9555 in k9547 in k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9569,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9571,a[2]=lf[786],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1798 ##sys#map */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a9570 in k9555 in k9547 in k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9571,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_i_cdr(t3);
t5=(C_word)C_eqp(t4,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_car(t2));}
else{
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_car(t7));}}

/* k9567 in k9555 in k9547 in k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9563 in k9555 in k9547 in k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k9559 in k9555 in k9547 in k9532 in k9525 in k9522 in k9519 in a9516 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9561,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[7],t1);
t3=(C_word)C_a_i_list(&a,4,lf[249],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,4,lf[81],((C_word*)t0)[3],((C_word*)t0)[2],t3));}

/* k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[516]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9225,a[2]=t3,a[3]=lf[785],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1804 ##sys#register-macro */
t5=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,lf[773],t4);}

/* a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9225(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9225,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9228,a[2]=t6,a[3]=t8,a[4]=lf[767],tmp=(C_word)a,a+=5,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9238,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[775],tmp=(C_word)a,a+=5,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9435,a[2]=t8,a[3]=lf[784],tmp=(C_word)a,a+=4,tmp));
/* eval.scm: 1865 walk */
t12=((C_word*)t4)[1];
f_9228(t12,t1,t2,C_fix(0));}

/* simplify in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9435(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9435,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9439,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1852 ##sys#match-expression */
t4=*((C_word*)lf[177]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,lf[782],lf[783]);}

/* k9437 in simplify in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9439,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[776],t1);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_a_i_list(&a,2,lf[770],t3);
/* eval.scm: 1853 simplify */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9435(t5,((C_word*)t0)[3],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1854 ##sys#match-expression */
t3=*((C_word*)lf[177]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[780],lf[781]);}}

/* k9458 in k9437 in simplify in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9460,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[777],t1);
t3=(C_word)C_i_length(t2);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(32)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9479,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9483,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_assq(lf[776],t1);
t7=(C_word)C_slot(t6,C_fix(1));
t8=(C_word)C_slot(t2,C_fix(1));
/* ##sys#cons */
t9=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t5,t7,t8);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1861 ##sys#match-expression */
t3=*((C_word*)lf[177]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[778],lf[779]);}}

/* k9500 in k9458 in k9437 in simplify in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(lf[776],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k9481 in k9458 in k9437 in simplify in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[770],t1);}

/* k9477 in k9458 in k9437 in simplify in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1858 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9435(t2,((C_word*)t0)[2],t1);}

/* walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9238(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[72],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9238,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_vectorp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9252,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9256,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1814 vector->list */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_eqp(t4,lf[769]);
if(C_truep(t6)){
t7=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=(C_word)C_slot(t5,C_fix(0));
t9=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9299,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1826 walk */
t12=((C_word*)((C_word*)t0)[3])[1];
f_9228(t12,t10,t8,t11);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[772]);}}
else{
t7=(C_word)C_eqp(t4,lf[773]);
if(C_truep(t7)){
t8=(C_truep((C_word)C_blockp(t5))?(C_word)C_pairp(t5):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_a_i_list(&a,2,lf[135],lf[773]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9326,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_slot(t5,C_fix(0));
t12=(C_word)C_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1831 walk */
t13=((C_word*)((C_word*)t0)[3])[1];
f_9228(t13,t10,t11,t12);}
else{
t9=(C_word)C_a_i_list(&a,2,lf[135],lf[773]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9345,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1832 walk */
t11=((C_word*)((C_word*)t0)[3])[1];
f_9228(t11,t10,t5,t3);}}
else{
t8=(C_truep((C_word)C_blockp(t4))?(C_word)C_pairp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=(C_word)C_slot(t4,C_fix(0));
t10=(C_word)C_slot(t4,C_fix(1));
t11=(C_word)C_eqp(t9,lf[774]);
t12=(C_truep(t11)?(C_truep((C_word)C_blockp(t10))?(C_word)C_pairp(t10):C_SCHEME_FALSE):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=(C_word)C_slot(t10,C_fix(0));
t14=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9379,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1843 walk */
t16=((C_word*)((C_word*)t0)[3])[1];
f_9228(t16,t15,t5,t3);}
else{
t15=(C_word)C_a_i_list(&a,2,lf[135],lf[774]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9398,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1845 walk */
t18=((C_word*)((C_word*)t0)[3])[1];
f_9228(t18,t16,t13,t17);}}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9409,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1847 walk */
t14=((C_word*)((C_word*)t0)[3])[1];
f_9228(t14,t13,t4,t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9426,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1848 walk */
t10=((C_word*)((C_word*)t0)[3])[1];
f_9228(t10,t9,t4,t3);}}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[135],t2));}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[135],t2));}}

/* k9424 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9430,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1848 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9228(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9428 in k9424 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9430,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t1));}

/* k9407 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9413,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1847 walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_9228(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9411 in k9407 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9413,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t1));}

/* k9396 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9398,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[770],((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9390,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1846 walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_9228(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9388 in k9396 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9390,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t1));}

/* k9377 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9379,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[115],((C_word*)t0)[2],t1));}

/* k9343 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9345,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[82],((C_word*)t0)[2],t1));}

/* k9324 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9326,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[770],((C_word*)t0)[2],t1));}

/* k9297 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9299,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[770],lf[771],t1));}

/* k9254 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1814 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9228(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9250 in walk1 in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9252,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,lf[768],t1));}

/* walk in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9228(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9228,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9236,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1809 walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9238(t5,t4,t2,t3);}

/* k9234 in walk in a9224 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1809 simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_9435(t2,((C_word*)t0)[2],t1);}

/* k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9215,a[2]=lf[765],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1867 ##sys#register-macro */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[766],t3);}

/* a9214 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9215(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9215,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,3,lf[136],C_SCHEME_END_OF_LIST,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[764],t3));}

/* k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1874 append */
t3=*((C_word*)lf[93]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[763],*((C_word*)lf[335]+1));}

/* k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8359,2,t0,t1);}
t2=C_mutate((C_word*)lf[335]+1,t1);
t3=C_mutate((C_word*)lf[633]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8361,a[2]=lf[634],tmp=(C_word)a,a+=3,tmp));
t4=C_set_block_item(lf[635],0,C_SCHEME_FALSE);
t5=C_set_block_item(lf[636],0,C_SCHEME_FALSE);
t6=C_set_block_item(lf[637],0,C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9212,a[2]=lf[761],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1887 make-parameter */
t9=*((C_word*)lf[762]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}

/* a9211 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9212,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[760]);}

/* k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8375,2,t0,t1);}
t2=C_mutate((C_word*)lf[638]+1,t1);
t3=*((C_word*)lf[202]+1);
t4=*((C_word*)lf[638]+1);
t5=C_mutate((C_word*)lf[639]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8377,a[2]=t4,a[3]=t3,a[4]=lf[642],tmp=(C_word)a,a+=5,tmp));
t6=*((C_word*)lf[372]+1);
t7=*((C_word*)lf[393]+1);
t8=*((C_word*)lf[199]+1);
t9=*((C_word*)lf[75]+1);
t10=*((C_word*)lf[202]+1);
t11=*((C_word*)lf[643]+1);
t12=C_mutate((C_word*)lf[644]+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8393,a[2]=t9,a[3]=t7,a[4]=t6,a[5]=t10,a[6]=t8,a[7]=lf[672],tmp=(C_word)a,a+=8,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8600,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1974 make-vector */
t14=*((C_word*)lf[563]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8600,2,t0,t1);}
t2=C_mutate((C_word*)lf[673]+1,t1);
t3=C_mutate((C_word*)lf[674]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8602,a[2]=lf[675],tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[676]+1);
t5=*((C_word*)lf[677]+1);
t6=*((C_word*)lf[393]+1);
t7=C_mutate((C_word*)lf[676]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8611,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=lf[682],tmp=(C_word)a,a+=6,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8686,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9087,a[2]=lf[759],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2004 ##sys#register-macro */
t10=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,lf[755],t9);}

/* a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9087(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr3r,(void*)f_9087r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_9087r(t0,t1,t2,t3);}}

static void f_9087r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(15);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9090,a[2]=lf[754],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_symbolp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9178,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2015 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[755],t3,lf[756]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9188,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2018 ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[755],t2,lf[758]);}}

/* k9186 in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2019 ##sys#check-syntax */
t3=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[755],((C_word*)t0)[2],lf[757]);}

/* k9189 in k9186 in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9191,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9202,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9206,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* ##sys#cons */
t6=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* k9204 in k9189 in k9186 in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k9200 in k9189 in k9186 in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2020 expand */
f_9090(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9176 in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* eval.scm: 2016 expand */
f_9090(((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* expand in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9090(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9090,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9094,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_i_car(t3);
t6=(C_word)C_eqp(lf[136],t5);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(C_word)C_i_cadr(t3);
t9=t4;
f_9094(t9,(C_word)C_i_symbolp(t8));}
else{
t8=t4;
f_9094(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_9094(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_9094(t5,C_SCHEME_FALSE);}}

/* k9092 in expand in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[35],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9094,NULL,2,t0,t1);}
t2=(C_truep(*((C_word*)lf[111]+1))?lf[326]:lf[325]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9105,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=(C_word)C_a_i_list(&a,2,lf[135],((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9116,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9120,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_i_cadr(((C_word*)t0)[2]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* ##sys#cons */
t10=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t6,t8,t9);}
else{
t4=(C_word)C_a_i_list(&a,2,lf[135],((C_word*)t0)[3]);
t5=t3;
f_9105(t5,(C_word)C_a_i_list(&a,3,lf[50],t4,((C_word*)t0)[2]));}}

/* k9118 in k9092 in expand in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k9114 in k9092 in expand in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9116,2,t0,t1);}
t2=((C_word*)t0)[3];
f_9105(t2,(C_word)C_a_i_list(&a,3,lf[46],((C_word*)t0)[2],t1));}

/* k9103 in k9092 in expand in a9086 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_9105(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9105,NULL,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9068,a[2]=lf[753],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2022 ##sys#register-macro */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[534],t3);}

/* a9067 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9068(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_9068r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_9068r(t0,t1,t2);}}

static void f_9068r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9072,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2025 ##sys#check-syntax */
t4=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[534],t2,lf[752]);}

/* k9070 in a9067 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9079,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9081,a[2]=lf[751],tmp=(C_word)a,a+=3,tmp);
/* map */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a9080 in k9070 in a9067 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9081,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[135],t2));}

/* k9077 in k9070 in a9067 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[319],t1);}

/* k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8692,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9062,a[2]=lf[750],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2031 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[748],t3);}

/* a9061 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9062,3,t0,t1,t2);}
/* eval.scm: 2034 ##sys#syntax-error-hook */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[748],lf[749]);}

/* k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9056,a[2]=lf[747],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2036 ##sys#register-macro-2 */
t4=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[745],t3);}

/* a9055 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9056(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9056,3,t0,t1,t2);}
/* eval.scm: 2039 ##sys#syntax-error-hook */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[745],lf[746]);}

/* k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[48],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8695,2,t0,t1);}
t2=C_mutate((C_word*)lf[683]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8697,a[2]=lf[687],tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[688]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8728,a[2]=lf[691],tmp=(C_word)a,a+=3,tmp));
t4=lf[692]=C_SCHEME_FALSE;;
t5=C_mutate(&lf[693],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8760,a[2]=lf[704],tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[705],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8819,a[2]=lf[707],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[708],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8828,a[2]=lf[711],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[712],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8840,a[2]=lf[714],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[715],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8856,a[2]=lf[718],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[719],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8882,a[2]=lf[721],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[722],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8895,a[2]=lf[724],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[725],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8921,a[2]=lf[727],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[728],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8958,a[2]=lf[730],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[731]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8974,a[2]=lf[733],tmp=(C_word)a,a+=3,tmp));
t15=C_mutate(&lf[734],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9000,a[2]=lf[736],tmp=(C_word)a,a+=3,tmp));
t16=C_mutate(&lf[737],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9022,a[2]=lf[739],tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[740],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9037,a[2]=lf[742],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9047,a[2]=lf[744],tmp=(C_word)a,a+=3,tmp));
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_SCHEME_UNDEFINED);}

/* ##sys#make-lambda-info in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9047(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9047,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9054,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2175 ##sys#make-string */
t5=*((C_word*)lf[743]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k9052 in ##sys#make-lambda-info in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(C_word)C_string_to_lambdainfo(t1);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* CHICKEN_get_error_message in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9037,4,t0,t1,t2,t3);}
t4=lf[692];
t5=(C_truep(t4)?t4:lf[741]);
/* eval.scm: 2168 store-string */
t6=t1;
((C_proc2)C_retrieve_proc(t6))(2,t6,f_8882(t5,t3,t2));}

/* CHICKEN_load in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9022,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9026,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(0));}

/* k9024 in CHICKEN_load in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9031,a[2]=t1,a[3]=lf[738],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2165 run-safe */
f_8760(((C_word*)t0)[2],t2);}

/* a9030 in k9024 in CHICKEN_load in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9035,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2165 load */
t3=*((C_word*)lf[412]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9033 in a9030 in k9024 in CHICKEN_load in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* CHICKEN_read in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9000,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9004,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k9002 in CHICKEN_read in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9004,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9009,a[2]=t1,a[3]=t2,a[4]=lf[735],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2159 run-safe */
f_8760(((C_word*)t0)[2],t3);}

/* a9008 in k9002 in CHICKEN_read in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2161 open-input-string */
t3=*((C_word*)lf[716]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9011 in a9008 in k9002 in CHICKEN_read in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2162 read */
t3=*((C_word*)lf[393]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k9018 in k9011 in a9008 in k9002 in CHICKEN_read in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_9020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2162 store-result */
f_8819(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_apply_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc(c,6);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8974,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8980,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t5,a[6]=lf[732],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2152 run-safe */
f_8760(t1,t6);}

/* a8979 in CHICKEN_apply_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 2154 open-output-string */
t3=*((C_word*)lf[696]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8982 in a8979 in CHICKEN_apply_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8987,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8998,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8996 in k8982 in a8979 in CHICKEN_apply_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2155 write */
t2=*((C_word*)lf[199]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8985 in k8982 in a8979 in CHICKEN_apply_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2156 get-output-string */
t3=*((C_word*)lf[694]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8992 in k8985 in k8982 in a8979 in CHICKEN_apply_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2156 store-string */
t2=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_8882(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_apply in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8958,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8964,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=lf[729],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2147 run-safe */
f_8760(t1,t5);}

/* a8963 in CHICKEN_apply in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8972,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8970 in a8963 in CHICKEN_apply in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2147 store-result */
f_8819(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8921,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8925,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,C_fix(0));}

/* k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8925,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8930,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=lf[726],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2138 run-safe */
f_8760(((C_word*)t0)[2],t4);}

/* a8929 in k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2140 open-output-string */
t3=*((C_word*)lf[696]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8932 in a8929 in k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8937,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8948,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8952,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8956,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2141 open-input-string */
t6=*((C_word*)lf[716]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k8954 in k8932 in a8929 in k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2141 read */
t2=*((C_word*)lf[393]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8950 in k8932 in a8929 in k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2141 eval */
t2=*((C_word*)lf[372]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8946 in k8932 in a8929 in k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2141 write */
t2=*((C_word*)lf[199]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8935 in k8932 in a8929 in k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8944,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2142 get-output-string */
t3=*((C_word*)lf[694]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8942 in k8935 in k8932 in a8929 in k8923 in CHICKEN_eval_string_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2142 store-string */
t2=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_8882(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* CHICKEN_eval_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8895(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8895,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8901,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=lf[723],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2129 run-safe */
f_8760(t1,t5);}

/* a8900 in CHICKEN_eval_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8905,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 2131 open-output-string */
t3=*((C_word*)lf[696]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8903 in a8900 in CHICKEN_eval_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8908,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8919,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2132 eval */
t4=*((C_word*)lf[372]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k8917 in k8903 in a8900 in CHICKEN_eval_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2132 write */
t2=*((C_word*)lf[199]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8906 in k8903 in a8900 in CHICKEN_eval_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8915,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2133 get-output-string */
t3=*((C_word*)lf[694]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8913 in k8906 in k8903 in a8900 in CHICKEN_eval_to_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2133 store-string */
t2=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_8882(t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* store-string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static C_word C_fcall f_8882(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t4=(C_word)C_block_size(t1);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,t2))){
t5=C_mutate(&lf[692],lf[720]);
return(C_SCHEME_FALSE);}
else{
return((C_word)C_copy_result_string(t1,t3,t4));}}

/* CHICKEN_eval_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8856(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8856,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8860,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,C_fix(0));}

/* k8858 in CHICKEN_eval_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8860,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8865,a[2]=t1,a[3]=t2,a[4]=lf[717],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2110 run-safe */
f_8760(((C_word*)t0)[2],t3);}

/* a8864 in k8858 in CHICKEN_eval_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8869,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2112 open-input-string */
t3=*((C_word*)lf[716]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8867 in a8864 in k8858 in CHICKEN_eval_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8880,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2113 read */
t4=*((C_word*)lf[393]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t1);}

/* k8878 in k8867 in a8864 in k8858 in CHICKEN_eval_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2113 eval */
t2=*((C_word*)lf[372]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8874 in k8867 in a8864 in k8858 in CHICKEN_eval_string in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2113 store-result */
f_8819(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_eval in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8840(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8840,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8846,a[2]=t2,a[3]=t3,a[4]=lf[713],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2105 run-safe */
f_8760(t1,t4);}

/* a8845 in CHICKEN_eval in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8854,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2107 eval */
t3=*((C_word*)lf[372]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8852 in a8845 in CHICKEN_eval in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2107 store-result */
f_8819(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* CHICKEN_yield in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8834,a[2]=lf[710],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2102 run-safe */
f_8760(t1,t2);}

/* a8833 in CHICKEN_yield in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2102 thread-yield! */
t3=*((C_word*)lf[709]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8836 in a8833 in CHICKEN_yield in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* store-result in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8819(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8819,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8823,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2096 ##sys#gc */
t5=*((C_word*)lf[706]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_FALSE);}

/* k8821 in store-result in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_store_result(((C_word*)t0)[3],((C_word*)t0)[4]):C_SCHEME_UNDEFINED);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8760(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8760,NULL,2,t1,t2);}
t3=lf[692]=C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8768,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8770,a[2]=t2,a[3]=lf[703],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2084 call-with-current-continuation */
t6=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8770(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8770,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8776,a[2]=t2,a[3]=lf[698],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8795,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[702],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2084 with-exception-handler */
t5=*((C_word*)lf[73]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a8794 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8801,a[2]=((C_word*)t0)[3],a[3]=lf[699],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8807,a[2]=((C_word*)t0)[2],a[3]=lf[701],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2084 ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a8806 in a8794 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8807(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8807r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8807r(t0,t1,t2);}}

static void f_8807r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8813,a[2]=t2,a[3]=lf[700],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2084 g1360 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a8812 in a8806 in a8794 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8813,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a8800 in a8794 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8801,2,t0,t1);}
/* eval.scm: 2089 thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a8775 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8776(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8776,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8782,a[2]=t2,a[3]=lf[697],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2084 g1360 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a8781 in a8775 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8786,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2085 open-output-string */
t3=*((C_word*)lf[696]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8784 in a8781 in a8775 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8789,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 2086 print-error-message */
t3=*((C_word*)lf[695]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k8787 in k8784 in a8781 in a8775 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8793,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2087 get-output-string */
t3=*((C_word*)lf[694]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8791 in k8787 in k8784 in a8781 in a8775 in a8769 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[692],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* k8766 in run-safe in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* set-dispatch-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8728(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8728,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8732,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[690]+1))){
t5=t4;
f_8732(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8757,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2059 make-vector */
t6=*((C_word*)lf[563]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_fix(256),C_SCHEME_FALSE);}}

/* k8755 in set-dispatch-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[690]+1,t1);
t3=((C_word*)t0)[2];
f_8732(t3,t2);}

/* k8730 in set-dispatch-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8732,NULL,2,t0,t1);}
t2=(C_word)C_i_check_char_2(((C_word*)t0)[4],lf[688]);
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[4]));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8741,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2062 ##sys#check-range */
t5=*((C_word*)lf[686]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t3,C_fix(0),C_fix(256),lf[688]);}

/* k8739 in k8730 in set-dispatch-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8746,a[2]=((C_word*)t0)[4],a[3]=lf[689],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(*((C_word*)lf[690]+1),((C_word*)t0)[2],t2));}

/* a8745 in k8739 in k8730 in set-dispatch-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8746(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8746,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8750,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2067 ##sys#read-char-0 */
t5=*((C_word*)lf[662]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k8748 in a8745 in k8739 in k8730 in set-dispatch-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2068 proc */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8697,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8701,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[685]+1))){
t5=t4;
f_8701(t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8726,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 2046 make-vector */
t6=*((C_word*)lf[563]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_fix(256),C_SCHEME_FALSE);}}

/* k8724 in set-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[685]+1,t1);
t3=((C_word*)t0)[2];
f_8701(t3,t2);}

/* k8699 in set-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8701,NULL,2,t0,t1);}
t2=(C_word)C_i_check_char_2(((C_word*)t0)[4],lf[683]);
t3=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[4]));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8710,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2049 ##sys#check-range */
t5=*((C_word*)lf[686]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,t3,C_fix(0),C_fix(256),lf[683]);}

/* k8708 in k8699 in set-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8715,a[2]=((C_word*)t0)[4],a[3]=lf[684],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(*((C_word*)lf[685]+1),((C_word*)t0)[2],t2));}

/* a8714 in k8708 in k8699 in set-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8715,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8719,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 2054 ##sys#read-char-0 */
t5=*((C_word*)lf[662]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k8717 in a8714 in k8708 in k8699 in set-read-syntax! in k8693 in k8690 in k8687 in k8684 in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 2055 proc */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8611(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8611,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_make_character(44));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8621,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1987 read-char */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* eval.scm: 1999 old */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k8619 in ##sys#user-read-hook in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8624,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1988 read */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}

/* k8622 in k8619 in ##sys#user-read-hook in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8625,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[680],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_nullp(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8638,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_8638(t5,t3);}
else{
t5=(C_word)C_i_listp(t1);
t6=t4;
f_8638(t6,(C_word)C_i_not(t5));}}

/* k8636 in k8622 in k8619 in ##sys#user-read-hook in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8638,NULL,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1991 err */
t2=((C_word*)t0)[5];
f_8625(t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8656,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1995 ##sys#hash-table-ref */
t4=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[673]+1),t2);}
else{
/* eval.scm: 1994 err */
t3=((C_word*)t0)[5];
f_8625(t3,((C_word*)t0)[4]);}}}

/* k8654 in k8636 in k8622 in k8619 in ##sys#user-read-hook in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
C_apply(4,0,((C_word*)t0)[4],t1,t2);}
else{
/* eval.scm: 1998 ##sys#read-error */
t2=*((C_word*)lf[678]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[681],((C_word*)t0)[2]);}}

/* err in k8622 in k8619 in ##sys#user-read-hook in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8625,NULL,2,t0,t1);}
/* eval.scm: 1989 ##sys#read-error */
t2=*((C_word*)lf[678]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)t0)[3],lf[679],((C_word*)t0)[2]);}

/* define-reader-ctor in k8598 in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8602,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[674]);
/* eval.scm: 1978 ##sys#hash-table-set! */
t5=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[673]+1),t2,t3);}

/* repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8396,a[2]=((C_word*)t0)[6],a[3]=lf[648],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8411,a[2]=t2,a[3]=lf[649],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8417,a[2]=t2,a[3]=lf[650],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[651]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[641]+1);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[652]+1);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8440,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=t10,a[10]=t8,a[11]=t6,tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1919 ##sys#error-handler */
t12=*((C_word*)lf[658]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}

/* k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8443,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* eval.scm: 1920 ##sys#reset-handler */
t3=*((C_word*)lf[667]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8445,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=lf[653],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8451,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=lf[654],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8460,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,a[5]=lf[659],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8506,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=lf[670],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8589,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=lf[671],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1932 ##sys#dynamic-wind */
t7=*((C_word*)lf[418]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[2],t4,t5,t6);}

/* a8588 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8593,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1968 ##sys#error-handler */
t3=*((C_word*)lf[658]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k8591 in a8588 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1969 ##sys#reset-handler */
t2=*((C_word*)lf[667]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8506,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=lf[669],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_8512(t5,t1);}

/* loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8512,NULL,2,t0,t1);}
t2=f_8445(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8519,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8570,a[2]=((C_word*)t0)[3],a[3]=lf[668],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1949 call-with-current-continuation */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a8569 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8570(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8570,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8576,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[666],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1951 ##sys#reset-handler */
t4=*((C_word*)lf[667]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a8575 in a8569 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8576,2,t0,t1);}
t2=C_set_block_item(lf[400],0,C_SCHEME_FALSE);
t3=C_set_block_item(lf[664],0,C_SCHEME_FALSE);
t4=C_set_block_item(lf[665],0,C_SCHEME_TRUE);
t5=C_set_block_item(lf[442],0,C_SCHEME_FALSE);
t6=f_8451(((C_word*)t0)[3]);
/* eval.scm: 1958 c */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,C_SCHEME_FALSE);}

/* k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1959 ##sys#read-prompt-hook */
t3=*((C_word*)lf[639]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8520 in k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8525,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[637]+1);
t4=(C_truep(t3)?t3:((C_word*)t0)[2]);
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t2);}

/* k8523 in k8520 in k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8525,2,t0,t1);}
if(C_truep((C_word)C_eofp(t1))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8534,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8565,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1962 ##sys#peek-char-0 */
t4=*((C_word*)lf[663]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[651]+1));}}

/* k8563 in k8523 in k8520 in k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_make_character(10),t1);
if(C_truep(t2)){
/* eval.scm: 1963 ##sys#read-char-0 */
t3=*((C_word*)lf[662]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],*((C_word*)lf[651]+1));}
else{
t3=((C_word*)t0)[2];
f_8534(2,t3,C_SCHEME_UNDEFINED);}}

/* k8532 in k8523 in k8520 in k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8539,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=lf[660],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[661],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1964 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a8547 in k8532 in k8523 in k8520 in k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8548(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_8548r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_8548r(t0,t1,t2);}}

static void f_8548r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8552,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1965 write-results */
t4=((C_word*)t0)[2];
f_8417(t4,t3,t2);}

/* k8550 in a8547 in k8532 in k8523 in k8520 in k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1966 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8512(t2,((C_word*)t0)[2]);}

/* a8538 in k8532 in k8523 in k8520 in k8517 in loop in a8505 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8539,2,t0,t1);}
t2=*((C_word*)lf[635]+1);
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=t3;
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,((C_word*)t0)[2]);}

/* a8459 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[657],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1934 ##sys#error-handler */
t3=*((C_word*)lf[658]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* a8465 in a8459 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8466(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_8466r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_8466r(t0,t1,t2,t3);}}

static void f_8466r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=f_8451(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8473,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1937 display */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,lf[656]);}

/* k8471 in a8465 in a8459 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1938 display */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8474 in k8471 in a8465 in a8459 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8482,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
t4=t2;
f_8482(t4,(C_word)C_i_nullp(t3));}
else{
t3=t2;
f_8482(t3,C_SCHEME_FALSE);}}

/* k8480 in k8474 in k8471 in a8465 in a8459 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8482(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8482,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8485,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1941 display */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[655]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1944 ##sys#write-char-0 */
t3=*((C_word*)lf[645]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),*((C_word*)lf[641]+1));}}

/* k8489 in k8480 in k8474 in k8471 in a8465 in a8459 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1945 write-err */
t2=((C_word*)t0)[4];
f_8411(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8483 in k8480 in k8474 in k8471 in a8465 in a8459 in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1942 write-err */
t2=((C_word*)t0)[4];
f_8411(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* resetports in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static C_word C_fcall f_8451(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=C_mutate((C_word*)lf[651]+1,((C_word*)((C_word*)t0)[4])[1]);
t2=C_mutate((C_word*)lf[641]+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate((C_word*)lf[652]+1,((C_word*)((C_word*)t0)[2])[1]);
return(t3);}

/* saveports in k8441 in k8438 in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static C_word C_fcall f_8445(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=C_mutate(((C_word *)((C_word*)t0)[4])+1,*((C_word*)lf[651]+1));
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[641]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,*((C_word*)lf[652]+1));
return(t3);}

/* write-results in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8417,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8427,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=t4;
f_8427(t5,t3);}
else{
t5=(C_word)C_i_car(t2);
t6=t4;
f_8427(t6,(C_word)C_eqp(C_SCHEME_UNDEFINED,t5));}}

/* k8425 in write-results in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* for-each */
t2=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* write-err in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8411,NULL,3,t0,t1,t2);}
/* for-each */
t3=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* write-one in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8396(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8396,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8400,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8405,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[646],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1906 ##sys#with-print-length-limit */
t5=*((C_word*)lf[647]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,*((C_word*)lf[636]+1),t4);}

/* a8404 in write-one in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8405,2,t0,t1);}
/* write1255 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k8398 in write-one in repl in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1907 ##sys#write-char-0 */
t2=*((C_word*)lf[645]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[641]+1));}

/* ##sys#read-prompt-hook in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8381,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8388,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8391,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1893 repl-prompt */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k8389 in ##sys#read-prompt-hook in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k8386 in ##sys#read-prompt-hook in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1893 display */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8379 in ##sys#read-prompt-hook in k8373 in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1894 ##sys#flush-output */
t2=*((C_word*)lf[640]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],*((C_word*)lf[641]+1));}

/* ##sys#test-feature in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8361,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8365,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1877 ##sys#->feature-id */
t4=*((C_word*)lf[468]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k8363 in ##sys#test-feature in k8357 in k8353 in k8350 in k8347 in k8344 in k8341 in k8338 in k8335 in k8332 in k8329 in k8326 in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_memq(t1,*((C_word*)lf[335]+1)));}

/* ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+28)){
C_save_and_reclaim((void*)tr5rv,(void*)f_7936r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_7936r(t0,t1,t2,t3,t4,t5);}}

static void f_7936r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(28);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7951,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=lf[598],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7939,a[2]=t6,a[3]=lf[599],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7982,a[2]=((C_word*)t0)[2],a[3]=lf[601],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8044,a[2]=lf[603],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8073,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t8,a[6]=t9,a[7]=t7,a[8]=t6,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(t5))){
t11=(C_word)C_i_vector_ref(t5,C_fix(0));
t12=C_mutate((C_word*)lf[374]+1,t11);
t13=t10;
f_8073(t13,t12);}
else{
t11=t10;
f_8073(t11,C_SCHEME_UNDEFINED);}}

/* k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8073,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8078,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=((C_word*)t0)[8],a[7]=lf[631],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_8078(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* walk in k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8078(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word *a;
loop:
a=C_alloc(21);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8078,NULL,4,t0,t1,t2,t3);}
t4=(C_truep((C_word)C_blockp(t3))?(C_word)C_vectorp(t3):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(C_word)C_slot(t3,C_fix(0));
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t6,C_fix(1));
t8=(C_truep(t7)?(C_word)C_slot(t3,C_fix(1)):C_fix(0));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8094,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t10=(C_word)C_eqp(t6,C_fix(1));
if(C_truep(t10)){
t11=t9;
f_8094(t11,C_fix(1));}
else{
t11=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t12=t9;
f_8094(t12,(C_truep(t11)?(C_word)C_slot(t3,C_fix(2)):C_fix(99999)));}}
else{
if(C_truep((C_word)C_blockp(t3))){
if(C_truep((C_word)C_symbolp(t3))){
t5=t3;
t6=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t7=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t7)){
/* eval.scm: 1654 test */
t8=((C_word*)t0)[4];
f_7939(t8,t1,t2,*((C_word*)lf[610]+1),lf[611]);}
else{
t8=(C_word)C_eqp(t5,lf[612]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8223,a[2]=lf[613],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1655 test */
t10=((C_word*)t0)[4];
f_7939(t10,t1,t2,t9,lf[614]);}
else{
t9=(C_word)C_eqp(t5,lf[615]);
if(C_truep(t9)){
/* eval.scm: 1656 test */
t10=((C_word*)t0)[4];
f_7939(t10,t1,t2,*((C_word*)lf[616]+1),lf[617]);}
else{
t10=(C_word)C_eqp(t5,lf[618]);
if(C_truep(t10)){
/* eval.scm: 1657 test */
t11=((C_word*)t0)[4];
f_7939(t11,t1,t2,((C_word*)t0)[3],lf[619]);}
else{
t11=(C_word)C_eqp(t5,lf[620]);
if(C_truep(t11)){
/* eval.scm: 1658 test */
t12=((C_word*)t0)[4];
f_7939(t12,t1,t2,*((C_word*)lf[621]+1),lf[622]);}
else{
t12=(C_word)C_eqp(t5,lf[569]);
if(C_truep(t12)){
/* eval.scm: 1659 test */
t13=((C_word*)t0)[4];
f_7939(t13,t1,t2,*((C_word*)lf[623]+1),lf[624]);}
else{
t13=(C_word)C_eqp(t5,lf[625]);
if(C_truep(t13)){
/* eval.scm: 1660 test */
t14=((C_word*)t0)[4];
f_7939(t14,t1,t2,((C_word*)t0)[2],lf[626]);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8277,a[2]=t3,a[3]=lf[627],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1661 test */
t15=((C_word*)t0)[4];
f_7939(t15,t1,t2,t14,lf[628]);}}}}}}}}}
else{
t5=(C_word)C_i_not((C_word)C_blockp(t2));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t6)){
/* eval.scm: 1663 err */
t7=((C_word*)t0)[6];
f_7951(t7,t1,lf[629]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8296,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 1665 walk */
t30=t7;
t31=t8;
t32=t9;
t1=t30;
t2=t31;
t3=t32;
goto loop;}}}
else{
t5=(C_word)C_eqp(t3,t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1650 err */
t6=((C_word*)t0)[6];
f_7951(t6,t1,lf[630]);}}}}

/* k8294 in walk in k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1666 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8078(t4,((C_word*)t0)[2],t2,t3);}

/* a8276 in walk in k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8277,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(t2,((C_word*)t0)[2]));}

/* a8222 in walk in k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8223,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_symbolp(t2));}

/* k8092 in walk in k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8094,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8099,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=lf[607],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_8099(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do1129 in k8092 in walk in k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_8099(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8099,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[7]))){
/* eval.scm: 1643 err */
t5=((C_word*)t0)[6];
f_7951(t5,t1,lf[604]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8118,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
/* eval.scm: 1645 err */
t6=((C_word*)t0)[6];
f_7951(t6,t5,lf[605]);}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
/* eval.scm: 1647 err */
t8=((C_word*)t0)[6];
f_7951(t8,t5,lf[606]);}
else{
t8=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1648 walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_8078(t9,t5,t8,((C_word*)t0)[2]);}}}}

/* k8116 in do1129 in k8092 in walk in k8071 in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_8099(t4,((C_word*)t0)[2],t2,t3);}

/* proper-list? in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8044(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8044,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8050,a[2]=lf[602],tmp=(C_word)a,a+=3,tmp);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_8050(t2));}

/* loop in proper-list? in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static C_word C_fcall f_8050(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(t2);}
else{
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_pairp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(C_word)C_slot(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* lambda-list? in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7982,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7986,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1610 ##sys#extended-lambda-list? */
t4=*((C_word*)lf[118]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7984 in lambda-list? in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7986,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7994,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[600],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7994(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop in k7984 in lambda-list? in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7994,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8017,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1614 keyword? */
t5=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
if(C_truep((C_word)C_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_not((C_word)C_blockp(t4));
t6=(C_truep(t5)?t5:(C_word)C_i_not((C_word)C_symbolp(t4)));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1619 loop */
t10=t1;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* k8015 in loop in k7984 in lambda-list? in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_8017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_not(t1));}

/* test in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7939(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7939,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7946,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1598 pred */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}

/* k7944 in test in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 1598 err */
t2=((C_word*)t0)[3];
f_7951(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* err in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7951(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7951,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[374]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7955,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1602 get-line-number */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k7953 in err in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7962,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7969,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1605 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7980,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1606 symbol->string */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}

/* k7978 in k7953 in err in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1606 string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[596],t1,lf[597],((C_word*)t0)[2]);}

/* k7967 in k7953 in err in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7973,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1605 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}

/* k7971 in k7967 in k7953 in err in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1605 string-append */
t2=((C_word*)t0)[5];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],lf[593],((C_word*)t0)[3],lf[594],t1,lf[595],((C_word*)t0)[2]);}

/* k7960 in k7953 in err in ##sys#check-syntax in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1603 ##sys#syntax-error-hook */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* get-line-number in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7900,3,t0,t1,t2);}
if(C_truep(*((C_word*)lf[585]+1))){
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7922,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1584 ##sys#hash-table-ref */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[585]+1),t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k7920 in get-line-number in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#syntax-error-hook in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7892(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_7892r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_7892r(t0,t1,t2);}}

static void f_7892r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[389]+1),lf[586],t2);}

/* ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7838(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7838,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7842,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1559 display-rj */
t5=((C_word*)t0)[2];
f_7817(t5,t3,t4,C_fix(8));}

/* k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7845,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1560 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[583]);}

/* k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7848,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1561 display-rj */
t4=((C_word*)t0)[2];
f_7817(t4,t2,t3,C_fix(8));}

/* k7846 in k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1562 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[582]);}

/* k7849 in k7846 in k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(2));
/* eval.scm: 1563 display-rj */
t4=((C_word*)t0)[2];
f_7817(t4,t2,t3,C_fix(8));}

/* k7852 in k7849 in k7846 in k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1564 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[581]);}

/* k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
/* eval.scm: 1565 display-rj */
t4=((C_word*)t0)[2];
f_7817(t4,t2,t3,C_fix(8));}

/* k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1566 display */
t3=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[580]);}

/* k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7866,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(4));
/* eval.scm: 1567 display-rj */
t4=((C_word*)t0)[2];
f_7817(t4,t2,t3,C_fix(8));}

/* k7864 in k7861 in k7858 in k7855 in k7852 in k7849 in k7846 in k7843 in k7840 in ##sys#display-times in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1568 display */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[579]);}

/* display-rj in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7817(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7817,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7821,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_zerop(t2))){
t5=t4;
f_7821(2,t5,lf[577]);}
else{
/* eval.scm: 1554 number->string */
C_number_to_string(3,0,t4,t2);}}

/* k7819 in display-rj in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7821,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7824,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],t2);
/* eval.scm: 1556 spaces */
t5=((C_word*)t0)[2];
f_7793(t5,t3,t4);}

/* k7822 in k7819 in display-rj in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1557 display */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* spaces in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7793(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7793,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7799,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[575],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7799(t6,t1,t2);}

/* do1059 in spaces in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7799(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7799,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7809,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1551 display */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(32));}}

/* k7807 in do1059 in spaces in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7799(t3,((C_word*)t0)[2],t2);}

/* ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_7659r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_7659r(t0,t1,t2,t3,t4);}}

static void f_7659r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_7663(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_7663(2,t7,(C_word)C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7663,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7665,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=lf[571],tmp=(C_word)a,a+=5,tmp));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7700,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=lf[572],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7717,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 1532 test */
t7=t5;
f_7700(t7,t6,((C_word*)t0)[4]);}

/* k7715 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7717,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7727,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7772,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1534 ##sys#repository-path */
t4=*((C_word*)lf[486]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=t2;
f_7727(2,t3,*((C_word*)lf[492]+1));}}}

/* k7770 in k7715 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7772,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 1534 ##sys#append */
t3=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],*((C_word*)lf[492]+1),t2);}

/* k7725 in k7715 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7727,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7729,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=lf[573],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_7729(t5,((C_word*)t0)[2],t1);}

/* loop in k7725 in k7715 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7729(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7729,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[6]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7739,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7753,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7761,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1538 string */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,*((C_word*)lf[43]+1));}}

/* k7759 in loop in k7725 in k7715 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1537 string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7751 in loop in k7725 in k7715 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1537 test */
t2=((C_word*)t0)[3];
f_7700(t2,((C_word*)t0)[2],t1);}

/* k7737 in loop in k7725 in k7715 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1540 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_7729(t3,((C_word*)t0)[4],t2);}}

/* test in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7700(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7700,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?(C_word)C_a_i_list(&a,2,lf[20],*((C_word*)lf[433]+1)):(C_word)C_a_i_list(&a,2,*((C_word*)lf[433]+1),lf[20]));
/* eval.scm: 1527 test2 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7665(t4,t1,t2,t3);}

/* test2 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7665(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7665,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7678,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1521 exists? */
f_7640(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7681,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(t3);
/* eval.scm: 1522 ##sys#string-append */
t6=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t2,t5);}}

/* k7679 in test2 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7681,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7687,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1523 exists? */
f_7640(t2,t1);}

/* k7685 in k7679 in test2 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* eval.scm: 1525 test2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7665(t3,((C_word*)t0)[6],((C_word*)t0)[2],t2);}}

/* k7676 in test2 in k7661 in ##sys#resolve-include-filename in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* exists? in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7640(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7640,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7644,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1516 ##sys#file-info */
t4=*((C_word*)lf[431]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7642 in exists? in k7634 in k7631 in k7627 in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=(C_word)C_eqp(C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_not(t3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* initb in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7613(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7613,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7615,a[2]=t2,a[3]=lf[567],tmp=(C_word)a,a+=4,tmp));}

/* f_7615 in initb in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7615,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7619,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1478 ##sys#hash-table-location */
t4=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,C_SCHEME_TRUE);}

/* k7617 */
static void f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_setslot(t1,C_fix(1),t2));}

/* null-environment in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7575(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7575r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7575r(t0,t1,t2,t3);}}

static void f_7575r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[564]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t2,C_fix(4));
t7=(C_truep(t6)?t6:(C_word)C_fixnum_greaterp(t2,C_fix(5)));
if(C_truep(t7)){
/* eval.scm: 1469 ##sys#error */
t8=*((C_word*)lf[175]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,lf[564],lf[565],t2);}
else{
t8=t5;
f_7582(2,t8,C_SCHEME_UNDEFINED);}}

/* k7580 in null-environment in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1472 make-vector */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k7587 in k7580 in null-environment in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7589,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[3]);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0)):C_SCHEME_FALSE);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,3,lf[552],t1,t3));}

/* scheme-report-environment in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7531(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3rv,(void*)f_7531r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_7531r(t0,t1,t2,t3);}}

static void f_7531r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t4=(C_word)C_i_check_exact_2(t2,lf[560]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
t7=t2;
switch(t7){
case C_fix(4):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7551,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1460 ##sys#copy-env-table */
t9=*((C_word*)lf[554]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[550],C_SCHEME_TRUE,t6);
case C_fix(5):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7564,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1461 ##sys#copy-env-table */
t9=*((C_word*)lf[554]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[551],C_SCHEME_TRUE,t6);
default:
/* eval.scm: 1462 ##sys#error */
t8=*((C_word*)lf[175]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[560],lf[561],t2);}}

/* k7562 in scheme-report-environment in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7564,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[552],t1,((C_word*)t0)[2]));}

/* k7549 in scheme-report-environment in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7551,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[552],t1,((C_word*)t0)[2]));}

/* interaction-environment in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7528,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[553]);}

/* ##sys#copy-env-table in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7447,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7454,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1438 ##sys#make-vector */
t7=*((C_word*)lf[272]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t5,C_SCHEME_END_OF_LIST);}

/* k7452 in ##sys#copy-env-table in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7454,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7459,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=lf[556],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_7459(t5,((C_word*)t0)[2],C_fix(0));}

/* do999 in k7452 in ##sys#copy-env-table in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7459(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7459,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7480,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7486,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[555],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_7486(t8,t3,t4);}}

/* copy in do999 in k7452 in ##sys#copy-env-table in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7486(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7486,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[3]:(C_word)C_slot(t3,C_fix(2)));
t7=(C_word)C_a_i_vector(&a,3,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7507,a[2]=t7,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 1451 copy */
t11=t8;
t12=t9;
t1=t11;
t2=t12;
goto loop;}}

/* k7505 in copy in do999 in k7452 in ##sys#copy-env-table in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7507,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7478 in do999 in k7452 in ##sys#copy-env-table in k7438 in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7459(t4,((C_word*)t0)[2],t3);}

/* ##sys#string->c-identifier in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7384,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7388,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1420 string-copy */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k7386 in ##sys#string->c-identifier in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7388,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7396,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=lf[548],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7396(t6,((C_word*)t0)[2],C_fix(0));}

/* do986 in k7386 in ##sys#string->c-identifier in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7396,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7416,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_u_i_char_alphabeticp(t3))){
t5=t4;
f_7416(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_u_i_char_numericp(t3);
t6=(C_word)C_i_not(t5);
t7=t4;
f_7416(t7,(C_truep(t6)?t6:(C_word)C_eqp(t2,C_fix(0))));}}}

/* k7414 in do986 in k7386 in ##sys#string->c-identifier in k7380 in k7377 in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(t1)?(C_word)C_setsubchar(((C_word*)t0)[5],((C_word*)t0)[4],C_make_character(95)):C_SCHEME_UNDEFINED);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7396(t4,((C_word*)t0)[2],t3);}

/* set-extension-specifier! in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7340,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[543]);
t5=(C_word)C_i_assq(t2,*((C_word*)lf[536]+1));
if(C_truep(t5)){
t6=(C_word)C_slot(t5,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7358,a[2]=t6,a[3]=t3,a[4]=lf[544],tmp=(C_word)a,a+=5,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_setslot(t5,C_fix(1),t7));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7372,a[2]=t3,a[3]=lf[545],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,*((C_word*)lf[536]+1));
t9=C_mutate((C_word*)lf[536]+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* a7371 in set-extension-specifier! in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7372(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7372,3,t0,t1,t2);}
/* eval.scm: 1380 proc */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_SCHEME_FALSE);}

/* a7357 in set-extension-specifier! in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7358,3,t0,t1,t2);}
/* eval.scm: 1378 proc */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7006,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7009,a[2]=t3,a[3]=lf[525],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7030,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=lf[535],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7216,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_i_car(t2);
t8=t6;
f_7216(t8,(C_word)C_i_symbolp(t7));}
else{
t7=t6;
f_7216(t7,C_SCHEME_FALSE);}}

/* k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7216,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(C_word)C_i_assq(t2,*((C_word*)lf[536]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=t5;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,((C_word*)t0)[6]);}
else{
/* eval.scm: 1366 ##sys#error */
t4=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[540],((C_word*)t0)[6]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
/* eval.scm: 1368 doit */
t2=((C_word*)t0)[2];
f_7030(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* eval.scm: 1369 ##sys#error */
t2=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[5],lf[541],((C_word*)t0)[6]);}}}

/* k7223 in k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7225,2,t0,t1);}
if(C_truep((C_word)C_i_stringp(t1))){
t2=(C_word)C_a_i_list(&a,2,lf[412],t1);
/* eval.scm: 1354 values */
C_values(4,0,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_vectorp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1356 vector->list */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}
else{
/* eval.scm: 1365 ##sys#do-the-right-thing */
t2=*((C_word*)lf[321]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}}}

/* k7249 in k7223 in k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7251,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7253,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[539],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7253(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k7249 in k7223 in k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7253(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7253,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7267,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7271,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1360 reverse */
t7=*((C_word*)lf[124]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7276,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[537],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7286,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=lf[538],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1361 ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}}

/* a7285 in loop in k7249 in k7223 in k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7286(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7286,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t6=(C_truep(t3)?t3:((C_word*)t0)[3]);
/* eval.scm: 1362 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7253(t7,t1,t4,t5,t6);}

/* a7275 in loop in k7249 in k7223 in k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7276,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* eval.scm: 1361 ##sys#do-the-right-thing */
t3=*((C_word*)lf[321]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k7269 in loop in k7249 in k7223 in k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1304 ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[153],t1);}

/* k7265 in loop in k7249 in k7223 in k7214 in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1360 values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7030(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7030,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_memq(t2,lf[37]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7040(2,t5,t3);}
else{
if(C_truep(((C_word*)t0)[4])){
t5=t4;
f_7040(2,t5,(C_word)C_i_memq(t2,lf[39]));}
else{
/* eval.scm: 1319 test-feature? */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}}

/* k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 1320 values */
C_values(4,0,((C_word*)t0)[5],lf[526],C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[4];
if(C_truep((C_truep((C_word)C_eqp(t2,lf[527]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[528]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t2,lf[529]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1322 ##sys#->feature-id */
t4=*((C_word*)lf[468]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],lf[30]))){
t3=(C_word)C_i_assq(((C_word*)t0)[4],lf[33]);
t4=(C_truep(t3)?(C_word)C_i_cadr(t3):((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7091,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7119,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7141,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_car(t3);
/* eval.scm: 1330 ##sys#->feature-id */
t9=*((C_word*)lf[468]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t7=t6;
f_7119(t7,C_SCHEME_FALSE);}}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1338 ##sys#extension-info */
t4=*((C_word*)lf[509]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[4],lf[534]);}}}}

/* k7149 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7151,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7161,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_assq(lf[533],t1);
t4=(C_truep(t3)?t3:(C_word)C_i_assq(lf[513],t1));
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,2,lf[135],((C_word*)t0)[3]);
t6=t2;
f_7161(t6,(C_word)C_a_i_list(&a,2,lf[313],t5));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7177,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1344 add-req */
t6=((C_word*)t0)[2];
f_7009(t6,t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1348 add-req */
t3=((C_word*)t0)[2];
f_7009(t3,t2,((C_word*)t0)[3]);}}

/* k7188 in k7149 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7190,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[135],((C_word*)t0)[3]);
t3=(C_word)C_a_i_list(&a,2,lf[315],t2);
/* eval.scm: 1349 values */
C_values(4,0,((C_word*)t0)[2],t3,C_SCHEME_FALSE);}

/* k7175 in k7149 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7177,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[135],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_7161(t3,(C_word)C_a_i_list(&a,2,lf[315],t2));}

/* k7159 in k7149 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7161(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1340 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7139 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_memq(t1,*((C_word*)lf[335]+1));
t3=((C_word*)t0)[2];
f_7119(t3,(C_word)C_i_not(t2));}

/* k7117 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7119,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7126,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* eval.scm: 1331 ##sys#resolve-include-filename */
t4=*((C_word*)lf[531]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7091(2,t2,C_SCHEME_UNDEFINED);}}

/* k7124 in k7117 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1331 ##sys#load */
t2=*((C_word*)lf[397]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7089 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_a_i_list(&a,2,lf[532],((C_word*)t0)[2]);
t4=(C_word)C_a_i_list(&a,2,lf[135],t3);
t5=t2;
f_7098(t5,(C_word)C_a_i_list(&a,2,lf[332],t4));}
else{
t3=(C_word)C_a_i_list(&a,2,lf[135],((C_word*)t0)[2]);
t4=t2;
f_7098(t4,(C_word)C_a_i_list(&a,2,lf[470],t3));}}

/* k7096 in k7089 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7098(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1332 values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7050 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7055,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_memq(t1,*((C_word*)lf[335]+1)))){
t3=t2;
f_7055(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7064,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7072,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7076,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1324 ##sys#symbol->string */
t6=*((C_word*)lf[481]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}

/* k7074 in k7050 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1324 ##sys#resolve-include-filename */
t2=*((C_word*)lf[531]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k7070 in k7050 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1324 ##sys#load */
t2=*((C_word*)lf[397]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k7062 in k7050 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7064,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[335]+1));
t3=C_mutate((C_word*)lf[335]+1,t2);
t4=((C_word*)t0)[2];
f_7055(t4,t3);}

/* k7053 in k7050 in k7038 in doit in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7055(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1326 values */
C_values(4,0,((C_word*)t0)[2],lf[530],C_SCHEME_TRUE);}

/* add-req in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_7009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7009,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7018,a[2]=t2,a[3]=lf[520],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7024,a[2]=t2,a[3]=lf[521],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1310 hash-table-update! */
t5=*((C_word*)lf[522]+1);
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,*((C_word*)lf[523]+1),lf[524],t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a7023 in add-req in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7024,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* a7017 in add-req in ##sys#do-the-right-thing in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_7018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7018,3,t0,t1,t2);}
/* lset-adjoin */
t3=*((C_word*)lf[518]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,*((C_word*)lf[519]+1),t2,((C_word*)t0)[2]);}

/* ##sys#lookup-runtime-requirements in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6957,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6963,a[2]=t4,a[3]=lf[514],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6963(t6,t1,t2);}

/* loop1 in ##sys#lookup-runtime-requirements in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6963(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6963,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6977,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(t2);
/* eval.scm: 1298 ##sys#extension-info */
t5=*((C_word*)lf[509]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,C_SCHEME_FALSE);}}

/* k6975 in loop1 in ##sys#lookup-runtime-requirements in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_assq(lf[513],t1);
t4=t2;
f_6980(t4,(C_truep(t3)?(C_word)C_i_cdr(t3):C_SCHEME_FALSE));}
else{
t3=t2;
f_6980(t3,C_SCHEME_FALSE);}}

/* k6978 in k6975 in loop1 in ##sys#lookup-runtime-requirements in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6980(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6980,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6987,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* eval.scm: 1302 loop1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6963(t5,t3,t4);}

/* k6985 in k6978 in k6975 in loop1 in ##sys#lookup-runtime-requirements in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1297 append */
t2=*((C_word*)lf[93]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extension-info in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6951,3,t0,t1,t2);}
/* eval.scm: 1288 ##sys#extension-info */
t3=*((C_word*)lf[509]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[511]);}

/* ##sys#extension-info in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6929(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6929,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1282 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[477]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k6931 in ##sys#extension-info in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6936,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6949,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1283 ##sys#repository-path */
t4=*((C_word*)lf[486]+1);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6947 in k6931 in ##sys#extension-info in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1283 string-append */
t2=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],t1,lf[44],((C_word*)t0)[2],lf[23]);}

/* k6934 in k6931 in ##sys#extension-info in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6942,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1284 file-exists? */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k6940 in k6934 in k6931 in ##sys#extension-info in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 1285 with-input-from-file */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#require in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6916(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6916r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6916r(t0,t1,t2);}}

static void f_6916r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6922,a[2]=lf[507],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6921 in ##sys#require in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6922(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6922,3,t0,t1,t2);}
/* ##sys#load-extension */
t3=*((C_word*)lf[496]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[506]);}

/* ##sys#provided? in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6902,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6913,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1263 ##sys#canonicalize-extension-path */
t4=*((C_word*)lf[477]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[504]);}

/* k6911 in ##sys#provided? in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_member(t1,*((C_word*)lf[495]+1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#provide in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6882(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_6882r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6882r(t0,t1,t2);}}

static void f_6882r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6888,a[2]=lf[501],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a6887 in ##sys#provide in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6888,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[500]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6895,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1256 ##sys#canonicalize-extension-path */
t5=*((C_word*)lf[477]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[500]);}

/* k6893 in a6887 in ##sys#provide in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,*((C_word*)lf[495]+1));
t3=C_mutate((C_word*)lf[495]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_6817r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6817r(t0,t1,t2,t3,t4);}}

static void f_6817r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_symbol_2(t2,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6824,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1239 ##sys#canonicalize-extension-path */
t7=*((C_word*)lf[477]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,t3);}

/* k6822 in ##sys#load-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6824,2,t0,t1);}
t2=(C_word)C_i_member(t1,*((C_word*)lf[495]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],lf[30]))){
/* eval.scm: 1242 ##sys#load-library */
t3=*((C_word*)lf[461]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6842,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 1244 ##sys#find-extension */
t4=*((C_word*)lf[489]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_SCHEME_TRUE);}}}

/* k6840 in k6822 in ##sys#load-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6842,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6848,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1246 ##sys#load */
t3=*((C_word*)lf[397]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_6858(2,t4,C_SCHEME_TRUE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_6858(2,t5,(C_word)C_i_car(t2));}
else{
/* eval.scm: 1249 ##sys#error */
t5=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}}

/* k6856 in k6840 in k6822 in ##sys#load-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 1249 ##sys#error */
t2=*((C_word*)lf[175]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[497],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6846 in k6840 in k6822 in ##sys#load-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6848,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],*((C_word*)lf[495]+1));
t3=C_mutate((C_word*)lf[495]+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}

/* ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6740,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6743,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[490],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6774,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6814,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1228 ##sys#repository-path */
t7=*((C_word*)lf[486]+1);
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}

/* k6812 in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6807,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1229 ##sys#append */
t4=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[492]+1),lf[493]);}
else{
t4=t3;
f_6807(2,t4,C_SCHEME_END_OF_LIST);}}

/* k6805 in k6812 in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1228 ##sys#append */
t2=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6772 in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6774,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6776,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=lf[491],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6776(t5,((C_word*)t0)[2],t1);}

/* loop in k6772 in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6776(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6776,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1232 check */
t5=((C_word*)t0)[2];
f_6743(t5,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k6787 in loop in k6772 in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1233 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6776(t3,((C_word*)t0)[4],t2);}}

/* check in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6743,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6747,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1224 string-append */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t2,lf[44],((C_word*)t0)[2]);}

/* k6745 in check in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6753,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6767,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1225 ##sys#string-append */
t4=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,*((C_word*)lf[433]+1));}

/* k6765 in k6745 in check in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1225 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6751 in k6745 in check in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_6756(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6763,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1226 ##sys#string-append */
t4=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],lf[20]);}}

/* k6761 in k6751 in k6745 in check in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1226 file-exists? */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6754 in k6751 in k6745 in check in ##sys#find-extension in k6735 in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6589(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6589,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6592,a[2]=t2,a[3]=t3,a[4]=lf[479],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6599,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=t5;
f_6599(2,t6,t2);}
else{
if(C_truep((C_word)C_i_symbolp(t2))){
/* eval.scm: 1188 ##sys#symbol->string */
t6=*((C_word*)lf[481]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
if(C_truep((C_word)C_i_listp(t2))){
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6682,a[2]=t4,a[3]=t7,a[4]=((C_word*)t0)[2],a[5]=lf[484],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6682(t9,t5,t2);}
else{
t6=t5;
f_6599(2,t6,C_SCHEME_UNDEFINED);}}}}

/* loop in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6682(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6682,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[482]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6699,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(t3))){
/* eval.scm: 1195 ##sys#symbol->string */
t5=*((C_word*)lf[481]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}
else{
if(C_truep((C_word)C_i_stringp(t3))){
t5=t4;
f_6699(2,t5,t3);}
else{
/* eval.scm: 1197 err */
t5=((C_word*)t0)[2];
f_6592(t5,t4);}}}}

/* k6697 in loop in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6699,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?lf[483]:lf[44]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6707,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* eval.scm: 1201 loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_6682(t7,t5,t6);}

/* k6705 in k6697 in loop in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1193 string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6597 in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6599,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6604,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=lf[480],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6604(t5,((C_word*)t0)[2],t1);}

/* check in k6597 in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6604(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6604,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(C_word)C_eqp(C_fix(0),t3);
if(C_truep(t4)){
/* eval.scm: 1204 err */
t5=((C_word*)t0)[3];
f_6592(t5,t1);}
else{
t5=(C_word)C_i_string_ref(t2,C_fix(0));
t6=(C_word)C_eqp(lf[42],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6630,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1206 ##sys#substring */
t8=*((C_word*)lf[474]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,t2,C_fix(1),t3);}
else{
t7=(C_word)C_fixnum_difference(t3,C_fix(1));
t8=(C_word)C_i_string_ref(t2,t7);
t9=(C_word)C_eqp(lf[42],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6643,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t11=(C_word)C_fixnum_difference(t3,C_fix(1));
/* eval.scm: 1208 ##sys#substring */
t12=*((C_word*)lf[474]+1);
((C_proc5)C_retrieve_proc(t12))(5,t12,t10,t2,C_fix(0),t11);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t2);}}}}

/* k6641 in check in k6597 in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1208 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6604(t2,((C_word*)t0)[2],t1);}

/* k6628 in check in k6597 in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1206 check */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6604(t2,((C_word*)t0)[2],t1);}

/* err in ##sys#canonicalize-extension-path in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6592,NULL,2,t0,t1);}
/* eval.scm: 1186 ##sys#error */
t2=*((C_word*)lf[175]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[3],lf[478],((C_word*)t0)[2]);}

/* ##sys#split-at-separator in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6533(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6533,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6542,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=lf[475],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6542(t8,t1,C_SCHEME_END_OF_LIST,C_fix(0),C_fix(0));}

/* loop in ##sys#split-at-separator in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6542(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6542,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6560,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1174 ##sys#substring */
t6=*((C_word*)lf[474]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[4],t4,((C_word*)t0)[6]);}
else{
t5=(C_word)C_eqp((C_word)C_subchar(((C_word*)t0)[4],t3),((C_word*)t0)[3]);
if(C_truep(t5)){
t6=(C_word)C_fixnum_plus(t3,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6580,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1177 ##sys#substring */
t8=*((C_word*)lf[474]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,((C_word*)t0)[4],t4,t3);}
else{
t6=(C_word)C_fixnum_plus(t3,C_fix(1));
/* eval.scm: 1178 loop */
t11=t1;
t12=t2;
t13=t6;
t14=t4;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}}

/* k6578 in loop in ##sys#split-at-separator in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6580,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* eval.scm: 1177 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6542(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2],((C_word*)t0)[2]);}

/* k6558 in loop in ##sys#split-at-separator in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6560,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* eval.scm: 1174 reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6504(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_6504r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_6504r(t0,t1,t2,t3);}}

static void f_6504r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_symbol_2(t2,lf[470]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6511,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_notvemptyp(t3);
t7=(C_truep(t6)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_FALSE);
/* eval.scm: 1165 ##sys#load-library */
t8=*((C_word*)lf[461]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t2,t7);}

/* k6509 in load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}}

/* k6519 in k6509 in load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1166 ##sys#error */
t2=*((C_word*)lf[175]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[470],lf[471],((C_word*)t0)[2],t1);}

/* ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6398(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6398,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6402,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 1138 ##sys#->feature-id */
t5=*((C_word*)lf[468]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6402,2,t0,t1);}
t2=(C_word)C_i_memq(t1,*((C_word*)lf[335]+1));
if(C_truep(t2)){
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6411,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=t3;
f_6411(t4,(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6494,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
/* eval.scm: 1143 ##sys#string-append */
t6=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,*((C_word*)lf[458]+1));}}}

/* k6492 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6498,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1144 dynamic-load-libraries */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k6496 in k6492 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6498,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6411(t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6411,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6480,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1149 ##sys#string->c-identifier */
t6=*((C_word*)lf[467]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k6478 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1147 string-append */
t2=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[465],t1,lf[466]);}

/* k6474 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1146 ##sys#make-c-string */
t2=*((C_word*)lf[424]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6417,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6463,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1151 load-verbose */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k6461 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6463,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1152 display */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[464]);}
else{
t2=((C_word*)t0)[3];
f_6417(2,t2,C_SCHEME_UNDEFINED);}}

/* k6464 in k6461 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1153 display */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6467 in k6464 in k6461 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1154 display */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[463]);}

/* k6415 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6417,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=lf[462],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6422(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k6415 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6422(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6422,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6435,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6456,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1157 ##sys#make-c-string */
t6=*((C_word*)lf[424]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k6454 in loop in k6415 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1157 ##sys#dload */
t2=*((C_word*)lf[423]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6433 in loop in k6415 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6435,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6438,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],*((C_word*)lf[335]+1)))){
t3=t2;
f_6438(t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],*((C_word*)lf[335]+1));
t4=C_mutate((C_word*)lf[335]+1,t3);
t5=t2;
f_6438(t5,t4);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 1160 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_6422(t3,((C_word*)t0)[5],t2);}}

/* k6436 in k6433 in loop in k6415 in k6412 in k6409 in k6400 in ##sys#load-library in k6394 in k6390 in k6387 in k6383 in k6379 in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6438(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6339(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_6339r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6339r(t0,t1,t2,t3);}}

static void f_6339r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6343,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6376,a[2]=lf[455],tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
t6=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,lf[456],t3,t5);}

/* a6375 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6376,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6373,a[2]=lf[453],tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[454],((C_word*)t0)[2],t3);}

/* a6372 in k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6373,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6344 in k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6349,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6370,a[2]=lf[451],tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[452],((C_word*)t0)[2],t3);}

/* a6369 in k6344 in k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k6347 in k6344 in k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6349,2,t0,t1);}
t2=*((C_word*)lf[442]+1);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6354,a[2]=t3,a[3]=t5,a[4]=lf[448],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6359,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=lf[449],tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6365,a[2]=t5,a[3]=t3,a[4]=lf[450],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[418]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a6364 in k6347 in k6344 in k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6365,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[442]+1));
t3=C_mutate((C_word*)lf[442]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a6358 in k6347 in k6344 in k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
/* eval.scm: 1101 ##sys#load */
t2=*((C_word*)lf[397]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,t1,((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6353 in k6347 in k6344 in k6341 in load-noisily in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6354,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[442]+1));
t3=C_mutate((C_word*)lf[442]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6294(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr3r,(void*)f_6294r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6294r(t0,t1,t2,t3);}}

static void f_6294r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(19);
t4=*((C_word*)lf[442]+1);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6300,a[2]=t5,a[3]=t7,a[4]=lf[443],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6305,a[2]=t2,a[3]=t3,a[4]=lf[444],tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6334,a[2]=t7,a[3]=t5,a[4]=lf[445],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t11=*((C_word*)lf[418]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t1,t8,t9,t10);}

/* a6333 in load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6334,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[442]+1));
t3=C_mutate((C_word*)lf[442]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* a6304 in load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6305,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6313,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
t4=t3;
f_6313(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_6313(2,t5,(C_word)C_i_car(t2));}
else{
/* eval.scm: 1097 ##sys#error */
t5=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k6311 in a6304 in load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1097 ##sys#load */
t2=*((C_word*)lf[397]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* a6299 in load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[442]+1));
t3=C_mutate((C_word*)lf[442]+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr5r,(void*)f_5916r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_5916r(t0,t1,t2,t3,t4,t5);}}

static void f_5916r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(25);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t4,a[12]=((C_word*)t0)[10],a[13]=t3,a[14]=lf[438],tmp=(C_word)a,a+=15,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6241,a[2]=t7,a[3]=lf[439],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6246,a[2]=t8,a[3]=lf[440],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-timer703771 */
t10=t9;
f_6246(t10,t1);}
else{
t10=(C_word)C_i_car(t5);
t11=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t11))){
/* def-printer704769 */
t12=t8;
f_6241(t12,t1,t10);}
else{
t12=(C_word)C_i_car(t11);
t13=(C_word)C_i_cdr(t11);
if(C_truep((C_word)C_i_nullp(t13))){
/* body701706 */
t14=t7;
f_5918(t14,t1,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}

/* def-timer703 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6246,NULL,2,t0,t1);}
/* def-printer704769 */
t2=((C_word*)t0)[2];
f_6241(t2,t1,C_SCHEME_FALSE);}

/* def-printer704 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6241,NULL,3,t0,t1,t2);}
/* body701706 */
t3=((C_word*)t0)[2];
f_5918(t3,t1,t2,C_SCHEME_FALSE);}

/* body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_5918(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5918,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],a[15]=t1,a[16]=((C_word*)t0)[13],tmp=(C_word)a,a+=17,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6240,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1032 ##sys#expand-home-path */
t6=*((C_word*)lf[437]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}
else{
t5=t4;
f_5922(t5,C_SCHEME_UNDEFINED);}}

/* k6238 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5922(t3,t2);}

/* k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_5922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5922,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1035 port? */
t4=*((C_word*)lf[436]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k6172 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6174,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_5925(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1037 ##sys#file-info */
t3=*((C_word*)lf[431]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
/* eval.scm: 1028 ##sys#signal-hook */
t3=*((C_word*)lf[389]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],lf[434],lf[412],lf[435],t2);}}}

/* k6187 in k6172 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(4));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix(1),t3);
t5=C_mutate((C_word*)lf[430]+1,t4);
t6=t2;
f_6192(t6,(C_word)C_i_not(t3));}
else{
t4=t2;
f_6192(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6192(t3,C_SCHEME_FALSE);}}

/* k6190 in k6187 in k6172 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_6192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6192,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_5925(2,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1043 ##sys#string-append */
t3=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[433]+1));}}

/* k6193 in k6190 in k6187 in k6172 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6201,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1044 ##sys#file-info */
t3=*((C_word*)lf[431]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k6199 in k6193 in k6190 in k6187 in k6172 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6201,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5925(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1046 ##sys#string-append */
t3=*((C_word*)lf[432]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[20]);}}

/* k6202 in k6199 in k6193 in k6190 in k6187 in k6172 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6210,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1047 ##sys#file-info */
t3=*((C_word*)lf[431]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k6208 in k6202 in k6199 in k6193 in k6190 in k6187 in k6172 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5925(2,t2,((C_word*)t0)[3]);}
else{
t2=*((C_word*)lf[430]+1);
t3=((C_word*)t0)[4];
f_5925(2,t3,(C_truep(t2)?C_SCHEME_FALSE:((C_word*)((C_word*)t0)[2])[1]));}}

/* k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5925,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=(C_truep(t2)?t2:(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6159,a[2]=lf[398],tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t3,a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=t1,a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t5=(C_word)C_i_stringp(((C_word*)((C_word*)t0)[6])[1]);
t6=(C_truep(t5)?(C_word)C_i_not(t1):C_SCHEME_FALSE);
if(C_truep(t6)){
/* eval.scm: 1056 ##sys#signal-hook */
t7=*((C_word*)lf[389]+1);
((C_proc6)C_retrieve_proc(t7))(6,t7,t4,lf[426],lf[412],lf[427],((C_word*)((C_word*)t0)[6])[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6152,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1057 load-verbose */
t8=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}}

/* k6150 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6152,2,t0,t1);}
t2=(C_truep(t1)?((C_word*)t0)[4]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6143,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1058 display */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[429]);}
else{
t3=((C_word*)t0)[2];
f_5931(2,t3,C_SCHEME_UNDEFINED);}}

/* k6141 in k6150 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6146,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1059 display */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6144 in k6141 in k6150 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1060 display */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[428]);}

/* k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[15],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[14])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6100,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6128,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1062 ##sys#make-c-string */
t5=*((C_word*)lf[424]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[14]);}
else{
t3=t2;
f_5934(2,t3,C_SCHEME_FALSE);}}

/* k6126 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1062 ##sys#dload */
t2=*((C_word*)lf[423]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6098 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6100,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_5934(2,t2,t1);}
else{
t2=((C_word*)t0)[4];
t3=(C_word)C_block_size(t2);
t4=(C_word)C_fixnum_difference(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5880,a[2]=t2,a[3]=lf[422],tmp=(C_word)a,a+=4,tmp);
t6=f_5880(t5,t4);
if(C_truep(t6)){
t7=((C_word*)t0)[5];
f_5934(2,t7,C_SCHEME_FALSE);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6120,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1064 string-append */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t8,lf[425],lf[44],((C_word*)t0)[4]);}}}

/* k6118 in k6098 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1064 ##sys#make-c-string */
t2=*((C_word*)lf[424]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6114 in k6098 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1064 ##sys#dload */
t2=*((C_word*)lf[423]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6098 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static C_word C_fcall f_5880(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_i_zerop(t1))){
return(C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(lf[42],(C_word)C_subchar(((C_word*)t0)[2],t1));
if(C_truep(t2)){
return(t2);}
else{
t3=(C_word)C_fixnum_difference(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}}

/* k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[13],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_5937(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=lf[421],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 1065 call-with-current-continuation */
t4=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}}

/* a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5942(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[48],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5942,3,t0,t1,t2);}
t3=C_SCHEME_TRUE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=((C_word*)t0)[12];
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5944,a[2]=t2,a[3]=lf[399],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5953,a[2]=t8,a[3]=t6,a[4]=t4,a[5]=t14,a[6]=t12,a[7]=t10,a[8]=lf[401],tmp=(C_word)a,a+=9,tmp);
t16=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5962,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=lf[419],tmp=(C_word)a,a+=14,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6090,a[2]=t14,a[3]=t12,a[4]=t10,a[5]=t8,a[6]=t6,a[7]=t4,a[8]=lf[420],tmp=(C_word)a,a+=9,tmp);
/* ##sys#dynamic-wind */
t18=*((C_word*)lf[418]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,t15,t16,t17);}

/* a6089 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6090,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[400]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[382]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[380]+1));
t5=C_mutate((C_word*)lf[400]+1,((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate((C_word*)lf[382]+1,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate((C_word*)lf[380]+1,((C_word*)((C_word*)t0)[2])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5966,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[5])){
/* eval.scm: 1070 open-input-file */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_5966(2,t3,((C_word*)((C_word*)t0)[2])[1]);}}

/* k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5971,a[2]=lf[402],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],a[11]=lf[416],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6081,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[417],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1071 ##sys#dynamic-wind */
t5=*((C_word*)lf[418]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t2,t3,t4);}

/* a6080 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6081,2,t0,t1);}
/* eval.scm: 1092 close-input-port */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5978,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 1074 peek-char */
t3=*((C_word*)lf[415]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5981,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(t1,C_make_character(127));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6075,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_dlerror),C_fix(0));}
else{
t4=t2;
f_5981(2,t4,C_SCHEME_UNDEFINED);}}

/* k6073 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1076 ##sys#error */
t2=*((C_word*)lf[175]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[412],lf[413],((C_word*)t0)[2],t1);}

/* k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 1077 read */
t3=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[9]);}

/* k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5988,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t3,a[11]=lf[411],tmp=(C_word)a,a+=12,tmp));
t5=((C_word*)t3)[1];
f_5990(t5,((C_word*)t0)[2],t1);}

/* do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_eofp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6000,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* eval.scm: 1079 printer */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_6000(2,t4,C_SCHEME_UNDEFINED);}}}

/* k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6003,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=lf[408],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[410],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 1080 ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a6045 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6046(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_6046r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6046r(t0,t1,t2);}}

static void f_6046r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[409],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* a6054 in a6045 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6055,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6059,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1089 write */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6057 in a6054 in a6045 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1090 newline */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a6011 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6019,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1083 ##sys#start-timer */
t3=*((C_word*)lf[407]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* eval.scm: 1084 evproc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}}

/* k6017 in a6011 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[403],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6030,a[2]=lf[406],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1083 ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6029 in k6017 in a6011 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6030(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_6030r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_6030r(t0,t1,t2);}}

static void f_6030r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6034,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6041,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 1083 ##sys#stop-timer */
t5=*((C_word*)lf[405]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6039 in a6029 in k6017 in a6011 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1083 ##sys#display-times */
t2=*((C_word*)lf[404]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k6032 in a6029 in k6017 in a6011 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a6023 in k6017 in a6011 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6024,2,t0,t1);}
/* eval.scm: 1083 evproc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k6001 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 1077 read */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k6008 in k6001 in k5998 in do747 in k5986 in k5979 in k5976 in a5973 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_5990(t2,((C_word*)t0)[2],t1);}

/* a5970 in k5964 in a5961 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5971,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* a5952 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5953,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,*((C_word*)lf[400]+1));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,*((C_word*)lf[382]+1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,*((C_word*)lf[380]+1));
t5=C_mutate((C_word*)lf[400]+1,((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate((C_word*)lf[382]+1,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate((C_word*)lf[380]+1,((C_word*)((C_word*)t0)[2])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}

/* f_5944 in a5941 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5944,2,t0,t1);}
/* eval.scm: 1069 abrt */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_FALSE);}

/* k5935 in k5932 in k5929 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* f_6159 in k5923 in k5920 in body701 in ##sys#load in k5866 in k5787 in k5688 in k1596 in k1592 */
static void f_6159(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6159r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6159r(t0,t1,t2,t3);}}

static void f_6159r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6167,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1052 ##sys#eval-handler */
t5=*((C_word*)lf[370]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k6165 */
static void f_6167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 1053 ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6169 in k6165 */
static void f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* set-dynamic-load-mode! in k5787 in k5688 in k1596 in k1592 */
static void f_5795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5795,3,t0,t1,t2);}
t3=(C_word)C_i_pairp(t2);
t4=(C_truep(t3)?t2:(C_word)C_a_i_list(&a,1,t2));
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5802,a[2]=t8,a[3]=t6,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5807,a[2]=t6,a[3]=t8,a[4]=t11,a[5]=lf[391],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_5807(t13,t9,t4);}

/* loop in set-dynamic-load-mode! in k5787 in k5688 in k1596 in k1592 */
static void C_fcall f_5807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5807,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5820,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_eqp(t3,lf[385]);
if(C_truep(t5)){
t6=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t7=t4;
f_5820(2,t7,t6);}
else{
t6=(C_word)C_eqp(t3,lf[386]);
if(C_truep(t6)){
t7=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t8=t4;
f_5820(2,t8,t7);}
else{
t7=(C_word)C_eqp(t3,lf[387]);
if(C_truep(t7)){
t8=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t9=t4;
f_5820(2,t9,t8);}
else{
t8=(C_word)C_eqp(t3,lf[388]);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t10=t4;
f_5820(2,t10,t9);}
else{
t9=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 1009 ##sys#signal-hook */
t10=*((C_word*)lf[389]+1);
((C_proc5)C_retrieve_proc(t10))(5,t10,t4,lf[383],lf[390],t9);}}}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5818 in loop in set-dynamic-load-mode! in k5787 in k5688 in k1596 in k1592 */
static void f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 1010 loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5807(t3,((C_word*)t0)[2],t2);}

/* k5800 in set-dynamic-load-mode! in k5787 in k5688 in k1596 in k1592 */
static void f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 1011 ##sys#set-dlopen-flags! */
t2=*((C_word*)lf[384]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* f_5791 in k5787 in k5688 in k1596 in k1592 */
static void f_5791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5791,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* ##sys#decompose-lambda-list in k5688 in k1596 in k1592 */
static void f_5707(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5707,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5710,a[2]=t2,a[3]=lf[376],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5720,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=lf[377],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5720(t8,t1,t2,C_SCHEME_END_OF_LIST,C_fix(0));}

/* loop in ##sys#decompose-lambda-list in k5688 in k1596 in k1592 */
static void C_fcall f_5720(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(17);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5720,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5734,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 980  reverse */
t7=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t3);}
else{
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5753,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
/* eval.scm: 982  reverse */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
if(C_truep((C_word)C_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(1));
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_a_i_cons(&a,2,t7,t3);
t9=(C_word)C_fixnum_plus(t4,C_fix(1));
/* eval.scm: 984  loop */
t14=t1;
t15=t6;
t16=t8;
t17=t9;
t1=t14;
t2=t15;
t3=t16;
t4=t17;
goto loop;}
else{
/* eval.scm: 983  err */
t6=((C_word*)t0)[2];
f_5710(t6,t1);}}}
else{
/* eval.scm: 981  err */
t6=((C_word*)t0)[2];
f_5710(t6,t1);}}}

/* k5751 in loop in ##sys#decompose-lambda-list in k5688 in k1596 in k1592 */
static void f_5753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 982  k */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5732 in loop in ##sys#decompose-lambda-list in k5688 in k1596 in k1592 */
static void f_5734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 980  k */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* err in ##sys#decompose-lambda-list in k5688 in k1596 in k1592 */
static void C_fcall f_5710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5710,NULL,2,t0,t1);}
t2=C_set_block_item(lf[374],0,C_SCHEME_FALSE);
/* eval.scm: 977  ##sys#syntax-error-hook */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[375],((C_word*)t0)[2]);}

/* eval in k5688 in k1596 in k1592 */
static void f_5693(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5693r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5693r(t0,t1,t2,t3);}}

static void f_5693r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5701,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 965  ##sys#eval-handler */
t5=*((C_word*)lf[370]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k5699 in eval in k5688 in k1596 in k1592 */
static void f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5705,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 966  ##sys#interpreter-toplevel-macroexpand-hook */
t3=*((C_word*)lf[100]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5703 in k5699 in eval in k5688 in k1596 in k1592 */
static void f_5705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##sys#compile-to-closure in k1596 in k1592 */
static void f_3556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[37],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3556,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=lf[206],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3601,a[2]=t5,a[3]=lf[209],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3713,a[2]=t6,a[3]=t8,a[4]=lf[210],tmp=(C_word)a,a+=5,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[4],a[3]=lf[217],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3805,a[2]=t8,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=t12,a[7]=t14,a[8]=((C_word*)t0)[3],a[9]=t5,a[10]=lf[357],tmp=(C_word)a,a+=11,tmp));
t16=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5476,a[2]=t12,a[3]=lf[368],tmp=(C_word)a,a+=4,tmp));
/* eval.scm: 944  compile */
t17=((C_word*)t12)[1];
f_3805(t17,t1,t2,t3,C_SCHEME_FALSE,t4);}

/* compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_5476(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5476,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5480,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 921  compile */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3805(t7,t5,t6,t3,C_SCHEME_FALSE,t4);}

/* k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5480,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5450,a[2]=lf[358],tmp=(C_word)a,a+=3,tmp);
t4=f_5450(t2,C_fix(0));
switch(t4){
case C_SCHEME_FALSE:
/* eval.scm: 925  ##sys#syntax-error-hook */
t5=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[359],((C_word*)t0)[6]);
case C_fix(0):
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5502,a[2]=t1,a[3]=lf[360],tmp=(C_word)a,a+=4,tmp));
case C_fix(1):
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5518,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 927  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3805(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(2):
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 929  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3805(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(3):
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 932  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3805(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(4):
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 936  compile */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3805(t7,t5,t6,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
default:
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5654,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[367],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 941  ##sys#map */
t7=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}}

/* a5674 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5675,3,t0,t1,t2);}
/* eval.scm: 941  compile */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3805(t3,t1,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5652 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5654,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5655,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=lf[366],tmp=(C_word)a,a+=5,tmp));}

/* f_5655 in k5652 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5655(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5655,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5663,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5661 */
static void f_5663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5667,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5669,a[2]=((C_word*)t0)[3],a[3]=lf[365],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 942  ##sys#map */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a5668 in k5661 */
static void f_5669(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5669,3,t0,t1,t2);}
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k5665 in k5661 */
static void f_5667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5612 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 937  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3805(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5615 in k5612 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 938  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3805(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5618 in k5615 in k5612 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 939  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3805(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(3)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5621 in k5618 in k5615 in k5612 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=lf[364],tmp=(C_word)a,a+=8,tmp));}

/* f_5624 in k5621 in k5618 in k5615 in k5612 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5624,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5630 */
static void f_5632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k5634 in k5630 */
static void f_5636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5636,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5638 in k5634 in k5630 */
static void f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5642 in k5638 in k5634 in k5630 */
static void f_5644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5647,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5645 in k5642 in k5638 in k5634 in k5630 */
static void f_5647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5573 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 933  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3805(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5576 in k5573 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 934  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3805(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(2)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5579 in k5576 in k5573 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=lf[363],tmp=(C_word)a,a+=7,tmp));}

/* f_5582 in k5579 in k5576 in k5573 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5582,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5588 */
static void f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5594,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k5592 in k5588 */
static void f_5594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5594,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5596 in k5592 in k5588 */
static void f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5601,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5599 in k5596 in k5592 in k5588 */
static void f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5541 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5546,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 930  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3805(t3,t2,(C_word)C_u_i_list_ref(((C_word*)t0)[4],C_fix(1)),((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5544 in k5541 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5546,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5547,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=lf[362],tmp=(C_word)a,a+=6,tmp));}

/* f_5547 in k5544 in k5541 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5555,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5553 */
static void f_5555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k5557 in k5553 */
static void f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5562,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5560 in k5557 in k5553 */
static void f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5516 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5519,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=lf[361],tmp=(C_word)a,a+=5,tmp));}

/* f_5519 in k5516 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5519,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5527,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5525 */
static void f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5530,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5528 in k5525 */
static void f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* f_5502 in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5502,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 926  fn */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5507 */
static void f_5509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* loop in k5478 in compile-call in ##sys#compile-to-closure in k1596 in k1592 */
static C_word C_fcall f_5450(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(t2);}
else{
if(C_truep((C_word)C_i_pairp(t1))){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_fixnum_plus(t2,C_fix(1));
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* compile in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3805,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_symbolp(t2))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=lf[218],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3823,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=lf[225],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 584  ##sys#call-with-values */
C_call_with_values(4,0,t1,t6,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3884,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=t5,a[10]=t3,a[11]=((C_word*)t0)[7],a[12]=t1,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 602  ##sys#number? */
t7=*((C_word*)lf[356]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}

/* k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3884,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3891,a[2]=lf[226],tmp=(C_word)a,a+=3,tmp));
case C_fix(0):
t3=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3899,a[2]=lf[227],tmp=(C_word)a,a+=3,tmp));
case C_fix(1):
t3=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3907,a[2]=lf[228],tmp=(C_word)a,a+=3,tmp));
default:
t3=(C_word)C_eqp(t2,C_fix(2));
t4=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3915,a[2]=lf[229],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[13],a[3]=lf[230],tmp=(C_word)a,a+=4,tmp)));}}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[13]))){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[13])?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3928,a[2]=lf[231],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3930,a[2]=lf[232],tmp=(C_word)a,a+=3,tmp)));}
else{
t2=(C_word)C_charp(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=t3;
f_3940(t4,t2);}
else{
t4=(C_word)C_eofp(((C_word*)t0)[13]);
t5=t3;
f_3940(t5,(C_truep(t4)?t4:(C_word)C_i_stringp(((C_word*)t0)[13])));}}}}

/* k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3940(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3940,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[12],a[3]=lf[233],tmp=(C_word)a,a+=4,tmp));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[12]))){
t2=(C_word)C_slot(((C_word*)t0)[12],C_fix(0));
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[12],C_fix(0));
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
/* eval.scm: 620  defined? */
t5=((C_word*)t0)[4];
f_3601(t5,t4,t3,((C_word*)t0)[10]);}
else{
/* eval.scm: 902  compile-call */
t3=((C_word*)((C_word*)t0)[11])[1];
f_5476(t3,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[10],((C_word*)t0)[9]);}}
else{
/* eval.scm: 617  ##sys#syntax-error-hook */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[13],lf[355],((C_word*)t0)[12]);}}}

/* k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 621  compile-call */
t2=((C_word*)((C_word*)t0)[14])[1];
f_5476(t2,((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* eval.scm: 622  macroexpand-1-checked */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3713(t3,t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10]);}}

/* k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word ab[127],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(C_word)C_eqp(t1,((C_word*)t0)[13]);
if(C_truep(t2)){
t3=(C_word)C_eqp(((C_word*)t0)[12],lf[135]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3987,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 627  ##sys#check-syntax */
t5=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[135],((C_word*)t0)[13],lf[242],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[12],lf[243]);
if(C_truep(t4)){
t5=(C_word)C_i_cadr(((C_word*)t0)[13]);
if(C_truep(*((C_word*)lf[197]+1))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 642  ##sys#hash-table-location */
t7=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,*((C_word*)lf[197]+1),t5,C_SCHEME_TRUE);}
else{
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4069,a[2]=t5,a[3]=lf[245],tmp=(C_word)a,a+=4,tmp));}}
else{
t5=(C_word)C_eqp(((C_word*)t0)[12],lf[246]);
if(C_truep(t5)){
t6=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 647  compile */
t7=((C_word*)((C_word*)t0)[10])[1];
f_3805(t7,((C_word*)t0)[11],t6,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[12],lf[247]);
if(C_truep(t6)){
t7=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 650  compile */
t8=((C_word*)((C_word*)t0)[10])[1];
f_3805(t8,((C_word*)t0)[11],t7,((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[12],lf[161]);
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4103,a[2]=lf[248],tmp=(C_word)a,a+=3,tmp));}
else{
t8=(C_word)C_eqp(((C_word*)t0)[12],lf[249]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 655  ##sys#check-syntax */
t10=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,lf[249],((C_word*)t0)[13],lf[252],C_SCHEME_FALSE);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[12],lf[153]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 664  ##sys#check-syntax */
t11=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,lf[153],((C_word*)t0)[13],lf[256],C_SCHEME_FALSE);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[12],lf[94]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[12],lf[96]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
/* eval.scm: 680  ##sys#check-syntax */
t13=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t13+1)))(6,t13,t12,lf[94],((C_word*)t0)[13],lf[266],C_SCHEME_FALSE);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[12],lf[81]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 701  ##sys#check-syntax */
t14=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t14+1)))(6,t14,t13,lf[81],((C_word*)t0)[13],lf[277],C_SCHEME_FALSE);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[12],lf[136]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 752  ##sys#check-syntax */
t15=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t15+1)))(6,t15,t14,lf[136],((C_word*)t0)[13],lf[311],C_SCHEME_FALSE);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[12],lf[87]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5038,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[13]);
/* eval.scm: 518  ##sys#cons */
t17=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t15,lf[136],t16);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[12],lf[312]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5055,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t17=(C_word)C_i_cddr(((C_word*)t0)[13]);
/* eval.scm: 518  ##sys#cons */
t18=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t16,lf[136],t17);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[12],lf[313]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5072,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5103,a[2]=lf[318],tmp=(C_word)a,a+=3,tmp);
t19=(C_word)C_i_cdr(((C_word*)t0)[13]);
/* map */
t20=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t17,t18,t19);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[12],lf[319]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t19=(C_word)C_i_cdr(((C_word*)t0)[13]);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5133,a[2]=t21,a[3]=lf[324],tmp=(C_word)a,a+=4,tmp));
t23=((C_word*)t21)[1];
f_5133(t23,t18,t19);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[12],lf[325]);
t19=(C_truep(t18)?t18:(C_word)C_eqp(((C_word*)t0)[12],lf[326]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5185,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
t22=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 867  ##sys#compile-to-closure */
t23=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t23+1)))(5,t23,t21,t22,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[12],lf[328]);
if(C_truep(t20)){
t21=(C_word)C_i_cadr(((C_word*)t0)[13]);
/* eval.scm: 871  compile */
t22=((C_word*)((C_word*)t0)[10])[1];
f_3805(t22,((C_word*)t0)[11],t21,((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[12],lf[329]);
t22=(C_truep(t21)?t21:(C_word)C_eqp(((C_word*)t0)[12],lf[330]));
if(C_truep(t22)){
/* eval.scm: 874  compile */
t23=((C_word*)((C_word*)t0)[10])[1];
f_3805(t23,((C_word*)t0)[11],lf[331],((C_word*)t0)[9],C_SCHEME_FALSE,((C_word*)t0)[7]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[12],lf[332]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5223,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_memq(lf[334],*((C_word*)lf[335]+1)))){
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5234,a[2]=lf[337],tmp=(C_word)a,a+=3,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[13]);
/* for-each */
t27=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t24,t25,t26);}
else{
/* eval.scm: 879  ##sys#warn */
t25=*((C_word*)lf[338]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t24,lf[339],((C_word*)t0)[13]);}}
else{
t24=(C_word)C_eqp(((C_word*)t0)[12],lf[340]);
t25=(C_truep(t24)?t24:(C_word)C_eqp(((C_word*)t0)[12],lf[341]));
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5265,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5269,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5273,a[2]=t27,a[3]=((C_word*)t0)[13],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 883  cadadr */
t29=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t29))(3,t29,t28,((C_word*)t0)[13]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[12],lf[342]);
t27=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5286,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t26)){
t28=t27;
f_5286(t28,t26);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[12],lf[346]);
if(C_truep(t28)){
t29=t27;
f_5286(t29,t28);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[12],lf[347]);
if(C_truep(t29)){
t30=t27;
f_5286(t30,t29);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[12],lf[348]);
if(C_truep(t30)){
t31=t27;
f_5286(t31,t30);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[12],lf[349]);
if(C_truep(t31)){
t32=t27;
f_5286(t32,t31);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[12],lf[350]);
if(C_truep(t32)){
t33=t27;
f_5286(t33,t32);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[12],lf[351]);
if(C_truep(t33)){
t34=t27;
f_5286(t34,t33);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[12],lf[352]);
if(C_truep(t34)){
t35=t27;
f_5286(t35,t34);}
else{
t35=(C_word)C_eqp(((C_word*)t0)[12],lf[353]);
t36=t27;
f_5286(t36,(C_truep(t35)?t35:(C_word)C_eqp(((C_word*)t0)[12],lf[354])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}
else{
/* eval.scm: 900  compile */
t3=((C_word*)((C_word*)t0)[10])[1];
f_3805(t3,((C_word*)t0)[11],t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k5284 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_5286(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 889  ##sys#syntax-error-hook */
t2=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],lf[343],((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[83]);
if(C_truep(t2)){
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
/* eval.scm: 892  compile-call */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5476(t4,((C_word*)t0)[7],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[344]);
if(C_truep(t3)){
/* eval.scm: 896  ##sys#syntax-error-hook */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[7],lf[345],((C_word*)t0)[6]);}
else{
/* eval.scm: 898  compile-call */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5476(t4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}}}}

/* k5271 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 518  ##sys#cons */
t3=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k5267 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 518  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[94],t1);}

/* k5263 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 883  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a5233 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5234,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* eval.scm: 878  ##compiler#process-declaration */
t4=*((C_word*)lf[336]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k5221 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 880  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],lf[333],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5183 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5177 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 868  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],lf[327],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* loop in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_5133(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5133,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[320]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5145,a[2]=t2,a[3]=lf[322],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=lf[323],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 862  ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}}

/* a5154 in loop in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5155(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5155,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5163,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* eval.scm: 863  loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_5133(t6,t4,t5);}

/* k5161 in a5154 in loop in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[153],((C_word*)t0)[2],t1));}

/* a5144 in loop in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5153,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 862  cadar */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5151 in a5144 in loop in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 862  ##sys#do-the-right-thing */
t2=*((C_word*)lf[321]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k5125 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 858  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a5102 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5110,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 848  ##sys#compile-to-closure */
t4=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k5108 in a5102 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5070 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5072,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5075,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_apply(4,0,t2,*((C_word*)lf[315]+1),t1);}

/* k5073 in k5070 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5078,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 850  ##sys#lookup-runtime-requirements */
t3=*((C_word*)lf[317]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5076 in k5073 in k5070 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5078,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t1))){
t3=t2;
f_5085(2,t3,lf[314]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5095,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5097,a[2]=lf[316],tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}

/* a5096 in k5076 in k5073 in k5070 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5097,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[135],t2));}

/* k5093 in k5076 in k5073 in k5070 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 518  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[315],t1);}

/* k5083 in k5076 in k5073 in k5070 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 851  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5053 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* eval.scm: 845  compile */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3805(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5036 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 842  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4678,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[8]);
t6=t5;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[7];
t9=(C_truep(t8)?t8:lf[278]);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)t4)[1]);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4690,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t10,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5007,a[2]=t11,a[3]=t7,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 756  ##sys#extended-lambda-list? */
t13=*((C_word*)lf[118]+1);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,((C_word*)t4)[1]);}

/* k5005 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5007,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[309],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[310],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 757  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
f_4690(2,t2,C_SCHEME_UNDEFINED);}}

/* a5017 in k5005 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5018,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a5011 in k5005 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5012,2,t0,t1);}
/* eval.scm: 759  ##sys#expand-extended-lambda-list */
t2=*((C_word*)lf[126]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[77]+1));}

/* k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=lf[307],tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 762  ##sys#decompose-lambda-list */
t3=*((C_word*)lf[308]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4695,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4702,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4998,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5000,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=lf[306],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 767  ##sys#canonicalize-body */
t9=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,((C_word*)((C_word*)t0)[2])[1],t8,((C_word*)t0)[4]);}

/* a4999 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_5000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5000,3,t0,t1,t2);}
/* defined?306 */
t3=((C_word*)t0)[3];
f_3601(t3,t1,t2,((C_word*)t0)[2]);}

/* k4996 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 766  ##sys#compile-to-closure */
t2=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[74],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
t2=((C_word*)t0)[6];
switch(t2){
case C_fix(0):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[280],tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[282],tmp=(C_word)a,a+=6,tmp)));
case C_fix(1):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4755,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[284],tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[286],tmp=(C_word)a,a+=6,tmp)));
case C_fix(2):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[288],tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[290],tmp=(C_word)a,a+=6,tmp)));
case C_fix(3):
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[292],tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[294],tmp=(C_word)a,a+=6,tmp)));
default:
t3=(C_word)C_eqp(t2,C_fix(4));
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[296],tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[299],tmp=(C_word)a,a+=6,tmp)):(C_truep(((C_word*)t0)[4])?(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=lf[302],tmp=(C_word)a,a+=7,tmp):(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=lf[305],tmp=(C_word)a,a+=7,tmp))));}}

/* f_4960 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4960(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4960,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4966,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[304],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 833  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4965 */
static void f_4966(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_4966r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4966r(t0,t1,t2);}}

static void f_4966r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t3=(C_word)C_i_length(t2);
t4=(C_word)C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4986,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4990,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t6,*((C_word*)lf[297]+1),t2);}
else{
/* eval.scm: 837  ##sys#error */
t5=*((C_word*)lf[175]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[303],((C_word*)t0)[4],t3);}}

/* k4988 in a4965 */
static void f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 838  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4984 in a4965 */
static void f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4937 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4937,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4943,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=lf[301],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 828  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4942 */
static void f_4943(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr2r,(void*)f_4943r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4943r(t0,t1,t2);}}

static void f_4943r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(21);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4951,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4959,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=((C_word*)t0)[2];
if(C_truep((C_word)C_i_nullp(t2))){
t7=t5;
f_4959(2,t7,(C_word)C_a_i_list(&a,1,t2));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5417,a[2]=t8,a[3]=t2,a[4]=lf[300],tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_5417(t10,t5,t6,t2,C_SCHEME_FALSE);}}

/* do581 in a4942 */
static void C_fcall f_5417(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5417,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=(C_word)C_a_i_list(&a,1,t3);
t7=(C_word)C_i_setslot(t4,C_fix(1),t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t6=(C_word)C_fixnum_difference(t2,C_fix(1));
t7=(C_word)C_slot(t3,C_fix(1));
t11=t1;
t12=t6;
t13=t7;
t14=t3;
t1=t11;
t2=t12;
t3=t13;
t4=t14;
goto loop;}}

/* k4957 in a4942 */
static void f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[297]+1),t1);}

/* k4953 in a4942 */
static void f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 830  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4949 in a4942 */
static void f_4951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4915 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4915(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4915,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4921,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=lf[298],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 821  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4920 */
static void f_4921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=6) C_bad_argc(c,6);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4921,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4929,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4933,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 823  ##sys#vector */
t8=*((C_word*)lf[297]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t7,t2,t3,t4,t5);}

/* k4931 in a4920 */
static void f_4933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 823  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4927 in a4920 */
static void f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_4896 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4896(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4896,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[295],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 816  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4901 */
static void f_4902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,...){
C_word tmp;
C_word t6;
va_list v;
C_word *a,c2=c;
C_save_rest(t5,c2,6);
if(c<6) C_bad_min_argc(c,6);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr6r,(void*)f_4902r,6,t0,t1,t2,t3,t4,t5);}
else{
a=C_alloc((c-6)*3);
t6=C_restore_rest(a,C_rest_count(0));
f_4902r(t0,t1,t2,t3,t4,t5,t6);}}

static void f_4902r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t7=(C_word)C_a_i_vector(&a,5,t2,t3,t4,t5,t6);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,t8);}

/* f_4868 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4868(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4868,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[293],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 810  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4873 */
static void f_4874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4874,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4849 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4849,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4855,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[291],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 805  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4854 */
static void f_4855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc(c,5);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_4855r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4855r(t0,t1,t2,t3,t4,t5);}}

static void f_4855r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(8);
t6=(C_word)C_a_i_vector(&a,4,t2,t3,t4,t5);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t1,t7);}

/* f_4821 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4821(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4821,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[289],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 799  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4826 */
static void f_4827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4827,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4802 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4802(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4802,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4808,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[287],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 794  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4807 */
static void f_4808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_4808r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4808r(t0,t1,t2,t3,t4);}}

static void f_4808r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(C_word)C_a_i_vector(&a,3,t2,t3,t4);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[3]);
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t1,t6);}

/* f_4774 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4774,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4780,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[285],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 788  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4779 */
static void f_4780(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4780,3,t0,t1,t2);}
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* f_4755 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4755(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4755,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4761,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[283],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 783  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4760 */
static void f_4761(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_4761r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4761r(t0,t1,t2,t3);}}

static void f_4761r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t4=(C_word)C_a_i_vector(&a,2,t2,t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t5);}

/* f_4731 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4731,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4737,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[281],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 778  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4736 */
static void f_4737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4737,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f_4712 in k4700 in a4694 in k4688 in k4676 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4712,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=lf[279],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 773  decorate */
t4=((C_word*)t0)[3];
f_3766(t4,t1,t3,((C_word*)t0)[2]);}

/* a4717 */
static void f_4718(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_4718r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4718r(t0,t1,t2);}}

static void f_4718r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_a_i_vector(&a,1,t2);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}

/* k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4384,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[8]);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4665,a[2]=lf[276],tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a4664 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4665(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4665,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4393,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4399,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4653,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4659,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=lf[275],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 707  ##sys#canonicalize-body */
t7=*((C_word*)lf[152]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t4,t5,t6,((C_word*)t0)[6]);}

/* a4658 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4659,3,t0,t1,t2);}
/* defined?306 */
t3=((C_word*)t0)[3];
f_3601(t3,t1,t2,((C_word*)t0)[2]);}

/* k4651 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 706  ##sys#compile-to-closure */
t2=*((C_word*)lf[203]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[66],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4399,2,t0,t1);}
switch(((C_word*)t0)[8]){
case C_fix(1):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4408,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 711  cadar */
t4=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4438,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 714  cadar */
t4=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4525,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 718  cadar */
t4=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4591,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 726  cadar */
t4=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);
default:
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4594,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=lf[274],tmp=(C_word)a,a+=6,tmp);
/* map */
t4=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}}

/* a4640 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4641,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
/* eval.scm: 737  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3805(t4,t1,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4592 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4594,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4595,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[273],tmp=(C_word)a,a+=6,tmp));}

/* f_4595 in k4592 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4595,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 739  ##sys#make-vector */
t4=*((C_word*)lf[272]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}

/* k4597 */
static void f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4602,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4611,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=lf[271],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_4611(t6,t2,C_fix(0),((C_word*)t0)[2]);}

/* do469 in k4597 */
static void C_fcall f_4611(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4611,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4636,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t3,C_fix(0));
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,((C_word*)t0)[2]);}}

/* k4634 in do469 in k4597 */
static void f_4636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4611(t5,((C_word*)t0)[2],t3,t4);}

/* k4600 in k4597 */
static void f_4602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4602,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k4589 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 726  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4537,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 727  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}

/* k4585 in k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 727  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4535 in k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4537,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4543,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 729  cadar */
t5=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4581 in k4535 in k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 729  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4541 in k4535 in k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4579,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 730  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4577 in k4541 in k4535 in k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 730  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4544 in k4541 in k4535 in k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=lf[270],tmp=(C_word)a,a+=8,tmp));}

/* f_4547 in k4544 in k4541 in k4535 in k4532 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4561 */
static void f_4563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4567,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k4565 in k4561 */
static void f_4567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4569 in k4565 in k4561 */
static void f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4575,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4573 in k4569 in k4565 in k4561 */
static void f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4523 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 718  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4477 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4482,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4521,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 719  cadadr */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}

/* k4519 in k4477 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 719  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4480 in k4477 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4482,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4488,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 721  cadar */
t5=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k4515 in k4480 in k4477 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 721  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4486 in k4480 in k4477 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4488,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=lf[269],tmp=(C_word)a,a+=7,tmp));}

/* f_4489 in k4486 in k4480 in k4477 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4489,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4505,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4503 */
static void f_4505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k4507 in k4503 */
static void f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4509,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4511 in k4507 in k4503 */
static void f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4513,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4468 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 714  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4436 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4441,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 715  cadadr */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4464 in k4436 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 715  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4439 in k4436 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4441,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=lf[268],tmp=(C_word)a,a+=6,tmp));}

/* f_4442 in k4439 in k4436 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4442(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4442,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4456 */
static void f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4460 in k4456 */
static void f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4427 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 711  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4406 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4409,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=lf[267],tmp=(C_word)a,a+=5,tmp));}

/* f_4409 in k4406 in k4397 in k4391 in k4382 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4409,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4425,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4423 */
static void f_4425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4425,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,1,t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4278,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=lf[257],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=lf[265],tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t3,t4);}

/* a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4292,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* eval.scm: 683  compile */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3805(t6,t4,t5,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(C_word)C_i_zerop(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4350,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[258],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4363,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=lf[259],tmp=(C_word)a,a+=6,tmp)));}
else{
if(C_truep(*((C_word*)lf[197]+1))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4308,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 686  ##sys#hash-table-location */
t4=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[197]+1),((C_word*)t0)[2],*((C_word*)lf[198]+1));}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4335,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=lf[264],tmp=(C_word)a,a+=5,tmp));}}}

/* f_4335 in k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4335(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4335,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4343,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4341 */
static void f_4343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(0),t1));}

/* k4306 in k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4311(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 690  ##sys#error */
t3=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[263],((C_word*)t0)[2]);}}

/* k4309 in k4306 in k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4311,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=lf[260],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[2],a[3]=lf[262],tmp=(C_word)a,a+=4,tmp)));}

/* f_4327 in k4309 in k4306 in k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4327(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
/* eval.scm: 693  ##sys#error */
t2=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[261],((C_word*)t0)[2]);}

/* f_4318 in k4309 in k4306 in k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4318(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4318,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4324 */
static void f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* f_4363 in k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4363(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4363,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4369 */
static void f_4371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot((C_word)C_u_i_list_ref(((C_word*)t0)[4],((C_word*)t0)[3]),((C_word*)t0)[2],t1));}

/* f_4350 in k4294 in a4291 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4350,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4362,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4360 */
static void f_4362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_setslot(((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* a4285 in k4276 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
/* eval.scm: 682  lookup */
f_3559(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_i_length(t2);
switch(t3){
case C_fix(0):
/* eval.scm: 668  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3805(t4,((C_word*)t0)[4],lf[253],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(1):
t4=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 669  compile */
t5=((C_word*)((C_word*)t0)[5])[1];
f_3805(t5,((C_word*)t0)[4],t4,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
case C_fix(2):
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 670  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3805(t6,t4,t5,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);
default:
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4229,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_slot(t2,C_fix(0));
/* eval.scm: 674  compile */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3805(t6,t4,t5,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}}

/* k4227 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* eval.scm: 675  compile */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3805(t4,t2,t3,((C_word*)t0)[4],C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k4230 in k4227 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4235,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4250,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
t5=(C_word)C_slot(t4,C_fix(1));
/* eval.scm: 518  ##sys#cons */
t6=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[153],t5);}

/* k4248 in k4230 in k4227 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 676  compile */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3805(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4233 in k4230 in k4227 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4235,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=lf[255],tmp=(C_word)a,a+=6,tmp));}

/* f_4236 in k4233 in k4230 in k4227 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4238 */
static void f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4241 in k4238 */
static void f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4205 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4210,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* eval.scm: 671  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3805(t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4208 in k4205 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4211,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=lf[254],tmp=(C_word)a,a+=5,tmp));}

/* f_4211 in k4208 in k4205 in k4168 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4211,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4215,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4213 */
static void f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4111 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* eval.scm: 656  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3805(t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4114 in k4111 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* eval.scm: 657  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3805(t4,t2,t3,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4117 in k4114 in k4111 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
/* eval.scm: 659  compile */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3805(t5,t2,t4,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
/* eval.scm: 660  compile */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3805(t4,t2,lf[251],((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}}

/* k4120 in k4117 in k4114 in k4111 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4123,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=lf[250],tmp=(C_word)a,a+=6,tmp));}

/* f_4123 in k4120 in k4117 in k4114 in k4111 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4123,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4128 */
static void f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* f_4103 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4103,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* f_4069 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4069(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(0)));}

/* k4061 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4064,a[2]=t1,a[3]=lf[244],tmp=(C_word)a,a+=4,tmp));}

/* f_4064 in k4061 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4064(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4064,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(((C_word*)t0)[2],C_fix(1)));}

/* k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
switch(t2){
case C_fix(-1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3997,a[2]=lf[234],tmp=(C_word)a,a+=3,tmp));
case C_fix(0):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4005,a[2]=lf[235],tmp=(C_word)a,a+=3,tmp));
case C_fix(1):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=lf[236],tmp=(C_word)a,a+=3,tmp));
case C_fix(2):
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=lf[237],tmp=(C_word)a,a+=3,tmp));
case C_SCHEME_TRUE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=lf[238],tmp=(C_word)a,a+=3,tmp));
case C_SCHEME_FALSE:
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4037,a[2]=lf[239],tmp=(C_word)a,a+=3,tmp));
default:
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4045,a[2]=lf[240],tmp=(C_word)a,a+=3,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4047,a[2]=t2,a[3]=lf[241],tmp=(C_word)a,a+=4,tmp)));}}

/* f_4047 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4047(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_4045 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4045(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4045,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* f_4037 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4037(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_4029 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4029(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4029,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_4021 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4021(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_4013 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4013(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_4005 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_4005(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4005,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3997 in k3985 in k3970 in k3964 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3997(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* f_3941 in k3938 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3941(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3930 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3930(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_3928 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3928(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3917 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3917(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_3915 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3915(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(2));}

/* f_3907 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3907(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3907,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(1));}

/* f_3899 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3899(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* f_3891 in k3882 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3891(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(-1));}

/* a3822 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3823,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
t5=(C_word)C_i_zerop(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3865,a[2]=t3,a[3]=lf[219],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3874,a[2]=t3,a[3]=t2,a[4]=lf[220],tmp=(C_word)a,a+=5,tmp)));}
else{
if(C_truep(*((C_word*)lf[197]+1))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 587  ##sys#hash-table-location */
t6=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[197]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[2],a[3]=lf[224],tmp=(C_word)a,a+=4,tmp));}}}

/* f_3857 in a3822 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3857(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_retrieve(((C_word*)t0)[2]));}

/* k3834 in a3822 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_3839(2,t3,C_SCHEME_UNDEFINED);}
else{
/* eval.scm: 588  ##sys#syntax-error-hook */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[223],((C_word*)t0)[2]);}}

/* k3837 in k3834 in a3822 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3839,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=lf[222],tmp=(C_word)a,a+=6,tmp));}

/* f_3840 in k3837 in k3834 in a3822 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3840(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3840,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(C_word)C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* eval.scm: 595  ##sys#error */
t4=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[221],((C_word*)t0)[2]);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* f_3874 in a3822 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3874,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot((C_word)C_u_i_list_ref(t2,((C_word*)t0)[3]),((C_word*)t0)[2]));}

/* f_3865 in a3822 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3865,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t3,((C_word*)t0)[2]));}

/* a3816 in compile in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3817,2,t0,t1);}
/* eval.scm: 584  lookup */
f_3559(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* decorate in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3766,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3772,a[2]=lf[211],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3785,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=lf[215],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 572  ##sys#decorate-lambda */
t6=*((C_word*)lf[216]+1);
((C_proc5)C_retrieve_proc(t6))(5,t6,t1,t2,t4,t5);}

/* a3784 in decorate in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3785,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3793,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3797,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=lf[213],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 579  with-output-to-string */
t7=*((C_word*)lf[214]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* a3798 in a3784 in decorate in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
/* write296 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k3795 in a3784 in decorate in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 578  ##sys#make-lambda-info */
t2=*((C_word*)lf[212]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3791 in a3784 in decorate in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}

/* a3771 in decorate in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3772,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_lambdainfop(t2)));}

/* macroexpand-1-checked in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3713(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3713,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 560  ##sys#macroexpand-1-local */
t6=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t4);}

/* k3715 in macroexpand-1-checked in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3732,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,lf[81]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3764,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 563  defined? */
t6=((C_word*)t0)[2];
f_3601(t6,t5,lf[81],((C_word*)t0)[4]);}
else{
t5=t3;
f_3732(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* k3762 in k3715 in macroexpand-1-checked in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3732(t2,(C_word)C_i_not(t1));}

/* k3730 in k3715 in macroexpand-1-checked in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3732,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_3741(t5,(C_word)C_i_symbolp(t4));}
else{
t4=t3;
f_3741(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}}

/* k3739 in k3730 in k3715 in macroexpand-1-checked in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* eval.scm: 566  macroexpand-1-checked */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3713(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* defined? in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3601,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3607,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=lf[207],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=lf[208],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a3612 in defined? in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3613,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* a3606 in defined? in ##sys#compile-to-closure in k1596 in k1592 */
static void f_3607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3607,2,t0,t1);}
/* eval.scm: 535  lookup */
f_3559(t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lookup in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3559(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3559,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3565,a[2]=t5,a[3]=t2,a[4]=lf[205],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3565(t7,t1,t3,C_fix(0));}

/* loop in lookup in ##sys#compile-to-closure in k1596 in k1592 */
static void C_fcall f_3565(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3565,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* eval.scm: 530  values */
C_values(4,0,t1,C_SCHEME_FALSE,((C_word*)t0)[3]);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3683,a[2]=t5,a[3]=lf[204],tmp=(C_word)a,a+=4,tmp);
t7=f_3683(t6,t4,C_fix(0));
if(C_truep(t7)){
/* eval.scm: 531  values */
C_values(4,0,t1,t3,t7);}
else{
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_fixnum_plus(t3,C_fix(1));
/* eval.scm: 532  loop */
t11=t1;
t12=t8;
t13=t9;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}

/* loop in loop in lookup in ##sys#compile-to-closure in k1596 in k1592 */
static C_word C_fcall f_3683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t2);}
else{
t5=(C_word)C_slot(t1,C_fix(1));
t6=(C_word)C_fixnum_plus(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* ##sys#hash-table-location in k1596 in k1592 */
static void f_3493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3493,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3497,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_block_size(t2);
/* eval.scm: 499  ##sys#hash-symbol */
t7=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}

/* k3495 in ##sys#hash-table-location in k1596 in k1592 */
static void f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[6],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3505,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=lf[195],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_3505(t6,((C_word*)t0)[2],t2);}

/* loop in k3495 in ##sys#hash-table-location in k1596 in k1592 */
static void C_fcall f_3505(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3505,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[8])){
t3=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[7],((C_word*)t0)[6],C_SCHEME_TRUE);
t4=(C_word)C_a_i_cons(&a,2,t3,((C_word*)t0)[5]);
t5=(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[7],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 510  loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-for-each in k1596 in k1592 */
static void f_3447(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3447,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3453,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=t4,a[6]=lf[191],tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3453(t8,t1,C_fix(0));}

/* do277 in ##sys#hash-table-for-each in k1596 in k1592 */
static void C_fcall f_3453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3453,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3463,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[3],a[3]=lf[189],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_slot(((C_word*)t0)[2],t2);
/* eval.scm: 491  ##sys#for-each */
t6=*((C_word*)lf[190]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}}

/* a3471 in do277 in ##sys#hash-table-for-each in k1596 in k1592 */
static void f_3472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3472,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 492  p */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k3461 in do277 in ##sys#hash-table-for-each in k1596 in k1592 */
static void f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3453(t3,((C_word*)t0)[2],t2);}

/* ##sys#hash-table-set! in k1596 in k1592 */
static void f_3392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3392,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3396,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 477  ##sys#hash-symbol */
t6=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,(C_word)C_block_size(t2));}

/* k3394 in ##sys#hash-table-set! in k1596 in k1592 */
static void f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3396,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3404,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=lf[186],tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3404(t6,((C_word*)t0)[2],t2);}

/* loop in k3394 in ##sys#hash-table-set! in k1596 in k1592 */
static void C_fcall f_3404(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3404,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[5]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_i_setslot(((C_word*)t0)[4],((C_word*)t0)[3],t5));}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t4,C_fix(0));
t6=(C_word)C_eqp(((C_word*)t0)[7],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(t4,C_fix(1),((C_word*)t0)[6]));}
else{
t7=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 485  loop */
t11=t1;
t12=t7;
t1=t11;
t2=t12;
goto loop;}}}

/* ##sys#hash-table-ref in k1596 in k1592 */
static void f_3347(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3347,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3351,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 466  ##sys#hash-symbol */
t5=*((C_word*)lf[182]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,(C_word)C_block_size(t2));}

/* k3349 in ##sys#hash-table-ref in k1596 in k1592 */
static void f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3351,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[3],a[3]=lf[184],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,f_3360(t3,t2));}

/* loop in k3349 in ##sys#hash-table-ref in k1596 in k1592 */
static C_word C_fcall f_3360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
t2=(C_word)C_eqp(t1,C_SCHEME_END_OF_LIST);
if(C_truep(t2)){
return(C_SCHEME_FALSE);}
else{
t3=(C_word)C_slot(t1,C_fix(0));
t4=(C_word)C_slot(t3,C_fix(0));
t5=(C_word)C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
return((C_word)C_slot(t3,C_fix(1)));}
else{
t6=(C_word)C_slot(t1,C_fix(1));
t8=t6;
t1=t8;
goto loop;}}}

/* ##sys#hash-symbol in k1596 in k1592 */
static void f_3332(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3332,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_fixnum_modulo(((C_word*)((C_word*)t0)[2])[1],t3));}
else{
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_word)C_hash_string(t5);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_fixnum_modulo(t6,t3));}}

/* ##sys#expand-curried-define in k1596 in k1592 */
static void f_3272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3272,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3275,a[2]=t7,a[3]=t5,a[4]=lf[180],tmp=(C_word)a,a+=5,tmp));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3327,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 448  loop */
t10=((C_word*)t7)[1];
f_3275(t10,t9,t2,t3);}

/* k3325 in ##sys#expand-curried-define in k1596 in k1592 */
static void f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)((C_word*)t0)[2])[1],t1));}

/* loop in ##sys#expand-curried-define in k1596 in k1592 */
static void C_fcall f_3275(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3275,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_symbolp(t4))){
t5=(C_word)C_slot(t2,C_fix(0));
t6=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3293,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 440  ##sys#cons */
t9=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t3);}
else{
t5=(C_word)C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3316,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 440  ##sys#cons */
t9=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t3);}}

/* k3314 in loop in ##sys#expand-curried-define in k1596 in k1592 */
static void f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 440  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k3310 in loop in ##sys#expand-curried-define in k1596 in k1592 */
static void f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 447  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3275(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3291 in loop in ##sys#expand-curried-define in k1596 in k1592 */
static void f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 440  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* ##sys#match-expression in k1596 in k1592 */
static void f_3181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3181,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3184,a[2]=t8,a[3]=t4,a[4]=t6,a[5]=lf[178],tmp=(C_word)a,a+=6,tmp));
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3270,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 435  mwalk */
t11=((C_word*)t8)[1];
f_3184(t11,t10,t2,t3);}

/* k3268 in ##sys#match-expression in k1596 in k1592 */
static void f_3270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}

/* mwalk in ##sys#match-expression in k1596 in k1592 */
static void C_fcall f_3184(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3184,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_not((C_word)C_blockp(t3));
t5=(C_truep(t4)?t4:(C_word)C_i_not((C_word)C_pairp(t3)));
if(C_truep(t5)){
t6=(C_word)C_i_assq(t3,((C_word*)((C_word*)t0)[4])[1]);
if(C_truep(t6)){
t7=(C_word)C_slot(t6,C_fix(1));
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_i_equalp(t2,t7));}
else{
if(C_truep((C_word)C_i_memq(t3,((C_word*)t0)[3]))){
t7=(C_word)C_a_i_cons(&a,2,t3,t2);
t8=(C_word)C_a_i_cons(&a,2,t7,((C_word*)((C_word*)t0)[4])[1]);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_TRUE);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_eqp(t2,t3));}}}
else{
t6=(C_word)C_i_not((C_word)C_blockp(t2));
t7=(C_truep(t6)?t6:(C_word)C_i_not((C_word)C_pairp(t2)));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3239,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(C_word)C_slot(t2,C_fix(0));
t10=(C_word)C_slot(t3,C_fix(0));
/* eval.scm: 432  mwalk */
t17=t8;
t18=t9;
t19=t10;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k3237 in mwalk in ##sys#match-expression in k1596 in k1592 */
static void f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* eval.scm: 433  mwalk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3184(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##sys#canonicalize-body in k1596 in k1592 */
static void f_2727(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_2727r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2727r(t0,t1,t2,t3,t4);}}

static void f_2727r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2731,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_2731(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_2731(2,t7,(C_word)C_i_car(t4));}
else{
/* eval.scm: 351  ##sys#error */
t7=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2731,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2733,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=lf[163],tmp=(C_word)a,a+=6,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,a[5]=lf[174],tmp=(C_word)a,a+=6,tmp));
/* eval.scm: 416  expand */
t8=((C_word*)t5)[1];
f_2913(t8,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void C_fcall f_2913(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2913,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=lf[173],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2919(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void C_fcall f_2919(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2919,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_pairp(t2))){
t7=(C_word)C_slot(t2,C_fix(0));
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_i_pairp(t7);
t10=(C_truep(t9)?(C_word)C_slot(t7,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=t10,a[7]=t2,a[8]=t6,a[9]=t5,a[10]=t4,a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_symbolp(t10))){
/* eval.scm: 382  lookup */
t12=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t10);}
else{
t12=t11;
f_2953(2,t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 381  fini */
t11=((C_word*)((C_word*)t0)[5])[1];
f_2733(t11,t1,t3,t4,t5,t6,t2);}}
else{
/* eval.scm: 377  fini */
t7=((C_word*)((C_word*)t0)[5])[1];
f_2733(t7,t1,t3,t4,t5,t6,t2);}}

/* k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
if(C_truep(t1)){
/* eval.scm: 383  fini */
t2=((C_word*)((C_word*)t0)[13])[1];
f_2733(t2,((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(C_word)C_eqp(lf[154],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 385  ##sys#check-syntax */
t4=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[154],((C_word*)t0)[3],lf[170],C_SCHEME_FALSE);}
else{
t3=(C_word)C_eqp(lf[155],((C_word*)t0)[6]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 406  ##sys#check-syntax */
t5=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[155],((C_word*)t0)[3],lf[171],C_SCHEME_FALSE);}
else{
t4=(C_word)C_eqp(lf[153],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3111,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* eval.scm: 409  ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[153],((C_word*)t0)[3],lf[172],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3125,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[3],tmp=(C_word)a,a+=12,tmp);
/* eval.scm: 412  ##sys#macroexpand-0 */
t6=lf[59];
f_1659(t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}}}}}

/* k3123 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3125,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[11],t1);
if(C_truep(t2)){
/* eval.scm: 414  fini */
t3=((C_word*)((C_word*)t0)[10])[1];
f_2733(t3,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* eval.scm: 415  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2919(t4,((C_word*)t0)[9],t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* k3109 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3118,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 410  ##sys#append */
t4=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k3116 in k3109 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 410  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2919(t2,((C_word*)t0)[6],t1,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3081 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[9]);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[8]);
t4=(C_word)C_i_caddr(((C_word*)t0)[9]);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
/* eval.scm: 407  loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2919(t6,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3,t5);}

/* k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2970,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=lf[169],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_2970(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2 in k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void C_fcall f_2970(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2970,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep((C_word)C_i_pairp(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3017,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 397  ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[154],t2,lf[165],C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3035,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 400  ##sys#check-syntax */
t6=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[154],t2,lf[166],C_SCHEME_FALSE);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* eval.scm: 389  ##sys#check-syntax */
t5=*((C_word*)lf[89]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[154],t2,lf[168],C_SCHEME_FALSE);}}

/* k2981 in loop2 in k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t3=(C_word)C_i_cddr(((C_word*)t0)[8]);
t4=(C_word)C_i_pairp(t3);
t5=(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[8]):lf[167]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
/* eval.scm: 390  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_2919(t7,((C_word*)t0)[5],((C_word*)t0)[4],t2,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3033 in loop2 in k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3035,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[10],C_fix(0));
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3050,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3054,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(((C_word*)t0)[10],C_fix(1));
t7=(C_word)C_i_cddr(((C_word*)t0)[2]);
/* eval.scm: 347  ##sys#cons */
t8=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k3052 in k3033 in loop2 in k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 347  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k3048 in k3033 in loop2 in k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3050,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[8]);
/* eval.scm: 401  loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_2919(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3015 in loop2 in k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 398  ##sys#expand-curried-define */
t4=*((C_word*)lf[164]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3026 in k3015 in loop2 in k2963 in k2951 in loop in expand in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3028,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[154],t1);
/* eval.scm: 398  loop2 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2970(t3,((C_word*)t0)[2],t2);}

/* fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void C_fcall f_2733(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2733,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_nullp(t2);
t8=(C_truep(t7)?(C_word)C_i_nullp(t4):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2745,a[2]=t6,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=lf[156],tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_2745(t12,t1,t6,C_SCHEME_END_OF_LIST);}
else{
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2815,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t6,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* eval.scm: 361  reverse */
t10=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t10))(3,t10,t9,t2);}}

/* k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2826,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=lf[162],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2905,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_apply(5,0,t5,*((C_word*)lf[115]+1),t1,((C_word*)t0)[3]);}

/* k2903 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 362  ##sys#map */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2892 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2893(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2893,3,t0,t1,t2);}
t3=(C_word)C_a_i_list(&a,1,lf[161]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,t2,t3));}

/* k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2830,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2834,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2883,a[2]=lf[160],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 364  reverse */
t6=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k2889 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 364  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2882 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2883(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2883,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[96],t2,t3));}

/* k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2838,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2844,a[2]=((C_word*)t0)[5],a[3]=lf[159],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* eval.scm: 371  reverse */
t6=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k2875 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2881,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 372  reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2879 in k2875 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 365  map */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2843 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2844,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2848,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 366  ##sys#map */
t5=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[125]+1),t2);}

/* k2846 in a2843 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[136],C_SCHEME_END_OF_LIST,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2859,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2863,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2867,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2869,a[2]=lf[158],tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 370  map */
t7=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,t6,((C_word*)t0)[2],t1);}

/* a2868 in k2846 in a2843 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2869,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,3,lf[96],t2,t3));}

/* k2865 in k2846 in a2843 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2861 in k2846 in a2843 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k2857 in k2846 in a2843 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2859,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,3,lf[157],((C_word*)t0)[2],t1));}

/* k2840 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2836 in k2832 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2828 in k2824 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2820 in k2813 in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* loop in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void C_fcall f_2745(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2745,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2764,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_pairp(t4))){
t6=(C_word)C_slot(t4,C_fix(0));
t7=(C_word)C_a_i_list(&a,2,lf[154],lf[155]);
t8=t5;
f_2764(t8,(C_word)C_i_memq(t6,t7));}
else{
t6=t5;
f_2764(t6,C_SCHEME_FALSE);}}
else{
/* eval.scm: 347  ##sys#cons */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[153],((C_word*)t0)[2]);}}

/* k2762 in loop in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void C_fcall f_2764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2764,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2771,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2775,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 359  reverse */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
/* eval.scm: 360  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2745(t4,((C_word*)t0)[8],t2,t3);}}

/* k2773 in k2762 in loop in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2783,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 359  expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2913(t3,t2,((C_word*)t0)[2]);}

/* k2781 in k2773 in k2762 in loop in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2783,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* eval.scm: 359  ##sys#append */
t3=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2769 in k2762 in loop in fini in k2729 in ##sys#canonicalize-body in k1596 in k1592 */
static void f_2771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 347  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[153],t1);}

/* ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2208,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2211,a[2]=t2,a[3]=t4,a[4]=lf[127],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t5,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t9,a[8]=t7,a[9]=lf[149],tmp=(C_word)a,a+=10,tmp));
t13=((C_word*)t11)[1];
f_2230(t13,t1,C_fix(0),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,t2);}

/* loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2230(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word *a;
loop:
a=C_alloc(85);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2230,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep((C_word)C_i_nullp(t6))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[8],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 276  reverse */
t9=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t3);}
else{
/* eval.scm: 276  reverse */
t8=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
if(C_truep((C_word)C_i_symbolp(t6))){
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(2)))){
/* eval.scm: 299  err */
t7=((C_word*)t0)[4];
f_2211(t7,t1,lf[139]);}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2474,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t8)){
t9=t7;
f_2474(t9,C_SCHEME_UNDEFINED);}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t10=t7;
f_2474(t10,t9);}}}
else{
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_slot(t6,C_fix(0));
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(t7,lf[120]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t11=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t11)){
t12=t10;
f_2506(t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2525,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 311  gensym */
t13=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}}
else{
t10=(C_word)C_eqp(t7,lf[119]);
if(C_truep(t10)){
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,C_fix(1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[7],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_pairp(t8))){
t12=(C_word)C_slot(t8,C_fix(0));
t13=t11;
f_2543(t13,(C_word)C_i_symbolp(t12));}
else{
t12=t11;
f_2543(t12,C_SCHEME_FALSE);}}
else{
/* eval.scm: 323  err */
t11=((C_word*)t0)[4];
f_2211(t11,t1,lf[142]);}}
else{
t11=(C_word)C_eqp(t7,lf[121]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t13=((C_word*)((C_word*)t0)[8])[1];
if(C_truep(t13)){
t14=t12;
f_2589(t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2608,a[2]=t12,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 325  gensym */
t15=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t15))(2,t15,t14);}}
else{
if(C_truep((C_word)C_i_symbolp(t7))){
t12=t2;
switch(t12){
case C_fix(0):
t13=(C_word)C_a_i_cons(&a,2,t7,t3);
/* eval.scm: 332  loop */
t34=t1;
t35=C_fix(0);
t36=t13;
t37=C_SCHEME_END_OF_LIST;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(1):
t13=(C_word)C_a_i_list(&a,2,t7,C_SCHEME_FALSE);
t14=(C_word)C_a_i_cons(&a,2,t13,t4);
/* eval.scm: 333  loop */
t34=t1;
t35=C_fix(1);
t36=t3;
t37=t14;
t38=C_SCHEME_END_OF_LIST;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;
case C_fix(2):
/* eval.scm: 334  err */
t13=((C_word*)t0)[4];
f_2211(t13,t1,lf[144]);
default:
t13=(C_word)C_a_i_list(&a,1,t7);
t14=(C_word)C_a_i_cons(&a,2,t13,t5);
/* eval.scm: 335  loop */
t34=t1;
t35=C_fix(3);
t36=t3;
t37=t4;
t38=t14;
t39=t8;
t1=t34;
t2=t35;
t3=t36;
t4=t37;
t5=t38;
t6=t39;
goto loop;}}
else{
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2670,a[2]=t5,a[3]=t8,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t7,a[8]=t1,a[9]=((C_word*)t0)[4],a[10]=t2,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t7))){
t13=(C_word)C_i_length(t7);
t14=t12;
f_2670(t14,(C_word)C_eqp(C_fix(2),t13));}
else{
t13=t12;
f_2670(t13,C_SCHEME_FALSE);}}}}}}
else{
/* eval.scm: 305  err */
t7=((C_word*)t0)[4];
f_2211(t7,t1,lf[148]);}}}}

/* k2668 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2670,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
switch(t2){
case C_fix(0):
/* eval.scm: 338  err */
t3=((C_word*)t0)[9];
f_2211(t3,((C_word*)t0)[8],lf[145]);
case C_fix(1):
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
/* eval.scm: 339  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2230(t4,((C_word*)t0)[8],C_fix(1),((C_word*)t0)[4],t3,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
case C_fix(2):
/* eval.scm: 340  err */
t3=((C_word*)t0)[9];
f_2211(t3,((C_word*)t0)[8],lf[146]);
default:
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[2]);
/* eval.scm: 341  loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2230(t4,((C_word*)t0)[8],C_fix(3),((C_word*)t0)[4],((C_word*)t0)[6],t3,((C_word*)t0)[3]);}}
else{
/* eval.scm: 342  err */
t2=((C_word*)t0)[9];
f_2211(t2,((C_word*)t0)[8],lf[147]);}}

/* k2606 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2589(t3,t2);}

/* k2587 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2589(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_less_or_equal_p(((C_word*)t0)[8],C_fix(3)))){
/* eval.scm: 327  loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_2230(t2,((C_word*)t0)[6],C_fix(3),((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 328  err */
t2=((C_word*)t0)[2];
f_2211(t2,((C_word*)t0)[6],lf[143]);}}

/* k2541 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2543(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2543,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t3)){
t4=t2;
f_2546(t4,C_SCHEME_UNDEFINED);}
else{
t4=(C_word)C_slot(((C_word*)t0)[9],C_fix(0));
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=t2;
f_2546(t6,t5);}}
else{
/* eval.scm: 322  err */
t2=((C_word*)t0)[2];
f_2211(t2,((C_word*)t0)[6],lf[141]);}}

/* k2544 in k2541 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2546(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* eval.scm: 321  loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2230(t5,((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t4);}

/* k2523 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2506(t3,t2);}

/* k2504 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[7],C_fix(0));
if(C_truep(t2)){
/* eval.scm: 313  loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2230(t3,((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);}
else{
/* eval.scm: 314  err */
t3=((C_word*)t0)[2];
f_2211(t3,((C_word*)t0)[5],lf[140]);}}

/* k2472 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
/* eval.scm: 303  loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2230(t3,((C_word*)t0)[4],C_fix(4),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k2451 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 276  ##sys#append */
t2=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[4]))){
t3=t2;
f_2248(t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2383,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[6],a[3]=lf[138],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2446,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 287  reverse */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[4]);}}

/* k2444 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2389(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2389,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2400,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2442,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_slot(t3,C_fix(1));
/* eval.scm: 266  string->keyword */
t8=*((C_word*)lf[137]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}

/* k2440 in a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,lf[135],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2412,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2416,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[2]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* eval.scm: 261  ##sys#cons */
t9=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_SCHEME_END_OF_LIST,t8);}
else{
t6=t4;
f_2416(t6,C_SCHEME_END_OF_LIST);}}

/* k2428 in k2440 in a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[136],t1);}

/* k2424 in k2440 in a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2426,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2416(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2414 in k2440 in a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2410 in k2440 in a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2402 in a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[134],t1);}

/* k2398 in a2388 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k2385 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2381 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[133],t1);}

/* k2377 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2248(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t3=t2;
f_2251(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)((C_word*)t0)[4])[1];
if(C_truep(t4)){
t5=t3;
f_2260(t5,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[3]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[6]);
t6=t3;
f_2260(t6,(C_word)C_i_nullp(t5));}
else{
t5=t3;
f_2260(t5,C_SCHEME_FALSE);}}}}

/* k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2260,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2271,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2283,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 291  caar */
t5=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}
else{
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_i_nullp(((C_word*)t0)[3]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2308,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[6],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 293  reverse */
t8=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2327,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[7],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[6],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2339,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 295  reverse */
t9=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)t0)[5]);}}}

/* k2337 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2339,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=(C_truep(t2)?t2:((C_word*)((C_word*)t0)[3])[1]);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 295  ##sys#append */
t5=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}

/* k2333 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2329 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2325 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[132],t1);}

/* k2321 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2323,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2251(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2314 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2310 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k2306 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[131],t1);}

/* k2302 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2251(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2281 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2291,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 291  cadar */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2289 in k2281 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2291,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,lf[128],((C_word*)((C_word*)t0)[5])[1],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,1,t3);
/* eval.scm: 261  ##sys#cons */
t5=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k2269 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 261  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[81],t1);}

/* k2265 in k2258 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2251(t2,(C_word)C_a_i_list(&a,1,t1));}

/* k2249 in k2246 in k2242 in loop in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2251(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 275  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* err in ##sys#expand-extended-lambda-list in k1596 in k1592 */
static void C_fcall f_2211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2211,NULL,3,t0,t1,t2);}
/* eval.scm: 265  errh */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* ##sys#extended-lambda-list? in k1596 in k1592 */
static void f_2165(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2165,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2171,a[2]=t4,a[3]=lf[122],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_2171(t6,t1,t2);}

/* loop in ##sys#extended-lambda-list? in k1596 in k1592 */
static void C_fcall f_2171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2171,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_eqp(t3,lf[119]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2190,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2190(t6,t4);}
else{
t6=(C_word)C_eqp(t3,lf[120]);
t7=t5;
f_2190(t7,(C_truep(t6)?t6:(C_word)C_eqp(t3,lf[121])));}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k2188 in loop in ##sys#extended-lambda-list? in k1596 in k1592 */
static void C_fcall f_2190(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* eval.scm: 259  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2171(t3,((C_word*)t0)[4],t2);}}

/* ##sys#undefine-non-standard-macros in k1596 in k1592 */
static void f_2094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2094,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2098,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 227  ##sys#append */
t4=*((C_word*)lf[115]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[116]);}

/* k2096 in ##sys#undefine-non-standard-macros in k1596 in k1592 */
static void f_2098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2098,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2103,a[2]=t1,a[3]=t3,a[4]=lf[114],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2103(t5,((C_word*)t0)[2],C_fix(0));}

/* do113 in k2096 in ##sys#undefine-non-standard-macros in k1596 in k1592 */
static void C_fcall f_2103(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2103,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,C_fix(301)))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2124,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(*((C_word*)lf[45]+1),t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2130,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=lf[113],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2130(t8,t3,t4);}}

/* loop in do113 in k2096 in ##sys#undefine-non-standard-macros in k1596 in k1592 */
static void C_fcall f_2130(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2130,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t5,((C_word*)t0)[3]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2156,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 238  loop */
t8=t6;
t9=t4;
t1=t8;
t2=t9;
goto loop;}
else{
/* eval.scm: 239  loop */
t8=t1;
t9=t4;
t1=t8;
t2=t9;
goto loop;}}}

/* k2154 in loop in do113 in k2096 in ##sys#undefine-non-standard-macros in k1596 in k1592 */
static void f_2156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2156,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2122 in do113 in k2096 in ##sys#undefine-non-standard-macros in k1596 in k1592 */
static void f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(*((C_word*)lf[45]+1),((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2103(t4,((C_word*)t0)[2],t3);}

/* macroexpand-1 in k1596 in k1592 */
static void f_2077(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2077r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2077r(t0,t1,t2,t3);}}

static void f_2077r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
/* eval.scm: 219  ##sys#macroexpand-0 */
t6=lf[59];
f_1659(t6,t1,t2,t5);}

/* macroexpand in k1596 in k1592 */
static void f_2041(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2041r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2041r(t0,t1,t2,t3);}}

static void f_2041r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):C_SCHEME_END_OF_LIST);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2050,a[2]=t7,a[3]=t5,a[4]=lf[107],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2050(t9,t1,t2);}

/* loop in macroexpand in k1596 in k1592 */
static void C_fcall f_2050(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2050,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=lf[105],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[2],a[3]=lf[106],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a2061 in loop in macroexpand in k1596 in k1592 */
static void f_2062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2062,4,t0,t1,t2,t3);}
if(C_truep(t3)){
/* eval.scm: 215  loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2050(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* a2055 in loop in macroexpand in k1596 in k1592 */
static void f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
/* eval.scm: 213  ##sys#macroexpand-0 */
t2=lf[59];
f_1659(t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#macroexpand-1-local in k1596 in k1592 */
static void f_2035(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2035,4,t0,t1,t2,t3);}
/* eval.scm: 205  ##sys#macroexpand-0 */
t4=lf[59];
f_1659(t4,t1,t2,t3);}

/* ##sys#interpreter-toplevel-macroexpand-hook in k1596 in k1592 */
static void f_2032(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2032,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#compiler-toplevel-macroexpand-hook in k1596 in k1592 */
static void f_2029(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2029,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1659(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1659,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],a[3]=lf[76],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1808,a[2]=t4,a[3]=t3,a[4]=lf[80],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_symbolp(t6))){
t8=(C_word)C_eqp(t6,lf[81]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1896,a[2]=t2,a[3]=t1,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 174  ##sys#check-syntax */
t10=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[81],t7,lf[91]);}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1969,a[2]=t6,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_truep((C_word)C_eqp(t6,lf[94]))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t6,lf[96]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
if(C_truep((C_word)C_i_pairp(t7))){
t10=(C_word)C_slot(t7,C_fix(0));
t11=t9;
f_1969(t11,(C_word)C_i_pairp(t10));}
else{
t10=t9;
f_1969(t10,C_SCHEME_FALSE);}}
else{
t10=t9;
f_1969(t10,C_SCHEME_FALSE);}}}
else{
/* eval.scm: 197  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}
else{
/* eval.scm: 198  values */
C_values(4,0,t1,t2,C_SCHEME_FALSE);}}

/* k1967 in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1969,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1975,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 190  ##sys#check-syntax */
t4=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[94],((C_word*)t0)[6],lf[95]);}
else{
/* eval.scm: 196  expand */
t2=((C_word*)t0)[4];
f_1808(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1973 in k1967 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(0));
t4=(C_word)C_a_i_list(&a,2,lf[92],t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t7=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
/* eval.scm: 192  append */
t8=*((C_word*)lf[93]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t2,t5,t6,t7);}

/* k1980 in k1973 in k1967 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 191  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1908,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* eval.scm: 177  ##sys#check-syntax */
t4=*((C_word*)lf[89]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[81],((C_word*)t0)[4],lf[90]);}
else{
/* eval.scm: 185  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1942,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1950,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1956,a[2]=lf[88],tmp=(C_word)a,a+=3,tmp);
/* map */
t9=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t2);}

/* a1955 in k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1956,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_car(t2));}

/* k1948 in k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* eval.scm: 126  ##sys#cons */
t3=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k1944 in k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 126  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[87],t1);}

/* k1940 in k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,3,lf[84],t3,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1930,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 183  ##sys#map */
t6=*((C_word*)lf[85]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[86]+1),((C_word*)t0)[2]);}

/* k1928 in k1940 in k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 126  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1920 in k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 126  ##sys#cons */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k1916 in k1906 in k1894 in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 179  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* expand in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1808(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1808,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t3,((C_word*)t0)[3]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_slot(t4,C_fix(1));
t7=t6;
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1828,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* eval.scm: 158  ##sys#hash-table-ref */
t6=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,*((C_word*)lf[45]+1),t3);}}

/* k1826 in expand in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1828,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1836,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=lf[79],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1836(t5,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
/* eval.scm: 167  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* scan in k1826 in expand in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1836(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1836,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1850,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 164  call-handler */
t4=((C_word*)t0)[6];
f_1662(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 165  scan */
t6=t1;
t7=t3;
t1=t6;
t2=t7;
goto loop;}
else{
/* eval.scm: 166  ##sys#syntax-error-hook */
t3=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[78],((C_word*)t0)[3]);}}}

/* k1848 in scan in k1826 in expand in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 164  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k1820 in expand in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 157  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1662,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1669,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1671,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=lf[74],tmp=(C_word)a,a+=7,tmp);
/* call-with-current-continuation */
t7=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1671(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1671,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1677,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=lf[68],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1784,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[72],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[73]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1783 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=lf[69],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1796,a[2]=((C_word*)t0)[2],a[3]=lf[71],tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1795 in a1783 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1796(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1796r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1796r(t0,t1,t2);}}

static void f_1796r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1802,a[2]=t2,a[3]=lf[70],tmp=(C_word)a,a+=4,tmp);
/* g6163 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1801 in a1795 in a1783 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1802,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1789 in a1783 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
/* eval.scm: 154  handler */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1677(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1677,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=lf[67],tmp=(C_word)a,a+=6,tmp);
/* g6163 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1682 in a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc(c,2);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1691,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[4],lf[61]))){
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t5=t3;
f_1694(t5,(C_word)C_i_memv(lf[66],t4));}
else{
t4=t3;
f_1694(t4,C_SCHEME_FALSE);}}

/* k1692 in a1682 in a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1694(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1694,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1705,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1711,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=lf[65],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1711(t8,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_1691(t2,((C_word*)t0)[5]);}}

/* copy in k1692 in a1682 in a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1711,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1730,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_eqp(lf[62],t3);
if(C_truep(t6)){
if(C_truep((C_word)C_i_pairp(t4))){
t7=(C_word)C_i_car(t4);
t8=t5;
f_1730(t8,(C_word)C_i_stringp(t7));}
else{
t7=t5;
f_1730(t7,C_SCHEME_FALSE);}}
else{
t7=t5;
f_1730(t7,C_SCHEME_FALSE);}}}

/* k1728 in copy in k1692 in a1682 in a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_i_car(((C_word*)t0)[6]);
/* eval.scm: 148  string-append */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,lf[63],t3,lf[64],t4);}
else{
/* eval.scm: 152  copy */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1711(t2,((C_word*)t0)[5],((C_word*)t0)[6]);}}

/* k1739 in k1728 in copy in k1692 in a1682 in a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
t3=(C_word)C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,lf[62],t3));}

/* k1703 in k1692 in a1682 in a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1705,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1691(t2,(C_word)C_a_i_record(&a,3,lf[61],((C_word*)t0)[2],t1));}

/* k1689 in a1682 in a1676 in a1670 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void C_fcall f_1691(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* eval.scm: 132  ##sys#abort */
t2=*((C_word*)lf[60]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1667 in call-handler in ##sys#macroexpand-0 in k1596 in k1592 */
static void f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* undefine-macro! in k1596 in k1592 */
static void f_1650(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1650,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[56]);
t4=t2;
/* eval.scm: 117  ##sys#hash-table-set! */
t5=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[45]+1),t4,C_SCHEME_FALSE);}

/* macro? in k1596 in k1592 */
static void f_1632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1632,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[53]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* eval.scm: 114  ##sys#hash-table-ref */
t5=*((C_word*)lf[54]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[45]+1),t2);}

/* k1640 in macro? in k1596 in k1592 */
static void f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* ##sys#register-macro in k1596 in k1592 */
static void f_1616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1616,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1622,a[2]=t3,a[3]=lf[51],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 108  ##sys#hash-table-set! */
t5=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[45]+1),t2,t4);}

/* a1621 in ##sys#register-macro in k1596 in k1592 */
static void f_1622(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1622,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
C_apply(4,0,t1,((C_word*)t0)[2],t3);}

/* ##sys#register-macro-2 in k1596 in k1592 */
static void f_1600(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1600,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1606,a[2]=t3,a[3]=lf[47],tmp=(C_word)a,a+=4,tmp);
/* eval.scm: 102  ##sys#hash-table-set! */
t5=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,*((C_word*)lf[45]+1),t2,t4);}

/* a1605 in ##sys#register-macro-2 in k1596 in k1592 */
static void f_1606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1606,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
/* eval.scm: 104  handler */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}
/* end of file */
