/* Generated from pcre.scm by the Chicken compiler
   2005-09-10 23:11
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: pcre.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file upcre.c -explicit-use
   unit: regex
*/

#include "chicken.h"

#include <pcre.h>

#define C_REGEX_OVECTOR_SIZE         256

static const char *C_regex_error;
static int C_regex_error_offset;
static int C_regex_ovector[ C_REGEX_OVECTOR_SIZE * 2 ];


static C_TLS C_word lf[52];


/* from k527 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub62(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub62(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * buffer=(void * )C_c_pointer_or_null(C_a0);
int c;pcre_fullinfo(buffer, NULL, PCRE_INFO_CAPTURECOUNT, &c);return(c);
C_return:
#undef return

return C_r;}

/* from k514 in re-match in k279 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub51(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub51(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * buffer=(void * )C_c_pointer_or_null(C_a0);
char * str=(char * )C_string_or_null(C_a1);
int start=(int )C_unfix(C_a2);
int range=(int )C_unfix(C_a3);
return(pcre_exec(buffer, NULL, str, start + range, start, 0, C_regex_ovector, C_REGEX_OVECTOR_SIZE));
C_return:
#undef return

return C_r;}

/* from re-register-index in k279 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub30(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub30(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_regex_ovector[ i ]);
C_return:
#undef return

return C_r;}

/* from k296 */
static C_word C_fcall stub12(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub12(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
pcre_free(t0);
return C_r;}

/* from k286 in re-compile-pattern in k279 */
#define return(x) C_cblock C_r = (C_mpointer_or_false(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub4(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub4(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * rx=(char * )C_string_or_null(C_a0);
unsigned int flags=(unsigned int )C_num_to_unsigned_int(C_a1);
return(pcre_compile(rx, flags, &C_regex_error, &C_regex_error_offset, NULL));
C_return:
#undef return

return C_r;}

C_externexport void C_regex_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_281(C_word c,C_word t0,C_word t1) C_noret;
static void f_1409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1413(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1421(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1453(C_word c,C_word t0,C_word t1) C_noret;
static void f_1440(C_word c,C_word t0,C_word t1) C_noret;
static void f_1443(C_word c,C_word t0,C_word t1) C_noret;
static void f_1372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1378(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1397(C_word c,C_word t0,C_word t1) C_noret;
static void f_1404(C_word c,C_word t0,C_word t1) C_noret;
static void f_1283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1295(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1297(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1367(C_word c,C_word t0,C_word t1) C_noret;
static void f_1363(C_word c,C_word t0,C_word t1) C_noret;
static void f_1356(C_word c,C_word t0,C_word t1) C_noret;
static void f_1340(C_word c,C_word t0,C_word t1) C_noret;
static void f_1327(C_word c,C_word t0,C_word t1) C_noret;
static void f_1323(C_word c,C_word t0,C_word t1) C_noret;
static void f_1291(C_word c,C_word t0,C_word t1) C_noret;
static void f_1136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_1175(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1205(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1214(C_word t0,C_word t1) C_noret;
static void C_fcall f_1261(C_word t0,C_word t1) C_noret;
static void f_1246(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1220(C_word t0,C_word t1) C_noret;
static void f_1170(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1160(C_word t0,C_word t1) C_noret;
static void f_1156(C_word c,C_word t0,C_word t1) C_noret;
static void f_888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
static void f_888r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
static void C_fcall f_1050(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1054(C_word c,C_word t0,C_word t1) C_noret;
static void f_1124(C_word c,C_word t0,C_word t1) C_noret;
static void f_1120(C_word c,C_word t0,C_word t1) C_noret;
static void f_1103(C_word c,C_word t0,C_word t1) C_noret;
static void f_1085(C_word c,C_word t0,C_word t1) C_noret;
static void f_1078(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1012(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1016(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1021(C_word t0,C_word t1,C_word t2);
static void C_fcall f_915(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_921(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_988(C_word c,C_word t0,C_word t1) C_noret;
static void f_976(C_word c,C_word t0,C_word t1) C_noret;
static void f_935(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_900(C_word *a,C_word t0,C_word t1);
static void f_713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_869(C_word c,C_word t0,C_word t1) C_noret;
static void f_828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_729(C_word t0,C_word t1) C_noret;
static void C_fcall f_737(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_741(C_word c,C_word t0,C_word t1) C_noret;
static void f_802(C_word c,C_word t0,C_word t1) C_noret;
static void f_783(C_word c,C_word t0,C_word t1) C_noret;
static void f_817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_704r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_708(C_word c,C_word t0,C_word t1) C_noret;
static void f_695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_695r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_699(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_625(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void C_fcall f_635(C_word t0,C_word t1) C_noret;
static void f_639(C_word c,C_word t0,C_word t1) C_noret;
static void f_646(C_word c,C_word t0,C_word t1) C_noret;
static void f_649(C_word c,C_word t0,C_word t1) C_noret;
static void f_616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_616r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_620(C_word c,C_word t0,C_word t1) C_noret;
static void f_607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_607r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_611(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_534(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_580(C_word c,C_word t0,C_word t1) C_noret;
static void f_542(C_word c,C_word t0,C_word t1) C_noret;
static void f_549(C_word c,C_word t0,C_word t1) C_noret;
static void f_552(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_524(C_word t0);
static void C_fcall f_507(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_516(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_486(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_490(C_word c,C_word t0,C_word t1) C_noret;
static void f_498(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_404(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_416(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_450(C_word t0,C_word t1) C_noret;
static void f_454(C_word c,C_word t0,C_word t1) C_noret;
static void f_436(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_401(C_word t0);
static void f_395(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_379(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_379r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_344(C_word t0,C_word t1) C_noret;
static void C_fcall f_393(C_word t0,C_word t1) C_noret;
static void f_383(C_word c,C_word t0,C_word t1) C_noret;
static void f_386(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_303(C_word t0,C_word t1,C_word t2) C_noret;
static void f_307(C_word c,C_word t0,C_word t1) C_noret;
static void f_321(C_word c,C_word t0,C_word t1) C_noret;
static void f_317(C_word c,C_word t0,C_word t1) C_noret;
static void f_293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_283(C_word t0,C_word t1,C_word t2) C_noret;
static void f_288(C_word c,C_word t0,C_word t1) C_noret;

static void C_fcall trf_1421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1421(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1421(t0,t1,t2);}

static void C_fcall trf_1378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1378(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1378(t0,t1,t2);}

static void C_fcall trf_1297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1297(t0,t1,t2);}

static void C_fcall trf_1142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1142(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1142(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1175(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1175(t0,t1,t2,t3);}

static void C_fcall trf_1214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1214(t0,t1);}

static void C_fcall trf_1261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1261(t0,t1);}

static void C_fcall trf_1220(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1220(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1220(t0,t1);}

static void C_fcall trf_1160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1160(t0,t1);}

static void C_fcall trf_1050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1050(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1050(t0,t1,t2,t3);}

static void C_fcall trf_1012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1012(t0,t1,t2);}

static void C_fcall trf_915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_915(t0,t1,t2);}

static void C_fcall trf_921(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_921(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_921(t0,t1,t2,t3);}

static void C_fcall trf_729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_729(t0,t1);}

static void C_fcall trf_737(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_737(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_737(t0,t1,t2,t3);}

static void C_fcall trf_625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_625(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_625(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_635(t0,t1);}

static void C_fcall trf_534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_534(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_534(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_507(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_507(t0,t1,t2,t3,t4);}

static void C_fcall trf_486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_486(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_486(t0,t1,t2,t3,t4);}

static void C_fcall trf_404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_404(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_404(t0,t1,t2);}

static void C_fcall trf_416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_416(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_416(t0,t1,t2);}

static void C_fcall trf_450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_450(t0,t1);}

static void C_fcall trf_344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_344(t0,t1);}

static void C_fcall trf_393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_393(t0,t1);}

static void C_fcall trf_303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_303(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_303(t0,t1,t2);}

static void C_fcall trf_283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_283(t0,t1,t2);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr5rv(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5rv(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n+1);
t5=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_regex_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_regex_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("regex_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(333)){
C_save(t1);
C_rereclaim2(333*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,52);
lf[1]=C_h_intern(&lf[1],17,"\003sysmake-c-string");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_h_intern(&lf[5],17,"\003sysstring-append");
lf[6]=C_static_string(C_heaptop,37,"can not compile regular expression - ");
lf[7]=C_h_intern(&lf[7],17,"\003syspeek-c-string");
lf[8]=C_h_intern(&lf[8],6,"regexp");
lf[9]=C_h_intern(&lf[9],14,"set-finalizer!");
lf[10]=C_h_intern(&lf[10],7,"regexp\077");
lf[13]=C_h_intern(&lf[13],9,"substring");
lf[15]=C_h_intern(&lf[15],7,"\003sysmap");
lf[18]=C_h_intern(&lf[18],13,"string-append");
lf[19]=C_static_string(C_heaptop,0,"");
lf[20]=C_static_string(C_heaptop,1,"^");
lf[21]=C_static_string(C_heaptop,1,"$");
lf[22]=C_h_intern(&lf[22],15,"\003syssignal-hook");
lf[23]=C_h_intern(&lf[23],11,"\000type-error");
lf[24]=C_static_string(C_heaptop,51,"bad argument type - not a string or compiled regexp");
lf[25]=C_h_intern(&lf[25],12,"string-match");
lf[26]=C_h_intern(&lf[26],22,"string-match-positions");
lf[27]=C_static_string(C_heaptop,51,"bad argument type - not a string or compiled regexp");
lf[28]=C_h_intern(&lf[28],13,"string-search");
lf[29]=C_h_intern(&lf[29],23,"string-search-positions");
lf[30]=C_h_intern(&lf[30],7,"reverse");
lf[31]=C_h_intern(&lf[31],19,"string-split-fields");
lf[32]=C_h_intern(&lf[32],6,"\000infix");
lf[33]=C_h_intern(&lf[33],7,"\000suffix");
lf[34]=C_static_string(C_heaptop,31,"record does not end with suffix");
lf[35]=C_h_intern(&lf[35],11,"make-string");
lf[36]=C_h_intern(&lf[36],17,"string-substitute");
lf[37]=C_h_intern(&lf[37],18,"string-substitute*");
lf[38]=C_h_intern(&lf[38],21,"\003sysfragments->string");
lf[39]=C_h_intern(&lf[39],13,"\003syssubstring");
lf[40]=C_h_intern(&lf[40],12,"list->string");
lf[41]=C_h_intern(&lf[41],12,"string->list");
lf[42]=C_h_intern(&lf[42],12,"glob->regexp");
lf[43]=C_h_intern(&lf[43],8,"\003syscons");
lf[44]=C_h_intern(&lf[44],4,"grep");
lf[45]=C_h_intern(&lf[45],18,"open-output-string");
lf[46]=C_h_intern(&lf[46],17,"get-output-string");
lf[47]=C_h_intern(&lf[47],13,"regexp-escape");
lf[48]=C_h_intern(&lf[48],16,"\003syswrite-char-0");
lf[49]=C_h_intern(&lf[49],17,"register-feature!");
lf[50]=C_h_intern(&lf[50],5,"regex");
lf[51]=C_h_intern(&lf[51],4,"pcre");
C_register_lf(lf,52);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_281,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[49]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[50],lf[51]);}

/* k279 */
static void f_281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[79],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_281,2,t0,t1);}
t2=C_mutate(&lf[0],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_283,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_293,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_303,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_379,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_395,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_401,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_404,tmp=(C_word)a,a+=2,tmp));
t9=*((C_word*)lf[13]+1);
t10=C_mutate(&lf[14],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_486,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[16],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_507,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_524,tmp=(C_word)a,a+=2,tmp));
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=*((C_word*)lf[18]+1);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_534,a[2]=t17,a[3]=t16,a[4]=t14,tmp=(C_word)a,a+=5,tmp);
t19=C_mutate((C_word*)lf[25]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_607,a[2]=t18,a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t20=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_616,a[2]=t18,a[3]=t16,tmp=(C_word)a,a+=4,tmp));
t21=C_SCHEME_FALSE;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_FALSE;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_625,a[2]=t24,a[3]=t22,tmp=(C_word)a,a+=4,tmp);
t26=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=t25,a[3]=t24,tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_704,a[2]=t25,a[3]=t24,tmp=(C_word)a,a+=4,tmp));
t28=*((C_word*)lf[30]+1);
t29=*((C_word*)lf[13]+1);
t30=*((C_word*)lf[29]+1);
t31=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_713,a[2]=t28,a[3]=t30,a[4]=t29,tmp=(C_word)a,a+=5,tmp));
t32=*((C_word*)lf[13]+1);
t33=*((C_word*)lf[30]+1);
t34=*((C_word*)lf[35]+1);
t35=*((C_word*)lf[29]+1);
t36=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_888,a[2]=t35,a[3]=t33,a[4]=t34,a[5]=t32,tmp=(C_word)a,a+=6,tmp));
t37=*((C_word*)lf[29]+1);
t38=C_mutate((C_word*)lf[37]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1136,a[2]=t37,tmp=(C_word)a,a+=3,tmp));
t39=*((C_word*)lf[40]+1);
t40=*((C_word*)lf[41]+1);
t41=C_mutate((C_word*)lf[42]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1283,a[2]=t40,a[3]=t39,tmp=(C_word)a,a+=4,tmp));
t42=*((C_word*)lf[28]+1);
t43=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1372,a[2]=t42,tmp=(C_word)a,a+=3,tmp));
t44=*((C_word*)lf[45]+1);
t45=*((C_word*)lf[46]+1);
t46=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1409,a[2]=t44,a[3]=t45,tmp=(C_word)a,a+=4,tmp));
t47=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t47+1)))(2,t47,C_SCHEME_UNDEFINED);}

/* regexp-escape in k279 */
static void f_1409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1409,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1413,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1411 in regexp-escape in k279 */
static void f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1421,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1421(t6,((C_word*)t0)[2],C_fix(0));}

/* loop in k1411 in regexp-escape in k279 */
static void C_fcall f_1421(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1421,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[4]);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[3],t2);
if(C_truep((C_truep((C_word)C_eqp(t3,C_make_character(92)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(63)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(42)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(43)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(94)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(36)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(40)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(41)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(91)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(93)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(124)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(123)))?C_SCHEME_TRUE:(C_truep((C_word)C_eqp(t3,C_make_character(125)))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))))))))){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(92),((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1453,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,(C_word)C_subchar(((C_word*)t0)[3],t2),((C_word*)t0)[4]);}}}

/* k1451 in loop in k1411 in regexp-escape in k279 */
static void f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1421(t3,((C_word*)t0)[2],t2);}

/* k1438 in loop in k1411 in regexp-escape in k279 */
static void f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,(C_word)C_subchar(((C_word*)t0)[3],((C_word*)t0)[6]),((C_word*)t0)[2]);}

/* k1441 in k1438 in loop in k1411 in regexp-escape in k279 */
static void f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1421(t3,((C_word*)t0)[2],t2);}

/* grep in k279 */
static void f_1372(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1372,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1378,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1378(t7,t1,t3);}

/* loop in grep in k279 */
static void C_fcall f_1378(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1378,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1397,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k1395 in loop in grep in k279 */
static void f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1404,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
f_1378(t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
f_1378(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k1402 in k1395 in loop in grep in k279 */
static void f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1404,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* glob->regexp in k279 */
static void f_1283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1291,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1293 in glob->regexp in k279 */
static void f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1297(t5,((C_word*)t0)[2],t1);}

/* loop in k1293 in glob->regexp in k279 */
static void C_fcall f_1297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1297,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(C_word)C_slot(t2,C_fix(1));
switch(t3){
case C_make_character(42):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1323,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t14=t6;
t15=t4;
t1=t14;
t2=t15;
goto loop;
case C_make_character(63):
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=t5;
t15=t4;
t1=t14;
t2=t15;
goto loop;
default:
t5=(C_word)C_u_i_char_alphabeticp(t3);
t6=(C_truep(t5)?t5:(C_word)C_u_i_char_numericp(t3));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1356,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=t7;
t15=t4;
t1=t14;
t2=t15;
goto loop;}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1363,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1367,a[2]=t3,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t14=t8;
t15=t4;
t1=t14;
t2=t15;
goto loop;}}}}

/* k1365 in loop in k1293 in glob->regexp in k279 */
static void f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1361 in loop in k1293 in glob->regexp in k279 */
static void f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(92),t1);}

/* k1354 in loop in k1293 in glob->regexp in k279 */
static void f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1356,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1338 in loop in k1293 in glob->regexp in k279 */
static void f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_make_character(46),t1));}

/* k1325 in loop in k1293 in glob->regexp in k279 */
static void f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(42),t1);}

/* k1321 in loop in k1293 in glob->regexp in k279 */
static void f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[43]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(46),t1);}

/* k1289 in glob->regexp in k279 */
static void f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* string-substitute* in k279 */
static void f_1136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1136,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1142,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1142(t8,t1,C_fix(0),C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* collect in string-substitute* in k279 */
static void C_fcall f_1142(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1142,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1156,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1160,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(t2,t3))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1170,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[5],t3,t2);}
else{
t9=t8;
f_1160(t9,((C_word*)t6)[1]);}}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t6,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t2,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_1175(t10,t1,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* loop in collect in string-substitute* in k279 */
static void C_fcall f_1175(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1175,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_u_fixnum_difference(t3,((C_word*)t0)[9]);
t5=(C_word)C_u_fixnum_plus(((C_word*)t0)[8],t4);
t6=((C_word*)((C_word*)t0)[7])[1];
f_1142(t6,t1,t3,((C_word*)t0)[6],t5,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_u_i_car(t4);
t6=(C_word)C_slot(t4,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1205,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[8],a[12]=t6,tmp=(C_word)a,a+=13,tmp);
t8=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,t5,((C_word*)t0)[4],((C_word*)t0)[9]);}}

/* k1203 in loop in collect in string-substitute* in k279 */
static void f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_slot(t1,C_fix(0)):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1214,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(0));
t5=t3;
f_1214(t5,(C_word)C_eqp(((C_word*)t0)[7],t4));}
else{
t4=t3;
f_1214(t4,C_SCHEME_FALSE);}}

/* k1212 in k1203 in loop in collect in string-substitute* in k279 */
static void C_fcall f_1214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1214,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[13],C_fix(1));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1220,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[7],((C_word*)t0)[6]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1246,a[2]=t4,a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
t5=t4;
f_1220(t5,C_SCHEME_UNDEFINED);}}
else{
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1261,a[2]=t2,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[13])){
t4=(C_word)C_slot(((C_word*)t0)[13],C_fix(0));
t5=t3;
f_1261(t5,(C_word)C_i_fixnum_min(((C_word*)t0)[2],t4));}
else{
t4=t3;
f_1261(t4,((C_word*)t0)[2]);}}}

/* k1259 in k1212 in k1203 in loop in collect in string-substitute* in k279 */
static void C_fcall f_1261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1175(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1244 in k1212 in k1203 in loop in collect in string-substitute* in k279 */
static void f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_1220(t4,t3);}

/* k1218 in k1212 in k1203 in loop in collect in string-substitute* in k279 */
static void C_fcall f_1220(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1220,NULL,2,t0,t1);}
t2=(C_word)C_fix((C_word)C_header_size(((C_word*)t0)[7]));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[6],t2);
t4=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);
t5=((C_word*)((C_word*)t0)[4])[1];
f_1142(t5,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[2],t3,t4);}

/* k1168 in collect in string-substitute* in k279 */
static void f_1170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1170,2,t0,t1);}
t2=((C_word*)t0)[3];
f_1160(t2,(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]));}

/* k1158 in collect in string-substitute* in k279 */
static void C_fcall f_1160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[30]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1154 in collect in string-substitute* in k279 */
static void f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* string-substitute in k279 */
static void f_888(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+35)){
C_save_and_reclaim((void*)tr5rv,(void*)f_888r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest_vector(a,C_rest_count(0));
f_888r(t0,t1,t2,t3,t4,t5);}}

static void f_888r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a=C_alloc(35);
t6=(C_word)C_notvemptyp(t5);
t7=(C_truep(t6)?(C_word)C_slot(t5,C_fix(0)):C_fix(1));
t8=(C_word)C_block_size(t3);
t9=(C_word)C_u_fixnum_difference(t8,C_fix(1));
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_fix(0);
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_900,a[2]=t13,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_915,a[2]=t4,a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t14,a[7]=t9,tmp=(C_word)a,a+=8,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1012,a[2]=t13,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1050,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t11,a[5]=((C_word*)t0)[3],a[6]=t16,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t15,a[10]=t18,a[11]=t14,a[12]=t7,tmp=(C_word)a,a+=13,tmp));
t20=((C_word*)t18)[1];
f_1050(t20,t1,C_fix(0),C_fix(1));}

/* loop in string-substitute in k279 */
static void C_fcall f_1050(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1050,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1054,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k1052 in loop in string-substitute in k279 */
static void f_1054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1054,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_i_car(t1);
t3=(C_word)C_u_i_cadr(t2);
t4=(C_word)C_fixnump(((C_word*)t0)[13]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(((C_word*)t0)[12],((C_word*)t0)[13]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1085,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_u_i_car(t2);
t9=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,((C_word*)t0)[6],((C_word*)t0)[5],t8);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1103,a[2]=t3,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[6]);
t4=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],((C_word*)t0)[5],t3);}}

/* k1122 in k1052 in loop in string-substitute in k279 */
static void f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1124,2,t0,t1);}
t2=f_900(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1118 in k1122 in k1052 in loop in string-substitute in k279 */
static void f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1012(t2,((C_word*)t0)[2],t1);}

/* k1101 in k1052 in loop in string-substitute in k279 */
static void f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=f_900(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
f_1050(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k1083 in k1052 in loop in string-substitute in k279 */
static void f_1085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1085,2,t0,t1);}
t2=f_900(C_a_i(&a,3),((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
f_915(t4,t3,((C_word*)t0)[2]);}

/* k1076 in k1083 in k1052 in loop in string-substitute in k279 */
static void f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[4])[1];
f_1050(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* concatenate in string-substitute in k279 */
static void C_fcall f_1012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1012,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1016,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k1014 in concatenate in string-substitute in k279 */
static void f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1021(t2,((C_word*)t0)[2],C_fix(0)));}

/* loop in k1014 in concatenate in string-substitute in k279 */
static C_word C_fcall f_1021(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_block_size(t3);
t5=(C_word)C_substring_copy(t3,((C_word*)t0)[2],C_fix(0),t4,t2);
t6=(C_word)C_slot(t1,C_fix(1));
t7=(C_word)C_u_fixnum_plus(t2,t4);
t9=t6;
t10=t7;
t1=t9;
t2=t10;
goto loop;}}

/* substitute in string-substitute in k279 */
static void C_fcall f_915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_915,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_921(t6,t1,C_fix(0),C_fix(0));}

/* loop in substitute in string-substitute in k279 */
static void C_fcall f_921(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_921,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t4;
f_935(2,t6,((C_word*)t0)[7]);}
else{
t6=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[7],t2,((C_word*)t0)[5]);}}
else{
t4=(C_word)C_subchar(((C_word*)t0)[7],t3);
t5=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t6=(C_word)C_eqp(t4,C_make_character(92));
if(C_truep(t6)){
t7=(C_word)C_subchar(((C_word*)t0)[7],t5);
t8=(C_word)C_eqp(C_make_character(92),t7);
if(C_truep(t8)){
t9=(C_word)C_u_fixnum_plus(t5,C_fix(1));
t17=t1;
t18=t2;
t19=t9;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t9=(C_word)C_fix((C_word)C_character_code(t7));
t10=(C_word)C_u_fixnum_difference(t9,C_fix(48));
t11=(C_word)C_u_i_list_ref(((C_word*)t0)[3],t10);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t11,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[4],a[8]=t3,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t13=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,((C_word*)t0)[7],t2,t3);}}
else{
t17=t1;
t18=t2;
t19=t5;
t1=t17;
t2=t18;
t3=t19;
goto loop;}}}

/* k986 in loop in substitute in string-substitute in k279 */
static void f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
t2=f_900(C_a_i(&a,3),((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(((C_word*)t0)[4]);
t5=(C_word)C_u_i_cadr(((C_word*)t0)[4]);
t6=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[2],t4,t5);}

/* k974 in k986 in loop in substitute in string-substitute in k279 */
static void f_976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_976,2,t0,t1);}
t2=f_900(C_a_i(&a,3),((C_word*)t0)[6],t1);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[5],C_fix(2));
t4=((C_word*)((C_word*)t0)[4])[1];
f_921(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k933 in loop in substitute in string-substitute in k279 */
static void f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_900(C_a_i(&a,3),((C_word*)t0)[2],t1));}

/* push in string-substitute in k279 */
static C_word C_fcall f_900(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(C_word)C_block_size(t1);
t5=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t4);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
return(t6);}

/* string-split-fields in k279 */
static void f_713(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4rv,(void*)f_713r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_713r(t0,t1,t2,t3,t4);}}

static void f_713r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(25);
t5=(C_word)C_block_size(t4);
t6=(C_word)C_block_size(t3);
t7=(C_word)C_fixnum_greaterp(t5,C_fix(0));
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_TRUE);
t9=(C_word)C_fixnum_greaterp(t5,C_fix(1));
t10=(C_truep(t9)?(C_word)C_slot(t4,C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_729,a[2]=t10,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,tmp=(C_word)a,a+=10,tmp);
t12=(C_word)C_eqp(t8,lf[33]);
if(C_truep(t12)){
t13=t11;
f_729(t13,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_828,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));}
else{
t13=(C_word)C_eqp(t8,lf[32]);
t14=t11;
f_729(t14,(C_truep(t13)?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_848,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t6,tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp)));}}

/* f_870 in string-split-fields in k279 */
static void f_870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_870,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}

/* f_848 in string-split-fields in k279 */
static void f_848(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_848,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_869,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}}

/* k867 */
static void f_869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_869,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* f_828 in string-split-fields in k279 */
static void f_828(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_828,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t3,((C_word*)t0)[5]))){
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[31],lf[34],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k727 in string-split-fields in k279 */
static void C_fcall f_729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_729,NULL,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[9],lf[32]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[9],lf[33]));
t4=(C_truep(t3)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_812,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_817,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_737,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_737(t8,((C_word*)t0)[3],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);}

/* loop in k727 in string-split-fields in k279 */
static void C_fcall f_737(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_737,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_741,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* k739 in loop in k727 in string-split-fields in k279 */
static void f_741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_741,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(0));
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_u_i_cadr(t2);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(t4,((C_word*)t0)[8]);
if(C_truep(t6)){
t7=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t4,C_fix(2));
t10=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,((C_word*)t0)[4],t8,t9);}}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_802,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[4],t3,t4);}}
else{
t2=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k800 in k739 in loop in k727 in string-split-fields in k279 */
static void f_802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_802,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=((C_word*)((C_word*)t0)[4])[1];
f_737(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k781 in k739 in loop in k727 in string-split-fields in k279 */
static void f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_737(t4,((C_word*)t0)[2],t2,t3);}

/* f_817 in k727 in string-split-fields in k279 */
static void f_817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_817,5,t0,t1,t2,t3,t4);}
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* f_812 in k727 in string-split-fields in k279 */
static void f_812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_812,5,t0,t1,t2,t3,t4);}
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t2,t3);}

/* string-search-positions in k279 */
static void f_704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_704r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_704r(t0,t1,t2,t3,t4);}}

static void f_704r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_708,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[2];
f_625(t6,t5,t2,t3,t4,lf[29]);}

/* k706 in string-search-positions in k279 */
static void f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_404(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* string-search in k279 */
static void f_695(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_695r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_695r(t0,t1,t2,t3,t4);}}

static void f_695r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_699,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
f_625(t6,t5,t2,t3,t4,lf[28]);}

/* k697 in string-search in k279 */
static void f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[14];
f_486(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* prepare in k279 */
static void C_fcall f_625(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_625,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep((C_word)C_blockp(t4))?(C_word)C_slot(t4,C_fix(1)):C_SCHEME_FALSE);
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_635,a[2]=t5,a[3]=t7,a[4]=t3,a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_blockp(t6))){
t9=t8;
f_635(t9,(C_word)C_slot(t6,C_fix(0)));}
else{
t9=(C_word)C_block_size(t3);
t10=t8;
f_635(t10,(C_word)C_u_fixnum_difference(t9,t7));}}

/* k633 in prepare in k279 */
static void C_fcall f_635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_635,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_639,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[5]))){
f_303(t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
if(C_truep((C_word)C_i_structurep(((C_word*)t0)[5],lf[8]))){
t3=t2;
f_639(2,t3,(C_word)C_slot(((C_word*)t0)[5],C_fix(1)));}
else{
t3=*((C_word*)lf[22]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[23],((C_word*)t0)[2],lf[27],((C_word*)t0)[5]);}}}

/* k637 in k633 in prepare in k279 */
static void f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_639,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=f_524(((C_word*)((C_word*)t0)[8])[1]);
t4=(C_word)C_u_fixnum_plus(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[7])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_646,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
f_507(t6,((C_word*)((C_word*)t0)[8])[1],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k644 in k637 in k633 in prepare in k279 */
static void f_646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_649,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t3=lf[2];
f_293(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_649(2,t3,C_SCHEME_UNDEFINED);}}

/* k647 in k644 in k637 in k633 in prepare in k279 */
static void f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-match-positions in k279 */
static void f_616(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_616r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_616r(t0,t1,t2,t3,t4);}}

static void f_616r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_620,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[2];
f_534(t6,t5,t2,t3,t4,lf[26]);}

/* k618 in string-match-positions in k279 */
static void f_620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_404(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* string-match in k279 */
static void f_607(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_607r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_607r(t0,t1,t2,t3,t4);}}

static void f_607r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_611,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
f_534(t6,t5,t2,t3,t4,lf[25]);}

/* k609 in string-match in k279 */
static void f_611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[14];
f_486(t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* prepare in k279 */
static void C_fcall f_534(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_534,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_pairp(t4);
t7=(C_truep(t6)?(C_word)C_slot(t4,C_fix(0)):C_fix(0));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_542,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_580,a[2]=t5,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=(C_word)C_fixnum_greaterp(t7,C_fix(0));
t11=(C_truep(t10)?lf[19]:lf[20]);
t12=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t9,t11,t2,lf[21]);}
else{
if(C_truep((C_word)C_i_structurep(t2,lf[8]))){
t9=t8;
f_542(2,t9,(C_word)C_slot(t2,C_fix(1)));}
else{
t9=*((C_word*)lf[22]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,lf[23],t5,lf[24],t2);}}}

/* k578 in prepare in k279 */
static void f_580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_303(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k540 in prepare in k279 */
static void f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_542,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,t1);
t3=f_524(((C_word*)((C_word*)t0)[7])[1]);
t4=(C_word)C_u_fixnum_plus(C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_549,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_block_size(((C_word*)t0)[3]);
t8=(C_word)C_u_fixnum_difference(t7,((C_word*)t0)[2]);
f_507(t6,((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k547 in k540 in prepare in k279 */
static void f_549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_552,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[3]))){
t3=lf[2];
f_293(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_552(2,t3,C_SCHEME_UNDEFINED);}}

/* k550 in k547 in k540 in prepare in k279 */
static void f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* re-capture-count in k279 */
static C_word C_fcall f_524(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_truep(t1)?(C_word)C_i_foreign_pointer_argumentp(t1):C_SCHEME_FALSE);
return((C_word)stub62(C_SCHEME_UNDEFINED,t2));}

/* re-match in k279 */
static void C_fcall f_507(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_507,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_516,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t8=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t8=t7;
f_516(2,t8,C_SCHEME_FALSE);}}

/* k514 in re-match in k279 */
static void f_516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub51(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* gather-results in k279 */
static void C_fcall f_486(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_486,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_490,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
f_404(t5,t2,t4);}

/* k488 in gather-results in k279 */
static void f_490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_490,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a497 in k488 in gather-results in k279 */
static void f_498(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_498,3,t0,t1,t2);}
if(C_truep(t2)){
C_apply(5,0,t1,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* gather-result-positions in k279 */
static void C_fcall f_404(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_404,NULL,3,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_416,a[2]=t5,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_416(t7,t1,C_fix(0));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* loop in gather-result-positions in k279 */
static void C_fcall f_416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_416,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_436,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t13=t3;
t14=t4;
t1=t13;
t2=t14;
goto loop;}
else{
t3=(C_word)C_fixnum_times(t2,C_fix(2));
t4=f_401(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_450,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,C_fix(0)))){
t6=(C_word)C_fixnum_times(t2,C_fix(2));
t7=(C_word)C_u_fixnum_plus(t6,C_fix(1));
t8=f_401(t7);
t9=(C_word)C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=t5;
f_450(t10,(C_word)C_a_i_cons(&a,2,t4,t9));}
else{
t6=t5;
f_450(t6,C_SCHEME_FALSE);}}}}

/* k448 in loop in gather-result-positions in k279 */
static void C_fcall f_450(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_450,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_454,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)((C_word*)t0)[2])[1];
f_416(t4,t2,t3);}

/* k452 in k448 in loop in gather-result-positions in k279 */
static void f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_454,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k434 in loop in gather-result-positions in k279 */
static void f_436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_436,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* re-register-index in k279 */
static C_word C_fcall f_401(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub30(C_SCHEME_UNDEFINED,t1));}

/* regexp? in k279 */
static void f_395(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_395,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[8]));}

/* regexp in k279 */
static void f_379(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+23)){
C_save_and_reclaim((void*)tr3r,(void*)f_379r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_379r(t0,t1,t2,t3);}}

static void f_379r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(23);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_393,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_393(t6,C_fix(0));}
else{
t6=(C_word)C_u_i_car(t3);
t7=(C_truep(t6)?C_unsigned_int_to_num(&a,PCRE_CASELESS):C_fix(0));
t8=(C_word)C_slot(t3,C_fix(1));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_344,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t8))){
t10=t9;
f_344(t10,C_fix(0));}
else{
t10=(C_word)C_u_i_car(t8);
t11=(C_truep(t10)?C_unsigned_int_to_num(&a,PCRE_EXTENDED):C_fix(0));
t12=(C_word)C_slot(t8,C_fix(1));
t13=(C_word)C_i_pairp(t12);
t14=(C_truep(t13)?(C_word)C_u_i_cadr(t8):C_SCHEME_FALSE);
t15=(C_truep(t14)?C_unsigned_int_to_num(&a,PCRE_UTF8):C_fix(0));
t16=t9;
f_344(t16,(C_word)C_u_fixnum_plus(t11,t15));}}}

/* k342 in regexp in k279 */
static void C_fcall f_344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_393(t2,(C_word)C_u_fixnum_plus(((C_word*)t0)[2],t1));}

/* k391 in regexp in k279 */
static void C_fcall f_393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
f_283(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k381 in regexp in k279 */
static void f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_386,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[2]);}

/* k384 in k381 in regexp in k279 */
static void f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[8],((C_word*)t0)[2]));}

/* re-compile in k279 */
static void C_fcall f_303(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_303,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_307,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
f_283(t4,t2,C_fix(0));}

/* k305 in re-compile in k279 */
static void f_307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_307,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_regex_error),C_fix(0));}}

/* k319 in k305 in re-compile in k279 */
static void f_321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[6],t1);}

/* k315 in k305 in re-compile in k279 */
static void f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* finalizer in k279 */
static void f_293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_293,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub12(C_SCHEME_UNDEFINED,t3));}

/* re-compile-pattern in k279 */
static void C_fcall f_283(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_283,NULL,3,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_288,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t6=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t6=t5;
f_288(2,t6,C_SCHEME_FALSE);}}

/* k286 in re-compile-pattern in k279 */
static void f_288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub4(((C_word*)t0)[3],t1,((C_word*)t0)[2]));}
/* end of file */
