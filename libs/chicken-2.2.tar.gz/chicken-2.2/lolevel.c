/* Generated from lolevel.scm by the Chicken compiler
   2005-09-24 22:15
   Version 2, Build 112 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: lolevel.scm -quiet -no-trace -optimize-level 2 -include-path . -output-file lolevel.c -explicit-use
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif
#if defined(__i386__) && !defined(C_NONUNIX) && !defined(__CYGWIN__)
# define C_valloc(n)               valloc(n)
#elif defined(__i386__) || defined(_M_IX86)
# define C_valloc(n)               malloc(n)
#else
# define C_valloc(n)               NULL
#endif

#define C_pointer_to_object(ptr)   ((C_word*)C_block_item(ptr, 0))
#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_pointer_eqp(x, y)        C_mk_bool(C_c_pointer_nn(x) == C_c_pointer_nn(y))

C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[255];


/* from k2343 */
static C_word C_fcall stub457(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub457(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2264 */
static C_word C_fcall stub431(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub431(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1897 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub369(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub369(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int size=(int )C_unfix(C_a0);
char *bv;
           if((bv = (char *)malloc(size + 3 + sizeof(C_header))) == NULL) return(C_SCHEME_FALSE);
           bv = (char *)C_align((C_word)bv);
           ((C_SCHEME_BLOCK *)bv)->header = C_BYTEVECTOR_TYPE | size;
           return((C_word)bv);
C_return:
#undef return

return C_r;}

/* from k1431 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub260(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub260(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((double *)p));
C_return:
#undef return

return C_r;}

/* from k1421 */
#define return(x) C_cblock C_r = (C_flonum(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub253(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub253(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((float *)p));
C_return:
#undef return

return C_r;}

/* from k1411 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub246(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub246(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_s32 *)p));
C_return:
#undef return

return C_r;}

/* from k1401 */
#define return(x) C_cblock C_r = (C_int_to_num(&C_a,(x))); goto C_return; C_cblockend
static C_word C_fcall stub239(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub239(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((C_u32 *)p));
C_return:
#undef return

return C_r;}

/* from k1391 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub233(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub233(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((short *)p));
C_return:
#undef return

return C_r;}

/* from k1381 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub227(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub227(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned short *)p));
C_return:
#undef return

return C_r;}

/* from k1371 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub221(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub221(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((char *)p));
C_return:
#undef return

return C_r;}

/* from k1361 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub215(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub215(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
return(*((unsigned char *)p));
C_return:
#undef return

return C_r;}

/* from k1351 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub208(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub208(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
float n=(float )C_c_double(C_a1);
*((double *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1337 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub200(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub200(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
double n=(double )C_c_double(C_a1);
*((float *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1323 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub192(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub192(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_s32 *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1309 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub184(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub184(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((C_u32 *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1295 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub176(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub176(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((short *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1281 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub168(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub168(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned short *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1267 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub160(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub160(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((char *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1253 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub152(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub152(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * p=(void * )C_c_pointer_or_null(C_a0);
int n=(int )C_unfix(C_a1);
*((unsigned char *)p) = n;
C_return:
#undef return

return C_r;}

/* from k1239 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub143(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub143(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
return((unsigned char *)ptr + off);
C_return:
#undef return

return C_r;}

/* from k1197 */
static C_word C_fcall stub136(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub136(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

/* from k1187 */
static C_word C_fcall stub129(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub129(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1180 */
static C_word C_fcall stub124(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub124(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from f_1159 in object->pointer in k687 in k684 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub113(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub113(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
return((void *)x);
C_return:
#undef return

return C_r;}

/* from k762 */
static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

/* from k742 */
static C_word C_fcall stub34(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub34(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

/* from k722 */
static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

/* from k702 */
static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub10(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_memmove(t0,t1,t2);
return C_r;}

C_externexport void C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_686(C_word c,C_word t0,C_word t1) C_noret;
static void f_689(C_word c,C_word t0,C_word t1) C_noret;
static void f_2918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2877(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2877r(C_word t0,C_word t1,C_word t3) C_noret;
static void C_fcall f_2882(C_word t0,C_word t1) C_noret;
static void f_2858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2862(C_word c,C_word t0,C_word t1) C_noret;
static void f_2865(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_2865r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_2851(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2848(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_2815(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2815r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2823(C_word c,C_word t0,C_word t1) C_noret;
static void f_2786(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2786r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2794(C_word c,C_word t0,C_word t1) C_noret;
static void f_2723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2735(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2757(C_word c,C_word t0,C_word t1) C_noret;
static void f_2760(C_word c,C_word t0,C_word t1) C_noret;
static void f_2730(C_word c,C_word t0,C_word t1) C_noret;
static void f_2588(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2588r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2592(C_word c,C_word t0,C_word t1) C_noret;
static void f_2601(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2606(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2622(C_word c,C_word t0,C_word t1) C_noret;
static void f_2665(C_word c,C_word t0,C_word t1) C_noret;
static void f_2668(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2677(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2698(C_word c,C_word t0,C_word t1) C_noret;
static void f_2671(C_word c,C_word t0,C_word t1) C_noret;
static void f_2651(C_word c,C_word t0,C_word t1) C_noret;
static void f_2654(C_word c,C_word t0,C_word t1) C_noret;
static void f_2635(C_word c,C_word t0,C_word t1) C_noret;
static void f_2638(C_word c,C_word t0,C_word t1) C_noret;
static void f_2504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2508(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2513(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2526(C_word c,C_word t0,C_word t1) C_noret;
static void f_2583(C_word c,C_word t0,C_word t1) C_noret;
static void f_2535(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2547(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2569(C_word c,C_word t0,C_word t1) C_noret;
static void f_2538(C_word c,C_word t0,C_word t1) C_noret;
static void f_2350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_2350r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void f_2354(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2357(C_word t0,C_word t1) C_noret;
static void f_2483(C_word c,C_word t0,C_word t1) C_noret;
static void f_2360(C_word c,C_word t0,C_word t1) C_noret;
static void f_2363(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2371(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2381(C_word c,C_word t0,C_word t1) C_noret;
static void f_2476(C_word c,C_word t0,C_word t1) C_noret;
static void f_2393(C_word c,C_word t0,C_word t1) C_noret;
static void f_2453(C_word c,C_word t0,C_word t1) C_noret;
static void f_2399(C_word c,C_word t0,C_word t1) C_noret;
static void f_2402(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2414(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2435(C_word c,C_word t0,C_word t1) C_noret;
static void f_2405(C_word c,C_word t0,C_word t1) C_noret;
static void f_2366(C_word c,C_word t0,C_word t1) C_noret;
static void f_2268(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2268r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_2277(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2312(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2322(C_word c,C_word t0,C_word t1) C_noret;
static void f_2296(C_word c,C_word t0,C_word t1) C_noret;
static void f_2303(C_word c,C_word t0,C_word t1) C_noret;
static void f_2340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2157(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2157r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_2164(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2169(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2179(C_word c,C_word t0,C_word t1) C_noret;
static void f_2188(C_word c,C_word t0,C_word t1) C_noret;
static void f_2192(C_word c,C_word t0,C_word t1) C_noret;
static void f_2198(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2210(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2231(C_word c,C_word t0,C_word t1) C_noret;
static void f_2201(C_word c,C_word t0,C_word t1) C_noret;
static void f_2261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2154(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_2079(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2109(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_2124(C_word t0,C_word t1,C_word t2) C_noret;
static void f_2145(C_word c,C_word t0,C_word t1) C_noret;
static void f_2112(C_word c,C_word t0,C_word t1) C_noret;
static void f_2019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2032(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_2037(C_word t0,C_word t1);
static void f_2013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_2004(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_2004r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1982(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1961(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1974(C_word t0,C_word t1) C_noret;
static void f_1965(C_word c,C_word t0,C_word t1) C_noret;
static void f_1944(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1954(C_word c,C_word t0,C_word t1) C_noret;
static void f_1938(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1938r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
static void f_1917(C_word c,C_word t0,C_word t1) C_noret;
static void f_1923(C_word c,C_word t0,C_word t1) C_noret;
static void f_1894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1886(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1884(C_word c,C_word t0,C_word t1) C_noret;
static void f_1862(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1872(C_word c,C_word t0,C_word t1) C_noret;
static void f_1809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1819(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1824(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1834(C_word c,C_word t0,C_word t1) C_noret;
static void f_1773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1785(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1803(C_word c,C_word t0,C_word t1) C_noret;
static void f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void f_1710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1671(C_word c,C_word t0,C_word t1,...) C_noret;
static void f_1671r(C_word t0,C_word t1,C_word t3) C_noret;
static void f_1678(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1683(C_word t0,C_word t1,C_word t2);
static void f_1649(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1649r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void f_1656(C_word c,C_word t0,C_word t1) C_noret;
static void f_1659(C_word c,C_word t0,C_word t1) C_noret;
static void f_1615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static C_word C_fcall f_1630(C_word t0,C_word t1);
static void f_1609(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1598(C_word c,C_word t0,C_word t1) C_noret;
static void f_1560(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1570(C_word c,C_word t0,C_word t1) C_noret;
static void f_1529(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1544(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1542(C_word c,C_word t0,C_word t1) C_noret;
static void f_1491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1495(C_word c,C_word t0,C_word t1) C_noret;
static void f_1516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1500(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1442(C_word c,C_word t0,C_word t1) C_noret;
static void f_1445(C_word c,C_word t0,C_word t1) C_noret;
static void f_1428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1418(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1408(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1398(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1388(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1378(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1358(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1227(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_1194(C_word *a,C_word t0);
static void f_1184(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1172(C_word c,C_word t0,C_word t1) C_noret;
static void f_1175(C_word c,C_word t0,C_word t1) C_noret;
static void f_1162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1166(C_word c,C_word t0,C_word t1) C_noret;
static void f_1151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1159(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1138(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1142(C_word c,C_word t0,C_word t1) C_noret;
static void f_1149(C_word c,C_word t0,C_word t1) C_noret;
static void f_1129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1133(C_word c,C_word t0,C_word t1) C_noret;
static void f_1110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1114(C_word c,C_word t0,C_word t1) C_noret;
static void f_1101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_1089(C_word t0,C_word t1) C_noret;
static void f_771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
static void f_771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
static void C_fcall f_819(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_881(C_word c,C_word t0,C_word t1) C_noret;
static void f_980(C_word c,C_word t0,C_word t1) C_noret;
static void f_1028(C_word c,C_word t0,C_word t1) C_noret;
static void f_1042(C_word c,C_word t0,C_word t1) C_noret;
static void f_1038(C_word c,C_word t0,C_word t1) C_noret;
static void f_1003(C_word c,C_word t0,C_word t1) C_noret;
static void f_999(C_word c,C_word t0,C_word t1) C_noret;
static void f_890(C_word c,C_word t0,C_word t1) C_noret;
static void f_925(C_word c,C_word t0,C_word t1) C_noret;
static void f_939(C_word c,C_word t0,C_word t1) C_noret;
static void f_935(C_word c,C_word t0,C_word t1) C_noret;
static void f_897(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_798(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
static void C_fcall f_786(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_780(C_word t0,C_word t1) C_noret;
static void C_fcall f_774(C_word t0,C_word t1) C_noret;

static void C_fcall trf_2882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2882(t0,t1);}

static void C_fcall trf_2735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2735(t0,t1,t2);}

static void C_fcall trf_2606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2606(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2606(t0,t1,t2);}

static void C_fcall trf_2677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2677(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2677(t0,t1,t2);}

static void C_fcall trf_2513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2513(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2513(t0,t1,t2);}

static void C_fcall trf_2547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2547(t0,t1,t2);}

static void C_fcall trf_2357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2357(t0,t1);}

static void C_fcall trf_2371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2371(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2371(t0,t1,t2);}

static void C_fcall trf_2414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2414(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2414(t0,t1,t2);}

static void C_fcall trf_2277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2277(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2277(t0,t1,t2);}

static void C_fcall trf_2312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2312(t0,t1,t2);}

static void C_fcall trf_2169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2169(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2169(t0,t1,t2);}

static void C_fcall trf_2210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2210(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2210(t0,t1,t2);}

static void C_fcall trf_2079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2079(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2079(t0,t1,t2);}

static void C_fcall trf_2124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2124(t0,t1,t2);}

static void C_fcall trf_1974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1974(t0,t1);}

static void C_fcall trf_1901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1901(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1901(t0,t1,t2,t3,t4,t5);}

static void C_fcall trf_1824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1824(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1824(t0,t1,t2,t3);}

static void C_fcall trf_1785(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1785(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1785(t0,t1,t2);}

static void C_fcall trf_1089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1089(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1089(t0,t1);}

static void C_fcall trf_819(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_819(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_819(t0,t1,t2,t3);}

static void C_fcall trf_798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_798(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_798(t0,t1,t2,t3,t4);}

static void C_fcall trf_786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_786(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_786(t0,t1,t2,t3);}

static void C_fcall trf_780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_780(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_780(t0,t1);}

static void C_fcall trf_774(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_774(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_774(t0,t1);}

static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1152)){
C_save(t1);
C_rereclaim2(1152*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,255);
lf[1]=C_static_string(C_heaptop,27,"too many optional arguments");
tmp=C_intern(C_heaptop,4,"mmap");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"u8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"u32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,8,"s8vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s16vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"s32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f32vector");
C_save(tmp);
tmp=C_intern(C_heaptop,9,"f64vector");
C_save(tmp);
lf[2]=C_h_list(9,C_pick(8),C_pick(7),C_pick(6),C_pick(5),C_pick(4),C_pick(3),C_pick(2),C_pick(1),C_pick(0));
C_drop(9);
lf[3]=C_h_intern(&lf[3],12,"move-memory!");
lf[4]=C_h_intern(&lf[4],9,"\003syserror");
lf[5]=C_static_string(C_heaptop,28,"need number of bytes to move");
lf[6]=C_static_lambda_info(C_heaptop,5,"(err)");
lf[7]=C_h_intern(&lf[7],15,"\003syssignal-hook");
lf[8]=C_h_intern(&lf[8],11,"\000type-error");
lf[9]=C_static_string(C_heaptop,21,"invalid argument type");
lf[10]=C_static_lambda_info(C_heaptop,10,"(xerr x62)");
lf[11]=C_static_string(C_heaptop,33,"number of bytes to move too large");
lf[12]=C_static_lambda_info(C_heaptop,19,"(checkn n63 nmax64)");
lf[13]=C_static_string(C_heaptop,33,"number of bytes to move too large");
lf[14]=C_static_lambda_info(C_heaptop,28,"(checkn2 n65 nmax66 nmax267)");
lf[15]=C_h_intern(&lf[15],15,"\003sysbytevector\077");
lf[16]=C_h_intern(&lf[16],13,"\003syslocative\077");
lf[17]=C_static_lambda_info(C_heaptop,18,"(move from69 to70)");
lf[18]=C_static_lambda_info(C_heaptop,32,"(move-memory! from55 to56 . n57)");
lf[19]=C_h_intern(&lf[19],17,"\003syscheck-pointer");
lf[20]=C_static_string(C_heaptop,33,"bad argument type - not a pointer");
lf[21]=C_static_lambda_info(C_heaptop,33,"(##sys#check-pointer ptr96 loc97)");
lf[22]=C_h_intern(&lf[22],12,"null-pointer");
lf[23]=C_h_intern(&lf[23],16,"\003sysnull-pointer");
lf[24]=C_h_intern(&lf[24],8,"pointer\077");
lf[25]=C_static_lambda_info(C_heaptop,15,"(pointer\077 x102)");
lf[26]=C_h_intern(&lf[26],16,"address->pointer");
lf[27]=C_h_intern(&lf[27],20,"\003sysaddress->pointer");
lf[28]=C_static_string(C_heaptop,34,"bad argument type - not an integer");
lf[29]=C_static_lambda_info(C_heaptop,26,"(address->pointer addr105)");
lf[30]=C_h_intern(&lf[30],16,"pointer->address");
lf[31]=C_h_intern(&lf[31],20,"\003syspointer->address");
lf[32]=C_h_intern(&lf[32],17,"\003syscheck-special");
lf[33]=C_static_lambda_info(C_heaptop,25,"(pointer->address ptr107)");
lf[34]=C_h_intern(&lf[34],13,"null-pointer\077");
lf[35]=C_static_lambda_info(C_heaptop,22,"(null-pointer\077 ptr109)");
lf[36]=C_h_intern(&lf[36],15,"object->pointer");
lf[37]=C_static_lambda_info(C_heaptop,16,"(f_1159 a112115)");
lf[38]=C_static_lambda_info(C_heaptop,22,"(object->pointer x111)");
lf[39]=C_h_intern(&lf[39],15,"pointer->object");
lf[40]=C_static_lambda_info(C_heaptop,24,"(pointer->object ptr117)");
lf[41]=C_h_intern(&lf[41],9,"pointer=\077");
lf[42]=C_static_lambda_info(C_heaptop,23,"(pointer=\077 p1119 p2120)");
lf[43]=C_h_intern(&lf[43],8,"allocate");
lf[44]=C_static_lambda_info(C_heaptop,18,"(allocate a123126)");
lf[45]=C_h_intern(&lf[45],4,"free");
lf[46]=C_static_lambda_info(C_heaptop,14,"(free a128132)");
lf[47]=C_static_lambda_info(C_heaptop,7,"(align)");
lf[48]=C_h_intern(&lf[48],13,"align-to-word");
lf[49]=C_static_string(C_heaptop,43,"bad argument type - not a pointer or fixnum");
lf[50]=C_static_lambda_info(C_heaptop,20,"(align-to-word x140)");
lf[51]=C_h_intern(&lf[51],14,"pointer-offset");
lf[52]=C_static_lambda_info(C_heaptop,32,"(pointer-offset a142146 a141147)");
lf[53]=C_h_intern(&lf[53],15,"pointer-u8-set!");
lf[54]=C_static_lambda_info(C_heaptop,33,"(pointer-u8-set! a151155 a150156)");
lf[55]=C_h_intern(&lf[55],15,"pointer-s8-set!");
lf[56]=C_static_lambda_info(C_heaptop,33,"(pointer-s8-set! a159163 a158164)");
lf[57]=C_h_intern(&lf[57],16,"pointer-u16-set!");
lf[58]=C_static_lambda_info(C_heaptop,34,"(pointer-u16-set! a167171 a166172)");
lf[59]=C_h_intern(&lf[59],16,"pointer-s16-set!");
lf[60]=C_static_lambda_info(C_heaptop,34,"(pointer-s16-set! a175179 a174180)");
lf[61]=C_h_intern(&lf[61],16,"pointer-u32-set!");
lf[62]=C_static_lambda_info(C_heaptop,34,"(pointer-u32-set! a183187 a182188)");
lf[63]=C_h_intern(&lf[63],16,"pointer-s32-set!");
lf[64]=C_static_lambda_info(C_heaptop,34,"(pointer-s32-set! a191195 a190196)");
lf[65]=C_h_intern(&lf[65],16,"pointer-f32-set!");
lf[66]=C_static_lambda_info(C_heaptop,34,"(pointer-f32-set! a199203 a198204)");
lf[67]=C_h_intern(&lf[67],16,"pointer-f64-set!");
lf[68]=C_static_lambda_info(C_heaptop,34,"(pointer-f64-set! a207211 a206212)");
lf[69]=C_h_intern(&lf[69],14,"pointer-u8-ref");
lf[70]=C_static_lambda_info(C_heaptop,24,"(pointer-u8-ref a214218)");
lf[71]=C_h_intern(&lf[71],14,"pointer-s8-ref");
lf[72]=C_static_lambda_info(C_heaptop,24,"(pointer-s8-ref a220224)");
lf[73]=C_h_intern(&lf[73],15,"pointer-u16-ref");
lf[74]=C_static_lambda_info(C_heaptop,25,"(pointer-u16-ref a226230)");
lf[75]=C_h_intern(&lf[75],15,"pointer-s16-ref");
lf[76]=C_static_lambda_info(C_heaptop,25,"(pointer-s16-ref a232236)");
lf[77]=C_h_intern(&lf[77],15,"pointer-u32-ref");
lf[78]=C_static_lambda_info(C_heaptop,25,"(pointer-u32-ref a238242)");
lf[79]=C_h_intern(&lf[79],15,"pointer-s32-ref");
lf[80]=C_static_lambda_info(C_heaptop,25,"(pointer-s32-ref a245249)");
lf[81]=C_h_intern(&lf[81],15,"pointer-f32-ref");
lf[82]=C_static_lambda_info(C_heaptop,25,"(pointer-f32-ref a252256)");
lf[83]=C_h_intern(&lf[83],15,"pointer-f64-ref");
lf[84]=C_static_lambda_info(C_heaptop,25,"(pointer-f64-ref a259263)");
lf[85]=C_h_intern(&lf[85],11,"tag-pointer");
lf[86]=C_static_string(C_heaptop,33,"bad argument type - not a pointer");
lf[87]=C_h_intern(&lf[87],23,"\003sysmake-tagged-pointer");
lf[88]=C_static_lambda_info(C_heaptop,27,"(tag-pointer ptr266 tag267)");
lf[89]=C_h_intern(&lf[89],15,"tagged-pointer\077");
lf[90]=C_static_lambda_info(C_heaptop,29,"(tagged-pointer\077 x270 tag271)");
lf[91]=C_h_intern(&lf[91],11,"pointer-tag");
lf[92]=C_static_string(C_heaptop,33,"bad argument type - not a pointer");
lf[93]=C_static_lambda_info(C_heaptop,18,"(pointer-tag x272)");
lf[94]=C_h_intern(&lf[94],8,"extended");
lf[96]=C_h_intern(&lf[96],16,"extend-procedure");
lf[97]=C_static_lambda_info(C_heaptop,12,"(a1499 x275)");
lf[98]=C_static_lambda_info(C_heaptop,17,"(a1515 x276 i277)");
lf[99]=C_h_intern(&lf[99],19,"\003sysdecorate-lambda");
lf[100]=C_static_string(C_heaptop,35,"bad argument type - not a procedure");
lf[101]=C_static_lambda_info(C_heaptop,34,"(extend-procedure proc273 data274)");
lf[102]=C_h_intern(&lf[102],19,"extended-procedure\077");
lf[103]=C_static_lambda_info(C_heaptop,12,"(a1543 x281)");
lf[104]=C_h_intern(&lf[104],21,"\003syslambda-decoration");
lf[105]=C_static_lambda_info(C_heaptop,26,"(extended-procedure\077 x280)");
lf[106]=C_h_intern(&lf[106],14,"procedure-data");
lf[107]=C_static_lambda_info(C_heaptop,12,"(a1577 x284)");
lf[108]=C_static_lambda_info(C_heaptop,21,"(procedure-data x282)");
lf[109]=C_h_intern(&lf[109],19,"set-procedure-data!");
lf[110]=C_static_string(C_heaptop,45,"bad argument type - not an extended procedure");
lf[111]=C_static_lambda_info(C_heaptop,34,"(set-procedure-data! proc286 x287)");
lf[112]=C_h_intern(&lf[112],12,"byte-vector\077");
lf[113]=C_static_lambda_info(C_heaptop,19,"(byte-vector\077 x289)");
lf[114]=C_h_intern(&lf[114],17,"byte-vector-fill!");
lf[115]=C_static_lambda_info(C_heaptop,7,"(do293)");
lf[116]=C_static_lambda_info(C_heaptop,30,"(byte-vector-fill! bv290 n291)");
lf[117]=C_h_intern(&lf[117],16,"make-byte-vector");
lf[118]=C_h_intern(&lf[118],19,"\003sysallocate-vector");
lf[119]=C_static_lambda_info(C_heaptop,36,"(make-byte-vector size301 . init302)");
lf[120]=C_h_intern(&lf[120],11,"byte-vector");
lf[121]=C_static_lambda_info(C_heaptop,16,"(do311 bytes314)");
lf[122]=C_static_lambda_info(C_heaptop,24,"(byte-vector . bytes308)");
lf[123]=C_h_intern(&lf[123],15,"byte-vector-ref");
lf[124]=C_static_string(C_heaptop,12,"out of range");
lf[125]=C_static_lambda_info(C_heaptop,28,"(byte-vector-ref bv317 i318)");
lf[126]=C_h_intern(&lf[126],16,"byte-vector-set!");
lf[127]=C_static_string(C_heaptop,12,"out of range");
lf[128]=C_static_lambda_info(C_heaptop,34,"(byte-vector-set! bv324 i325 x326)");
lf[129]=C_h_intern(&lf[129],17,"byte-vector->list");
lf[130]=C_static_lambda_info(C_heaptop,11,"(loop i336)");
lf[131]=C_static_lambda_info(C_heaptop,25,"(byte-vector->list bv333)");
lf[132]=C_h_intern(&lf[132],17,"list->byte-vector");
lf[133]=C_h_intern(&lf[133],27,"\003sysnot-a-proper-list-error");
lf[134]=C_static_lambda_info(C_heaptop,17,"(do343 p345 i346)");
lf[135]=C_static_lambda_info(C_heaptop,26,"(list->byte-vector lst340)");
lf[136]=C_h_intern(&lf[136],19,"string->byte-vector");
lf[137]=C_static_lambda_info(C_heaptop,26,"(string->byte-vector s353)");
lf[138]=C_h_intern(&lf[138],11,"make-string");
lf[139]=C_h_intern(&lf[139],19,"byte-vector->string");
lf[140]=C_static_lambda_info(C_heaptop,27,"(byte-vector->string bv359)");
lf[141]=C_h_intern(&lf[141],18,"byte-vector-length");
lf[142]=C_static_lambda_info(C_heaptop,26,"(byte-vector-length bv364)");
lf[143]=C_static_lambda_info(C_heaptop,16,"(malloc a368371)");
lf[144]=C_h_intern(&lf[144],13,"\000bounds-error");
lf[145]=C_static_string(C_heaptop,12,"out of range");
lf[146]=C_h_intern(&lf[146],14,"\000runtime-error");
lf[147]=C_static_string(C_heaptop,48,"can not allocate statically allocated bytevector");
lf[148]=C_static_lambda_info(C_heaptop,38,"(make size373 init374 alloc375 loc376)");
lf[149]=C_h_intern(&lf[149],23,"make-static-byte-vector");
lf[150]=C_static_lambda_info(C_heaptop,43,"(make-static-byte-vector size380 . init381)");
lf[151]=C_h_intern(&lf[151],27,"static-byte-vector->pointer");
lf[152]=C_h_intern(&lf[152],16,"\003sysmake-pointer");
lf[153]=C_static_string(C_heaptop,36,"can not coerce non-static bytevector");
lf[154]=C_static_lambda_info(C_heaptop,35,"(static-byte-vector->pointer bv383)");
lf[155]=C_h_intern(&lf[155],9,"block-ref");
lf[156]=C_h_intern(&lf[156],13,"\003sysblock-ref");
lf[157]=C_h_intern(&lf[157],10,"block-set!");
lf[158]=C_h_intern(&lf[158],14,"\003sysblock-set!");
lf[159]=C_h_intern(&lf[159],15,"number-of-slots");
lf[160]=C_static_string(C_heaptop,20,"slots not accessible");
lf[161]=C_static_lambda_info(C_heaptop,22,"(number-of-slots x387)");
lf[162]=C_h_intern(&lf[162],15,"number-of-bytes");
lf[163]=C_static_string(C_heaptop,51,"can not compute number of bytes of immediate object");
lf[164]=C_static_lambda_info(C_heaptop,22,"(number-of-bytes x393)");
lf[165]=C_h_intern(&lf[165],20,"make-record-instance");
lf[166]=C_h_intern(&lf[166],18,"\003sysmake-structure");
lf[167]=C_static_lambda_info(C_heaptop,40,"(make-record-instance type394 . args395)");
lf[168]=C_h_intern(&lf[168],16,"record-instance\077");
lf[169]=C_static_lambda_info(C_heaptop,23,"(record-instance\077 x397)");
lf[170]=C_h_intern(&lf[170],14,"record->vector");
lf[171]=C_static_lambda_info(C_heaptop,7,"(do401)");
lf[172]=C_h_intern(&lf[172],15,"\003sysmake-vector");
lf[173]=C_static_string(C_heaptop,42,"bad argument type - not a record structure");
lf[174]=C_static_lambda_info(C_heaptop,21,"(record->vector x398)");
lf[175]=C_h_intern(&lf[175],11,"make-vector");
lf[176]=C_h_intern(&lf[176],11,"object-copy");
lf[177]=C_static_lambda_info(C_heaptop,12,"(do415 i417)");
lf[178]=C_static_lambda_info(C_heaptop,11,"(copy x409)");
lf[179]=C_static_lambda_info(C_heaptop,18,"(object-copy x407)");
lf[180]=C_h_intern(&lf[180],15,"object-evicted\077");
lf[181]=C_static_lambda_info(C_heaptop,22,"(object-evicted\077 x422)");
lf[182]=C_h_intern(&lf[182],15,"make-hash-table");
lf[183]=C_h_intern(&lf[183],22,"hash-table-ref/default");
lf[184]=C_h_intern(&lf[184],15,"hash-table-set!");
lf[185]=C_h_intern(&lf[185],12,"object-evict");
lf[186]=C_static_lambda_info(C_heaptop,16,"(f_2261 a430433)");
lf[187]=C_static_lambda_info(C_heaptop,12,"(do442 i444)");
lf[188]=C_static_lambda_info(C_heaptop,12,"(evict x436)");
lf[189]=C_h_intern(&lf[189],3,"eq\077");
lf[190]=C_static_lambda_info(C_heaptop,34,"(object-evict x426 . allocator427)");
lf[191]=C_h_intern(&lf[191],14,"object-release");
lf[192]=C_static_lambda_info(C_heaptop,16,"(f_2340 a456460)");
lf[193]=C_static_lambda_info(C_heaptop,12,"(do465 i467)");
lf[194]=C_static_lambda_info(C_heaptop,14,"(release x463)");
lf[195]=C_static_lambda_info(C_heaptop,35,"(object-release x453 . releaser454)");
lf[196]=C_h_intern(&lf[196],24,"object-evict-to-location");
lf[197]=C_static_lambda_info(C_heaptop,12,"(do493 i495)");
lf[198]=C_h_intern(&lf[198],24,"\003sysset-pointer-address!");
lf[199]=C_static_string(C_heaptop,37,"can not evict object - limit exceeded");
lf[200]=C_static_lambda_info(C_heaptop,12,"(evict x486)");
lf[201]=C_static_string(C_heaptop,33,"bad argument type - not a pointer");
lf[202]=C_static_lambda_info(C_heaptop,49,"(object-evict-to-location x476 ptr477 . limit478)");
lf[203]=C_h_intern(&lf[203],11,"object-size");
lf[204]=C_static_lambda_info(C_heaptop,12,"(do517 i519)");
lf[205]=C_static_lambda_info(C_heaptop,12,"(evict x514)");
lf[206]=C_static_lambda_info(C_heaptop,18,"(object-size x511)");
lf[207]=C_h_intern(&lf[207],14,"object-unevict");
lf[208]=C_h_intern(&lf[208],15,"\003sysmake-string");
lf[209]=C_static_lambda_info(C_heaptop,12,"(do550 i552)");
lf[210]=C_static_lambda_info(C_heaptop,11,"(copy x541)");
lf[211]=C_static_lambda_info(C_heaptop,31,"(object-unevict x532 . g531533)");
lf[212]=C_h_intern(&lf[212],14,"object-become!");
lf[213]=C_h_intern(&lf[213],11,"\003sysbecome!");
lf[214]=C_static_string(C_heaptop,41,"bad argument type - new item is immediate");
lf[215]=C_static_string(C_heaptop,41,"bad argument type - old item is immediate");
lf[216]=C_static_string(C_heaptop,33,"bad argument type - not an a-list");
lf[217]=C_static_lambda_info(C_heaptop,13,"(loop lst561)");
lf[218]=C_static_lambda_info(C_heaptop,23,"(object-become! lst559)");
lf[219]=C_h_intern(&lf[219],13,"make-locative");
lf[220]=C_h_intern(&lf[220],17,"\003sysmake-locative");
lf[221]=C_static_lambda_info(C_heaptop,33,"(make-locative obj571 . index572)");
lf[222]=C_h_intern(&lf[222],18,"make-weak-locative");
lf[223]=C_static_lambda_info(C_heaptop,38,"(make-weak-locative obj575 . index576)");
lf[224]=C_h_intern(&lf[224],12,"locative-ref");
lf[225]=C_static_lambda_info(C_heaptop,14,"C_locative_ref");
lf[226]=C_h_intern(&lf[226],13,"locative-set!");
lf[227]=C_static_lambda_info(C_heaptop,25,"(locative-set! x579 y580)");
lf[228]=C_h_intern(&lf[228],16,"locative->object");
lf[229]=C_static_lambda_info(C_heaptop,23,"(locative->object x581)");
lf[230]=C_h_intern(&lf[230],9,"locative\077");
lf[231]=C_static_lambda_info(C_heaptop,16,"(locative\077 x582)");
lf[233]=C_h_intern(&lf[233],30,"invalid-procedure-call-handler");
lf[234]=C_h_intern(&lf[234],31,"\003sysinvalid-procedure-call-hook");
lf[235]=C_h_intern(&lf[235],26,"\003syslast-invalid-procedure");
lf[236]=C_static_lambda_info(C_heaptop,45,"(##sys#invalid-procedure-call-hook . args584)");
lf[237]=C_static_string(C_heaptop,35,"bad argument type - not a procedure");
lf[238]=C_static_lambda_info(C_heaptop,40,"(invalid-procedure-call-handler proc583)");
lf[239]=C_h_intern(&lf[239],22,"unbound-variable-value");
lf[240]=C_h_intern(&lf[240],31,"\003sysunbound-variable-value-hook");
lf[241]=C_static_lambda_info(C_heaptop,33,"(unbound-variable-value . val587)");
lf[242]=C_h_intern(&lf[242],10,"global-ref");
lf[243]=C_static_lambda_info(C_heaptop,19,"(global-ref sym588)");
lf[244]=C_h_intern(&lf[244],11,"global-set!");
lf[245]=C_static_lambda_info(C_heaptop,25,"(global-set! sym590 x591)");
lf[246]=C_h_intern(&lf[246],13,"global-bound\077");
lf[247]=C_h_intern(&lf[247],32,"\003syssymbol-has-toplevel-binding\077");
lf[248]=C_static_lambda_info(C_heaptop,22,"(global-bound\077 sym593)");
lf[249]=C_h_intern(&lf[249],20,"global-make-unbound!");
lf[250]=C_h_intern(&lf[250],28,"\003sysarbitrary-unbound-symbol");
lf[251]=C_static_lambda_info(C_heaptop,29,"(global-make-unbound! sym595)");
lf[252]=C_h_intern(&lf[252],17,"register-feature!");
lf[253]=C_h_intern(&lf[253],7,"lolevel");
lf[254]=C_static_lambda_info(C_heaptop,10,"(toplevel)");
C_register_lf(lf,255);
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_686,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k684 */
static void f_686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_689,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 88   register-feature! */
t3=*((C_word*)lf[252]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[253]);}

/* k687 in k684 */
static void f_689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word ab[260],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_689,2,t0,t1);}
t2=lf[2];
t3=C_mutate((C_word*)lf[3]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_771,a[2]=t2,a[3]=lf[18],tmp=(C_word)a,a+=4,tmp));
t4=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1082,a[2]=lf[21],tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[22]+1,*((C_word*)lf[23]+1));
t6=C_mutate((C_word*)lf[24]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1101,a[2]=lf[25],tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[26]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1110,a[2]=lf[29],tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[30]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1129,a[2]=lf[33],tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[34]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=lf[35],tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1151,a[2]=lf[38],tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[39]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1162,a[2]=lf[40],tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1168,a[2]=lf[42],tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[43]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1177,a[2]=lf[44],tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1184,a[2]=lf[46],tmp=(C_word)a,a+=3,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1194,a[2]=lf[47],tmp=(C_word)a,a+=3,tmp);
t16=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1200,a[2]=t15,a[3]=lf[50],tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[51]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1232,a[2]=lf[52],tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[53]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1246,a[2]=lf[54],tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[55]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=lf[56],tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=lf[58],tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[59]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1288,a[2]=lf[60],tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1302,a[2]=lf[62],tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=lf[64],tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1330,a[2]=lf[66],tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1344,a[2]=lf[68],tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[69]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1358,a[2]=lf[70],tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1368,a[2]=lf[72],tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1378,a[2]=lf[74],tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1388,a[2]=lf[76],tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1398,a[2]=lf[78],tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1408,a[2]=lf[80],tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=lf[82],tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1428,a[2]=lf[84],tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1438,a[2]=lf[88],tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1453,a[2]=lf[90],tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1469,a[2]=lf[93],tmp=(C_word)a,a+=3,tmp));
t37=(C_word)C_a_i_vector(&a,1,lf[94]);
t38=C_mutate(&lf[95],t37);
t39=C_mutate((C_word*)lf[96]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1491,a[2]=lf[101],tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1529,a[2]=lf[105],tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[106]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1560,a[2]=lf[108],tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[96]+1);
t43=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1594,a[2]=t42,a[3]=lf[111],tmp=(C_word)a,a+=4,tmp));
t44=C_mutate((C_word*)lf[112]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1609,a[2]=lf[113],tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[114]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1615,a[2]=lf[116],tmp=(C_word)a,a+=3,tmp));
t46=*((C_word*)lf[114]+1);
t47=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1649,a[2]=t46,a[3]=lf[119],tmp=(C_word)a,a+=4,tmp));
t48=*((C_word*)lf[117]+1);
t49=C_mutate((C_word*)lf[120]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1671,a[2]=t48,a[3]=lf[122],tmp=(C_word)a,a+=4,tmp));
t50=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1710,a[2]=lf[125],tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=lf[128],tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1773,a[2]=lf[131],tmp=(C_word)a,a+=3,tmp));
t53=*((C_word*)lf[117]+1);
t54=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1809,a[2]=t53,a[3]=lf[135],tmp=(C_word)a,a+=4,tmp));
t55=*((C_word*)lf[117]+1);
t56=C_mutate((C_word*)lf[136]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1862,a[2]=t55,a[3]=lf[137],tmp=(C_word)a,a+=4,tmp));
t57=*((C_word*)lf[138]+1);
t58=C_mutate((C_word*)lf[139]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1874,a[2]=t57,a[3]=lf[140],tmp=(C_word)a,a+=4,tmp));
t59=C_mutate((C_word*)lf[141]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1886,a[2]=lf[142],tmp=(C_word)a,a+=3,tmp));
t60=*((C_word*)lf[114]+1);
t61=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=lf[143],tmp=(C_word)a,a+=3,tmp);
t62=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1901,a[2]=t60,a[3]=lf[148],tmp=(C_word)a,a+=4,tmp);
t63=C_mutate((C_word*)lf[149]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1938,a[2]=t61,a[3]=t62,a[4]=lf[150],tmp=(C_word)a,a+=5,tmp));
t64=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1944,a[2]=lf[154],tmp=(C_word)a,a+=3,tmp));
t65=C_mutate((C_word*)lf[155]+1,*((C_word*)lf[156]+1));
t66=C_mutate((C_word*)lf[157]+1,*((C_word*)lf[158]+1));
t67=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1961,a[2]=lf[161],tmp=(C_word)a,a+=3,tmp));
t68=C_mutate((C_word*)lf[162]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1982,a[2]=lf[164],tmp=(C_word)a,a+=3,tmp));
t69=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2004,a[2]=lf[167],tmp=(C_word)a,a+=3,tmp));
t70=C_mutate((C_word*)lf[168]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2013,a[2]=lf[169],tmp=(C_word)a,a+=3,tmp));
t71=C_mutate((C_word*)lf[170]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=lf[174],tmp=(C_word)a,a+=3,tmp));
t72=*((C_word*)lf[175]+1);
t73=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2073,a[2]=t72,a[3]=lf[179],tmp=(C_word)a,a+=4,tmp));
t74=C_mutate((C_word*)lf[180]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2154,a[2]=lf[181],tmp=(C_word)a,a+=3,tmp));
t75=*((C_word*)lf[182]+1);
t76=*((C_word*)lf[183]+1);
t77=*((C_word*)lf[184]+1);
t78=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2157,a[2]=t75,a[3]=t76,a[4]=t77,a[5]=lf[190],tmp=(C_word)a,a+=6,tmp));
t79=C_mutate((C_word*)lf[191]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2268,a[2]=lf[195],tmp=(C_word)a,a+=3,tmp));
t80=*((C_word*)lf[182]+1);
t81=*((C_word*)lf[183]+1);
t82=*((C_word*)lf[48]+1);
t83=*((C_word*)lf[184]+1);
t84=C_mutate((C_word*)lf[196]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2350,a[2]=t80,a[3]=t81,a[4]=t82,a[5]=t83,a[6]=lf[202],tmp=(C_word)a,a+=7,tmp));
t85=*((C_word*)lf[182]+1);
t86=*((C_word*)lf[183]+1);
t87=*((C_word*)lf[48]+1);
t88=*((C_word*)lf[184]+1);
t89=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2504,a[2]=t85,a[3]=t86,a[4]=t87,a[5]=t88,a[6]=lf[206],tmp=(C_word)a,a+=7,tmp));
t90=*((C_word*)lf[175]+1);
t91=*((C_word*)lf[182]+1);
t92=*((C_word*)lf[184]+1);
t93=*((C_word*)lf[183]+1);
t94=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2588,a[2]=t91,a[3]=t93,a[4]=t90,a[5]=t92,a[6]=lf[211],tmp=(C_word)a,a+=7,tmp));
t95=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2723,a[2]=lf[218],tmp=(C_word)a,a+=3,tmp));
t96=C_mutate((C_word*)lf[219]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2786,a[2]=lf[221],tmp=(C_word)a,a+=3,tmp));
t97=C_mutate((C_word*)lf[222]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2815,a[2]=lf[223],tmp=(C_word)a,a+=3,tmp));
t98=C_mutate((C_word*)lf[224]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=lf[225],tmp=(C_word)a,a+=3,tmp));
t99=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2845,a[2]=lf[227],tmp=(C_word)a,a+=3,tmp));
t100=C_mutate((C_word*)lf[228]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2848,a[2]=lf[229],tmp=(C_word)a,a+=3,tmp));
t101=C_mutate((C_word*)lf[230]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2851,a[2]=lf[231],tmp=(C_word)a,a+=3,tmp));
t102=lf[232]=C_SCHEME_FALSE;;
t103=C_mutate((C_word*)lf[233]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2858,a[2]=lf[238],tmp=(C_word)a,a+=3,tmp));
t104=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2877,a[2]=lf[241],tmp=(C_word)a,a+=3,tmp));
t105=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2894,a[2]=lf[243],tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2900,a[2]=lf[245],tmp=(C_word)a,a+=3,tmp));
t107=C_mutate((C_word*)lf[246]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=lf[248],tmp=(C_word)a,a+=3,tmp));
t108=C_mutate((C_word*)lf[249]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2918,a[2]=lf[251],tmp=(C_word)a,a+=3,tmp));
t109=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t109+1)))(2,t109,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k687 in k684 */
static void f_2918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2918,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[249]);
t4=(C_word)C_slot(lf[250],C_fix(0));
t5=(C_word)C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k687 in k684 */
static void f_2909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2909,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[246]);
/* lolevel.scm: 671  ##sys#symbol-has-toplevel-binding? */
t4=*((C_word*)lf[247]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t2);}

/* global-set! in k687 in k684 */
static void f_2900(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2900,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_symbol_2(t2,lf[244]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k687 in k684 */
static void f_2894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2894,3,t0,t1,t2);}
t3=(C_word)C_i_check_symbol_2(t2,lf[242]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_retrieve(t2));}

/* unbound-variable-value in k687 in k684 */
static void f_2877(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2877r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2877r(t0,t1,t2);}}

static void f_2877r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2882,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_notvemptyp(t2))){
t4=(C_word)C_i_vector_ref(t2,C_fix(0));
t5=t3;
f_2882(t5,(C_word)C_a_i_vector(&a,1,t4));}
else{
t4=t3;
f_2882(t4,C_SCHEME_FALSE);}}

/* k2880 in unbound-variable-value in k687 in k684 */
static void C_fcall f_2882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[240]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* invalid-procedure-call-handler in k687 in k684 */
static void f_2858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2862,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_closurep(t2))){
t4=t3;
f_2862(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 647  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[8],lf[233],lf[237],t2);}}

/* k2860 in invalid-procedure-call-handler in k687 in k684 */
static void f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2862,2,t0,t1);}
t2=C_mutate(&lf[232],((C_word*)t0)[3]);
t3=C_mutate((C_word*)lf[234]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2865,a[2]=lf[236],tmp=(C_word)a,a+=3,tmp));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ##sys#invalid-procedure-call-hook in k2860 in invalid-procedure-call-handler in k687 in k684 */
static void f_2865(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2865r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2865r(t0,t1,t2);}}

static void f_2865r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* lolevel.scm: 651  ipc-hook */
t3=lf[232];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,*((C_word*)lf[235]+1),t2);}

/* locative? in k687 in k684 */
static void f_2851(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2851,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_locativep(t2):C_SCHEME_FALSE));}

/* locative->object in k687 in k684 */
static void f_2848(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2848,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_locative_to_object(t2));}

/* locative-set! in k687 in k684 */
static void f_2845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2845,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_locative_set(t2,t3));}

/* make-weak-locative in k687 in k684 */
static void f_2815(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2815r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2815r(t0,t1,t2,t3);}}

static void f_2815r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2823,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2823(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2823(2,t6,(C_word)C_i_car(t3));}
else{
/* lolevel.scm: 633  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2821 in make-weak-locative in k687 in k684 */
static void f_2823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 633  ##sys#make-locative */
t2=*((C_word*)lf[220]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[222]);}

/* make-locative in k687 in k684 */
static void f_2786(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2786r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2786r(t0,t1,t2,t3);}}

static void f_2786r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2794(2,t5,C_fix(0));}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2794(2,t6,(C_word)C_i_car(t3));}
else{
/* lolevel.scm: 630  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2792 in make-locative in k687 in k684 */
static void f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 630  ##sys#make-locative */
t2=*((C_word*)lf[220]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[219]);}

/* object-become! in k687 in k684 */
static void f_2723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2723,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[212]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2730,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2735,a[2]=t6,a[3]=lf[217],tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_2735(t8,t4,t2);}

/* loop in object-become! in k687 in k684 */
static void C_fcall f_2735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2735,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep((C_word)C_i_pairp(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_pair_2(t4,lf[212]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2757,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(t4,C_fix(0));
if(C_truep((C_word)C_blockp(t7))){
t8=t6;
f_2757(2,t8,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 619  ##sys#signal-hook */
t8=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[8],lf[212],lf[215],t4);}}
else{
/* lolevel.scm: 623  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[8],lf[212],lf[216]);}}}

/* k2755 in loop in object-become! in k687 in k684 */
static void f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_slot(((C_word*)t0)[2],C_fix(1));
if(C_truep((C_word)C_blockp(t3))){
t4=t2;
f_2760(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 621  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[8],lf[212],lf[214],((C_word*)t0)[2]);}}

/* k2758 in k2755 in loop in object-become! in k687 in k684 */
static void f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
/* lolevel.scm: 622  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2735(t3,((C_word*)t0)[2],t2);}

/* k2728 in object-become! in k687 in k684 */
static void f_2730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 624  ##sys#become! */
t2=*((C_word*)lf[213]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k687 in k684 */
static void f_2588(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2588r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2588r(t0,t1,t2,t3);}}

static void f_2588r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2592,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t5=t4;
f_2592(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t5))){
t6=t4;
f_2592(2,t6,(C_word)C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2590 in object-unevict in k687 in k684 */
static void f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 580  make-hash-table */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,*((C_word*)lf[189]+1));}

/* k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2606,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=lf[210],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2606(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void C_fcall f_2606(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2606,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 584  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[5],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[7]))){
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2635,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[7]);
/* lolevel.scm: 587  ##sys#make-string */
t4=*((C_word*)lf[208]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[7]);}}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[7]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2651,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_slot(((C_word*)t0)[7],C_fix(1));
/* lolevel.scm: 592  ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 597  make-vector */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}}}}

/* k2663 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[7],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 598  hash-table-set! */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k2666 in k2663 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2677,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=lf[209],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2677(t7,t2,t3);}

/* do550 in k2666 in k2663 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void C_fcall f_2677(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2677,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2698,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 601  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2606(t5,t3,t4);}}

/* k2696 in do550 in k2666 in k2663 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2677(t4,((C_word*)t0)[2],t3);}

/* k2669 in k2666 in k2663 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2649 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2654,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 593  hash-table-set! */
t3=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2652 in k2649 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2633 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2635,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2638,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 588  hash-table-set! */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],t2);}

/* k2636 in k2633 in k2620 in copy in k2599 in k2590 in object-unevict in k687 in k684 */
static void f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k687 in k684 */
static void f_2504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2504,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2508,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 553  make-hash-table */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,*((C_word*)lf[189]+1));}

/* k2506 in object-size in k687 in k684 */
static void f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=lf[205],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2513(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2506 in object-size in k687 in k684 */
static void C_fcall f_2513(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2513,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2526,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 556  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2524 in evict in k2506 in object-size in k687 in k684 */
static void f_2526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2526,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 560  align-to-word */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2583(2,t4,(C_word)C_bytes(t2));}}}

/* k2581 in k2524 in evict in k2506 in object-size in k687 in k684 */
static void f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 562  hash-table-set! */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[6],C_SCHEME_TRUE);}

/* k2533 in k2581 in k2524 in evict in k2506 in object-size in k687 in k684 */
static void f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2538(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=lf[204],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2547(t9,t2,t5);}}

/* do517 in k2533 in k2581 in k2524 in evict in k2506 in object-size in k687 in k684 */
static void C_fcall f_2547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2547,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2569,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 569  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2513(t5,t3,t4);}}

/* k2567 in do517 in k2533 in k2581 in k2524 in evict in k2506 in object-size in k687 in k684 */
static void f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2547(t5,((C_word*)t0)[2],t4);}

/* k2536 in k2533 in k2581 in k2524 in evict in k2506 in object-size in k687 in k684 */
static void f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-evict-to-location in k687 in k684 */
static void f_2350(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2350r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2350r(t0,t1,t2,t3,t4);}}

static void f_2350r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2354,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t6=(C_truep((C_word)C_blockp(t3))?(C_word)C_specialp(t3):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t5;
f_2354(2,t7,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 511  ##sys#signal-hook */
t7=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,lf[8],lf[196],lf[201],t3);}}

/* k2352 in object-evict-to-location in k687 in k684 */
static void f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[2]))){
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
t4=(C_word)C_i_check_exact_2(t3,lf[196]);
t5=t2;
f_2357(t5,t3);}
else{
t3=t2;
f_2357(t3,C_SCHEME_FALSE);}}

/* k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void C_fcall f_2357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2357,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2483,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 519  ##sys#pointer->address */
t6=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k2481 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 519  ##sys#address->pointer */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2363,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 520  make-hash-table */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,*((C_word*)lf[189]+1));}

/* k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t4,a[8]=((C_word*)t0)[7],a[9]=lf[200],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_2371(t6,t2,((C_word*)t0)[2]);}

/* evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void C_fcall f_2371(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2371,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm: 524  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[5],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2381,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[8]))){
/* lolevel.scm: 528  align-to-word */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2476(2,t4,(C_word)C_bytes(t2));}}}

/* k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2393,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=(C_word)C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
/* lolevel.scm: 532  ##sys#error */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,lf[196],lf[199],((C_word*)t0)[9]);}
else{
t6=t3;
f_2393(2,t6,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2393(2,t4,C_SCHEME_UNDEFINED);}}

/* k2391 in k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2393,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_i_symbolp(((C_word*)t0)[9]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2453,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 535  ##sys#pointer->address */
t7=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[8]);}

/* k2451 in k2391 in k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2453,2,t0,t1);}
t2=(C_word)C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm: 535  ##sys#set-pointer-address! */
t3=*((C_word*)lf[198]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2397 in k2391 in k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2402,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 536  hash-table-set! */
t3=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k2400 in k2397 in k2391 in k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2405(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=lf[197],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2414(t9,t2,t5);}}

/* do493 in k2400 in k2397 in k2391 in k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void C_fcall f_2414(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2414,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2435,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 543  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2371(t5,t3,t4);}}

/* k2433 in do493 in k2400 in k2397 in k2391 in k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2414(t4,((C_word*)t0)[2],t3);}

/* k2403 in k2400 in k2397 in k2391 in k2474 in k2379 in evict in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2364 in k2361 in k2358 in k2355 in k2352 in object-evict-to-location in k687 in k684 */
static void f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 545  values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-release in k687 in k684 */
static void f_2268(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2268r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2268r(t0,t1,t2,t3);}}

static void f_2268r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(10);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2340,a[2]=lf[192],tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2277,a[2]=t7,a[3]=t5,a[4]=lf[194],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_2277(t9,t1,t2);}

/* release in object-release in k687 in k684 */
static void C_fcall f_2277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2277,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_permanentp(t2))){
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2296,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_byteblockp(t2))){
t5=t4;
f_2296(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(C_truep((C_word)C_specialp(t2))?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2312,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t7,a[5]=t3,a[6]=lf[193],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_2312(t9,t4,t5);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* do465 in release in object-release in k687 in k684 */
static void C_fcall f_2312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2312,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2322,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 499  release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2277(t5,t3,t4);}}

/* k2320 in do465 in release in object-release in k687 in k684 */
static void f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2312(t3,((C_word*)t0)[2],t2);}

/* k2294 in release in object-release in k687 in k684 */
static void f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 500  ##sys#address->pointer */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,(C_word)C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2301 in k2294 in release in object-release in k687 in k684 */
static void f_2303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 500  free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2340 in object-release in k687 in k684 */
static void f_2340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2340,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub457(C_SCHEME_UNDEFINED,t3));}

/* object-evict in k687 in k684 */
static void f_2157(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2157r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2157r(t0,t1,t2,t3);}}

static void f_2157r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(10);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_i_vector_ref(t3,C_fix(0)):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=lf[186],tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2164,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 469  make-hash-table */
t7=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,*((C_word*)lf[189]+1));}

/* k2162 in object-evict in k687 in k684 */
static void f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=lf[188],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2169(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2162 in object-evict in k687 in k684 */
static void C_fcall f_2169(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2169,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm: 472  hash-table-ref/default */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2177 in evict in k2162 in object-evict in k687 in k684 */
static void f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm: 475  align-to-word */
t4=*((C_word*)lf[48]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
t4=t3;
f_2188(2,t4,(C_word)C_bytes(t2));}}}

/* k2186 in k2177 in evict in k2162 in object-evict in k687 in k684 */
static void f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_plus(t1,(C_word)C_bytes(C_fix(1)));
/* lolevel.scm: 476  allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2190 in k2186 in k2177 in evict in k2162 in object-evict in k687 in k684 */
static void f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=(C_word)C_evict_block(((C_word*)t0)[7],t1);
t3=(C_word)C_i_symbolp(((C_word*)t0)[7]);
t4=(C_truep(t3)?(C_word)C_i_set_i_slot(t2,C_fix(0),C_SCHEME_UNDEFINED):C_SCHEME_UNDEFINED);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2198,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm: 478  hash-table-set! */
t6=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* k2196 in k2190 in k2186 in k2177 in evict in k2162 in object-evict in k687 in k684 */
static void f_2198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2201,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[4]))){
t3=t2;
f_2201(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_specialp(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:(C_word)C_i_symbolp(((C_word*)t0)[4]));
t5=(C_truep(t4)?C_fix(1):C_fix(0));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t7,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=lf[187],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_2210(t9,t2,t5);}}

/* do442 in k2196 in k2190 in k2186 in k2177 in evict in k2162 in object-evict in k687 in k684 */
static void C_fcall f_2210(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2210,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2231,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm: 483  evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2169(t5,t3,t4);}}

/* k2229 in do442 in k2196 in k2190 in k2186 in k2177 in evict in k2162 in object-evict in k687 in k684 */
static void f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2210(t4,((C_word*)t0)[2],t3);}

/* k2199 in k2196 in k2190 in k2186 in k2177 in evict in k2162 in object-evict in k687 in k684 */
static void f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2261 in object-evict in k687 in k684 */
static void f_2261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2261,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub431(t3,t4));}

/* object-evicted? in k687 in k684 */
static void f_2154(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2154,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_permanentp(t2));}

/* object-copy in k687 in k684 */
static void f_2073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2073,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=lf[178],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2079(t6,t1,t2);}

/* copy in object-copy in k687 in k684 */
static void C_fcall f_2079(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2079,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_i_symbolp(t2))){
t3=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 444  ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=(C_word)C_block_size(t2);
t4=(C_truep((C_word)C_byteblockp(t2))?(C_word)C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 448  make-vector */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2107 in copy in object-copy in k687 in k684 */
static void f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2109,2,t0,t1);}
t2=(C_word)C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2112,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:(C_word)C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=t3;
f_2112(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_truep((C_word)C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=lf[177],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_2124(t10,t3,t6);}}

/* do415 in k2107 in copy in object-copy in k687 in k684 */
static void C_fcall f_2124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2124,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2145,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm: 452  copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2079(t5,t3,t4);}}

/* k2143 in do415 in k2107 in copy in object-copy in k687 in k684 */
static void f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2124(t4,((C_word*)t0)[2],t3);}

/* k2110 in k2107 in copy in object-copy in k687 in k684 */
static void f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* record->vector in k687 in k684 */
static void f_2019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2019,3,t0,t1,t2);}
t3=(C_word)C_immp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_structurep(t2));
if(C_truep(t4)){
t5=(C_word)C_block_size(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2032,a[2]=t1,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 430  ##sys#make-vector */
t7=*((C_word*)lf[172]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
/* lolevel.scm: 434  ##sys#signal-hook */
t5=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[8],lf[170],lf[173],t2);}}

/* k2030 in record->vector in k687 in k684 */
static void f_2032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=lf[171],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2037(t2,C_fix(0)));}

/* do401 in k2030 in record->vector in k687 in k684 */
static C_word C_fcall f_2037(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=(C_word)C_slot(((C_word*)t0)[2],t1);
t3=(C_word)C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=t4;
t1=t6;
goto loop;}}

/* record-instance? in k687 in k684 */
static void f_2013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2013,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_structurep(t2):C_SCHEME_FALSE));}

/* make-record-instance in k687 in k684 */
static void f_2004(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2004r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2004r(t0,t1,t2,t3);}}

static void f_2004r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_word)C_i_check_symbol_2(t2,lf[165]);
C_apply(5,0,t1,*((C_word*)lf[166]+1),t2,t3);}

/* number-of-bytes in k687 in k684 */
static void f_1982(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1982,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_block_size(t2));}
else{
t3=(C_word)C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_w2b(t3));}}
else{
/* lolevel.scm: 412  ##sys#signal-hook */
t3=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[8],lf[162],lf[163],t2);}}

/* number-of-slots in k687 in k684 */
static void f_1961(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1961,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1965,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_not((C_word)C_blockp(t2));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1974,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_1974(t6,t4);}
else{
t6=(C_word)C_specialp(t2);
t7=t5;
f_1974(t7,(C_truep(t6)?t6:(C_word)C_byteblockp(t2)));}}

/* k1972 in number-of-slots in k687 in k684 */
static void C_fcall f_1974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* lolevel.scm: 407  ##sys#signal-hook */
t2=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[8],lf[159],lf[160],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_1965(2,t2,C_SCHEME_UNDEFINED);}}

/* k1963 in number-of-slots in k687 in k684 */
static void f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_block_size(((C_word*)t0)[2]));}

/* static-byte-vector->pointer in k687 in k684 */
static void f_1944(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1944,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[151]);
if(C_truep((C_word)C_permanentp(t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1954,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 391  ##sys#make-pointer */
t5=*((C_word*)lf[152]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
/* lolevel.scm: 394  ##sys#error */
t4=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[151],lf[153],t2);}}

/* k1952 in static-byte-vector->pointer in k687 in k684 */
static void f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_pointer_to_block(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* make-static-byte-vector in k687 in k684 */
static void f_1938(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_1938r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1938r(t0,t1,t2,t3);}}

static void f_1938r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* lolevel.scm: 385  make */
t4=((C_word*)t0)[3];
f_1901(t4,t1,t2,t3,((C_word*)t0)[2],lf[149]);}

/* make in k687 in k684 */
static void C_fcall f_1901(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1901,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_check_exact_2(t2,t5);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix((C_word)C_HEADER_SIZE_MASK)))){
/* lolevel.scm: 379  ##sys#signal-hook */
t7=*((C_word*)lf[7]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,lf[144],t5,lf[145],t2,C_fix((C_word)C_HEADER_SIZE_MASK));}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1917,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm: 380  alloc */
t8=t4;
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t2);}}

/* k1915 in make in k687 in k684 */
static void f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1923,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(0));
/* lolevel.scm: 382  byte-vector-fill! */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t1,t3);}
else{
t3=t2;
f_1923(2,t3,C_SCHEME_UNDEFINED);}}
else{
/* lolevel.scm: 384  ##sys#signal-hook */
t2=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],lf[146],lf[147],((C_word*)t0)[2]);}}

/* k1921 in k1915 in make in k687 in k684 */
static void f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* malloc in k687 in k684 */
static void f_1894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1894,3,t0,t1,t2);}
t3=(C_word)C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub369(C_SCHEME_UNDEFINED,t3));}

/* byte-vector-length in k687 in k684 */
static void f_1886(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1886,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[141]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_block_size(t2));}

/* byte-vector->string in k687 in k684 */
static void f_1874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1874,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[139]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1884,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 358  make-string */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k1882 in byte-vector->string in k687 in k684 */
static void f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* string->byte-vector in k687 in k684 */
static void f_1862(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1862,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[136]);
t4=(C_word)C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1872,a[2]=t1,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 349  make-byte-vector */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k1870 in string->byte-vector in k687 in k684 */
static void f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_copy_memory(t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* list->byte-vector in k687 in k684 */
static void f_1809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1809,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[132]);
t4=(C_word)C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1819,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 334  make-byte-vector */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k1817 in list->byte-vector in k687 in k684 */
static void f_1819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1819,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=lf[134],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1824(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do343 in k1817 in list->byte-vector in k687 in k684 */
static void C_fcall f_1824(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1824,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1834,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(t2))){
t6=(C_word)C_slot(t2,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[132]);
t8=t5;
f_1834(2,t8,(C_word)C_setbyte(((C_word*)t0)[4],t3,t6));}
else{
/* lolevel.scm: 342  ##sys#not-a-proper-list-error */
t6=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}}}

/* k1832 in do343 in k1817 in list->byte-vector in k687 in k684 */
static void f_1834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1824(t4,((C_word*)t0)[2],t2,t3);}

/* byte-vector->list in k687 in k684 */
static void f_1773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1773,3,t0,t1,t2);}
t3=(C_word)C_i_check_bytevector_2(t2,lf[129]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1785,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=lf[130],tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_1785(t8,t1,C_fix(0));}

/* loop in byte-vector->list in k687 in k684 */
static void C_fcall f_1785(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1785,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_subbyte(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1803,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_fixnum_plus(t2,C_fix(1));
/* lolevel.scm: 327  loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k1801 in loop in byte-vector->list in k687 in k684 */
static void f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* byte-vector-set! in k687 in k684 */
static void f_1740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(c!=5) C_bad_argc(c,5);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1740,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_bytevector_2(t2,lf[126]);
t6=(C_word)C_i_check_exact_2(t3,lf[126]);
t7=(C_word)C_i_check_exact_2(t4,lf[126]);
t8=(C_word)C_block_size(t2);
t9=(C_word)C_fixnum_lessp(t3,C_fix(0));
t10=(C_truep(t9)?t9:(C_word)C_fixnum_greater_or_equal_p(t3,t8));
if(C_truep(t10)){
/* lolevel.scm: 317  ##sys#error */
t11=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t1,lf[126],lf[127],t2,t3);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_setbyte(t2,t3,t4));}}

/* byte-vector-ref in k687 in k684 */
static void f_1710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1710,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_bytevector_2(t2,lf[123]);
t5=(C_word)C_i_check_exact_2(t3,lf[123]);
t6=(C_word)C_block_size(t2);
t7=(C_word)C_fixnum_lessp(t3,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t3,t6));
if(C_truep(t8)){
/* lolevel.scm: 307  ##sys#error */
t9=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t1,lf[123],lf[124],t2,t3);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_subbyte(t2,t3));}}

/* byte-vector in k687 in k684 */
static void f_1671(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1671r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1671r(t0,t1,t2);}}

static void f_1671r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t3=(C_word)C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1678,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 295  make-byte-vector */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1676 in byte-vector in k687 in k684 */
static void f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1683,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=lf[121],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1683(t2,C_fix(0),((C_word*)t0)[2]));}

/* do311 in k1676 in byte-vector in k687 in k684 */
static C_word C_fcall f_1683(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(((C_word*)t0)[2]);}
else{
t3=(C_word)C_slot(t2,C_fix(0));
t4=(C_word)C_setbyte(((C_word*)t0)[2],t1,t3);
t5=(C_word)C_fixnum_plus(t1,C_fix(1));
t6=(C_word)C_slot(t2,C_fix(1));
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}

/* make-byte-vector in k687 in k684 */
static void f_1649(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc(c,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1649r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1649r(t0,t1,t2,t3);}}

static void f_1649r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[117]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 286  ##sys#allocate-vector */
t6=*((C_word*)lf[118]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t2,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k1654 in make-byte-vector in k687 in k684 */
static void f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(C_word)C_string_to_bytevector(t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1659,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(((C_word*)t0)[3]))){
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
/* lolevel.scm: 288  byte-vector-fill! */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t1,t4);}
else{
t4=t3;
f_1659(2,t4,C_SCHEME_UNDEFINED);}}

/* k1657 in k1654 in make-byte-vector in k687 in k684 */
static void f_1659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* byte-vector-fill! in k687 in k684 */
static void f_1615(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1615,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_bytevector_2(t2,lf[114]);
t5=(C_word)C_i_check_exact_2(t3,lf[114]);
t6=(C_word)C_block_size(t2);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1630,a[2]=t3,a[3]=t2,a[4]=t6,a[5]=lf[115],tmp=(C_word)a,a+=6,tmp);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_1630(t7,C_fix(0)));}

/* do293 in byte-vector-fill! in k687 in k684 */
static C_word C_fcall f_1630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
loop:
C_stack_check;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_setbyte(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t3=(C_word)C_fixnum_plus(t1,C_fix(1));
t5=t3;
t1=t5;
goto loop;}}

/* byte-vector? in k687 in k684 */
static void f_1609(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1609,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_bytevectorp(t2):C_SCHEME_FALSE));}

/* set-procedure-data! in k687 in k684 */
static void f_1594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1594,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1598,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 262  extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k1596 in set-procedure-data! in k687 in k684 */
static void f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}
else{
/* lolevel.scm: 265  ##sys#signal-hook */
t3=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[2],lf[8],lf[109],lf[110],((C_word*)t0)[3]);}}

/* procedure-data in k687 in k684 */
static void f_1560(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1560,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1570,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=lf[107],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 256  ##sys#lambda-decoration */
t5=*((C_word*)lf[104]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1577 in procedure-data in k687 in k684 */
static void f_1578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1578,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[95],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1568 in procedure-data in k687 in k684 */
static void f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k687 in k684 */
static void f_1529(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1529,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1544,a[2]=lf[103],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 250  ##sys#lambda-decoration */
t5=*((C_word*)lf[104]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1543 in extended-procedure? in k687 in k684 */
static void f_1544(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1544,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[95],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1540 in extended-procedure? in k687 in k684 */
static void f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k687 in k684 */
static void f_1491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1491,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1495,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_closurep(t2))){
t5=t4;
f_1495(2,t5,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 239  ##sys#signal-hook */
t5=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[8],lf[96],lf[100],t2);}}

/* k1493 in extend-procedure in k687 in k684 */
static void f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1500,a[2]=lf[97],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[4],a[3]=lf[98],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 240  ##sys#decorate-lambda */
t4=*((C_word*)lf[99]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1515 in k1493 in extend-procedure in k687 in k684 */
static void f_1516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1516,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_cons(&a,2,lf[95],((C_word*)t0)[2]);
t5=(C_word)C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a1499 in k1493 in extend-procedure in k687 in k684 */
static void f_1500(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1500,3,t0,t1,t2);}
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[95],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-tag in k687 in k684 */
static void f_1469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1469,3,t0,t1,t2);}
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep((C_word)C_taggedpointerp(t2))?(C_word)C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm: 229  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[8],lf[85],lf[92],t2);}}

/* tagged-pointer? in k687 in k684 */
static void f_1453(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1453,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_blockp(t2))){
if(C_truep((C_word)C_taggedpointerp(t2))){
t4=(C_word)C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_i_equalp(t3,t4));}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* tag-pointer in k687 in k684 */
static void f_1438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1438,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1442,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 214  ##sys#make-tagged-pointer */
t5=*((C_word*)lf[87]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1440 in tag-pointer in k687 in k684 */
static void f_1442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1445,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep((C_word)C_blockp(((C_word*)t0)[2]))?(C_word)C_specialp(((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1445(2,t4,(C_word)C_copy_pointer(((C_word*)t0)[2],t1));}
else{
/* lolevel.scm: 217  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[8],lf[85],lf[86],((C_word*)t0)[2]);}}

/* k1443 in k1440 in tag-pointer in k687 in k684 */
static void f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* pointer-f64-ref in k687 in k684 */
static void f_1428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1428,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub260(t3,t4));}

/* pointer-f32-ref in k687 in k684 */
static void f_1418(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1418,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub253(t3,t4));}

/* pointer-s32-ref in k687 in k684 */
static void f_1408(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1408,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub246(t3,t4));}

/* pointer-u32-ref in k687 in k684 */
static void f_1398(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1398,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub239(t3,t4));}

/* pointer-s16-ref in k687 in k684 */
static void f_1388(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1388,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub233(C_SCHEME_UNDEFINED,t3));}

/* pointer-u16-ref in k687 in k684 */
static void f_1378(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1378,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub227(C_SCHEME_UNDEFINED,t3));}

/* pointer-s8-ref in k687 in k684 */
static void f_1368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1368,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub221(C_SCHEME_UNDEFINED,t3));}

/* pointer-u8-ref in k687 in k684 */
static void f_1358(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1358,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub215(C_SCHEME_UNDEFINED,t3));}

/* pointer-f64-set! in k687 in k684 */
static void f_1344(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1344,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub208(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-f32-set! in k687 in k684 */
static void f_1330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1330,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_flonum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub200(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s32-set! in k687 in k684 */
static void f_1316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1316,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub192(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u32-set! in k687 in k684 */
static void f_1302(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1302,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub184(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s16-set! in k687 in k684 */
static void f_1288(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1288,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub176(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u16-set! in k687 in k684 */
static void f_1274(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1274,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub168(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-s8-set! in k687 in k684 */
static void f_1260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1260,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub160(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-u8-set! in k687 in k684 */
static void f_1246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1246,4,t0,t1,t2,t3);}
t4=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t5=(C_word)C_i_foreign_fixnum_argumentp(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub152(C_SCHEME_UNDEFINED,t4,t5));}

/* pointer-offset in k687 in k684 */
static void f_1232(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1232,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=(C_word)C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)stub143(t4,t5,t6));}

/* align-to-word in k687 in k684 */
static void f_1200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1200,3,t0,t1,t2);}
if(C_truep((C_word)C_i_numberp(t2))){
/* lolevel.scm: 186  align */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,f_1194(C_a_i(&a,6),t2));}
else{
t3=(C_truep((C_word)C_blockp(t2))?(C_word)C_specialp(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1227,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 188  ##sys#pointer->address */
t5=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
/* lolevel.scm: 189  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,lf[8],lf[48],lf[49],t2);}}}

/* k1225 in align-to-word in k687 in k684 */
static void f_1227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1227,2,t0,t1);}
t2=f_1194(C_a_i(&a,6),t1);
/* lolevel.scm: 188  ##sys#address->pointer */
t3=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* align in k687 in k684 */
static C_word C_fcall f_1194(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(4));
t3=(C_word)C_i_foreign_integer_argumentp(t1);
return((C_word)stub136(t2,t3));}

/* free in k687 in k684 */
static void f_1184(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1184,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub129(C_SCHEME_UNDEFINED,t3));}

/* allocate in k687 in k684 */
static void f_1177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1177,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=(C_word)C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub124(t3,t4));}

/* pointer=? in k687 in k684 */
static void f_1168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1168,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1172,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 176  ##sys#check-special */
t5=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[41]);}

/* k1170 in pointer=? in k687 in k684 */
static void f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm: 177  ##sys#check-special */
t3=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[41]);}

/* k1173 in k1170 in pointer=? in k687 in k684 */
static void f_1175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k687 in k684 */
static void f_1162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1162,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1166,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 172  ##sys#check-pointer */
t4=*((C_word*)lf[19]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[39]);}

/* k1164 in pointer->object in k687 in k684 */
static void f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k687 in k684 */
static void f_1151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1151,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1159,a[2]=lf[37],tmp=(C_word)a,a+=3,tmp);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1159 in object->pointer in k687 in k684 */
static void f_1159(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1159,3,t0,t1,t2);}
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)stub113(t3,t2));}

/* null-pointer? in k687 in k684 */
static void f_1138(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1138,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1142,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 162  ##sys#check-special */
t4=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[34]);}

/* k1140 in null-pointer? in k687 in k684 */
static void f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm: 163  ##sys#pointer->address */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1147 in k1140 in null-pointer? in k687 in k684 */
static void f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(0),t1));}

/* pointer->address in k687 in k684 */
static void f_1129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1129,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1133,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm: 158  ##sys#check-special */
t4=*((C_word*)lf[32]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[30]);}

/* k1131 in pointer->address in k687 in k684 */
static void f_1133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 159  ##sys#pointer->address */
t2=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k687 in k684 */
static void f_1110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1110,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1114,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_integerp(t2))){
t4=t3;
f_1114(2,t4,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 153  ##sys#signal-hook */
t4=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[8],lf[26],lf[28],t2);}}

/* k1112 in address->pointer in k687 in k684 */
static void f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 155  ##sys#address->pointer */
t2=*((C_word*)lf[27]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer? in k687 in k684 */
static void f_1101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc(c,3);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1101,3,t0,t1,t2);}
if(C_truep((C_word)C_blockp(t2))){
t3=(C_word)C_pointerp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_taggedpointerp(t2)));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##sys#check-pointer in k687 in k684 */
static void f_1082(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc(c,4);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1082,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1089,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_blockp(t2))){
t5=(C_word)C_pointerp(t2);
if(C_truep(t5)){
t6=t4;
f_1089(t6,t5);}
else{
t6=(C_word)C_swigpointerp(t2);
t7=t4;
f_1089(t7,(C_truep(t6)?t6:(C_word)C_taggedpointerp(t2)));}}
else{
t5=t4;
f_1089(t5,C_SCHEME_FALSE);}}

/* k1087 in ##sys#check-pointer in k687 in k684 */
static void C_fcall f_1089(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* lolevel.scm: 140  ##sys#signal-hook */
t2=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[8],((C_word*)t0)[3],lf[20],((C_word*)t0)[2]);}}

/* move-memory! in k687 in k684 */
static void f_771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc(c,4);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+30)){
C_save_and_reclaim((void*)tr4r,(void*)f_771r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_771r(t0,t1,t2,t3,t4);}}

static void f_771r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(30);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_774,a[2]=t3,a[3]=t2,a[4]=lf[6],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=lf[10],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_786,a[2]=t3,a[3]=t2,a[4]=lf[12],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_798,a[2]=t3,a[3]=t2,a[4]=lf[14],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_819,a[2]=t8,a[3]=t7,a[4]=t5,a[5]=t4,a[6]=t6,a[7]=t10,a[8]=((C_word*)t0)[2],a[9]=lf[17],tmp=(C_word)a,a+=10,tmp));
t12=((C_word*)t10)[1];
f_819(t12,t1,t2,t3);}

/* move in move-memory! in k687 in k684 */
static void C_fcall f_819(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(10);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_819,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_structurep(t2))){
t4=(C_word)C_slot(t2,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[8]))){
t5=(C_word)C_slot(t2,C_fix(1));
/* lolevel.scm: 113  move */
t11=t1;
t12=t5;
t13=t3;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 114  xerr */
f_780(t1,t2);}}
else{
if(C_truep((C_word)C_structurep(t3))){
t4=(C_word)C_slot(t3,C_fix(0));
if(C_truep((C_word)C_i_memq(t4,((C_word*)t0)[8]))){
t5=(C_word)C_slot(t3,C_fix(1));
/* lolevel.scm: 117  move */
t11=t1;
t12=t2;
t13=t5;
t1=t11;
t2=t12;
t3=t13;
goto loop;}
else{
/* lolevel.scm: 118  xerr */
f_780(t1,t3);}}
else{
t4=(C_word)C_pointerp(t2);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t4)){
t6=t5;
f_881(2,t6,t4);}
else{
/* lolevel.scm: 119  ##sys#locative? */
t6=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}}}}

/* k879 in move in move-memory! in k687 in k684 */
static void f_881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_881,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_pointerp(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_890,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t2)){
t4=t3;
f_890(2,t4,t2);}
else{
/* lolevel.scm: 120  ##sys#locative? */
t4=*((C_word*)lf[16]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[9]);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_980,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 124  ##sys#bytevector? */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k978 in k879 in move in move-memory! in k687 in k684 */
static void f_980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_980,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[8]));
if(C_truep(t2)){
t3=(C_word)C_block_size(((C_word*)t0)[8]);
if(C_truep((C_word)C_pointerp(((C_word*)t0)[7]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[5];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1003,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
t7=t6;
f_1003(2,t7,t3);}
else{
t7=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t7))){
t8=t6;
f_1003(2,t8,(C_word)C_i_car(t5));}
else{
/* lolevel.scm: 126  ##sys#error */
t8=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 127  ##sys#bytevector? */
t5=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[7]);}}
else{
/* lolevel.scm: 130  xerr */
f_780(((C_word*)t0)[6],((C_word*)t0)[8]);}}

/* k1026 in k978 in k879 in move in move-memory! in k687 in k684 */
static void f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[8]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1038,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
t6=t5;
f_1042(2,t6,((C_word*)t0)[3]);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_1042(2,t7,(C_word)C_i_car(t4));}
else{
/* lolevel.scm: 128  ##sys#error */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}
else{
/* lolevel.scm: 129  xerr */
f_780(((C_word*)t0)[7],((C_word*)t0)[8]);}}

/* k1040 in k1026 in k978 in k879 in move in move-memory! in k687 in k684 */
static void f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[5]);
/* lolevel.scm: 128  checkn2 */
t3=((C_word*)t0)[4];
f_798(t3,((C_word*)t0)[3],t1,((C_word*)t0)[2],t2);}

/* k1036 in k1026 in k978 in k879 in move in move-memory! in k687 in k684 */
static void f_1038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t1);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub46(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* k1001 in k978 in k879 in move in move-memory! in k687 in k684 */
static void f_1003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm: 126  checkn */
t2=((C_word*)t0)[4];
f_786(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k997 in k978 in k879 in move in move-memory! in k687 in k684 */
static void f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?(C_word)C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t1);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub22(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* k888 in k879 in move in move-memory! in k687 in k684 */
static void f_890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_890,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* lolevel.scm: 120  err */
t4=((C_word*)t0)[4];
f_774(t4,t3);}
else{
t4=(C_word)C_i_cdr(t2);
if(C_truep((C_word)C_i_nullp(t4))){
t5=t3;
f_897(2,t5,(C_word)C_i_car(t2));}
else{
/* lolevel.scm: 120  ##sys#error */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* lolevel.scm: 121  ##sys#bytevector? */
t3=*((C_word*)lf[15]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}}

/* k923 in k888 in k879 in move in move-memory! in k687 in k684 */
static void f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_925,2,t0,t1);}
t2=(C_truep(t1)?t1:(C_word)C_i_stringp(((C_word*)t0)[8]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_939,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* lolevel.scm: 122  err */
t6=((C_word*)t0)[3];
f_774(t6,t5);}
else{
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_nullp(t6))){
t7=t5;
f_939(2,t7,(C_word)C_i_car(t4));}
else{
/* lolevel.scm: 122  ##sys#error */
t7=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}
else{
/* lolevel.scm: 123  xerr */
f_780(((C_word*)t0)[7],((C_word*)t0)[8]);}}

/* k937 in k923 in k888 in k879 in move in move-memory! in k687 in k684 */
static void f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[4]);
/* lolevel.scm: 122  checkn */
t3=((C_word*)t0)[3];
f_786(t3,((C_word*)t0)[2],t1,t2);}

/* k933 in k923 in k888 in k879 in move in move-memory! in k687 in k684 */
static void f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_truep(t3)?(C_word)C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t1);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub34(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* k895 in k888 in k879 in move in move-memory! in k687 in k684 */
static void f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
t5=(C_truep(t3)?(C_word)C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t6=(C_truep(t4)?(C_word)C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t7=(C_word)C_i_foreign_fixnum_argumentp(t1);
t8=t2;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)stub10(C_SCHEME_UNDEFINED,t5,t6,t7));}

/* checkn2 in move-memory! in k687 in k684 */
static void C_fcall f_798(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_798,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_less_or_equal_p(t2,t3);
t6=(C_truep(t5)?(C_word)C_fixnum_less_or_equal_p(t2,t4):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
/* lolevel.scm: 109  ##sys#error */
t7=*((C_word*)lf[4]+1);
((C_proc9)(void*)(*((C_word*)t7+1)))(9,t7,t1,lf[3],lf[13],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3,t4);}}

/* checkn in move-memory! in k687 in k684 */
static void C_fcall f_786(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_786,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_less_or_equal_p(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* lolevel.scm: 105  ##sys#error */
t4=*((C_word*)lf[4]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t1,lf[3],lf[11],((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}}

/* xerr in move-memory! in k687 in k684 */
static void C_fcall f_780(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_780,NULL,2,t1,t2);}
/* lolevel.scm: 101  ##sys#signal-hook */
t3=*((C_word*)lf[7]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t1,lf[8],lf[3],lf[9],t2);}

/* err in move-memory! in k687 in k684 */
static void C_fcall f_774(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_774,NULL,2,t0,t1);}
/* lolevel.scm: 100  ##sys#error */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[3],lf[5],((C_word*)t0)[3],((C_word*)t0)[2]);}
/* end of file */
