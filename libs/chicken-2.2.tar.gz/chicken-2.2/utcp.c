/* Generated from tcp.scm by the Chicken compiler
   2005-08-24 19:42
   Version 2, Build 106 - linux-unix-gnu-x86 - [ libffi dload ]
   command line: tcp.scm -quiet -no-trace -no-lambda-info -optimize-level 2 -unsafe -feature unsafe -include-path . -output-file utcp.c -explicit-use
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# include <winsock2.h>
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# define SD_RECEIVE      0
# define SD_SEND         1
# define closesocket     close
# define INVALID_SOCKET  -1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

C_externimport void C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_externimport void C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[71];


/* from general-strerror */
static C_word C_fcall stub275(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub275(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from get-socket-error */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub271(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub271(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_return:
#undef return

return C_r;}

/* from f_675 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_return:
#undef return

return C_r;}

/* from k595 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub149(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub149(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_return:
#undef return

return C_r;}

/* from k492 in ##net#gethostaddr in k458 in k377 in k374 in k371 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub123(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_return:
#undef return

return C_r;}

/* from ##net#select-write */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub117(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub117(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_return:
#undef return

return C_r;}

/* from ##net#select in k458 in k377 in k374 in k371 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub113(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub113(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_return:
#undef return

return C_r;}

/* from k469 in k465 in k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub104(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub104(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(se->s_port);
C_return:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub100(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub100(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     return(1);
#endif
C_return:
#undef return

return C_r;}

/* from ##net#getpeername */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub96(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub96(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, &len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_return:
#undef return

return C_r;}

/* from ##net#getsockport */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_return; C_cblockend
static C_word C_fcall stub92(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_return:
#undef return

return C_r;}

/* from ##net#getsockname */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_return; C_cblockend
static C_word C_fcall stub87(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub87(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, &len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_return:
#undef return

return C_r;}

/* from ##net#make-nonblocking in k377 in k374 in k371 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_return; C_cblockend
static C_word C_fcall stub83(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub83(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_return:
#undef return

return C_r;}

/* from k434 */
static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub75(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from ##net#shutdown in k377 in k374 in k371 */
static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub68(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k424 */
static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub58(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k417 */
static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub46(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)send(t0,t1,t2,t3));
return C_r;}

/* from ##net#close in k377 in k374 in k371 */
static C_word C_fcall stub39(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub39(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k401 */
static C_word C_fcall stub29(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub29(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from ##net#listen */
static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub22(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k387 */
static C_word C_fcall stub13(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from ##net#socket in k377 in k374 in k371 */
static C_word C_fcall stub5(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub5(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_externexport void C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
static void f_373(C_word c,C_word t0,C_word t1) C_noret;
static void f_376(C_word c,C_word t0,C_word t1) C_noret;
static void f_379(C_word c,C_word t0,C_word t1) C_noret;
static void f_460(C_word c,C_word t0,C_word t1) C_noret;
static void f_1553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1544(C_word c,C_word t0,C_word t1) C_noret;
static void f_1510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1534(C_word c,C_word t0,C_word t1) C_noret;
static void f_1530(C_word c,C_word t0,C_word t1) C_noret;
static void f_1520(C_word c,C_word t0,C_word t1) C_noret;
static void f_1465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1469(C_word c,C_word t0,C_word t1) C_noret;
static void f_1476(C_word c,C_word t0,C_word t1) C_noret;
static void f_1508(C_word c,C_word t0,C_word t1) C_noret;
static void f_1504(C_word c,C_word t0,C_word t1) C_noret;
static void f_1479(C_word c,C_word t0,C_word t1) C_noret;
static void f_1483(C_word c,C_word t0,C_word t1) C_noret;
static void f_1497(C_word c,C_word t0,C_word t1) C_noret;
static void f_1493(C_word c,C_word t0,C_word t1) C_noret;
static void f_1486(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1450(C_word t0,C_word t1) C_noret;
static void f_1454(C_word c,C_word t0,C_word t1) C_noret;
static void f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1448(C_word c,C_word t0,C_word t1) C_noret;
static void f_1231(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_1231r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_1235(C_word t0,C_word t1) C_noret;
static void f_1419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_1413(C_word c,C_word t0,C_word t1) C_noret;
static void f_1405(C_word c,C_word t0,C_word t1) C_noret;
static void f_1238(C_word c,C_word t0,C_word t1) C_noret;
static void f_1241(C_word c,C_word t0,C_word t1) C_noret;
static void f_1391(C_word c,C_word t0,C_word t1) C_noret;
static void f_1402(C_word c,C_word t0,C_word t1) C_noret;
static void f_1398(C_word c,C_word t0,C_word t1) C_noret;
static void f_1267(C_word c,C_word t0,C_word t1) C_noret;
static void f_1382(C_word c,C_word t0,C_word t1) C_noret;
static void f_1270(C_word c,C_word t0,C_word t1) C_noret;
static void f_1368(C_word c,C_word t0,C_word t1) C_noret;
static void f_1379(C_word c,C_word t0,C_word t1) C_noret;
static void f_1375(C_word c,C_word t0,C_word t1) C_noret;
static void f_1273(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1330(C_word t0,C_word t1) C_noret;
static void f_1337(C_word c,C_word t0,C_word t1) C_noret;
static void f_1346(C_word c,C_word t0,C_word t1) C_noret;
static void f_1276(C_word c,C_word t0,C_word t1) C_noret;
static void f_1316(C_word c,C_word t0,C_word t1) C_noret;
static void f_1312(C_word c,C_word t0,C_word t1) C_noret;
static void f_1299(C_word c,C_word t0,C_word t1) C_noret;
static void f_1295(C_word c,C_word t0,C_word t1) C_noret;
static void f_1282(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1246(C_word t0,C_word t1) C_noret;
static void f_1253(C_word c,C_word t0,C_word t1) C_noret;
static void f_1264(C_word c,C_word t0,C_word t1) C_noret;
static void f_1260(C_word c,C_word t0,C_word t1) C_noret;
static void f_1189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_1205(C_word c,C_word t0,C_word t1) C_noret;
static void f_1216(C_word c,C_word t0,C_word t1) C_noret;
static void f_1212(C_word c,C_word t0,C_word t1) C_noret;
static void f_1196(C_word c,C_word t0,C_word t1) C_noret;
static void f_1132(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_1141(C_word t0,C_word t1) C_noret;
static void f_1177(C_word c,C_word t0,C_word t1) C_noret;
static void f_1180(C_word c,C_word t0,C_word t1) C_noret;
static void f_1163(C_word c,C_word t0,C_word t1) C_noret;
static void f_1174(C_word c,C_word t0,C_word t1) C_noret;
static void f_1170(C_word c,C_word t0,C_word t1) C_noret;
static void f_1154(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_818(C_word t0,C_word t1,C_word t2) C_noret;
static void f_1119(C_word c,C_word t0,C_word t1) C_noret;
static void f_1130(C_word c,C_word t0,C_word t1) C_noret;
static void f_1126(C_word c,C_word t0,C_word t1) C_noret;
static void f_822(C_word c,C_word t0,C_word t1) C_noret;
static void f_825(C_word c,C_word t0,C_word t1) C_noret;
static void f_1072(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_1086(C_word t0,C_word t1) C_noret;
static void f_1089(C_word c,C_word t0,C_word t1) C_noret;
static void f_1100(C_word c,C_word t0,C_word t1) C_noret;
static void f_1096(C_word c,C_word t0,C_word t1) C_noret;
static void f_1037(C_word c,C_word t0,C_word t1) C_noret;
static void f_1059(C_word c,C_word t0,C_word t1) C_noret;
static void f_1070(C_word c,C_word t0,C_word t1) C_noret;
static void f_1066(C_word c,C_word t0,C_word t1) C_noret;
static void f_1050(C_word c,C_word t0,C_word t1) C_noret;
static void f_972(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_996(C_word t0,C_word t1) C_noret;
static void f_1024(C_word c,C_word t0,C_word t1) C_noret;
static void f_1035(C_word c,C_word t0,C_word t1) C_noret;
static void f_1031(C_word c,C_word t0,C_word t1) C_noret;
static void f_1015(C_word c,C_word t0,C_word t1) C_noret;
static void f_1018(C_word c,C_word t0,C_word t1) C_noret;
static void f_992(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_976(C_word t0,C_word t1) C_noret;
static void f_831(C_word c,C_word t0,C_word t1) C_noret;
static void f_929(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_943(C_word t0,C_word t1) C_noret;
static void f_946(C_word c,C_word t0,C_word t1) C_noret;
static void f_957(C_word c,C_word t0,C_word t1) C_noret;
static void f_953(C_word c,C_word t0,C_word t1) C_noret;
static void f_865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_874(C_word t0,C_word t1) C_noret;
static void f_920(C_word c,C_word t0,C_word t1) C_noret;
static void f_899(C_word c,C_word t0,C_word t1) C_noret;
static void f_910(C_word c,C_word t0,C_word t1) C_noret;
static void f_906(C_word c,C_word t0,C_word t1) C_noret;
static void f_893(C_word c,C_word t0,C_word t1) C_noret;
static void f_834(C_word c,C_word t0,C_word t1) C_noret;
static void f_863(C_word c,C_word t0,C_word t1) C_noret;
static void f_859(C_word c,C_word t0,C_word t1) C_noret;
static void f_788(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_801(C_word c,C_word t0,C_word t1) C_noret;
static void f_812(C_word c,C_word t0,C_word t1) C_noret;
static void f_808(C_word c,C_word t0,C_word t1) C_noret;
static void f_779(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_687(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
static void f_687r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
static void C_fcall f_734(C_word t0,C_word t1) C_noret;
static void C_fcall f_729(C_word t0,C_word t1,C_word t2) C_noret;
static void C_fcall f_689(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_717(C_word c,C_word t0,C_word t1) C_noret;
static void f_728(C_word c,C_word t0,C_word t1) C_noret;
static void f_724(C_word c,C_word t0,C_word t1) C_noret;
static void f_708(C_word c,C_word t0,C_word t1) C_noret;
static void f_695(C_word c,C_word t0,C_word t1) C_noret;
static void f_682(C_word c,C_word t0,C_word t1) C_noret;
static void f_606(C_word c,C_word t0,C_word t1) C_noret;
static void f_675(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_674(C_word c,C_word t0,C_word t1) C_noret;
static void f_659(C_word c,C_word t0,C_word t1) C_noret;
static void f_670(C_word c,C_word t0,C_word t1) C_noret;
static void f_666(C_word c,C_word t0,C_word t1) C_noret;
static void f_609(C_word c,C_word t0,C_word t1) C_noret;
static void f_612(C_word c,C_word t0,C_word t1) C_noret;
static void f_647(C_word c,C_word t0,C_word t1) C_noret;
static void f_615(C_word c,C_word t0,C_word t1) C_noret;
static void f_630(C_word c,C_word t0,C_word t1) C_noret;
static void f_641(C_word c,C_word t0,C_word t1) C_noret;
static void f_637(C_word c,C_word t0,C_word t1) C_noret;
static void f_621(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_520(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void C_fcall f_529(C_word t0,C_word t1,C_word t2) C_noret;
static void f_552(C_word c,C_word t0,C_word t1) C_noret;
static void f_556(C_word c,C_word t0,C_word t1) C_noret;
static void f_467(C_word c,C_word t0,C_word t1) C_noret;
static void f_471(C_word c,C_word t0,C_word t1) C_noret;
static void f_568(C_word c,C_word t0,C_word t1) C_noret;
static void f_579(C_word c,C_word t0,C_word t1) C_noret;
static void f_575(C_word c,C_word t0,C_word t1) C_noret;
static void f_562(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_499(C_word t0) C_noret;
static void f_505(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
static void f_514(C_word c,C_word t0,C_word t1) C_noret;
static void C_fcall f_485(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
static void f_494(C_word c,C_word t0,C_word t1) C_noret;
static C_word C_fcall f_479(C_word t0);
static C_word C_fcall f_438(C_word t0);
static C_word C_fcall f_428(C_word t0,C_word t1);
static C_word C_fcall f_411(C_word t0);
static C_word C_fcall f_381(C_word t0,C_word t1,C_word t2);

static void C_fcall trf_1450(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1450(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1450(t0,t1);}

static void C_fcall trf_1235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1235(t0,t1);}

static void C_fcall trf_1330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1330(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1330(t0,t1);}

static void C_fcall trf_1246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1246(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1246(t0,t1);}

static void C_fcall trf_1141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1141(t0,t1);}

static void C_fcall trf_818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_818(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_818(t0,t1,t2);}

static void C_fcall trf_1086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1086(t0,t1);}

static void C_fcall trf_996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_996(t0,t1);}

static void C_fcall trf_976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_976(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_976(t0,t1);}

static void C_fcall trf_943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_943(t0,t1);}

static void C_fcall trf_874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_874(t0,t1);}

static void C_fcall trf_734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_734(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_734(t0,t1);}

static void C_fcall trf_729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_729(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_729(t0,t1,t2);}

static void C_fcall trf_689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_689(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_689(t0,t1,t2,t3);}

static void C_fcall trf_520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_520(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_520(t0,t1,t2,t3);}

static void C_fcall trf_529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_529(t0,t1,t2);}

static void C_fcall trf_499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_499(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_499(t0);}

static void C_fcall trf_485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_485(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_485(t0,t1,t2,t3);}

static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(279)){
C_save(t1);
C_rereclaim2(279*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,71);
lf[6]=C_h_intern(&lf[6],17,"\003sysmake-c-string");
lf[8]=C_h_intern(&lf[8],18,"\003syscurrent-thread");
lf[9]=C_h_intern(&lf[9],12,"\003sysschedule");
lf[10]=C_h_intern(&lf[10],9,"substring");
lf[12]=C_h_intern(&lf[12],15,"\003syssignal-hook");
lf[13]=C_h_intern(&lf[13],14,"\000network-error");
lf[14]=C_h_intern(&lf[14],11,"tcp-connect");
lf[15]=C_h_intern(&lf[15],17,"\003sysstring-append");
lf[16]=C_static_string(C_heaptop,36,"can not compute port from service - ");
lf[17]=C_h_intern(&lf[17],17,"\003syspeek-c-string");
lf[18]=C_h_intern(&lf[18],16,"\003sysupdate-errno");
lf[19]=C_h_intern(&lf[19],10,"tcp-listen");
lf[20]=C_static_string(C_heaptop,25,"can not bind to socket - ");
lf[21]=C_static_string(C_heaptop,34,"getting listener host IP failed - ");
lf[22]=C_h_intern(&lf[22],11,"make-string");
lf[23]=C_static_string(C_heaptop,32,"error while setting up socket - ");
lf[24]=C_h_intern(&lf[24],9,"\003syserror");
lf[25]=C_static_string(C_heaptop,21,"can not create socket");
lf[26]=C_h_intern(&lf[26],12,"tcp-listener");
lf[27]=C_static_string(C_heaptop,27,"can not listen on socket - ");
lf[28]=C_h_intern(&lf[28],13,"tcp-listener\077");
lf[29]=C_h_intern(&lf[29],9,"tcp-close");
lf[30]=C_static_string(C_heaptop,27,"can not close TCP socket - ");
lf[31]=C_h_intern(&lf[31],15,"make-input-port");
lf[32]=C_h_intern(&lf[32],16,"make-output-port");
lf[34]=C_static_string(C_heaptop,5,"(tcp)");
lf[35]=C_static_string(C_heaptop,5,"(tcp)");
lf[36]=C_h_intern(&lf[36],6,"socket");
lf[37]=C_h_intern(&lf[37],13,"\003sysport-data");
lf[38]=C_static_string(C_heaptop,26,"can not write to socket - ");
lf[39]=C_static_string(C_heaptop,35,"can not close socket output port - ");
lf[40]=C_h_intern(&lf[40],25,"\003systhread-block-for-i/o!");
lf[41]=C_static_string(C_heaptop,27,"can not read from socket - ");
lf[42]=C_static_string(C_heaptop,33,"can not check socket for input - ");
lf[43]=C_static_string(C_heaptop,34,"can not close socket input port - ");
lf[44]=C_static_string(C_heaptop,27,"can not create TCP ports - ");
lf[45]=C_h_intern(&lf[45],10,"tcp-accept");
lf[46]=C_static_string(C_heaptop,33,"could not accept from listener - ");
lf[47]=C_h_intern(&lf[47],17,"tcp-accept-ready\077");
lf[48]=C_static_string(C_heaptop,33,"can not check socket for input - ");
lf[49]=C_static_string(C_heaptop,28,"can not connect to socket - ");
lf[50]=C_static_string(C_heaptop,22,"getsockopt() failed - ");
lf[51]=C_static_string(C_heaptop,24,"can not create socket - ");
lf[52]=C_static_string(C_heaptop,17,"fcntl() failed - ");
lf[53]=C_static_string(C_heaptop,25,"can not find host address");
lf[54]=C_static_string(C_heaptop,24,"can not create socket - ");
lf[55]=C_static_string(C_heaptop,17,"no port specified");
lf[56]=C_static_string(C_heaptop,3,"tcp");
lf[57]=C_h_intern(&lf[57],20,"\003systcp-port->fileno");
lf[59]=C_h_intern(&lf[59],11,"\000type-error");
lf[60]=C_static_string(C_heaptop,37,"bad argument type - not a TCP port - ");
lf[61]=C_h_intern(&lf[61],13,"tcp-addresses");
lf[62]=C_static_string(C_heaptop,33,"can not compute remote address - ");
lf[63]=C_static_string(C_heaptop,32,"can not compute local address - ");
lf[64]=C_h_intern(&lf[64],17,"tcp-listener-port");
lf[65]=C_static_string(C_heaptop,31,"can not obtain listener port - ");
lf[66]=C_h_intern(&lf[66],16,"tcp-abandon-port");
lf[67]=C_h_intern(&lf[67],19,"tcp-listener-fileno");
lf[68]=C_static_string(C_heaptop,26,"can not initialize Winsock");
lf[69]=C_h_intern(&lf[69],17,"register-feature!");
lf[70]=C_h_intern(&lf[70],3,"tcp");
C_register_lf(lf,71);
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k371 */
static void f_373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_376,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k374 in k371 */
static void f_376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_376,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[70]);}

/* k377 in k374 in k371 */
static void f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_379,2,t0,t1);}
t2=C_mutate(&lf[0],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_381,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_411,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_428,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_438,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub100(C_SCHEME_UNDEFINED))){
t7=t6;
f_460(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,lf[13],lf[68]);}}

/* k458 in k377 in k374 in k371 */
static void f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_479,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_485,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[7],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_499,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[10]+1);
t6=C_mutate(&lf[11],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_520,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[19]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_687,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[28]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_779,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[29]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_788,tmp=(C_word)a,a+=2,tmp));
t10=*((C_word*)lf[31]+1);
t11=*((C_word*)lf[32]+1);
t12=*((C_word*)lf[22]+1);
t13=*((C_word*)lf[10]+1);
t14=C_mutate(&lf[33],(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_818,a[2]=t12,a[3]=t10,a[4]=t11,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t15=C_mutate((C_word*)lf[45]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1132,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1189,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[14]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1231,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1440,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1450,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1465,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1510,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1536,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1553,tmp=(C_word)a,a+=2,tmp));
t24=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k458 in k377 in k374 in k371 */
static void f_1553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1553,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k458 in k377 in k374 in k371 */
static void f_1536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1536,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1544,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_1450(t3,t2);}

/* k1542 in tcp-abandon-port in k458 in k377 in k374 in k371 */
static void f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k458 in k377 in k374 in k371 */
static void f_1510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1510,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)stub92(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1520,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1530,a[2]=t3,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1534,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t7=t5;
f_1520(2,t7,C_SCHEME_UNDEFINED);}}

/* k1532 in tcp-listener-port in k458 in k377 in k374 in k371 */
static void f_1534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[65],t1);}

/* k1528 in tcp-listener-port in k458 in k377 in k374 in k371 */
static void f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[64],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1518 in tcp-listener-port in k458 in k377 in k374 in k371 */
static void f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1465,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1469,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1476,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub87(t4,t3),C_fix(0));}

/* k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1479(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1508,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k1506 in k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[63],t1);}

/* k1502 in k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[61],t1,((C_word*)t0)[2]);}

/* k1477 in k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1483,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub96(t4,t3),C_fix(0));}

/* k1481 in k1477 in k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_1486(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k1495 in k1481 in k1477 in k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[62],t1);}

/* k1491 in k1481 in k1477 in k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[61],t1,((C_word*)t0)[2]);}

/* k1484 in k1481 in k1477 in k1474 in k1467 in tcp-addresses in k458 in k377 in k374 in k371 */
static void f_1486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port-data in k458 in k377 in k374 in k371 */
static void C_fcall f_1450(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1450,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1452 in ##sys#tcp-port-data in k458 in k377 in k374 in k371 */
static void f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}
else{
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[59],lf[60],((C_word*)t0)[2]);}}

/* ##sys#tcp-port->fileno in k458 in k377 in k374 in k371 */
static void f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
f_1450(t3,t2);}

/* k1446 in ##sys#tcp-port->fileno in k458 in k377 in k374 in k371 */
static void f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k458 in k377 in k374 in k371 */
static void f_1231(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1231r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1231r(t0,t1,t2,t3);}}

static void f_1231r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t6=t5;
f_1235(t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_slot(t3,C_fix(1));
t7=(C_word)C_i_nullp(t6);
t8=t5;
f_1235(t8,(C_truep(t7)?(C_word)C_u_i_car(t3):C_SCHEME_TRUE));}}

/* k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void C_fcall f_1235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1235,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t3)[1])){
t5=t4;
f_1238(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1419,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_u_call_with_values(4,0,t5,t6,t7);}}

/* a1418 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1419,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a1412 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1413,2,t0,t1);}
t2=lf[11];
f_520(t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[56]);}

/* k1403 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_1238(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[14],lf[55],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1241,2,t0,t1);}
t2=f_381(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1391,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1267(2,t6,C_SCHEME_UNDEFINED);}}

/* k1389 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1402,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1400 in k1389 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[54],t1);}

/* k1396 in k1389 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[14],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
f_485(t3,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1380 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1270(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[14],lf[53],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=f_438(((C_word*)t0)[5]);
if(C_truep(t3)){
t4=t2;
f_1273(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1368,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1366 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1377 in k1366 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[52],t1);}

/* k1373 in k1366 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[14],t1);}

/* k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=(C_word)stub75(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t5,t4);
t7=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t7)){
t8=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_1330(t12,t2);}
else{
t9=((C_word*)t0)[2];
f_1246(t9,t2);}}
else{
t8=t2;
f_1276(2,t8,C_SCHEME_UNDEFINED);}}

/* loop in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void C_fcall f_1330(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1330,NULL,2,t0,t1);}
t2=(C_word)stub117(C_SCHEME_UNDEFINED,((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1337,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
t5=((C_word*)t0)[2];
f_1246(t5,t3);}
else{
t5=t3;
f_1337(2,t5,C_SCHEME_UNDEFINED);}}

/* k1335 in loop in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
f_499(t3);}}

/* k1344 in k1335 in loop in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1330(t2,((C_word*)t0)[2]);}

/* k1274 in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(C_word)stub271(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1295,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1299,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1316,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,(C_word)stub275(t7,t2),C_fix(0));}
else{
t5=t3;
f_1282(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1314 in k1274 in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k1310 in k1274 in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[14],t1);}

/* k1297 in k1274 in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[50],t1);}

/* k1293 in k1274 in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[13],lf[14],t1);}

/* k1280 in k1274 in k1271 in k1268 in k1265 in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[33];
f_818(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void C_fcall f_1246(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1246,NULL,2,t0,t1);}
t2=f_411(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1251 in fail in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1264,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1262 in k1251 in fail in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k1258 in k1251 in fail in k1239 in k1236 in k1233 in tcp-connect in k458 in k377 in k374 in k371 */
static void f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[14],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k458 in k377 in k374 in k371 */
static void f_1189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1189,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=f_479(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1196,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1205,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t5;
f_1196(2,t7,C_SCHEME_UNDEFINED);}}

/* k1203 in tcp-accept-ready? in k458 in k377 in k374 in k371 */
static void f_1205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1214 in k1203 in tcp-accept-ready? in k458 in k377 in k374 in k371 */
static void f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[48],t1);}

/* k1210 in k1203 in tcp-accept-ready? in k458 in k377 in k374 in k371 */
static void f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[47],t1,((C_word*)t0)[2]);}

/* k1194 in tcp-accept-ready? in k458 in k377 in k374 in k371 */
static void f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k458 in k377 in k374 in k371 */
static void f_1132(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1132,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1141,a[2]=t5,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1141(t7,t1);}

/* loop in tcp-accept in k458 in k377 in k374 in k371 */
static void C_fcall f_1141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1141,NULL,2,t0,t1);}
t2=f_479(((C_word*)t0)[4]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)stub29(C_SCHEME_UNDEFINED,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1154,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t5;
f_1154(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[8]+1),((C_word*)t0)[4],C_SCHEME_TRUE);}}

/* k1175 in loop in tcp-accept in k458 in k377 in k374 in k371 */
static void f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_499(t2);}

/* k1178 in k1175 in loop in tcp-accept in k458 in k377 in k374 in k371 */
static void f_1180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_1141(t2,((C_word*)t0)[2]);}

/* k1161 in loop in tcp-accept in k458 in k377 in k374 in k371 */
static void f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1174,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1172 in k1161 in loop in tcp-accept in k458 in k377 in k374 in k371 */
static void f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[46],t1);}

/* k1168 in k1161 in loop in tcp-accept in k458 in k377 in k374 in k371 */
static void f_1170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[45],t1,((C_word*)t0)[2]);}

/* k1152 in loop in tcp-accept in k458 in k377 in k374 in k371 */
static void f_1154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=lf[33];
f_818(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k458 in k377 in k374 in k371 */
static void C_fcall f_818(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_818,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=f_438(t2);
if(C_truep(t4)){
t5=t3;
f_822(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1119,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k1117 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1128 in k1117 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[44],t1);}

/* k1124 in k1117 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[13],t1);}

/* k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_825,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1024));}

/* k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[38],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_825,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_831,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1037,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1072,a[2]=t10,a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t15=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t11,t12,t13,t14);}

/* a1071 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1072,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_428(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_411(((C_word*)t0)[3]);
t6=t4;
f_1086(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1086(t5,C_SCHEME_FALSE);}}}

/* k1084 in a1071 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void C_fcall f_1086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1087 in k1084 in a1071 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1098 in k1087 in k1084 in a1071 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[43],t1);}

/* k1094 in k1087 in k1084 in a1071 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* a1036 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1037,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_479(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1050,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1059,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1050(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1057 in a1036 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1066,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1068 in k1057 in a1036 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[42],t1);}

/* k1064 in k1057 in a1036 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1048 in a1036 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_976,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_992,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_996,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_996(t7,t3);}
else{
t3=t2;
f_976(t3,C_SCHEME_UNDEFINED);}}

/* loop in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void C_fcall f_996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_996,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=(C_word)stub58(C_SCHEME_UNDEFINED,t2,t4,C_fix(1024),C_fix(0));
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1015,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=*((C_word*)lf[40]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,*((C_word*)lf[8]+1),((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1024,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}}

/* k1022 in loop in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1033 in k1022 in loop in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[41],t1);}

/* k1029 in k1022 in loop in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* k1013 in loop in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_499(t2);}

/* k1016 in k1013 in loop in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_1018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_996(t2,((C_word*)t0)[2]);}

/* k990 in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
f_976(t4,t3);}

/* k974 in a971 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void C_fcall f_976(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_834,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_865,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a928 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_929,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(2)))?C_SCHEME_UNDEFINED:f_428(((C_word*)t0)[3],C_fix((C_word)SD_SEND)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_943,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_411(((C_word*)t0)[3]);
t6=t4;
f_943(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_943(t5,C_SCHEME_FALSE);}}}

/* k941 in a928 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void C_fcall f_943(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_943,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k944 in k941 in a928 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_957,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k955 in k944 in k941 in a928 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[39],t1);}

/* k951 in k944 in k941 in a928 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[13],t1,((C_word*)t0)[2]);}

/* a864 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_865,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(C_word)C_block_size(((C_word*)t3)[1]);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_874,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t6,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_874(t10,t1);}

/* loop in a864 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void C_fcall f_874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_874,NULL,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=((C_word*)((C_word*)t0)[5])[1];
t4=((C_word*)((C_word*)t0)[4])[1];
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=(C_word)stub46(C_SCHEME_UNDEFINED,t2,t5,t4,C_fix(0));
t7=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t7)){
t8=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_893,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
f_499(t9);}
else{
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_899,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t6,((C_word*)((C_word*)t0)[4])[1]))){
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_920,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,((C_word*)((C_word*)t0)[5])[1],t6,((C_word*)((C_word*)t0)[4])[1]);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}}}

/* k918 in loop in a864 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=((C_word*)((C_word*)t0)[3])[1];
f_874(t5,((C_word*)t0)[2]);}

/* k897 in loop in a864 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k908 in k897 in loop in a864 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[38],t1);}

/* k904 in k897 in loop in a864 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[13],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k891 in loop in a864 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_874(t2,((C_word*)t0)[2]);}

/* k832 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[34]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[35]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[36]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[36]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_863,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t7=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[4]);}

/* k861 in k832 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=(C_word)C_i_setslot(t1,C_fix(0),((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k857 in k861 in k832 in k829 in k823 in k820 in ##net#io-ports in k458 in k377 in k374 in k371 */
static void f_859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_setslot(t1,C_fix(0),((C_word*)t0)[5]);
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* tcp-close in k458 in k377 in k374 in k371 */
static void f_788(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_788,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=f_411(t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_801,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k799 in tcp-close in k458 in k377 in k374 in k371 */
static void f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_801,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_812,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k810 in k799 in tcp-close in k458 in k377 in k374 in k371 */
static void f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[30],t1);}

/* k806 in k799 in tcp-close in k458 in k377 in k374 in k371 */
static void f_808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[29],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k458 in k377 in k374 in k371 */
static void f_779(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_779,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[26]):C_SCHEME_FALSE));}

/* tcp-listen in k458 in k377 in k374 in k371 */
static void f_687(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_687r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_687r(t0,t1,t2,t3);}}

static void f_687r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_689,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_729,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_734,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
t7=t6;
f_734(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
t9=t5;
f_729(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
t11=t4;
f_689(t11,t1,t7,t9);}}}

/* def-w178 in tcp-listen in k458 in k377 in k374 in k371 */
static void C_fcall f_734(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_734,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
f_729(t2,t1,C_fix(10));}

/* def-host179 in tcp-listen in k458 in k377 in k374 in k371 */
static void C_fcall f_729(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_729,NULL,3,t0,t1,t2);}
t3=((C_word*)t0)[2];
f_689(t3,t1,t2,C_SCHEME_FALSE);}

/* body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void C_fcall f_689(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_689,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_701,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_u_call_with_values(4,0,t1,t4,t5);}

/* a700 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_701,4,t0,t1,t2,t3);}
t4=t2;
t5=((C_word*)t0)[3];
t6=(C_word)stub22(C_SCHEME_UNDEFINED,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_708,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_717,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=t7;
f_708(2,t9,C_SCHEME_UNDEFINED);}}

/* k715 in a700 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k726 in k715 in a700 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[27],t1);}

/* k722 in k715 in a700 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[19],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k706 in a700 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_708,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[26],((C_word*)t0)[2]));}

/* a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_695,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=f_381(C_fix((C_word)AF_INET),t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_606,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_682,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t9=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_606(2,t8,C_SCHEME_UNDEFINED);}}

/* k680 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[25]);}

/* k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_674,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_675,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_675 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_675(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_675,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub161(C_SCHEME_UNDEFINED,t2));}

/* k672 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_674,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_609(2,t3,C_SCHEME_UNDEFINED);}}

/* k657 in k672 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_670,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k668 in k657 in k672 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[23],t1);}

/* k664 in k657 in k672 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[19],t1,((C_word*)t0)[2]);}

/* k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k610 in k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_647,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
f_485(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=t2;
f_615(2,t5,(C_word)stub149(C_SCHEME_UNDEFINED,t4,((C_word*)t0)[3]));}}

/* k645 in k610 in k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_615(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[19],lf[21],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k613 in k610 in k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_615,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
t5=(C_word)stub13(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_621,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_630,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_621(2,t8,C_SCHEME_UNDEFINED);}}

/* k628 in k613 in k610 in k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_630,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_641,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k639 in k628 in k613 in k610 in k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[20],t1);}

/* k635 in k628 in k613 in k610 in k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[13],lf[19],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k619 in k613 in k610 in k607 in k604 in a694 in body176 in tcp-listen in k458 in k377 in k374 in k371 */
static void f_621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#parse-host in k458 in k377 in k374 in k371 */
static void C_fcall f_520(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_520,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_529,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_529(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void C_fcall f_529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_529,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_552,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_fixnum_increase(t2);
t7=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_556,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_556,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_467,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=t4;
f_467(2,t5,C_SCHEME_FALSE);}}

/* k465 in k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_471,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_471(2,t3,C_SCHEME_FALSE);}}

/* k469 in k465 in k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
t2=(C_word)stub104(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_562,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_568,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=*((C_word*)lf[18]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_562(2,t5,C_SCHEME_UNDEFINED);}}

/* k566 in k469 in k465 in k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k577 in k566 in k469 in k465 in k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[16],t1);}

/* k573 in k566 in k469 in k465 in k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[13],lf[14],t1,((C_word*)t0)[2]);}

/* k560 in k469 in k465 in k554 in k550 in loop in ##net#parse-host in k458 in k377 in k374 in k371 */
static void f_562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k458 in k377 in k374 in k371 */
static void C_fcall f_499(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_499,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_505,tmp=(C_word)a,a+=2,tmp);
C_call_cc(3,0,t1,t2);}

/* a504 in yield in k458 in k377 in k374 in k371 */
static void f_505(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_505,3,t0,t1,t2);}
t3=*((C_word*)lf[8]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_514,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a513 in a504 in yield in k458 in k377 in k374 in k371 */
static void f_514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_514,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k458 in k377 in k374 in k371 */
static void C_fcall f_485(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_485,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?t2:C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_494,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t7=t6;
f_494(2,t7,C_SCHEME_FALSE);}}

/* k492 in ##net#gethostaddr in k458 in k377 in k374 in k371 */
static void f_494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub123(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* ##net#select in k458 in k377 in k374 in k371 */
static C_word C_fcall f_479(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub113(C_SCHEME_UNDEFINED,t1));}

/* ##net#make-nonblocking in k377 in k374 in k371 */
static C_word C_fcall f_438(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub83(C_SCHEME_UNDEFINED,t1));}

/* ##net#shutdown in k377 in k374 in k371 */
static C_word C_fcall f_428(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub68(C_SCHEME_UNDEFINED,t1,t2));}

/* ##net#close in k377 in k374 in k371 */
static C_word C_fcall f_411(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub39(C_SCHEME_UNDEFINED,t1));}

/* ##net#socket in k377 in k374 in k371 */
static C_word C_fcall f_381(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)stub5(C_SCHEME_UNDEFINED,t1,t2,t3));}
/* end of file */
